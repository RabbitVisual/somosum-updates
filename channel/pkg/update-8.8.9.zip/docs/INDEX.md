# Documentação oficial — SOMOSUM

Portal do **SOMOSUM**, sistema de projeção para cultos **100% offline**.

**Autor:** Reinan Rodrigues · **Versão canônica:** `8.8.9` (arquivo `VERSION` na raiz — lida pelo Painel, `/api/health` e o instalador).

## Como ler

| Quem | Onde |
|------|------|
| **Operador** (app rodando) | **http://127.0.0.1:PORTA/docs/** — portal com Markdown formatado |
| **Desenvolvimento** | pasta `docs/` neste repositório · **README.md** na raiz |
| **Programadores** | [`DOCUMENTACAO-TECNICA-PROGRAMADORES.md`](DOCUMENTACAO-TECNICA-PROGRAMADORES.md) |

## Glossário (8.7.9)

| Termo | Significado |
|-------|-------------|
| **Painel** | **Painel Gerencial** — janela principal do EXE (`/launcher/panel.html`). Hub: abrir telas, Loja, LAN/PIN, monitores, desempenho, backup, igreja, Sobre (versão + novidades ao vivo). |
| **Layout MVC** | Pastas físicas `model/` · `view/` · `controller/` com URLs públicas estáveis (`/control.html`, `/js/*`, …) via `ContentLayout`. Ver [`architecture/estrutura-mvc.md`](architecture/estrutura-mvc.md). |
| **PluginHost** | Host JS autoritativo (`/js/plugins/plugin-host.js`). Carrega ES modules de `model/data/plugins/`, executa lifecycle **`activate` / `deactivate`** por superfície (Control ≠ Screen ≠ Stage ≠ Remote), quarantine e instalação ZIP. O Engine C# participa apenas da allowlist e de `POST /api/plugins/install\|uninstall`. |
| **Plugin Studio** | Página dedicada no Controle para configurar cada plugin (`controller/js/plugins/studio/*`). View `plugin:{id}:studio`, prévia local 16:9, abas Geral/Aparência/Ações. |
| **Control Center** | Catálogo em **Ajustes → Plugins**: ligar/desligar, **Como usar**, **Abrir Studio**, Reativar (quarantine) e Desinstalar. |
| **Plugin Hub** | Painel de saúde em **Mais → Configurar plugins**: status, `lastError`, quarantine e atalho ao Studio. |
| **chromeTheme** | Preferência global `prefs.ui.chromeTheme` (`dark` \| `light`). Define o **chrome operador** — **não** altera atmosferas da projeção (`projectionTheme`). |
| **quarantine** | Proteção do PluginEngine: após três falhas consecutivas, o plugin fica isolado ~5 min até **Reativar**. |
| **LogService** | Cliente de observabilidade: ring buffer + flush para `POST /api/log` (**204**, sem disco). Suporte via **Diagnóstico**. |
| **runtimeEngine.enabled** | Flag em `model/data/config.json` da ponte JS/COM de projeção nativa — **não** indica se o Kestrel está ativo. |
| **Tour v11** | Guia interativo do Controle (tecla **?** · Ajuda → Tour guiado). Linguagem clara, passos leves. |
| **Sobre (Painel)** | Versão instalada, cards **O que há de novo** (lidos da release notes) e mapa clicável das 10 seções. |

## Estrutura

| Pasta / arquivo | Conteúdo |
|-----------------|----------|
| `guides/` | Operação, guia do operador, deploy, backup, recovery, diagnóstico, plugins, atualização |
| `architecture/` | Arquitetura, estrutura MVC, rede/Remote, contratos runtime |
| `enterprise/` | Motores, checklists, threat model (engenharia) |
| `enterprise/PRODUCTION-RELEASE-8.0.0/` | Evidências históricas da release 8.0 |
| `model/content/` | Seed de build (hinários → `model/data/default-hinarios.json`) |
| `governance/` | Regras de arquitetura |
| `releases/` | Notas de release (`RELEASE-NOTES-8.7.9.md`, …) |
| `changelog.md` / `roadmap.md` | Histórico e próximos passos |

O Setup de produção inclui o portal (`docs/index.html` + Markdown do catálogo).

## Início rápido (operador)

1. Instale com **`SOMOSUM-Setup.exe`** ou rode **`SOMOSUM.exe`**.
2. Abre o **Painel Gerencial** + ícone na bandeja.
3. **Telas** → Controle / Projeção / Stage / Remote.
4. No Controle: tecla **?** = tour guiado (v11) · tecla **D** = documentação.
5. **Rede** → Modo LAN → **Preparar rede** (UAC) → QR no celular.
6. **Púlpito:** Central Stage → aba Púlpito → monitor + tela cheia → Abrir (Pregador).
7. **Sobre:** confira a versão e o que há de novo nesta instalação.

Leitura recomendada: [`guides/guia-operador.md`](guides/guia-operador.md) · [`guides/funcionamento-atual.md`](guides/funcionamento-atual.md).

## Instalação

- **Oficial:** `dist\SOMOSUM-Setup.exe`
- **Portátil / dev:** `scripts\compile-launcher.ps1` → `app\SOMOSUM.exe`
- Confiabilidade: [`installer/CONFIABILIDADE.md`](../installer/CONFIABILIDADE.md)
- Textos do assistente (pt-BR): `installer/wizard-boas-vindas.txt`, `wizard-pos-instalacao.txt`, `TERMOS-DE-USO.txt`

## Rede (resumo)

Sem **Preparar rede** + UAC, o celular na Wi-Fi não alcança a porta (só `127.0.0.1` no PC).

Guia: [`guides/funcionamento-atual.md`](guides/funcionamento-atual.md) · Técnico: [`architecture/remote-network.md`](architecture/remote-network.md).

## Desenvolvimento

```powershell
node scripts/bump-version.js [x.y.z]
powershell -File scripts\compile-launcher.ps1
powershell -File scripts\build-all.ps1
```

Scripts em `scripts\` são para desenvolvedor/CI — não vão no atalho do usuário final.
