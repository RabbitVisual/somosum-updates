# Release Notes — SOMOSUM 8.8.9

**Data:** 2026-08-19  
**Tipo:** projeção tela cheia + ordem do culto

## Destaques

### Projetor — tela cheia, brilho e clareza
- Ao abrir o sistema, a janela de projeção **identifica o monitor** e preenche os pixels nativos (sem faixa preta ao redor).
- Vídeo e fundo de culto usam **preenchimento máximo** (cover) em todos os tipos de slide — boas-vindas, letra, Bíblia, mensagem, oferta, ceia, mídia, PPTX e os demais.
- Margem de segurança só no **texto** (cerca de 2%), para nada importante cair fora do quadro do projetor antigo, sem “encolher” a imagem.
- Contraste e brilho automáticos conforme o aparelho (projetor / TV / LED).
- Vídeo mais fluido (GPU no WebView); zoom da janela travado em 100%.

### Ordem do culto — inspetor e conteúdo
- Leitura **responsiva** e **interlinear**: dá para mudar a passagem depois de adicionar.
- Roteiro da mensagem (teleprompter) grava de verdade.
- Comunicados: só emoji/símbolo no início vira ícone.
- Introito sem trecho: só a referência na tela da igreja (sem aviso de operador).
- Ceia: texto das fases não some ao adicionar/remover fase.
- Título do introito deixa de ser forçado.
- Assistente da Bíblia espera o seletor carregar.
- Apresentação (PPTX) abre o importador (não entra vazio).
- Avisos, texto livre, tema, oferta, pausa e áudio acompanham o Ao vivo.

## Como atualizar
1. Em **8.8.8**: Ajuda → Verificar atualização → **8.8.9** → confirme o reinício.
2. Se estiver atrás: suba de 1 em 1 até **8.8.9**.
3. Ligue o projetor, abra o SOMOSUM e **Projeção** — a imagem deve ocupar a tela inteira.

## Verificação rápida
- [ ] Sobre = **8.8.9**
- [ ] Projetor ligado: slide de louvor e vídeo sem barras pretas nas bordas
- [ ] Texto da letra/Bíblia grande e legível
- [ ] Leitura responsiva: mudar passagem no inspetor
- [ ] Adicionar → Apresentação abre o importador de PowerPoint
