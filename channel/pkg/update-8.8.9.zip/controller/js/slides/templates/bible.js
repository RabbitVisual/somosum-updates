import { esc } from '../../core/render-engine/index.js';
import { renderInterlinearSlideHtml } from '../../bible/interlinear-render.js';
import { wrapScriptHtml, verseDirectionMeta } from '../text-direction.js';
import { slideStyleVars, slidePersistClass } from './shared.js';
import { standardSlideBg } from './registry-background.js';

function bibleVersesHtml(verses, meta = {}) {
  const dir = meta.dir || 'ltr';
  const lang = meta.lang || '';
  const dirAttr = dir === 'rtl' ? ' dir="rtl" lang="he"' : (lang ? ` lang="${lang}"` : '');
  return (verses || [])
    .map((v) => {
      const vDir = v.dir || dir;
      const vLang = v.lang || lang;
      const cls = vDir === 'rtl' ? ' bible-verse--rtl' : (vLang === 'grc' ? ' bible-verse--grc' : '');
      const inner = wrapScriptHtml(v.text, { lang: vLang, dir: vDir });
      return `<p class="bible-verse${cls}"${vDir === 'rtl' ? ' dir="rtl" lang="he"' : (vLang === 'grc' ? ' lang="grc"' : '')}><sup class="verse-num">${v.number}</sup> ${inner}</p>`;
    })
    .join('');
}

export function renderBibleInterlinear(slide, options = {}) {
  return renderInterlinearSlideHtml(slide, {
    surface: 'screen',
    liveView: options.liveView || slide.liveView || null,
    styleVars: slideStyleVars(slide.style),
  });
}

export function renderBibleResponsive(slide) {
  const segments = slide.segments || [];
  const rows = segments.map((seg) => {
    const roleCls = seg.role === 'leader' ? 'bible-resp-leader' : 'bible-resp-congregation';
    const label = seg.role === 'leader' ? 'Dirigente' : 'Congregação';
    return `
      <div class="bible-resp-row ${roleCls}">
        <span class="bible-resp-label">${label}</span>
        <p class="bible-resp-text"><sup>${seg.number}</sup> ${esc(seg.text)}</p>
      </div>`;
  }).join('');
  return `
    <div class="slide slide-bible slide-bible-responsive${slidePersistClass()}" data-type="bible-responsive" style="${slideStyleVars(slide.style)}">
      ${standardSlideBg(slide)}
      <div class="slide-content anim-fade-up">
        <h2 class="bible-ref">${esc(slide.reference)}</h2>
        <div class="bible-responsive-stack">${rows}</div>
      </div>
    </div>`;
}

export function renderBible(slide) {
  if (slide.displayMode === 'excerpt' || slide.excerptText) {
    const ref = slide.reference || '';
    const excerpt = slide.excerptText?.trim() || '';
    return `
      <div class="slide slide-bible slide-bible-intro${slidePersistClass()}" data-type="bible" style="${slideStyleVars(slide.style)}">
        ${standardSlideBg(slide)}
        <div class="slide-content anim-fade-up">
          ${ref ? `<p class="bible-intro-ref">${esc(ref)}:</p>` : ''}
          ${excerpt
            ? `<blockquote class="bible-intro-excerpt">“${esc(excerpt)}”</blockquote>`
            : ''}
        </div>
      </div>`;
  }

  if (slide.referenceOnly || !slide.verses?.length) {
    const stacked = (slide.refLayout || 'stacked') === 'stacked' && slide.referenceParts?.bookName;
    const parts = slide.referenceParts || {};
    const chapterOnly = !!(slide.chapterOnly || parts.chapterOnly);
    const ver = parts.version ? `<span class="bible-ref-ver">(${esc(parts.version)})</span>` : '';
    return `
      <div class="slide slide-bible slide-bible-ref${chapterOnly ? ' is-chapter-only' : ''}${slidePersistClass()}" data-type="bible" style="${slideStyleVars(slide.style)}">
        ${standardSlideBg(slide)}
        <div class="slide-content anim-fade-up">
          ${stacked ? `
            <div class="bible-ref-stack${chapterOnly ? ' is-chapter-only' : ''}" aria-label="${esc(slide.reference || '')}">
              <div class="bible-ref-book">${esc(parts.bookName)}</div>
              <div class="bible-ref-cvs">${esc(parts.chapterVerse)}${ver}</div>
            </div>` : `
            <h1 class="bible-ref-only">${esc(slide.reference)}</h1>`}
        </div>
      </div>`;
  }

  if (slide.versesB?.length || slide.dual) {
    const labelA = slide.versionLabel || slide.version || '';
    const labelB = slide.versionLabelB || slide.versionB || '';
    return `
      <div class="slide slide-bible slide-bible-dual${slidePersistClass()}" data-type="bible" style="${slideStyleVars(slide.style)}">
        ${standardSlideBg(slide)}
        <div class="slide-content anim-fade-up">
          <h2 class="bible-ref">${esc(slide.reference)}</h2>
          <div class="bible-dual">
            <div class="bible-dual-col">
              ${labelA ? `<p class="bible-dual-label">${esc(labelA)}</p>` : ''}
              <div class="bible-verses">${bibleVersesHtml(slide.verses)}</div>
            </div>
            <div class="bible-dual-col">
              ${labelB ? `<p class="bible-dual-label">${esc(labelB)}</p>` : ''}
              <div class="bible-verses">${bibleVersesHtml(slide.versesB || [])}</div>
            </div>
          </div>
        </div>
      </div>`;
  }

  return `
    <div class="slide slide-bible${slidePersistClass()}" data-type="bible" style="${slideStyleVars(slide.style)}">
      ${standardSlideBg(slide)}
      <div class="slide-content anim-fade-up">
        <h2 class="bible-ref">${esc(slide.reference)}</h2>
        <div class="bible-verses">${bibleVersesHtml(slide.verses, verseDirectionMeta(slide))}</div>
      </div>
    </div>`;
}

export function renderBibleReader(slide) {
  const theme = slide.readerTheme || 'dark';
  const fontSize = slide.readerStyle?.fontSize || 44;
  const verses = (slide.verses || [])
    .map((v) => `<p class="bible-reader-verse"><sup class="verse-num">${v.number}</sup> ${esc(v.text)}</p>`)
    .join('');

  return `
    <div class="slide slide-bible-reader bible-reader-theme--${theme}" data-type="bible-reader" style="--reader-font-size:${fontSize}px">
      <div class="slide-bg bible-reader-bg"></div>
      <div class="slide-content bible-reader-content anim-fade-up">
        <header class="bible-reader-header">
          <h1 class="bible-reader-chapter">${esc(slide.chapterTitle || '')}</h1>
          <p class="bible-reader-range">${esc(slide.slideRange || '')}</p>
          ${slide.slideCount > 1 ? `<span class="bible-reader-counter">${(slide.slideIndex ?? 0) + 1} / ${slide.slideCount}</span>` : ''}
        </header>
        <div class="bible-reader-verses">${verses}</div>
      </div>
    </div>`;
}
