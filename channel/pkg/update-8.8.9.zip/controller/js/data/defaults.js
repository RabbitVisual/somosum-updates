export const DEFAULTS = {
  event: {
    title: '',
    church: '',
    theme: '',
    motto: '',
    mottoText: '',
  },
  prayers: {},
  sections: {},
  message: {
    title: 'Mensagem Bíblica',
    preacher: '',
    reference: '',
  },
  displayEngine: {
    safeAreaGlobal: { top: 2, right: 2, bottom: 2, left: 2 },
    videoFitDefault: 'cover',
    maxLegibility: true,
  },
};
