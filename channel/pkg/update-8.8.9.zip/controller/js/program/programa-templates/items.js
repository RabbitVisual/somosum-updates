﻿import { generateId } from '../../core/store.js';
import {
  resolveWelcomePreset,
} from '../../slides/welcome-config.js';

function welcomeItem(data = {}, church = {}) {
  const presetId = data.welcomePreset || data.preset || 'domingo';
  const base = resolveWelcomePreset(presetId, church);
  const merged = { ...base, ...data, welcomePreset: presetId };
  return {
    id: generateId(),
    type: 'welcome',
    title: data.title || 'Boas-Vindas',
    slideType: 'welcome',
    data: {
      title: data.title || 'Boas-Vindas',
      theme: merged.theme ?? '',
      subtitle: merged.subtitle ?? '',
      years: merged.years || 'Bem-vindos',
      badge: merged.badge ?? '',
      dateLine: merged.dateLine ?? '',
      extraLine: merged.extraLine ?? '',
      layout: merged.layout || 'center',
      logoPosition: merged.logoPosition || 'top',
      logoSize: merged.logoSize || 260,
      showLogo: merged.showLogo !== false,
      showChurchName: merged.showChurchName !== false,
      animation: merged.animation || 'classic',
      bgMotion: merged.bgMotion || 'kenburns',
      overlayStrength: merged.overlayStrength || 'strong',
      accent: merged.accent || '#d4c68d',
      accentSoft: merged.accentSoft || 'rgba(212, 198, 141, 0.28)',
      badgeStyle: merged.badgeStyle || 'pill',
      sparkles: !!merged.sparkles,
      textShine: merged.textShine !== false,
      atmosParticles: merged.atmosParticles || 'none',
      showBadge: merged.showBadge !== false,
      showTheme: merged.showTheme !== false,
      showExtra: merged.showExtra !== false,
      showSubtitle: merged.showSubtitle !== false,
      showDate: merged.showDate !== false,
      bgMediaId: merged.bgMediaId || '',
      bgMedia: merged.bgMedia || '',
      bgKind: merged.bgKind || 'image',
      welcomePreset: presetId,
    },
  };
}

function introitoItem() {
  return {
    id: generateId(),
    type: 'bible',
    title: 'Introito',
    slideType: 'bible',
    data: { role: 'introito' },
    bible: {
      version: 'naa',
      book: 'Jo',
      chapter: 17,
      verseStart: 11,
      verseEnd: 11,
      displayMode: 'excerpt',
      referenceOverride: '',
      excerptText: '',
      showText: true,
    },
  };
}

export function isIntroitoProgramItem(item) {
  return item?.slideType === 'bible' && (
    item?.data?.role === 'introito'
    || item?.id === 'a1000002-0000-4000-8000-000000000002'
  );
}

export function isBibleInspectorType(slideType) {
  return slideType === 'bible'
    || slideType === 'bible-responsive'
    || slideType === 'bible-interlinear';
}

function themeSomosUmItem() {
  return {
    id: generateId(),
    type: 'theme',
    title: 'Divisa e Tema',
    slideType: 'theme',
    data: {
      motto: 'João 17:11 (NAA)',
      mottoText: '...para que sejam um, assim como somos um.',
      theme: 'SOMOS UM',
    },
  };
}

function prayerItem(title) {
  return {
    id: generateId(),
    type: 'prayer',
    title,
    slideType: 'prayer',
    data: { title },
  };
}

function sectionItem(title) {
  return {
    id: generateId(),
    type: 'section',
    title,
    slideType: 'section',
    data: { title },
  };
}

function lyricsItem(title, placeholder) {
  return {
    id: generateId(),
    type: 'lyrics',
    title,
    slideType: 'lyrics',
    songId: null,
    placeholder,
  };
}

function bibleReadingItem() {
  return {
    id: generateId(),
    type: 'bible',
    title: 'Leitura Bíblica',
    slideType: 'bible',
    placeholder: 'Livro, Capítulo, Versículo X a Y',
    bible: {
      version: 'naa',
      book: 'Sl',
      chapter: 23,
      verseStart: 1,
      verseEnd: 6,
      displayMode: 'verses',
      showText: true,
      showVersion: true,
      refStyle: 'colon',
    },
  };
}

function bibleResponsiveItem() {
  return {
    id: generateId(),
    type: 'bible-responsive',
    title: 'Leitura Responsiva',
    slideType: 'bible-responsive',
    placeholder: 'Passagem alternada dirigente/congregação',
    bible: {
      version: 'naa',
      book: 'Sl',
      chapter: 24,
      verseStart: 1,
      verseEnd: 6,
      showVersion: true,
      refStyle: 'colon',
    },
  };
}

function messageItem(data = {}) {
  return {
    id: generateId(),
    type: 'message',
    title: data.title || data.theme || 'Mensagem Bíblica',
    slideType: 'message',
    bible: data.bible || {
      version: 'naa',
      book: 'Jo',
      chapter: 17,
      verseStart: 11,
      verseEnd: 11,
      refStyle: 'colon',
    },
    data: {
      messageMode: data.messageMode || 'ref_pregador',
      theme: data.theme || '',
      mottoText: data.mottoText || '',
      showMotto: data.showMotto !== false,
      referenceOverride: data.referenceOverride || '',
      reference: data.reference || '',
      preacher: data.preacher || '',
      preacherFrom: data.preacherFrom || '',
      preacherPhotoId: data.preacherPhotoId || null,
      showVersion: data.showVersion !== false,
      scriptRaw: data.scriptRaw || '',
      scriptBlocks: data.scriptBlocks || [],
      style: { fontSize: 72, textTransform: 'uppercase' },
    },
  };
}

function announcementsItem() {
  return {
    id: generateId(),
    type: 'announcements',
    title: 'Comunicados',
    slideType: 'announcements',
    data: {
      title: 'Comunicados',
      items: [],
    },
  };
}

function mediaAudioItem(title, hint = '') {
  return {
    id: generateId(),
    type: 'media-audio',
    title,
    slideType: 'media-audio',
    placeholder: hint,
    data: {
      audioPath: null,
      loop: false,
      hint: hint || 'Selecione áudio de fundo (~5 min)',
      screenTitle: title,
    },
  };
}

function celebrationSpine({
  welcomeTitle = 'Boas-Vindas',
  welcomePreset = 'domingo',
  church = {},
  welcomeExtra = {},
} = {}) {
  return [
    welcomeItem({ title: welcomeTitle, welcomePreset, ...welcomeExtra }, church),
    introitoItem(),
    prayerItem('Oração inicial'),
    sectionItem('Momento de louvores'),
    lyricsItem('Música 1', 'Música 1 — escolha no Louvores'),
    lyricsItem('Música 2', 'Música 2 — escolha no Louvores'),
    lyricsItem('Música 3', 'Música 3 — escolha no Louvores'),
    bibleReadingItem(),
    sectionItem('Dedicação de Vidas e Bens'),
    lyricsItem('Música 4', 'Música 4 — Dedicação — escolha no Louvores'),
    sectionItem('Momento de expressão de gratidão e pedidos'),
    prayerItem('Oração de Gratidão'),
    sectionItem('Confraternização'),
    lyricsItem('Música 5', 'Música 5 — Confraternização — escolha no Louvores'),
    lyricsItem('Música 6', 'Música 6 — Confraternização — escolha no Louvores'),
    messageItem({ title: 'Mensagem Bíblica', reference: 'Livro, Capítulo, Versículo X a Y' }),
    prayerItem('Oração Final / Bênção Apostólica'),
  ];
}

export {
  welcomeItem,
  introitoItem,
  themeSomosUmItem,
  prayerItem,
  sectionItem,
  lyricsItem,
  bibleReadingItem,
  bibleResponsiveItem,
  messageItem,
  announcementsItem,
  mediaAudioItem,
  celebrationSpine,
};
