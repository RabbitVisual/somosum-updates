﻿import { generateId } from '../../core/store.js';
import { createCommunionItem } from '../../data/communion-defaults.js';
import {
  applyPackSlideDefaults,
  getCultoThemePack,
  welcomeVisualFromPack,
} from '../culto-theme-packs.js';
import {
  isIntroitoProgramItem,
  isBibleInspectorType,
  welcomeItem,
  introitoItem,
  themeSomosUmItem,
  prayerItem,
  sectionItem,
  lyricsItem,
  bibleReadingItem,
  messageItem,
  mediaAudioItem,
  celebrationSpine,
} from './items.js';

export { isIntroitoProgramItem, isBibleInspectorType };

export function createBlankProgram() {
  return [];
}

/**
 * Ordem padrão — Culto de Celebração (domingos 18:30).
 * Usada em: restaurar programa, novo culto domingo, template 📋 Ordem.
 */
export function createDefaultProgram(church = {}) {
  const pack = getCultoThemePack('domingo');
  const visual = welcomeVisualFromPack('domingo');
  return applyPackSlideDefaults(
    celebrationSpine({
      welcomeTitle: 'Boas-Vindas',
      welcomePreset: pack.welcomePreset,
      church,
      welcomeExtra: visual,
    }),
    pack
  );
}

export function createDomingoProgram(church = {}) {
  return createDefaultProgram(church);
}

/** Ordem padrão — Culto de Oração (quartas 19:00), com momento de oração + fundo musical. */
export function createQuartaProgram(church = {}) {
  const pack = getCultoThemePack('quarta');
  const visual = welcomeVisualFromPack('quarta');
  const items = celebrationSpine({
    welcomeTitle: 'Boas-Vindas',
    welcomePreset: pack.welcomePreset,
    church,
    welcomeExtra: visual,
  });
  const afterMusic3 = 7;
  items.splice(
    afterMusic3,
    0,
    sectionItem('Momento de oração'),
    mediaAudioItem(
      'Fundo Musical para 5 min de oração',
      'Selecione áudio de fundo / ~5 min'
    )
  );
  return applyPackSlideDefaults(items, pack);
}

export function createEspecialProgram(church = {}) {
  const pack = getCultoThemePack('especial');
  const visual = welcomeVisualFromPack('especial');
  const items = celebrationSpine({
    welcomeTitle: 'Boas-Vindas',
    welcomePreset: pack.welcomePreset,
    church,
    welcomeExtra: visual,
  });
  items.splice(1, 0, {
    id: generateId(),
    type: 'theme',
    title: 'Tema do Evento',
    slideType: 'theme',
    data: { motto: '', mottoText: '', theme: '' },
  });
  return applyPackSlideDefaults(items, pack);
}

export function createMulheresProgram(church = {}) {
  const pack = getCultoThemePack('mulheres');
  const visual = welcomeVisualFromPack('mulheres');
  const items = [
    welcomeItem({ title: 'Boas-Vindas', welcomePreset: 'mulheres', ...visual }, church),
    introitoItem(),
    prayerItem('Oração inicial'),
    sectionItem('Momento de louvor'),
    lyricsItem('Música 1', 'Música 1 — escolha no Louvores'),
    lyricsItem('Música 2', 'Música 2 — escolha no Louvores'),
    bibleReadingItem(),
    sectionItem('Palavra / testemunho'),
    messageItem({ title: 'Palavra', reference: 'Livro, Capítulo, Versículo X a Y' }),
    sectionItem('Dedicação e gratidão'),
    lyricsItem('Música 3', 'Música 3 — Dedicação — escolha no Louvores'),
    lyricsItem('Música 4', 'Música 4 — escolha no Louvores'),
    prayerItem('Oração Final / Bênção'),
  ];
  return applyPackSlideDefaults(items, pack);
}

export function createHomensProgram(church = {}) {
  const pack = getCultoThemePack('homens');
  const visual = welcomeVisualFromPack('homens');
  const items = [
    welcomeItem({ title: 'Boas-Vindas', welcomePreset: 'homens', ...visual }, church),
    introitoItem(),
    prayerItem('Oração inicial'),
    sectionItem('Louvor'),
    lyricsItem('Música 1', 'Música 1 — escolha no Louvores'),
    lyricsItem('Música 2', 'Música 2 — escolha no Louvores'),
    lyricsItem('Música 3', 'Música 3 — escolha no Louvores'),
    bibleReadingItem(),
    sectionItem('Desafio / compromisso'),
    messageItem({ title: 'Mensagem', reference: 'Livro, Capítulo, Versículo X a Y' }),
    lyricsItem('Música 4', 'Música 4 — Resposta — escolha no Louvores'),
    prayerItem('Oração Final / Bênção'),
  ];
  return applyPackSlideDefaults(items, pack);
}

export function createJovensProgram(church = {}) {
  const pack = getCultoThemePack('jovens');
  const visual = welcomeVisualFromPack('jovens');
  const items = [
    welcomeItem({ title: 'Boas-Vindas', welcomePreset: 'jovens', ...visual }, church),
    sectionItem('Adoração'),
    lyricsItem('Música 1', 'Música 1 — Adoração — escolha no Louvores'),
    lyricsItem('Música 2', 'Música 2 — Adoração — escolha no Louvores'),
    lyricsItem('Música 3', 'Música 3 — Adoração — escolha no Louvores'),
    lyricsItem('Música 4', 'Música 4 — escolha no Louvores'),
    prayerItem('Oração'),
    bibleReadingItem(),
    sectionItem('Palavra para esta geração'),
    messageItem({ title: 'Mensagem', reference: 'Livro, Capítulo, Versículo X a Y' }),
    lyricsItem('Música 5', 'Música 5 — Resposta — escolha no Louvores'),
    prayerItem('Bênção'),
  ];
  return applyPackSlideDefaults(items, pack);
}

export function createCriancasProgram(church = {}) {
  const pack = getCultoThemePack('criancas');
  const visual = welcomeVisualFromPack('criancas');
  const items = [
    welcomeItem({ title: 'Boas-Vindas', welcomePreset: 'criancas', ...visual }, church),
    sectionItem('Louvor infantil'),
    lyricsItem('Música 1', 'Música infantil 1 — escolha no Louvores'),
    lyricsItem('Música 2', 'Música infantil 2 — escolha no Louvores'),
    sectionItem('História bíblica'),
    bibleReadingItem(),
    messageItem({
      title: 'História',
      reference: 'Livro, Capítulo, Versículo',
      messageMode: 'ref_pregador',
    }),
    sectionItem('Atividade / aplicação'),
    prayerItem('Bênção das crianças'),
  ];
  return applyPackSlideDefaults(items, pack);
}

export function createMissoesProgram(church = {}) {
  const pack = getCultoThemePack('missoes');
  const visual = welcomeVisualFromPack('missoes');
  const items = celebrationSpine({
    welcomeTitle: 'Boas-Vindas',
    welcomePreset: 'missoes',
    church,
    welcomeExtra: visual,
  });
  items.splice(1, 0, {
    id: generateId(),
    type: 'theme',
    title: 'Campo / Missões',
    slideType: 'theme',
    data: {
      motto: 'Mateus 28:19',
      mottoText: 'Ide, portanto, e fazei discípulos de todas as nações…',
      theme: 'Missões',
    },
  });
  const afterBible = items.findIndex((i) => /leitura bíblica/i.test(i.title || ''));
  if (afterBible >= 0) {
    items.splice(afterBible + 1, 0, sectionItem('Oferta missionária / intercessão'));
  }
  return applyPackSlideDefaults(items, pack);
}

export function createAniversarioProgram(church = {}) {
  const pack = getCultoThemePack('aniversario');
  const visual = welcomeVisualFromPack('aniversario');
  const items = celebrationSpine({
    welcomeTitle: 'Boas-Vindas',
    welcomePreset: 'aniversario',
    church,
    welcomeExtra: visual,
  });
  items.splice(1, 0, themeSomosUmItem());
  return applyPackSlideDefaults(items, pack);
}

export function createDomingoComCeiaProgram(church = {}) {
  const pack = getCultoThemePack('domingo');
  const items = createDefaultProgram(church);
  const finalIdx = items.findIndex((i) => /ora[cç][aã]o final|b[eê]n[cç][aã]o apost[oó]lica/i.test(i.title || ''));
  const insertAt = finalIdx >= 0 ? finalIdx : items.length;
  items.splice(insertAt, 0, createCommunionItem());
  return applyPackSlideDefaults(items, pack);
}

/** Resolve template pelo tipo do culto ativo (quarta / domingo / especial / calendário). */
export function createProgramForCultoType(cultoType = 'domingo', church = {}) {
  return createProgramFromTemplate(cultoType, church);
}

/** Ordens padrão embutidas no sistema (sempre disponíveis offline). */
export const BUILTIN_PROGRAM_TEMPLATES = [
  {
    id: 'domingo',
    name: 'Culto de Celebração (domingo)',
    description: 'Boas-vindas celebração + ordem completa 18:30',
  },
  {
    id: 'domingo-com-ceia',
    name: 'Celebração + Ceia do Senhor',
    description: 'Ordem de domingo com Ceia do Senhor antes da Oração Final',
  },
  {
    id: 'quarta',
    name: 'Culto de Oração (quarta)',
    description: 'Boas-vindas serenas + Momento de oração e Fundo Musical 5 min',
  },
  {
    id: 'especial',
    name: 'Culto Especial',
    description: 'Boas-vindas de evento + Tema do Evento',
  },
  {
    id: 'missoes',
    name: 'Culto de Missões',
    description: 'Boas-vindas missionárias + campo + oferta missionária',
  },
  {
    id: 'mulheres',
    name: 'Ministério de Mulheres',
    description: 'Ordem acolhedora com palavra/testemunho (4 músicas)',
  },
  {
    id: 'homens',
    name: 'Ministério de Homens',
    description: 'Ordem enxuta com desafio/compromisso',
  },
  {
    id: 'jovens',
    name: 'Culto / Encontro de Jovens',
    description: 'Adoração estendida + palavra para a geração',
  },
  {
    id: 'criancas',
    name: 'Culto / Ministério Infantil',
    description: 'Ordem curta: louvor, história bíblica, atividade e bênção',
  },
  {
    id: 'aniversario',
    name: 'Aniversário da Congregação',
    description: 'Tela especial de aniversário + divisa SOMOS UM',
  },
  {
    id: 'blank',
    name: 'Em branco',
    description: 'Ordem vazia — monte do zero',
  },
];

export function createProgramFromTemplate(template = 'domingo', church = {}) {
  switch (template) {
    case 'blank':
      return createBlankProgram();
    case 'quarta':
      return createQuartaProgram(church);
    case 'especial':
      return createEspecialProgram(church);
    case 'domingo-com-ceia':
      return createDomingoComCeiaProgram(church);
    case 'missoes':
      return createMissoesProgram(church);
    case 'mulheres':
      return createMulheresProgram(church);
    case 'homens':
      return createHomensProgram(church);
    case 'jovens':
      return createJovensProgram(church);
    case 'criancas':
      return createCriancasProgram(church);
    case 'aniversario':
      return createAniversarioProgram(church);
    case 'domingo':
    default:
      return createDomingoProgram(church);
  }
}
