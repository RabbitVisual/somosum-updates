const PREFS_KEY = 'somosum-prefs';

import { DiskAdapter } from './storage/adapters/disk-adapter.js';
import {
  waitForServerBoot,
  waitForServer,
  saveAssetToDisk,
  saveMediaToDisk,
  deleteMediaFromDisk,
  dataPublicUrl,
} from './storage/adapters/server-adapter.js';
import { runDataMigration, fixCountdownOnBoot } from './migration.js';
import { randomId } from './uuid.js';
import { DatabaseEngine } from './database/database-engine.js';
import { coordinatedSave } from './database/save-coordinator.js';
import { idbPut, idbGetAll as idbGetAllRows, idbGet as idbGetRow, idbDelete as idbDeleteRow } from './database/idb-adapter.js';
import { normalizeCountdownPresets } from './countdown.js';
import { normalizeAtmosphereId } from '../ui/theme/atmospheres.js';
import { PRODUCT_LOGO } from './brand-assets.js';

export const DEFAULT_CHURCH_LOGO = PRODUCT_LOGO;
export const DEFAULT_CHURCH_WELCOME_BG = '/IMG/FRENTE_DA_IGREJA.png';

/** Garante URL absoluta para o browser (evita /launcher/IMG/... no Painel). */
export function toPublicUrl(path) {
  const p = String(path || '').trim();
  if (!p) return '';
  if (
    p.startsWith('data:')
    || p.startsWith('blob:')
    || p.startsWith('http://')
    || p.startsWith('https://')
    || p.startsWith('/')
  ) {
    return p;
  }
  return `/${p.replace(/^\/+/, '')}`;
}

export function assetExtFromMime(mime = 'image/png') {
  if (mime.includes('jpeg') || mime.includes('jpg')) return 'jpg';
  if (mime.includes('webp')) return 'webp';
  if (mime.includes('gif')) return 'gif';
  if (mime.includes('webm')) return 'webm';
  if (mime.includes('mp4') || mime.includes('video')) return 'mp4';
  if (mime.includes('png')) return 'png';
  return 'png';
}

export function assetDiskPath(key, mime = 'image/png') {
  return dataPublicUrl(`assets/${key}.${assetExtFromMime(mime)}`);
}

/** Perfil da igreja — vazio usa padrão de fábrica; preenchido persiste o da congregação. */
export function normalizeChurchProfile(church = {}) {
  const c = { ...church };
  return {
    name: String(c.name ?? '').trim(),
    subtitle: String(c.subtitle ?? '').trim(),
    defaultWelcomeTitle: String(c.defaultWelcomeTitle ?? 'Boas-Vindas').trim() || 'Boas-Vindas',
    defaultTheme: String(c.defaultTheme ?? '').trim(),
    logoPath: toPublicUrl(String(c.logoPath ?? '').trim() || DEFAULT_CHURCH_LOGO),
    welcomeBgPath: toPublicUrl(String(c.welcomeBgPath ?? '').trim() || DEFAULT_CHURCH_WELCOME_BG),
    welcomeBgKind: c.welcomeBgKind === 'video' ? 'video' : 'image',
  };
}

/** URL do fundo padrão da igreja (boas-vindas, pré-culto, picker). */
export function resolveChurchWelcomeBgUrl({ church = {}, assets = {} } = {}) {
  return toPublicUrl(assets.welcomeBg || church.welcomeBgPath || DEFAULT_CHURCH_WELCOME_BG);
}

export function resolveChurchLogoUrl({ church = {}, assets = {} } = {}) {
  return toPublicUrl(assets.logo || church.logoPath || DEFAULT_CHURCH_LOGO);
}

export function resolveChurchWelcomeBgKind({ church = {}, url = '' } = {}) {
  if (church.welcomeBgKind === 'video' || church.welcomeBgKind === 'image') {
    return church.welcomeBgKind;
  }
  return /\.(mp4|webm|mov)(\?|$)/i.test(String(url || '')) ? 'video' : 'image';
}

export function churchWelcomeBgIsCustom({ church = {}, assets = {} } = {}) {
  const url = resolveChurchWelcomeBgUrl({ church, assets });
  const path = toPublicUrl(church.welcomeBgPath || '');
  return !!(assets.welcomeBg || (path && path !== DEFAULT_CHURCH_WELCOME_BG))
    || resolveChurchWelcomeBgKind({ church, url }) === 'video';
}

export function churchLogoIsCustom({ church = {}, assets = {} } = {}) {
  const path = toPublicUrl(church.logoPath || '');
  return !!(assets.logo || (path && path !== DEFAULT_CHURCH_LOGO));
}

const DEFAULT_PREFS = {
  /** @deprecated Prefer projectionTheme — mantido para sync legado */
  theme: 'somos-um',
  /** Atmosfera litúrgica da projeção / prévia (não recoloria o Controle) */
  projectionTheme: 'somos-um',
  church: {
    name: '',
    subtitle: '',
    defaultWelcomeTitle: 'Boas-Vindas',
    defaultTheme: '',
    logoPath: DEFAULT_CHURCH_LOGO,
    welcomeBgPath: DEFAULT_CHURCH_WELCOME_BG,
    welcomeBgKind: 'image',
  },
  navigation: {
    currentIndex: 0,
    overlay: null,
    activeCultoId: null,
    lastView: 'program',
  },
  layout: {
    sidebarWidth: 168,
    dockWidth: 320,
    inspectorWidth: 280,
    sidebarCollapsed: true,
    dockCollapsed: false,
  },
  ui: {
    scale: 1,
    fontScale: 1,
    highContrast: false,
    reducedMotion: false,
    lowSpec: false,
    chromeTheme: 'dark',
  },
  /** Modo Low-Spec — equipamento com recursos limitados: eco profile, menos animações, toast FPS */
  lowSpec: false,
  favorites: {
    items: [],
  },
  shortcuts: {},
  bibleVersion: 'naa',
  bibleQuickBook: 'Jo',
  transition: 'fade',
  showClock: false,
  showFooterVerse: true,
  versesPerSlide: 2,
  projectionFontBoost: 1.15,
  globalLyricsStyle: {
    fontSize: 80,
    lineHeight: 1.45,
    align: 'center',
    marginTop: 5,
    marginBottom: 5,
    marginLeft: 6,
    marginRight: 6,
    splitMode: 'lines',
    linesPerSlide: 3,
    highlightLine: false,
    backgroundPreset: 'theme',
    backgroundMediaId: null,
  },
  lyricsFx: {
    ambient: 'none',
    lineEntrance: 'none',
    highlightPulse: true,
  },
  autoLive: true,
  slideStripLyricsMode: 'numbers',
  rehearsalMode: false,
  productionMode: false,
  production: null,
  blockCountdownOnErrors: false,
  highContrast: false,
  /** Projeção 8.1 — auto = DOM confiável (bíblia/welcome); fluid = Canvas só em letras */
  render: {
    mode: 'auto',
    engine: 'dom',
    postFx: false,
    previewMode: 'dom',
  },
  displayEngine: {
    safeAreaGlobal: { top: 2, right: 2, bottom: 2, left: 2 },
    safeAreaByDevice: {},
    safeAreaPreset: 'TEXT',
    projectorProfile: null,
    videoFitDefault: 'cover',
    projectorDeviceName: '',
    stageDeviceName: '',
    maxLegibility: true,
    videoLegibility: 'shadow',
    videoLegibilityStrength: 0.45,
    knownDisplays: [],
  },
  ambient: {
    trackPath: null,
    volume: 0.3,
    playing: false,
    loop: true,
  },
  countdown: {
    mode: 'duration',
    serviceTime: '19:30',
    serviceDate: null,
    durationMinutes: 10,
    label: 'O culto começa em',
    announcementTitle: 'O Culto vai Começar',
    announcementDurationSec: 14,
    noticeSpotlightSec: 3.2,
    transitionDurationSec: 4,
    showBranding: true,
    showRandomVerses: true,
    verseIntervalSec: 22,
    verseSpotlightSec: 10,
    includeEventMotto: true,
    hideFooter: true,
    hideClock: true,
    autoGoToWelcome: true,
    playBell: true,
    bellPath: null,
    bellVolume: 0.7,
    fadeAmbientOnEnd: true,
    ambientFadeStart: 'transition',
    ambientFadeSec: 4,
    active: false,
    phase: 'idle',
    targetMs: null,
    startedAt: null,
    backgroundMode: 'midnight',
    backgroundDim: 0.45,
    panelMinimized: false,
  },
  countdownPresets: [],
  runtimeEngine: {
    // Keep enabled false by default for browser/non-native; native config.json enables it.
    // When enabled + bridgePreferred, sync is authoritative (legacyFallback false).
    enabled: false,
    bridgePreferred: true,
    legacyFallback: false,
    authoritativeSync: true,
    authoritativeRecovery: true,
  },
  midi: {
    enabled: false,
    deviceId: '',
    debounceMs: 120,
    actionByIntensity: false,
    maps: [
      { kind: 'note', channel: -1, code: 60, action: 'next' },
      { kind: 'note', channel: -1, code: 58, action: 'prev' },
    ],
  },
};

function normalizeDisplayEngine(de = {}) {
  const next = { ...de };
  if (next.videoFitDefault === 'contain' || next.videoFitDefault === 'fit') {
    next.videoFitDefault = 'cover';
  }
  const g = next.safeAreaGlobal || {};
  const isLegacyFour = [g.top, g.right, g.bottom, g.left].every((n) => Number(n) === 4);
  if (isLegacyFour) {
    next.safeAreaGlobal = { top: 2, right: 2, bottom: 2, left: 2 };
  }
  if (!next.safeAreaPreset || next.safeAreaPreset === 'default' || next.safeAreaPreset === 'SAFE') {
    next.safeAreaPreset = 'TEXT';
  }
  if (next.maxLegibility !== false) next.maxLegibility = true;
  return next;
}

function openDb() {
  return DatabaseEngine.init();
}

async function idbGet(storeName, key) {
  return idbGetRow(storeName, key);
}

async function idbGetAll(storeName) {
  return idbGetAllRows(storeName);
}

async function idbDelete(storeName, key) {
  return idbDeleteRow(storeName, key);
}

export function getPrefs() {
  try {
    const raw = localStorage.getItem(PREFS_KEY);
    if (!raw) return structuredClone(DEFAULT_PREFS);
    const parsed = JSON.parse(raw);
    const merged = {
      ...structuredClone(DEFAULT_PREFS),
      ...parsed,
      church: normalizeChurchProfile({ ...DEFAULT_PREFS.church, ...(parsed.church || {}) }),
      navigation: { ...DEFAULT_PREFS.navigation, ...(parsed.navigation || {}) },
      layout: { ...DEFAULT_PREFS.layout, ...(parsed.layout || {}) },
      ui: { ...DEFAULT_PREFS.ui, ...(parsed.ui || {}) },
      favorites: { ...DEFAULT_PREFS.favorites, ...(parsed.favorites || {}) },
      shortcuts: { ...DEFAULT_PREFS.shortcuts, ...(parsed.shortcuts || {}) },
      globalLyricsStyle: { ...DEFAULT_PREFS.globalLyricsStyle, ...(parsed.globalLyricsStyle || {}) },
      lyricsFx: { ...DEFAULT_PREFS.lyricsFx, ...(parsed.lyricsFx || {}) },
      ambient: { ...DEFAULT_PREFS.ambient, ...(parsed.ambient || {}) },
      countdown: { ...DEFAULT_PREFS.countdown, ...(parsed.countdown || {}) },
      countdownPresets: normalizeCountdownPresets(parsed.countdownPresets || DEFAULT_PREFS.countdownPresets),
      displayEngine: normalizeDisplayEngine({ ...DEFAULT_PREFS.displayEngine, ...(parsed.displayEngine || {}) }),
      render: { ...DEFAULT_PREFS.render, ...(parsed.render || {}) },
      runtimeEngine: { ...DEFAULT_PREFS.runtimeEngine, ...(parsed.runtimeEngine || {}) },
      midi: {
        ...DEFAULT_PREFS.midi,
        ...(parsed.midi || {}),
        maps: Array.isArray(parsed.midi?.maps) ? parsed.midi.maps : DEFAULT_PREFS.midi.maps,
      },
    };
    // Migra prefs.theme legado → projectionTheme (atmosfera litúrgica)
    const atm = normalizeAtmosphereId(merged.projectionTheme || merged.theme || 'somos-um');
    merged.projectionTheme = atm;
    merged.theme = atm;
    return merged;
  } catch {
    return structuredClone(DEFAULT_PREFS);
  }
}

function mergePrefs(partial) {
  const current = getPrefs();
  return {
    ...current,
    ...partial,
    church: normalizeChurchProfile({ ...current.church, ...(partial.church || {}) }),
    navigation: { ...current.navigation, ...(partial.navigation || {}) },
    layout: { ...current.layout, ...(partial.layout || {}) },
    ui: { ...current.ui, ...(partial.ui || {}) },
    favorites: { ...current.favorites, ...(partial.favorites || {}) },
    shortcuts: { ...current.shortcuts, ...(partial.shortcuts || {}) },
    globalLyricsStyle: { ...current.globalLyricsStyle, ...(partial.globalLyricsStyle || {}) },
    lyricsFx: { ...current.lyricsFx, ...(partial.lyricsFx || {}) },
    ambient: { ...current.ambient, ...(partial.ambient || {}) },
    countdown: { ...current.countdown, ...(partial.countdown || {}) },
    countdownPresets: normalizeCountdownPresets(partial.countdownPresets || current.countdownPresets),
    displayEngine: normalizeDisplayEngine({ ...current.displayEngine, ...(partial.displayEngine || {}) }),
    render: { ...current.render, ...(partial.render || {}) },
    runtimeEngine: { ...current.runtimeEngine, ...(partial.runtimeEngine || {}) },
    midi: {
      ...current.midi,
      ...(partial.midi || {}),
      maps: Array.isArray(partial.midi?.maps)
        ? partial.midi.maps
        : (current.midi?.maps || []),
    },
  };
}

/** Atualiza preferências só na memória do navegador (sem gravar config.json). */
export function savePrefsLocal(partial) {
  const merged = mergePrefs(partial);
  localStorage.setItem(PREFS_KEY, JSON.stringify(merged));
  return merged;
}

export function savePrefs(prefs) {
  const merged = mergePrefs(prefs);
  localStorage.setItem(PREFS_KEY, JSON.stringify(merged));
  DiskAdapter.saveDebounced('config.json', merged, 500, { silent: true });
  return merged;
}

export async function flushPrefsToDisk() {
  return DiskAdapter.save('config.json', getPrefs(), { silent: true });
}

let diskInitialized = false;

export async function initializeFromDisk() {
  if (diskInitialized) return;
  diskInitialized = true;
  await DatabaseEngine.init();
  const serverUp = await waitForServerBoot();
  if (!serverUp) {
    fixCountdownOnBoot();
    return;
  }

  const [program, songs, config] = await Promise.all([
    DiskAdapter.load('programa.json'),
    DiskAdapter.load('letras.json'),
    DiskAdapter.load('config.json'),
  ]);

  if (Array.isArray(program)) {
    await idbPut('program', { id: 'current', items: program, updatedAt: Date.now() });
  }

  const { isStressSong } = await import('./database/repositories/song-repository.js');
  const diskSongList = Array.isArray(songs)
    ? songs
    : (songs && Array.isArray(songs.songs) ? songs.songs : []);
  const diskLoaded = songs != null;
  const cleanDiskSongs = diskSongList.filter((s) => s?.id && !isStressSong(s));
  if (diskLoaded) {
    // Disco é fonte da verdade: remove stress e órfãos do IndexedDB
    const keepIds = new Set(cleanDiskSongs.map((s) => s.id));
    for (const row of await idbGetAllRows('songs')) {
      if (!keepIds.has(row?.id)) {
        await idbDeleteRow('songs', row.id);
      }
    }
    for (const song of cleanDiskSongs) {
      await idbPut('songs', song);
    }
    if (cleanDiskSongs.length !== diskSongList.length) {
      await DiskAdapter.save('letras.json', cleanDiskSongs, { silent: true });
    }
  } else {
    const { SongRepository } = await import('./database/repositories/song-repository.js');
    await SongRepository.purgeStressSongs();
  }

  if (config && typeof config === 'object') {
    localStorage.setItem(PREFS_KEY, JSON.stringify({ ...structuredClone(DEFAULT_PREFS), ...config }));
  }
  fixCountdownOnBoot();

  await hydrateMediaFromDisk();
  try {
    const { MediaRepository, isStressMedia } = await import('./database/repositories/media-repository.js');
    await MediaRepository.purgeStressMedia();
    // Disco = fonte da verdade: remove órfãos de stress/QA do IDB
    const indexRaw = await DiskAdapter.load('media/index.json');
    const { normalizeMediaIndex } = await import('./media-url.js');
    const indexMap = normalizeMediaIndex(indexRaw);
    const keepIds = new Set(Object.keys(indexMap));
    for (const row of await idbGetAllRows('media')) {
      if (!row?.id) continue;
      if (isStressMedia(row) || (keepIds.size > 0 && !keepIds.has(row.id) && String(row.id).startsWith('stress-'))) {
        await idbDeleteRow('media', row.id);
      }
    }
    // Pack antigo (sys-bg / SOMOSUM_S / sys-loop) → 404; remove do IDB/index
    try {
      const { fetchSystemMediaIndex } = await import('./media-convert.js');
      const sys = await fetchSystemMediaIndex();
      const validSys = new Set((sys?.media || []).map((m) => m?.id).filter(Boolean));
      await MediaRepository.purgeObsoleteSystemMedia(validSys);
    } catch {
      await MediaRepository.purgeObsoleteSystemMedia();
    }
    const { IndexEngine } = await import('./storage/index/index-engine.js');
    await IndexEngine.rebuildMedia();
  } catch { /* purge best-effort */ }
  await runDataMigration();
}

export async function getAsset(key) {
  return DatabaseEngine.assets.get(key);
}

export async function saveAsset(key, dataUrl, mimeType = 'image/png') {
  return DatabaseEngine.assets.save(key, dataUrl, mimeType);
}

export async function deleteAsset(key) {
  return DatabaseEngine.assets.delete(key);
}

export async function getAllAssets() {
  return DatabaseEngine.assets.getAll();
}

export async function getAllMedia() {
  return DatabaseEngine.media.getAll();
}

export async function getMedia(id) {
  return DatabaseEngine.media.getById(id);
}

export async function saveMedia(item) {
  return DatabaseEngine.media.save({
    ...item,
    id: item.id || randomId(),
  });
}

export async function deleteMedia(id) {
  return DatabaseEngine.media.delete(id);
}

export async function saveMediaFile(file, opts = {}) {
  const { convertAndSaveMediaFile } = await import('./media-convert.js');
  const converted = await convertAndSaveMediaFile(file, {
    category: opts.category,
    onProgress: opts.onProgress,
  });
  return saveMedia({
    ...converted,
    tags: converted.tags || [],
    favorite: false,
  });
}

export async function hydrateMediaFromDisk() {
  const { normalizeMediaIndex, resolveMediaSrc, buildMediaIndexPayload } = await import('./media-url.js');
  const { fetchSystemMediaIndex } = await import('./media-convert.js');

  // Merge pack do sistema (somente leitura) no índice do usuário
  try {
    const sys = await fetchSystemMediaIndex();
    const sysMedia = Array.isArray(sys?.media) ? sys.media : [];
    if (sysMedia.length) {
      const indexRaw = await DiskAdapter.load('media/index.json');
      const indexMap = normalizeMediaIndex(indexRaw);
      let changed = false;
      for (const entry of sysMedia) {
        if (!entry?.id) continue;
        const next = {
          ...entry,
          system: true,
          readonly: true,
          src: entry.src || (entry.path?.startsWith('system/') ? `/${entry.path}` : `/system/media/${entry.id}`),
          path: entry.path || `system/media/${entry.id}.${(entry.kind === 'video' ? 'mp4' : 'webp')}`,
        };
        const prev = indexMap[entry.id];
        if (!prev || prev.system) {
          indexMap[entry.id] = { ...prev, ...next, system: true, readonly: true };
          changed = true;
        }
      }
      if (changed) {
        DiskAdapter.saveDebounced('media/index.json', buildMediaIndexPayload(indexMap), 200, { silent: true });
      }
      for (const entry of sysMedia) {
        if (!entry?.id) continue;
        const existing = await idbGet('media', entry.id);
        const row = {
          ...(existing || {}),
          ...entry,
          system: true,
          readonly: true,
          src: entry.src || `/${entry.path || `system/media/${entry.id}`}`,
          path: entry.path,
          updatedAt: entry.updatedAt || Date.now(),
          createdAt: existing?.createdAt || Date.now(),
        };
        await idbPut('media', row);
      }
    }
  } catch { /* system pack optional */ }

  const indexRaw = await DiskAdapter.load('media/index.json');
  const indexMap = normalizeMediaIndex(indexRaw);
  try {
    const { pruneMissingMediaFromIndex } = await import('./media-url.js');
    const removed = await pruneMissingMediaFromIndex(indexMap);
    if (removed.length) {
      DiskAdapter.saveDebounced('media/index.json', buildMediaIndexPayload(indexMap), 200, { silent: true });
    }
  } catch { /* ignore */ }

  try {
    const sys = await fetchSystemMediaIndex();
    const validSys = new Set((sys?.media || []).map((m) => m?.id).filter(Boolean));
    const { MediaRepository } = await import('./database/repositories/media-repository.js');
    await MediaRepository.purgeObsoleteSystemMedia(validSys);
    const { IndexEngine } = await import('./storage/index/index-engine.js');
    await IndexEngine.rebuildMedia();
  } catch { /* sync system cache best-effort */ }

  const entries = Object.values(indexMap);
  if (!entries.length) return;

  for (const meta of entries) {
    if (!meta?.id) continue;
    if (meta.system) {
      const existing = await idbGet('media', meta.id);
      if (!existing) {
        await idbPut('media', {
          ...meta,
          src: resolveMediaSrc(meta),
          createdAt: meta.updatedAt || Date.now(),
        });
      }
      continue;
    }
    const existing = await idbGet('media', meta.id);
    const src = resolveMediaSrc(meta);
    // Preferir path/src em disco — evita carregar todos os arquivos como dataUrl (RAM em PCs fracos)
    if (existing?.dataUrl || existing?.src || src) {
      const next = {
        ...(existing || meta),
        ...meta,
        src: existing?.src || src,
        path: existing?.path || meta.path,
        createdAt: existing?.createdAt || meta.updatedAt || Date.now(),
      };
      // Mantém dataUrl legado se já existir; não hidrata blob novo
      if (existing?.dataUrl) next.dataUrl = existing.dataUrl;
      await idbPut('media', next);
      continue;
    }
  }
}

export async function getAllSongs() {
  return DatabaseEngine.songs.getAll();
}

export async function getSong(id) {
  return DatabaseEngine.songs.getById(id);
}

export async function saveSong(song) {
  const now = Date.now();
  const payload = {
    ...song,
    id: song.id || randomId(),
    updatedAt: now,
    createdAt: song.createdAt || now,
  };
  return coordinatedSave('save-song', () => DatabaseEngine.songs.save(payload));
}

export async function deleteSong(id) {
  return coordinatedSave('delete-song', () => DatabaseEngine.songs.delete(id));
}

export async function getProgram() {
  return DatabaseEngine.program.getItems();
}

export async function saveProgram(items) {
  return coordinatedSave('save-program', () => DatabaseEngine.program.saveItems(items));
}

export function getNavigationState() {
  return getPrefs().navigation || structuredClone(DEFAULT_PREFS.navigation);
}

export function saveNavigationState(nav) {
  return savePrefsLocal({
    navigation: { ...getNavigationState(), ...nav },
  });
}

export async function exportBackup() {
  const assets = await getAllAssets();
  const media = await getAllMedia();
  const [songs, program] = await Promise.all([getAllSongs(), getProgram()]);
  let cultos = null;
  try {
    const { loadCultoIndex, getCulto } = await import('../program/culto-manager.js');
    const index = await loadCultoIndex();
    const programs = {};
    for (const c of index.cultos || []) {
      const culto = await getCulto(c.id);
      if (culto?.items) programs[c.id] = culto.items;
    }
    cultos = { index, programs };
  } catch {
    cultos = null;
  }
  let overlays = null;
  let templates = null;
  let worshipMeta = null;
  try {
    overlays = await DiskAdapter.load('overlays.json');
    templates = await DiskAdapter.load('templates/index.json');
    worshipMeta = await DiskAdapter.load('worship-meta.json');
  } catch { /* optional */ }
  return {
    version: 5,
    schemaVersion: 4,
    exportedAt: new Date().toISOString(),
    songs,
    program,
    prefs: getPrefs(),
    assets,
    media,
    cultos,
    overlays,
    templates,
    worshipMeta,
    checksum: null,
  };
}

export async function exportBackupWithChecksum() {
  const data = await exportBackup();
  const { computeBackupChecksum } = await import('./validation/json-validator.js');
  data.checksum = await computeBackupChecksum(data);
  return data;
}

export async function importBackup(data) {
  const { importBackupSafe } = await import('./validation/backup-validator.js');
  return importBackupSafe(data);
}

export async function importBackupPartial(data) {
  const { importBackupSafe } = await import('./validation/backup-validator.js');
  return importBackupSafe(data, { partial: true });
}

/** Import legado direto — uso interno após validação. */
export async function importBackupCore(data) {
  if (!data || (data.version !== 1 && data.version !== 2 && data.version !== 3 && data.version !== 4 && data.version !== 5)) {
    throw new Error('Backup inválido ou versão incompatível.');
  }
  if (Array.isArray(data.songs)) {
    for (const song of data.songs) await saveSong(song);
  }
  if (Array.isArray(data.program)) await saveProgram(data.program);
  if (data.prefs) savePrefs(data.prefs);
  if (data.assets) {
    for (const [key, dataUrl] of Object.entries(data.assets)) {
      await saveAsset(key, dataUrl);
    }
  }
  if (Array.isArray(data.media)) {
    for (const m of data.media) await saveMedia(m);
  }
  if (data.cultos?.index && data.cultos?.programs) {
    const { saveCulto, saveCultoIndex } = await import('../program/culto-manager.js');
    for (const [id, items] of Object.entries(data.cultos.programs)) {
      const meta = data.cultos.index.cultos?.find((c) => c.id === id) || {};
      await saveCulto(id, items, meta);
    }
    await saveCultoIndex(data.cultos.index);
  }
  if (data.overlays) {
    await DiskAdapter.save('overlays.json', data.overlays);
  }
  if (data.templates) {
    await DiskAdapter.save('templates/index.json', data.templates);
  }
  if (data.worshipMeta) {
    await DiskAdapter.save('worship-meta.json', data.worshipMeta);
  }
}

export function generateId() {
  return randomId();
}

export async function fileToDataUrl(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}
