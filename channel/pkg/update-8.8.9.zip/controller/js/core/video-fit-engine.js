/** object-fit inteligente para mídia na projeção. */

export const VIDEO_FIT_MODES = ['contain', 'cover', 'fit', 'crop', 'center', 'stretch'];
export const ASPECT_POLICIES = ['contain', 'cover', 'fit', 'crop'];

const FILL_SLIDE_TYPES = new Set([
  'welcome', 'lyrics', 'lyrics-title', 'prayer', 'section', 'message',
  'bible', 'bible-responsive', 'bible-interlinear', 'bible-intro',
  'custom', 'theme', 'announcements', 'communion', 'offering', 'countdown',
  'participation', 'media', 'deck', 'pptx', 'visitor-welcome',
]);

function shouldFillFrame(slide) {
  const slideType = slide?.type || '';
  const bgType = slide?.background?.type || '';
  return FILL_SLIDE_TYPES.has(slideType)
    || bgType === 'video'
    || bgType === 'image'
    || !!slide?.isBackgroundLoop;
}

export function resolveAspectPolicy({ slide, prefs = {}, profile = null, display = null } = {}) {
  const cfg = prefs.displayEngine || {};
  const fromSlide = slide?.aspectPolicy || slide?.mediaAspect;
  if (fromSlide && ASPECT_POLICIES.includes(fromSlide)) return fromSlide;
  if (cfg.aspectPolicy && ASPECT_POLICIES.includes(cfg.aspectPolicy) && cfg.aspectPolicy !== 'contain') {
    return cfg.aspectPolicy;
  }
  if (profile?.aspectPolicy && ASPECT_POLICIES.includes(profile.aspectPolicy) && profile.aspectPolicy !== 'contain') {
    return profile.aspectPolicy;
  }
  if (shouldFillFrame(slide) || display?.aspectRatio === '4:3') return 'cover';
  return 'cover';
}

export function resolveVideoFit({ slide, prefs = {}, profile = null } = {}) {
  const fromSlide = slide?.videoFit || slide?.mediaFit;
  if (fromSlide === 'contain' || fromSlide === 'fit') {
    /* operador pediu letterbox só neste slide */
    if (fromSlide && VIDEO_FIT_MODES.includes(fromSlide) && !shouldFillFrame(slide)) return fromSlide;
  } else if (fromSlide && VIDEO_FIT_MODES.includes(fromSlide)) {
    return fromSlide;
  }
  if (shouldFillFrame(slide)) return 'cover';
  const cfg = prefs.displayEngine || {};
  if (cfg.videoFitDefault && VIDEO_FIT_MODES.includes(cfg.videoFitDefault) && cfg.videoFitDefault !== 'contain') {
    return cfg.videoFitDefault;
  }
  if (profile?.videoFit && VIDEO_FIT_MODES.includes(profile.videoFit) && profile.videoFit !== 'contain') {
    return profile.videoFit;
  }
  return 'cover';
}

export function applyVideoFitVars(target, mode) {
  if (!target) return;
  const fit = VIDEO_FIT_MODES.includes(mode) ? mode : 'cover';
  const cssFit = fit === 'stretch' ? 'fill' : fit === 'center' ? 'none' : fit === 'fit' ? 'contain' : fit === 'crop' ? 'cover' : fit;
  target.style.setProperty('--video-fit', cssFit);
  target.style.setProperty('--video-aspect-policy', fit);
  target.dataset.videoFit = fit;
}

export function applyVideoLegibilityLayer(target, prefs = {}) {
  if (!target) return;
  const cfg = prefs.displayEngine || {};
  // Com vídeo de fundo em loop, sombra no texto é melhor que lavagem preta em tela cheia
  const hasBgVideo = target.dataset?.hasBgVideo === '1'
    || document.documentElement?.dataset?.hasBgVideo === '1'
    || document.querySelector?.('.screen-viewport')?.dataset?.hasBgVideo === '1';
  // Preferência do operador só vale sem vídeo — com vídeo, forçar shadow (paridade com o espelho do Controle)
  const modeDefault = hasBgVideo ? 'shadow' : 'gradient';
  const modePref = cfg.videoLegibility;
  const mode = hasBgVideo
    ? (modePref === 'outline' || modePref === 'plate' || modePref === 'shadow' ? modePref : 'shadow')
    : (modePref || modeDefault);
  const allowed = ['gradient', 'dark', 'shadow', 'outline', 'plate'];
  const resolved = allowed.includes(mode) ? mode : modeDefault;
  target.dataset.videoLegibility = resolved;
  target.style.setProperty('--video-legibility-mode', resolved);
  const strength = Number(cfg.videoLegibilityStrength);
  const fallback = hasBgVideo ? 0.12 : 0.45;
  target.style.setProperty('--video-legibility-strength', String(
    Number.isFinite(strength) ? Math.max(0, Math.min(1, strength)) : fallback,
  ));
}

export function applyVideoFitToElements(root, mode) {
  if (!root) return;
  const fit = VIDEO_FIT_MODES.includes(mode) ? mode : 'cover';
  const cssFit = fit === 'stretch' ? 'fill' : fit === 'center' ? 'none' : fit === 'fit' ? 'contain' : fit === 'crop' ? 'cover' : fit;
  root.querySelectorAll(
    [
      'video.lyrics-bg-video',
      'video.slide-bg-video',
      'video.welcome-bg-video',
      '#lyrics-bg-persist video',
      '.lyrics-bg-persist video',
      '.slide-bg video',
      '.slide-media video',
      '.slide-media img',
      '.slide-bg-media',
      '.slide-bg-image',
      '.media-video',
      '.media-image',
      '.slide-deck img',
      '.slide-deck video',
    ].join(', '),
  ).forEach((el) => {
    el.style.objectFit = cssFit;
    if (fit === 'crop' || cssFit === 'cover') el.style.objectPosition = el.style.objectPosition || 'center';
  });
}
