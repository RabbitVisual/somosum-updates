/**
 * Display Authority — fachada JS (Projetor.md Display & Presentation Core 1.0).
 * Discovery + identity + capabilities + resolução inteligente + color policy.
 */
import { matchProjectorProfile, PROJECTOR_PROFILES } from './projector-profiles.js';
import { findKnownDisplayByHash, upsertKnownDisplayProfile } from './known-displays.js';

export const COLOR_POLICIES = {
  standard: {
    id: 'standard',
    label: 'Padrão',
    saturation: 1,
    contrast: 1,
    warmth: 0,
    brightness: 1,
  },
  warm: {
    id: 'warm',
    label: 'Quente (legado)',
    saturation: 1.05,
    contrast: 1.04,
    warmth: 0.08,
    brightness: 1.02,
  },
  vivid: {
    id: 'vivid',
    label: 'Vívido',
    saturation: 1.12,
    contrast: 1.06,
    warmth: 0.02,
    brightness: 1.04,
  },
  high_contrast: {
    id: 'high_contrast',
    label: 'Alto contraste',
    saturation: 0.95,
    contrast: 1.18,
    warmth: 0,
    brightness: 1.06,
  },
};

/**
 * Hierarquia Projetor.md §5:
 * 1. Perfil salvo válido
 * 2. Recommended / nativo
 * 3. Melhor modo ≤ nativo
 * 4. Modo atual DEVMODE
 * 5. Fallback
 */
export function resolveProjectionMode(display, savedProfile = null) {
  const rec = display?.recommendedMode || {};
  const cur = display?.currentMode || {};
  const max = display?.maxMode || {};
  const saved = savedProfile?.nativeMode || savedProfile?.lastMode || null;

  const candidates = [];
  if (saved?.w > 0 && saved?.h > 0) {
    candidates.push({
      w: saved.w, h: saved.h, hz: saved.hz || 60, source: 'saved',
    });
  }
  if (rec.w > 0 && rec.h > 0) {
    candidates.push({
      w: rec.w, h: rec.h, hz: rec.hz || 60, source: 'recommended',
    });
  }
  if (max.w > 0 && max.h > 0) {
    // Nunca preferir max se for muito maior que recommended (ex. 1080 em nativo 800)
    const nativeCap = rec.w > 0 ? rec.w : (saved?.w || max.w);
    if (max.w <= nativeCap * 1.05) {
      candidates.push({
        w: max.w, h: max.h, hz: max.hz || 60, source: 'max',
      });
    } else if (rec.w > 0) {
      candidates.push({
        w: rec.w, h: rec.h, hz: rec.hz || 60, source: 'native-cap',
      });
    }
  }
  if (cur.w > 0 && cur.h > 0) {
    candidates.push({
      w: cur.w, h: cur.h, hz: cur.hz || 60, source: 'current',
    });
  }

  const pick = candidates[0] || {
    w: display?.width || 1280,
    h: display?.height || 720,
    hz: 60,
    source: 'fallback',
  };

  // Cap: se recommended é SVGA, não devolver 1080
  if (rec.w > 0 && pick.w > rec.w * 1.1 && rec.w <= 1280) {
    return {
      w: rec.w,
      h: rec.h || Math.round(rec.w * 0.75),
      hz: rec.hz || pick.hz,
      source: 'native-guard',
    };
  }
  return pick;
}

export function enrichDisplayIdentity(display) {
  if (!display) return display;
  const manufacturer = display.manufacturer
    || String(display.friendlyName || '').split(/\s+/)[0]
    || '';
  const model = display.model || '';
  const hash = display.displayHash || `idx:${display.index ?? 0}`;
  const displayId = display.displayId
    || `DISPLAY-${(manufacturer || 'UNK').toUpperCase()}-${(model || 'DISP').toUpperCase().replace(/\s+/g, '-')}-${hash}`;
  const profile = matchProjectorProfile({
    ...display,
    // Perfil usa capacidade nativa real — recommendedMode separado
    maxMode: display.maxMode || display.recommendedMode || display.currentMode,
  });
  return {
    ...display,
    manufacturer,
    model,
    displayId,
    isProjector: display.isProjector ?? guessIsProjector(display),
    matchedProfileId: profile?.id || 'fhd',
  };
}

function guessIsProjector(d) {
  const name = `${d.friendlyName || ''} ${d.deviceName || ''} ${d.deviceId || ''} ${d.manufacturer || ''} ${d.model || ''}`.toLowerCase();
  if (/epson|powerlite|benq|optoma|projector|projetor|infocus|christie|barco|vivitek|svga|s18|eb-x|eb-s/.test(name)) {
    return true;
  }
  if (/viewsonic/.test(name) && /pj|pjd/.test(name)) return true;
  const w = d.maxMode?.w || d.recommendedMode?.w || d.width || 0;
  const aspect = d.aspectRatio || '';
  if (!d.primary && aspect === '4:3' && w > 0 && w <= 1600) return true;
  if (!d.primary && aspect === '4:3' && w > 0 && w <= 1024) return true;
  return false;
}

export function suggestColorPolicy(display, profile = null) {
  if (display?.hdrCapable === true || display?.colorProfile === 'HDR') return 'vivid';
  const name = `${display?.friendlyName || ''} ${display?.manufacturer || ''} ${display?.model || ''}`.toLowerCase();
  const w = display?.recommendedMode?.w || display?.recommendedW || profile?.maxMode?.w || 0;
  const aspect = display?.aspectRatio || profile?.aspectRatio || '';
  if (w > 0 && w <= 800) return 'high_contrast';
  if (aspect === '4:3' && w > 0 && w <= 1280) return 'high_contrast';
  if (/projector|projetor|epson|benq|optoma|viewsonic|powerlite|svga|xga/.test(name)) return 'warm';
  if (/led|tv|samsung|lg philips/.test(name) && !display?.hdrCapable) return 'vivid';
  return 'standard';
}

export function applyColorPolicyVars(target, policyId) {
  if (!target) return;
  const policy = COLOR_POLICIES[policyId] || COLOR_POLICIES.standard;
  target.style.setProperty('--proj-saturation', String(policy.saturation));
  target.style.setProperty('--proj-contrast', String(policy.contrast));
  target.style.setProperty('--proj-warmth', String(policy.warmth));
  target.style.setProperty('--proj-brightness', String(policy.brightness));
  target.dataset.colorPolicy = policy.id;
  const filter = [
    `saturate(${policy.saturation})`,
    `contrast(${policy.contrast})`,
    `brightness(${policy.brightness})`,
    policy.warmth
      ? `sepia(${Math.min(0.35, policy.warmth * 2)})`
      : null,
  ].filter(Boolean).join(' ');
  target.style.setProperty('--proj-color-filter', filter);
}

export function buildKnownProfileFromDisplay(display, prefs = {}) {
  const enriched = enrichDisplayIdentity(display);
  const mode = resolveProjectionMode(enriched, findKnownDisplayByHash(enriched.displayHash));
  const matched = matchProjectorProfile({
    ...enriched,
    maxMode: { w: mode.w, h: mode.h },
    recommendedMode: enriched.recommendedMode,
  });
  const de = prefs.displayEngine || {};
  const known = findKnownDisplayByHash(enriched.displayHash);
  const suggestedColor = known?.projection?.colorPolicy || suggestColorPolicy(enriched, matched);
  return {
    displayId: enriched.displayId,
    displayHash: enriched.displayHash,
    deviceName: enriched.deviceName || '',
    identity: {
      manufacturer: enriched.manufacturer || '',
      model: enriched.model || '',
      friendlyName: enriched.friendlyName || '',
    },
    nativeMode: {
      w: enriched.recommendedMode?.w || mode.w,
      h: enriched.recommendedMode?.h || mode.h,
      hz: enriched.recommendedMode?.hz || mode.hz || 60,
    },
    lastMode: { w: mode.w, h: mode.h, hz: mode.hz || 60 },
    projection: {
      fullscreen: true,
      role: enriched.role || 'projection',
      safeArea: matched.safeArea || { top: 2, right: 2, bottom: 2, left: 2 },
      projectorProfileId: de.projectorProfile || matched.id,
      colorPolicy: de.colorPolicy || suggestedColor,
    },
    rendering: { vsync: true },
    index: enriched.index ?? 0,
  };
}

export function restoreOrCreateDisplayProfile(display, prefs = {}) {
  const enriched = enrichDisplayIdentity(display);
  const existing = findKnownDisplayByHash(enriched.displayHash);
  if (existing?.displayId) {
    const mode = resolveProjectionMode(enriched, existing);
    const updated = {
      ...existing,
      lastMode: { w: mode.w, h: mode.h, hz: mode.hz || 60 },
      index: enriched.index ?? existing.index,
      identity: {
        ...(existing.identity || {}),
        manufacturer: enriched.manufacturer || existing.identity?.manufacturer || '',
        model: enriched.model || existing.identity?.model || '',
        friendlyName: enriched.friendlyName || existing.identity?.friendlyName || '',
      },
    };
    upsertKnownDisplayProfile(updated);
    return updated;
  }
  const created = buildKnownProfileFromDisplay(enriched, prefs);
  upsertKnownDisplayProfile(created);
  return created;
}

export { PROJECTOR_PROFILES, matchProjectorProfile };
