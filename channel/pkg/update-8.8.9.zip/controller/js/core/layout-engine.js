/** Vars de layout por tipo de slide e viewport. */

const SLIDE_DEFAULTS = {
  lyrics: { maxWidth: 92, titleSize: 8, gap: 2.2 },
  bible: { maxWidth: 88, titleSize: 6, gap: 2 },
  welcome: { maxWidth: 85, titleSize: 10, gap: 2.5 },
  message: { maxWidth: 90, titleSize: 7, gap: 2 },
  default: { maxWidth: 90, titleSize: 7, gap: 2 },
};

function aspectKey(aspect) {
  if (!aspect) return '16x9';
  return String(aspect).replace(':', 'x').replace('/', 'x');
}

export function computeLayoutVars(snapshot, slideType = 'default') {
  const display = snapshot?.projectionDisplay || snapshot?.displays?.[0] || {};
  const vw = display.currentMode?.w || display.bounds?.w || display.width || 1920;
  const vh = display.currentMode?.h || display.bounds?.h || display.height || 1080;
  const aspect = aspectKey(display.aspectRatio || (vw / vh < 1.4 ? '4x3' : '16x9'));
  const base = SLIDE_DEFAULTS[slideType] || SLIDE_DEFAULTS.default;
  const is43 = aspect === '4x3' || vw / vh < 1.4;
  const isUltra = aspect === '21x9' || aspect === '32x9' || aspect === 'ultrawide' || vw / vh > 2.1;

  const maxWidth = isUltra ? Math.min(base.maxWidth + 4, 98) : is43 ? Math.min(base.maxWidth + 4, 96) : Math.min(base.maxWidth + 4, 96);
  const titleSize = is43 ? base.titleSize * 1.08 : base.titleSize;
  const gap = is43 ? base.gap * 1.05 : base.gap;

  return {
    '--layout-lyrics-max-width': `${maxWidth}%`,
    '--layout-title-size': `${titleSize}cqw`,
    '--layout-region-gap': `${gap}cqh`,
    '--layout-viewport-w': `${vw}`,
    '--layout-viewport-h': `${vh}`,
    '--layout-aspect': aspect,
  };
}

export function applyLayoutVars(target, vars) {
  if (!target || !vars) return;
  Object.entries(vars).forEach(([k, v]) => target.style.setProperty(k, v));
}
