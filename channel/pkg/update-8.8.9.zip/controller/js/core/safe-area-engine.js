/** Margens safe area — global, por dispositivo e overscan estimado. */

export const SAFE_AREA_PRESETS = {
  FULL: { top: 0, right: 0, bottom: 0, left: 0 },
  TEXT: { top: 2, right: 2, bottom: 2, left: 2 },
  SAFE: { top: 2, right: 2, bottom: 2, left: 2 },
  PROJECTOR: { top: 2.5, right: 2.5, bottom: 2.5, left: 2.5 },
  PROJECTOR_OLD: { top: 2.5, right: 2.5, bottom: 2.5, left: 2.5 },
  TV: { top: 2, right: 2, bottom: 2, left: 2 },
  CUSTOM: null,
  default: { top: 2, right: 2, bottom: 2, left: 2 },
  projector_old: { top: 2.5, right: 2.5, bottom: 2.5, left: 2.5 },
  tv: { top: 2, right: 2, bottom: 2, left: 2 },
};

function pct(v) {
  const n = Number(v);
  if (!Number.isFinite(n)) return 0;
  return Math.max(0, Math.min(12, n));
}

/** WorkArea gap = overscan automático somente no monitor primário (taskbar). */
export function estimateOverscan(display) {
  if (!display?.primary) return null;
  if (!display?.bounds || !display?.workingArea) return null;
  const b = display.bounds;
  const w = display.workingArea;
  if (!b.w || !b.h) return null;
  const top = Math.max(0, (w.y - b.y) / b.h * 100);
  const left = Math.max(0, (w.x - b.x) / b.w * 100);
  const bottom = Math.max(0, ((b.y + b.h) - (w.y + w.h)) / b.h * 100);
  const right = Math.max(0, ((b.x + b.w) - (w.x + w.w)) / b.w * 100);
  const sum = top + left + bottom + right;
  if (sum < 0.5) return null;
  return {
    top: Math.round(top * 10) / 10,
    right: Math.round(right * 10) / 10,
    bottom: Math.round(bottom * 10) / 10,
    left: Math.round(left * 10) / 10,
  };
}

function resolvePresetKey(display, prefs = {}, profile = null) {
  const cfg = prefs.displayEngine || {};
  if (cfg.safeAreaPreset && SAFE_AREA_PRESETS[cfg.safeAreaPreset]) {
    return cfg.safeAreaPreset;
  }
  const mode = display?.currentMode || display?.recommendedMode || {};
  const w = mode.w || display?.width || 0;
  const h = mode.h || display?.height || 0;
  const aspect = display?.aspectRatio || '';
  const isOldProjector = display?.isProjector
    && !display?.primary
    && ((w > 0 && w <= 1024 && h > 0 && h <= 768) || aspect === '4:3');
  if (isOldProjector) return 'PROJECTOR';
  if (display?.isProjector && !display?.primary) return 'TEXT';
  if (profile?.safeAreaPreset && SAFE_AREA_PRESETS[profile.safeAreaPreset]) {
    return profile.safeAreaPreset;
  }
  return 'TEXT';
}

export function resolveSafeArea(display, prefs = {}, profile = null) {
  const cfg = prefs.displayEngine || {};
  const presetKey = resolvePresetKey(display, prefs, profile);
  const preset = SAFE_AREA_PRESETS[presetKey] || SAFE_AREA_PRESETS.TEXT;
  const global = { ...SAFE_AREA_PRESETS.TEXT, ...(cfg.safeAreaGlobal || {}) };
  const byDevice = display?.deviceName ? cfg.safeAreaByDevice?.[display.deviceName] : null;
  const overscan = estimateOverscan(display);
  const profileArea = profile?.safeArea || null;
  const userGlobal = cfg.safeAreaGlobal || {};
  const hasUserOverride = Object.keys(userGlobal).some((k) => userGlobal[k] != null);

  const merged = {
    top: pct(hasUserOverride ? (userGlobal.top ?? global.top) : (profileArea?.top ?? byDevice?.top ?? preset?.top ?? global.top)),
    right: pct(hasUserOverride ? (userGlobal.right ?? global.right) : (profileArea?.right ?? byDevice?.right ?? preset?.right ?? global.right)),
    bottom: pct(hasUserOverride ? (userGlobal.bottom ?? global.bottom) : (profileArea?.bottom ?? byDevice?.bottom ?? preset?.bottom ?? global.bottom)),
    left: pct(hasUserOverride ? (userGlobal.left ?? global.left) : (profileArea?.left ?? byDevice?.left ?? preset?.left ?? global.left)),
  };

  if (overscan) {
    merged.top = Math.max(merged.top, Math.ceil(overscan.top));
    merged.right = Math.max(merged.right, Math.ceil(overscan.right));
    merged.bottom = Math.max(merged.bottom, Math.ceil(overscan.bottom));
    merged.left = Math.max(merged.left, Math.ceil(overscan.left));
  }

  merged.preset = presetKey;
  return merged;
}

export function applySafeAreaVars(target, safeArea) {
  if (!target || !safeArea) return;
  const x = Math.max(safeArea.left, safeArea.right);
  const y = Math.max(safeArea.top, safeArea.bottom);
  target.style.setProperty('--safe-x', `${x}%`);
  target.style.setProperty('--safe-y', `${y}%`);
  target.style.setProperty('--safe-left', `${safeArea.left}%`);
  target.style.setProperty('--safe-right', `${safeArea.right}%`);
  target.style.setProperty('--safe-top', `${safeArea.top}%`);
  target.style.setProperty('--safe-bottom', `${safeArea.bottom}%`);
  if (safeArea.preset) target.dataset.safeAreaPreset = safeArea.preset;
}
