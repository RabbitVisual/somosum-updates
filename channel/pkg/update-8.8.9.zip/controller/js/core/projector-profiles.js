/**
 * Perfis de projetor / TV / LED — match inteligente por resolução nativa.
 * Marcas (Epson, BenQ, Optoma…) só sugerem “é projetor”; o modo nativo decide o perfil.
 * Nunca force SVGA só porque o nome contém Epson (ex.: EB-X06 = XGA).
 */

export const PROJECTOR_PROFILES = {
  /** 800×600 — PowerLite S18+, Optoma/BenQ SVGA, etc. */
  svga: {
    id: 'svga',
    label: 'SVGA 800×600',
    aspectRatio: '4:3',
    maxMode: { w: 800, h: 600 },
    safeArea: { top: 2.5, right: 2.5, bottom: 2.5, left: 2.5 },
    fontBoost: 1.3,
    videoFit: 'cover',
    typographyMin: 28,
    typographyMax: 72,
    maxLegibility: true,
  },
  /** 1024×768 — Epson EB-X, BenQ MX, Optoma XGA */
  xga: {
    id: 'xga',
    label: 'XGA 1024×768',
    aspectRatio: '4:3',
    maxMode: { w: 1024, h: 768 },
    safeArea: { top: 2.5, right: 2.5, bottom: 2.5, left: 2.5 },
    fontBoost: 1.18,
    videoFit: 'cover',
    typographyMin: 32,
    typographyMax: 96,
    maxLegibility: true,
  },
  /** 4:3 genérico (não SVGA/XGA) */
  projector_4x3: {
    id: 'projector_4x3',
    label: 'Projetor 4:3',
    aspectRatio: '4:3',
    safeArea: { top: 2.5, right: 2.5, bottom: 2.5, left: 2.5 },
    fontBoost: 1.22,
    videoFit: 'cover',
    typographyMin: 36,
    typographyMax: 120,
    maxLegibility: true,
  },
  /** 1280×720 */
  hd720: {
    id: 'hd720',
    label: 'HD 720p',
    aspectRatio: '16:9',
    maxMode: { w: 1280, h: 720 },
    safeArea: { top: 2, right: 2, bottom: 2, left: 2 },
    fontBoost: 1.14,
    videoFit: 'cover',
    typographyMin: 34,
    typographyMax: 100,
  },
  /** 1280×800 */
  wxga: {
    id: 'wxga',
    label: 'WXGA 1280×800',
    aspectRatio: '16:10',
    maxMode: { w: 1280, h: 800 },
    safeArea: { top: 2, right: 2, bottom: 2, left: 2 },
    fontBoost: 1.12,
    videoFit: 'cover',
    typographyMin: 36,
    typographyMax: 104,
  },
  /** 1366×768 notebooks / TVs */
  wxga_plus: {
    id: 'wxga_plus',
    label: 'WXGA+ 1366×768',
    aspectRatio: '16:9',
    maxMode: { w: 1366, h: 768 },
    safeArea: { top: 2, right: 2, bottom: 2, left: 2 },
    fontBoost: 1.12,
    videoFit: 'cover',
    typographyMin: 36,
    typographyMax: 104,
  },
  /** 1400×1050 */
  sxga_plus: {
    id: 'sxga_plus',
    label: 'SXGA+ 1400×1050',
    aspectRatio: '4:3',
    maxMode: { w: 1400, h: 1050 },
    safeArea: { top: 2.5, right: 2.5, bottom: 2.5, left: 2.5 },
    fontBoost: 1.12,
    videoFit: 'cover',
    typographyMin: 34,
    typographyMax: 100,
  },
  /** 1600×1200 */
  uxga: {
    id: 'uxga',
    label: 'UXGA 1600×1200',
    aspectRatio: '4:3',
    maxMode: { w: 1600, h: 1200 },
    safeArea: { top: 2, right: 2, bottom: 2, left: 2 },
    fontBoost: 1.1,
    videoFit: 'cover',
    typographyMin: 36,
    typographyMax: 110,
  },
  /** 1920×1080 projetor/TV */
  fhd: {
    id: 'fhd',
    label: 'Full HD 1080p',
    aspectRatio: '16:9',
    maxMode: { w: 1920, h: 1080 },
    safeArea: { top: 2, right: 2, bottom: 2, left: 2 },
    fontBoost: 1.1,
    videoFit: 'cover',
    typographyMin: 40,
    typographyMax: 120,
  },
  /** 1920×1200 */
  wuxga: {
    id: 'wuxga',
    label: 'WUXGA 1920×1200',
    aspectRatio: '16:10',
    maxMode: { w: 1920, h: 1200 },
    safeArea: { top: 2, right: 2, bottom: 2, left: 2 },
    fontBoost: 1.1,
    videoFit: 'cover',
    typographyMin: 40,
    typographyMax: 120,
  },
  /** 2560×1440 */
  qhd: {
    id: 'qhd',
    label: 'QHD 1440p',
    aspectRatio: '16:9',
    maxMode: { w: 2560, h: 1440 },
    safeArea: { top: 3, right: 3, bottom: 3, left: 3 },
    fontBoost: 1.06,
    videoFit: 'cover',
    typographyMin: 44,
    typographyMax: 140,
  },
  /** 3840×2160 */
  '4k': {
    id: '4k',
    label: '4K UHD',
    aspectRatio: '16:9',
    maxMode: { w: 3840, h: 2160 },
    safeArea: { top: 3, right: 3, bottom: 3, left: 3 },
    fontBoost: 1.05,
    videoFit: 'cover',
    typographyMin: 48,
    typographyMax: 160,
  },
  tv_fhd: {
    id: 'tv_fhd',
    label: 'TV Full HD',
    aspectRatio: '16:9',
    safeArea: { top: 2, right: 2, bottom: 2, left: 2 },
    fontBoost: 1.08,
    videoFit: 'cover',
    typographyMin: 40,
    typographyMax: 120,
  },
  tv_4k: {
    id: 'tv_4k',
    label: 'TV 4K',
    aspectRatio: '16:9',
    safeArea: { top: 2, right: 2, bottom: 2, left: 2 },
    fontBoost: 1.05,
    videoFit: 'cover',
    typographyMin: 48,
    typographyMax: 160,
  },
  ultrawide: {
    id: 'ultrawide',
    label: 'Ultrawide 21:9',
    aspectRatio: '21:9',
    safeArea: { top: 2, right: 3, bottom: 2, left: 3 },
    fontBoost: 1.08,
    videoFit: 'cover',
    typographyMin: 36,
    typographyMax: 110,
  },
  led_panel: {
    id: 'led_panel',
    label: 'Painel LED',
    aspectRatio: '16:9',
    safeArea: { top: 1, right: 1, bottom: 1, left: 1 },
    fontBoost: 1.0,
    videoFit: 'cover',
    typographyMin: 40,
    typographyMax: 140,
  },
  /** Fallback seguro culto */
  auto_safe: {
    id: 'auto_safe',
    label: 'Automático (seguro)',
    aspectRatio: '16:9',
    safeArea: { top: 2.5, right: 2.5, bottom: 2.5, left: 2.5 },
    fontBoost: 1.15,
    videoFit: 'cover',
    typographyMin: 36,
    typographyMax: 110,
    maxLegibility: true,
  },
};

/** Marcas/modelos típicos de projetor — não definem resolução sozinhas. */
const PROJECTOR_BRAND_RE = /epson|powerlite|power\s*lite|benq|optoma|viewsonic|acer|sony|panasonic|nec|casio|infocus|christie|barco|vivitek|ricoh|canon|lg\s*probeam|hitachi|mitsubishi|sharp|dell\s*projector|projetor|projector|s18|eb-x|eb-s|eh-tw|wuxga|xga|svga/i;

const TV_RE = /\btv\b|television|smart\s*tv|roku|fire\s*tv|android\s*tv|bravia|oled|qled/i;
const LED_RE = /\bled\b|painel|ledwall|led\s*wall|videowall|video\s*wall/i;

function modeSize(display) {
  const w = Number(
    display?.recommendedMode?.w
    || display?.nativeMode?.w
    || display?.maxMode?.w
    || display?.currentMode?.w
    || display?.width
    || 0,
  );
  const h = Number(
    display?.recommendedMode?.h
    || display?.nativeMode?.h
    || display?.maxMode?.h
    || display?.currentMode?.h
    || display?.height
    || 0,
  );
  return { w, h };
}

function near(a, b, tol = 40) {
  return Math.abs(a - b) <= tol;
}

function displayName(display) {
  return `${display?.friendlyName || ''} ${display?.deviceName || ''} ${display?.manufacturer || ''} ${display?.model || ''}`.toLowerCase();
}

/**
 * Match automático: 1) LED/TV por nome 2) resolução nativa 3) aspecto 4) fallback seguro.
 * Epson FHD → fhd; Epson S18 / 800×600 → svga; nunca “tudo Epson = SVGA”.
 */
export function matchProjectorProfile(display) {
  if (!display) return PROJECTOR_PROFILES.fhd;

  const name = displayName(display);
  const aspect = display.aspectRatio || '16:9';
  const { w: maxW, h: maxH } = modeSize(display);
  const isTv = TV_RE.test(name);
  const isLed = LED_RE.test(name);
  const isProj = !!(display.isProjector || PROJECTOR_BRAND_RE.test(name));

  if (isLed) return PROJECTOR_PROFILES.led_panel;

  if (aspect === '21:9' || aspect === '32:9' || aspect === 'ultrawide') {
    return PROJECTOR_PROFILES.ultrawide;
  }

  // Por resolução nativa (prioridade absoluta)
  if (maxW > 0 && maxH > 0) {
    if (maxW >= 3800 || (near(maxW, 3840) && near(maxH, 2160))) {
      return isTv ? PROJECTOR_PROFILES.tv_4k : PROJECTOR_PROFILES['4k'];
    }
    if (near(maxW, 2560) && near(maxH, 1440)) return PROJECTOR_PROFILES.qhd;
    if (near(maxW, 1920) && near(maxH, 1200)) return PROJECTOR_PROFILES.wuxga;
    if (near(maxW, 1920) && near(maxH, 1080)) {
      return isTv ? PROJECTOR_PROFILES.tv_fhd : PROJECTOR_PROFILES.fhd;
    }
    if (near(maxW, 1600) && near(maxH, 1200)) return PROJECTOR_PROFILES.uxga;
    if (near(maxW, 1400) && near(maxH, 1050)) return PROJECTOR_PROFILES.sxga_plus;
    if (near(maxW, 1366, 20) && near(maxH, 768, 20)) return PROJECTOR_PROFILES.wxga_plus;
    if (near(maxW, 1280) && near(maxH, 800)) return PROJECTOR_PROFILES.wxga;
    if (near(maxW, 1280) && near(maxH, 720)) return PROJECTOR_PROFILES.hd720;
    if (near(maxW, 1024) && near(maxH, 768)) return PROJECTOR_PROFILES.xga;
    if (maxW <= 850 && maxH <= 650) return PROJECTOR_PROFILES.svga;
    if (near(maxW, 800) && near(maxH, 600)) return PROJECTOR_PROFILES.svga;

    // Faixas
    if (maxW <= 850) return PROJECTOR_PROFILES.svga;
    if (maxW <= 1024 && maxH <= 768) return PROJECTOR_PROFILES.xga;
    if (maxW <= 1280 && maxH <= 720) return PROJECTOR_PROFILES.hd720;
    if (maxW <= 1280 && maxH <= 800) return PROJECTOR_PROFILES.wxga;
    if (maxW <= 1400) return aspect === '4:3' ? PROJECTOR_PROFILES.sxga_plus : PROJECTOR_PROFILES.wxga_plus;
    if (maxW <= 1600 && aspect === '4:3') return PROJECTOR_PROFILES.uxga;
    if (maxW < 1920) return aspect === '16:10' ? PROJECTOR_PROFILES.wxga : PROJECTOR_PROFILES.hd720;
    if (maxW < 2560) return maxH >= 1200 ? PROJECTOR_PROFILES.wuxga : PROJECTOR_PROFILES.fhd;
    if (maxW < 3840) return PROJECTOR_PROFILES.qhd;
  }

  if (aspect === '4:3') {
    if (isProj) return PROJECTOR_PROFILES.projector_4x3;
    return PROJECTOR_PROFILES.projector_4x3;
  }

  if (isTv) return PROJECTOR_PROFILES.tv_fhd;
  if (isProj) return PROJECTOR_PROFILES.auto_safe;
  return PROJECTOR_PROFILES.fhd;
}

export function listProfileOptions() {
  // Ordem amigável no seletor de Ajustes
  const order = [
    'svga', 'xga', 'projector_4x3', 'hd720', 'wxga', 'wxga_plus', 'sxga_plus', 'uxga',
    'fhd', 'wuxga', 'qhd', '4k', 'tv_fhd', 'tv_4k', 'ultrawide', 'led_panel', 'auto_safe',
  ];
  return order
    .filter((id) => PROJECTOR_PROFILES[id])
    .map((id) => ({ id, label: PROJECTOR_PROFILES[id].label }));
}

export function isKnownProjectorBrand(display) {
  return PROJECTOR_BRAND_RE.test(displayName(display));
}
