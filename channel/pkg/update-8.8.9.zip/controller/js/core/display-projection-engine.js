/**
 * Display & Projection Engine — snapshot nativo, canvas dinâmico, CSS vars unificadas.
 */
import { parseDisplaysJson, getCachedDisplaySnapshot, applyPushedDisplaySnapshot, listDisplaysFast } from './display-manager.js';
import { resolveSafeArea, applySafeAreaVars } from './safe-area-engine.js';
import { computeLayoutVars, applyLayoutVars } from './layout-engine.js';
import { computeTypography, applyTypographyVars } from './typography-engine.js';
import { resolveVideoFit, applyVideoFitVars, applyVideoFitToElements, resolveAspectPolicy, applyVideoLegibilityLayer } from './video-fit-engine.js';
import { matchProjectorProfile, PROJECTOR_PROFILES } from './projector-profiles.js';
import { mergeKnownDisplays } from './known-displays.js';
import {
  captureProjectionViewport,
  compareViewportMismatch,
  applyProjectionViewportDataset,
} from './projection-viewport.js';
import { resolveOutputPreset, applyOutputPresetVars } from './projection-output-presets.js';
import {
  logViewportMismatch,
  logColorPolicy,
  logVideoLayout,
  logHotplug,
} from './projection-telemetry.js';
import {
  applyColorPolicyVars,
  enrichDisplayIdentity,
  restoreOrCreateDisplayProfile,
  resolveProjectionMode,
  suggestColorPolicy,
} from './display-authority.js';

function evenPx(n) {
  const v = Math.max(2, Math.round(Number(n) || 0));
  return v % 2 === 0 ? v : v - 1;
}

/** Escolhe o display do output (1=projection, 2=projection2). Nunca misturar identidades. */
export function pickProjectionDisplay(displays, outputIndex = 1) {
  if (!Array.isArray(displays) || !displays.length) return null;
  const idx = Number(outputIndex) > 1 ? Math.floor(Number(outputIndex)) : 1;
  if (idx > 1) {
    return displays.find((d) => d.role === 'projection2')
      || displays.find((d) => !d.primary && d.role !== 'projection')
      || displays.find((d) => !d.primary)
      || displays[Math.min(idx, displays.length - 1)]
      || displays[0];
  }
  return displays.find((d) => d.role === 'projection')
    || displays.find((d) => !d.primary)
    || displays[0];
}

/** Tamanho de design em px lógicos — nunca DEVMODE físico (quebra DPI). */
function logicalDesignSize(viewport, display) {
  const vw = viewport?.clientWidth
    || display?.bounds?.w
    || display?.workingArea?.w
    || 1920;
  const vh = viewport?.clientHeight
    || display?.bounds?.h
    || display?.workingArea?.h
    || 1080;
  return { vw: Number(vw) || 1920, vh: Number(vh) || 1080 };
}

function requestNativeProjectionRecover() {
  try {
    window.chrome?.webview?.postMessage?.({ type: 'recover-projection-layout', force: true });
  } catch { /* browser */ }
  try {
    const native = window.chrome?.webview?.hostObjects?.sync?.somosumNative
      || window.somosumNative;
    native?.recoverProjectionLayout?.(true);
  } catch { /* optional */ }
}

function aspectCssKey(ratio) {
  if (!ratio) return '16x9';
  return String(ratio).replace(':', 'x').replace('/', 'x');
}

function browserFallbackSnapshot() {
  const w = window.innerWidth || screen.width || 1920;
  const h = window.innerHeight || screen.height || 1080;
  const dpr = window.devicePixelRatio || 1;
  return {
    timestamp: Date.now(),
    displays: [{
      index: 0,
      deviceName: 'browser',
      friendlyName: 'Browser',
      primary: true,
      bounds: { x: 0, y: 0, w, h },
      workingArea: { x: 0, y: 0, w, h },
      dpiScale: dpr,
      refreshHz: 60,
      orientation: w >= h ? 'landscape' : 'portrait',
      currentMode: { w, h },
      recommendedMode: { w, h },
      maxMode: { w, h },
      aspectRatio: w / h < 1.4 ? '4:3' : '16:9',
      connectionHint: 'unknown',
      hdrCapable: false,
      colorProfile: 'UNKNOWN',
      role: 'projection',
      width: w,
      height: h,
    }],
  };
}

function normalizeLegacyDisplay(d, i) {
  const base = {
    index: d.index ?? i,
    deviceName: d.deviceName || `display-${i}`,
    friendlyName: d.friendlyName || `Monitor ${i + 1}`,
    manufacturer: d.manufacturer || '',
    model: d.model || '',
    displayId: d.displayId || '',
    displayHash: d.displayHash || '',
    isProjector: !!d.isProjector,
    primary: !!d.primary,
    bounds: d.bounds || { x: d.x || 0, y: d.y || 0, w: d.width || 1920, h: d.height || 1080 },
    workingArea: d.workingArea || d.bounds || { x: d.x || 0, y: d.y || 0, w: d.width || 1920, h: d.height || 1080 },
    dpiScale: d.dpiScale || 1,
    refreshHz: d.refreshHz || d.currentMode?.hz || 60,
    orientation: d.orientation || 'landscape',
    currentMode: d.currentMode || { w: d.width || 1920, h: d.height || 1080 },
    recommendedMode: d.recommendedMode || d.currentMode,
    maxMode: d.maxMode || d.currentMode,
    aspectRatio: d.aspectRatio || '16:9',
    connectionHint: d.connectionHint || 'unknown',
    hdrCapable: d.hdrCapable === true ? true : d.hdrCapable === false ? false : null,
    colorProfile: d.colorProfile || (d.hdrCapable === true ? 'HDR' : d.hdrCapable === false ? 'SDR' : 'UNKNOWN'),
    role: d.role || 'unknown',
    width: d.width || d.currentMode?.w || d.bounds?.w,
    height: d.height || d.currentMode?.h || d.bounds?.h,
    knownProfile: d.knownProfile || null,
  };
  return enrichDisplayIdentity(base);
}

export class DisplayProjectionEngine {
  static _instance = null;

  static getInstance() {
    return DisplayProjectionEngine._instance;
  }

  static attach(viewportEl, canvasEl, options = {}) {
    const engine = new DisplayProjectionEngine();
    engine.init({ viewportEl, canvasEl, ...options });
    DisplayProjectionEngine._instance = engine;
    return engine;
  }

  constructor() {
    this.viewportEl = null;
    this.canvasEl = null;
    this.surface = 'screen';
    this.prefs = {};
    this.snapshot = null;
    this.projectionDisplay = null;
    this.profile = PROJECTOR_PROFILES.fhd;
    this._slideContext = { type: 'default', lineCount: 3, maxChars: 42 };
    this._disposeFns = [];
    this._nativeListener = null;
    this._recalcPending = false;
    this._recalcRunning = false;
    this._lastSnapshotKey = '';
    this._lastLayoutKey = '';
    this._lastNativeGeometry = null;
    this._outputIndex = 1;
    this._lastRecoverAt = 0;
  }

  init({ viewportEl, canvasEl, surface = 'screen', prefs = null, outputIndex = 1 } = {}) {
    this.viewportEl = viewportEl;
    this.canvasEl = canvasEl;
    this.surface = surface;
    this._outputIndex = Number(outputIndex) > 1 ? Math.floor(Number(outputIndex)) : 1;
    if (prefs) this.prefs = prefs;
    this.bindEvents();
    const cached = getCachedDisplaySnapshot(8000);
    if (cached) {
      this.applySnapshot(cached, { silent: true });
    } else {
      requestAnimationFrame(() => {
        this.refresh().catch(() => this.recalculate());
      });
    }
    if (surface === 'screen') {
      window.setTimeout(() => {
        requestNativeProjectionRecover();
        this.refresh().catch(() => this.recalculate());
      }, 280);
    }
  }

  setPrefs(prefs) {
    const prevKey = JSON.stringify(this.prefs?.displayEngine || {});
    this.prefs = prefs || {};
    const nextKey = JSON.stringify(this.prefs?.displayEngine || {});
    if (prevKey !== nextKey) {
      this.recalculate();
    }
  }

  bindEvents() {
    const onResize = () => {
      this._lastLayoutKey = '';
      this._checkViewportMismatch(true);
      this.scheduleRecalc();
    };
    window.addEventListener('resize', onResize, { passive: true });
    this._disposeFns.push(() => window.removeEventListener('resize', onResize));

    if (window.visualViewport) {
      const onVv = () => {
        this._lastLayoutKey = '';
        this._checkViewportMismatch(true);
        this.scheduleRecalc();
      };
      window.visualViewport.addEventListener('resize', onVv, { passive: true });
      this._disposeFns.push(() => window.visualViewport.removeEventListener('resize', onVv));
    }

    const onDisplayChanged = (ev) => {
      logHotplug('display-changed', { source: ev?.type || 'event' });
      const snap = ev?.detail?.snapshot;
      if (snap?.displays?.length) {
        applyPushedDisplaySnapshot(snap);
        this.applySnapshot(snap, { silent: true });
        return;
      }
      this.scheduleRecalc();
    };
    window.addEventListener('somosum-display-changed', onDisplayChanged);
    this._disposeFns.push(() => window.removeEventListener('somosum-display-changed', onDisplayChanged));

    document.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'visible') this.scheduleRecalc();
    });

    const onLayoutReady = () => this.scheduleRecalc();
    window.addEventListener('somosum-projection-layout-ready', onLayoutReady);
    this._disposeFns.push(() => window.removeEventListener('somosum-projection-layout-ready', onLayoutReady));

    this._bindNativeMessages();
  }

  _bindNativeMessages() {
    if (typeof window === 'undefined') return;
    if (this._nativeListener) return;
    const handler = (ev) => {
      const snapshot = ev?.detail?.snapshot;
      if (!snapshot) return;
      applyPushedDisplaySnapshot(snapshot);
      this.applySnapshot(snapshot, { silent: true });
    };
    window.addEventListener('engine-display-changed', handler);
    this._disposeFns.push(() => window.removeEventListener('engine-display-changed', handler));
    if (window.Engine?.display?.onChanged) {
      const off = window.Engine.display.onChanged(({ snapshot }) => {
        if (!snapshot) return;
        applyPushedDisplaySnapshot(snapshot);
        this.applySnapshot(snapshot, { silent: true });
      });
      if (typeof off === 'function') this._disposeFns.push(off);
    }
  }

  scheduleRecalc() {
    if (this._recalcPending) return;
    this._recalcPending = true;
    requestAnimationFrame(() => {
      this._recalcPending = false;
      this.recalculate();
    });
  }

  async fetchSnapshot() {
    const cached = getCachedDisplaySnapshot(400);
    if (cached) return cached;

    const shell = window.Engine?.shell;
    const snap = window.Engine?.display?.getSnapshot?.();
    if (snap?.displays?.length) {
      applyPushedDisplaySnapshot(snap);
      return snap;
    }
    // Preferir snapshot detalhado (hash/DPI/modos) — nunca promover lista fina ao cache
    if (shell?.isAvailable?.()) {
      const detailedRaw = shell.getDisplaysDetailed?.()
        ?? shell.getDisplaySnapshot?.()
        ?? shell.getDisplaysJson?.();
      if (detailedRaw != null) {
        try {
          const parsed = typeof detailedRaw === 'string' ? JSON.parse(detailedRaw) : detailedRaw;
          if (parsed?.displays?.length) {
            const built = {
              ...parsed,
              timestamp: parsed.timestamp || Date.now(),
              displays: parsed.displays.map((d, i) => normalizeLegacyDisplay(d, i)),
            };
            applyPushedDisplaySnapshot(built);
            return built;
          }
          const asList = parseDisplaysJson(typeof detailedRaw === 'string' ? detailedRaw : String(detailedRaw))
            .map((d, i) => normalizeLegacyDisplay(d, i));
          if (asList.length) {
            const built = { timestamp: Date.now(), displays: asList };
            applyPushedDisplaySnapshot(built);
            return built;
          }
        } catch { /* fallback abaixo */ }
      }
      const list = (shell.getDisplays?.() || []).map((d, i) => normalizeLegacyDisplay(d, i));
      if (list.length && list.some((d) => d.displayHash || d.currentMode || d.dpiScale)) {
        const built = { timestamp: Date.now(), displays: list };
        applyPushedDisplaySnapshot(built);
        return built;
      }
    }
    const fast = listDisplaysFast(0);
    if (fast?.length && !shell?.isAvailable?.()) {
      return { timestamp: Date.now(), displays: fast.map((d, i) => normalizeLegacyDisplay(d, i)) };
    }
    return browserFallbackSnapshot();
  }

  async refresh() {
    const snapshot = await this.fetchSnapshot();
    this.applySnapshot(snapshot);
  }

  _snapshotKey(display, snapshot) {
    if (!display) return '';
    const b = display.bounds || {};
    const m = display.currentMode || {};
    const cfg = snapshot?.configurationVersion || '';
    return `${display.deviceName}|${b.w || m.w}|${b.h || m.h}|${display.dpiScale || 1}|${cfg}`;
  }

  _checkViewportMismatch(force = false) {
    const viewport = this.viewportEl;
    if (!viewport || !this.projectionDisplay) return false;
    const captured = captureProjectionViewport(viewport);
    applyProjectionViewportDataset(viewport, captured, this.snapshot, this._outputIndex);
    const result = compareViewportMismatch(captured, this.projectionDisplay, this.snapshot || {});
    if (result.mismatch) {
      logViewportMismatch(result.flags, { viewport: captured.clientWidth + 'x' + captured.clientHeight });
      this._lastSnapshotKey = '';
      // Ao redimensionar / “aumentar a tela”: reassert bounds nativos (evita projetor reduzido)
      const now = Date.now();
      if (force || !this._lastRecoverAt || now - this._lastRecoverAt > 800) {
        this._lastRecoverAt = now;
        requestNativeProjectionRecover();
      }
      return true;
    }
    return false;
  }

  noteNativeGeometry(diagnostic) {
    this._lastNativeGeometry = diagnostic || null;
    if (diagnostic && diagnostic.ok === false) {
      this._lastSnapshotKey = '';
      // Não “adaptar” ao client pela metade — pedir reassert nativo (Holyrics drift loop).
      const now = Date.now();
      if (!this._lastRecoverAt || now - this._lastRecoverAt > 800) {
        this._lastRecoverAt = now;
        requestNativeProjectionRecover();
      }
      this.scheduleRecalc();
    }
  }

  applySnapshot(snapshot, options = {}) {
    if (!snapshot?.displays?.length) return;
    const silent = options.silent === true;
    const merged = mergeKnownDisplays(snapshot);
    this.snapshot = merged;
    const nextDisplay = pickProjectionDisplay(merged.displays, this._outputIndex);
    if (!nextDisplay) return;
    const normalized = normalizeLegacyDisplay(nextDisplay, nextDisplay.index ?? 0);
    const nextKey = this._snapshotKey(normalized, merged);
    const viewportMismatch = this._checkViewportMismatch();
    if (silent && nextKey && nextKey === this._lastSnapshotKey && !viewportMismatch) return;
    this._lastSnapshotKey = nextKey;
    this.projectionDisplay = normalized;

    // Restaura / cria perfil persistente (Projetor.md Fase 2)
    try {
      this._knownProfile = restoreOrCreateDisplayProfile(normalized, this.prefs);
    } catch { this._knownProfile = null; }

    const profileId = this.prefs?.displayEngine?.projectorProfile
      || this._knownProfile?.projection?.projectorProfileId;
    this.profile = profileId && PROJECTOR_PROFILES[profileId]
      ? PROJECTOR_PROFILES[profileId]
      : matchProjectorProfile({
        ...this.projectionDisplay,
        maxMode: resolveProjectionMode(this.projectionDisplay, this._knownProfile),
        recommendedMode: this.projectionDisplay.recommendedMode,
      });

    this.recalculate();
    if (!silent) {
      window.dispatchEvent(new CustomEvent('somosum-display-changed', { detail: { snapshot: this.snapshot } }));
    }
  }

  updateSlideContext(ctx = {}) {
    const prev = this._slideContext;
    const next = { ...prev, ...ctx };
    const typographyChanged = next.lineCount !== prev.lineCount
      || next.maxChars !== prev.maxChars
      || next.type !== prev.type
      || next.operatorFontSize !== prev.operatorFontSize
      || next.preferOperatorFont !== prev.preferOperatorFont;
    this._slideContext = next;
    if (typographyChanged) {
      this.applyTypographyOnly();
    }
  }

  applyTypographyOnly() {
    const viewport = this.viewportEl;
    if (!viewport) return;

    const { vw, vh } = logicalDesignSize(viewport, this.projectionDisplay);
    const designW = evenPx(vw);
    const designH = evenPx(vh);
    const aspect = this.projectionDisplay?.aspectRatio
      || (designW / designH < 1.4 ? '4:3' : '16:9');
    const dpiScale = this.projectionDisplay?.dpiScale || 1;
    const fontBoost = this.profile?.fontBoost
      || parseFloat(this.prefs?.projectionFontBoost)
      || 1.1;
    const safeArea = resolveSafeArea(this.projectionDisplay, this.prefs, this.profile);

    const typography = computeTypography({
      viewportW: designW,
      viewportH: designH,
      lineCount: this._slideContext.lineCount,
      maxCharsPerLine: this._slideContext.maxChars,
      dpiScale,
      aspectRatio: aspect,
      operatorFontSize: this._slideContext.operatorFontSize
        ?? this.prefs?.globalLyricsStyle?.fontSize
        ?? 54,
      preferOperatorFont: !!this._slideContext.preferOperatorFont,
      fontBoost,
      profile: this.profile,
      safeArea,
      maxLegibility: !!(this.prefs?.displayEngine?.maxLegibility || this.profile?.maxLegibility),
    });
    applyTypographyVars(viewport, typography);
    if (this.canvasEl) applyTypographyVars(this.canvasEl, typography);
  }

  recalculate() {
    if (this._recalcRunning) return;
    const viewport = this.viewportEl;
    const canvas = this.canvasEl;
    if (!viewport) return;

    this._recalcRunning = true;
    try {
      this._recalculateCore(viewport, canvas);
    } finally {
      this._recalcRunning = false;
    }
  }

  _recalculateCore(viewport, canvas) {
    if (this._checkViewportMismatch(true)) {
      // força novo ciclo mesmo que snapshot key pareça estável
    }

    const { vw, vh } = logicalDesignSize(viewport, this.projectionDisplay);
    const designW = evenPx(vw);
    const designH = evenPx(vh);

    if (canvas) {
      canvas.style.width = `${designW}px`;
      canvas.style.height = `${designH}px`;
      canvas.style.transform = 'scale(1)';
    }

    const safeArea = resolveSafeArea(this.projectionDisplay, this.prefs, this.profile);
    const outputPreset = resolveOutputPreset(this.surface, this._outputIndex);

    // Canvas preenche o monitor 1:1. Safe area só recua o texto (CSS padding), não encolhe o quadro.
    const safeScale = 1;

    const aspect = this.projectionDisplay?.aspectRatio
      || (designW / designH < 1.4 ? '4:3' : '16:9');
    const dpiScale = this.projectionDisplay?.dpiScale || 1;
    const fontBoost = this.profile?.fontBoost
      || parseFloat(this.prefs?.projectionFontBoost)
      || 1.1;

    const layoutKey = [
      designW, designH, aspect, dpiScale, fontBoost,
      JSON.stringify(safeArea), this._snapshotKey(this.projectionDisplay, this.snapshot),
      outputPreset.id,
    ].join('|');
    if (layoutKey === this._lastLayoutKey && !this._checkViewportMismatch()) {
      return;
    }
    this._lastLayoutKey = layoutKey;

    const targets = [viewport, canvas, document.documentElement].filter(Boolean);
    const aspectPolicy = resolveAspectPolicy({
      slide: this._slideContext,
      prefs: this.prefs,
      profile: this.profile,
      display: this.projectionDisplay,
    });
    targets.forEach((el) => {
      // Sempre com unidade — CSS width: var(--dpe-design-w) precisa de px
      el.style.setProperty('--dpe-viewport-w', `${Math.round(vw)}px`);
      el.style.setProperty('--dpe-viewport-h', `${Math.round(vh)}px`);
      el.style.setProperty('--dpe-design-w', `${designW}px`);
      el.style.setProperty('--dpe-design-h', `${designH}px`);
      el.style.setProperty('--dpe-scale', String(safeScale));
      el.style.setProperty('--projection-scale', String(safeScale));
      el.style.setProperty('--dpe-dpi-scale', String(dpiScale));
      el.style.setProperty('--dpe-aspect', aspectCssKey(aspect));
      el.style.setProperty('--projection-aspect-policy', aspectPolicy);
      el.style.setProperty('--dpe-font-boost', String(fontBoost));
      el.style.setProperty('--projection-font-boost', String(fontBoost));
      // Em SVGA/4:3: floor mais alto evita tipografia “miúda”
      const projFloor = (this.profile?.id === 'svga' || aspect === '4:3') ? '0.72' : '0.55';
      el.style.setProperty('--proj-comp', `max(var(--dpe-scale, var(--projection-scale, 1)), ${projFloor})`);
      applySafeAreaVars(el, safeArea);
    });

    viewport.dataset.projectionFit = '1';
    viewport.dataset.projectionViewport = `${Math.round(vw)}x${Math.round(vh)}`;
    viewport.dataset.aspect = aspect === '4:3' || designW / designH < 1.4 ? '4x3' : '';
    viewport.dataset.dpeProfile = this.profile?.id || '';
    document.documentElement.dataset.dpeProfile = this.profile?.id || '';
    document.documentElement.dataset.aspect = viewport.dataset.aspect || '';

    const colorPolicy = this.prefs?.displayEngine?.colorPolicy
      || this._knownProfile?.projection?.colorPolicy
      || suggestColorPolicy(this.projectionDisplay, this.profile);
    applyColorPolicyVars(viewport, colorPolicy);
    logColorPolicy(colorPolicy, this.projectionDisplay);
    if (canvas) applyColorPolicyVars(canvas, colorPolicy);
    if (canvas) {
      canvas.style.filter = 'var(--proj-color-filter, none)';
    }
    applyVideoLegibilityLayer(viewport, this.prefs);
    if (canvas) applyVideoLegibilityLayer(canvas, this.prefs);

    const layoutVars = computeLayoutVars(
      { projectionDisplay: this.projectionDisplay, displays: this.snapshot?.displays },
      this._slideContext.type || 'default',
    );
    applyLayoutVars(viewport, layoutVars);

    const typography = computeTypography({
      viewportW: designW,
      viewportH: designH,
      lineCount: this._slideContext.lineCount,
      maxCharsPerLine: this._slideContext.maxChars,
      dpiScale,
      aspectRatio: aspect,
      operatorFontSize: this._slideContext.operatorFontSize
        ?? this.prefs?.globalLyricsStyle?.fontSize
        ?? 54,
      preferOperatorFont: !!this._slideContext.preferOperatorFont,
      fontBoost,
      profile: this.profile,
      safeArea,
      maxLegibility: !!(this.prefs?.displayEngine?.maxLegibility || this.profile?.maxLegibility),
    });
    applyTypographyVars(viewport, typography);

    const videoFit = resolveVideoFit({ slide: this._slideContext, prefs: this.prefs, profile: this.profile });
    applyVideoFitVars(viewport, videoFit);
    logVideoLayout(videoFit, { aspectPolicy });
    applyVideoFitToElements(viewport, videoFit);
    if (canvas && canvas !== viewport) applyVideoFitToElements(canvas, videoFit);
    applyOutputPresetVars(viewport, outputPreset);
    if (canvas) applyOutputPresetVars(canvas, outputPreset);

    const capturedViewport = captureProjectionViewport(viewport);
    applyProjectionViewportDataset(viewport, capturedViewport, this.snapshot);
    if (this.snapshot?.configurationVersion) {
      document.documentElement.dataset.configurationVersion = this.snapshot.configurationVersion;
    }

    document.documentElement.classList.add('projection-ready');
  }

  detach() {
    this._disposeFns.forEach((fn) => { try { fn(); } catch { /* */ } });
    this._disposeFns = [];
    if (DisplayProjectionEngine._instance === this) DisplayProjectionEngine._instance = null;
  }
}

export function bootDisplayProjectionEngine(options) {
  return DisplayProjectionEngine.attach(options.viewportEl, options.canvasEl, options);
}

export function getDesignDimensions(viewportEl) {
  const vw = viewportEl?.clientWidth || window.innerWidth || 1920;
  const vh = viewportEl?.clientHeight || window.innerHeight || 1080;
  return { w: evenPx(vw), h: evenPx(vh) };
}
