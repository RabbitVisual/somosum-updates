﻿import { toast as fbToast, confirmDialog, clearBanner } from '../../ui/feedback.js';
import { HealthMonitor } from '../../core/health-monitor.js';
import { MessageTypes } from '../../core/bus.js';
import { animateSlideChange } from '../../slides/animations.js';
import { renderPreview, ensurePreviewLyricsBackground, patchPreviewLyricsStage, previewLyricsShellKey } from '../../slides/slide-engine.js';
import { DEFAULT_COMMUNION_PHASES } from '../../data/communion-defaults.js';
import { getPassage } from '../../bible/bible-service.js';
import { DiskAdapter } from '../../core/storage/adapters/disk-adapter.js';
import { TRANSITIONS, transitionLabel } from '../../slides/animations.js';
import { SLIDE_TYPE_OPTIONS } from '../../program/programa-templates.js';
import { wireStageCentral } from '../stage-central.js';
import { wireEbdTimer } from '../ebd/ebd-timer.js';
import { parseLyrics } from '../../lyrics/lyrics-parser.js';
import { parseScriptBlocks } from '../utils/sermon-script.js';
import { getRecoveryEngine } from '../../runtime/facades/recovery-runtime.js';
import { defer, scheduleRaf } from '../../core/defer.js';
import { isRuntimeRecoveryActive } from '../../runtime/facades/recovery-runtime.js';
import { TaskIds } from '../../core/task-registry.js';
import { TaskScheduler } from '../../core/task-scheduler.js';
import { RecoveryMonitor } from '../../core/recovery/recovery-monitor.js';
import { resolveLiveAtmosphereId } from '../../ui/theme/atmospheres.js';
import { ThemeEngine } from '../../ui/theme/theme-engine.js';
import { wireCommandPalette } from '../../ux/command-palette.js';
import { wireQuickSearch } from '../../ux/quick-search.js';
import { wireGlobalUndo } from '../../ux/global-undo.js';
import { initDockPanels } from '../../ux/dock-panels.js';
import { createProjectorSync } from '../sync/projector-sync.js';
import { createToastService } from '../services/toast-service.js';
import { faIcon } from '../../core/fa-icons.js';
import { refitStagePreviewContainer } from '../../ui/stage-preview-fit.js';
import { esc, escAttr, rawHtml, setHtml, patchHost } from '../../core/render-engine/index.js';

const SLIDE_TYPE_LABELS = Object.fromEntries(SLIDE_TYPE_OPTIONS.map((o) => [o.type, o.label]));

function slideTypeLabel(t) {
  return SLIDE_TYPE_LABELS[t] || ({
    welcome: 'Boas-vindas', lyrics: 'Louvor', 'lyrics-title': 'Louvor',
    bible: 'Leitura bíblica', message: 'Mensagem', prayer: 'Oração',
    section: 'Seção', announcements: 'Comunicados', communion: 'Ceia do Senhor',
    theme: 'Tema / Divisa', custom: 'Personalizado', media: 'Mídia',
    deck: 'Apresentação', pptx: 'Apresentação',
    participation: 'Participação', offering: 'Oferta', countdown: 'Pré-culto',
    'bible-intro': 'Introito', 'bible-interlinear': 'Interlinear',
    blank: 'Em branco', logo: 'Logo',
  }[t] || t || '');
}

function registerPreviewFit(container, fitFn) {
  if (container._resizeObs) {
    container._resizeObs.disconnect();
    container._resizeObs = null;
  }
  if (!window.__SOMOSUM_PREVIEW_FIT_SET) {
    window.__SOMOSUM_PREVIEW_FIT_SET = new Set();
    let pending = false;
    window.addEventListener('resize', () => {
      if (pending) return;
      pending = true;
      scheduleRaf(() => {
        pending = false;
        window.__SOMOSUM_PREVIEW_FIT_SET.forEach((fn) => { try { fn(); } catch { /* */ } });
      });
    }, { passive: true });
  }
  if (container._previewFitFn) {
    window.__SOMOSUM_PREVIEW_FIT_SET.delete(container._previewFitFn);
  }
  container._previewFitFn = fitFn;
  window.__SOMOSUM_PREVIEW_FIT_SET.add(fitFn);
}

let previewLiveRaf = null;
let previewLiveJob = null;

function schedulePreviewLiveCommit(run) {
  previewLiveJob = run;
  if (previewLiveRaf != null) return;
  previewLiveRaf = scheduleRaf(() => {
    previewLiveRaf = null;
    const job = previewLiveJob;
    previewLiveJob = null;
    if (typeof job === 'function') job();
  });
}

function extractStageInner(rendered) {
  return rendered.match(/<div class="screen-stage">([\s\S]*)<\/div><\/div><\/div>/)?.[1] || null;
}

function patchPreviewStageFromRendered(scaler, rendered) {
  const stageInner = extractStageInner(rendered);
  const stage = scaler?.querySelector('.screen-stage');
  if (stage && stageInner) {
    const probe = document.createElement('div');
    setHtml(probe, rawHtml(stageInner));
    patchHost(stage, probe, { full: true });
    return true;
  }
  if (scaler) {
    setHtml(scaler, rawHtml(rendered));
    return true;
  }
  return false;
}

function writePreviewContainer(container, rendered) {
  setHtml(container, rawHtml(`<div class="preview-scaler" id="preview-scaler">${rendered}</div>`));
  return container.querySelector('#preview-scaler');
}

function paintPreviewAtmosphere(app, slide, scaler) {
  const themeId = resolveLiveAtmosphereId(app.prefs, slide);
  const el = scaler || document.getElementById('preview-scaler');
  if (el) ThemeEngine.applyTo(el, themeId);
  else ThemeEngine.apply(themeId);
}

function previewShellKey(slide, prefs) {
  const bg = slide?.background;
  const bgKey = bg?.type && bg?.src
    ? `${bg.type}:${String(bg.src).slice(0, 120)}`
    : (bg?.type || 'none');
  return `${slide?.type || 'unknown'}|${slide?.transition || prefs?.transition || 'fade'}|${bgKey}`;
}

function applyLowSpecFlag(app) {
  const on = !!(app.prefs?.lowSpec || app.prefs?.ui?.lowSpec);
  window.__SOMOSUM_LOW_SPEC = on;
  document.documentElement.classList.toggle('somosum-low-spec', on);
  document.documentElement.classList.toggle('su-reduce-motion', on || !!app.prefs?.ui?.reducedMotion);
  if (on) {
    import('../../runtime/resource-governor.js').then(({ ResourceGovernor }) => {
      const live = !!window.__SOMOSUM_LIVE_ACTIVE;
      ResourceGovernor.forceProfile(live ? 'live-eco' : 'eco');
    }).catch(() => {});
  }
}

function wireLowSpecFpsToast(app) {
  if (typeof window === 'undefined' || window.__SOMOSUM_FPS_TOAST_BOUND) return;
  window.__SOMOSUM_FPS_TOAST_BOUND = true;
  let lastToastAt = 0;
  window.addEventListener('somosum-watchdog-fps-low', (ev) => {
    const fps = Number(ev.detail?.fps || 0);
    // Toast na faixa Low-Spec Pro: fps < 20 (warn ou fail do Watchdog)
    if (fps >= 20) return;
    const now = Date.now();
    if (now - lastToastAt < 60000) return;
    lastToastAt = now;
    const msg = fps
      ? `Desempenho baixo (${fps} FPS). Considere desativar animações pesadas (Modo Low-Spec).`
      : 'Desempenho baixo. Considere desativar animações pesadas (Modo Low-Spec).';
    try {
      app.toast?.(msg, 'warn');
    } catch { /* ignore */ }
  });
}

function wireLowSpecAutoDetect(app) {
  if (typeof window === 'undefined' || window.__SOMOSUM_LOW_SPEC_AUTO_BOUND) return;
  window.__SOMOSUM_LOW_SPEC_AUTO_BOUND = true;
  window.addEventListener('somosum-low-spec-auto', (ev) => {
    applyLowSpecFlag(app);
    const reason = ev.detail?.reason === 'deviceMemory'
      ? 'memória limitada'
      : 'CPU limitada';
    app.toast?.(`Modo Low-Spec ativado (${reason}). Ajuste em Ajustes se preferir desligar.`, 'info');
  });
}

export function wireControlUpgradesB(app) {
  app.setPreviewHtml = (container, slide) => {
    if (!container) return;
    const urls = app.getAssetUrls();
    const isLyrics = slide?.type === 'lyrics' || slide?.type === 'lyrics-title';
    const isParticipation = slide?.type === 'participation';

    const scheduleFit = () => {
      scheduleRaf(() => refitStagePreviewContainer(container));
    };

    if (isLyrics) {
      const shellKey = previewLyricsShellKey(slide);
      let scaler = container.querySelector('#preview-scaler');
      if (scaler && container._previewLyricsShellKey === shellKey
        && patchPreviewLyricsStage(scaler, slide, app.prefs, {
          defaults: app.defaults,
          assets: urls,
        })) {
        ensurePreviewLyricsBackground(scaler, slide, app.prefs);
        paintPreviewAtmosphere(app, slide, scaler);
        if (!app.isCountdownLive?.()) {
          container.querySelectorAll('.countdown-preview-overlay').forEach((n) => n.remove());
        }
        return;
      }
      const rendered = renderPreview(slide, app.defaults, app.prefs, urls);
      scaler = writePreviewContainer(container, rendered);
      container._previewHtml = rendered;
      container._previewLyricsShellKey = shellKey;
      container._previewShellKey = null;
      ensurePreviewLyricsBackground(scaler, slide, app.prefs);
      paintPreviewAtmosphere(app, slide, scaler);
      scheduleFit();
      registerPreviewFit(container, scheduleFit);
      return;
    }

    container._previewLyricsShellKey = null;
    const rendered = renderPreview(slide, app.defaults, app.prefs, urls);
    const htmlKey = `<div class="preview-scaler" id="preview-scaler">${rendered}</div>`;
    const shellKey = previewShellKey(slide, app.prefs);
    const hasMediaBg = slide?.background?.type === 'video' || slide?.background?.type === 'image';

    if (container._previewHtml === htmlKey) {
      if (!app.isCountdownLive?.()) {
        container.querySelectorAll('.countdown-preview-overlay').forEach((n) => n.remove());
      }
      const existingScaler = container.querySelector('#preview-scaler');
      if (hasMediaBg && existingScaler) {
        ensurePreviewLyricsBackground(existingScaler, slide, app.prefs);
      }
      paintPreviewAtmosphere(app, slide, existingScaler);
      scheduleFit();
      return;
    }
    container._previewHtml = htmlKey;

    const prevStage = container.querySelector('.screen-stage');
    const isCustomCanvas = slide?.type === 'custom' && slide?.layers?.length;
    const skipAnimate = isLyrics || isParticipation || app.autoLive;
    const scaler = container.querySelector('#preview-scaler');

    const commit = () => {
      let nextScaler = scaler;
      if (nextScaler && container._previewShellKey === shellKey && patchPreviewStageFromRendered(nextScaler, rendered)) {
        container._previewShellKey = shellKey;
      } else {
        nextScaler = writePreviewContainer(container, rendered);
        container._previewShellKey = shellKey;
      }
      const stage = nextScaler?.querySelector('.screen-stage');
      if (stage) stage.dataset.transition = slide?.transition || app.prefs.transition || 'fade';
      if (hasMediaBg) ensurePreviewLyricsBackground(nextScaler, slide, app.prefs);
      paintPreviewAtmosphere(app, slide, nextScaler);
      scheduleFit();
    };

    if (prevStage && slide && !isCustomCanvas && !skipAnimate) {
      animateSlideChange(prevStage, commit);
    } else {
      commit();
    }

    registerPreviewFit(container, scheduleFit);
  };

  app.renderLookahead = () => {
    const el = document.getElementById('rundown-lookahead');
    if (!el) return;
    const meta = app.program.getCurrentMeta();
    if (!meta) { setHtml(el, ''); return; }
    const start = meta.itemIndex + 1;
    const next = app.program.items.slice(start, start + 4);
    if (!next.length) {
      setHtml(el, rawHtml('<p class="lookahead-empty">Fim do programa</p>'));
      return;
    }
    setHtml(el, rawHtml(`<div class="lookahead-title">${faIcon('next', 'su-fa su-fa--sm')} A seguir</div>${next.map((it, i) => {
      const idx = start + i;
      return `<button type="button" class="lookahead-item" data-item-index="${idx}" title="Ir para este item">
        <span class="lookahead-type">${esc(slideTypeLabel(it.slideType))}</span>
        <span class="lookahead-name">${esc(it.title)}</span>
      </button>`;
    }).join('')}`));
    el.querySelectorAll('[data-item-index]').forEach((btn) => {
      btn.onclick = () => app.goToItem?.(Number(btn.dataset.itemIndex));
    });
  };

  app.renderOverlayPanel = () => {
    const el = document.getElementById('overlay-panel');
    if (!el) return;
    const slide = app.program?.getCurrentSlide?.();
    const isIl = slide?.type === 'bible-interlinear';
    const view = app.interlinearView || {
      original: true,
      strong: true,
      gloss: true,
      translation: true,
    };
    const chip = (key, label, on) =>
      `<button type="button" class="btn btn-sm il-live-chip ${on ? 'is-on' : ''}" data-il-toggle="${key}" title="${label}">${label}</button>`;
    setHtml(el, rawHtml(`
      <button type="button" class="btn btn-secondary btn-sm overlay-btn" data-overlay="clear" title="Limpar overlay">${faIcon('close', 'su-fa su-fa--inline-btn')} Limpar</button>
      <button type="button" class="btn btn-secondary btn-sm overlay-btn" data-overlay="blank" title="Tela preta (B)">${faIcon('blank', 'su-fa su-fa--inline-btn')} Preta</button>
      <button type="button" class="btn btn-secondary btn-sm overlay-btn" data-overlay="logo" title="Logo (L)">${faIcon('logo', 'su-fa su-fa--inline-btn')} Logo</button>
      ${isIl ? `<span class="il-live-chips" title="Camadas do interlinear ao vivo">
        ${chip('original', 'Original', view.original !== false)}
        ${chip('strong', 'Strong', view.strong !== false)}
        ${chip('gloss', 'Significado', view.gloss !== false)}
        ${chip('translation', 'Tradução', view.translation !== false)}
      </span>` : ''}`));
    el.querySelectorAll('[data-overlay]').forEach((btn) => {
      btn.onclick = () => {
        const mode = btn.dataset.overlay;
        if (mode === 'clear') app.broadcastOverlay?.('clear');
        else app.broadcastOverlay?.(mode);
      };
    });
    el.querySelectorAll('[data-il-toggle]').forEach((btn) => {
      btn.onclick = () => {
        const key = btn.dataset.ilToggle;
        if (!app.interlinearView) {
          app.interlinearView = { original: true, strong: true, gloss: true, translation: true };
        }
        app.interlinearView[key] = !(app.interlinearView[key] !== false);
        app.renderOverlayPanel?.();
        app.syncProjectorState?.(true, { skipInspector: true, liveEdit: true });
        app.syncCoordinator?.emit?.({ kind: 'stage' });
      };
    });
  };

  app.communionInspectorHtml = (item) => {
    const d = item.data || {};
    const phases = d.phases?.length ? d.phases : structuredClone(DEFAULT_COMMUNION_PHASES);
    const kindOptions = (selected) => [
      { id: 'intro', label: 'Abertura' },
      { id: 'bread', label: 'O Pão' },
      { id: 'cup', label: 'O Cálice' },
      { id: 'meditation', label: 'Meditação' },
      { id: 'custom', label: 'Personalizada' },
    ].map((k) => `<option value="${k.id}" ${selected === k.id ? 'selected' : ''}>${k.label}</option>`).join('');

    const phasesHtml = phases.map((p, i) => {
      const kind = p.id || 'custom';
      const canLoadBible = kind === 'bread' || kind === 'cup';
      return `
      <article class="communion-phase-card" data-phase-idx="${i}">
        <header class="comm-phase-header">
          <span class="comm-phase-badge comm-phase-badge--${esc(kind)}">${i + 1}</span>
          <select class="comm-phase-kind" title="Tipo da fase">${kindOptions(kind)}</select>
          ${phases.length > 1 ? `<button type="button" class="btn btn-ghost btn-sm comm-phase-remove" title="Remover fase">✕</button>` : ''}
        </header>
        <input type="hidden" class="comm-phase-id" value="${escAttr(p.id || `phase-${i}`)}" />
        <div class="form-block">
          <label>Título na projeção</label>
          <input class="comm-phase-title" value="${escAttr(p.title || '')}" placeholder="Ex.: O Pão" />
        </div>
        <div class="form-block">
          <label>Subtítulo <span class="form-hint-inline">(opcional)</span></label>
          <input class="comm-phase-sub" value="${escAttr(p.subtitle || '')}" placeholder="Ex.: Corpo de Cristo, partido por nós" />
        </div>
        <div class="form-block">
          <label>Referência bíblica</label>
          <div class="comm-ref-row">
            <input class="comm-phase-ref" value="${escAttr(p.reference || '')}" placeholder="1 Coríntios 11:23-24 (NAA)" />
            ${canLoadBible ? `<button type="button" class="btn btn-secondary btn-sm comm-load-bible" data-kind="${esc(kind)}">Carregar versículo</button>` : ''}
          </div>
        </div>
        <div class="form-block">
          <label>Texto na projeção</label>
          <textarea class="comm-phase-text" rows="4" placeholder="Texto bíblico ou meditação">${esc(p.text || '')}</textarea>
        </div>
      </article>`;
    }).join('');

    return `
      <div class="communion-inspector">
        <div class="communion-inspector-intro">
          <p class="communion-inspector-lead">Configure cada momento da Ceia do Senhor — pão e cálice na projeção, textos e navegação por fases.</p>
          <div class="communion-toolbar">
            <button type="button" class="btn btn-secondary btn-sm" id="comm-defaults">${faIcon('reset', 'su-fa su-fa--inline-btn')} Textos bíblicos padrão</button>
            <button type="button" class="btn btn-secondary btn-sm" id="comm-add-phase">+ Nova fase</button>
          </div>
        </div>
        <div id="comm-phases" class="communion-phases">${phasesHtml}</div>
        <div class="communion-options">
          <h4 class="form-section-title">Visual na projeção</h4>
          <label class="comm-option"><input type="checkbox" id="comm-elements" ${d.showElements !== false ? 'checked' : ''} />
            <span><strong>Pão e cálice</strong> — ilustrações douradas por fase</span></label>
          <label class="comm-option"><input type="checkbox" id="comm-cross" ${d.showCross ? 'checked' : ''} />
            <span><strong>Cruz</strong> — substitui o ornamento central</span></label>
          <label class="comm-option"><input type="checkbox" id="comm-theme" ${d.useCommunionTheme !== false ? 'checked' : ''} />
            <span><strong>Paleta trigo &amp; vinho</strong> — fundo temático automático</span></label>
        </div>
        <p class="form-hint communion-nav-hint">No preview, use os chips abaixo para avançar entre as fases (como em louvor).</p>
      </div>`;
  };

  app.readCommunionFromInspector = (el, item) => {
    const rows = el.querySelectorAll('.communion-phase-card');
    const phases = [...rows].map((row, i) => {
      const kind = row.querySelector('.comm-phase-kind')?.value || 'custom';
      return {
        id: kind === 'custom' ? (row.querySelector('.comm-phase-id')?.value || `phase-${i}`) : kind,
        title: row.querySelector('.comm-phase-title')?.value || '',
        reference: row.querySelector('.comm-phase-ref')?.value || '',
        text: row.querySelector('.comm-phase-text')?.value || '',
        subtitle: row.querySelector('.comm-phase-sub')?.value || '',
      };
    });
    return {
      ...item,
      data: {
        ...item.data,
        phases: phases.length ? phases : item.data?.phases,
        showCross: !!el.querySelector('#comm-cross')?.checked,
        showElements: el.querySelector('#comm-elements')?.checked !== false,
        useCommunionTheme: el.querySelector('#comm-theme')?.checked !== false,
      },
    };
  };

  const COMMUNION_BIBLE = {
    bread: { book: '1Co', chapter: 11, verseStart: 23, verseEnd: 24, ref: '1 Coríntios 11:23-24 (NAA)' },
    cup: { book: '1Co', chapter: 11, verseStart: 25, verseEnd: 25, ref: '1 Coríntios 11:25 (NAA)' },
  };

  app.bindCommunionInspector = (el, item, meta) => {
    el.querySelector('#comm-defaults')?.addEventListener('click', () => {
      item.data = {
        ...item.data,
        phases: structuredClone(DEFAULT_COMMUNION_PHASES),
        showElements: true,
        showCross: false,
        useCommunionTheme: true,
      };
      app.renderInspector(meta);
    });

    el.querySelector('#comm-add-phase')?.addEventListener('click', () => {
      const snap = app.readCommunionFromInspector?.(el, item) || item;
      const phases = [...(snap.data?.phases || []), {
        id: 'custom',
        title: 'Nova fase',
        subtitle: '',
        reference: '',
        text: '',
      }];
      Object.assign(item, snap);
      item.data = { ...item.data, phases };
      app.renderInspector(meta);
    });

    el.querySelectorAll('.comm-phase-remove').forEach((btn) => {
      btn.addEventListener('click', () => {
        const snap = app.readCommunionFromInspector?.(el, item) || item;
        const card = btn.closest('.communion-phase-card');
        const idx = Number(card?.dataset.phaseIdx);
        const phases = [...(snap.data?.phases || [])];
        if (phases.length <= 1) return;
        phases.splice(idx, 1);
        Object.assign(item, snap);
        item.data = { ...item.data, phases };
        app.renderInspector(meta);
      });
    });

    el.querySelectorAll('.comm-phase-kind').forEach((sel) => {
      sel.addEventListener('change', () => {
        const card = sel.closest('.communion-phase-card');
        const idInput = card?.querySelector('.comm-phase-id');
        if (idInput && sel.value !== 'custom') idInput.value = sel.value;
        const badge = card?.querySelector('.comm-phase-badge');
        if (badge) {
          badge.className = `comm-phase-badge comm-phase-badge--${sel.value}`;
        }
      });
    });

    el.querySelectorAll('.comm-load-bible').forEach((btn) => {
      btn.addEventListener('click', async () => {
        const kind = btn.dataset.kind;
        const spec = COMMUNION_BIBLE[kind];
        if (!spec) return;
        btn.disabled = true;
        btn.textContent = '…';
        try {
          const passage = await getPassage('naa', spec.book, spec.chapter, spec.verseStart, spec.verseEnd);
          const card = btn.closest('.communion-phase-card');
          const refEl = card?.querySelector('.comm-phase-ref');
          const textEl = card?.querySelector('.comm-phase-text');
          const text = passage.verses?.map((v) => v.text).join(' ') || '';
          if (refEl) refEl.value = passage.reference || spec.ref;
          if (textEl && text) textEl.value = text;
          app.toast('Versículo carregado');
        } catch {
          app.toast('Não foi possível carregar — verifique a Bíblia offline', 'error');
        } finally {
          btn.disabled = false;
          btn.textContent = 'Carregar versículo';
        }
      });
    });
  };

  app.transitionOverrideHtml = (item) => {
    const cur = item.transition || '';
    const opts = TRANSITIONS.map((t) =>
      `<option value="${t}" ${cur === t ? 'selected' : ''}>${transitionLabel(t)}</option>`
    ).join('');
    const globalLabel = transitionLabel(app.prefs.transition || 'fade');
    return `
      <section class="insp-card">
        <header class="insp-card-head">
          <h3 class="form-section-title">Transição deste item</h3>
        </header>
        <div class="form-block" style="margin:0">
          <select id="insp-transition">
            <option value="" ${!cur ? 'selected' : ''}>Herdar global (${globalLabel})</option>
            ${opts}
          </select>
          <p class="form-hint">A transição anima a entrada no projetor ao avançar o culto.</p>
        </div>
      </section>`;
  };

  app.enhanceTopbar = () => {
    const church = app.prefs.church || {};
    const brandTitle = document.getElementById('topbar-brand-title')
      || document.querySelector('.topbar-brand h1');
    if (brandTitle) brandTitle.textContent = church.name?.trim() || 'SOMOSUM';

    const rehearsal = document.getElementById('btn-rehearsal');
    if (rehearsal) {
      rehearsal.classList.toggle('is-active', !!app.isRehearsal());
      rehearsal.textContent = app.isRehearsal() ? 'Ensaio' : 'Ao vivo';
    }
  };

  app.bindCultoProgramUi = () => {
    const main = document.getElementById('main-view');
    if (!main || main.dataset.cultoUiBound === '1') return;
    main.dataset.cultoUiBound = '1';

    main.addEventListener('click', async (ev) => {
      const startBtn = ev.target.closest?.('#btn-culto-start');
      const endBtn = ev.target.closest?.('#btn-culto-end');
      const editBtn = ev.target.closest?.('#btn-culto-quick-edit');
      const closeBtn = ev.target.closest?.('#btn-culto-quick-close');
      const backdrop = ev.target.closest?.('#culto-quick-edit-backdrop');

      if (startBtn) {
        try {
          const { enterCultoPresentation } = await import('../../core/live-culto-mode.js');
          await enterCultoPresentation(app);
          // Sempre permanecer no Live Console (SEQUÊNCIA + Controles) —
          // nunca remountar a view legada `program` (dock ← Projetar →).
          if (app.view !== 'live') {
            if (typeof app.setView === 'function') app.setView('live');
            else {
              app.view = 'live';
              app.renderNav?.();
              app.renderView?.();
            }
          } else {
            app.refreshProgramUI?.({ skipInspector: true });
          }
        } catch (err) {
          app.toast?.(`Não foi possível iniciar o culto: ${err?.message || err}`, 'warn');
        }
        return;
      }
      if (endBtn) {
        try {
          const { exitCultoPresentation } = await import('../../core/live-culto-mode.js');
          await exitCultoPresentation(app);
          app.refreshProgramUI?.();
        } catch (err) {
          app.toast?.(`Não foi possível encerrar o culto: ${err?.message || err}`, 'warn');
        }
        return;
      }
      if (editBtn) {
        const { toggleCultoQuickEdit } = await import('../../core/live-culto-mode.js');
        const open = toggleCultoQuickEdit(true);
        if (open) app.paintInspectorForSelection?.();
        return;
      }
      if (closeBtn || backdrop) {
        const { toggleCultoQuickEdit } = await import('../../core/live-culto-mode.js');
        toggleCultoQuickEdit(false);
      }
    });
  };

  app.bindCultoQuickEdit = app.bindCultoProgramUi;

  app.closeCultoQuickEditIfOpen = async () => {
    const grid = document.querySelector('.program-grid');
    if (grid?.classList.contains('program-grid--quick-edit')) {
      const { toggleCultoQuickEdit } = await import('../../core/live-culto-mode.js');
      toggleCultoQuickEdit(false);
    }
  };

  app.enhanceUpdatePreviewBadge = () => {
    const badge = document.getElementById('preview-badge');
    if (!badge) return;
    if (app.isRehearsal()) {
      badge.textContent = '🎭 ENSAIO';
      badge.classList.add('is-rehearsal');
      return;
    }
    badge.classList.remove('is-rehearsal');
  };

  const origUpdateBadge = app.updatePreviewBadge.bind(app);
  app.updatePreviewBadge = () => {
    origUpdateBadge();
    app.enhanceUpdatePreviewBadge();
  };

  app.health.start(30000, { initialDelayMs: 12000 });
  if (location.protocol !== 'file:') {
    import('../../core/storage/adapters/server-adapter.js').then(({ waitForServerBoot }) => {
      waitForServerBoot().then((ok) => {
        if (ok) app.health?.markBootOk?.();
      }).catch(() => {});
    }).catch(() => {});
  }
  try {
    app.startAutoResync();
  } catch (err) {
    console.warn('[SOMOSUM] auto-resync', err);
  }

  import('../../core/live-culto-mode.js').then(({ restoreCultoPresentationFromPrefs }) => {
    restoreCultoPresentationFromPrefs(app);
    app.bindCultoProgramUi?.();
  }).catch(() => {});

  window.addEventListener('online', () => clearBanner());
  try {
    wireStageCentral(app);
    wireEbdTimer(app);
  } catch (err) {
    console.warn('[SOMOSUM] stage-central', err);
  }
}
