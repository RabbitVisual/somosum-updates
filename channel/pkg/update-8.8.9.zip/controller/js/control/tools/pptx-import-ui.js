/**
 * Diálogo Ferramentas → PowerPoint: importar .pptx nativo para a ordem.
 */
import { esc } from '../utils/escape.js';
import { parsePptxFile } from './pptx-import.js';
import { createProgramItem } from '../../program/programa-templates/factory.js';
import { saveMediaFile, generateId } from '../../core/store.js';
import { normalizeSong } from '../../worship/worship-schema.js';
import { saveWorshipSong } from '../../worship/worship-store.js';

function closeOverlay(overlay) {
  overlay.classList.remove('is-visible');
  setTimeout(() => overlay.remove(), 200);
}

/**
 * @param {import('../control-app/class-a.js').ControlApp} app
 * @param {{ targetItemId?: string }} [opts]
 */
export async function openPowerpointImport(app, opts = {}) {
  const existing = document.getElementById('su-pptx-overlay');
  if (existing) existing.remove();

  const overlay = document.createElement('div');
  overlay.id = 'su-pptx-overlay';
  overlay.className = 'su-dialog-overlay su-tools-overlay';
  overlay.innerHTML = `
    <div class="su-dialog su-dialog--wide su-tools-dialog" role="dialog" aria-modal="true" aria-labelledby="su-pptx-title">
      <h3 class="su-dialog__title" id="su-pptx-title">PowerPoint → ordem do culto</h3>
      <div class="su-dialog__body su-tools-body">
        <p class="su-tools-lead">Importação <strong>nativa</strong> de <code>.pptx</code> — sem precisar do PowerPoint instalado. Os slides entram na ordem e avançam com ← → no Ao vivo.</p>
        <label class="su-tools-file">
          <span>Escolher arquivo .pptx</span>
          <input type="file" accept=".pptx,application/vnd.openxmlformats-officedocument.presentationml.presentation" id="su-pptx-file">
        </label>
        <p class="su-tools-hint" id="su-pptx-status">Nenhum arquivo selecionado.</p>
        <div class="su-tools-preview" id="su-pptx-preview" hidden></div>
        <label class="su-tools-check">
          <input type="checkbox" id="su-pptx-lyrics">
          Também criar louvor com o texto extraído (se houver)
        </label>
      </div>
      <div class="su-dialog__actions">
        <button type="button" class="su-btn su-btn--secondary" data-act="cancel">Cancelar</button>
        <button type="button" class="su-btn su-btn--primary" data-act="import" disabled>${opts.targetItemId ? 'Substituir slides' : 'Adicionar à ordem'}</button>
      </div>
    </div>`;

  document.body.appendChild(overlay);
  requestAnimationFrame(() => overlay.classList.add('is-visible'));

  let parsed = null;
  const status = overlay.querySelector('#su-pptx-status');
  const preview = overlay.querySelector('#su-pptx-preview');
  const importBtn = overlay.querySelector('[data-act="import"]');
  const fileInput = overlay.querySelector('#su-pptx-file');

  overlay.querySelector('[data-act="cancel"]').onclick = () => closeOverlay(overlay);
  overlay.onclick = (e) => { if (e.target === overlay) closeOverlay(overlay); };

  fileInput.onchange = async () => {
    const file = fileInput.files?.[0];
    parsed = null;
    importBtn.disabled = true;
    preview.hidden = true;
    preview.innerHTML = '';
    if (!file) {
      status.textContent = 'Nenhum arquivo selecionado.';
      return;
    }
    status.textContent = `Lendo ${file.name}…`;
    try {
      parsed = await parsePptxFile(file);
      status.textContent = `${parsed.slideCount} slide(s) em “${parsed.title}”.`;
      const withImg = parsed.slides.filter((s) => s.image).length;
      const withText = parsed.slides.filter((s) => s.text).length;
      preview.hidden = false;
      preview.innerHTML = `
        <ul class="su-tools-slide-list">
          ${parsed.slides.slice(0, 12).map((s) => `
            <li>
              <strong>${esc(s.title)}</strong>
              <small>${s.image ? 'imagem' : 'texto'}${s.text ? ` · ${esc(String(s.text).slice(0, 60))}` : ''}</small>
            </li>`).join('')}
          ${parsed.slides.length > 12 ? `<li><small>… e mais ${parsed.slides.length - 12}</small></li>` : ''}
        </ul>
        <p class="su-tools-meta">${withImg} com imagem · ${withText} com texto</p>`;
      importBtn.disabled = false;
    } catch (err) {
      status.textContent = err?.message || 'Falha ao ler o PPTX';
      app.toast?.(status.textContent, 'warn');
    }
  };

  importBtn.onclick = async () => {
    if (!parsed) return;
    importBtn.disabled = true;
    status.textContent = 'Importando slides para a mídia e ordem…';
    try {
      const deckSlides = [];
      for (let i = 0; i < parsed.slides.length; i += 1) {
        const s = parsed.slides[i];
        status.textContent = `Importando slide ${i + 1}/${parsed.slides.length}…`;
        if (s.image?.bytes?.length) {
          const file = new File([s.image.bytes], s.image.name || `pptx-slide-${i + 1}.png`, {
            type: s.image.mime || 'image/png',
          });
          const media = await saveMediaFile(file, { category: 'image' });
          deckSlides.push({
            kind: 'media',
            mediaId: media.id,
            title: s.title,
            text: s.text || '',
          });
        } else {
          deckSlides.push({
            kind: 'text',
            title: s.title,
            text: s.text || s.title || `Slide ${i + 1}`,
          });
        }
      }

      const payload = {
        title: `Apresentação: ${parsed.title}`,
        slides: deckSlides,
        source: 'pptx',
        sourceName: parsed.title,
      };
      const target = opts.targetItemId
        ? app.program?.items?.find((it) => it.id === opts.targetItemId)
        : null;
      if (target) {
        target.title = payload.title;
        target.data = { ...(target.data || {}), slides: deckSlides, source: 'pptx', sourceName: parsed.title };
        const idx = app.program.items.findIndex((it) => it.id === target.id);
        if (idx >= 0) await app.program.rebuildItem?.(idx);
        await app.persistProgram?.();
        app.toast?.(`Apresentação atualizada: ${deckSlides.length} slides`, 'success');
      } else {
        const item = createProgramItem('deck', payload);
        await app.insertProgramItem?.(item);
        await app.persistProgram?.();
        app.toast?.(`Apresentação com ${deckSlides.length} slides na ordem`, 'success');
      }

      const alsoLyrics = overlay.querySelector('#su-pptx-lyrics')?.checked;
      if (alsoLyrics && parsed.allText?.trim()) {
        const song = normalizeSong({
          id: generateId(),
          title: parsed.title,
          lyrics: parsed.allText,
          tags: ['importado', 'pptx'],
          category: 'Livre',
        });
        await saveWorshipSong(song, { allowDuplicate: true });
        app.toast?.('Louvor criado com o texto do PPTX', 'success');
      }

      app.setView?.('live');
      app.render?.();
      closeOverlay(overlay);
    } catch (err) {
      status.textContent = err?.message || 'Falha na importação';
      app.toast?.(status.textContent, 'error');
      importBtn.disabled = false;
    }
  };
}
