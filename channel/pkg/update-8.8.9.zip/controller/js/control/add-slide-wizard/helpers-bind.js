﻿import { createProgramItem, SLIDE_TYPE_OPTIONS, PARTICIPATION_KINDS } from '../../program/programa-templates.js';
import {
  DEFAULT_WELCOME_NORMAL,
  WELCOME_PRESETS,
  resolveWelcomePreset,
  resolveWelcomeBackground,
} from '../../slides/welcome-config.js';
import { welcomeBackgroundPickerHtml, bindWelcomeBackgroundPicker, resolveMediaSrc } from '../../core/media-url.js';
import { getVersions, getPassage } from '../../bible/bible-service.js';
import { BOOKS } from '../../bible/books-map.js';
import { bindBibleRefPicker } from '../../bible/bible-picker.js';
import { loadAmbientTracks } from '../../core/ambient-audio.js';
import { getAllSongs, getSong } from '../../core/store.js';
import {
  messageModeOptionsHtml,
  applyMessageWizardModeUI,
  getMessageMode,
} from '../../slides/message-display-modes.js';
import {
  esc,
  escAttr,
  TYPE_LABELS,
  wizardBodyForType,
  biblePickerHtml,
  FREE_INTENTS,
  freeIntentPanelHtml,
} from './helpers-forms.js';

export async function wireBiblePicker(modal, app, initial = {}) {
  const root = modal.querySelector('.wizard-body');
  const picker = await bindBibleRefPicker(root, {
    versionSel: root.querySelector('#wiz-ver'),
    bookSel: root.querySelector('#wiz-book'),
    chapterSel: root.querySelector('#wiz-ch'),
    verseStartSel: root.querySelector('#wiz-vs'),
    verseEndSel: root.querySelector('#wiz-ve'),
    hintEl: root.querySelector('#wiz-bounds'),
    initial,
  });
  modal._biblePicker = picker;
  return picker;
}


export function wireBibleLoadButtons(modal, app) {

  const root = modal.querySelector('.wizard-body');
  const loadPassage = async (joinAsExcerpt = false) => {
    const ref = modal._biblePicker?.readValues?.();
    if (!ref?.book) {
      app.toast('Selecione livro e versículos');
      return null;
    }
    try {
      const passage = await getPassage(ref.version, ref.book, ref.chapter, ref.verseStart, ref.verseEnd);
      const refEl = root.querySelector('#wiz-ref-override');
      const excerptEl = root.querySelector('#wiz-excerpt');
      if (refEl) refEl.value = passage.reference.replace(':', '.');
      if (joinAsExcerpt && excerptEl) {
        excerptEl.value = passage.verses.map((v) => v.text).join(' ');
      }
      return passage;
    } catch (err) {
      app.toast(`Erro: ${err.message}`);
      return null;
    }
  };

  root.querySelector('#wiz-load-excerpt')?.addEventListener('click', async () => {
    await loadPassage(true);
    app.toast('Trecho carregado — edite se quiser só uma parte');
  });

  root.querySelector('#wiz-load-full')?.addEventListener('click', async () => {
    const mode = root.querySelector('#wiz-bible-mode')?.value;
    if (mode === 'verses') {
      const p = await loadPassage(false);
      if (p) app.toast(`${p.verses.length} versículo(s) — serão exibidos na projeção`);
      return;
    }
    await loadPassage(true);
    app.toast('Versículos completos colados no trecho — ajuste se necessário');
  });
}

export function wireBibleModeToggle(modal) {
  const root = modal.querySelector('.wizard-body');
  const modeSel = root.querySelector('#wiz-bible-mode');
  if (!modeSel) return;
  const excerptWrap = root.querySelector('#wiz-excerpt-wrap');
  const versesHint = root.querySelector('#wiz-verses-hint');
  const ilExtra = root.querySelector('#wiz-bible-il-extra');
  const update = () => {
    const m = modeSel.value;
    if (excerptWrap) excerptWrap.style.display = (m === 'verses' || m === 'interlinear') ? 'none' : '';
    if (versesHint) versesHint.style.display = m === 'verses' ? '' : 'none';
    if (ilExtra) ilExtra.style.display = m === 'interlinear' ? '' : 'none';
  };
  modeSel.addEventListener('change', update);
  update();
}

export function readBibleFromPicker(modal, wholeChapter = false) {
  const ref = modal._biblePicker?.readValues?.() || {};
  return {
    ...ref,
    verseStart: wholeChapter ? 1 : ref.verseStart,
    verseEnd: wholeChapter ? 999 : ref.verseEnd,
    wholeChapter,
  };
}

/**
 * Filtra <select> reconstruindo options (option.hidden é ignorado no Chrome).
 * Snapshot na 1ª ligação; preserva valor selecionado se ainda bater.
 */
export function wireSongFilter(selectEl, filterEl) {
  if (!selectEl || !filterEl) return;
  if (!selectEl._songFilterSnapshot) {
    selectEl._songFilterSnapshot = [...selectEl.options].map((opt) => ({
      value: opt.value,
      text: opt.textContent,
      search: (opt.dataset.search || opt.textContent || '').toLowerCase(),
      disabled: opt.disabled,
      isPlaceholder: !opt.value,
    }));
  }
  const apply = () => {
    const q = filterEl.value.trim().toLowerCase();
    const prev = selectEl.value;
    const snap = selectEl._songFilterSnapshot || [];
    const placeholder = snap.find((o) => o.isPlaceholder);
    const matches = snap.filter((o) => {
      if (o.isPlaceholder) return false;
      return !q || o.search.includes(q);
    });
    selectEl.replaceChildren();
    if (placeholder) {
      const ph = new Option(placeholder.text, placeholder.value, false, false);
      ph.disabled = !!placeholder.disabled;
      selectEl.add(ph);
    }
    for (const o of matches) {
      const opt = new Option(o.text, o.value, false, false);
      if (o.search) opt.dataset.search = o.search;
      selectEl.add(opt);
    }
    if (prev && matches.some((o) => o.value === prev)) {
      selectEl.value = prev;
    } else if (placeholder) {
      selectEl.value = '';
    }
  };
  filterEl.addEventListener('input', apply);
  filterEl.addEventListener('search', apply);
}

export async function refreshSongPreview(modal, app) {
  const preview = modal.querySelector('#wiz-song-preview');
  const songId = modal.querySelector('#wiz-song')?.value;
  const titleInput = modal.querySelector('#wiz-item-title');
  const sync = modal.querySelector('#wiz-sync-song-title')?.checked;
  if (!preview) return;
  if (!songId) {
    preview.innerHTML = '<p class="form-hint">Selecione um louvor para ler a letra aqui.</p>';
    return;
  }
  preview.innerHTML = '<p class="form-hint">Carregando letra…</p>';
  try {
    const song = await getSong(songId);
    if (!song) {
      preview.innerHTML = '<p class="form-hint">Louvor não encontrado.</p>';
      return;
    }
    if (sync && titleInput) titleInput.value = song.title || titleInput.value;
    const lyrics = String(song.lyrics || '').trim();
    const lines = lyrics ? lyrics.split(/\r?\n/).slice(0, 16) : [];
    const more = lyrics && lyrics.split(/\r?\n/).length > 16;
    preview.innerHTML = `
      <div class="wiz-song-preview-head">
        <strong>${esc(song.title || 'Sem título')}</strong>
        ${song.artist ? `<span class="form-hint">${esc(song.artist)}</span>` : ''}
      </div>
      ${lines.length
        ? `<pre class="wiz-song-lyrics">${esc(lines.join('\n'))}${more ? '\n…' : ''}</pre>`
        : '<p class="form-hint">Este louvor ainda não tem letra cadastrada — edite na aba Louvores.</p>'}`;
  } catch (err) {
    preview.innerHTML = `<p class="form-hint">Erro ao carregar: ${esc(err.message || '')}</p>`;
  }
}

export function wireSongBrowser(modal, app) {
  const selectEl = modal.querySelector('#wiz-song');
  const filterEl = modal.querySelector('#wiz-song-filter');
  if (!selectEl) return;
  wireSongFilter(selectEl, filterEl);
  selectEl.addEventListener('change', () => refreshSongPreview(modal, app));
  modal.querySelector('#wiz-sync-song-title')?.addEventListener('change', () => {
    if (modal.querySelector('#wiz-sync-song-title')?.checked) refreshSongPreview(modal, app);
  });
}

export function wirePresetToTitle(modal, presetId) {
  const preset = modal.querySelector(presetId);
  const title = modal.querySelector('#wiz-item-title');
  if (!preset || !title) return;
  preset.addEventListener('change', () => {
    if (preset.value) title.value = preset.value;
  });
}

export function parseAnnounceLines(raw) {
  return (raw || '').split('\n').map((l) => l.trim()).filter(Boolean).map((line) => {
    try {
      const emoji = line.match(/^(\p{Extended_Pictographic}(?:\uFE0F|\u200D\p{Extended_Pictographic})*)\s+(.+)$/u);
      if (emoji) return { icon: emoji[1], text: emoji[2] };
    } catch { /* WebView antigo sem \p{} */ }
    const symbol = line.match(/^([^\sA-Za-zÀ-ÿ0-9]{1,4})\s+(.+)$/);
    if (symbol) return { icon: symbol[1], text: symbol[2] };
    return { icon: '•', text: line };
  });
}

export function collectLyricsData(modal) {
  const itemTitle = modal.querySelector('#wiz-item-title')?.value?.trim();
  const songId = modal.querySelector('#wiz-song')?.value || null;
  return { title: itemTitle || 'Louvor', songId };
}

export function collectBibleResponsiveData(modal, titleFallback) {
  const itemTitle = modal.querySelector('#wiz-item-title')?.value?.trim();
  const ref = readBibleFromPicker(modal);
  return {
    title: itemTitle || titleFallback,
    bible: ref,
  };
}

export function collectBibleData(modal, titleFallback) {
  const itemTitle = modal.querySelector('#wiz-item-title')?.value?.trim();
  const mode = modal.querySelector('#wiz-bible-mode')?.value || 'reference';
  const ref = readBibleFromPicker(modal);
  const layout = modal.querySelector('#wiz-bible-il-layout')?.value || 'study';
  const bible = {
    ...ref,
    displayMode: mode,
    chapterOnly: mode === 'chapter',
    showText: mode !== 'reference' && mode !== 'chapter',
    verseStart: mode === 'chapter' ? 1 : ref.verseStart,
    verseEnd: mode === 'chapter' ? 999 : ref.verseEnd,
    referenceOverride: modal.querySelector('#wiz-ref-override')?.value?.trim() || '',
    excerptText: mode === 'excerpt' ? modal.querySelector('#wiz-excerpt')?.value?.trim() || '' : '',
  };
  if (mode === 'interlinear') {
    bible.originalLang = modal.querySelector('#wiz-bible-original-lang')?.value || 'he';
    bible.interlinear = {
      layout,
      chunkMode: layout === 'word' ? 'word' : 'verse',
      show: {
        original: modal.querySelector('#wiz-il-show-original')?.checked !== false,
        gloss: modal.querySelector('#wiz-il-show-gloss')?.checked !== false,
        translation: modal.querySelector('#wiz-il-show-translation')?.checked !== false,
        strong: modal.querySelector('#wiz-il-show-strong')?.checked === true,
        morph: false,
        description: false,
      },
    };
  }
  return {
    title: itemTitle || titleFallback,
    bible,
    openDesigner: modal.querySelector('#wiz-open-designer')?.checked === true,
  };
}

export function collectInterlinearData(modal) {
  const itemTitle = modal.querySelector('#wiz-item-title')?.value?.trim();
  const ref = readBibleFromPicker(modal);
  const layout = modal.querySelector('#wiz-bible-il-layout')?.value || 'study';
  return {
    title: itemTitle || 'Estudo Interlinear',
    bible: {
      ...ref,
      displayMode: 'interlinear',
      showText: true,
      originalLang: modal.querySelector('#wiz-bible-original-lang')?.value || 'he',
      interlinear: {
        layout,
        chunkMode: layout === 'word' ? 'word' : 'verse',
        show: {
          original: modal.querySelector('#wiz-il-show-original')?.checked !== false,
          gloss: modal.querySelector('#wiz-il-show-gloss')?.checked !== false,
          translation: modal.querySelector('#wiz-il-show-translation')?.checked !== false,
          strong: modal.querySelector('#wiz-il-show-strong')?.checked === true,
          morph: false,
          description: false,
        },
      },
    },
  };
}

export function collectWizardData(type, modal, app) {
  const itemTitle = modal.querySelector('#wiz-item-title')?.value?.trim();
  switch (type) {
    case 'welcome': {
      const presetId = modal.querySelector('#wiz-welcome-preset')?.value || 'domingo';
      const base = resolveWelcomePreset(presetId, app?.prefs?.church || {});
      const bgMediaId = modal.querySelector('#wiz-w-bg-media-id')?.value?.trim() || '';
      const bgResolved = resolveWelcomeBackground(
        {
          bgMediaId,
          bgMedia: '',
          bgKind: modal.querySelector('#wiz-w-bg-kind')?.value || 'image',
        },
        app?.mediaList || [],
        app?.prefs?.church || {},
      );
      return {
        title: itemTitle || 'Boas-Vindas',
        ...base,
        welcomePreset: presetId,
        years: modal.querySelector('#wiz-years')?.value?.trim() || base.years || DEFAULT_WELCOME_NORMAL.years,
        theme: modal.querySelector('#wiz-theme')?.value?.trim() || '',
        subtitle: modal.querySelector('#wiz-subtitle')?.value?.trim() || '',
        badge: modal.querySelector('#wiz-badge')?.value?.trim() || '',
        dateLine: modal.querySelector('#wiz-date')?.value?.trim() || '',
        extraLine: modal.querySelector('#wiz-extra')?.value?.trim() || '',
        layout: base.layout,
        animation: base.animation,
        showLogo: modal.querySelector('#wiz-w-show-logo')?.checked !== false,
        showChurchName: modal.querySelector('#wiz-w-show-church')?.checked !== false,
        showBadge: modal.querySelector('#wiz-w-show-badge')?.checked !== false,
        showTheme: modal.querySelector('#wiz-w-show-theme')?.checked !== false,
        showExtra: modal.querySelector('#wiz-w-show-extra')?.checked !== false,
        logoPosition: modal.querySelector('#wiz-w-show-logo')?.checked === false ? 'hidden' : (base.logoPosition || 'top'),
        bgMediaId: bgResolved.bgMediaId,
        bgMedia: bgResolved.bgMedia,
        bgKind: bgResolved.bgKind,
        openDesigner: modal.querySelector('#wiz-open-designer')?.checked === true,
      };
    }
    case 'bible-intro': {
      const ref = readBibleFromPicker(modal);
      const mode = modal.querySelector('#wiz-bible-mode')?.value || 'excerpt';
      return {
        title: itemTitle || 'Introito Bíblico',
        bible: {
          ...ref,
          displayMode: mode,
          showText: mode !== 'reference',
          referenceOverride: modal.querySelector('#wiz-ref-override')?.value?.trim() || '',
          excerptText: mode === 'excerpt' ? modal.querySelector('#wiz-excerpt')?.value?.trim() || '' : '',
        },
        openDesigner: modal.querySelector('#wiz-open-designer')?.checked === true,
      };
    }
    case 'prayer':
      return { title: itemTitle || 'Oração' };
    case 'section':
      return { title: itemTitle || 'Momento' };
    case 'participation': {
      const kind = modal.querySelector('#wiz-part-kind')?.value || 'musical';
      const kindDef = PARTICIPATION_KINDS.find((k) => k.id === kind);
      return {
        title: itemTitle || undefined,
        participationKind: kind,
        participationLabel: kind === 'outro'
          ? (modal.querySelector('#wiz-part-label')?.value?.trim() || 'Participação')
          : (kindDef?.label || 'Participação'),
        participantName: modal.querySelector('#wiz-part-name')?.value?.trim() || '',
        songId: kind === 'musical' ? (modal.querySelector('#wiz-part-song')?.value || null) : null,
        extraText: modal.querySelector('#wiz-part-extra')?.value?.trim() || '',
      };
    }
    case 'lyrics':
      return collectLyricsData(modal);
    case 'bible':
      return collectBibleData(modal, 'Leitura Bíblica');
    case 'bible-interlinear':
      return collectInterlinearData(modal);
    case 'bible-responsive':
      return collectBibleResponsiveData(modal, 'Leitura Responsiva');
    case 'message': {
      const mode = modal.querySelector('#wiz-msg-mode')?.value || 'ref_pregador';
      const modeDef = getMessageMode(mode);
      const whole = modeDef.wholeChapter;
      const bible = modeDef.showReference ? readBibleFromPicker(modal, whole) : {};
      const referenceOverride = modal.querySelector('#wiz-ref-override')?.value?.trim() || '';
      return {
        title: itemTitle || modal.querySelector('#wiz-theme')?.value?.trim() || 'Mensagem Bíblica',
        messageMode: mode,
        theme: modeDef.showTheme ? (modal.querySelector('#wiz-theme')?.value?.trim() || '') : '',
        mottoText: modeDef.showMottoSection ? (modal.querySelector('#wiz-excerpt')?.value?.trim() || '') : '',
        showMotto: modal.querySelector('#wiz-msg-show-motto')?.checked !== false,
        referenceOverride,
        bible: modeDef.showReference ? { ...bible, referenceOverride } : {},
        preacher: modal.querySelector('#wiz-preacher')?.value?.trim() || '',
        preacherFrom: modal.querySelector('#wiz-from')?.value?.trim() || '',
        showPreacherPhoto: false,
      };
    }
    case 'communion':
      return {
        title: itemTitle || 'Ceia do Senhor',
        showElements: modal.querySelector('#wiz-comm-elements')?.checked !== false,
        useCommunionTheme: modal.querySelector('#wiz-comm-theme')?.checked !== false,
      };
    case 'announcements':
      return {
        title: itemTitle || 'Comunicados',
        items: parseAnnounceLines(modal.querySelector('#wiz-items')?.value),
      };
    case 'theme':
      return {
        title: itemTitle || 'Tema / Divisa',
        theme: modal.querySelector('#wiz-theme')?.value?.trim() || '',
        motto: modal.querySelector('#wiz-motto')?.value?.trim() || '',
        mottoText: modal.querySelector('#wiz-motto-text')?.value?.trim() || '',
      };
    case 'media':
      return {
        title: itemTitle || 'Imagem / Vídeo',
        mediaId: modal.querySelector('#wiz-media')?.value || null,
        loop: modal.querySelector('#wiz-media-loop')?.checked !== false,
      };
    case 'media-audio':
      return {
        title: itemTitle || 'Áudio no programa',
        screenTitle: modal.querySelector('#wiz-screen-title')?.value?.trim() || itemTitle || 'Áudio',
        audioPath: modal.querySelector('#wiz-audio')?.value || null,
        loop: modal.querySelector('#wiz-audio-loop')?.checked === true,
        hint: modal.querySelector('#wiz-audio-hint')?.value?.trim() || '',
      };
    case 'offering':
      return {
        title: itemTitle || 'Oferta / Dízimo',
        screenTitle: modal.querySelector('#wiz-screen-title')?.value?.trim() || 'Oferta e Dízimos',
        subtitle: modal.querySelector('#wiz-offering-sub')?.value?.trim() || '',
        verse: modal.querySelector('#wiz-offering-verse')?.value?.trim() || '',
        template: modal.querySelector('#wiz-offering-tpl')?.value || 'classic',
      };
    case 'countdown': {
      const minsRaw = modal.querySelector('#wiz-pause-min')?.value;
      const durationMin = minsRaw ? Number(minsRaw) : null;
      return {
        title: itemTitle || 'Pausa',
        screenTitle: modal.querySelector('#wiz-screen-title')?.value?.trim() || 'Pausa',
        note: modal.querySelector('#wiz-pause-note')?.value?.trim() || '',
        durationMin: Number.isFinite(durationMin) && durationMin > 0 ? durationMin : null,
      };
    }
    case 'custom': {
      const intent = modal.querySelector('#wiz-free-intent')?.value || 'texto';
      if (intent === 'louvor') {
        return { _createAs: 'lyrics', ...collectLyricsData(modal) };
      }
      if (intent === 'biblia') {
        return { _createAs: 'bible', ...collectBibleData(modal, 'Leitura Bíblica') };
      }
      if (intent === 'oracao') {
        const screen = modal.querySelector('#wiz-prayer-screen')?.value?.trim();
        return { _createAs: 'prayer', title: screen || itemTitle || 'Oração' };
      }
      if (intent === 'titulo') {
        const screen = modal.querySelector('#wiz-title-only')?.value?.trim();
        return { _createAs: 'section', title: screen || itemTitle || 'Momento' };
      }
      if (intent === 'comunicado') {
        return {
          _createAs: 'announcements',
          title: itemTitle || 'Comunicados',
          items: parseAnnounceLines(modal.querySelector('#wiz-free-ann')?.value),
        };
      }
      if (intent === 'designer') {
        return {
          _createAs: 'custom',
          title: itemTitle || 'Slide Designer',
          text: '',
          screenTitle: itemTitle || '',
          openDesigner: true,
          backgroundPreset: 'dark',
          align: 'center',
        };
      }
      const screenTitle = modal.querySelector('#wiz-screen-title')?.value?.trim();
      return {
        _createAs: 'custom',
        title: itemTitle || 'Slide livre',
        text: modal.querySelector('#wiz-text')?.value?.trim() || '',
        screenTitle: screenTitle || '',
        subtitle: modal.querySelector('#wiz-subtitle')?.value?.trim() || '',
        align: modal.querySelector('#wiz-align')?.value || 'center',
        backgroundPreset: modal.querySelector('#wiz-bg-preset')?.value || 'dark',
        openDesigner: modal.querySelector('#wiz-open-designer')?.checked === true,
      };
    }
    default:
      return {
        title: itemTitle || TYPE_LABELS[type] || 'Item',
        text: modal.querySelector('#wiz-text')?.value?.trim() || '',
      };
  }
}

export const WIZARD_LEADS = {
  welcome: 'Escolha o modelo (domingo, oração, missões…). Aniversário só para esse evento.',
  'bible-intro': 'Referência e trecho do introito. Ajuste tipografia no inspetor.',
  prayer: 'Título em tela cheia para o momento de oração.',
  section: 'Marcador de momento na ordem (Louvor, Palavra, Ceia…).',
  participation: 'Nome, tipo e música (se musical).',
  lyrics: 'Busque o louvor, leia a letra e adicione à ordem.',
  bible: 'Referência e modo de leitura na projeção.',
  'bible-interlinear': 'Original + significado Strong + tradução — aula e exegese.',
  'bible-responsive': 'Passagem alternada: dirigente (ímpar) e congregação (par).',
  message: 'Tema, referência e pregador — essencial da Mensagem Bíblica.',
  communion: 'Fases da Ceia do Senhor prontas; edite textos no inspetor.',
  announcements: 'Um aviso por linha. Emoji opcional no início.',
  theme: 'Tema e divisa bíblica na projeção.',
  media: 'Imagem ou vídeo da biblioteca de mídia.',
  'media-audio': 'Escolha o áudio que toca neste item da ordem.',
  offering: 'Slide de Oferta / Dízimo com título e texto opcional.',
  countdown: 'Pausa na ordem. Contagem pré-culto continua na barra ⏱.',
  deck: 'Importe um .pptx — os slides entram na ordem e avançam com ← →.',
  custom: 'Escolha o estilo — os campos mudam. Louvor mostra a biblioteca de letras.',
};

export async function ensureSongs(app) {
  try {
    // Sempre recarrega: músicas novas na aba Louvores devem aparecer na busca
    app.songs = await getAllSongs();
  } catch {
    app.songs = app.songs || [];
  }
}

export function wireFreeIntent(modal, app) {
  const sel = modal.querySelector('#wiz-free-intent');
  const hint = modal.querySelector('#wiz-free-hint');
  const mount = modal.querySelector('#wiz-free-mount');
  if (!sel || !mount) return;

  const apply = async () => {
    const intent = sel.value;
    const def = FREE_INTENTS.find((i) => i.id === intent);
    if (hint && def) hint.textContent = def.hint;
    modal._biblePicker = null;
    mount.innerHTML = freeIntentPanelHtml(intent, app);
    if (intent === 'louvor') {
      wireSongBrowser(modal, app);
    }
    if (intent === 'biblia') {
      await wireBiblePicker(modal, app);
      wireBibleModeToggle(modal);
      wireBibleLoadButtons(modal, app);
    }
  };

  sel.addEventListener('change', () => { apply(); });
  apply();
}


