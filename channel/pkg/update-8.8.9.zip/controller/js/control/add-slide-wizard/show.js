import {
  esc,
  escAttr,
  wizardBodyForType,
  wireBiblePicker,
  wireBibleModeToggle,
  wireBibleLoadButtons,
  wireSongBrowser,
  wireSongFilter,
  wirePresetToTitle,
  wireFreeIntent,
  applyMessageWizardModeUI,
  biblePickerHtml,
  ensureSongs,
  TYPE_LABELS,
  WIZARD_LEADS,
  WELCOME_PRESETS,
  collectWizardData,
  loadAmbientTracks,
  getMessageMode,
  resolveWelcomePreset,
  bindWelcomeBackgroundPicker,
} from './helpers.js';
import { createProgramItem } from '../../program/programa-templates.js';

export async function showAddSlideWizard(app, slideType) {
  if (!app.cultoIndex?.activeId) {
    app.toast('Selecione ou crie um culto no Calendário');
    return;
  }
  app.closeModal?.();

  if (slideType === 'media-audio') {
    try {
      app.ambientTracks = await loadAmbientTracks();
    } catch {
      app.ambientTracks = app.ambientTracks || [];
    }
  }

  if (slideType === 'lyrics' || slideType === 'custom' || slideType === 'participation') {
    await ensureSongs(app);
  }

  if (slideType === 'deck' || slideType === 'pptx') {
    void import('../tools/pptx-import-ui.js').then(({ openPowerpointImport }) => {
      openPowerpointImport(app);
    });
    return;
  }

  const label = TYPE_LABELS[slideType] || slideType;
  const lead = WIZARD_LEADS[slideType] || 'Configure o essencial. Depois refine no inspetor Editar Item.';
  const modal = document.createElement('div');
  modal.className = 'somosum-modal';
  modal.innerHTML = `
    <div class="somosum-modal-backdrop"></div>
    <div class="somosum-modal-card wizard-card wizard-card-wide">
      <h3>Adicionar: ${esc(label)}</h3>
      <p class="form-hint wizard-lead">${esc(lead)}</p>
      <div class="wizard-body">${wizardBodyForType(slideType, app)}</div>
      <div class="somosum-modal-actions">
        <button type="button" class="btn btn-primary" id="wiz-add">Adicionar à ordem</button>
        <button type="button" class="btn btn-secondary" id="wiz-cancel">Cancelar</button>
      </div>
    </div>`;
  document.body.appendChild(modal);

  const bibleTypes = ['bible-intro', 'bible', 'bible-interlinear', 'bible-responsive', 'message'];
  let biblePickerReady = Promise.resolve();
  if (bibleTypes.includes(slideType)) {
    biblePickerReady = wireBiblePicker(modal, app).then(() => {
      if (slideType !== 'message') {
        wireBibleModeToggle(modal);
        wireBibleLoadButtons(modal, app);
      } else {
        wireBibleLoadButtons(modal, app);
      }
      if (slideType === 'message') {
        const modeSel = modal.querySelector('#wiz-msg-mode');
        const updateMsgMode = async () => {
          if (!modeSel) return;
          const m = modeSel.value;
          applyMessageWizardModeUI(modal, m);
          const modeDef = getMessageMode(m);
          if (modeDef.showReference) {
            const bibleWrap = modal.querySelector('#wiz-bible-wrap');
            if (bibleWrap) {
              bibleWrap.innerHTML = biblePickerHtml('wiz', {}, app.prefs.bibleVersion || 'naa');
              await wireBiblePicker(modal, app);
            }
          }
        };
        modeSel?.addEventListener('change', () => updateMsgMode());
        applyMessageWizardModeUI(modal, modeSel?.value || 'ref_pregador');
      }
    });
  }

  if (slideType === 'lyrics') {
    wireSongBrowser(modal, app);
  }

  if (slideType === 'offering') {
    const TPL = {
      classic: { title: 'Oferta e Dízimos', sub: 'Com alegria e gratidão', verse: 'Cada um contribua segundo o propósito do seu coração. (2 Co 9:7)' },
      dizimo: { title: 'Dízimo', sub: 'Honra ao Senhor com os teus bens', verse: 'Honra ao Senhor com os teus bens e com as primícias de toda a tua renda. (Pv 3:9)' },
      oferta: { title: 'Oferta', sub: 'Uma semeadura com fé', verse: 'Dai, e ser-vos-á dado. (Lc 6:38)' },
      mission: { title: 'Oferta Missionária', sub: 'Para que o Evangelho alcance mais vidas', verse: 'Ide por todo o mundo e pregai o evangelho. (Mc 16:15)' },
      sacred: { title: 'Contribuição', sub: 'Adoração também é ofertar', verse: 'Deus ama a quem dá com alegria. (2 Co 9:7)' },
      compact: { title: 'PIX', sub: '', verse: '' },
      split: { title: 'Oferta e Dízimos', sub: 'Escaneie o QR ou use a chave', verse: '' },
    };
    const applyTpl = () => {
      const id = modal.querySelector('#wiz-offering-tpl')?.value || 'classic';
      const t = TPL[id] || TPL.classic;
      const title = modal.querySelector('#wiz-screen-title');
      const sub = modal.querySelector('#wiz-offering-sub');
      const verse = modal.querySelector('#wiz-offering-verse');
      const itemTitle = modal.querySelector('#wiz-item-title');
      if (title) title.value = t.title;
      if (sub) sub.value = t.sub;
      if (verse) verse.value = t.verse;
      if (itemTitle && (!itemTitle.value || /oferta|d[ií]zimo/i.test(itemTitle.value))) {
        itemTitle.value = t.title;
      }
    };
    modal.querySelector('#wiz-offering-tpl')?.addEventListener('change', applyTpl);
  }

  if (slideType === 'custom') {
    wireFreeIntent(modal, app);
  }

  if (slideType === 'participation') {
    const kindSel = modal.querySelector('#wiz-part-kind');
    const songWrap = modal.querySelector('#wiz-part-song-wrap');
    const labelWrap = modal.querySelector('#wiz-part-label-wrap');
    const updatePart = () => {
      const k = kindSel?.value || 'musical';
      if (songWrap) songWrap.style.display = k === 'musical' ? '' : 'none';
      if (labelWrap) labelWrap.style.display = k === 'outro' ? '' : 'none';
    };
    kindSel?.addEventListener('change', updatePart);
    updatePart();
    wireSongFilter(
      modal.querySelector('#wiz-part-song'),
      modal.querySelector('#wiz-part-song-filter')
    );
  }

  wirePresetToTitle(modal, '#wiz-prayer-preset');
  wirePresetToTitle(modal, '#wiz-section-preset');

  if (slideType === 'welcome') {
    const presetSel = modal.querySelector('#wiz-welcome-preset');
    const hint = modal.querySelector('#wiz-welcome-preset-hint');
    const church = app.prefs?.church || {};
    const fill = (id) => {
      const p = WELCOME_PRESETS.find((x) => x.id === id) || WELCOME_PRESETS[0];
      const w = resolveWelcomePreset(p.id, church);
      if (hint) hint.textContent = p.description;
      const set = (sel, val) => { const el = modal.querySelector(sel); if (el) el.value = val || ''; };
      set('#wiz-badge', w.badge);
      set('#wiz-years', w.years);
      set('#wiz-theme', w.theme);
      set('#wiz-date', w.dateLine);
      set('#wiz-subtitle', w.subtitle);
      set('#wiz-extra', w.extraLine);
    };
    presetSel?.addEventListener('change', () => fill(presetSel.value));
    bindWelcomeBackgroundPicker(modal, {
      onChange: ({ label, kind }) => {
        const hint = modal.querySelector('[data-welcome-bg-label]');
        if (hint && label) {
          const kindNote = kind === 'video' ? ' (vídeo)' : '';
          hint.innerHTML = `Fundo atual: <strong>${label}${kindNote}</strong>`;
        }
      },
    });
  }

  modal.querySelector('.somosum-modal-backdrop').onclick = () => app.closeModal?.();
  modal.querySelector('#wiz-cancel').onclick = () => app.closeModal?.();
  modal.querySelector('#wiz-add').onclick = async () => {
    const btn = modal.querySelector('#wiz-add');
    btn.disabled = true;
    try {
      if (bibleTypes.includes(slideType)) {
        await biblePickerReady;
        const ref = modal._biblePicker?.readValues?.() || {};
        const needsPassage = slideType !== 'message' || !!modal.querySelector('#wiz-bible-wrap')?.offsetParent;
        if (needsPassage && slideType !== 'message' && !ref.book) {
          btn.disabled = false;
          app.toast('Escolha o livro e o capítulo da passagem', 'warn');
          return;
        }
      }
      const data = collectWizardData(slideType, modal, app);
      const createType = data._createAs || slideType;
      delete data._createAs;
      const openDesigner = !!data.openDesigner;
      delete data.openDesigner;

      const item = createProgramItem(createType, data);
      app.closeModal?.();
      await app.insertProgramItem(item);

      const createdLabel = TYPE_LABELS[createType] || label;
      if (openDesigner || (slideType === 'custom' && createType === 'custom' && modal.querySelector('#wiz-free-intent')?.value === 'designer')) {
        const idx = app.program.items.findIndex((it) => it.id === item.id);
        app._designerPendingItem = idx >= 0 ? idx : app.program.items.length - 1;
        app.view = 'designer';
        app.renderNav?.();
        app.renderView?.();
        app.toast(`${createdLabel} adicionado — personalize no Designer`);
        return;
      }
      app.toast(`${createdLabel} adicionado — refine no inspetor à direita`);
    } catch (err) {
      btn.disabled = false;
      app.toast(`Erro: ${err.message}`);
    }
  };
}

