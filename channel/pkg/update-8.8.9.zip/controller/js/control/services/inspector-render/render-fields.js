import { BOOKS } from '../../../bible/books-map.js';
import { getVersions, resolveBibleDisplayMode } from '../../../bible/bible-service.js';
import { isIntroitoProgramItem, isBibleInspectorType } from '../../../program/programa-templates.js';
import { hasDesignerSkin } from '../../../designer/content-bindings.js';
import { esc, escAttr } from '../../../core/render-engine/index.js';
import { loadAmbientTracks } from '../../../core/ambient-audio.js';
import {
  messageModeOptionsHtml,
  resolveShowPreacherPhoto,
  getMessageMode,
} from '../../../slides/message-display-modes.js';

export const inspectorRenderFields = {
  buildInspectorFieldsHtml(item, meta) {
    let fields = '';
if (item.slideType === 'lyrics') {
  fields = this.lyricsInspectorFieldsHtml(item);
}

if (item.slideType === 'participation') {
  fields = this.participationInspectorFieldsHtml(item);
}

if (isBibleInspectorType(item.slideType)) {
  const b = item.bible || {};
  const mode = item.slideType === 'bible-responsive'
    ? 'verses'
    : (item.slideType === 'bible-interlinear' ? 'interlinear' : resolveBibleDisplayMode(b));
  const isIntro = isIntroitoProgramItem(item);
  const refLayout = b.refLayout || (mode === 'reference' || mode === 'chapter' ? 'stacked' : 'inline');
  fields = `
    ${isIntro ? '<p class="form-hint inspector-introito-badge">Introito bíblico — referência + trecho na projeção</p>' : ''}
    ${hasDesignerSkin(item) ? '<p class="form-hint" style="color:var(--color-gold)">Design personalizado ativo — edite o versículo aqui; layout permanece. Use ◫ Designer para mudar fundo, tipografia e molduras.</p>' : ''}
    <section class="insp-card">
      <header class="insp-card-head">
        <h3 class="form-section-title">Passagem</h3>
        <p class="form-hint insp-card-lead">${item.slideType === 'bible-responsive'
          ? 'Leitura responsiva: versículos ímpares no dirigente e pares na congregação. Escolha a passagem aqui.'
          : 'Escolha versão, livro e intervalo. Modos “só referência” e “capítulo” não projetam o texto dos versículos.'}</p>
      </header>
      <div class="form-block"><label>Versão</label>
        <select id="insp-ver">${getVersions().map((v) => `<option value="${v.key}" ${(b.version || this.prefs.bibleVersion) === v.key ? 'selected' : ''}>${v.abbrev} — ${v.name}</option>`).join('')}</select>
      </div>
      <div class="form-block"><label>Livro</label>
        <select id="insp-book">${BOOKS.map((bk) => `<option value="${bk.abbrev}" ${b.book === bk.abbrev ? 'selected' : ''}>${bk.name}</option>`).join('')}</select>
      </div>
      <div class="form-block form-row-2 bible-ref-grid">
        <div><label>Cap.</label><select id="insp-ch" title="Capítulo"><option value="">…</option></select></div>
        <div id="insp-bible-vs-wrap"><label>De</label><select id="insp-vs" title="Versículo início"><option value="">—</option></select></div>
        <div id="insp-bible-ve-wrap"><label>Até</label><select id="insp-ve" title="Versículo fim"><option value="">—</option></select></div>
      </div>
      <p class="form-hint" id="insp-bible-bounds">Carregando limites do livro...</p>
    </section>
    <section class="insp-card">
      <header class="insp-card-head">
        <h3 class="form-section-title">Modo na projeção</h3>
      </header>
      <div class="form-block">
        <select id="insp-bible-mode" ${item.slideType === 'bible' ? '' : 'disabled'}>
          <option value="reference" ${mode === 'reference' ? 'selected' : ''}>Só referência (Livro Cap:Versículos)</option>
          <option value="chapter" ${mode === 'chapter' ? 'selected' : ''}>Capítulo completo (ex.: Números 2) — sem texto</option>
          <option value="verses" ${mode === 'verses' ? 'selected' : ''}>Texto completo do(s) versículo(s)</option>
          <option value="excerpt" ${mode === 'excerpt' ? 'selected' : ''}>Introito — referência + trecho</option>
          <option value="interlinear" ${mode === 'interlinear' ? 'selected' : ''}>Interlinear (PT + original)</option>
        </select>
        <p class="form-hint">Capítulo completo mostra só o livro e o número do capítulo (ajuda a localizar na Bíblia, sem projetar o texto).</p>
      </div>
      <div class="form-row-2 bible-display-options" id="insp-bible-ref-opts">
        <label class="checkbox-inline"><input type="checkbox" id="insp-bible-show-version" ${b.showVersion !== false ? 'checked' : ''} /> Mostrar tradução (NAA, ARA…)</label>
        <div class="form-block" style="margin:0" id="insp-bible-ref-style-wrap">
          <label>Separador</label>
          <select id="insp-bible-ref-style">
            <option value="colon" ${(b.refStyle || 'colon') === 'colon' ? 'selected' : ''}>23:1-6</option>
            <option value="dot" ${b.refStyle === 'dot' ? 'selected' : ''}>23.1-6</option>
          </select>
        </div>
      </div>
      <div class="form-block" id="insp-bible-ref-layout-wrap" style="${(mode === 'reference' || mode === 'chapter') ? '' : 'display:none'}">
        <label>Layout da referência</label>
        <select id="insp-bible-ref-layout">
          <option value="stacked" ${refLayout === 'stacked' ? 'selected' : ''}>Empilhado — LIVRO / CAPÍTULO (ou CAP:VERS)</option>
          <option value="inline" ${refLayout === 'inline' ? 'selected' : ''}>Uma linha — Números 2 · Salmos 23:1-6</option>
        </select>
        <p class="form-hint">Empilhado: livro em cima e capítulo/versículos embaixo — fácil de localizar.</p>
      </div>
      <div class="form-block bible-dual-options">
        <label class="checkbox-inline"><input type="checkbox" id="insp-bible-dual" ${b.dual ? 'checked' : ''} /> Projeção dual (2 traduções)</label>
        <div id="insp-bible-dual-wrap" style="${b.dual ? '' : 'display:none'}">
          <label>Segunda versão</label>
          <select id="insp-ver-b">${getVersions().map((v) => `<option value="${v.key}" ${(b.versionB || '') === v.key ? 'selected' : ''}>${v.abbrev} — ${v.name}</option>`).join('')}</select>
        </div>
      </div>
      <div class="bible-ref-preview-wrap">
        <span class="bible-ref-preview-label">Prévia na tela</span>
        <p class="bible-ref-preview" id="insp-bible-ref-preview">—</p>
      </div>
      <div class="bible-history-wrap">
        <span class="bible-ref-preview-label">Leituras deste culto</span>
        <ul class="bible-history-list" id="insp-bible-history"><li class="muted">—</li></ul>
      </div>
    </section>
    <div class="form-block" id="insp-bible-interlinear-wrap" style="${mode === 'interlinear' ? '' : 'display:none'}">
      <label>Idioma original</label>
      <select id="insp-bible-original-lang">
        <option value="he" ${(b.originalLang || 'he') === 'he' ? 'selected' : ''}>Hebraico (AT)</option>
        <option value="grc" ${b.originalLang === 'grc' ? 'selected' : ''}>Grego (NT)</option>
      </select>
      <p class="form-hint">AT: palavra a palavra com Strong. NT: texto grego tokenizado (sem Strong por palavra).</p>
      <label>Layout de estudo</label>
      <select id="insp-bible-il-layout">
        <option value="study" ${(b.interlinear?.layout || 'study') === 'study' ? 'selected' : ''}>Estudo (Strong → original → sentido → PT)</option>
        <option value="classic" ${b.interlinear?.layout === 'classic' ? 'selected' : ''}>Clássico (PT + original)</option>
        <option value="word" ${b.interlinear?.layout === 'word' || b.interlinear?.chunkMode === 'word' ? 'selected' : ''}>Palavra a palavra (slides numerados)</option>
        <option value="verse-only" ${b.interlinear?.layout === 'verse-only' ? 'selected' : ''}>Só original</option>
      </select>
      <div class="il-show-toggles">
        <label class="checkbox-inline"><input type="checkbox" id="insp-bible-il-show-original" ${(b.interlinear?.show?.original !== false) ? 'checked' : ''} /> Original</label>
        <label class="checkbox-inline"><input type="checkbox" id="insp-bible-il-show-strong" ${(b.interlinear?.show?.strong !== false) ? 'checked' : ''} /> Strong</label>
        <label class="checkbox-inline"><input type="checkbox" id="insp-bible-il-show-gloss" ${(b.interlinear?.show?.gloss !== false) ? 'checked' : ''} /> Significado</label>
        <label class="checkbox-inline"><input type="checkbox" id="insp-bible-il-show-translation" ${(b.interlinear?.show?.translation !== false) ? 'checked' : ''} /> Tradução PT</label>
        <label class="checkbox-inline"><input type="checkbox" id="insp-bible-il-show-morph" ${b.interlinear?.show?.morph ? 'checked' : ''} /> Morfologia</label>
        <label class="checkbox-inline"><input type="checkbox" id="insp-bible-il-show-desc" ${b.interlinear?.show?.description ? 'checked' : ''} /> Descrição Strong</label>
      </div>
      <div class="form-row-2">
        <div class="form-block" style="margin:0">
          <label>Versos / slide</label>
          <input type="number" id="insp-bible-il-vps" min="1" max="4" value="${b.interlinear?.versesPerSlide || 1}" />
        </div>
        <div class="form-block" style="margin:0">
          <label>Palavras / slide</label>
          <input type="number" id="insp-bible-il-wps" min="1" max="8" value="${b.interlinear?.wordsPerSlide || 1}" />
        </div>
      </div>
      <button type="button" class="btn btn-secondary btn-sm" id="insp-bible-il-study-slides" style="margin-top:.5rem">Gerar slides de estudo (palavra a palavra)</button>
    </div>
    <div id="insp-bible-excerpt-wrap" style="${mode === 'excerpt' ? '' : 'display:none'}">
      <div class="form-block">
        <label>Referência na tela</label>
        <input id="insp-bible-ref-override" value="${escAttr(b.referenceOverride || '')}" placeholder="João 17.11 (NAA)" />
        <p class="form-hint">Deixe vazio para gerar automaticamente a partir do livro/capítulo/versículo.</p>
      </div>
      <div class="form-block">
        <label>Trecho bíblico</label>
        <textarea id="insp-bible-excerpt" rows="3" placeholder="...para que sejam um, assim como somos um">${esc(b.excerptText || '')}</textarea>
      </div>
      <button type="button" class="btn btn-secondary" id="insp-bible-load-excerpt">Carregar trecho do versículo</button>
    </div>`;
}

if (item.slideType === 'announcements') {
  const items = (item.data?.items || []).map((i) => (typeof i === 'string' ? { icon: '•', text: i } : i));
  const lines = items.map((i) => `${i.icon || '•'} ${i.text}`).join('\n');
  fields = `
    <div class="form-block"><label>Título</label><input id="insp-ann-title" value="${escAttr(item.data?.title || item.title || 'Comunicados')}" /></div>
    <div class="form-block"><label>Avisos (um por linha — opcional: emoji no início)</label>
      <textarea id="insp-ann-items" rows="8" placeholder="📅 Reunião — sábado 19h">${esc(lines)}</textarea>
    </div>
    <p class="form-hint">Mais de 4 avisos são divididos em vários slides automaticamente.</p>`;
}

if (item.slideType === 'custom') {
  const skinned = hasDesignerSkin(item);
  fields += `
    <div class="form-block"><label>Título na projeção</label>
      <input id="insp-screen-title" value="${escAttr(item.data?.title || '')}" placeholder="Se vazio, usa o nome do item" /></div>
    <div class="form-block"><label>Subtítulo</label>
      <input id="insp-custom-sub" value="${escAttr(item.data?.subtitle || '')}" /></div>
    <div class="form-block"><label>Texto / conteúdo</label>
      <textarea id="insp-text" rows="6" placeholder="Opcional — se vazio, só título na tela">${esc(item.data?.text ?? '')}</textarea></div>
    <div class="form-row-2">
      <div class="form-block"><label>Alinhamento</label>
        <select id="insp-custom-align" ${skinned ? 'disabled title="Com design personalizado, use o Designer"' : ''}>
          <option value="center" ${(item.data?.align || 'center') === 'center' ? 'selected' : ''}>Centro</option>
          <option value="left" ${item.data?.align === 'left' ? 'selected' : ''}>Esquerda</option>
          <option value="right" ${item.data?.align === 'right' ? 'selected' : ''}>Direita</option>
        </select>
      </div>
      <div class="form-block"><label>Fundo</label>
        <select id="insp-custom-bg">
          ${['dark', 'gold', 'theme', 'bible', 'communion'].map((p) =>
            `<option value="${p}" ${(item.data?.backgroundPreset || item.data?.background?.preset || item.data?.designer?.background?.preset || 'dark') === p ? 'selected' : ''}>${p === 'dark' ? 'Escuro' : p === 'gold' ? 'Dourado' : p === 'theme' ? 'Tema' : p === 'bible' ? 'Bíblia' : 'Ceia'}</option>`
          ).join('')}
        </select>
      </div>
    </div>
    ${skinned
      ? `<p class="form-hint" style="color:var(--color-gold)">Design personalizado: título → papel «título», subtítulo → «legenda», texto → «corpo»; fundo do inspetor atualiza o gradiente. Tipografia/molduras → Designer.</p>`
      : `<p class="form-hint">Layout com camadas e tipografia livre → botão Designer abaixo.</p>`}`;
}

if (item.slideType === 'prayer') {
  const prayerText = item.data?.text || '';
  fields += `
    <div class="form-block"><label>Texto (opcional)</label>
      <textarea id="insp-prayer-text" rows="3" placeholder="Ex.: Momento de oração…">${esc(prayerText)}</textarea>
      <p class="form-hint">Título em destaque; o texto abaixo usa tamanho/cor «Texto» do estilo.</p>
    </div>`;
}

if (item.slideType === 'message') {
  const d = item.data || {};
  const mode = d.messageMode || 'ref_pregador';
  const modeDef = getMessageMode(mode);
  const b = item.bible || {};
  const st = d.style || {};
  const showPreacherPhoto = resolveShowPreacherPhoto(d);
  const photoOpts = this.mediaList
    .filter((m) => m.kind === 'image')
    .map((m) =>
      `<option value="${m.id}" ${d.preacherPhotoId === m.id ? 'selected' : ''}>${esc(m.name)}</option>`
    )
    .join('');
  const showVersion = d.showVersion !== false;
  const refStyle = d.refStyle || b.refStyle || 'colon';
  const mottoText = d.mottoText || '';
  fields = `
    ${this.slideBackgroundInspectorHtml(item, { idPrefix: 'insp-msg' })}
    <div class="form-block"><label>Modo de exibição</label>
      <select id="insp-msg-mode">${messageModeOptionsHtml(mode)}</select>
      <p class="form-hint" id="insp-msg-mode-hint">${modeDef.hint}</p>
    </div>
    <div id="insp-msg-theme-wrap" style="${modeDef.showTheme ? '' : 'display:none'}">
      <div class="form-block"><label>Tema</label><input id="insp-msg-theme" value="${escAttr(d.theme || '')}" placeholder="Ex.: SOMOS UM" /></div>
    </div>
    <div id="insp-msg-bible-wrap" style="${modeDef.showReference ? '' : 'display:none'}">
      <h3 class="form-section-title">Referência bíblica</h3>
      <div class="form-block"><label>Versão bíblica</label>
        <select id="insp-msg-ver">${getVersions().map((v) =>
          `<option value="${v.key}" ${(b.version || this.prefs.bibleVersion || 'naa') === v.key ? 'selected' : ''}>${v.abbrev} — ${v.name}</option>`
        ).join('')}</select>
      </div>
      <div class="form-block"><label>Livro</label>
        <select id="insp-msg-book">${BOOKS.map((bk) =>
          `<option value="${bk.abbrev}" ${b.book === bk.abbrev ? 'selected' : ''}>${bk.name}</option>`
        ).join('')}</select>
      </div>
      <div class="form-block form-row-2 bible-ref-grid">
        <div><label>Cap.</label><select id="insp-msg-ch" title="Capítulo"><option value="">…</option></select></div>
        <div id="insp-msg-verses-wrap" style="${modeDef.wholeChapter ? 'display:none' : ''}">
          <label>De</label><select id="insp-msg-vs" title="Versículo início"><option value="">—</option></select>
        </div>
        <div id="insp-msg-verse-end-wrap" style="${modeDef.wholeChapter ? 'display:none' : ''}">
          <label>Até</label><select id="insp-msg-ve" title="Versículo fim"><option value="">—</option></select>
        </div>
      </div>
      <p class="form-hint" id="insp-msg-bible-bounds">Carregando limites do livro...</p>
      <div class="form-row-2 bible-display-options">
        <label class="checkbox-inline"><input type="checkbox" id="insp-msg-show-version" ${showVersion ? 'checked' : ''} /> Mostrar tradução na referência</label>
        <div class="form-block" style="margin:0">
          <label>Formato da referência</label>
          <select id="insp-msg-ref-style">
            <option value="colon" ${refStyle === 'colon' ? 'selected' : ''}>João 1:11</option>
            <option value="dot" ${refStyle === 'dot' ? 'selected' : ''}>João 1.11</option>
          </select>
        </div>
      </div>
      <div class="form-block">
        <label>Referência personalizada na tela</label>
        <input id="insp-msg-ref-override" value="${escAttr(d.referenceOverride || b.referenceOverride || '')}" placeholder="Deixe vazio para gerar automaticamente" />
      </div>
      <div class="bible-ref-preview-wrap">
        <span class="bible-ref-preview-label">Prévia da referência</span>
        <p class="bible-ref-preview" id="insp-msg-ref-preview">—</p>
      </div>
      <div id="insp-msg-motto-wrap" style="${modeDef.showMottoSection ? '' : 'display:none'}">
      <h3 class="form-section-title" style="margin-top:1rem">Trecho / Divisa do versículo</h3>
      <p class="form-hint">Carregue o versículo e edite só a parte que quer na projeção — como a divisa do culto abaixo do tema.</p>
      <div class="form-block">
        <label>Trecho bíblico (divisa)</label>
        <textarea id="insp-msg-motto" rows="3" placeholder="...para que sejam um, assim como somos um">${esc(mottoText)}</textarea>
      </div>
      <div class="form-block" style="display:flex;gap:.4rem;flex-wrap:wrap;margin-bottom:.5rem">
        <button type="button" class="btn btn-secondary btn-sm" id="insp-msg-load-verse">Carregar versículo completo</button>
        <button type="button" class="btn btn-secondary btn-sm" id="insp-msg-trim-excerpt">Recortar trecho selecionado</button>
        <button type="button" class="btn btn-secondary btn-sm" id="insp-msg-use-excerpt-theme">Usar trecho como tema</button>
      </div>
      <label class="checkbox-inline"><input type="checkbox" id="insp-msg-show-motto" ${d.showMotto !== false ? 'checked' : ''} /> Mostrar trecho/divisa na projeção</label>
      </div>
    </div>
    <div id="insp-msg-preacher-wrap" style="${modeDef.showPreacher ? '' : 'display:none'}">
    <div class="form-row-2">
      <div class="form-block"><label>Pregador</label><input id="insp-msg-preacher" value="${escAttr(d.preacher || '')}" /></div>
      <div class="form-block"><label>De onde é</label><input id="insp-msg-from" value="${escAttr(d.preacherFrom || '')}" placeholder="Ex.: CBA Central" /></div>
    </div>
    <div class="form-block" id="insp-msg-photo-wrap">
      <label>Foto do pregador</label>
      <div class="msg-photo-picker">
        <div class="msg-photo-preview" id="insp-msg-photo-preview"><span class="msg-photo-placeholder">Sem foto</span></div>
        <div class="msg-photo-controls">
          <select id="insp-msg-photo"><option value="">— Sem foto —</option>${photoOpts}</select>
          <button type="button" class="btn btn-secondary btn-sm" id="insp-msg-goto-media">+ Enviar em Mídia</button>
        </div>
      </div>
      <label class="checkbox-inline" style="display:block;margin-top:.5rem">
        <input type="checkbox" id="insp-msg-show-photo" ${showPreacherPhoto ? 'checked' : ''} /> Mostrar foto na projeção
      </label>
      <p class="form-hint">Desmarque para exibir só o nome do pregador, sem círculo vazio na tela.</p>
    </div>
    </div>
    <div class="form-block">
      <label>Script / teleprompter (Stage)</label>
      <textarea id="insp-msg-script" rows="8" placeholder="Use **pausa pesada** ou **texto** para ênfase.&#10;• Ponto de outline&#10;>> Ritmo lento">${esc(d.scriptRaw || '')}</textarea>
      <p class="form-hint">Visível no Stage em modo Teleprompter. Não altera a projeção da congregação.</p>
    </div>
    <h3 class="form-section-title">Layout na projeção</h3>
    <div class="form-row-2">
      <div class="form-block"><label>Disposição</label>
        <select id="insp-msg-layout">
          <option value="balanced" ${(st.layout || 'balanced') === 'balanced' ? 'selected' : ''}>Lado a lado (equilibrado)</option>
          <option value="card-large" ${st.layout === 'card-large' ? 'selected' : ''}>Lado a lado (card grande)</option>
          <option value="center" ${st.layout === 'center' ? 'selected' : ''}>Centralizado</option>
        </select>
      </div>
      <div class="form-block"><label>Alinhamento do texto</label>
        <select id="insp-msg-align">
          <option value="left" ${(st.align || 'left') === 'left' ? 'selected' : ''}>Esquerda</option>
          <option value="center" ${st.align === 'center' ? 'selected' : ''}>Centro</option>
          <option value="right" ${st.align === 'right' ? 'selected' : ''}>Direita</option>
        </select>
      </div>
    </div>
    <div class="form-row-2">
      <div class="form-block"><label>Largura na tela (%)</label>
        <input type="number" id="insp-msg-content-width" min="70" max="100" step="1" value="${st.contentWidth ?? 94}" />
      </div>
      <div class="form-block" id="insp-msg-card-width-block" style="${showPreacherPhoto ? '' : 'display:none'}"><label>Largura do card pregador (%)</label>
        <input type="number" id="insp-msg-card-width" min="24" max="48" step="1" value="${st.cardWidth ?? 36}" />
      </div>
      <div class="form-block"><label>Rótulos</label>
        <label class="checkbox-inline"><input type="checkbox" id="insp-msg-labels" ${st.showLabels !== false ? 'checked' : ''} /> Mostrar Tema / Divisa / Referência / Pregador</label>
      </div>
    </div>
    <h3 class="form-section-title">Tamanhos na projeção</h3>
    <div class="font-toolbar font-toolbar-wrap">
      <div class="font-toolbar-group" id="insp-msg-theme-size-group" style="${modeDef.showTheme ? '' : 'display:none'}">
        <span class="font-toolbar-label">Tema</span>
        <button type="button" class="btn btn-secondary btn-icon font-size-btn" id="insp-msg-font-minus">A−</button>
        <span class="font-size-readout" id="insp-msg-font-readout">${st.fontSize ?? 80}</span>
        <button type="button" class="btn btn-secondary btn-icon font-size-btn" id="insp-msg-font-plus">A+</button>
      </div>
      <div class="font-toolbar-group" id="insp-msg-ref-size-group" style="${modeDef.showReference ? '' : 'display:none'}">
        <span class="font-toolbar-label">Referência</span>
        <button type="button" class="btn btn-secondary btn-icon font-size-btn" id="insp-msg-ref-minus">A−</button>
        <span class="font-size-readout" id="insp-msg-ref-readout">${st.refSize ?? st.textSize ?? 34}</span>
        <button type="button" class="btn btn-secondary btn-icon font-size-btn" id="insp-msg-ref-plus">A+</button>
      </div>
      <div class="font-toolbar-group" id="insp-msg-preacher-size-group">
        <span class="font-toolbar-label">Pregador</span>
        <button type="button" class="btn btn-secondary btn-icon font-size-btn" id="insp-msg-preacher-minus">A−</button>
        <span class="font-size-readout" id="insp-msg-preacher-readout">${st.preacherSize ?? 32}</span>
        <button type="button" class="btn btn-secondary btn-icon font-size-btn" id="insp-msg-preacher-plus">A+</button>
      </div>
      <div class="font-toolbar-group" id="insp-msg-from-size-group">
        <span class="font-toolbar-label">De onde é</span>
        <button type="button" class="btn btn-secondary btn-icon font-size-btn" id="insp-msg-from-size-minus">A−</button>
        <span class="font-size-readout" id="insp-msg-from-readout">${st.fromSize ?? 22}</span>
        <button type="button" class="btn btn-secondary btn-icon font-size-btn" id="insp-msg-from-size-plus">A+</button>
      </div>
      <div class="font-toolbar-group" id="insp-msg-photo-size-wrap" style="${showPreacherPhoto ? '' : 'display:none'}">
        <span class="font-toolbar-label">Foto</span>
        <button type="button" class="btn btn-secondary btn-icon font-size-btn" id="insp-msg-photo-minus">−</button>
        <span class="font-size-readout" id="insp-msg-photo-readout">${st.photoSize ?? 200}</span>
        <button type="button" class="btn btn-secondary btn-icon font-size-btn" id="insp-msg-photo-plus">+</button>
      </div>
      <div class="font-toolbar-group" id="insp-msg-motto-size-group" style="${modeDef.showMottoSection ? '' : 'display:none'}">
        <span class="font-toolbar-label">Divisa</span>
        <button type="button" class="btn btn-secondary btn-icon font-size-btn" id="insp-msg-motto-minus">A−</button>
        <span class="font-size-readout" id="insp-msg-motto-readout">${st.mottoSize ?? st.textSize ?? 30}</span>
        <button type="button" class="btn btn-secondary btn-icon font-size-btn" id="insp-msg-motto-plus">A+</button>
      </div>
      <div class="font-toolbar-group" id="insp-msg-text-size-group" style="${modeDef.showReference ? '' : 'display:none'}">
        <span class="font-toolbar-label">Texto ref.</span>
        <button type="button" class="btn btn-secondary btn-icon font-size-btn" id="insp-msg-text-minus">A−</button>
        <span class="font-size-readout" id="insp-msg-text-readout">${st.textSize ?? 30}</span>
        <button type="button" class="btn btn-secondary btn-icon font-size-btn" id="insp-msg-text-plus">A+</button>
      </div>
      <div class="font-toolbar-group font-picker-group">
        <span class="font-toolbar-label">Fonte</span>
        ${this.fontPickerPairHtml(st.fontFamily || '', st, { familyId: 'insp-msg-font', variantId: 'insp-msg-font-variant' })}
      </div>
      <div class="font-toolbar-group">
        <span class="font-toolbar-label">Texto tema</span>
        <select id="insp-msg-transform">
          <option value="none" ${(st.textTransform || 'none') === 'none' ? 'selected' : ''}>Normal</option>
          <option value="uppercase" ${st.textTransform === 'uppercase' ? 'selected' : ''}>MAIÚSCULAS</option>
          <option value="lowercase" ${st.textTransform === 'lowercase' ? 'selected' : ''}>minúsculas</option>
          <option value="capitalize" ${st.textTransform === 'capitalize' ? 'selected' : ''}>Primeira Maiúscula</option>
        </select>
      </div>
      ${this.slideStyleColorControlsHtml(st, { showRef: true, idPrefix: 'insp-msg' })}
      ${this.slideLegibilityControlsHtml(st, { idPrefix: 'insp-msg' })}
    </div>`;
}

if (item.slideType === 'welcome') {
  fields = this.welcomeInspectorHtml(item);
}

if (item.slideType === 'section') {
  fields = `
    <div class="form-block"><label>Título na tela</label><input id="insp-sec-title" value="${escAttr(item.data?.title || item.title)}" /></div>
    <p class="form-hint">Na projeção aparece apenas o título em tela cheia.</p>`;
}

if (item.slideType === 'theme') {
  fields = `
    <div class="form-block"><label>Divisa ref.</label><input id="insp-th-motto" value="${escAttr(item.data?.motto || '')}" /></div>
    <div class="form-block"><label>Texto divisa</label><textarea id="insp-th-text">${esc(item.data?.mottoText || '')}</textarea></div>
    <div class="form-block"><label>Tema</label><input id="insp-th-theme" value="${escAttr(item.data?.theme || '')}" /></div>`;
}

if (item.slideType === 'deck') {
  const n = Array.isArray(item.data?.slides) ? item.data.slides.length : 0;
  fields = `
    <p class="form-hint">${n
      ? `${n} slide(s) nesta apresentação. Use ← → no Ao vivo para avançar.`
      : 'Ainda sem slides. Importe um arquivo .pptx — não precisa do PowerPoint instalado.'}</p>
    <button type="button" class="btn btn-secondary" id="insp-deck-import">Importar PowerPoint…</button>
    <p class="form-hint">Também em Ferramentas → PowerPoint.</p>`;
}

if (item.slideType === 'communion') {
  fields = this.communionInspectorHtml?.(item) || '';
}

if (item.slideType === 'media') {
  const opts = this.mediaList.map((m) =>
    `<option value="${m.id}" ${item.mediaId === m.id ? 'selected' : ''}>${esc(m.name)} (${m.kind})</option>`
  ).join('');
  fields = `
    <div class="form-block"><label>Arquivo de mídia</label>
      <select id="insp-media"><option value="">— Selecionar —</option>${opts}</select>
    </div>
    <div class="form-block"><label><input type="checkbox" id="insp-media-loop" ${item.data?.loop !== false ? 'checked' : ''} /> Repetir vídeo (loop)</label></div>`;
}

if (item.slideType === 'media-audio') {
  if (!this.ambientTracks?.length && !this._audioTracksLoading) {
    this._audioTracksLoading = true;
    const itemId = item.id;
    loadAmbientTracks().then((tracks) => {
      this.ambientTracks = tracks;
      this._audioTracksLoading = false;
      if (this._inspectorItemRef?.id === itemId) this.renderInspector(meta);
    }).catch(() => { this._audioTracksLoading = false; });
  }
  const tracks = this.ambientTracks || [];
  const cur = item.data?.audioPath || '';
  const opts = tracks.map((t) =>
    `<option value="${escAttr(t.path)}" ${cur === t.path ? 'selected' : ''}>${esc(t.fileName || t.path)}</option>`
  ).join('');
  fields = `
    <div class="form-block"><label>Título na tela</label>
      <input id="insp-audio-screen" value="${escAttr(item.data?.screenTitle || item.title || '')}" /></div>
    <div class="form-block"><label>Arquivo de áudio</label>
      <select id="insp-audio-path"><option value="">— Selecionar —</option>${opts}</select>
    </div>
    <label class="checkbox-inline"><input type="checkbox" id="insp-audio-loop" ${item.data?.loop ? 'checked' : ''} /> Repetir em loop</label>
    <div class="form-block"><label>Nota / duração</label>
      <input id="insp-audio-hint" value="${escAttr(item.data?.hint || item.placeholder || '')}" placeholder="Ex.: ~5 min" /></div>
    <p class="form-hint">Lista de <code>audio/</code>. Atualize em Mídia → Áudio se faltar arquivo.</p>`;
}

if (item.slideType === 'offering') {
  const tpl = item.data?.template || 'classic';
  fields = `
    <div class="form-block"><label>Template visual</label>
      <select id="insp-offering-tpl" class="su-select">
        <option value="classic" ${tpl === 'classic' ? 'selected' : ''}>Clássico</option>
        <option value="dizimo" ${tpl === 'dizimo' ? 'selected' : ''}>Dízimo</option>
        <option value="oferta" ${tpl === 'oferta' ? 'selected' : ''}>Oferta</option>
        <option value="mission" ${tpl === 'mission' ? 'selected' : ''}>Missões</option>
        <option value="sacred" ${tpl === 'sacred' ? 'selected' : ''}>Sagrado</option>
        <option value="compact" ${tpl === 'compact' ? 'selected' : ''}>Compacto</option>
        <option value="split" ${tpl === 'split' ? 'selected' : ''}>Dividido</option>
      </select>
      <p class="form-hint">QR PIX: plugin Oferta PIX em Ajustes → Plugins (onde aparecer + discreto nas Boas-vindas).</p>
    </div>
    <div class="form-block"><label>Título na projeção</label>
      <input id="insp-offering-title" value="${escAttr(item.data?.title || item.title || 'Oferta e Dízimos')}" /></div>
    <div class="form-block"><label>Subtítulo</label>
      <input id="insp-offering-sub" value="${escAttr(item.data?.subtitle || '')}" /></div>
    <div class="form-block"><label>Versículo / texto</label>
      <textarea id="insp-offering-verse" rows="3">${esc(item.data?.verse || '')}</textarea></div>`;
}

if (item.slideType === 'countdown') {
  fields = `
    <div class="form-block"><label>Título na projeção</label>
      <input id="insp-pause-title" value="${escAttr(item.data?.title || item.title || 'Pausa')}" /></div>
    <div class="form-block"><label>Duração (minutos)</label>
      <input type="number" id="insp-pause-min" min="1" max="60" value="${escAttr(item.data?.durationMin || '')}" /></div>
    <div class="form-block"><label>Nota</label>
      <input id="insp-pause-note" value="${escAttr(item.data?.note || '')}" /></div>
    <p class="form-hint">Contagem regressiva pré-culto: use o botão <strong>Pré-culto</strong> na barra superior.</p>`;
}

if (!['lyrics', 'message', 'welcome'].includes(item.slideType)) {
  fields += this.transitionOverrideHtml?.(item) || '';
  if (isBibleInspectorType(item.slideType)) {
    fields += this.bibleStyleControlsHtml(item, item.slideType === 'bible-responsive'
      ? 'verses'
      : resolveBibleDisplayMode(item.bible || {}));
  } else {
    fields += this.programStyleControlsHtml(item);
  }
}
    return fields;
  },

  buildRehearsalBlockHtml(item) {
    const rehearsal = item.rehearsal || {};
    const rehearsalMin = rehearsal.estimatedSec ? Math.round((Number(rehearsal.estimatedSec) || 0) / 60) : '';
    return `
<section class="insp-card inspector-rehearsal-block">
  <header class="insp-card-head">
    <h3 class="form-section-title">Ensaio</h3>
  </header>
  <label class="checkbox-inline"><input type="checkbox" id="insp-rehearsal-marked" ${rehearsal.marked ? 'checked' : ''} /> Marcar item para ensaio</label>
  <div class="form-row-2" style="margin-top:.5rem">
    <div>
      <label>Tempo estimado (min)</label>
      <input type="number" id="insp-rehearsal-min" min="0" max="240" step="1" value="${escAttr(rehearsalMin)}" />
    </div>
    <div>
      <label>Nota do operador</label>
      <textarea id="insp-rehearsal-note" rows="3" placeholder="Ex.: conferir tom, microfone, entrada">${esc(rehearsal.operatorNote || '')}</textarea>
    </div>
  </div>
  <button type="button" class="btn btn-secondary btn-sm" id="insp-rehearsal-save" style="margin-top:.55rem">Salvar ensaio</button>
</section>`;
  },
};
