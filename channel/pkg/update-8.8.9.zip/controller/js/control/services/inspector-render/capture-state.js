import { isIntroitoProgramItem, isBibleInspectorType } from '../../../program/programa-templates.js';
import { parseAnnounceLines } from '../../add-slide-wizard/helpers-bind.js';

export const inspectorCaptureState = {
readRehearsalInspectorData(el) {
  const minutes = Number(el.querySelector('#insp-rehearsal-min')?.value);
  const estimatedSec = Number.isFinite(minutes) && minutes > 0 ? Math.round(minutes * 60) : null;
  const operatorNote = el.querySelector('#insp-rehearsal-note')?.value?.trim() || '';
  const marked = el.querySelector('#insp-rehearsal-marked')?.checked === true;
  const data = { marked, operatorNote, estimatedSec };
  return (marked || operatorNote || estimatedSec) ? data : null;
},

captureInspectorItemState(meta, el) {
  const item = this.program.items[meta.itemIndex];
  if (!item || !el || el._suppressInspectorSync) return false;
  // Bíblia: tipografia/cores podem sincronizar mesmo se o picker ainda não montou
  const bibleStyleOnly = isBibleInspectorType(item.slideType) && !el._biblePickerReady && !item.bible?.book;

  const rawTitle = el.querySelector('#insp-title')?.value?.trim() || '';
  if (item.slideType === 'section') {
    const title = el.querySelector('#insp-sec-title')?.value?.trim() || item.title;
    item.data = { ...(item.data || {}), title };
    item.title = title;
  } else if (item.slideType === 'prayer') {
    item.title = rawTitle || item.title;
    const prayerText = el.querySelector('#insp-prayer-text')?.value;
    item.data = {
      ...(item.data || {}),
      title: item.title,
      ...(prayerText !== undefined ? { text: prayerText.trim() } : {}),
    };
  } else if (item.slideType !== 'message' && !bibleStyleOnly) {
    item.title = rawTitle || item.title;
  }
  if (item.slideType === 'lyrics') {
    const prevSongId = item.songId || null;
    let songId = el.querySelector('#insp-song')?.value || null;
    if (!songId) {
      const q = el.querySelector('#insp-song-q')?.value?.trim() || '';
      if (q && Array.isArray(this.songs)) {
        const hits = this.songs.filter((s) => {
          const label = `${s.title || ''}${s.artist ? ` — ${s.artist}` : ''}`.toLowerCase();
          return label.includes(q.toLowerCase()) || (s.title || '').toLowerCase() === q.toLowerCase();
        });
        if (hits.length === 1) songId = hits[0].id;
        else {
          const exact = this.songs.find((s) => {
            const label = `${s.title || ''}${s.artist ? ` — ${s.artist}` : ''}`;
            return label === q;
          });
          if (exact) songId = exact.id;
        }
      }
    }
    if (songId) {
      item.songId = songId;
      const song = this.songs?.find((s) => s.id === songId);
      if (song?.title) item.title = song.title;
    }
    if (prevSongId && prevSongId !== item.songId) this.program.clearSongCache?.(prevSongId);
    item.data = {
      ...(item.data || {}),
      lyricsStyle: this.readLyricsInspectorStyle(el),
      lyricsFx: this.readLyricsInspectorFx(el),
    };
  }
  if (item.slideType === 'participation') {
    Object.assign(item.data || (item.data = {}), this.readParticipationInspectorData(el, item));
    item.songId = item.data.songId || null;
    const name = item.data.participantName || '';
    const label = item.data.participationLabel || 'Participação';
    if (name) item.title = `${label} — ${name}`;
  }
  if (item.slideType === 'message') {
    const fields = this.readMessageInspectorData(el, item);
    item.data = {
      ...(item.data || {}),
      messageMode: fields.messageMode,
      theme: fields.theme,
      mottoText: fields.mottoText,
      showMotto: fields.showMotto,
      referenceOverride: fields.referenceOverride,
      refStyle: fields.refStyle,
      reference: '',
      preacher: fields.preacher,
      preacherFrom: fields.preacherFrom,
      preacherPhotoId: fields.preacherPhotoId,
      showPreacherPhoto: fields.showPreacherPhoto,
      showVersion: fields.showVersion,
      scriptRaw: fields.scriptRaw,
      scriptBlocks: fields.scriptBlocks,
      style: fields.style,
    };
    item.bible = fields.bible;
    item.title = this.resolveMessageItemTitle(item, rawTitle || item.title);
  }
  if (isBibleInspectorType(item.slideType) && !bibleStyleOnly) {
    item.bible = { ...(item.bible || {}), ...this.readBibleInspectorData(el, item.bible) };
    if (item.bible.displayMode !== 'excerpt') item.bible.referenceOverride = '';
    const prevData = item.data || {};
    item.data = {
      ...prevData,
      style: this.readProgramStyle(el, item.slideType === 'bible-responsive' ? 'bible-responsive' : 'bible', prevData.style),
      designer: prevData.designer,
      layers: prevData.layers,
      background: prevData.background ?? prevData.designer?.background,
      templateId: prevData.templateId,
      previewDataUrl: prevData.previewDataUrl,
    };
    if (isIntroitoProgramItem(item)) {
      item.data.role = 'introito';
    }
  } else if (isBibleInspectorType(item.slideType) && bibleStyleOnly) {
    item.data = {
      ...(item.data || {}),
      style: this.readProgramStyle(el, item.slideType === 'bible-responsive' ? 'bible-responsive' : 'bible', item.data?.style),
    };
  }
  const trLive = el.querySelector('#insp-transition')?.value;
  if (trLive !== undefined && !['lyrics', 'message'].includes(item.slideType)) {
    item.transition = trLive || null;
  }
  item.rehearsal = this.readRehearsalInspectorData(el);
  if (item.slideType === 'welcome') {
    item.data = {
      ...this.readWelcomeFromInspector(el, item),
      style: this.readProgramStyle(el, 'welcome'),
    };
  }
  if (item.slideType === 'announcements') {
    const raw = el.querySelector('#insp-ann-items')?.value;
    if (raw !== undefined) {
      item.data = {
        ...(item.data || {}),
        title: el.querySelector('#insp-ann-title')?.value || item.data?.title || 'Comunicados',
        items: parseAnnounceLines(raw),
      };
      item.title = item.data.title;
    }
  }
  if (item.slideType === 'custom') {
    const title = el.querySelector('#insp-screen-title')?.value;
    const text = el.querySelector('#insp-text')?.value;
    if (title !== undefined || text !== undefined) {
      item.data = {
        ...(item.data || {}),
        title: title?.trim() || '',
        subtitle: el.querySelector('#insp-custom-sub')?.value?.trim() || '',
        text: text ?? item.data?.text ?? '',
        align: el.querySelector('#insp-custom-align')?.value || item.data?.align || 'center',
        backgroundPreset: el.querySelector('#insp-custom-bg')?.value || item.data?.backgroundPreset || 'dark',
        textEdited: true,
      };
    }
  }
  if (item.slideType === 'theme') {
    item.data = {
      ...(item.data || {}),
      motto: el.querySelector('#insp-th-motto')?.value ?? item.data?.motto ?? '',
      mottoText: el.querySelector('#insp-th-text')?.value ?? item.data?.mottoText ?? '',
      theme: el.querySelector('#insp-th-theme')?.value ?? item.data?.theme ?? '',
    };
  }
  if (item.slideType === 'offering') {
    const title = el.querySelector('#insp-offering-title')?.value?.trim() || item.data?.title || 'Oferta e Dízimos';
    item.data = {
      ...(item.data || {}),
      title,
      subtitle: el.querySelector('#insp-offering-sub')?.value?.trim() || '',
      verse: el.querySelector('#insp-offering-verse')?.value?.trim() || '',
      template: el.querySelector('#insp-offering-tpl')?.value || item.data?.template || 'classic',
    };
  }
  if (item.slideType === 'countdown') {
    item.data = {
      ...(item.data || {}),
      title: el.querySelector('#insp-pause-title')?.value?.trim() || item.data?.title || item.title,
      durationMin: Number(el.querySelector('#insp-pause-min')?.value) || item.data?.durationMin || null,
      note: el.querySelector('#insp-pause-note')?.value?.trim() || '',
    };
  }
  if (item.slideType === 'media-audio') {
    item.data = {
      ...(item.data || {}),
      screenTitle: el.querySelector('#insp-audio-screen')?.value?.trim() || item.title,
      audioPath: el.querySelector('#insp-audio-path')?.value || item.data?.audioPath || null,
      loop: el.querySelector('#insp-audio-loop')?.checked === true,
      hint: el.querySelector('#insp-audio-hint')?.value?.trim() || '',
    };
  }
  if (!['lyrics', 'message', 'welcome'].includes(item.slideType) && !isBibleInspectorType(item.slideType)) {
    const hasStyleToolbar = !!el.querySelector('#insp-style-title-readout, #insp-style-text-readout, #insp-style-font');
    if (hasStyleToolbar) {
      item.data = {
        ...(item.data || {}),
        style: this.readProgramStyle(el, item.slideType, item.data?.style),
      };
    }
  }
  return true;
},
};
