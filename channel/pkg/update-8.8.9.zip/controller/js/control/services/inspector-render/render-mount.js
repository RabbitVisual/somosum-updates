import { getPassage } from '../../../bible/bible-service.js';
import { bindBibleRefPicker } from '../../../bible/bible-picker.js';
import { hasDesignerSkin } from '../../../designer/content-bindings.js';
import { isBibleInspectorType } from '../../../program/programa-templates.js';
import { esc, escAttr, rawHtml, setHtml } from '../../../core/render-engine/index.js';
import {
  applyMessageInspectorModeUI,
  syncMessagePhotoInspectorUI,
} from '../../../slides/message-display-modes.js';

export const inspectorRenderMount = {
  mountInspectorPanel(el, meta, item, fields, rehearsalBlock, inspectorKey, inspGen) {
    try {
const canDesigner = ['custom', 'welcome', 'bible', 'bible-responsive', 'bible-interlinear', 'message', 'section'].includes(item.slideType)
  || item.data?.role === 'introito'
  || hasDesignerSkin(item);
const stickyExtra = canDesigner
  ? '<button class="btn btn-secondary" id="insp-designer" type="button">◫ Designer</button>'
  : (item.slideType === 'lyrics'
    ? '<button class="btn btn-secondary" id="insp-edit-lyrics" type="button">✎ Editar letra</button>'
    : '');
const designerHint = canDesigner && !hasDesignerSkin(item)
  ? '<p class="form-hint">◫ Designer: cria layout visual (fundo, tipografia, molduras). O texto da Bíblia/boas-vindas continua editável aqui.</p>'
  : '';
setHtml(el, rawHtml(`
  <div class="inspector-scroll">
  ${this.programOrderToolsHtml(meta)}
  <div class="form-block"><label>Item</label><input id="insp-title" value="${escAttr(item.slideType === 'message' ? this.resolveMessageItemTitle(item) : item.title)}" /></div>
  ${designerHint}
  ${fields}
  ${rehearsalBlock}
  </div>
  <div class="inspector-sticky-actions" role="toolbar" aria-label="Ações do item">
    ${stickyExtra}
    <button class="btn btn-primary" id="insp-apply">Aplicar</button>
    <button class="btn btn-danger" id="insp-del">Remover</button>
  </div>`));

this.bindProgramOrderInspector(el, meta);
el.querySelector('#insp-rehearsal-save')?.addEventListener('click', async () => {
  const current = this.program.items[meta.itemIndex];
  if (!current) return;
  current.rehearsal = this.readRehearsalInspectorData(el);
  this.markProgramDirty?.();
  this.programHistory?.record?.();
  await this.program.rebuildItem?.(meta.itemIndex);
  this.renderRundown?.();
  this.renderCultoBanner?.();
  this.syncCoordinator?.emit?.({ kind: 'stage', forceFull: true });
  this.toast?.('Dados de ensaio salvos');
});
if (item.slideType === 'welcome') {
  this.bindWelcomePresetApply?.(el, meta);
}

el.querySelector('#insp-designer')?.addEventListener('click', () => {
  this._designerPendingItem = meta.itemIndex;
  this.view = 'designer';
  this.renderNav();
  this.renderView();
});

if (item.slideType === 'message') {
  const modeSel = el.querySelector('#insp-msg-mode');
  const themeWrap = el.querySelector('#insp-msg-theme-wrap');
  const msgLive = (opts = {}) => {
    this.updateMessageRefPreview(el);
    if (!opts.initial) this.scheduleInspectorLiveSync(meta, el, 200);
  };
  const applyMsgMode = () => {
    const m = modeSel?.value || 'ref_pregador';
    applyMessageInspectorModeUI(el, m);
    syncMessagePhotoInspectorUI(el);
    msgLive();
  };
  modeSel?.addEventListener('change', applyMsgMode);
  applyMessageInspectorModeUI(el, modeSel?.value || 'ref_pregador');
  syncMessagePhotoInspectorUI(el);
  this.bindMessageInspectorToolbar(el, meta);
  this.bindSlideBackgroundInspector(el, meta, { idPrefix: 'insp-msg' });
  ['#insp-msg-theme', '#insp-msg-preacher', '#insp-msg-from'].forEach((sel) => {
    el.querySelector(sel)?.addEventListener('blur', () => this.scheduleInspectorLiveSync(meta, el, 80));
  });
  el.querySelector('#insp-msg-script')?.addEventListener('input', () => this.scheduleInspectorLiveSync(meta, el, 400));
  bindBibleRefPicker(el, {
    versionSel: el.querySelector('#insp-msg-ver'),
    bookSel: el.querySelector('#insp-msg-book'),
    chapterSel: el.querySelector('#insp-msg-ch'),
    verseStartSel: el.querySelector('#insp-msg-vs'),
    verseEndSel: el.querySelector('#insp-msg-ve'),
    hintEl: el.querySelector('#insp-msg-bible-bounds'),
    initial: item.bible || {},
    onRefresh: msgLive,
  }).then((picker) => {
    el._messageBiblePicker = picker;
    this.updateMessageRefPreview(el);
  });
  el.querySelector('#insp-msg-load-verse')?.addEventListener('click', async () => {
    const ref = this.readMessageBibleRef(el);
    const btn = el.querySelector('#insp-msg-load-verse');
    if (btn) { btn.disabled = true; btn.textContent = '…'; }
    try {
      const passage = await getPassage(ref.version, ref.book, ref.chapter, ref.verseStart, ref.verseEnd);
      const text = passage.verses.map((v) => v.text).join(' ');
      const mottoEl = el.querySelector('#insp-msg-motto');
      const refEl = el.querySelector('#insp-msg-ref-override');
      if (mottoEl) mottoEl.value = text;
      if (refEl && !refEl.value.trim()) refEl.value = passage.reference.replace(':', '.');
      this.updateMessageRefPreview(el);
      this.scheduleInspectorLiveSync(meta, el, 80);
      this.toast('Versículo carregado — recorte o trecho desejado');
    } catch (err) {
      this.toast(`Erro: ${err.message}`, 'error');
    } finally {
      if (btn) { btn.disabled = false; btn.textContent = 'Carregar versículo completo'; }
    }
  });
  el.querySelector('#insp-msg-trim-excerpt')?.addEventListener('click', () => {
    const mottoEl = el.querySelector('#insp-msg-motto');
    if (!mottoEl) return;
    const start = mottoEl.selectionStart ?? 0;
    const end = mottoEl.selectionEnd ?? 0;
    if (start === end) {
      this.toast('Selecione o trecho no texto antes de recortar', 'warn');
      return;
    }
    const selected = mottoEl.value.slice(start, end).trim();
    if (!selected) return;
    mottoEl.value = selected.startsWith('...') ? selected : `...${selected}${selected.endsWith('...') ? '' : '...'}`;
    this.scheduleInspectorLiveSync(meta, el, 80);
    this.toast('Trecho recortado');
  });
  el.querySelector('#insp-msg-use-excerpt-theme')?.addEventListener('click', () => {
    const excerpt = el.querySelector('#insp-msg-motto')?.value?.trim();
    if (!excerpt) {
      this.toast('Carregue ou digite o trecho primeiro', 'warn');
      return;
    }
    const themeEl = el.querySelector('#insp-msg-theme');
    if (themeEl) themeEl.value = excerpt.replace(/^\.\.\.|\.\.\.$/g, '').trim();
    if (modeSel && modeSel.value === 'ref_pregador') {
      modeSel.value = 'tema_ref_pregador';
      applyMessageInspectorModeUI(el, modeSel.value);
    }
    this.scheduleInspectorLiveSync(meta, el, 80);
    this.toast('Trecho aplicado ao tema');
  });
  this.updateMessagePhotoPreview(el);
  el.querySelector('#insp-msg-show-photo')?.addEventListener('change', () => {
    const showChk = el.querySelector('#insp-msg-show-photo');
    const photoId = el.querySelector('#insp-msg-photo')?.value;
    if (showChk?.checked && !photoId) {
      this.toast?.('Escolha uma foto na lista acima (ou envie em Mídia). Sem foto, a projeção mostra só o nome — sem círculo vazio.', 'info');
    }
    syncMessagePhotoInspectorUI(el);
    this.scheduleInspectorLiveSync(meta, el, 120);
  });
  el.querySelector('#insp-msg-photo')?.addEventListener('change', () => {
    const photoId = el.querySelector('#insp-msg-photo')?.value;
    const showChk = el.querySelector('#insp-msg-show-photo');
    if (showChk && photoId) showChk.checked = true;
    if (showChk && !photoId) showChk.checked = false;
    this.updateMessagePhotoPreview(el);
    syncMessagePhotoInspectorUI(el);
    this.scheduleInspectorLiveSync(meta, el, 120);
  });
  el.querySelector('#insp-msg-goto-media')?.addEventListener('click', () => {
    this.view = 'media';
    this.renderNav();
    this.renderView();
    this.toast('Envie a foto do pregador aqui — depois volte ao Programa');
  });
}

if (!['lyrics', 'message'].includes(item.slideType)) {
  this.bindProgramStyleToolbar(el, meta);
  this.bindSlideBackgroundInspector(el, meta);
  const styleLive = () => this.scheduleInspectorLiveSync(meta, el, 120);
  if (isBibleInspectorType(item.slideType)) {
    const bibleLive = (opts = {}) => {
      this.updateBibleRefPreview(el);
      if (!opts.initial) this.scheduleInspectorLiveSync(meta, el, 200);
    };
    el.querySelectorAll('#insp-style-title-minus,#insp-style-title-plus,#insp-style-text-minus,#insp-style-text-plus,#insp-style-ref-minus,#insp-style-ref-plus').forEach((btn) => {
      btn.addEventListener('click', () => setTimeout(bibleLive, 30));
    });
    ['#insp-style-font', '#insp-style-font-variant', '#insp-style-align', '#insp-style-valign', '#insp-style-transform', '#insp-style-text-effect', '#insp-bible-mode', '#insp-bible-show-version', '#insp-bible-ref-style', '#insp-bible-ref-layout'].forEach((sel) => {
      el.querySelector(sel)?.addEventListener('change', bibleLive);
    });
    ['#insp-style-title-color', '#insp-style-text-color', '#insp-style-ref-color', '#insp-style-bg-dim'].forEach((sel) => {
      el.querySelector(sel)?.addEventListener('input', bibleLive);
      el.querySelector(sel)?.addEventListener('change', bibleLive);
    });
    el.querySelector('#insp-bible-ref-override')?.addEventListener('input', bibleLive);
  } else {
    el.querySelectorAll('#insp-style-title-minus,#insp-style-title-plus,#insp-style-text-minus,#insp-style-text-plus').forEach((btn) => {
      btn.addEventListener('click', () => setTimeout(styleLive, 30));
    });
    ['#insp-style-font', '#insp-style-font-variant', '#insp-style-align', '#insp-style-valign', '#insp-style-transform', '#insp-style-text-effect'].forEach((sel) => {
      el.querySelector(sel)?.addEventListener('change', styleLive);
    });
    ['#insp-style-title-color', '#insp-style-text-color', '#insp-style-ref-color', '#insp-style-bg-dim'].forEach((sel) => {
      el.querySelector(sel)?.addEventListener('input', styleLive);
      el.querySelector(sel)?.addEventListener('change', styleLive);
    });
  }
}

if (isBibleInspectorType(item.slideType)) {
  const modeSelect = el.querySelector('#insp-bible-mode');
  const excerptWrap = el.querySelector('#insp-bible-excerpt-wrap');
  const bibleLive = (opts = {}) => {
    this.updateBibleRefPreview(el);
    if (!opts.initial) this.scheduleInspectorLiveSync(meta, el, 200);
  };
  modeSelect?.addEventListener('change', () => {
    if (excerptWrap) excerptWrap.style.display = modeSelect.value === 'excerpt' ? '' : 'none';
    const ilWrap = el.querySelector('#insp-bible-interlinear-wrap');
    if (ilWrap) ilWrap.style.display = modeSelect.value === 'interlinear' ? '' : 'none';
    const layoutWrap = el.querySelector('#insp-bible-ref-layout-wrap');
    if (layoutWrap) layoutWrap.style.display = (modeSelect.value === 'reference' || modeSelect.value === 'chapter') ? '' : 'none';
    const styleWrap = el.querySelector('#insp-bible-ref-style-wrap');
    if (styleWrap) styleWrap.style.display = modeSelect.value === 'chapter' ? 'none' : '';
    const vsWrap = el.querySelector('#insp-bible-vs-wrap');
    const veWrap = el.querySelector('#insp-bible-ve-wrap');
    if (vsWrap) vsWrap.style.display = modeSelect.value === 'chapter' ? 'none' : '';
    if (veWrap) veWrap.style.display = modeSelect.value === 'chapter' ? 'none' : '';
    const textGroup = el.querySelector('#insp-style-text-group') || el.querySelector('#insp-style-text-readout')?.closest('.font-toolbar-group');
    const refLayout = el.querySelector('#insp-bible-ref-layout')?.value || 'stacked';
    if (textGroup) {
      const showText = modeSelect.value !== 'reference' || refLayout === 'stacked' || modeSelect.value === 'chapter';
      textGroup.style.display = showText ? '' : 'none';
    }
    if (modeSelect.value !== 'excerpt') {
      const refOv = el.querySelector('#insp-bible-ref-override');
      if (refOv) {
        el._suppressInspectorSync = true;
        refOv.value = '';
        el._suppressInspectorSync = false;
      }
    }
    bibleLive();
  });
  // Estado inicial: ocultar De/Até no modo capítulo
  if (modeSelect?.value === 'chapter') {
    const vsWrap = el.querySelector('#insp-bible-vs-wrap');
    const veWrap = el.querySelector('#insp-bible-ve-wrap');
    const styleWrap = el.querySelector('#insp-bible-ref-style-wrap');
    if (vsWrap) vsWrap.style.display = 'none';
    if (veWrap) veWrap.style.display = 'none';
    if (styleWrap) styleWrap.style.display = 'none';
  }
  el.querySelector('#insp-bible-ref-layout')?.addEventListener('change', () => {
    const textGroup = el.querySelector('#insp-style-text-group') || el.querySelector('#insp-style-text-readout')?.closest('.font-toolbar-group');
    const mode = modeSelect?.value || 'reference';
    const refLayout = el.querySelector('#insp-bible-ref-layout')?.value || 'stacked';
    if (textGroup) textGroup.style.display = (mode !== 'reference' || refLayout === 'stacked' || mode === 'chapter') ? '' : 'none';
    bibleLive();
  });

  el.querySelector('#insp-bible-il-study-slides')?.addEventListener('click', async () => {
    const item = this.program.items[meta.itemIndex];
    if (!item?.bible) return;
    item.bible = {
      ...item.bible,
      displayMode: 'interlinear',
      interlinear: {
        ...(item.bible.interlinear || {}),
        layout: 'word',
        chunkMode: 'word',
        wordsPerSlide: Number(el.querySelector('#insp-bible-il-wps')?.value) || 1,
        show: {
          original: true,
          gloss: true,
          translation: true,
          strong: el.querySelector('#insp-bible-il-show-strong')?.checked !== false,
          morph: false,
          description: el.querySelector('#insp-bible-il-show-desc')?.checked === true,
        },
      },
    };
    const layoutSel = el.querySelector('#insp-bible-il-layout');
    if (layoutSel) layoutSel.value = 'word';
    await this.program.rebuildItem(meta.itemIndex);
    this.markProgramDirty?.();
    this.syncProjectorState?.(false, { skipInspector: true, liveEdit: true });
    this.renderOverlayPanel?.();
    this.toast?.('Slides de estudo gerados — avance como no louvor (1, 2, 3…)');
  });

  [
    '#insp-bible-il-layout', '#insp-bible-il-show-original', '#insp-bible-il-show-gloss',
    '#insp-bible-il-show-translation', '#insp-bible-il-show-strong', '#insp-bible-il-show-morph',
    '#insp-bible-il-show-desc', '#insp-bible-il-vps', '#insp-bible-il-wps', '#insp-bible-original-lang',
  ].forEach((sel) => el.querySelector(sel)?.addEventListener('change', bibleLive));

  el.querySelector('#insp-bible-excerpt')?.addEventListener('input', bibleLive);
  el.querySelector('#insp-bible-excerpt')?.addEventListener('blur', bibleLive);

  const dualCb = el.querySelector('#insp-bible-dual');
  const dualWrap = el.querySelector('#insp-bible-dual-wrap');
  dualCb?.addEventListener('change', () => {
    if (dualWrap) dualWrap.style.display = dualCb.checked ? '' : 'none';
    bibleLive();
  });
  el.querySelector('#insp-ver-b')?.addEventListener('change', bibleLive);

  void (async () => {
    try {
      const { listReadings } = await import('../../../bible/reading-history.js');
      const cultoId = this.program?.cultoId || this.cultoId || 'current';
      const entries = await listReadings({ cultoId, limit: 8 });
      const host = el.querySelector('#insp-bible-history');
      if (host) {
        setHtml(host, rawHtml(entries.length
          ? entries.map((e) => `<li>${esc(e.ref)}${e.version ? ` <span class="muted">(${esc(e.version)})</span>` : ''}</li>`).join('')
          : '<li class="muted">Nenhuma leitura registrada</li>'));
      }
    } catch { /* ignore */ }
  })();

  let biblePicker = null;
  bindBibleRefPicker(el, {
    versionSel: el.querySelector('#insp-ver'),
    bookSel: el.querySelector('#insp-book'),
    chapterSel: el.querySelector('#insp-ch'),
    verseStartSel: el.querySelector('#insp-vs'),
    verseEndSel: el.querySelector('#insp-ve'),
    hintEl: el.querySelector('#insp-bible-bounds'),
    initial: item.bible || {},
    onRefresh: (opts = {}) => {
      if (!el._biblePickerReady) return;
      this.syncBibleOverrideFromPicker(el);
      this.updateBibleRefPreview(el);
      if (!opts.initial) this.scheduleInspectorLiveSync(meta, el, 250, inspGen);
    },
  }).then((picker) => {
    biblePicker = picker;
    el._biblePicker = picker;
    el._biblePickerReady = true;
    this.updateBibleRefPreview(el);
  });

  el.querySelector('#insp-bible-load-excerpt')?.addEventListener('click', async () => {
    const ref = biblePicker?.readValues?.() || {
      version: el.querySelector('#insp-ver')?.value,
      book: el.querySelector('#insp-book')?.value,
      chapter: Number(el.querySelector('#insp-ch')?.value),
      verseStart: Number(el.querySelector('#insp-vs')?.value),
      verseEnd: Number(el.querySelector('#insp-ve')?.value),
    };
    try {
      const passage = await getPassage(
        ref.version,
        ref.book,
        ref.chapter,
        ref.verseStart,
        ref.verseEnd
      );
      const excerptEl = el.querySelector('#insp-bible-excerpt');
      const refEl = el.querySelector('#insp-bible-ref-override');
      if (excerptEl) excerptEl.value = passage.verses.map((v) => v.text).join(' ');
      if (refEl) refEl.value = passage.reference.replace(':', '.');
      this.syncBibleOverrideFromPicker(el, { force: true });
      this.scheduleInspectorLiveSync(meta, el, 80);
      this.toast('Trecho carregado da Bíblia — edite se quiser só uma parte.');
    } catch (err) {
      this.toast(`Erro: ${err.message}`);
    }
  });

  el.querySelector('#insp-apply')?.addEventListener('click', () => this.applyInspectorItem(meta, el));
el.querySelector('#insp-title')?.addEventListener('input', () => {
  if (!el._biblePickerReady) return;
  this.scheduleInspectorLiveSync(meta, el, 200, inspGen);
});

  el.querySelector('#insp-del')?.addEventListener('click', async () => {
    if (!confirm('Remover este item?')) return;
    await this.removeProgramItemAt?.(meta.itemIndex);
  });
  this._inspectorLiveKey = inspectorKey;
  return;
}

if (item.slideType === 'lyrics') {
  this.bindLyricsInspectorToolbar(el, meta);
  el.querySelector('#insp-edit-lyrics')?.addEventListener('click', async () => {
    const songId = item.songId;
    this.view = 'lyrics';
    this.renderNav();
    this.renderView();
    try {
      await this._worshipReady;
    } catch { /* init already logged */ }
    if (songId && this.lyricsEditor?.select) {
      await this.lyricsEditor.select(songId);
    }
    this.toast(songId ? 'Música aberta na biblioteca' : 'Selecione ou cadastre a música', 'success');
  });
}

if (item.slideType === 'participation') {
  this.bindParticipationInspector(el);
  const partLive = () => this.scheduleInspectorLiveSync(meta, el, 150);
  ['#insp-part-kind', '#insp-part-song', '#insp-part-label'].forEach((sel) => {
    el.querySelector(sel)?.addEventListener('change', partLive);
  });
  ['#insp-part-name', '#insp-part-extra', '#insp-part-song-q'].forEach((sel) => {
    el.querySelector(sel)?.addEventListener('input', partLive);
  });
}

if (item.slideType === 'communion') {
  this.bindCommunionInspector?.(el, item, meta);
}

if (item.slideType === 'welcome') {
  const welcomeLive = () => this.scheduleInspectorLiveSync(meta, el, 120);
  [
    '#insp-w-badge', '#insp-w-years', '#insp-w-theme', '#insp-w-date',
    '#insp-w-sub', '#insp-w-extra', '#insp-w-logo-size', '#insp-w-accent',
    '#insp-w-overlay-opacity',
  ].forEach((sel) => el.querySelector(sel)?.addEventListener('input', welcomeLive));
  [
    '#insp-w-layout', '#insp-w-logo-pos', '#insp-w-anim', '#insp-w-bg-motion', '#insp-w-overlay',
    '#insp-w-show-logo', '#insp-w-show-church', '#insp-w-show-years', '#insp-w-badge-style', '#insp-w-sparkles',
    '#insp-w-show-badge', '#insp-w-show-theme', '#insp-w-show-extra', '#insp-w-show-sub',
    '#insp-w-show-date', '#insp-w-text-shine', '#insp-w-particles', '#insp-w-scrim',
    '#insp-w-bg-media-id', '#insp-w-bg-kind',
    '#insp-style-font', '#insp-style-transform', '#insp-style-align',
    '#insp-style-title-color', '#insp-style-text-color', '#insp-style-ref-color',
  ].forEach((sel) => el.querySelector(sel)?.addEventListener('change', welcomeLive));
  el.querySelectorAll('.welcome-pos-select, .welcome-tstyle-select, [id^="insp-w-color-"], [id^="insp-w-size-"]')
    .forEach((node) => {
      node.addEventListener('change', welcomeLive);
      node.addEventListener('input', welcomeLive);
    });
  el.querySelectorAll('#insp-style-title-minus,#insp-style-title-plus,#insp-style-text-minus,#insp-style-text-plus').forEach((btn) => {
    btn.addEventListener('click', () => setTimeout(welcomeLive, 30));
  });
}

if (item.slideType === 'section') {
  el.querySelector('#insp-sec-title')?.addEventListener('input', () => {
    this.scheduleInspectorLiveSync(meta, el, 120);
  });
}

el.querySelector('#insp-deck-import')?.addEventListener('click', () => {
  void import('../../tools/pptx-import-ui.js').then(({ openPowerpointImport }) => {
    openPowerpointImport(this, { targetItemId: item.id });
  });
});

el.querySelector('#insp-apply')?.addEventListener('click', () => this.applyInspectorItem(meta, el));
el.querySelector('#insp-title')?.addEventListener('input', () => {
  this.scheduleInspectorLiveSync(meta, el, 280);
});
el.querySelector('#insp-transition')?.addEventListener('change', () => {
  this.scheduleInspectorLiveSync(meta, el, 100);
});

el.querySelector('#insp-del')?.addEventListener('click', async () => {
  if (!confirm('Remover este item?')) return;
  await this.removeProgramItemAt?.(meta.itemIndex);
});
this._inspectorLiveKey = inspectorKey;
    } catch (err) {
      console.error('[SOMOSUM] mountInspector', err);
      this._inspectorLiveKey = null;
      setHtml(el, rawHtml(`<div class="empty">Erro ao abrir inspetor: ${esc(String(err?.message || err))}</div>`));
    }
  },
};
