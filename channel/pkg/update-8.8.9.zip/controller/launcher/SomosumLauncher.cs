﻿using Somosum.Core;
using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Net;
using System.Reflection;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Win32;
using Somosum.Core;
using Somosum.Engine;
using Somosum.Network.Engine.Core;
using Somosum.Network.Engine.Ncm;

namespace SomosumLauncher
{
    public sealed class TrayApplicationContext : ApplicationContext
    {
        public const string AppVersionFallback = "8.8.9";

        private string AppVersion => ReadAppVersion(_root);

        private static string ReadAppVersion(string root)
        {
            try
            {
                var path = Path.Combine(root ?? "", "VERSION");
                if (File.Exists(path))
                {
                    var v = File.ReadAllText(path).Trim();
                    if (!string.IsNullOrWhiteSpace(v)) return v;
                }
            }
            catch { /* ignore */ }
            return AppVersionFallback;
        }

        private readonly string _root;
        private readonly NotifyIcon _tray;
        private readonly System.Windows.Forms.Timer _statusTimer;
        private System.Windows.Forms.Timer _idleGcTimer;
        private DateTime _lastProjectionActivityUtc = DateTime.UtcNow;
        private bool _cultoLiveHint;
        private readonly Icon _appIcon;
        private Process _serverProcess;
        private volatile bool _ncmStarting;
        private int _port;
        private bool _serverOk;
        private bool _healthReady;
        private bool _healthLan;
        private Mutex _mutex;
        private EventWaitHandle _showControlEvent;
        private string _ipcName;
        private ContextMenuStrip _contextMenu;
#if !LEGACY_BUILD
        private ControlForm _controlForm;
        private RemoteForm _remoteForm;
        private ManagementForm _managementForm;
        private DiagnosticsForm _diagnosticsForm;
        private DocsForm _docsForm;
        private WebShellForm _auxForm;
        private ProjectionForm _projectionForm;
        private ProjectionForm _projectionForm2;
        private StageForm _stageForm;
        private string _stageOpenLayout = "";
#endif
        private AppConfig _config;
        private readonly SynchronizationContext _ui;
        private readonly DisplayWindowManager _displayWindowManager;
        private readonly EngineEventRelay _engineRelay;
        private readonly LocalProjectionBridge _localProjectionBridge;
        private System.Windows.Forms.Timer _displayDebounceTimer;
        private volatile bool _serverRecoveryPending;
        private DateTime _lastElevatedRegisterUtc = DateTime.MinValue;
        private volatile bool _elevatedRegisterPending;
        private int _projectionGeneration;
        private int _projection2Generation;
        private ProjectionLifecycleState _projectionState = ProjectionLifecycleState.Closed;
        private ProjectionLifecycleState _projection2State = ProjectionLifecycleState.Closed;

        internal enum ProjectionLifecycleState
        {
            Closed,
            Opening,
            WaitingDisplaySettle,
            ResolvingTarget,
            PlacingWindow,
            InitializingWebview,
            SyncingViewport,
            Ready,
            DriftDetected,
            Recovering,
            DisplayLost,
            Degraded,
            Closing,
        }

        public Icon AppIcon { get { return _appIcon; } }
        public string GetRoot() { return _root; }
        public int GetPort() { return _port > 0 ? _port : ReadPort(); }

        public TrayApplicationContext()
        {
            _ui = SynchronizationContext.Current ?? new WindowsFormsSynchronizationContext();

            var assemblyDir = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
            if (string.IsNullOrEmpty(assemblyDir))
                assemblyDir = AppDomain.CurrentDomain.BaseDirectory.TrimEnd('\\');
            _root = ResolveContentRoot(assemblyDir);
            LocalServer.Root = _root;

            _config = AppConfig.Load(_root);
            _displayWindowManager = new DisplayWindowManager(this);
            _engineRelay = new EngineEventRelay(this);
            _localProjectionBridge = new LocalProjectionBridge(this);

            var mutexName = "Global\\SOMOSUM_" + _root.ToLowerInvariant().GetHashCode().ToString("X8");
            _ipcName = "Local\\SOMOSUM_SHOW_CTRL_" + _root.ToLowerInvariant().GetHashCode().ToString("X8");
            bool created;
            _mutex = new Mutex(true, mutexName, out created);
            if (!created)
            {
                // Segunda instância: pede à primeira para trazer o Controle  —  não cria janela e morre.
                try
                {
                    using (var ev = EventWaitHandle.OpenExisting(_ipcName))
                        ev.Set();
                }
                catch
                {
                    try
                    {
                        _port = ReadPort();
                        if (_port > 0)
                            DisplayHelper.OpenControlInBrowser(_port, AppVersion);
                    }
                    catch { /* ignore */ }
                }
                Environment.Exit(0);
                return;
            }

            try
            {
                _showControlEvent = new EventWaitHandle(false, EventResetMode.AutoReset, _ipcName);
            }
            catch
            {
                _showControlEvent = new EventWaitHandle(false, EventResetMode.AutoReset);
            }

            ThreadPool.QueueUserWorkItem(_ =>
            {
                while (_showControlEvent != null)
                {
                    try
                    {
                        if (!_showControlEvent.WaitOne(2500)) continue;
                        RunOnUi(() =>
                        {
                            OpenManagementPanelCore();
                        });
                    }
                    catch
                    {
                        break;
                    }
                }
            });

            _appIcon = LoadAppIcon();

            _tray = new NotifyIcon
            {
                Text = "SOMOSUM — iniciando...",
                Icon = _appIcon ?? SystemIcons.Application,
                Visible = true
            };

            BuildTrayMenu();
            _tray.MouseUp += OnTrayMouseUp;
            _tray.DoubleClick += (_, __) => OpenManagementPanel();

            _statusTimer = new System.Windows.Forms.Timer { Interval = 5000 };
            _statusTimer.Tick += (_, __) => UpdateStatus();
            _statusTimer.Start();

            // Low-Spec Pro: GC Gen0 suave apos 10 min sem atividade de projecao
            _idleGcTimer = new System.Windows.Forms.Timer { Interval = 60000 };
            _idleGcTimer.Tick += (_, __) => TryIdleSoftGc();
            _idleGcTimer.Start();
            _lastProjectionActivityUtc = DateTime.UtcNow;

            _displayDebounceTimer = new System.Windows.Forms.Timer { Interval = 450 };
            _displayDebounceTimer.Tick += (_, __) =>
            {
                _displayDebounceTimer.Stop();
                OnDisplaySettingsChangedCore();
            };

            SystemEvents.DisplaySettingsChanged += OnDisplaySettingsChanged;

            ThreadPool.QueueUserWorkItem(_ => Bootstrap());
        }

        private void OnDisplaySettingsChanged(object sender, EventArgs e)
        {
            DisplayEnumerator.InvalidateCache();
            if (_displayDebounceTimer != null)
            {
                _displayDebounceTimer.Stop();
                _displayDebounceTimer.Start();
                return;
            }
            RunOnUiAsync(OnDisplaySettingsChangedCore);
        }

        private int ResolveProjectorIndex(int displayIndex)
        {
            var screens = DisplayHelper.GetAllDisplays();
            if (screens.Length == 0) return 0;
            if (displayIndex >= 0) return Math.Min(displayIndex, screens.Length - 1);
            return DisplayHelper.ResolveProjectorIndex(
                _config.ProjectorDisplayIndex,
                _config.ProjectorDeviceName,
                screens);
        }

        private int ResolveProjector2Index(int displayIndex)
        {
            var screens = DisplayHelper.GetAllDisplays();
            if (screens.Length == 0) return 0;
            if (displayIndex >= 0) return Math.Min(displayIndex, screens.Length - 1);

            var byName = DisplayHelper.ResolveScreenIndex(_config.Projector2DeviceName, screens);
            if (byName >= 0) return byName;

            if (_config.Projector2DisplayIndex >= 0
                && _config.Projector2DisplayIndex < screens.Length)
                return _config.Projector2DisplayIndex;

            var projIdx = ResolveProjectorIndex(-1);
            for (var i = 0; i < screens.Length; i++)
            {
                if (i != projIdx && !screens[i].Primary) return i;
            }
            for (var i = 0; i < screens.Length; i++)
            {
                if (i != projIdx) return i;
            }
            return Math.Min(2, screens.Length - 1);
        }

        private bool IsSecondaryProjectorIndex(int idx)
        {
            var screens = DisplayHelper.GetAllDisplays();
            if (screens.Length < 2) return false;
            if (idx < 0 || idx >= screens.Length) return false;
            return !screens[idx].Primary;
        }

        private bool ShouldAutoOpenProjection()
        {
            if (!_config.AutoOpenProjection) return false;
            var screens = DisplayHelper.GetAllDisplays();
            if (screens.Length < 2) return false;
            var idx = ResolveProjectorIndex(-1);
            return IsSecondaryProjectorIndex(idx);
        }

        private void OnDisplaySettingsChangedCore()
        {
            DisplayEnumerator.InvalidateCache();
            SetProjectionState(ProjectionLifecycleState.Recovering);
            SetProjectionState(ProjectionLifecycleState.Recovering, second: true);

            var screens = DisplayHelper.GetAllDisplays();
            if (screens.Length == 0)
            {
                SetProjectionState(ProjectionLifecycleState.DisplayLost);
                SetProjectionState(ProjectionLifecycleState.DisplayLost, second: true);
                return;
            }

            var idx = ResolveProjectorIndex(-1);
            if (idx != _config.ProjectorDisplayIndex)
            {
                _config.ProjectorDisplayIndex = idx;
                AppConfig.SaveProjectorIndex(_root, idx);
            }

            var idx2 = ResolveProjector2Index(-1);
            if (idx2 != _config.Projector2DisplayIndex
                || !_displayWindowManager.IsIndexValid(_config.Projector2DisplayIndex, screens))
            {
                // Keep -1 (auto) until the user picks a monitor; only persist when valid.
                if (_config.Projector2DisplayIndex >= 0
                    || !string.IsNullOrWhiteSpace(_config.Projector2DeviceName))
                {
                    _config.Projector2DisplayIndex = idx2;
                    AppConfig.SaveProjector2Index(_root, idx2);
                }
            }

            var stageIdx = _displayWindowManager.ResolveDisplayIndex(
                "stage", _config.StageDisplayIndex, screens);
            if (stageIdx != _config.StageDisplayIndex
                || !_displayWindowManager.IsIndexValid(_config.StageDisplayIndex, screens))
            {
                _config.StageDisplayIndex = stageIdx;
                AppConfig.SaveStageDisplayIndex(_root, stageIdx);
            }

            if (_projectionForm != null && !_projectionForm.IsDisposed && _projectionForm.Visible)
            {
                if (!_displayWindowManager.IsIndexValid(idx, screens))
                {
                    SetProjectionState(ProjectionLifecycleState.DisplayLost);
                    _displayWindowManager.OnMonitorDisconnected("projection", _projectionForm, screens);
                }
                else
                {
                    if (_projectionForm.IsDisplayLost)
                        _projectionForm.SetDisplayLost(false);
                    var allowFs = screens.Length > 1 && IsSecondaryProjectorIndex(idx);
                    _projectionForm.ApplyDisplay(idx, allowFs);
                    _projectionForm.RecoverProjectionLayout(forceReapply: true);
                    _displayWindowManager.RememberWindow("projection", idx, _projectionForm);
                    SetProjectionState(ProjectionLifecycleState.Ready);
                }
            }

            if (_projectionForm2 != null && !_projectionForm2.IsDisposed && _projectionForm2.Visible)
            {
                if (!_displayWindowManager.IsIndexValid(idx2, screens))
                {
                    SetProjectionState(ProjectionLifecycleState.DisplayLost, second: true);
                    _displayWindowManager.OnMonitorDisconnected("projection2", _projectionForm2, screens);
                }
                else
                {
                    if (_projectionForm2.IsDisplayLost)
                        _projectionForm2.SetDisplayLost(false);
                    var allowFs2 = screens.Length > 1 && IsSecondaryProjectorIndex(idx2);
                    _projectionForm2.ApplyDisplay(idx2, allowFs2);
                    _projectionForm2.RecoverProjectionLayout(forceReapply: true);
                    _displayWindowManager.RememberWindow("projection2", idx2, _projectionForm2);
                    SetProjectionState(ProjectionLifecycleState.Ready, second: true);
                }
            }

            if (_stageForm != null && !_stageForm.IsDisposed && _stageForm.Visible)
            {
                if (!_displayWindowManager.IsIndexValid(stageIdx, screens))
                    _displayWindowManager.OnMonitorDisconnected("stage", _stageForm, screens);
                else
                {
                    _stageForm.ApplyDisplay(stageIdx, _config.StageFullscreen);
                    _displayWindowManager.RememberWindow("stage", stageIdx, _stageForm);
                }
            }

            _displayWindowManager.NotifyDisplayChanged();

#if !LEGACY_BUILD
            if (screens.Length >= 2 && _config.AutoOpenOnSecondDisplay && IsSecondaryProjectorIndex(idx))
            {
                if (_projectionForm == null || _projectionForm.IsDisposed || !_projectionForm.Visible)
                    InvokeOpenScreen(-1);
            }
#endif
        }

        internal void RunOnUi(Action action)
        {
            if (SynchronizationContext.Current == _ui)
                action();
            else
                _ui.Send(_ => action(), null);
        }

        internal void RunOnUiAsync(Action action)
        {
            if (SynchronizationContext.Current == _ui)
                action();
            else
                _ui.Post(_ => action(), null);
        }

        /// <summary>WebView2 → ponte local Controle↔Projeção (sem Kestrel).</summary>
        internal void HandleLocalWebMessage(string webMessageAsJson, string fromSurface)
        {
            _localProjectionBridge?.HandleWebMessage(webMessageAsJson, fromSurface);
        }

        internal void PushLocalSyncFromControl(string envelopeJson)
        {
            _localProjectionBridge?.PushFromControl(envelopeJson);
        }

#if !LEGACY_BUILD
        internal void PostLocalSyncToControl(string envelopeJson)
        {
            if (_controlForm != null && !_controlForm.IsDisposed)
                _controlForm.PostLocalSync(envelopeJson);
        }

        internal void PostLocalSyncToProjection(string envelopeJson)
        {
            if (_projectionForm != null && !_projectionForm.IsDisposed)
                _projectionForm.PostLocalSync(envelopeJson);
        }

        internal void PostLocalSyncToProjection2(string envelopeJson)
        {
            if (_projectionForm2 != null && !_projectionForm2.IsDisposed)
                _projectionForm2.PostLocalSync(envelopeJson);
        }

        internal void PostLocalSyncToStage(string envelopeJson)
        {
            if (_stageForm != null && !_stageForm.IsDisposed)
                _stageForm.PostLocalSync(envelopeJson);
        }
#endif

        private void OnTrayMouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right && _contextMenu != null)
            {
                _contextMenu.Show(Cursor.Position);
            }
            else if (e.Button == MouseButtons.Left)
            {
                OpenManagementPanel();
            }
        }

        private void BuildTrayMenu()
        {
            _contextMenu = new ContextMenuStrip
            {
                ShowImageMargin = true,
                Font = new Font("Segoe UI", 9f),
                Renderer = new SomosumTrayRenderer(),
                BackColor = Color.FromArgb(18, 16, 12),
                ForeColor = Color.FromArgb(232, 224, 208),
                Padding = new Padding(4, 6, 4, 6),
            };

            void Add(ToolStripItemCollection host, string text, Image icon, EventHandler onClick, bool bold = false)
            {
                var item = new ToolStripMenuItem(text, icon, onClick);
                if (bold) item.Font = new Font(item.Font, FontStyle.Bold);
                host.Add(item);
            }

            Add(_contextMenu.Items, "Painel Gerencial", TrayMenuIcons.Gold, (_, __) => OpenManagementPanel(), bold: true);
            _contextMenu.Items.Add(new ToolStripSeparator());

            var windows = new ToolStripMenuItem("Janelas", TrayMenuIcons.Soft);
            Add(windows.DropDownItems, "Controle", TrayMenuIcons.Gold, (_, __) => OpenControlWindow());
            Add(windows.DropDownItems, "Projecao", TrayMenuIcons.Accent, (_, __) => OpenScreenWindow());
            Add(windows.DropDownItems, "Projecao 2", TrayMenuIcons.Accent, (_, __) => InvokeOpenScreen2(-1));
            Add(windows.DropDownItems, "Stage (musicos)", TrayMenuIcons.Soft, (_, __) => InvokeOpenStage(-1));
            Add(windows.DropDownItems, "Remote (celular)", TrayMenuIcons.Soft, (_, __) => InvokeOpenRemote());
            windows.DropDownItems.Add(new ToolStripSeparator());
            Add(windows.DropDownItems, "So Controle", TrayMenuIcons.Gold, (_, __) => OpenControlWindow());
            Add(windows.DropDownItems, "Culto completo", TrayMenuIcons.Gold, (_, __) =>
            {
                EnsureControlVisible(forceReload: false);
                InvokeOpenScreen(-1);
            });
            Add(windows.DropDownItems, "Ensaio", TrayMenuIcons.Soft, (_, __) => OpenControlWindow());
            windows.DropDownItems.Add(new ToolStripSeparator());
            Add(windows.DropDownItems, "Painel + Controle", TrayMenuIcons.Gold, (_, __) =>
            {
                OpenManagementPanel();
                EnsureControlVisible(forceReload: false);
            });
            Add(windows.DropDownItems, "Painel + Controle + Projecao", TrayMenuIcons.Gold, (_, __) =>
            {
                OpenManagementPanel();
                EnsureControlVisible(forceReload: false);
                InvokeOpenScreen(-1);
            });
            StyleDropDown(windows);
            _contextMenu.Items.Add(windows);

            var network = new ToolStripMenuItem("Rede e URLs", TrayMenuIcons.Ok);
            Add(network.DropDownItems, "Copiar URL do Controle", TrayMenuIcons.Soft, (_, __) => CopyUrl("control.html"));
            Add(network.DropDownItems, "Copiar URL da Projecao", TrayMenuIcons.Soft, (_, __) => CopyUrl("screen.html"));
            Add(network.DropDownItems, "Copiar URL do Stage", TrayMenuIcons.Soft, (_, __) => CopyUrl("stage.html"));
            Add(network.DropDownItems, "Copiar URL do Remote", TrayMenuIcons.Soft, (_, __) => CopyRemoteUrl());
            network.DropDownItems.Add(new ToolStripSeparator());
            Add(network.DropDownItems, "Preparar rede local (admin)", TrayMenuIcons.Accent, (_, __) => InvokeRegisterHttpPorts());
            StyleDropDown(network);
            _contextMenu.Items.Add(network);

            var tools = new ToolStripMenuItem("Ferramentas", TrayMenuIcons.Soft);
            Add(tools.DropDownItems, "Configurar monitor do projetor...", TrayMenuIcons.Accent, (_, __) => ConfigureProjector());
            Add(tools.DropDownItems, "Reiniciar servidor", TrayMenuIcons.Soft, (_, __) => RestartServer());
            Add(tools.DropDownItems, "Documentacao...", TrayMenuIcons.Soft, (_, __) => OpenDocsPanel());
            Add(tools.DropDownItems, "Diagnostico do sistema...", TrayMenuIcons.Soft, (_, __) => OpenDiagnosticsPanel());
            tools.DropDownItems.Add(new ToolStripSeparator());
            Add(tools.DropDownItems, "Pasta de dados", TrayMenuIcons.Soft, (_, __) => OpenFolder(ContentLayout.DataDir(_root)));
            Add(tools.DropDownItems, "Pasta de logs", TrayMenuIcons.Soft, (_, __) => OpenFolder(Path.Combine(_root, "logs")));
            Add(tools.DropDownItems, "Pasta de fontes", TrayMenuIcons.Soft, (_, __) => OpenFolder(ContentLayout.FontsDir(_root)));
            Add(tools.DropDownItems, "Pasta de audio", TrayMenuIcons.Soft, (_, __) => OpenFolder(ContentLayout.AudioDir(_root)));
            StyleDropDown(tools);
            _contextMenu.Items.Add(tools);

            _contextMenu.Items.Add(new ToolStripSeparator());
            Add(_contextMenu.Items, "Criar atalho na Area de Trabalho", TrayMenuIcons.Soft, (_, __) => CreateDesktopShortcut(false));
            Add(_contextMenu.Items, "Guia de uso (LEIA-ME)", TrayMenuIcons.Soft, (_, __) => OpenGuide());
            _contextMenu.Items.Add(new ToolStripSeparator());
            Add(_contextMenu.Items, "Encerrar SOMOSUM", TrayMenuIcons.Danger, (_, __) => Shutdown());

            _tray.ContextMenuStrip = _contextMenu;
        }

        private static void StyleDropDown(ToolStripMenuItem parent)
        {
            if (parent.DropDown is ToolStripDropDownMenu dd)
            {
                dd.BackColor = Color.FromArgb(18, 16, 12);
                dd.ForeColor = Color.FromArgb(232, 224, 208);
                dd.Renderer = new SomosumTrayRenderer();
                dd.ShowImageMargin = true;
            }
        }

        public void OpenManagementPanel(string section = null)
        {
            RunOnUi(() => OpenManagementPanelCore(section));
        }

        private void OpenManagementPanelCore(string section = null)
        {
            _port = ReadPort();
            if (_port <= 0) _port = 8765;
            var url = string.Format(LocalServer.Scheme() + "://127.0.0.1:{0}/launcher/panel.html?v={1}", _port, AppVersion);
            if (!string.IsNullOrWhiteSpace(section))
            {
                var sec = section.Trim().TrimStart('?', '&');
                if (sec.StartsWith("section=", StringComparison.OrdinalIgnoreCase))
                    url += "&" + sec;
                else
                    url += "&section=" + Uri.EscapeDataString(sec);
            }
#if !LEGACY_BUILD
            try
            {
                if (_managementForm == null || _managementForm.IsDisposed)
                    _managementForm = new ManagementForm(url, this);
                else
                    _managementForm.NavigateTo(url);
                _managementForm.Show();
                _managementForm.WindowState = FormWindowState.Normal;
                _managementForm.BringToFront();
                return;
            }
            catch { }
#endif
            OpenUrlFallback(url);
        }

        public void OpenDiagnosticsPanel()
        {
            RunOnUi(OpenDiagnosticsPanelCore);
        }

        public void OpenDocsPanel(string fragment = null)
        {
            RunOnUi(() => OpenDocsPanelCore(fragment));
        }

        private void OpenDocsPanelCore(string fragment)
        {
            _port = ReadPort();
            if (_port <= 0) _port = 8765;
            var hash = string.IsNullOrWhiteSpace(fragment) ? "" : "#" + fragment.TrimStart('#');
            var url = string.Format(
                LocalServer.Scheme() + "://127.0.0.1:{0}/docs/index.html?v={1}{2}",
                _port, AppVersion, hash);
#if !LEGACY_BUILD
            try
            {
                if (_docsForm == null || _docsForm.IsDisposed)
                    _docsForm = new DocsForm(url, this);
                else
                    _docsForm.NavigateTo(url);
                _docsForm.Show();
                _docsForm.WindowState = FormWindowState.Normal;
                _docsForm.BringToFront();
                _docsForm.Activate();
                return;
            }
            catch { }
#endif
            OpenUrlFallback(url);
        }

        /// <summary>Janela auxiliar local (ícone SOMOSUM) — evita popup Edge genérico.</summary>
        public void OpenAuxBrowserWindow(string url)
        {
            RunOnUi(() => OpenAuxBrowserWindowCore(url));
        }

        private void OpenAuxBrowserWindowCore(string url)
        {
            if (string.IsNullOrWhiteSpace(url)) return;
#if !LEGACY_BUILD
            try
            {
                if (_auxForm == null || _auxForm.IsDisposed)
                {
                    _auxForm = new DocsForm(url, this);
                    _auxForm.Text = "SOMOSUM";
                }
                else
                {
                    _auxForm.Text = "SOMOSUM";
                    _auxForm.NavigateTo(url);
                }
                _auxForm.Show();
                _auxForm.WindowState = FormWindowState.Normal;
                _auxForm.BringToFront();
                _auxForm.Activate();
                return;
            }
            catch { }
#endif
            OpenUrlFallback(url);
        }

        private void OpenDiagnosticsPanelCore()
        {
            _port = ReadPort();
            if (_port <= 0) _port = 8765;
            var url = string.Format(LocalServer.Scheme() + "://127.0.0.1:{0}/launcher/diagnostics.html?v={1}", _port, AppVersion);
#if !LEGACY_BUILD
            try
            {
                if (_diagnosticsForm == null || _diagnosticsForm.IsDisposed)
                    _diagnosticsForm = new DiagnosticsForm(url, this);
                else
                    _diagnosticsForm.NavigateTo(url);
                _diagnosticsForm.Show();
                _diagnosticsForm.WindowState = FormWindowState.Normal;
                _diagnosticsForm.BringToFront();
                return;
            }
            catch { }
#endif
            OpenUrlFallback(url);
        }

        public void InvokeOpenControl() { OpenControlWindow(); }

        public void InvokeRestartServer() { RestartServer(); }

        public void InvokeRelaunchForUpdate()
        {
            var rootExe = Path.Combine(_root ?? "", "SOMOSUM.exe");
            if (!File.Exists(rootExe)) rootExe = ResolveSelfExePath(_root);
            if (string.IsNullOrEmpty(rootExe) || !File.Exists(rootExe))
            {
                _tray.ShowBalloonTip(4000, "SOMOSUM", "Nao foi possivel reiniciar para aplicar a atualizacao.", ToolTipIcon.Error);
                return;
            }
            try
            {
                // Preferir trampolim na raiz (aplica delta no boot); senão o app EXE (apply no Kestrel).
                var workDir = _root ?? Path.GetDirectoryName(rootExe) ?? ".";
                if (workDir.IndexOf('"') >= 0 || rootExe.IndexOf('"') >= 0)
                {
                    _tray.ShowBalloonTip(4000, "SOMOSUM", "Caminho invalido para reiniciar a atualizacao.", ToolTipIcon.Error);
                    return;
                }
                var bat = Path.Combine(Path.GetTempPath(), "somosum-relaunch-" + Guid.NewGuid().ToString("N") + ".cmd");
                var script =
                    "@echo off" + Environment.NewLine +
                    "ping -n 5 127.0.0.1 >nul" + Environment.NewLine +
                    "cd /d \"" + workDir + "\"" + Environment.NewLine +
                    "start \"\" \"" + rootExe + "\"" + Environment.NewLine +
                    "del \"%~f0\"" + Environment.NewLine;
                File.WriteAllText(bat, script);
                Process.Start(new ProcessStartInfo
                {
                    FileName = "cmd.exe",
                    Arguments = "/c \"" + bat + "\"",
                    WorkingDirectory = workDir,
                    UseShellExecute = false,
                    CreateNoWindow = true,
                    WindowStyle = ProcessWindowStyle.Hidden,
                });
            }
            catch (Exception ex)
            {
                _tray.ShowBalloonTip(5000, "SOMOSUM", "Falha ao reiniciar: " + ex.Message, ToolTipIcon.Error);
                return;
            }
            ForceShutdownForUpdate();
        }

        public void InvokeShutdown() { Shutdown(); }

        private void ForceShutdownForUpdate()
        {
            try { _statusTimer.Stop(); } catch { }
            try { _idleGcTimer?.Stop(); } catch { }
            try { SystemEvents.DisplaySettingsChanged -= OnDisplaySettingsChanged; } catch { }
            try { _tray.Visible = false; } catch { }
            RunEncerrar();
            if (_serverProcess != null && !_serverProcess.HasExited)
            {
                try { _serverProcess.Kill(true); } catch { }
            }
#if !LEGACY_BUILD
            foreach (var form in new Form[] {
                _controlForm, _remoteForm, _managementForm, _diagnosticsForm, _docsForm, _auxForm,
                _projectionForm, _projectionForm2, _stageForm
            })
            {
                if (form == null || form.IsDisposed) continue;
                try { form.Close(); form.Dispose(); } catch { }
            }
#endif
            try { Application.Exit(); } catch { }
            Environment.Exit(0);
        }

        public void InvokeOpenFolder(string relative)
        {
            if (string.IsNullOrWhiteSpace(relative))
            {
                OpenFolder(_root);
                return;
            }

            var rel = relative.Trim().Replace('\\', '/').TrimStart('/');
            if (rel.IndexOf("..", StringComparison.Ordinal) >= 0 || Path.IsPathRooted(relative.Trim()))
            {
                OpenFolder(_root);
                return;
            }

            // Aliases URL-style (data/fonts/audio/…) → pastas MVC via ContentLayout
            OpenFolder(ContentLayout.MapUrlToPhysical(_root, "/" + rel));
        }

        public void InvokeSetProjectorDisplay(int index)
        {
            var screens = DisplayHelper.GetAllDisplays();
            if (index < 0 || index >= screens.Length) return;
            _config.ProjectorDisplayIndex = index;
            _config.ProjectorDeviceName = screens[index].DeviceName ?? "";
            AppConfig.SaveProjectorIndex(_root, index);
            AppConfig.SaveProjectorDeviceName(_root, _config.ProjectorDeviceName);
#if !LEGACY_BUILD
            if (_projectionForm != null && !_projectionForm.IsDisposed && _projectionForm.Visible)
            {
                var allowFs = screens.Length > 1 && IsSecondaryProjectorIndex(index);
                _projectionForm.ApplyDisplay(index, allowFs);
            }
#endif
            try
            {
                var snap = DisplayHelper.GetDetailedSnapshotJson(
                    index, _config.StageDisplayIndex, 0, _config.Projector2DisplayIndex);
                BroadcastDisplayChanged(snap);
            }
            catch { /* optional */ }
            _tray.ShowBalloonTip(3000, "SOMOSUM", "Monitor do projetor: " + (index + 1), ToolTipIcon.Info);
        }

        public void InvokeSetProjector2Display(int index)
        {
            var screens = DisplayHelper.GetAllDisplays();
            if (index < 0 || index >= screens.Length) return;
            _config.Projector2DisplayIndex = index;
            _config.Projector2DeviceName = screens[index].DeviceName ?? "";
            AppConfig.SaveProjector2Index(_root, index);
            AppConfig.SaveProjector2DeviceName(_root, _config.Projector2DeviceName);
#if !LEGACY_BUILD
            if (_projectionForm2 != null && !_projectionForm2.IsDisposed && _projectionForm2.Visible)
            {
                var allowFs = screens.Length > 1 && IsSecondaryProjectorIndex(index);
                _projectionForm2.ApplyDisplay(index, allowFs);
            }
#endif
            try
            {
                var snap = DisplayHelper.GetDetailedSnapshotJson(
                    _config.ProjectorDisplayIndex, _config.StageDisplayIndex, 0, index);
                BroadcastDisplayChanged(snap);
            }
            catch { /* optional */ }
            _tray.ShowBalloonTip(3000, "SOMOSUM", "Monitor da projecao 2: " + (index + 1), ToolTipIcon.Info);
        }

        public void InvokeSetAutoOpenProjection(bool value)
        {
            _config.AutoOpenProjection = value;
            AppConfig.SaveBoolSetting(_root, "autoOpenProjection", value);
        }

        public void InvokeSetAutoOpenOnSecondDisplay(bool value)
        {
            _config.AutoOpenOnSecondDisplay = value;
            AppConfig.SaveBoolSetting(_root, "autoOpenOnSecondDisplay", value);
        }

        public bool GetAutoOpenProjection() { return _config.AutoOpenProjection; }
        public bool GetAutoOpenOnSecondDisplay() { return _config.AutoOpenOnSecondDisplay; }

        public void InvokeSetPreferNativeProjectorMode(bool value)
        {
            _config.PreferNativeProjectorMode = value;
            AppConfig.SaveBoolSetting(_root, "preferNativeProjectorMode", value);
        }

        public bool GetPreferNativeProjectorMode() { return _config.PreferNativeProjectorMode; }

        public void InvokeApplyProjectorNativeResolution(int displayIndex = -1)
        {
            var idx = displayIndex >= 0 ? displayIndex : _config.ProjectorDisplayIndex;
            TryApplyNativeProjectorMode(idx, allowFullscreen: true);
            try
            {
                var snapshot = DisplayEnumerator.GetDisplaysDetailedJson(
                    _config.ProjectorDisplayIndex,
                    _config.StageDisplayIndex,
                    0,
                    _config.Projector2DisplayIndex);
                BroadcastDisplayChanged(snapshot);
            }
            catch { /* ignore */ }
        }

        public int GetProjectorDisplayIndex() { return _config.ProjectorDisplayIndex; }
        public int GetProjector2DisplayIndex() { return _config.Projector2DisplayIndex; }

        public string GetProjectorDeviceName() { return _config.ProjectorDeviceName ?? ""; }
        public string GetProjector2DeviceName() { return _config.Projector2DeviceName ?? ""; }

        public int GetStageDisplayIndex() { return _config.StageDisplayIndex; }

        public bool GetStageFullscreen() { return _config.StageFullscreen; }

        public void InvokeSetStageFullscreen(bool value)
        {
            _config.StageFullscreen = value;
            AppConfig.SaveBoolSetting(_root, "stageFullscreen", value);
#if !LEGACY_BUILD
            if (_stageForm != null && !_stageForm.IsDisposed && _stageForm.Visible)
                _stageForm.ApplyDisplay(_config.StageDisplayIndex, _config.StageFullscreen);
#endif
        }

        public void BroadcastDisplayChanged(string snapshotJson)
        {
            RunOnUiAsync(() =>
            {
#if !LEGACY_BUILD
                if (_controlForm != null && !_controlForm.IsDisposed)
                    _controlForm.PostDisplayChanged(snapshotJson);
                if (_projectionForm != null && !_projectionForm.IsDisposed)
                    _projectionForm.PostDisplayChanged(snapshotJson);
                if (_projectionForm2 != null && !_projectionForm2.IsDisposed)
                    _projectionForm2.PostDisplayChanged(snapshotJson);
                if (_stageForm != null && !_stageForm.IsDisposed)
                    _stageForm.PostDisplayChanged(snapshotJson);
#endif
            });
        }

        private void BroadcastDisplaySnapshot()
        {
            try
            {
                DisplayEnumerator.InvalidateCache();
                var json = DisplayEnumerator.GetDisplaysDetailedJson(
                    _config.ProjectorDisplayIndex,
                    _config.StageDisplayIndex,
                    0,
                    _config.Projector2DisplayIndex);
                BroadcastDisplayChanged(json);
            }
            catch { /* optional */ }
        }

        public void BroadcastEngineEvents(string eventsJson)
        {
            RunOnUiAsync(() =>
            {
#if !LEGACY_BUILD
                if (_controlForm != null && !_controlForm.IsDisposed)
                    _controlForm.PostEngineEvents(eventsJson);
                if (_projectionForm != null && !_projectionForm.IsDisposed)
                    _projectionForm.PostEngineEvents(eventsJson);
                if (_projectionForm2 != null && !_projectionForm2.IsDisposed)
                    _projectionForm2.PostEngineEvents(eventsJson);
#endif
            });
        }

        public void InvokeOpenStage(int displayIndex)
        {
            RunOnUiAsync(() => InvokeOpenStageCore(displayIndex));
        }

        public void InvokeCloseStage()
        {
            RunOnUi(InvokeCloseStageCore);
        }

        public void InvokeSetStageDisplay(int index)
        {
            _config.StageDisplayIndex = index;
            AppConfig.SaveStageDisplayIndex(_root, index);
#if !LEGACY_BUILD
            if (_stageForm != null && !_stageForm.IsDisposed && _stageForm.Visible)
                _stageForm.ApplyDisplay(index, _config.StageFullscreen);
#endif
        }

        public void InvokeSetStageOpenLayout(string layout)
        {
#if !LEGACY_BUILD
            _stageOpenLayout = string.IsNullOrWhiteSpace(layout) ? "" : layout.Trim();
#endif
        }

        private void InvokeCloseStageCore()
        {
#if !LEGACY_BUILD
            if (_stageForm == null || _stageForm.IsDisposed) return;
            _stageForm.Close();
            _stageForm.Dispose();
            _stageForm = null;
#endif
        }

        private async void InvokeOpenStageCore(int displayIndex)
        {
            EnsureControlVisible(forceReload: false);
            _port = ReadPort();
            if (_port <= 0) _port = 8765;

            var screens = DisplayHelper.GetAllDisplays();
            if (screens.Length == 0) return;

            var idx = displayIndex >= 0 ? displayIndex : _config.StageDisplayIndex;
            if (idx < 0 || idx >= screens.Length) idx = 0;

            var url = string.Format(
                LocalServer.Scheme() + "://127.0.0.1:{0}/stage.html?v={1}",
                _port,
                Uri.EscapeDataString(AppVersion));
#if !LEGACY_BUILD
            var openLayout = _stageOpenLayout;
            _stageOpenLayout = "";
            if (!string.IsNullOrWhiteSpace(openLayout))
                url += "&layout=" + Uri.EscapeDataString(openLayout.Trim());
#endif

#if !LEGACY_BUILD
            try
            {
                if (_stageForm != null && !_stageForm.IsDisposed && _stageForm.IsInitialized)
                {
                    _stageForm.ApplyDisplay(idx, _config.StageFullscreen);
                    _stageForm.NavigateTo(url);
                    if (!_stageForm.Visible) _stageForm.Show();
                    _stageForm.BringToFront();
                    _stageForm.Activate();
                    return;
                }

                if (_stageForm != null && !_stageForm.IsDisposed)
                {
                    try { _stageForm.Close(); } catch { /* ignore */ }
                    try { _stageForm.Dispose(); } catch { /* ignore */ }
                    _stageForm = null;
                }

                _stageForm = new StageForm(this, idx);
                var form = _stageForm;
                form.FormClosed += (_, __) =>
                {
                    if (ReferenceEquals(_stageForm, form))
                        _stageForm = null;
                };
                await form.InitializeAndShowAsync(url, _config.StageFullscreen);
                return;
            }
            catch
            {
                OpenUrlFallback(url);
            }
#else
            OpenUrlFallback(url);
#endif
        }

        public void InvokeRegisterHttpPorts()
        {
            RunOnUi(() =>
            {
                // Ja admin: registra no processo e reabre o bind LAN sem segundo UAC.
                if (PortRegistrationService.IsRunningAsAdmin())
                {
                    _ = ApplyLanRegistrationViaHttpAsync(repair: false);
                    return;
                }
                LaunchElevatedNetworkRegister();
            });
        }

        private async System.Threading.Tasks.Task ApplyLanRegistrationViaHttpAsync(bool repair)
        {
            try
            {
                _port = ReadPort();
                if (_port <= 0) _port = 8765;
                var url = LocalServer.Base(_port) + "/api/network/register";
                var body = "{\"repair\":" + (repair ? "true" : "false") + "}";
                var req = (System.Net.HttpWebRequest)System.Net.WebRequest.Create(url);
                LocalServer.ConfigureRequestTls(LocalServer.Root, req);
                req.Method = "POST";
                req.ContentType = "application/json";
                // Resposta e rapida (rebind em background) — timeout curto evita freeze.
                req.Timeout = 15000;
                var bytes = System.Text.Encoding.UTF8.GetBytes(body);
                req.ContentLength = bytes.Length;
                using (var s = await req.GetRequestStreamAsync())
                    await s.WriteAsync(bytes, 0, bytes.Length);
                using (var resp = (System.Net.HttpWebResponse)await req.GetResponseAsync())
                using (var rs = resp.GetResponseStream())
                using (var reader = new System.IO.StreamReader(rs))
                {
                    var json = await reader.ReadToEndAsync();
                    var ok = json.IndexOf("\"ok\":true", StringComparison.OrdinalIgnoreCase) >= 0
                        || json.IndexOf("\"Success\":true", StringComparison.OrdinalIgnoreCase) >= 0;
                    var needsElev = json.IndexOf("\"NeedsElevation\":true", StringComparison.OrdinalIgnoreCase) >= 0;
                    if (ok)
                    {
                        _elevatedRegisterPending = false;
                        _tray.ShowBalloonTip(4000, "SOMOSUM", "Rede LAN preparada. Celular/Stage ja podem conectar.", ToolTipIcon.Info);
                        return;
                    }
                    if (needsElev && !_elevatedRegisterPending && !LanRegisterOkExists())
                    {
                        LaunchElevatedNetworkRegister();
                        return;
                    }
                    if (LanRegisterOkExists())
                    {
                        await TryRebindLanHttpAsync();
                        _tray.ShowBalloonTip(4000, "SOMOSUM", "Registro detectado. Reabrindo a rede LAN…", ToolTipIcon.Info);
                        return;
                    }
                    _tray.ShowBalloonTip(5000, "SOMOSUM", "Registro de rede incompleto. Tente Preparar rede de novo.", ToolTipIcon.Warning);
                }
            }
            catch
            {
                // Timeout/ocupado apos UAC: NUNCA reabrir UAC — adota .lan-register-ok + rebind.
                if (LanRegisterOkExists() || _elevatedRegisterPending)
                {
                    await System.Threading.Tasks.Task.Delay(1500);
                    await TryRebindLanHttpAsync();
                    // Força apply uma vez com timeout (sem recursao no catch)
                    try
                    {
                        _port = ReadPort();
                        if (_port <= 0) _port = 8765;
                        var url = LocalServer.Base(_port) + "/api/network/register";
                        var body = "{\"repair\":false}";
                        var req = (System.Net.HttpWebRequest)System.Net.WebRequest.Create(url);
                        LocalServer.ConfigureRequestTls(LocalServer.Root, req);
                        req.Method = "POST";
                        req.ContentType = "application/json";
                        req.Timeout = 20000;
                        var bytes = System.Text.Encoding.UTF8.GetBytes(body);
                        req.ContentLength = bytes.Length;
                        using (var s = await req.GetRequestStreamAsync())
                            await s.WriteAsync(bytes, 0, bytes.Length);
                        using (var resp = (System.Net.HttpWebResponse)await req.GetResponseAsync())
                        using (var rs = resp.GetResponseStream())
                        using (var reader = new System.IO.StreamReader(rs))
                            await reader.ReadToEndAsync();
                        _elevatedRegisterPending = false;
                        _tray.ShowBalloonTip(4000, "SOMOSUM", "Rede LAN preparada. Celular/Stage ja podem conectar.", ToolTipIcon.Info);
                    }
                    catch
                    {
                        _tray.ShowBalloonTip(4000, "SOMOSUM", "Servidor reiniciando a rede. Aguarde uns segundos e escaneie o QR.", ToolTipIcon.Info);
                    }
                    return;
                }
                if (!PortRegistrationService.IsRunningAsAdmin()
                    && (DateTime.UtcNow - _lastElevatedRegisterUtc).TotalSeconds > 90)
                {
                    LaunchElevatedNetworkRegister();
                }
                else
                    _tray.ShowBalloonTip(4000, "SOMOSUM", "Servidor ocupado. Aguarde e clique Preparar rede outra vez.", ToolTipIcon.Warning);
            }
        }

        private bool LanRegisterOkExists()
        {
            try
            {
                return File.Exists(Path.Combine(ContentLayout.DataDir(_root ?? ""), ".lan-register-ok"));
            }
            catch { return false; }
        }

        private async System.Threading.Tasks.Task TryRebindLanHttpAsync()
        {
            try
            {
                _port = ReadPort();
                if (_port <= 0) _port = 8765;
                var url = LocalServer.Base(_port) + "/api/network/rebind";
                var req = (System.Net.HttpWebRequest)System.Net.WebRequest.Create(url);
                LocalServer.ConfigureRequestTls(LocalServer.Root, req);
                req.Method = "POST";
                req.ContentType = "application/json";
                req.Timeout = 8000;
                req.ContentLength = 0;
                using (var resp = (System.Net.HttpWebResponse)await req.GetResponseAsync())
                using (var rs = resp.GetResponseStream())
                using (var reader = new System.IO.StreamReader(rs))
                    await reader.ReadToEndAsync();
            }
            catch { /* ignore */ }
        }

        private void LaunchElevatedNetworkRegister()
        {
            // Evita UAC em loop (freeze + popup repetido).
            if (_elevatedRegisterPending
                || (DateTime.UtcNow - _lastElevatedRegisterUtc).TotalSeconds < 90)
            {
                var waitSec = Math.Max(0, 90 - (int)(DateTime.UtcNow - _lastElevatedRegisterUtc).TotalSeconds);
                _tray.ShowBalloonTip(4500, "SOMOSUM",
                    waitSec > 0
                        ? $"UAC solicitado recentemente — aguarde {waitSec}s ou use Rede → Preparar rede."
                        : "Preparando rede… aguarde a confirmacao do UAC.",
                    ToolTipIcon.Info);
                _ = ApplyLanRegistrationViaHttpAsync(repair: false);
                return;
            }

            var exe = ResolveSelfExePath(_root);
            if (string.IsNullOrEmpty(exe) || !File.Exists(exe))
            {
                _tray.ShowBalloonTip(4000, "SOMOSUM", "SOMOSUM.exe nao encontrado para preparar a rede.", ToolTipIcon.Error);
                return;
            }

            try
            {
                _lastElevatedRegisterUtc = DateTime.UtcNow;
                _elevatedRegisterPending = true;
                var psi = new ProcessStartInfo
                {
                    FileName = exe,
                    Arguments = "--network-register-elevated --root \"" + _root + "\"",
                    WorkingDirectory = _root,
                    UseShellExecute = true,
                    Verb = "runas",
                    ErrorDialog = true,
                };
                var proc = Process.Start(psi);
                if (proc == null)
                {
                    _elevatedRegisterPending = false;
                    _tray.ShowBalloonTip(4000, "SOMOSUM", "Nao foi possivel abrir o pedido de administrador (UAC).", ToolTipIcon.Warning);
                    return;
                }
                _tray.ShowBalloonTip(3500, "SOMOSUM", "Confirme o UAC (Sim). Em seguida a rede sera ativada automaticamente.", ToolTipIcon.Info);
                // Aguarda o filho elevado e aplica bind no processo principal.
                System.Threading.Tasks.Task.Run(async () =>
                {
                    try
                    {
                        proc.WaitForExit(120000);
                        await System.Threading.Tasks.Task.Delay(800);
                        await ApplyLanRegistrationViaHttpAsync(repair: false);
                        // Segunda tentativa se o 1º POST cair no rebind do Kestrel
                        if (!LanRegisterOkExists() || !_healthLan)
                        {
                            await System.Threading.Tasks.Task.Delay(2000);
                            await ApplyLanRegistrationViaHttpAsync(repair: false);
                        }
                    }
                    catch { /* ignore */ }
                    finally { _elevatedRegisterPending = false; }
                });
            }
            catch (System.ComponentModel.Win32Exception ex) when (ex.NativeErrorCode == 1223)
            {
                _elevatedRegisterPending = false;
                _tray.ShowBalloonTip(4000, "SOMOSUM", "Permissao de administrador cancelada. Sem UAC a rede LAN nao abre.", ToolTipIcon.Warning);
            }
            catch (Exception ex)
            {
                _elevatedRegisterPending = false;
                _tray.ShowBalloonTip(5000, "SOMOSUM", "Falha ao pedir UAC: " + ex.Message, ToolTipIcon.Error);
            }
        }

        private static string ResolveSelfExePath(string root)
        {
            try
            {
                var processPath = Environment.ProcessPath;
                if (!string.IsNullOrEmpty(processPath)
                    && processPath.EndsWith(".exe", StringComparison.OrdinalIgnoreCase)
                    && File.Exists(processPath))
                    return processPath;
            }
            catch { /* ignore */ }

            try
            {
                var main = Process.GetCurrentProcess().MainModule?.FileName;
                if (!string.IsNullOrEmpty(main)
                    && main.EndsWith(".exe", StringComparison.OrdinalIgnoreCase)
                    && File.Exists(main))
                    return main;
            }
            catch { /* ignore */ }

            var candidates = new[]
            {
                Path.Combine(root ?? "", "app", "SOMOSUM.exe"),
                Path.Combine(AppContext.BaseDirectory ?? "", "SOMOSUM.exe"),
                Path.Combine(root ?? "", "SOMOSUM.exe"),
            };
            foreach (var c in candidates)
            {
                if (!string.IsNullOrEmpty(c) && File.Exists(c)) return c;
            }
            return null;
        }

        private void CopyUrl(string path)
        {
            _port = ReadPort();
            if (_port <= 0) _port = 8765;
            var url = string.Format(LocalServer.Scheme() + "://127.0.0.1:{0}/{1}", _port, path);
            try { Clipboard.SetText(url); _tray.ShowBalloonTip(2000, "SOMOSUM", "URL copiada.", ToolTipIcon.Info); }
            catch { }
        }

        private void CopyRemoteUrl()
        {
            _port = ReadPort();
            if (_port <= 0) _port = 8765;
            var token = ReadRemoteToken();
            var tq = string.IsNullOrWhiteSpace(token) ? "" : "?token=" + token;
            var url = string.Format(LocalServer.Scheme() + "://127.0.0.1:{0}/remote.html{1}", _port, tq);
            try { Clipboard.SetText(url); _tray.ShowBalloonTip(2000, "SOMOSUM", "URL Remote copiada.", ToolTipIcon.Info); }
            catch { }
        }

        private void OfferTrayHelpOnce()
        {
            var flag = Path.Combine(ContentLayout.DataDir(_root), ".tray-help-offered");
            if (File.Exists(flag)) return;
            try { File.WriteAllText(flag, DateTime.UtcNow.ToString("o")); } catch { }
            _tray.ShowBalloonTip(
                6000,
                "SOMOSUM",
                "O Painel Gerencial é a tela principal. Clique direito no icone para o menu completo.",
                ToolTipIcon.Info);
        }

        private void Bootstrap()
        {
            try
            {
                EngineHost.Instance.EnsureInitialized(_root);

                _port = ReadPort();
                // Exige ping + control.html  —  evita "servidor fantasma" na porta antiga.
                if (_port > 0 && ServerFullyReady(_port))
                {
                    _serverOk = true;
                    UpdateTrayText();
                    RunOnUi(() =>
                    {
                        OpenStartupWindows();
                        OfferDesktopShortcutOnce();
                        OfferProjectorSetupOnce();
                        OfferTrayHelpOnce();
                    });
                    return;
                }

                StartNcmServer();
                if (!WaitForServer(90))
                {
                    ShowError("Servidor Kestrel nao respondeu a tempo.\nVerifique logs\\somosum-*.log");
                    return;
                }

                _serverOk = true;
                UpdateTrayText();
                RunOnUi(() =>
                {
                    OpenStartupWindows();
                    OfferDesktopShortcutOnce();
                    OfferProjectorSetupOnce();
                    OfferTrayHelpOnce();
                });
            }
            catch (Exception ex)
            {
                ShowError("Erro ao iniciar: " + ex.Message);
            }
        }

        public void InvokeOpenScreen(int displayIndex)
        {
            RunOnUiAsync(() => InvokeOpenScreenCore(displayIndex));
        }

        public void InvokeOpenScreen2(int displayIndex)
        {
            RunOnUiAsync(() => InvokeOpenScreen2Core(displayIndex));
        }

        public void InvokeCloseProjection()
        {
            RunOnUi(InvokeCloseProjectionCore);
        }

        public void InvokeCloseProjection2()
        {
            RunOnUi(InvokeCloseProjection2Core);
        }

        public void InvokeToggleProjectionFullscreen()
        {
            RunOnUi(InvokeToggleProjectionFullscreenCore);
        }

        private void InvokeToggleProjectionFullscreenCore()
        {
#if !LEGACY_BUILD
            if (_projectionForm == null || _projectionForm.IsDisposed) return;
            _projectionForm.ToggleUserFullscreen();
#endif
        }

        /// <summary>Reaplica fullscreen do projetor (JS detectou meia-tela / drift DPI).</summary>
        public void InvokeRecoverProjectionLayout(bool force)
        {
            RunOnUiAsync(() =>
            {
#if !LEGACY_BUILD
                if (_projectionForm != null && !_projectionForm.IsDisposed && _projectionForm.Visible)
                    _projectionForm.RecoverProjectionLayout(forceReapply: force);
                if (_projectionForm2 != null && !_projectionForm2.IsDisposed && _projectionForm2.Visible)
                    _projectionForm2.RecoverProjectionLayout(forceReapply: force);
#endif
            });
        }

        private void InvokeCloseProjectionCore()
        {
#if !LEGACY_BUILD
            string deviceToRestore = null;
            try
            {
                var screens = DisplayHelper.GetAllDisplays();
                var idx = ResolveProjectorIndex(-1);
                if (idx >= 0 && idx < screens.Length)
                    deviceToRestore = screens[idx].DeviceName;
            }
            catch { /* ignore */ }

            if (_projectionForm != null && !_projectionForm.IsDisposed)
            {
                try
                {
                    _projectionForm.Hide();
                    _projectionForm.Close();
                }
                catch { /* ignore */ }
                try { _projectionForm.Dispose(); } catch { /* ignore */ }
            }
            _projectionForm = null;

            if (!string.IsNullOrEmpty(deviceToRestore) && _config.PreferNativeProjectorMode)
            {
                try { DisplayModeManager.RestoreMode(deviceToRestore); } catch { /* ignore */ }
            }
#endif
            try { _engineRelay?.Stop(); } catch { /* ignore */ }
        }

        /// <summary>
        /// Aplica resolução recomendada/nativa no monitor do projetor (secundário).
        /// </summary>
        private void TryApplyNativeProjectorMode(int displayIndex, bool allowFullscreen)
        {
            if (!_config.PreferNativeProjectorMode || !allowFullscreen) return;
            try
            {
                var infos = DisplayEnumerator.Enumerate(
                    _config.ProjectorDisplayIndex,
                    _config.StageDisplayIndex,
                    0,
                    _config.Projector2DisplayIndex);
                if (displayIndex < 0 || displayIndex >= infos.Length) return;
                var d = infos[displayIndex];
                if (d.Primary) return;
                var recW = d.RecommendedW > 0 ? d.RecommendedW : d.MaxW;
                var recH = d.RecommendedH > 0 ? d.RecommendedH : d.MaxH;
                var recHz = d.RecommendedHz > 0 ? d.RecommendedHz : d.CurrentHz;
                if (recW <= 0 || recH <= 0) return;
                if (d.CurrentW == recW && d.CurrentH == recH) return;
                // Só aplica se nativo/recomendado for razoável (≤ max) — nunca sobe para 1080 num SVGA
                if (d.MaxW > 0 && recW > d.MaxW) return;
                DisplayModeManager.ApplyMode(d.DeviceName, recW, recH, recHz);
            }
            catch { /* ignore — operador ainda vê projeção no modo atual */ }
        }

        private void InvokeCloseProjection2Core()
        {
#if !LEGACY_BUILD
            if (_projectionForm2 != null && !_projectionForm2.IsDisposed)
            {
                try
                {
                    _projectionForm2.Hide();
                    _projectionForm2.Close();
                }
                catch { /* ignore */ }
                try { _projectionForm2.Dispose(); } catch { /* ignore */ }
            }
            _projectionForm2 = null;
#endif
        }

        private int BeginProjectionOperation(bool second = false)
        {
            if (second)
                return System.Threading.Interlocked.Increment(ref _projection2Generation);
            return System.Threading.Interlocked.Increment(ref _projectionGeneration);
        }

        private bool IsProjectionGenerationCurrent(int generation, bool second = false)
        {
            return second ? generation == _projection2Generation : generation == _projectionGeneration;
        }

        private void SetProjectionState(ProjectionLifecycleState state, bool second = false)
        {
            if (second) _projection2State = state;
            else _projectionState = state;
        }

        private async Task WaitForDisplaySettleAsync(int generation, bool second = false)
        {
            SetProjectionState(ProjectionLifecycleState.WaitingDisplaySettle, second);
            DisplayEnumerator.InvalidateCache();
            await Task.Delay(450);
            if (!IsProjectionGenerationCurrent(generation, second)) return;
            DisplayEnumerator.InvalidateCache();
        }

        private async void InvokeOpenScreenCore(int displayIndex)
        {
            var generation = BeginProjectionOperation();
            SetProjectionState(ProjectionLifecycleState.Opening);
            NoteProjectionActivity();
            EnsureControlVisible(forceReload: false);
            _port = ReadPort();
            if (_port <= 0) _port = 8765;

            var screens = DisplayHelper.GetAllDisplays();
            if (screens.Length == 0) return;

            SetProjectionState(ProjectionLifecycleState.ResolvingTarget);
            var idx = ResolveProjectorIndex(displayIndex);
            var allowFullscreen = screens.Length > 1 && IsSecondaryProjectorIndex(idx);

            TryApplyNativeProjectorMode(idx, allowFullscreen);
            await WaitForDisplaySettleAsync(generation);
            if (!IsProjectionGenerationCurrent(generation)) return;

            // Bounds mudam após ChangeDisplaySettings — reenumerar
            screens = DisplayHelper.GetAllDisplays();
            idx = ResolveProjectorIndex(displayIndex);
            allowFullscreen = screens.Length > 1 && IsSecondaryProjectorIndex(idx);

            // 1 monitor: janela de teste (sem confirmacao) para validar antes do projetor.
            var autofs = allowFullscreen ? "autofs=1&" : "";
            var lite = "lite=1&production=1&";
            var url = string.Format(
                LocalServer.Scheme() + "://127.0.0.1:{0}/screen.html?{1}{2}v={3}",
                _port,
                autofs,
                lite,
                Uri.EscapeDataString(AppVersion));

#if !LEGACY_BUILD
            try
            {
                SetProjectionState(ProjectionLifecycleState.PlacingWindow);
                if (_projectionForm != null && !_projectionForm.IsDisposed && _projectionForm.IsInitialized)
                {
                    if (!IsProjectionGenerationCurrent(generation)) return;
                    _projectionForm.ApplyDisplay(idx, allowFullscreen);
                    _projectionForm.NavigateTo(url);
                    _projectionForm.Show();
                    return;
                }

                if (_projectionForm != null && !_projectionForm.IsDisposed)
                {
                    _projectionForm.Close();
                    _projectionForm.Dispose();
                }

                if (!IsProjectionGenerationCurrent(generation)) return;
                SetProjectionState(ProjectionLifecycleState.InitializingWebview);
                _projectionForm = new ProjectionForm(this, idx, "screen");
                await _projectionForm.InitializeAndShowAsync(url, allowFullscreen);
                if (!IsProjectionGenerationCurrent(generation)) return;
                SetProjectionState(ProjectionLifecycleState.SyncingViewport);
                BroadcastDisplaySnapshot();
                SetProjectionState(ProjectionLifecycleState.Ready);
                _engineRelay?.Start();
                return;
            }
            catch
            {
                if (allowFullscreen)
                    DisplayHelper.OpenScreenInBrowser(_root, _port, idx, AppVersion, kiosk: true, output: 1, deviceName: GetProjectorDeviceName());
                else
                    DisplayHelper.OpenScreenInBrowser(_root, _port, idx, AppVersion, kiosk: false, output: 1, deviceName: GetProjectorDeviceName());
            }
#else
            DisplayHelper.OpenScreenInBrowser(_root, _port, idx, AppVersion, kiosk: true, output: 1, deviceName: GetProjectorDeviceName());
#endif
        }

        private async void InvokeOpenScreen2Core(int displayIndex)
        {
            var generation = BeginProjectionOperation(second: true);
            SetProjectionState(ProjectionLifecycleState.Opening, second: true);
            NoteProjectionActivity();
            EnsureControlVisible(forceReload: false);
            _port = ReadPort();
            if (_port <= 0) _port = 8765;

            var screens = DisplayHelper.GetAllDisplays();
            if (screens.Length == 0) return;

            SetProjectionState(ProjectionLifecycleState.ResolvingTarget, second: true);
            var idx = ResolveProjector2Index(displayIndex);
            var allowFullscreen = screens.Length > 1 && IsSecondaryProjectorIndex(idx);

            TryApplyNativeProjectorMode(idx, allowFullscreen);
            await WaitForDisplaySettleAsync(generation, second: true);
            if (!IsProjectionGenerationCurrent(generation, second: true)) return;

            screens = DisplayHelper.GetAllDisplays();
            idx = ResolveProjector2Index(displayIndex);
            allowFullscreen = screens.Length > 1 && IsSecondaryProjectorIndex(idx);

            var autofs = allowFullscreen ? "autofs=1&" : "";
            var lite = "lite=1&production=1&";
            var url = string.Format(
                LocalServer.Scheme() + "://127.0.0.1:{0}/screen.html?output=2&{1}{2}v={3}",
                _port,
                autofs,
                lite,
                Uri.EscapeDataString(AppVersion));

#if !LEGACY_BUILD
            try
            {
                SetProjectionState(ProjectionLifecycleState.PlacingWindow, second: true);
                if (_projectionForm2 != null && !_projectionForm2.IsDisposed && _projectionForm2.IsInitialized)
                {
                    if (!IsProjectionGenerationCurrent(generation, second: true)) return;
                    _projectionForm2.ApplyDisplay(idx, allowFullscreen);
                    _projectionForm2.NavigateTo(url);
                    _projectionForm2.Show();
                    return;
                }

                if (_projectionForm2 != null && !_projectionForm2.IsDisposed)
                {
                    try { _projectionForm2.Close(); } catch { /* ignore */ }
                    try { _projectionForm2.Dispose(); } catch { /* ignore */ }
                    _projectionForm2 = null;
                }

                if (!IsProjectionGenerationCurrent(generation, second: true)) return;
                SetProjectionState(ProjectionLifecycleState.InitializingWebview, second: true);
                _projectionForm2 = new ProjectionForm(this, idx, "screen2");
                var form = _projectionForm2;
                form.FormClosed += (_, __) =>
                {
                    if (ReferenceEquals(_projectionForm2, form))
                        _projectionForm2 = null;
                };
                await form.InitializeAndShowAsync(url, allowFullscreen);
                if (!IsProjectionGenerationCurrent(generation, second: true)) return;
                SetProjectionState(ProjectionLifecycleState.SyncingViewport, second: true);
                BroadcastDisplaySnapshot();
                SetProjectionState(ProjectionLifecycleState.Ready, second: true);
                return;
            }
            catch
            {
                DisplayHelper.OpenScreenInBrowser(_root, _port, idx, AppVersion, kiosk: allowFullscreen, output: 2, deviceName: GetProjector2DeviceName());
            }
#else
            DisplayHelper.OpenScreenInBrowser(_root, _port, idx, AppVersion, kiosk: allowFullscreen, output: 2, deviceName: GetProjector2DeviceName());
#endif
        }

        public void InvokeOpenRemote()
        {
            RunOnUi(InvokeOpenRemoteCore);
        }

        private void InvokeOpenRemoteCore()
        {
            EnsureControlVisible(forceReload: false);
            _port = ReadPort();
            if (_port <= 0) _port = 8765;
            var token = ReadRemoteToken();
            var tq = string.IsNullOrWhiteSpace(token) ? "?v=" + AppVersion : "?token=" + Uri.EscapeDataString(token) + "&v=" + AppVersion;
            var url = string.Format(LocalServer.Scheme() + "://127.0.0.1:{0}/remote.html{1}", _port, tq);
#if !LEGACY_BUILD
            if (_remoteForm == null || _remoteForm.IsDisposed)
                _remoteForm = new RemoteForm(url, this);
            else
                _remoteForm.NavigateTo(url);

            _remoteForm.Show();
            _remoteForm.BringToFront();
#else
            OpenUrlFallback(url);
#endif
        }

        private string ReadRemoteToken()
        {
            try
            {
                var p = Path.Combine(ContentLayout.DataDir(_root), ".remote-token");
                if (File.Exists(p)) return File.ReadAllText(p).Trim();
            }
            catch { }
            return "";
        }

        private void OpenStartupWindows()
        {
            RunOnUi(OpenStartupWindowsCore);
        }

        private void OpenStartupWindowsCore()
        {
            // Hub gerencial é a janela principal do produto.
            OpenManagementPanelCore();
            if (_config.AutoOpenControl)
                EnsureControlVisible(forceReload: false);
            if (!ShouldAutoOpenProjection()) return;
            RunOnUiAsync(() =>
            {
                var delayTimer = new System.Windows.Forms.Timer { Interval = 2000 };
                delayTimer.Tick += (_, __) =>
                {
                    delayTimer.Stop();
                    delayTimer.Dispose();
                    if (_projectionForm == null || _projectionForm.IsDisposed || !_projectionForm.Visible)
                        InvokeOpenScreenCore(-1);
                };
                delayTimer.Start();
            });
        }

        /// <summary>
        /// Garante que o Controle está aberto e visível. Stage/Remote/Projeção sem Controle
        /// ficam eternamente em "Aguardando painel".
        /// </summary>
        private void EnsureControlVisible(bool forceReload = false)
        {
            _port = ReadPort();
            if (_port <= 0) _port = 8765;
            var url = string.Format(LocalServer.Scheme() + "://127.0.0.1:{0}/control.html?v={1}", _port, AppVersion);

#if !LEGACY_BUILD
            try
            {
                if (_controlForm == null || _controlForm.IsDisposed)
                {
                    _controlForm = new ControlForm(url, this);
                    _controlForm.Show();
                }
                else
                {
                    if (forceReload) _controlForm.NavigateTo(url);
                    _controlForm.ForceShow();
                }
                _controlForm.WindowState = FormWindowState.Normal;
                _controlForm.BringToFront();
                _controlForm.Activate();
                SchedulePreWarmProjectionWebView();
                return;
            }
            catch
            {
                DisplayHelper.OpenControlInBrowser(_port, AppVersion);
            }
#else
            DisplayHelper.OpenControlInBrowser(_port, AppVersion);
#endif
        }

        private void OpenControlWindow()
        {
            RunOnUi(() => EnsureControlVisible(forceReload: false));
        }

        private void OpenControlWindowCore()
        {
            EnsureControlVisible(forceReload: false);
        }

        private void OpenControlNativeWindow()
        {
            RunOnUi(() => EnsureControlVisible(forceReload: false));
        }

        private void OpenControlNativeWindowCore()
        {
            EnsureControlVisible(forceReload: false);
        }

        private void SchedulePreWarmProjectionWebView()
        {
#if !LEGACY_BUILD
            RunOnUiAsync(async () =>
            {
                try
                {
                    await Task.Delay(5000);
                    await WebView2Helper.GetEnvironmentAsync(_root);
                }
                catch { /* best-effort */ }
            });
#endif
        }

        private void OpenScreenWindow()
        {
            InvokeOpenScreen(-1);
        }

        private void ConfigureProjector()
        {
            var idx = DisplayHelper.PromptProjectorDisplay(null);
            _config.ProjectorDisplayIndex = idx;
            AppConfig.SaveProjectorIndex(_root, idx);
            _tray.ShowBalloonTip(3000, "SOMOSUM", "Monitor do projetor salvo.", ToolTipIcon.Info);
        }

        private void OfferProjectorSetupOnce()
        {
            var flag = Path.Combine(ContentLayout.DataDir(_root), ".projector-configured");
            if (File.Exists(flag)) return;
            if (DisplayHelper.GetAllDisplays().Length <= 1) return;

            try { File.WriteAllText(flag, DateTime.UtcNow.ToString("o")); } catch { }

            var result = SomosumDialog.Confirm(
                null,
                "Foram detectados vários monitores.\n\nDeseja configurar qual é o projetor agora?",
                "Configurar projetor",
                "Configurar",
                "Agora não");
            if (result == DialogResult.Yes)
                ConfigureProjector();
        }

        public void OpenUrlFallback(string url)
        {
            try
            {
                Process.Start(new ProcessStartInfo(url) { UseShellExecute = true });
            }
            catch
            {
                Process.Start("cmd.exe", "/c start \"\" \"" + url + "\"");
            }
        }

        private void OpenUrl(string path)
        {
            _port = ReadPort();
            if (_port <= 0) _port = 8765;
            OpenUrlFallback(string.Format(LocalServer.Scheme() + "://127.0.0.1:{0}/{1}?v={2}", _port, path, AppVersion));
        }

        private Icon LoadAppIcon()
        {
            var candidates = new[]
            {
                Path.Combine(ContentLayout.LauncherDir(_root), "somosum.ico"),
                Path.Combine(_root, ContentLayout.ViewDir, "IMG", "LOGO", "somosum.ico"),
                Path.Combine(_root, "SOMOSUM.exe")
            };
            foreach (var path in candidates)
            {
                if (!File.Exists(path)) continue;
                try
                {
                    if (path.EndsWith(".ico", StringComparison.OrdinalIgnoreCase))
                        return new Icon(path);
                    var assoc = Icon.ExtractAssociatedIcon(path);
                    if (assoc != null) return assoc;
                }
                catch { }
            }
            return null;
        }

        private void OfferDesktopShortcutOnce()
        {
            var flag = Path.Combine(ContentLayout.DataDir(_root), ".shortcut-offered");
            if (File.Exists(flag)) return;
            try { File.WriteAllText(flag, DateTime.UtcNow.ToString("o")); } catch { }
            if (DesktopShortcutExists()) return;

            var result = SomosumDialog.Confirm(
                null,
                "Deseja criar um atalho do SOMOSUM na Área de Trabalho?",
                "Atalho na Área de Trabalho",
                "Criar atalho",
                "Agora não");
            if (result == DialogResult.Yes)
                CreateDesktopShortcut(true);
        }

        private bool DesktopShortcutExists()
        {
            var desktop = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
            return File.Exists(Path.Combine(desktop, "SOMOSUM.lnk"));
        }

        private void CreateDesktopShortcut(bool silent)
        {
            try
            {
                var exe = Assembly.GetExecutingAssembly().Location;
                if (string.IsNullOrEmpty(exe) || !File.Exists(exe))
                    exe = Path.Combine(_root, "app", "SOMOSUM.exe");
                if (!File.Exists(exe))
                    exe = Path.Combine(_root, "SOMOSUM.exe");
                if (!File.Exists(exe))
                    throw new InvalidOperationException("SOMOSUM.exe nao encontrado.");

                var desktop = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
                var lnkPath = Path.Combine(desktop, "SOMOSUM.lnk");

                var shellType = Type.GetTypeFromProgID("WScript.Shell");
                if (shellType == null)
                    throw new InvalidOperationException("WScript.Shell indisponivel.");
                dynamic wsh = Activator.CreateInstance(shellType);
                var shortcut = wsh.CreateShortcut(lnkPath);
                shortcut.TargetPath = exe;
                shortcut.WorkingDirectory = _root;
                shortcut.Description = "SOMOSUM — Painel Gerencial e projecao para igrejas";
                var ico = Path.Combine(ContentLayout.LauncherDir(_root), "somosum.ico");
                if (!File.Exists(ico))
                    ico = Path.Combine(_root, ContentLayout.ViewDir, "IMG", "LOGO", "somosum.ico");
                shortcut.IconLocation = File.Exists(ico) ? (ico + ",0") : (exe + ",0");
                shortcut.Save();

                _tray.ShowBalloonTip(4000, "SOMOSUM", "Atalho criado na Area de Trabalho.", ToolTipIcon.Info);
            }
            catch (Exception ex)
            {
                if (!silent) ShowError("Erro ao criar atalho: " + ex.Message);
            }
        }

        public void InvokeCreateDesktopShortcut()
        {
            RunOnUi(() => CreateDesktopShortcut(false));
        }

        private void StartNcmServer()
        {
            if (_ncmStarting) return;
            _ncmStarting = true;
            ThreadPool.QueueUserWorkItem(_ =>
            {
                try
                {
                    NetworkConnectivityManager.Instance.StartAsync(_root).GetAwaiter().GetResult();
                }
                catch (Exception ex)
                {
                    RunOnUiAsync(() => ShowError("Falha ao iniciar NCM: " + ex.Message));
                }
                finally
                {
                    _ncmStarting = false;
                }
            });
        }

        private void StartServerHidden()
        {
            StartNcmServer();
        }

        private bool WaitForServer(int timeoutSec)
        {
            var deadline = DateTime.UtcNow.AddSeconds(timeoutSec);
            var okStreak = 0;
            while (DateTime.UtcNow < deadline)
            {
                _port = ReadPort();
                if (_port > 0 && ServerFullyReady(_port))
                {
                    okStreak++;
                    if (okStreak >= 2) return true;
                }
                else okStreak = 0;
                Thread.Sleep(500);
            }
            return false;
        }

        private bool ServerFullyReady(int port)
        {
            if (!PingServer(port)) return false;
            try
            {
                var req = LocalServer.CreateLocalRequest(port, "/control.html");
                req.Method = "GET";
                req.Timeout = 3000;
                req.ReadWriteTimeout = 3000;
                using (var res = (HttpWebResponse)req.GetResponse())
                    return (int)res.StatusCode >= 200 && (int)res.StatusCode < 400;
            }
            catch { return false; }
        }

        private int ReadPort()
        {
            try
            {
                var portFile = Path.Combine(ContentLayout.DataDir(_root), ".port");
                if (!File.Exists(portFile)) return 8765;
                int port;
                return int.TryParse(File.ReadAllText(portFile).Trim(), out port) && port > 0 ? port : 8765;
            }
            catch { return 8765; }
        }

        private bool PingServer(int port)
        {
            try
            {
                var req = LocalServer.CreateLocalRequest(port, "/api/ping");
                req.Method = "GET";
                req.Timeout = 2500;
                req.ReadWriteTimeout = 2500;
                using (var res = (HttpWebResponse)req.GetResponse())
                using (var sr = new StreamReader(res.GetResponseStream()))
                    return sr.ReadToEnd().Trim() == "ok";
            }
            catch { return false; }
        }

        private void UpdateStatus()
        {
            _port = ReadPort();
            _serverOk = _port > 0 && PingServer(_port);
            if (_serverOk)
            {
                FetchHealthBrief();
            }
            else if (!_serverOk && !_serverRecoveryPending)
            {
                _serverRecoveryPending = true;
                ThreadPool.QueueUserWorkItem(_ =>
                {
                    try
                    {
                        StartNcmServer();
                        if (WaitForServer(30))
                            _serverOk = true;
                    }
                    catch { /* ignore */ }
                    finally
                    {
                        _serverRecoveryPending = false;
                        RunOnUiAsync(UpdateTrayText);
                    }
                });
            }
            UpdateTrayText();
        }

        private void FetchHealthBrief()
        {
            try
            {
                var req = LocalServer.CreateLocalRequest(_port, "/api/health");
                req.Method = "GET";
                req.Timeout = 2000;
                using (var res = (HttpWebResponse)req.GetResponse())
                using (var sr = new StreamReader(res.GetResponseStream()))
                {
                    var json = sr.ReadToEnd();
                    _healthLan = json.IndexOf("\"lanMode\":true", StringComparison.OrdinalIgnoreCase) >= 0;
                    _healthReady = json.IndexOf("\"readyForService\":true", StringComparison.OrdinalIgnoreCase) >= 0;
                }
            }
            catch
            {
                _healthReady = false;
            }
        }

        private void UpdateTrayText()
        {
            if (_tray == null) return;
            if (!_serverOk)
            {
                _tray.Text = "SOMOSUM — servidor offline";
                return;
            }
            var lan = _healthLan ? "LAN" : "local";
            var ready = _healthReady ? "pronto" : "aguarde";
            _tray.Text = string.Format("SOMOSUM — :{0} {1} ({2})", _port, lan, ready);
        }

        private void OpenFolder(string path)
        {
            if (Directory.Exists(path))
                Process.Start("explorer.exe", path);
        }

        private void RestartServer()
        {
            _port = ReadPort();
            if (_port > 0 && PingServer(_port))
            {
                try
                {
                    var req = LocalServer.CreateLocalRequest(_port, "/api/restart-worker");
                    req.Method = "GET";
                    req.Timeout = 4000;
                    using (var res = (HttpWebResponse)req.GetResponse()) { res.Close(); }
                }
                catch { /* ignore */ }

                if (WaitForServer(90))
                {
                    _serverOk = true;
                    UpdateTrayText();
                    _tray.ShowBalloonTip(3000, "SOMOSUM", "Servidor reiniciado.", ToolTipIcon.Info);
                    return;
                }
            }

            try
            {
                NetworkConnectivityManager.Instance.RestartServerAsync().GetAwaiter().GetResult();
                if (WaitForServer(60))
                {
                    _serverOk = true;
                    UpdateTrayText();
                    _tray.ShowBalloonTip(3000, "SOMOSUM", "Servidor reiniciado (NCM).", ToolTipIcon.Info);
                    return;
                }
            }
            catch { /* ignore */ }

            ShowError("Falha ao reiniciar o servidor.");
        }

        private void RunEncerrar()
        {
            // Nunca bloquear a UI thread com Wait infinito (causa "travar ao encerrar")
            try
            {
                var stop = Task.Run(() => NetworkConnectivityManager.Instance.StopAsync());
                if (!stop.Wait(TimeSpan.FromSeconds(2)))
                {
                    /* timeout  —  segue o encerramento */
                }
            }
            catch { /* ignore */ }

            var selfId = Process.GetCurrentProcess().Id;
            foreach (var name in new[] { "SOMOSUM", "SOMOSUM-Remote" })
            {
                try
                {
                    foreach (var p in Process.GetProcessesByName(name))
                    {
                        try
                        {
                            if (p.Id == selfId) continue;
                            p.Kill(true);
                        }
                        catch { /* ignore */ }
                        finally { try { p.Dispose(); } catch { } }
                    }
                }
                catch { /* ignore */ }
            }
        }

        private void NoteProjectionActivity()
        {
            _lastProjectionActivityUtc = DateTime.UtcNow;
        }

        /// <summary>
        /// Low-Spec Pro: GC Gen0 otimizado apos 10 min idle (nunca Gen2 forcado em culto live).
        /// </summary>
        private void TryIdleSoftGc()
        {
            try
            {
                if (_cultoLiveHint) return;
                var idle = DateTime.UtcNow - _lastProjectionActivityUtc;
                if (idle.TotalMinutes < 10) return;
                GC.Collect(0, GCCollectionMode.Optimized, false);
                _lastProjectionActivityUtc = DateTime.UtcNow;
            }
            catch { /* ignore */ }
        }

        private void OpenGuide()
        {
            var path = Path.Combine(_root, "LEIA-ME.txt");
            if (!File.Exists(path)) path = Path.Combine(_root, "COMO-USAR.txt");
            if (File.Exists(path)) Process.Start("notepad.exe", path);
            else SomosumDialog.Info(null, "LEIA-ME.txt não encontrado.", "Documentação");
        }

        private void Shutdown()
        {
            if (SomosumDialog.ConfirmDanger(
                null,
                "Encerrar o SOMOSUM e liberar a porta?\n\nTelas e o servidor local serão fechados.",
                "Encerrar SOMOSUM",
                "Encerrar",
                "Cancelar") != DialogResult.Yes)
                return;

            try { _statusTimer.Stop(); } catch { }
            try { _idleGcTimer?.Stop(); } catch { }
            try { SystemEvents.DisplaySettingsChanged -= OnDisplaySettingsChanged; } catch { }

            // Esconder bandeja cedo (feedback imediato)
            try { _tray.Visible = false; } catch { }

            RunEncerrar();

            if (_serverProcess != null && !_serverProcess.HasExited)
            {
                try { _serverProcess.Kill(true); } catch { }
            }

#if !LEGACY_BUILD
            // Fechar janelas WebView2 sem esperar eventos que possam travar
            foreach (var form in new Form[] {
                _controlForm, _remoteForm, _managementForm, _diagnosticsForm, _docsForm, _auxForm,
                _projectionForm, _projectionForm2, _stageForm
            })
            {
                try
                {
                    if (form == null || form.IsDisposed) continue;
                    form.Hide();
                    form.Dispose();
                }
                catch { /* ignore */ }
            }
            _controlForm = null;
            _remoteForm = null;
            _managementForm = null;
            _diagnosticsForm = null;
            _docsForm = null;
            _auxForm = null;
            _projectionForm = null;
            _projectionForm2 = null;
            _stageForm = null;
#endif
            try { _tray.Dispose(); } catch { }
            try { if (_mutex != null) { _mutex.ReleaseMutex(); _mutex.Dispose(); } } catch { }

            // Application.Exit as vezes nao finaliza com WebView2 preso  —  forçar saída
            try { Application.Exit(); } catch { }
            Environment.Exit(0);
        }

        private void ShowError(string message)
        {
            RunOnUi(() =>
            {
                _tray.ShowBalloonTip(8000, "SOMOSUM — erro", message, ToolTipIcon.Error);
                SomosumDialog.Warn(null, message, "SOMOSUM — erro");
            });
        }

        /// <summary>
        /// EXE pode ficar em app/ (runtime .NET). Conteúdo (control.html, data/, js/) fica na pasta do projeto.
        /// </summary>
        private static string ResolveContentRoot(string assemblyDir)
        {
            var dir = assemblyDir;
            for (var i = 0; i < 5 && !string.IsNullOrEmpty(dir); i++)
            {
                var control = Somosum.Core.ContentLayout.ControlHtmlPath(dir);
                var data = Somosum.Core.ContentLayout.DataDir(dir);
                if (File.Exists(control) && Directory.Exists(data))
                    return dir;
                dir = Path.GetDirectoryName(dir);
            }
            return assemblyDir;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (_tray != null) { _tray.Visible = false; _tray.Dispose(); }
                if (_appIcon != null) { _appIcon.Dispose(); }
                if (_statusTimer != null) _statusTimer.Dispose();
                if (_idleGcTimer != null) _idleGcTimer.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
