﻿using Somosum.Core;
using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using Microsoft.Web.WebView2.Core;

namespace SomosumLauncher
{
    internal static class WebView2Helper
    {
        private static readonly object Gate = new object();
        private static readonly Dictionary<string, CoreWebView2Environment> Environments =
            new Dictionary<string, CoreWebView2Environment>(StringComparer.OrdinalIgnoreCase);
        private static readonly Dictionary<string, Task<CoreWebView2Environment>> Pending =
            new Dictionary<string, Task<CoreWebView2Environment>>(StringComparer.OrdinalIgnoreCase);

        /// <summary>
        /// Ambiente WebView2 por perfil. Stage usa pasta separada para
        /// não derrubar o Control quando a superfície Stage falha ao inicializar.
        /// </summary>
        public static Task<CoreWebView2Environment> GetEnvironmentAsync(string root, string profile = "main")
        {
            var key = string.IsNullOrWhiteSpace(profile) ? "main" : profile.Trim().ToLowerInvariant();
            lock (Gate)
            {
                if (Environments.TryGetValue(key, out var existing) && existing != null)
                    return Task.FromResult(existing);
                if (Pending.TryGetValue(key, out var pending) && pending != null)
                    return pending;

                var task = CreateEnvironmentAsync(root, key);
                Pending[key] = task;
                return task;
            }
        }

        private static async Task<CoreWebView2Environment> CreateEnvironmentAsync(string root, string profile)
        {
            try
            {
                var folderName = profile == "main" ? ".webview2" : (".webview2-" + profile);
                var userData = Path.Combine(ContentLayout.DataDir(root), folderName);
                try { Directory.CreateDirectory(userData); } catch { /* best-effort */ }

                var options = new CoreWebView2EnvironmentOptions(
                    "--autoplay-policy=no-user-gesture-required "
                    + "--enable-gpu-rasterization "
                    + "--ignore-gpu-blocklist "
                    + "--disable-features=CalculateNativeWinOcclusion");
                var env = await CoreWebView2Environment.CreateAsync(null, userData, options);
                lock (Gate)
                {
                    Environments[profile] = env;
                    Pending.Remove(profile);
                }
                return env;
            }
            catch
            {
                lock (Gate) { Pending.Remove(profile); }
                throw;
            }
        }

        /// <summary>
        /// Garante autoplay de vídeo mudo na projeção (fundos animados do culto).
        /// </summary>
        public static void GrantAutoplayPermission(CoreWebView2 core)
        {
            if (core == null) return;
            core.PermissionRequested += (_, args) =>
            {
                if (args.PermissionKind == CoreWebView2PermissionKind.Autoplay)
                {
                    args.State = CoreWebView2PermissionState.Allow;
                    args.Handled = true;
                }
            };
        }
    }
}
