using System;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using Microsoft.Web.WebView2.WinForms;

namespace SomosumLauncher
{
    internal static class DpiHelper
    {
        private enum MonitorDpiType { Effective = 0, Angular = 1, Raw = 2 }

        [StructLayout(LayoutKind.Sequential)]
        private struct POINT
        {
            public int X;
            public int Y;
        }

        [DllImport("user32.dll")]
        private static extern IntPtr MonitorFromPoint(POINT pt, uint dwFlags);

        [DllImport("Shcore.dll")]
        private static extern int GetDpiForMonitor(IntPtr hmonitor, MonitorDpiType dpiType, out uint dpiX, out uint dpiY);
        public static void ConfigureForm(Form form)
        {
            if (form == null) return;
            form.AutoScaleMode = AutoScaleMode.Dpi;
            form.AutoScaleDimensions = new SizeF(96F, 96F);
        }

        /// <summary>
        /// Projeção/Stage em monitor secundário: AutoScale Dpi + Maximized = meia tela (PerMonitorV2).
        /// Sempre None + Bounds manuais.
        /// </summary>
        public static void ConfigureProjectionForm(Form form)
        {
            if (form == null) return;
            form.AutoScaleMode = AutoScaleMode.None;
            form.AutoScaleDimensions = new SizeF(96F, 96F);
        }

        public static void ConfigureWebView(WebView2 web, Form host)
        {
            if (web?.CoreWebView2 == null || host == null) return;
            try
            {
                web.ZoomFactor = 1.0;
                web.CoreWebView2.Settings.IsZoomControlEnabled = false;
            }
            catch { /* optional */ }
        }

        public static void SyncProjectionRasterization(WebView2 web, Screen screen)
        {
            if (web == null) return;
            try { web.ZoomFactor = 1.0; } catch { /* */ }
        }

        public static float GetSystemDpi()
        {
            try
            {
                using (var g = Graphics.FromHwnd(IntPtr.Zero))
                    return g.DpiX;
            }
            catch
            {
                return 96f;
            }
        }

        public static double GetDpiScaleForScreen(Screen screen)
        {
            if (screen == null) return 1.0;
            try
            {
                var center = screen.Bounds;
                var pt = new POINT
                {
                    X = center.X + center.Width / 2,
                    Y = center.Y + center.Height / 2,
                };
                var hmon = MonitorFromPoint(pt, 2);
                if (hmon != IntPtr.Zero && GetDpiForMonitor(hmon, MonitorDpiType.Effective, out uint dpiX, out _) == 0)
                    return dpiX / 96.0;
            }
            catch { /* fallback */ }
            try
            {
                using (var g = Graphics.FromHwnd(IntPtr.Zero))
                    return g.DpiX / 96.0;
            }
            catch
            {
                return 1.0;
            }
        }

        public static Rectangle EnsureWindowOnScreen(Rectangle bounds, Screen screen)
        {
            if (screen == null) return bounds;
            var area = screen.WorkingArea;
            var w = Math.Min(bounds.Width, area.Width);
            var h = Math.Min(bounds.Height, area.Height);
            var x = Math.Max(area.X, Math.Min(bounds.X, area.X + area.Width - w));
            var y = Math.Max(area.Y, Math.Min(bounds.Y, area.Y + area.Height - h));
            return new Rectangle(x, y, w, h);
        }
    }
}
