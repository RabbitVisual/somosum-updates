# SOMOSUM — Como o sistema funciona hoje (v8.8.12)

> Documento operacional — julho/2026. Descreve o comportamento **real** do código em produção.

---

## Visão geral

O SOMOSUM é um sistema **100% offline** de projeção para cultos.

| Camada | Tecnologia |
|--------|------------|
| Launcher / Painel | `SOMOSUM.exe` (.NET 8 + WebView2) |
| Servidor HTTP | **Kestrel in-process** — porta em `model/data/.port` (padrão 8765) |
| Frontend | ES modules nativos em `controller/js/` (sem bundler) |
| Persistência | JSON atômico + WAL + backups em `model/data/` |
| Sync Controle ↔ Projeção | WebSocket `/ws/sync` + HTTP (fallback) |
| Layout | MVC: `model/` · `view/` · `controller/` (URLs públicas estáveis) |
| Versão canônica | arquivo `VERSION` na raiz (`8.8.12`) |

---

## Janelas e superfícies

| Superfície | URL | Função |
|------------|-----|--------|
| **Painel Gerencial** | `/launcher/panel.html` | Hub: culto neste PC — 10 seções, CTAs, LAN, monitores, Loja, backup, igreja, Sobre |
| **Controle** | `/control.html` | Culto ao vivo: ordem, projeção, bibliotecas, Designer, plugins · tour **?** |
| **Projeção** | `/screen.html` | Tela do projetor |
| **Stage** | `/stage.html` | Púlpito / músicos — Central Stage (monitor + tela cheia + Pregador) |
| **Remote** | `/remote.html` | Celular na mesma Wi‑Fi |
| **Docs** | `/docs/` | Manual embutido (Markdown offline) |

O EXE abre o **Painel** primeiro; ícone na bandeja mantém o serviço vivo.

### Divisão de responsabilidades

| Quem | Responsabilidade |
|------|------------------|
| **Painel Gerencial** | Abrir telas, Loja, rede/PIN, monitores, desempenho, backup, igreja, versão/novidades |
| **Controle** | Ordem do culto, projeção ao vivo, bibliotecas, Designer, plugins, preferências de culto |

### Painel Gerencial (8.7.9)

**Culto**
- **Início** — checklist e atalhos do culto
- **Telas** — abrir Controle, Projeção, Púlpito e Remote
- **Loja** — recursos extras / plugins

**Este computador**
- **Rede** — Wi‑Fi, código e celular/tablet
- **Operação** — status neste PC
- **Monitores** — Projetor 1 e 2
- **Desempenho** — CPU e memória
- **Dados** — cópia de segurança e pastas

**Igreja e ajuda**
- **Igreja** — nome, logo e fundo das boas-vindas
- **Sobre** — versão ao vivo, novidades da release e mapa clicável de todas as seções

Topbar: switch **claro/escuro** do chrome operador (não altera a atmosfera da projeção).

### Tema chrome claro / escuro

| Eixo | Onde muda | Preferência |
|------|-----------|-------------|
| **Chrome operador** | Painel, shell do Controle, chrome Stage/Remote | `prefs.ui.chromeTheme` |
| **Atmosfera de projeção** | Screen + prévia 16:9 | Ajustes → Projeção (`projectionTheme`) |

---

## Atualização do sistema (8.8.0)

1. Painel → **Sobre** → **Procurar novidades** (ou Controle → Ajustes → Sistema / Ajuda → Verificar atualização).
2. Baixa o pacote leve do canal (delta enxuto — sem áudio/packs).
3. Mostra **Atualização concluída** e pede confirmação para reiniciar.
4. Ao confirmar: aplica, limpa temp, fecha e **reabre sozinho**.
5. Na reabertura: tela de boas-vindas com o que mudou + versão.

No EXE, Controle ↔ Projetor usa **ponte nativa local** (slides sem esperar rede); Remote/Stage na LAN continuam via WebSocket.

Guia: [`atualizacao.md`](atualizacao.md).

---

## Plugins de culto (API 2 / Plugin Studio)

Oito plugins de fábrica. Fluxo:

1. **Ajustes → Plugins** ou **Painel → Loja**
2. Menu lateral → ícone do plugin (quando ligado) → Plugin Studio
3. **Mais → Configurar plugins** — saúde / quarantine

Guia: [`plugins.md`](plugins.md).

---

## Operar o culto (Controle)

1. Abra **Controle** (Painel → Telas ou bandeja).
2. Monte a **ordem** no console Ao vivo.
3. Com **Ao vivo** ligado, avance os slides — a projeção espelha.
4. Tecla **?** = tour guiado (v11) · **D** = documentação.
5. Bíblia na ordem: avance os versículos como slides.

---

## Rede local (LAN / QR)

1. Painel → **Rede** → **Modo LAN**.
2. **Preparar rede (admin)** e confirme o UAC.
3. Aguarde o badge **LAN pronta** com o IP Wi‑Fi (não `127.0.0.1`). O sistema testa o acesso antes de liberar o QR.
4. Escaneie o QR no celular/tablet na **mesma Wi‑Fi** (não use rede convidado).

---

## Backup

Painel → **Dados** ou Controle → Ajustes → Backup. Dados em `model/data/`.

---

## Tour guiado (v11)

- Tecla **?** · Ajuda → Tour guiado · Ajustes → Sistema
- Passos curtos, linguagem do operador (sem jargão técnico)
- Cobre: Painel × Controle, Ao vivo, ordem, teclado, prévia, Púlpito, Bíblia, louvores, Cultos/Designer, Pré-culto, Plugins/Ajustes, Sobre no Painel
