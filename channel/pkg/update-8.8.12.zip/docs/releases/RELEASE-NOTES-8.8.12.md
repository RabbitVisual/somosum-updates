# Release Notes — SOMOSUM 8.8.12

**Data:** 2026-08-19  
**Tipo:** Modo LAN desliga de verdade + rede só neste PC

## Destaques

### Rede da igreja (Modo LAN)
- Desligar o Modo LAN **grava no servidor** e fecha o acesso Wi‑Fi. Ao sair da aba e voltar, continua desligado.
- Controle e projeção **neste PC** seguem funcionando (não depende do Wi‑Fi).
- Ligar de novo prepara a rede, confirma o Windows se pedir, e só então libera QR para celular/tablet.

## Como atualizar
1. Em **8.8.11**: Ajuda → Verificar atualização → **8.8.12** → confirme o reinício.
2. Se estiver atrás: suba de 1 em 1 até **8.8.12**.

## Verificação rápida
- [ ] Sobre = **8.8.12**
- [ ] Ligar Modo LAN → QR com IP da Wi‑Fi
- [ ] Desligar → toast de desativado → sair da aba Rede e voltar: interruptor **desligado**
