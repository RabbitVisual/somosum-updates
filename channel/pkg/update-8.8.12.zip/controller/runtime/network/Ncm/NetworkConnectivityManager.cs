﻿using Somosum.Core;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using Somosum.Network.Engine.Core;
using Somosum.Network.Engine.Ncm;
using Somosum.Server;
using Somosum.Server.Sync;
using Somosum.Security;
using Somosum.Storage;

namespace Somosum.Network.Engine.Ncm
{
    /// <summary>
    /// Network Connectivity Manager — único ponto de acesso a rede, servidor HTTP e WebSocket.
    /// </summary>
    public sealed class NetworkConnectivityManager : IDisposable
    {
        private static readonly Lazy<NetworkConnectivityManager> Lazy =
            new Lazy<NetworkConnectivityManager>(() => new NetworkConnectivityManager());

        public static NetworkConnectivityManager Instance => Lazy.Value;

        private readonly object _gate = new object();
        private readonly NetworkEngineHost _engine = NetworkEngineHost.Instance;
        private KestrelHostService _kestrel;
        private SyncMessageStore _syncStore;
        private SyncWebSocketHub _wsHub;
        private StorageApiHandler _storage;
        private StreamApiHandler _stream;
        private PinAuthService _pinAuth;
        private string _rootPath = "";
        private int _port;
        private bool _lanMode;
        private bool _lanBindOk;
        private bool _lanBindIntent;
        private bool _lanTls;
        private bool _started;
        private int _lanEpoch;
        private NetworkGuaranteeSnapshot _guarantee = new NetworkGuaranteeSnapshot();

        private NetworkConnectivityManager() { }

        public string RootPath => _rootPath;
        public int Port => _port;
        public bool LanMode => _lanMode;
        public int LanEpoch => _lanEpoch;
        public bool LanBindOk => _lanBindOk;
        /// <summary>Intent durante rebind: Kestrel escuta AnyIP antes da prova.</summary>
        public bool LanBindIntent => _lanBindIntent;
        public bool ShouldListenAnyIp => _lanBindOk || _lanBindIntent;
        public bool TlsEnabled => _lanTls;
        public string Scheme => _lanTls ? "https" : "http";
        public bool IsServerRunning => _kestrel?.IsRunning == true;
        public NetworkGuaranteeSnapshot Guarantee => _guarantee;
        public SyncMessageStore SyncStore => _syncStore;
        public SyncWebSocketHub WebSocketHub => _wsHub;
        public StorageApiHandler StorageHandler => _storage;
        public StreamApiHandler StreamHandler => _stream;
        public PinAuthService PinAuth => _pinAuth;

        public Dictionary<string, object> ValidateSession(string token) =>
            _engine.ValidateSession(token ?? "");

        public async Task StartAsync(string rootPath, CancellationToken ct = default)
        {
            lock (_gate)
            {
                if (_started) return;
                _rootPath = rootPath ?? "";
                _engine.EnsureInitialized(_rootPath);
                LoadConfig();
                _port = ReadPortFile();
                if (_port <= 0)
                    _port = PortSelector.SelectAvailablePort();
                EnsureDataDirs();
                _syncStore = new SyncMessageStore(ContentLayout.DataDir(_rootPath));
                _wsHub = new SyncWebSocketHub(_syncStore);
                _storage = new StorageApiHandler(_rootPath);
                _stream = new StreamApiHandler();
                _pinAuth = new PinAuthService(_engine);
                _pinAuth.GetOrRotatePin(5);
                _kestrel = new KestrelHostService(this);
                _started = true;
            }

            await EnsurePortReadyAsync();
            await TryRegisterLanAsync();
            // Fundos: se system/media estiver vazio, extrai packs locais (hot-fix vídeo)
            try
            {
                var mediaHeal = new MediaPackInstallService(_rootPath).EnsureLocalPacksIfEmpty();
                if (mediaHeal != null && mediaHeal.TryGetValue("ok", out var okObj) && okObj is bool ok && ok
                    && mediaHeal.TryGetValue("skipped", out var sk) && sk is bool skipped && !skipped)
                {
                    System.Diagnostics.Debug.WriteLine("[SOMOSUM] system/media restored from local packs");
                }
            }
            catch { /* best-effort */ }
            await _kestrel.StartAsync(ct);
            WritePortFile(_port);
            WriteHealthFile();
            _engine.UpdateRuntimeState(_port, _lanMode, _lanBindOk);

            // Após escutar: comprovar IP LAN (ou demover Intent).
            if (_lanMode)
            {
                _ = Task.Run(async () =>
                {
                    try
                    {
                        await Task.Delay(600).ConfigureAwait(false);
                        await NetworkGuaranteeService.EnsureReadyAsync(this, forceRebind: false)
                            .ConfigureAwait(false);
                    }
                    catch { /* boot best-effort */ }
                });
            }
        }

        private Task EnsurePortReadyAsync()
        {
            _port = ReadPortFile();
            if (_port <= 0) _port = PortSelector.SelectAvailablePort();
            WritePortFile(_port);
            return Task.CompletedTask;
        }

        public async Task StopAsync()
        {
            if (_kestrel != null)
                await _kestrel.StopAsync();
            lock (_gate) { _started = false; }
        }

        public async Task RestartServerAsync()
        {
            if (_kestrel == null) return;
            await _kestrel.RestartAsync();
            WriteHealthFile();
            _engine.UpdateRuntimeState(_port, _lanMode, _lanBindOk);
        }

        public async Task HandleNetworkRebindAsync()
        {
            _engine.SignalRebind();
            await _wsHub.BroadcastNetworkRebindAsync();
            await RestartServerAsync();
        }

        public Dictionary<string, object> GetStatusPayload()
        {
            var status = _engine.GetStatus();
            status["version"] = ReadAppVersion(_rootPath);
            status["ncm"] = "2.0";
            status["serverRunning"] = IsServerRunning;
            status["websocketClients"] = _wsHub?.ClientCount ?? 0;
            status["qrReady"] = QrReadinessGate.Evaluate(this).Ready;
            return status;
        }

        public Dictionary<string, object> Discover() => _engine.Discover();

        public Dictionary<string, object> BuildQrPayload()
        {
            // Preferir sempre URL com .remote-token (lan-info) — consistente com sync/API.
            if (_lanBindOk && _port > 0)
            {
                var lan = BuildLanInfo(true);
                if (lan.TryGetValue("remoteUrl", out var remote) && remote is string url && !string.IsNullOrWhiteSpace(url))
                {
                    _pinAuth.GetOrRotatePin(5);
                    var readiness = QrReadinessGate.Evaluate(this);
                    return new Dictionary<string, object>
                    {
                        ["ok"] = true,
                        ["url"] = url,
                        ["stageUrl"] = lan.ContainsKey("stageUrl") ? lan["stageUrl"] : null,
                        ["source"] = "lan-info",
                        ["blockers"] = readiness.Blockers,
                        ["warning"] = readiness.Ready ? null : "qr_gate_soft"
                    };
                }
            }

            var readiness2 = QrReadinessGate.Evaluate(this);
            var qr = _engine.BuildQr(15);
            if (qr.ContainsKey("ok") && qr["ok"] is bool ok && ok)
            {
                _pinAuth.GetOrRotatePin(5);
                return qr;
            }

            return new Dictionary<string, object>
            {
                ["ok"] = false,
                ["error"] = "qr_not_ready",
                ["blockers"] = readiness2.Blockers
            };
        }

        public Dictionary<string, object> GetDiagnosticsPayload()
        {
            var baseDiag = _engine.Diagnose();
            baseDiag["version"] = ReadAppVersion(_rootPath);
            baseDiag["ncm"] = "2.0";
            baseDiag["server"] = new Dictionary<string, object>
            {
                ["running"] = IsServerRunning,
                ["uptimeMs"] = _kestrel != null ? (DateTime.UtcNow - _kestrel.StartedAt).TotalMilliseconds : 0,
                ["port"] = _port,
                ["requests"] = _kestrel?.RequestCount ?? 0,
                ["errors"] = _kestrel?.ErrorCount ?? 0
            };
            baseDiag["websocket"] = new Dictionary<string, object>
            {
                ["hubActive"] = IsServerRunning,
                ["clients"] = _wsHub?.ClientCount ?? 0
            };
            baseDiag["clients"] = BuildClientList();
            baseDiag["lastSyncAt"] = DateTimeOffset.FromUnixTimeMilliseconds(_wsHub?.LastSyncAtMs ?? 0).ToString("o");
            baseDiag["qrReady"] = QrReadinessGate.Evaluate(this).Ready;
            baseDiag["pin"] = _pinAuth?.GetCurrentPinPayload();
            return baseDiag;
        }

        public Dictionary<string, object> ApprovePairing(string deviceId, string name) =>
            _engine.ApprovePairing(deviceId, name);

        public Dictionary<string, object> RevokePairing(string deviceId) =>
            _engine.RevokePairing(deviceId);

        public Dictionary<string, object> ListPairings() =>
            _engine.ListPairings();

        public PortRegistrationResult RegisterPorts(bool repair = false)
        {
            // Só ACL/firewall — NÃO promove lanBindOk (isso exige NetworkGuarantee + probe).
            var result = _engine.RegisterPorts(repair);
            WriteHealthFile();
            _engine.UpdateRuntimeState(_port, _lanMode, _lanBindOk);
            return result;
        }

        /// <summary>
        /// Aplica resultado de registro (ex.: apos UAC filho) e agenda rebind do Kestrel
        /// em background — nunca reinicia o servidor no meio do request HTTP (causa hang/UAC loop).
        /// </summary>
        public async Task<Dictionary<string, object>> ApplyLanRegistrationAsync(bool repair = false)
        {
            PersistLanMode(true);
            var epoch = _lanEpoch;

            var result = RegisterPorts(repair);
            if (!result.Success && !result.NeedsElevation)
            {
                result = RegisterPorts(true);
            }

            if (!result.Success && TryAdoptElevatedRegistration(out var adoptMsg))
            {
                result.Success = true;
                result.NeedsElevation = false;
                result.AlreadyConfigured = true;
                result.Messages.Add(adoptMsg);
            }

            // NÃO marcar lanBindOk só com ACL/arquivo — isso mentia e o tablet quebrava.
            var payload = new Dictionary<string, object>
            {
                ["ok"] = result.Success,
                ["Success"] = result.Success,
                ["NeedsElevation"] = result.NeedsElevation,
                ["IsAdmin"] = result.IsAdmin,
                ["AlreadyConfigured"] = result.AlreadyConfigured,
                ["lanMode"] = _lanMode,
                ["port"] = _port,
                ["messages"] = result.Messages,
                ["firewallStatus"] = result.FirewallStatus ?? "",
            };

            if (!result.Success)
            {
                _lanBindOk = false;
                _lanBindIntent = false;
                _guarantee = new NetworkGuaranteeSnapshot
                {
                    Stage = result.NeedsElevation
                        ? NetworkGuaranteeService.StageNeedAdmin
                        : NetworkGuaranteeService.StageFailed,
                    NeedsAdmin = result.NeedsElevation,
                    IsAdmin = result.IsAdmin,
                    Port = _port,
                    Message = result.NeedsElevation
                        ? "Confirme o UAC do Windows para liberar firewall e rede."
                        : "Registro de porta falhou.",
                    Blockers = new List<string> { result.NeedsElevation ? "need_uac" : "register_failed" },
                    UpdatedAtUtcMs = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds()
                };
                payload["lanBindOk"] = false;
                payload["guaranteeStage"] = _guarantee.Stage;
                payload["guarantee"] = SnapshotToDict(_guarantee);
                WriteHealthFile();
                _engine.UpdateRuntimeState(_port, _lanMode, _lanBindOk);
                return payload;
            }

            payload["rebindScheduled"] = true;
            payload["lanBindOk"] = false;
            payload["guaranteeStage"] = NetworkGuaranteeService.StageBinding;
            _guarantee = new NetworkGuaranteeSnapshot
            {
                Stage = NetworkGuaranteeService.StageBinding,
                RegistrationOk = true,
                FirewallOk = FirewallInspector.HasInboundAllow(_port),
                IsAdmin = result.IsAdmin,
                Port = _port,
                LanIp = InterfaceSelector.GetBestIPv4() ?? "",
                Message = "Registrado. Abrindo e comprovando acesso na LAN…",
                UpdatedAtUtcMs = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds()
            };
            payload["guarantee"] = SnapshotToDict(_guarantee);
            WriteHealthFile();

            // Garantia em background (não trava o HTTP do painel).
            _ = Task.Run(async () =>
            {
                try
                {
                    await Task.Delay(900).ConfigureAwait(false);
                    if (!StillLanEpoch(epoch)) return;
                    await NetworkGuaranteeService.EnsureReadyAsync(this, forceRebind: true)
                        .ConfigureAwait(false);
                }
                catch
                {
                    if (!StillLanEpoch(epoch)) return;
                    SetLanBindOkGuaranteed(false, new NetworkGuaranteeSnapshot
                    {
                        Stage = NetworkGuaranteeService.StageFailed,
                        Message = "Falha na garantia de rede.",
                        Blockers = new List<string> { "guarantee_exception" },
                        Port = _port,
                        UpdatedAtUtcMs = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds()
                    });
                }
            });

            return payload;
        }

        public bool StillLanEpoch(int epoch) => epoch == _lanEpoch && _lanMode;

        public void SetLanBindIntent(bool intent)
        {
            _lanBindIntent = intent;
        }

        public void PublishGuarantee(NetworkGuaranteeSnapshot snap)
        {
            if (snap == null) return;
            _guarantee = snap;
            try { WriteHealthFile(); } catch { /* ignore */ }
        }

        /// <summary>Único lugar que promove lanBindOk após prova real na LAN.</summary>
        public void SetLanBindOkGuaranteed(bool ok, NetworkGuaranteeSnapshot snap)
        {
            lock (_gate)
            {
                if (ok && !_lanMode) return;
                _lanBindOk = ok && _lanMode;
                _lanBindIntent = false;
                if (snap != null) _guarantee = snap;
            }
            try
            {
                WriteHealthFile();
                _engine.UpdateRuntimeState(_port, _lanMode, _lanBindOk);
                if (ok)
                {
                    var okFile = Path.Combine(ContentLayout.DataDir(_rootPath ?? ""), ".lan-register-ok");
                    File.WriteAllText(okFile, DateTime.UtcNow.ToString("o"));
                }
            }
            catch { /* ignore */ }
        }

        private static Dictionary<string, object> SnapshotToDict(NetworkGuaranteeSnapshot s)
        {
            if (s == null) return new Dictionary<string, object>();
            return new Dictionary<string, object>
            {
                ["stage"] = s.Stage ?? "",
                ["ready"] = s.Ready,
                ["isAdmin"] = s.IsAdmin,
                ["needsAdmin"] = s.NeedsAdmin,
                ["firewallOk"] = s.FirewallOk,
                ["registrationOk"] = s.RegistrationOk,
                ["bindOk"] = s.BindOk,
                ["probeOk"] = s.ProbeOk,
                ["lanIp"] = s.LanIp ?? "",
                ["port"] = s.Port,
                ["message"] = s.Message ?? "",
                ["blockers"] = s.Blockers ?? new List<string>(),
                ["updatedAtUtcMs"] = s.UpdatedAtUtcMs
            };
        }

        /// <summary>
        /// Detecta que o processo elevado ja gravou urlacl/firewall (.lan-register-ok).
        /// </summary>
        private bool TryAdoptElevatedRegistration(out string message)
        {
            message = "";
            try
            {
                var okFile = Path.Combine(ContentLayout.DataDir(_rootPath ?? ""), ".lan-register-ok");
                var already = false;
                try
                {
                    already = new PortRegistrationService().IsAlreadyConfigured(_rootPath);
                }
                catch { /* ignore */ }

                if (File.Exists(okFile) || already)
                {
                    message = already
                        ? "Adotando registro LAN ja configurado (URL ACL + firewall)."
                        : "Adotando registro elevado (.lan-register-ok).";
                    return true;
                }
            }
            catch { /* ignore */ }
            return false;
        }

        public Dictionary<string, object> BuildHealthPayload()
        {
            var lanIp = InterfaceSelector.GetBestIPv4();
            var pkg = GetPackageHealthChecks(_rootPath);
            var version = ReadAppVersion(_rootPath);

            var appMeta = Somosum.Server.AppMetaService.GetPayload(_rootPath);

            return new Dictionary<string, object>
            {
                ["ok"] = true,
                ["version"] = version,
                ["protocol"] = appMeta.TryGetValue("protocol", out var proto) ? proto : 3,
                ["assetRevision"] = appMeta.TryGetValue("assetRevision", out var rev) ? rev : version,
                ["build"] = appMeta.TryGetValue("build", out var build) ? build : "",
                ["dbSchemaVersion"] = appMeta.TryGetValue("dbSchemaVersion", out var dbv) ? dbv : 4,
                ["port"] = _port,
                ["runtimeBridge"] = true,
                ["runtimeVersion"] = version,
                ["productionMode"] = false,
                ["lanMode"] = _lanMode,
                ["lanModeRequested"] = _lanMode && !_lanBindOk,
                ["lanBindOk"] = _lanBindOk,
                ["tlsEnabled"] = _lanTls,
                ["scheme"] = Scheme,
                ["lanIp"] = lanIp,
                ["uptimeSec"] = _kestrel != null ? (int)(DateTime.UtcNow - _kestrel.StartedAt).TotalSeconds : 0,
                ["requests"] = _kestrel?.RequestCount ?? 0,
                ["errors"] = _kestrel?.ErrorCount ?? 0,
                ["saveQueue"] = _storage?.PendingSaves ?? 0,
                ["syncSeq"] = _syncStore?.CurrentSeq ?? 0,
                ["websocketClients"] = _wsHub?.ClientCount ?? 0,
                ["konva"] = pkg.Konva,
                ["bibles"] = pkg.Bibles,
                ["fonts"] = pkg.Fonts,
                ["somosumExe"] = pkg.SomosumExe,
                ["remoteExe"] = pkg.RemoteExe,
                ["dataWritable"] = pkg.DataWritable,
                ["readyForService"] = pkg.Konva && pkg.Bibles >= 1 && pkg.DataWritable && pkg.SomosumExe,
                ["serverEngine"] = "Kestrel",
                ["ncm"] = "2.0"
            };
        }

        /// <summary>
        /// Checks estruturados para GET /api/diagnostics — alinhados ao guia docs/guides/diagnostico.md.
        /// </summary>
        public Dictionary<string, object> BuildDiagnosticsPayload()
        {
            var health = BuildHealthPayload();
            var root = _rootPath ?? "";
            var pkg = GetPackageHealthChecks(root);
            var version = health.TryGetValue("version", out var ver) ? ver : ReadAppVersion(root);
            var checks = new List<Dictionary<string, object>>();

            void Add(string id, string status, string title, string detail, string solution = "", string action = null)
            {
                var c = new Dictionary<string, object>
                {
                    ["id"] = id,
                    ["status"] = status,
                    ["title"] = title,
                    ["detail"] = detail,
                    ["solution"] = solution ?? ""
                };
                if (!string.IsNullOrEmpty(action)) c["action"] = action;
                checks.Add(c);
            }

            bool FileOk(string rel)
            {
                try
                {
                    var url = rel.Replace('\\', '/');
                    if (!url.StartsWith("/")) url = "/" + url;
                    return File.Exists(ContentLayout.MapUrlToPhysical(root, url));
                }
                catch { return false; }
            }

            var exeRoot = FileOk("SOMOSUM.exe");
            var exeApp = FileOk(Path.Combine("app", "SOMOSUM.exe"));
            var exeOk = exeRoot || exeApp;
            Add("file-exe", exeOk ? "ok" : "fail", "SOMOSUM.exe",
                exeOk
                    ? (exeRoot && exeApp ? "Trampolim na raiz e app/SOMOSUM.exe OK" : exeRoot ? "SOMOSUM.exe na raiz" : "app/SOMOSUM.exe OK")
                    : "Binário ausente na pasta do programa",
                exeOk ? "" : "Execute scripts\\compile-launcher.ps1 ou reinstale pelo Setup");

            var engineOk = FileOk(Path.Combine("app", "Somosum.Engine.dll"))
                || FileOk(Path.Combine("controller", "runtime", "bin", "Release", "net8.0-windows", "Somosum.Engine.dll"));
            Add("file-engine", engineOk ? "ok" : "warn", "Somosum.Engine.dll",
                engineOk ? "Motor HTTP in-process presente" : "DLL do motor não encontrada no pacote",
                engineOk ? "" : "Recompile com scripts\\compile-launcher.ps1");

            Add("file-control", FileOk("control.html") ? "ok" : "fail", "control.html",
                FileOk("control.html") ? "Entry point do Controle OK" : "control.html ausente",
                FileOk("control.html") ? "" : "Reinstale o pacote SOMOSUM completo");
            Add("file-screen", FileOk("screen.html") ? "ok" : "fail", "screen.html",
                FileOk("screen.html") ? "Entry point da Projeção OK" : "screen.html ausente",
                FileOk("screen.html") ? "" : "Reinstale o pacote SOMOSUM completo");
            Add("file-boot", FileOk(Path.Combine("js", "core", "boot-inline.js")) ? "ok" : "fail", "Boot JS",
                FileOk(Path.Combine("js", "core", "boot-inline.js")) ? "js/core/boot-inline.js OK" : "Boot JS ausente",
                FileOk(Path.Combine("js", "core", "boot-inline.js")) ? "" : "Reinstale o pacote — pasta js/");

            Add("pkg-konva", pkg.Konva ? "ok" : "fail", "Designer (Konva)",
                pkg.Konva ? "vendor/konva.min.js OK" : "Konva ausente ou corrompido",
                pkg.Konva ? "" : "Reinstale o pacote SOMOSUM completo (pasta vendor/)");
            Add("pkg-bibles", pkg.Bibles >= 1 ? "ok" : "fail", "Bíblias offline",
                pkg.Bibles + " versão(ões) em storage/private/biblias/offline",
                pkg.Bibles >= 1 ? "" : "Extraia o pacote completo — pasta storage/private/biblias/offline/");
            Add("pkg-fonts", pkg.Fonts >= 1 ? "ok" : "warn", "Fontes",
                pkg.Fonts + " arquivo(s) em fonts/",
                pkg.Fonts >= 1 ? "" : "Copie as fontes oficiais para fonts/ ou reinstale o pacote");

            Add("data-writable", pkg.DataWritable ? "ok" : "fail", "Pasta data gravável",
                pkg.DataWritable ? "Permissão de escrita em data/ OK" : "Sem permissão de escrita em data/",
                pkg.DataWritable ? "" : "Use Preparar rede (UAC) ou instale fora de pastas bloqueadas",
                pkg.DataWritable ? null : "openFolderData");

            var writeTest = ProbeDiagWriteTest(ContentLayout.DataDir(root));
            Add("data-write-test", writeTest ? "ok" : "fail", "Teste de gravação",
                writeTest ? "Arquivo temporário criado e removido em data/" : "Falha ao gravar arquivo de teste em data/",
                writeTest ? "" : "Verifique antivírus, permissões NTFS ou OneDrive bloqueando data/",
                writeTest ? null : "openFolderData");

            var logsWritable = ProbeDataWritable(Path.Combine(root, "logs"));
            Add("logs-writable", logsWritable ? "ok" : "warn", "Pasta logs gravável",
                logsWritable ? "logs/ aceita gravação" : "Não foi possível gravar em logs/",
                logsWritable ? "" : "Crie a pasta logs/ manualmente ou execute como administrador uma vez",
                logsWritable ? null : "openFolderLogs");

            var wv2Dir = Path.Combine(ContentLayout.DataDir(root), ".webview2");
            string wv2Detail;
            var wv2Status = "warn";
            try
            {
                if (Directory.Exists(wv2Dir))
                {
                    long bytes = 0;
                    foreach (var f in Directory.EnumerateFiles(wv2Dir, "*.*", SearchOption.AllDirectories))
                    {
                        try { bytes += new FileInfo(f).Length; } catch { /* ignore */ }
                    }
                    var mb = Math.Round(bytes / (1024.0 * 1024.0), 1);
                    wv2Detail = "Cache WebView2 em data/.webview2 (" + mb + " MB)";
                    wv2Status = "ok";
                }
                else
                {
                    wv2Detail = "Pasta data/.webview2 ainda não criada — normal na primeira execução";
                }
            }
            catch
            {
                wv2Detail = "Não foi possível inspecionar data/.webview2";
            }
            Add("webview2-cache", wv2Status, "Cache WebView2", wv2Detail, wv2Status == "ok" ? "" : "Abra pelo SOMOSUM.exe uma vez para inicializar o perfil WebView2");

            var errors = health.TryGetValue("errors", out var errObj) && errObj is int errN ? errN : 0;
            var requests = health.TryGetValue("requests", out var reqObj) && reqObj is int reqN ? reqN : 0;
            var saveQueue = health.TryGetValue("saveQueue", out var sqObj) && sqObj is int sqN ? sqN : 0;
            var uptime = health.TryGetValue("uptimeSec", out var upObj) && upObj is int upN ? upN : 0;
            var perfStatus = errors == 0 ? "ok" : (errors < 5 ? "warn" : "fail");
            if (saveQueue > 3) perfStatus = perfStatus == "ok" ? "warn" : perfStatus;
            Add("server-perf", perfStatus, "Desempenho servidor",
                uptime + "s uptime · " + requests + " req · " + errors + " erro(s) · fila save " + saveQueue,
                errors > 0 ? "Veja logs/somosum-*.log — Reiniciar servidor se a fila save não zerar" : "",
                saveQueue > 3 ? "restartServer" : null);

            var ready = health.TryGetValue("readyForService", out var rdy) && rdy is bool rdyB && rdyB;
            Add("health-ready", ready ? "ok" : "warn", "Pronto para culto",
                ready ? "Pacote offline íntegro" : "Alguns itens do pacote precisam de atenção",
                ready ? "" : "Veja os itens abaixo e corrija antes do culto");

            if (_lanMode)
            {
                var lanIp = health.TryGetValue("lanIp", out var ipObj) ? ipObj?.ToString() : "";
                Add("lan-bind", _lanBindOk ? "ok" : "fail", "Rede LAN",
                    _lanBindOk ? "Ativo — IP " + (string.IsNullOrEmpty(lanIp) ? "?" : lanIp) : "LAN solicitado mas bind falhou",
                    _lanBindOk ? "" : "Use Preparar rede no menu SOMOSUM (UAC uma vez por PC)",
                    _lanBindOk ? null : "registerPorts");
            }

            return new Dictionary<string, object>
            {
                ["version"] = version,
                ["ranAt"] = DateTime.UtcNow.ToString("o"),
                ["checks"] = checks,
                ["summary"] = new Dictionary<string, object>
                {
                    ["ok"] = checks.FindAll(c => (string)c["status"] == "ok").Count,
                    ["warn"] = checks.FindAll(c => (string)c["status"] == "warn").Count,
                    ["fail"] = checks.FindAll(c => (string)c["status"] == "fail").Count,
                    ["total"] = checks.Count
                }
            };
        }

        private static bool ProbeDiagWriteTest(string dataDir)
        {
            try
            {
                if (!Directory.Exists(dataDir))
                    Directory.CreateDirectory(dataDir);
                var probe = Path.Combine(dataDir, ".diag-write-test");
                File.WriteAllText(probe, DateTime.UtcNow.ToString("o"));
                File.Delete(probe);
                return true;
            }
            catch
            {
                return false;
            }
        }

        private static string ReadAppVersion(string root)
        {
            try
            {
                var path = Path.Combine(root ?? "", "VERSION");
                if (File.Exists(path))
                {
                    var v = File.ReadAllText(path).Trim();
                    if (!string.IsNullOrWhiteSpace(v)) return v;
                }
            }
            catch { /* ignore */ }
            return "0.0.0";
        }

        private sealed class PackageHealthChecks
        {
            public bool Konva;
            public int Bibles;
            public int Fonts;
            public bool SomosumExe;
            public bool RemoteExe;
            public bool DataWritable;
        }

        /// <summary>
        /// Checks alinhados ao legado PowerShell (Get-HealthPackageChecks) + layout app\.
        /// </summary>
        private static PackageHealthChecks GetPackageHealthChecks(string root)
        {
            var result = new PackageHealthChecks();

            var konva = ContentLayout.MapUrlToPhysical(root, "/vendor/konva.min.js");
            try
            {
                if (File.Exists(konva))
                {
                    var len = new FileInfo(konva).Length;
                    result.Konva = len > 100_000;
                }
            }
            catch { result.Konva = false; }

            var bibleDir = Path.Combine(ContentLayout.StorageDir(root), "private", "biblias", "offline");
            try
            {
                if (Directory.Exists(bibleDir))
                    result.Bibles = Directory.GetFiles(bibleDir, "*.bible.js").Length;
            }
            catch { result.Bibles = 0; }

            var fontsDir = Path.Combine(root, ContentLayout.ViewDir, "fonts");
            try
            {
                if (Directory.Exists(fontsDir))
                {
                    foreach (var f in Directory.EnumerateFiles(fontsDir, "*.*", SearchOption.AllDirectories))
                    {
                        var ext = Path.GetExtension(f);
                        if (ext == null) continue;
                        if (ext.Equals(".ttf", StringComparison.OrdinalIgnoreCase) ||
                            ext.Equals(".otf", StringComparison.OrdinalIgnoreCase) ||
                            ext.Equals(".woff", StringComparison.OrdinalIgnoreCase) ||
                            ext.Equals(".woff2", StringComparison.OrdinalIgnoreCase))
                        {
                            var name = Path.GetFileName(f);
                            if (name != null && name.StartsWith("LEIA-ME", StringComparison.OrdinalIgnoreCase))
                                continue;
                            result.Fonts++;
                        }
                    }
                }
            }
            catch { result.Fonts = 0; }

            result.SomosumExe =
                File.Exists(Path.Combine(root, "SOMOSUM.exe")) ||
                File.Exists(Path.Combine(root, "app", "SOMOSUM.exe"));
            result.RemoteExe =
                File.Exists(Path.Combine(root, "app", "SOMOSUM-Remote.exe")) ||
                File.Exists(Path.Combine(root, "SOMOSUM-Remote.exe"));

            var dataDir = ContentLayout.DataDir(root);
            result.DataWritable = ProbeDataWritable(dataDir);

            return result;
        }

        private static bool ProbeDataWritable(string dataDir)
        {
            try
            {
                if (!Directory.Exists(dataDir))
                    Directory.CreateDirectory(dataDir);
                var probe = Path.Combine(dataDir, ".write-probe-" + Guid.NewGuid().ToString("N"));
                File.WriteAllText(probe, "ok");
                File.Delete(probe);
                return true;
            }
            catch
            {
                return Directory.Exists(dataDir);
            }
        }

        public Dictionary<string, object> BuildLanInfo(bool includeSecrets = false)
        {
            var lanIp = !string.IsNullOrEmpty(_guarantee?.LanIp)
                ? _guarantee.LanIp
                : InterfaceSelector.GetBestIPv4();
            var candidates = InterfaceSelector.GetCandidateIPv4s();
            var tok = "";
            if (includeSecrets && SecurityRuntime.Stack != null)
            {
                tok = SecurityRuntime.Stack.Tokens.EnsureRemoteToken();
            }
            else if (includeSecrets)
                tok = RequestAuthHelper.GetRemoteToken(ContentLayout.DataDir(_rootPath));
            var tq = string.IsNullOrWhiteSpace(tok) ? "" : "?token=" + Uri.EscapeDataString(tok);
            var scheme = Scheme;
            var localBase = scheme + "://127.0.0.1:" + _port;
            // Público só com garantia (probe OK). Intent sozinho não publica QR.
            var publicOk = _lanBindOk && !string.IsNullOrEmpty(lanIp)
                && (_guarantee == null || _guarantee.Ready || _guarantee.ProbeOk);
            var publicBase = publicOk ? scheme + "://" + lanIp + ":" + _port : localBase;
            return new Dictionary<string, object>
            {
                ["lanMode"] = _lanMode,
                ["lanBindOk"] = _lanBindOk,
                ["tlsEnabled"] = _lanTls,
                ["scheme"] = scheme,
                ["lanIp"] = lanIp,
                ["lanIpCandidates"] = candidates,
                ["port"] = _port,
                ["localUrl"] = localBase + "/",
                ["lanUrl"] = publicOk ? publicBase + "/" : null,
                ["remoteUrl"] = publicBase + "/remote.html" + (includeSecrets ? tq : ""),
                ["controlUrl"] = publicBase + "/control.html",
                ["screenUrl"] = publicBase + "/screen.html" + (includeSecrets ? tq : ""),
                ["stageUrl"] = publicBase + "/stage.html" + (includeSecrets ? tq : ""),
                ["stageQrUrl"] = publicBase + "/stage.html" + (includeSecrets ? tq : ""),
                ["localRemoteUrl"] = localBase + "/remote.html" + (includeSecrets ? tq : ""),
                ["localStageUrl"] = localBase + "/stage.html" + (includeSecrets ? tq : ""),
                ["qrReady"] = publicOk,
                ["tokenInUrls"] = includeSecrets,
                ["listeningPublic"] = publicOk,
                ["guaranteeStage"] = _guarantee?.Stage ?? "idle",
                ["guarantee"] = SnapshotToDict(_guarantee),
                ["isAdmin"] = PortRegistrationService.IsRunningAsAdmin(),
                ["firewallOk"] = FirewallInspector.HasInboundAllow(_port)
            };
        }

        private IList<object> BuildClientList()
        {
            var list = new List<object>();
            if (_wsHub == null) return list;
            foreach (var c in _wsHub.GetClients())
            {
                list.Add(new Dictionary<string, object>
                {
                    ["id"] = c.Id,
                    ["role"] = c.Role,
                    ["ip"] = c.RemoteIp,
                    ["connectedAt"] = c.ConnectedAt.ToString("o"),
                    ["rttMs"] = c.LastRttMs
                });
            }
            return list;
        }

        private void LoadConfig()
        {
            _lanMode = false;
            _lanTls = false;
            try
            {
                var cfgPath = Path.Combine(ContentLayout.DataDir(_rootPath), "config.json");
                if (!File.Exists(cfgPath)) return;
                var json = File.ReadAllText(cfgPath);
                using var doc = JsonDocument.Parse(json);
                if (doc.RootElement.TryGetProperty("lanMode", out var lan))
                    _lanMode = lan.GetBoolean();
                if (doc.RootElement.TryGetProperty("lanTls", out var tls)
                    && (tls.ValueKind == JsonValueKind.True || tls.ValueKind == JsonValueKind.False))
                    _lanTls = tls.GetBoolean();
            }
            catch { /* ignore */ }
        }

        /// <summary>Persiste lanMode no config.json e invalida garantias atrasadas.</summary>
        private void PersistLanMode(bool enabled)
        {
            _lanEpoch++;
            _lanMode = enabled;
            if (!enabled)
            {
                _lanBindOk = false;
                _lanBindIntent = false;
                _guarantee = new NetworkGuaranteeSnapshot
                {
                    Stage = NetworkGuaranteeService.StageIdle,
                    Message = "Modo LAN desligado — só neste PC.",
                    Port = _port,
                    UpdatedAtUtcMs = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds()
                };
            }
            try
            {
                var cfgPath = Path.Combine(ContentLayout.DataDir(_rootPath ?? ""), "config.json");
                Dictionary<string, JsonElement> flat = null;
                if (File.Exists(cfgPath))
                {
                    using var doc = JsonDocument.Parse(File.ReadAllText(cfgPath));
                    flat = new Dictionary<string, JsonElement>(StringComparer.OrdinalIgnoreCase);
                    foreach (var p in doc.RootElement.EnumerateObject())
                        flat[p.Name] = p.Value.Clone();
                }
                using var ms = new MemoryStream();
                using (var writer = new Utf8JsonWriter(ms, new JsonWriterOptions { Indented = true }))
                {
                    writer.WriteStartObject();
                    writer.WriteBoolean("lanMode", enabled);
                    if (flat != null)
                    {
                        foreach (var kv in flat)
                        {
                            if (string.Equals(kv.Key, "lanMode", StringComparison.OrdinalIgnoreCase))
                                continue;
                            writer.WritePropertyName(kv.Key);
                            kv.Value.WriteTo(writer);
                        }
                    }
                    writer.WriteEndObject();
                }
                File.WriteAllBytes(cfgPath, ms.ToArray());
            }
            catch { /* ignore */ }
        }

        public Dictionary<string, object> SetLanMode(bool enabled)
        {
            if (!enabled)
            {
                PersistLanMode(false);
                WriteHealthFile();
                _engine.UpdateRuntimeState(_port, _lanMode, _lanBindOk);
                _ = Task.Run(async () =>
                {
                    try
                    {
                        await Task.Delay(250).ConfigureAwait(false);
                        await RestartServerAsync().ConfigureAwait(false);
                    }
                    catch { /* ignore */ }
                });
                return new Dictionary<string, object>
                {
                    ["ok"] = true,
                    ["lanMode"] = false,
                    ["lanBindOk"] = false,
                    ["lanModeRequested"] = false,
                    ["listeningPublic"] = false,
                    ["guaranteeStage"] = NetworkGuaranteeService.StageIdle,
                    ["message"] = "Modo LAN desativado. Controle e projeção seguem neste PC.",
                };
            }

            PersistLanMode(true);
            WriteHealthFile();
            _engine.UpdateRuntimeState(_port, _lanMode, _lanBindOk);
            return new Dictionary<string, object>
            {
                ["ok"] = true,
                ["lanMode"] = true,
                ["lanBindOk"] = _lanBindOk,
                ["lanModeRequested"] = !_lanBindOk,
            };
        }

        private async Task TryRegisterLanAsync()
        {
            if (!_lanMode) return;
            var result = _engine.RegisterPorts(false);
            var registered = result.Success;
            if (!registered && PortRegistrationService.IsRunningAsAdmin())
            {
                result = _engine.RegisterPorts(true);
                registered = result.Success;
            }
            if (!registered && result.AlreadyConfigured)
                registered = true;
            if (!registered && TryAdoptElevatedRegistration(out _))
                registered = true;
            if (!registered)
            {
                await FirewallRepairService.RepairAsync(_port);
                result = _engine.RegisterPorts(false);
                registered = result.Success || result.AlreadyConfigured;
                if (!registered && TryAdoptElevatedRegistration(out _))
                    registered = true;
            }

            // Soft register ≠ LAN pronta. Só abre Intent (AnyIP) se firewall Allow real.
            _lanBindOk = false;
            _lanBindIntent = registered && FirewallInspector.HasInboundAllow(_port);
            WriteHealthFile();
        }

        private void EnsureDataDirs()
        {
            var dataDir = ContentLayout.DataDir(_rootPath ?? "");
            var dirs = new[]
            {
                dataDir,
                Path.Combine(dataDir, "network"),
                Path.Combine(dataDir, "media"),
                Path.Combine(_rootPath ?? "", "logs")
            };
            foreach (var p in dirs)
            {
                if (!Directory.Exists(p)) Directory.CreateDirectory(p);
            }
            EnsureOptionalDataFiles();
            RequestAuthHelper.EnsureRemoteToken(ContentLayout.DataDir(_rootPath));
        }

        private void EnsureOptionalDataFiles()
        {
            var dataDir = ContentLayout.DataDir(_rootPath);
            foreach (var kv in StorageAllowlist.OptionalJsonDefaults)
            {
                var path = Path.Combine(dataDir, kv.Key.Replace('/', Path.DirectorySeparatorChar));
                if (File.Exists(path)) continue;
                try
                {
                    var dir = Path.GetDirectoryName(path);
                    if (!string.IsNullOrEmpty(dir) && !Directory.Exists(dir))
                        Directory.CreateDirectory(dir);
                    File.WriteAllText(path, kv.Value);
                }
                catch { /* ignore */ }
            }
        }

        private int ReadPortFile()
        {
            try
            {
                var path = Path.Combine(ContentLayout.DataDir(_rootPath), ".port");
                if (File.Exists(path) && int.TryParse(File.ReadAllText(path).Trim(), out var port) && port > 0)
                    return port;
            }
            catch { /* ignore */ }
            return 0;
        }

        private void WritePortFile(int port)
        {
            try
            {
                File.WriteAllText(Path.Combine(ContentLayout.DataDir(_rootPath), ".port"), port.ToString());
            }
            catch { /* ignore */ }
        }

        private void WriteHealthFile()
        {
            try
            {
                var health = new Dictionary<string, object>
                {
                    ["lanMode"] = _lanMode,
                    ["lanBindOk"] = _lanBindOk,
                    ["port"] = _port,
                    ["serverEngine"] = "Kestrel",
                    ["updatedUtc"] = DateTime.UtcNow.ToString("o")
                };
                NetworkJson.WriteFile(Path.Combine(ContentLayout.DataDir(_rootPath), ".worker-health.json"), health);
            }
            catch { /* ignore */ }
        }

        public void Dispose()
        {
            StopAsync().GetAwaiter().GetResult();
            _kestrel?.Dispose();
        }
    }
}
