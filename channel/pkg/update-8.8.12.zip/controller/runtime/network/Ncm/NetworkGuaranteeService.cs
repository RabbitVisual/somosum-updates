using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Somosum.Network.Engine.Core;

namespace Somosum.Network.Engine.Ncm
{
    public sealed class NetworkGuaranteeSnapshot
    {
        public string Stage = "idle";
        public bool Ready;
        public bool IsAdmin;
        public bool NeedsAdmin;
        public bool FirewallOk;
        public bool RegistrationOk;
        public bool BindOk;
        public bool ProbeOk;
        public string LanIp = "";
        public int Port;
        public string Message = "";
        public List<string> Blockers = new List<string>();
        public long UpdatedAtUtcMs;
    }

    /// <summary>
    /// Pipeline infalível Win10/Win11: admin/UAC → firewall completo → rebind AnyIP → prova no IP LAN.
    /// Só então lanBindOk / QR público.
    /// </summary>
    public static class NetworkGuaranteeService
    {
        public const string StageIdle = "idle";
        public const string StageNeedAdmin = "need_admin";
        public const string StageFirewall = "firewall";
        public const string StageBinding = "binding";
        public const string StageProbing = "probing";
        public const string StageReady = "ready";
        public const string StageFailed = "failed";

        /// <summary>
        /// Após registro ACL/FW (ou adopt): rebind Kestrel + probe. Atualiza NCM.lanBindOk.
        /// </summary>
        public static async Task<NetworkGuaranteeSnapshot> EnsureReadyAsync(
            NetworkConnectivityManager ncm,
            bool forceRebind,
            CancellationToken ct = default)
        {
            var snap = new NetworkGuaranteeSnapshot
            {
                IsAdmin = PortRegistrationService.IsRunningAsAdmin(),
                Port = ncm?.Port ?? 0,
                LanIp = InterfaceSelector.GetBestIPv4() ?? "",
                UpdatedAtUtcMs = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds()
            };

            if (ncm == null)
            {
                snap.Stage = StageFailed;
                snap.Message = "ncm_unavailable";
                snap.Blockers.Add("ncm_unavailable");
                return snap;
            }

            if (!ncm.LanMode)
            {
                snap.Stage = StageIdle;
                snap.Message = "Modo LAN desligado.";
                ncm.SetLanBindOkGuaranteed(false, snap);
                return snap;
            }

            snap.NeedsAdmin = !snap.IsAdmin && !FirewallInspector.HasInboundAllow(snap.Port);
            var fwOk = snap.Port > 0 && FirewallInspector.HasInboundAllow(snap.Port);
            snap.FirewallOk = fwOk;
            snap.RegistrationOk = fwOk || ncm.LanMode;

            if (!fwOk && ncm.LanMode)
            {
                snap.Stage = StageNeedAdmin;
                snap.NeedsAdmin = true;
                snap.Message = "Firewall incompleto — Preparar rede (UAC) ou Reparar firewall.";
                snap.Blockers.Add("firewall_blocked");
                ncm.SetLanBindOkGuaranteed(false, snap);
                return snap;
            }

            if (string.IsNullOrEmpty(snap.LanIp))
            {
                snap.Stage = StageFailed;
                snap.Message = "Sem IP Wi‑Fi/Ethernet válido.";
                snap.Blockers.Add("no_valid_interface");
                ncm.SetLanBindOkGuaranteed(false, snap);
                return snap;
            }

            // Rebind se ainda não público ou force
            var needBind = forceRebind || !ncm.ShouldListenAnyIp;
            if (needBind)
            {
                snap.Stage = StageBinding;
                snap.Message = "Abrindo servidor na rede local…";
                ncm.PublishGuarantee(snap);
                try
                {
                    ncm.SetLanBindIntent(true);
                    await ncm.HandleNetworkRebindAsync().ConfigureAwait(false);
                    snap.BindOk = true;
                }
                catch (Exception ex)
                {
                    snap.Stage = StageFailed;
                    snap.BindOk = false;
                    snap.Message = "Falha ao abrir porta na LAN: " + ex.Message;
                    snap.Blockers.Add("rebind_failed");
                    ncm.SetLanBindOkGuaranteed(false, snap);
                    return snap;
                }
            }
            else
            {
                snap.BindOk = true;
            }

            snap.Stage = StageProbing;
            snap.Message = "Verificando acesso pelo IP " + snap.LanIp + "…";
            ncm.PublishGuarantee(snap);

            var scheme = ncm.Scheme;
            var probe = await LanReachabilityProbe.ProbeLanAsync(scheme, snap.LanIp, snap.Port, ct)
                .ConfigureAwait(false);
            snap.ProbeOk = probe.Ok;

            if (!probe.Ok)
            {
                // Tenta candidatos alternativos (Wi‑Fi vs cabo)
                foreach (var ip in InterfaceSelector.GetCandidateIPv4s())
                {
                    if (string.Equals(ip, snap.LanIp, StringComparison.Ordinal)) continue;
                    ct.ThrowIfCancellationRequested();
                    var alt = await LanReachabilityProbe.ProbeLanAsync(scheme, ip, snap.Port, ct)
                        .ConfigureAwait(false);
                    if (alt.Ok)
                    {
                        snap.LanIp = ip;
                        snap.ProbeOk = true;
                        probe = alt;
                        break;
                    }
                }
            }

            if (!snap.ProbeOk)
            {
                snap.Stage = StageFailed;
                snap.Message = "Servidor não responde no IP da rede. Confirme Wi‑Fi e Reparar firewall.";
                snap.Blockers.Add("lan_probe_failed");
                snap.Blockers.Add(probe.Detail ?? "");
                ncm.SetLanBindOkGuaranteed(false, snap);
                // Fecha AnyIP se ficou aberto sem prova
                try
                {
                    ncm.SetLanBindIntent(false);
                    await ncm.HandleNetworkRebindAsync().ConfigureAwait(false);
                }
                catch { /* ignore */ }
                return snap;
            }

            if (!ncm.LanMode)
            {
                snap.Stage = StageIdle;
                snap.Message = "Modo LAN desligado.";
                ncm.SetLanBindOkGuaranteed(false, snap);
                return snap;
            }

            snap.Stage = StageReady;
            snap.Ready = true;
            snap.Message = "LAN pronta — QR válido para tablet na mesma Wi‑Fi.";
            snap.UpdatedAtUtcMs = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
            ncm.SetLanBindOkGuaranteed(true, snap);
            return snap;
        }
    }
}
