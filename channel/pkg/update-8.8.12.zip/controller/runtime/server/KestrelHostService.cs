using Somosum.Core;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Somosum.Network.Engine.Core;
using Somosum.Network.Engine.Ncm;
using Somosum.Server.Sync;
using Somosum.Security;
using Somosum.Performance;

namespace Somosum.Server
{
    public sealed class KestrelHostService : IDisposable
    {
        private readonly NetworkConnectivityManager _ncm;
        private WebApplication _app;
        private CancellationTokenSource _cts;
        private readonly DateTime _startedAt = DateTime.UtcNow;
        private long _requestCount;
        private long _errorCount;

        public KestrelHostService(NetworkConnectivityManager ncm)
        {
            _ncm = ncm;
        }

        public bool IsRunning => _app != null;
        public DateTime StartedAt => _startedAt;
        public long RequestCount => Interlocked.Read(ref _requestCount);
        public long ErrorCount => Interlocked.Read(ref _errorCount);

        public async Task StartAsync(CancellationToken ct = default)
        {
            if (_app != null) return;

            try
            {
                string applyErr;
                if (!AppUpdateInstallService.TryApplyPending(_ncm.RootPath, out applyErr)
                    && !string.IsNullOrWhiteSpace(applyErr))
                {
                    System.Diagnostics.Debug.WriteLine("AppUpdate apply: " + applyErr);
                }
            }
            catch { /* apply best-effort before bind */ }

            var port = _ncm.Port;
            var builder = WebApplication.CreateBuilder(new WebApplicationOptions
            {
                Args = Array.Empty<string>(),
                ContentRootPath = _ncm.RootPath
            });

            System.Security.Cryptography.X509Certificates.X509Certificate2 tlsCert = null;
            if (_ncm.TlsEnabled)
            {
                var sans = new List<string>();
                var lanIp = Somosum.Network.Engine.Core.InterfaceSelector.GetBestIPv4();
                if (!string.IsNullOrEmpty(lanIp)) sans.Add(lanIp);
                try { tlsCert = TlsCertificateService.EnsureCertificate(_ncm.RootPath, sans); }
                catch { tlsCert = null; }
            }

            builder.WebHost.UseKestrel(options =>
            {
                options.Limits.MaxRequestBodySize = RequestValidator.MaxBodyBytes;
                if (tlsCert != null)
                {
                    options.ListenLocalhost(port, lo => lo.UseHttps(tlsCert));
                    if (_ncm.ShouldListenAnyIp) options.ListenAnyIP(port, lo => lo.UseHttps(tlsCert));
                }
                else
                {
                    options.ListenLocalhost(port);
                    if (_ncm.ShouldListenAnyIp) options.ListenAnyIP(port);
                }
            });

            builder.Logging.ClearProviders();
            _app = builder.Build();
            _cts = CancellationTokenSource.CreateLinkedTokenSource(ct);

            ConfigurePipeline(_app);
            await _app.StartAsync(_cts.Token);
            await WaitForPingAsync(port, 15000, tlsCert != null);
        }

        public async Task StopAsync()
        {
            if (_app == null) return;
            try
            {
                _cts?.Cancel();
                await _app.StopAsync();
                await _app.DisposeAsync();
            }
            catch { /* ignore */ }
            finally
            {
                _app = null;
                _cts?.Dispose();
                _cts = null;
            }
        }

        public async Task RestartAsync(CancellationToken ct = default)
        {
            await StopAsync();
            await StartAsync(ct);
        }

        private void ConfigurePipeline(WebApplication app)
        {
            var syncStore = _ncm.SyncStore;
            var wsHub = _ncm.WebSocketHub;
            var storage = _ncm.StorageHandler;
            var stream = _ncm.StreamHandler;
            var dataDir = Somosum.Core.ContentLayout.DataDir(_ncm.RootPath);
            var ops = new ProductionOpsApi(_ncm.RootPath, wsHub, NetworkEngineHost.Instance);
            var security = SecurityStack.ForRoot(_ncm.RootPath);
            SecurityRuntime.Stack = security;
            var performance = PerformanceStack.ForRoot(_ncm.RootPath);
            PerformanceRuntime.Stack = performance;

            app.Use(async (ctx, next) =>
            {
                await new ApiSecurityMiddleware(next, security, () => _ncm.ShouldListenAnyIp).InvokeAsync(ctx);
            });

            app.Use(async (ctx, next) =>
            {
                Interlocked.Increment(ref _requestCount);
                try { await next(); }
                catch
                {
                    Interlocked.Increment(ref _errorCount);
                    throw;
                }
            });

            app.UseWebSockets(new WebSocketOptions { KeepAliveInterval = TimeSpan.FromSeconds(15) });

            var drainToken = _cts.Token;
            _ = Task.Run(async () =>
            {
                while (!drainToken.IsCancellationRequested)
                {
                    try { storage.ProcessQueue(); } catch { /* ignore */ }
                    try { await Task.Delay(50, drainToken); }
                    catch (OperationCanceledException) { break; }
                }
            }, drainToken);

            app.Run(async ctx =>
            {
                var path = ctx.Request.Path.Value ?? "/";

                if (path.StartsWith("/ws/sync", StringComparison.OrdinalIgnoreCase))
                {
                    if (!ctx.WebSockets.IsWebSocketRequest)
                    {
                        ctx.Response.StatusCode = 400;
                        return;
                    }

                    if (!RequestAuthHelper.ValidateSyncToken(ctx, dataDir))
                    {
                        ctx.Response.StatusCode = 403;
                        return;
                    }

                    var role = ctx.Request.Query["role"].ToString();
                    if (string.IsNullOrEmpty(role)) role = "remote";
                    var deviceFp = ctx.Request.Query["deviceFingerprint"].ToString();
                    var deviceId = ctx.Request.Query["deviceId"].ToString();
                    var deviceLabel = ctx.Request.Query["deviceLabel"].ToString();
                    var socket = await ctx.WebSockets.AcceptWebSocketAsync();
                    var ip = ctx.Connection.RemoteIpAddress?.ToString() ?? "unknown";
                    await wsHub.HandleConnectionAsync(socket, role, ip, deviceFp, deviceId, deviceLabel, ctx.RequestAborted);
                    return;
                }

                if (await ops.TryHandleAsync(ctx))
                    return;
                if (await TryHandleApiAsync(ctx, path, syncStore, wsHub, storage, stream, dataDir))
                    return;

                await ServeStaticAsync(ctx, path);
            });
        }

        private async Task<bool> TryHandleApiAsync(
            HttpContext ctx,
            string path,
            SyncMessageStore syncStore,
            SyncWebSocketHub wsHub,
            StorageApiHandler storage,
            StreamApiHandler stream,
            string dataDir)
        {
            var method = ctx.Request.Method;

            if (method == "GET" && path == "/api/ping")
            {
                if (!RequestAuthHelper.CanServeLanAsset(ctx, _ncm.ShouldListenAnyIp))
                {
                    ctx.Response.StatusCode = 403;
                    return true;
                }
                var wantsJson = ctx.Request.Query.ContainsKey("meta")
                    || (ctx.Request.Headers.Accept.ToString()?.IndexOf("application/json", StringComparison.OrdinalIgnoreCase) >= 0);
                if (wantsJson)
                {
                    var meta = AppMetaService.GetPayload(_ncm.RootPath);
                    await WriteJsonAsync(ctx, new Dictionary<string, object>
                    {
                        ["ok"] = true,
                        ["version"] = meta.TryGetValue("version", out var v) ? v : AppMetaService.ReadVersionFile(_ncm.RootPath),
                        ["protocol"] = meta.TryGetValue("protocol", out var p) ? p : 3,
                        ["assetRevision"] = meta.TryGetValue("assetRevision", out var r) ? r : meta["version"],
                    });
                }
                else
                {
                    await WritePlainAsync(ctx, "ok");
                }
                return true;
            }

            if (method == "GET" && path == "/api/app-meta")
            {
                if (!RequestAuthHelper.CanServeLanAsset(ctx, _ncm.ShouldListenAnyIp))
                {
                    ctx.Response.StatusCode = 403;
                    return true;
                }
                await WriteJsonAsync(ctx, AppMetaService.GetPayload(_ncm.RootPath));
                return true;
            }

            if (method == "GET" && path == "/api/remote-token")
            {
                if (!RequestAuthHelper.IsLocalRequest(ctx))
                {
                    ctx.Response.StatusCode = 403;
                    await WritePlainAsync(ctx, "acesso negado");
                    return true;
                }
                var token = SecurityRuntime.Stack.Tokens.EnsureRemoteToken();
                await WritePlainAsync(ctx, token);
                return true;
            }

            if (method == "POST" && path == "/api/auth/pair-token")
            {
                var pair = SecurityRuntime.Stack.Tokens.CreatePairToken();
                await WriteJsonAsync(ctx, new Dictionary<string, object>
                {
                    ["ok"] = true,
                    ["token"] = pair,
                    ["expiresInSeconds"] = (int)TokenManager.PairTokenTtl.TotalSeconds
                });
                return true;
            }

            if (method == "POST" && path == "/api/auth/rotate-token")
            {
                var rotated = SecurityRuntime.Stack.Tokens.RotateRemoteToken();
                await WriteJsonAsync(ctx, new Dictionary<string, object> { ["ok"] = true, ["rotated"] = true, ["length"] = rotated.Length });
                return true;
            }

            if (method == "GET" && path == "/api/security/audit")
            {
                await WriteJsonAsync(ctx, SecurityRuntime.Stack.Audit.Run());
                return true;
            }

            if (method == "GET" && path == "/api/performance")
            {
                var perf = PerformanceRuntime.Stack != null
                    ? PerformanceRuntime.Stack.Snapshot()
                    : new Dictionary<string, object> { { "ok", false }, { "error", "performance stack unavailable" } };
                await WriteJsonAsync(ctx, perf);
                return true;
            }

            if (method == "GET" && path == "/api/restart-worker")
            {
                if (!RequestAuthHelper.IsLocalRequest(ctx))
                {
                    ctx.Response.StatusCode = 403;
                    await WritePlainAsync(ctx, "acesso negado");
                    return true;
                }
                ctx.Response.StatusCode = 200;
                await WritePlainAsync(ctx, "ok");
                _ = Task.Run(async () => await _ncm.RestartServerAsync());
                return true;
            }

            if (method == "GET" && path == "/api/shutdown")
            {
                if (!RequestAuthHelper.IsLocalRequest(ctx))
                {
                    ctx.Response.StatusCode = 403;
                    await WritePlainAsync(ctx, "acesso negado");
                    return true;
                }
                ctx.Response.StatusCode = 200;
                await WritePlainAsync(ctx, "ok");
                _ = Task.Run(async () => await StopAsync());
                return true;
            }

            if (method == "GET" && path == "/api/health")
            {
                await WriteJsonAsync(ctx, _ncm.BuildHealthPayload());
                return true;
            }

            if (method == "GET" && path == "/api/diagnostics")
            {
                await WriteJsonAsync(ctx, _ncm.BuildDiagnosticsPayload());
                return true;
            }

            if (method == "GET" && path == "/api/network/status")
            {
                if (!RequestAuthHelper.IsLocalRequest(ctx))
                {
                    ctx.Response.StatusCode = 403;
                    return true;
                }
                await WriteJsonAsync(ctx, _ncm.GetStatusPayload());
                return true;
            }

            if (method == "GET" && path == "/api/network/discover")
            {
                if (!RequestAuthHelper.CanServeLanAsset(ctx, _ncm.ShouldListenAnyIp))
                {
                    ctx.Response.StatusCode = 403;
                    return true;
                }
                await WriteJsonAsync(ctx, _ncm.Discover());
                return true;
            }

            if (method == "GET" && path == "/api/network/qr")
            {
                if (!RequestAuthHelper.CanServeLanAsset(ctx, _ncm.ShouldListenAnyIp))
                {
                    ctx.Response.StatusCode = 403;
                    return true;
                }
                await WriteJsonAsync(ctx, _ncm.BuildQrPayload());
                return true;
            }

            if (method == "GET" && path == "/api/network/diagnostics")
            {
                if (!RequestAuthHelper.IsLocalRequest(ctx))
                {
                    ctx.Response.StatusCode = 403;
                    return true;
                }
                await WriteJsonAsync(ctx, _ncm.GetDiagnosticsPayload());
                return true;
            }

            if (method == "GET" && path == "/api/network/pin/current")
            {
                if (!RequestAuthHelper.IsLocalRequest(ctx))
                {
                    ctx.Response.StatusCode = 403;
                    return true;
                }
                var rotate = string.Equals(ctx.Request.Query["rotate"], "1", StringComparison.Ordinal)
                    || string.Equals(ctx.Request.Query["rotate"], "true", StringComparison.OrdinalIgnoreCase);
                await WriteJsonAsync(ctx, _ncm.PinAuth.GetCurrentPinPayload(rotate));
                return true;
            }

            if (method == "POST" && path == "/api/network/pin/verify")
            {
                if (!RequestAuthHelper.CanServeLanAsset(ctx, _ncm.ShouldListenAnyIp))
                {
                    ctx.Response.StatusCode = 403;
                    return true;
                }
                var body = await ReadBodyAsync(ctx);
                var json = NetworkJson.ParseObject(body);
                var pin = Convert.ToString(json.ContainsKey("pin") ? json["pin"] : "");
                var name = Convert.ToString(json.ContainsKey("name") ? json["name"] : "");
                var trust = json.ContainsKey("trust") && Convert.ToBoolean(json["trust"]);
                var ua = ctx.Request.Headers.UserAgent.ToString();
                var clientIp = ctx.Connection.RemoteIpAddress?.ToString() ?? "unknown";
                var deviceFp = Convert.ToString(json.ContainsKey("deviceFingerprint") ? json["deviceFingerprint"] : "");
                var result = _ncm.PinAuth.Verify(pin, name, trust, ua, clientIp, deviceFp);
                if (!result.Ok && result.Error == "pin_locked")
                    ctx.Response.StatusCode = 429;
                await WriteJsonAsync(ctx, new Dictionary<string, object>
                {
                    ["ok"] = result.Ok,
                    ["error"] = result.Error ?? "",
                    ["retryAfterSeconds"] = result.RetryAfterSeconds,
                    ["token"] = result.SessionToken ?? "",
                    ["refreshToken"] = result.RefreshToken ?? "",
                    ["expiresUtc"] = result.ExpiresUtc ?? "",
                    ["deviceId"] = result.DeviceId ?? "",
                    ["pinConsumed"] = result.Ok,
                    ["trust"] = trust
                });
                return true;
            }

            if (method == "GET" && path == "/api/network/session/validate")
            {
                if (!RequestAuthHelper.CanServeLanAsset(ctx, _ncm.ShouldListenAnyIp))
                {
                    ctx.Response.StatusCode = 403;
                    return true;
                }
                var token = ctx.Request.Query["token"].ToString();
                if (string.IsNullOrWhiteSpace(token))
                {
                    var auth = ctx.Request.Headers.Authorization.ToString();
                    if (!string.IsNullOrEmpty(auth) && auth.StartsWith("Bearer ", StringComparison.OrdinalIgnoreCase))
                        token = auth.Substring(7).Trim();
                }
                if (string.IsNullOrWhiteSpace(token))
                    token = Convert.ToString(ctx.Request.Headers["X-Somosum-Token"]);
                await WriteJsonAsync(ctx, _ncm.ValidateSession(token ?? ""));
                return true;
            }

            if (method == "POST" && path == "/api/network/rebind")
            {
                if (!RequestAuthHelper.IsLocalRequest(ctx))
                {
                    ctx.Response.StatusCode = 403;
                    return true;
                }
                await WriteJsonAsync(ctx, new Dictionary<string, object> { ["ok"] = true, ["rebind"] = true });
                _ = Task.Run(async () => await _ncm.HandleNetworkRebindAsync());
                return true;
            }

            if (method == "POST" && path == "/api/network/register")
            {
                if (!RequestAuthHelper.IsLocalRequest(ctx))
                {
                    ctx.Response.StatusCode = 403;
                    return true;
                }
                var repair = false;
                try
                {
                    var body = await ReadBodyAsync(ctx);
                    var json = NetworkJson.ParseObject(body);
                    if (json.ContainsKey("repair")) repair = Convert.ToBoolean(json["repair"]);
                }
                catch { /* body opcional */ }
                var payload = await _ncm.ApplyLanRegistrationAsync(repair);
                await WriteJsonAsync(ctx, payload);
                return true;
            }

            if (method == "POST" && path == "/api/network/lan-mode")
            {
                if (!RequestAuthHelper.IsLocalRequest(ctx))
                {
                    ctx.Response.StatusCode = 403;
                    return true;
                }
                var enabled = false;
                try
                {
                    var body = await ReadBodyAsync(ctx);
                    var json = NetworkJson.ParseObject(body);
                    if (json.ContainsKey("lanMode")) enabled = Convert.ToBoolean(json["lanMode"]);
                }
                catch { /* body */ }
                await WriteJsonAsync(ctx, _ncm.SetLanMode(enabled));
                return true;
            }

            if (method == "GET" && path == "/api/network/pair/list")
            {
                if (!RequestAuthHelper.IsLocalRequest(ctx))
                {
                    ctx.Response.StatusCode = 403;
                    return true;
                }
                await WriteJsonAsync(ctx, _ncm.ListPairings());
                return true;
            }

            if (method == "POST" && path == "/api/network/pair/approve")
            {
                if (!RequestAuthHelper.IsLocalRequest(ctx))
                {
                    ctx.Response.StatusCode = 403;
                    return true;
                }
                var body = await ReadBodyAsync(ctx);
                var json = NetworkJson.ParseObject(body);
                var deviceId = Convert.ToString(json.ContainsKey("deviceId") ? json["deviceId"] : "");
                var name = Convert.ToString(json.ContainsKey("name") ? json["name"] : "");
                await WriteJsonAsync(ctx, _ncm.ApprovePairing(deviceId, name));
                return true;
            }

            if (method == "POST" && path == "/api/network/pair/revoke")
            {
                if (!RequestAuthHelper.IsLocalRequest(ctx))
                {
                    ctx.Response.StatusCode = 403;
                    return true;
                }
                var body = await ReadBodyAsync(ctx);
                var json = NetworkJson.ParseObject(body);
                var deviceId = Convert.ToString(json.ContainsKey("deviceId") ? json["deviceId"] : "");
                await WriteJsonAsync(ctx, _ncm.RevokePairing(deviceId));
                return true;
            }

            if (method == "POST" && path == "/api/network/firewall/repair")
            {
                if (!RequestAuthHelper.IsLocalRequest(ctx))
                {
                    ctx.Response.StatusCode = 403;
                    return true;
                }
                var repair = await FirewallRepairService.RepairAsync(_ncm.Port);
                await WriteJsonAsync(ctx, new Dictionary<string, object>
                {
                    ["ok"] = repair.Ok,
                    ["message"] = repair.Message ?? "",
                    ["requiresElevation"] = repair.RequiresElevation
                });
                return true;
            }

            if (method == "GET" && path == "/api/lan-info")
            {
                var includeSecrets = RequestAuthHelper.IsLocalRequest(ctx);
                await WriteJsonAsync(ctx, _ncm.BuildLanInfo(includeSecrets));
                return true;
            }

            if (method == "GET" && path == "/api/sync/state")
            {
                if (!RequestAuthHelper.ValidateSyncToken(ctx, dataDir))
                {
                    ctx.Response.StatusCode = 403;
                    await ctx.Response.WriteAsync("token invalido");
                    return true;
                }
                ctx.Response.ContentType = "application/json; charset=utf-8";
                await ctx.Response.WriteAsync(syncStore.FullStateBody);
                return true;
            }

            if (method == "GET" && path == "/api/sync/poll")
            {
                if (!RequestAuthHelper.ValidateSyncToken(ctx, dataDir))
                {
                    ctx.Response.StatusCode = 403;
                    return true;
                }
                long since = 0;
                long.TryParse(ctx.Request.Query["since"], out since);
                var entries = syncStore.GetSince(since);
                var messages = new List<object>();
                foreach (var e in entries)
                    messages.Add(new Dictionary<string, object> { ["seq"] = e.Seq, ["ts"] = e.Ts, ["message"] = e.Message });

                await WriteJsonAsync(ctx, new Dictionary<string, object>
                {
                    ["seq"] = syncStore.CurrentSeq,
                    ["messages"] = messages
                });
                return true;
            }

            if (method == "POST" && path == "/api/sync/push")
            {
                if (!RequestAuthHelper.ValidateSyncToken(ctx, dataDir))
                {
                    ctx.Response.StatusCode = 403;
                    return true;
                }
                var body = await ReadBodyAsync(ctx);
                if (!ProtocolValidator.ValidateSyncMessage(body, _ncm.RootPath, out var protoErr))
                {
                    ctx.Response.StatusCode = 400;
                    await ctx.Response.WriteAsync(protoErr ?? "protocol_invalid");
                    return true;
                }
                var ip = ctx.Connection.RemoteIpAddress?.ToString() ?? "unknown";
                var isLocal = RequestAuthHelper.IsLocalRequest(ctx);
                if (!syncStore.TryPush(body, ip, isLocal, out var seq, out var shouldBroadcast))
                {
                    if (string.IsNullOrWhiteSpace(body))
                    {
                        ctx.Response.StatusCode = 400;
                        return true;
                    }
                    ctx.Response.StatusCode = 429;
                    await ctx.Response.WriteAsync("rate limit");
                    return true;
                }
                if (shouldBroadcast)
                    await wsHub.BroadcastFromPushAsync(body, null, ctx.RequestAborted);
                ctx.Response.ContentType = "application/json";
                await ctx.Response.WriteAsync("{\"seq\":" + seq + "}");
                return true;
            }

            if (method == "POST" && path == "/api/sync/push-batch")
            {
                if (!RequestAuthHelper.ValidateSyncToken(ctx, dataDir))
                {
                    ctx.Response.StatusCode = 403;
                    return true;
                }
                var batchBody = await ReadBodyAsync(ctx);
                var ip = ctx.Connection.RemoteIpAddress?.ToString() ?? "unknown";
                var isLocal = RequestAuthHelper.IsLocalRequest(ctx);
                var parsed = NetworkJson.ParseObject(batchBody);
                var list = new List<string>();
                if (parsed.ContainsKey("messages") && parsed["messages"] is System.Collections.IEnumerable enumerable)
                {
                    foreach (var item in enumerable)
                    {
                        if (item == null) continue;
                        if (item is string s) list.Add(s);
                        else list.Add(NetworkJson.Serialize(item));
                    }
                }
                if (list.Count == 0)
                {
                    ctx.Response.StatusCode = 400;
                    await ctx.Response.WriteAsync("{\"ok\":false,\"error\":\"messages_required\"}");
                    return true;
                }
                if (!syncStore.TryPushBatch(list, ip, isLocal, out var lastSeq, out var accepted))
                {
                    ctx.Response.StatusCode = 429;
                    await ctx.Response.WriteAsync("rate limit");
                    return true;
                }
                foreach (var msg in list)
                    await wsHub.BroadcastFromPushAsync(msg);
                ctx.Response.ContentType = "application/json";
                await ctx.Response.WriteAsync("{\"ok\":true,\"lastSeq\":" + lastSeq + ",\"accepted\":" + accepted + "}");
                return true;
            }

            if (await storage.TryHandleAsync(ctx))
                return true;

            if (await stream.TryHandleAsync(ctx, path))
                return true;

            return false;
        }

        private async Task ServeStaticAsync(HttpContext ctx, string path)
        {
            if (path == "/") path = "/control.html";

            if (StaticFilePolicy.IsBlocked(_ncm.RootPath, path, out var blockReason))
            {
                StaticFilePolicy.RecordBlocked(ctx, blockReason);
                ctx.Response.StatusCode = 403;
                await ctx.Response.WriteAsync("acesso negado");
                return;
            }

            var filePath = Somosum.Core.ContentLayout.MapUrlToPhysical(_ncm.RootPath, path);
            if (!File.Exists(filePath))
            {
                ctx.Response.StatusCode = 404;
                return;
            }

            var full = Path.GetFullPath(filePath);
            if (!full.StartsWith(_ncm.RootPath, StringComparison.OrdinalIgnoreCase))
            {
                ctx.Response.StatusCode = 403;
                return;
            }

            ctx.Response.ContentType = GetContentType(full);
            var ext = Path.GetExtension(full).ToLowerInvariant();
            if (ext is ".js" or ".css" or ".mjs")
            {
                var rev = AppMetaService.GetPayload(_ncm.RootPath);
                var assetRev = rev.TryGetValue("assetRevision", out var ar) ? ar?.ToString() : rev["version"]?.ToString();
                ctx.Response.Headers.CacheControl = "no-cache";
                if (!string.IsNullOrEmpty(assetRev))
                    ctx.Response.Headers.ETag = "\"somosum-" + assetRev + "\"";
            }
            SecurityHeaders.Apply(ctx, false);
            await ctx.Response.SendFileAsync(full);
        }

        private static string GetContentType(string path)
        {
            var ext = Path.GetExtension(path).ToLowerInvariant();
            return ext switch
            {
                ".html" => "text/html; charset=utf-8",
                ".js" => "application/javascript; charset=utf-8",
                ".css" => "text/css; charset=utf-8",
                ".json" => "application/json; charset=utf-8",
                ".png" => "image/png",
                ".jpg" or ".jpeg" => "image/jpeg",
                ".gif" => "image/gif",
                ".webp" => "image/webp",
                ".svg" => "image/svg+xml",
                ".mp4" => "video/mp4",
                ".webm" => "video/webm",
                ".mp3" => "audio/mpeg",
                ".wav" => "audio/wav",
                ".ogg" => "audio/ogg",
                ".woff2" => "font/woff2",
                ".woff" => "font/woff",
                ".ttf" => "font/ttf",
                ".otf" => "font/otf",
                ".webmanifest" => "application/manifest+json",
                ".ico" => "image/x-icon",
                ".md" => "text/markdown; charset=utf-8",
                ".txt" => "text/plain; charset=utf-8",
                ".zip" => "application/zip",
                ".7z" => "application/x-7z-compressed",
                _ => "application/octet-stream"
            };
        }

        private static async Task WriteJsonAsync(HttpContext ctx, object obj)
        {
            ctx.Response.ContentType = "application/json; charset=utf-8";
            await ctx.Response.WriteAsync(NetworkJson.Serialize(obj));
        }

        private static async Task WritePlainAsync(HttpContext ctx, string text)
        {
            ctx.Response.ContentType = "text/plain; charset=utf-8";
            await ctx.Response.WriteAsync(text ?? string.Empty);
        }

        private static async Task<string> ReadBodyAsync(HttpContext ctx)
        {
            using var reader = new StreamReader(ctx.Request.Body, Encoding.UTF8);
            return await reader.ReadToEndAsync();
        }

        private static async Task WaitForPingAsync(int port, int timeoutMs, bool tls = false)
        {
            var deadline = DateTime.UtcNow.AddMilliseconds(timeoutMs);
            var scheme = tls ? "https" : "http";
            var handler = new System.Net.Http.HttpClientHandler();
            if (tls)
            {
                // Cert self-signed em loopback � aceito s� aqui, para o health check interno.
                handler.ServerCertificateCustomValidationCallback = (_, __, ___, ____) => true;
            }
            while (DateTime.UtcNow < deadline)
            {
                try
                {
                    using var client = new System.Net.Http.HttpClient(handler, false) { Timeout = TimeSpan.FromSeconds(2) };
                    var text = await client.GetStringAsync(scheme + "://127.0.0.1:" + port + "/api/ping");
                    if (text.Trim() == "ok") { handler.Dispose(); return; }
                }
                catch { /* retry */ }
                await Task.Delay(200);
            }
            handler.Dispose();
        }

        public void Dispose()
        {
            StopAsync().GetAwaiter().GetResult();
        }
    }
}
