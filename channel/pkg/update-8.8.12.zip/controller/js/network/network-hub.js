/**
 * Network Hub — UI canônica de Rede (Painel + Controle).
 * Fluxo: status → ações → PIN → QR → URLs → aparelhos.
 */
import { loadRemoteToken } from '../runtime/facades/sync-runtime.js';
import { drawQrToCanvas } from '../ui/qr-lite.js';
import {
  enableLanModeFlow,
  disableLanModeFlow,
  networkRegisterPorts,
  networkRepairFirewall,
  waitForLanBind,
  beginRebindGrace,
  networkPairList,
  networkPairApprove,
  networkPairRevoke,
} from '../runtime/facades/network-runtime.js';
import { mountLivePin, stopPinTimer } from './network-panel.js';

const QR_SIZE = 260;
const POLL_MS = 4000;

const _hubs = new WeakMap();

function esc(t) {
  const d = document.createElement('div');
  d.textContent = t ?? '';
  return d.innerHTML;
}

async function fetchJson(url, ms = 6000) {
  const ctrl = typeof AbortController !== 'undefined' ? new AbortController() : null;
  const timer = ctrl ? setTimeout(() => ctrl.abort(), ms) : null;
  try {
    const res = await fetch(url, { cache: 'no-store', signal: ctrl?.signal });
    if (timer) clearTimeout(timer);
    if (!res.ok) return null;
    return res.json();
  } catch {
    if (timer) clearTimeout(timer);
    return null;
  }
}

function hubEl(root, sel) {
  return root?.querySelector(sel) ?? null;
}

function deviceId(d) {
  return d?.id || d?.Id || d?.deviceId || '';
}

function deviceName(d) {
  return d?.name || d?.Name || 'Dispositivo';
}

function normalizePresence(raw) {
  const list = Array.isArray(raw?.clients) ? raw.clients : (Array.isArray(raw) ? raw : []);
  return list.map((c) => ({
    label: c.label || c.name || c.role || 'Cliente',
    role: c.role || '—',
    online: c.online !== false,
    ageMs: c.ageMs ?? c.age ?? null,
  }));
}

function normalizeDeviceRegistry(raw) {
  const list = Array.isArray(raw?.devices) ? raw.devices : (Array.isArray(raw) ? raw : []);
  return list.map((c) => ({
    label: c.label || c.name || c.role || 'Aparelho',
    role: c.role || '—',
    online: c.online !== false,
    ageMs: c.ageMs ?? c.age ?? null,
    remoteIp: c.remoteIp || c.ip || '',
    wsConnected: !!c.wsConnected,
    authorized: c.authorized,
  }));
}

function hubHtml(surface) {
  const modClass = surface === 'control' ? ' network-hub--control' : ' network-hub--panel';
  return `
    <div class="network-hub${modClass}" data-network-hub>
      <section class="network-hub__block network-hub__status" data-hub-status role="status">
        <div class="network-hub__status-row">
          <span class="network-hub__badge" data-hub-badge>Verificando…</span>
          <span class="network-hub__meta" data-hub-meta></span>
        </div>
        <p class="network-hub__status-msg" data-hub-msg>Conectando ao servidor…</p>
      </section>

      <section class="network-hub__block network-hub__actions">
        <label class="network-hub__lan-toggle">
          <input type="checkbox" class="su-switch" data-hub-lan />
          <span>
            <strong>Modo LAN</strong>
            <small>Celular e Púlpito na mesma Wi‑Fi</small>
          </span>
        </label>
        <div class="network-hub__action-row">
          <button type="button" class="network-hub__btn network-hub__btn--primary" data-hub-prepare>Preparar rede</button>
          <button type="button" class="network-hub__btn network-hub__btn--ghost" data-hub-firewall>Reparar firewall</button>
          <button type="button" class="network-hub__btn network-hub__btn--ghost" data-hub-wizard>Assistente</button>
        </div>
      </section>

      <section class="network-hub__block network-hub__pin network-hub__anim" data-hub-pin-section hidden>
        <div data-hub-pin-host></div>
      </section>

      <section class="network-hub__block network-hub__qr network-hub__anim" data-hub-qr-section>
        <h3 class="network-hub__heading">Escaneie com a câmera</h3>
        <p class="network-hub__lead">QR abre o link · PIN de 1 uso libera o aparelho</p>
        <div class="network-hub__qr-grid">
          <figure class="network-hub__qr-card">
            <canvas data-hub-qr-remote width="${QR_SIZE}" height="${QR_SIZE}" aria-label="QR Remote"></canvas>
            <figcaption>Remote · Celular</figcaption>
          </figure>
          <figure class="network-hub__qr-card">
            <canvas data-hub-qr-stage width="${QR_SIZE}" height="${QR_SIZE}" aria-label="QR Púlpito"></canvas>
            <figcaption>Púlpito · Stage</figcaption>
          </figure>
        </div>
      </section>

      <section class="network-hub__block network-hub__urls network-hub__anim" data-hub-urls-section>
        <h3 class="network-hub__heading">URLs</h3>
        <div class="network-hub__url-list" data-hub-urls></div>
      </section>

      <section class="network-hub__block network-hub__devices network-hub__anim">
        <div class="network-hub__devices-head">
          <h3 class="network-hub__heading">Aparelhos</h3>
          <div class="network-hub__tabs" role="tablist">
            <button type="button" class="network-hub__tab is-active" data-hub-tab="pair" role="tab">Pareados</button>
            <button type="button" class="network-hub__tab" data-hub-tab="presence" role="tab">Online agora</button>
          </div>
        </div>
        <div class="network-hub__tab-panel is-active" data-hub-panel="pair" role="tabpanel">
          <ul class="network-hub__list" data-hub-pair-list></ul>
        </div>
        <div class="network-hub__tab-panel" data-hub-panel="presence" role="tabpanel" hidden>
          <ul class="network-hub__list" data-hub-presence-list></ul>
        </div>
        <button type="button" class="network-hub__btn network-hub__btn--ghost network-hub__btn--sm" data-hub-refresh-devices>Atualizar aparelhos</button>
      </section>

      <section class="network-hub__block network-hub__wizard-wrap" data-hub-wizard-wrap hidden>
        <div class="network-hub__wizard-head">
          <h3 class="network-hub__heading">Assistente de conexão</h3>
          <button type="button" class="network-hub__btn network-hub__btn--ghost network-hub__btn--sm" data-hub-wizard-close>Fechar</button>
        </div>
        <div class="network-hub__wizard-host" data-hub-wizard-host></div>
      </section>
    </div>`;
}

function isLanPublicReady(info) {
  if (!info) return false;
  const stage = String(info.guarantee?.stage || info.guaranteeStage || '').toLowerCase();
  const probeOk = info.guarantee?.probeOk === true || info.lanProbeOk === true;
  return !!(info.lanBindOk && info.listeningPublic !== false
    && (stage === 'ready' || probeOk || info.guarantee?.ready === true));
}

async function resolveUrls(lastHealth = {}) {
  const h = lastHealth || {};
  let host = h.lanIp || '127.0.0.1';
  const port = h.port || location.port || '8765';
  let lanBindOk = false;
  let lanMode = !!(h.lanMode);
  let guaranteeStage = '';
  let guaranteeMsg = '';
  let remoteUrl = '';
  let stageUrl = '';
  try {
    const info = await fetchJson('/api/lan-info');
    if (info) {
      host = info.lanIp || host;
      lanBindOk = isLanPublicReady(info);
      lanMode = !!info.lanMode;
      guaranteeStage = String(info.guarantee?.stage || info.guaranteeStage || '');
      guaranteeMsg = String(info.guarantee?.message || '');
      const pubRemote = info.remoteUrl || '';
      const pubStage = info.stageUrl || info.stageQrUrl || '';
      const isLocal = (u) => !u || String(u).includes('127.0.0.1') || String(u).includes('localhost');
      if (lanBindOk && !isLocal(pubRemote)) {
        remoteUrl = pubRemote;
        stageUrl = isLocal(pubStage) ? '' : pubStage;
      } else {
        lanBindOk = false;
        remoteUrl = info.localRemoteUrl || '';
        stageUrl = info.localStageUrl || '';
      }
    }
  } catch { /* ignore */ }
  const token = await loadRemoteToken().catch(() => '');
  const tq = token ? `?token=${encodeURIComponent(token)}` : '';
  const lanHost = h.lanIp && h.lanIp !== '127.0.0.1' ? h.lanIp : host;
  if (!remoteUrl) {
    remoteUrl = lanBindOk && lanHost !== '127.0.0.1'
      ? `http://${lanHost}:${port}/remote.html${tq}`
      : `http://127.0.0.1:${port}/remote.html${tq}`;
  }
  if (!stageUrl) {
    stageUrl = lanBindOk && lanHost !== '127.0.0.1'
      ? `http://${lanHost}:${port}/stage.html${tq}`
      : `http://127.0.0.1:${port}/stage.html${tq}`;
  }
  return {
    lanHost, port, lanBindOk, lanMode, remoteUrl, stageUrl, tokenSig: token || '',
    guaranteeStage, guaranteeMsg,
  };
}

async function paintQr(canvas, url, root) {
  if (!canvas || !url) return;
  if (canvas.dataset.qrUrl === url) return;
  canvas.dataset.qrUrl = url;
  const card = canvas.closest('.network-hub__qr-card');
  card?.classList.add('is-refreshing');
  try {
    await drawQrToCanvas(canvas, url, { size: QR_SIZE, margin: 2 });
  } catch { /* ignore */ }
  requestAnimationFrame(() => card?.classList.remove('is-refreshing'));
}

function paintStatus(root, { lanBindOk, lanMode, lanHost, port, guaranteeStage, guaranteeMsg }) {
  const badge = hubEl(root, '[data-hub-badge]');
  const meta = hubEl(root, '[data-hub-meta]');
  const msg = hubEl(root, '[data-hub-msg]');
  const statusBlock = hubEl(root, '[data-hub-status]');
  if (!badge || !msg) return;
  statusBlock?.classList.remove('is-ok', 'is-warn');
  const stage = String(guaranteeStage || '').toLowerCase();
  if (lanBindOk && lanHost && lanHost !== '127.0.0.1') {
    statusBlock?.classList.add('is-ok');
    badge.textContent = 'LAN pronta';
    meta.textContent = `${lanHost} · porta ${port}`;
    msg.innerHTML = 'Rede comprovada neste PC. Escaneie o QR no <strong>mesmo Wi‑Fi</strong>. Digite o PIN de <strong>1 uso</strong>.';
  } else if (lanMode && (stage === 'need_admin' || stage === 'failed' || !stage)) {
    statusBlock?.classList.add('is-warn');
    badge.textContent = stage === 'failed' ? 'Rede bloqueada' : 'Aguardando UAC';
    meta.textContent = lanHost !== '127.0.0.1' ? `${lanHost} · porta ${port}` : `porta ${port}`;
    msg.innerHTML = guaranteeMsg
      ? `${guaranteeMsg} Use <strong>Preparar rede</strong> e confirme o UAC.`
      : 'Clique em <strong>Preparar rede</strong> e confirme o UAC. Sem isso o QR do tablet não funciona (só neste PC).';
  } else if (lanMode && (stage === 'binding' || stage === 'probing' || stage === 'firewall')) {
    statusBlock?.classList.add('is-warn');
    badge.textContent = stage === 'probing' ? 'Testando LAN…' : 'Abrindo rede…';
    meta.textContent = lanHost !== '127.0.0.1' ? `${lanHost} · porta ${port}` : `porta ${port}`;
    msg.textContent = guaranteeMsg || 'Aguarde — comprovando que o tablet consegue alcançar este PC…';
  } else if (lanMode) {
    statusBlock?.classList.add('is-warn');
    badge.textContent = 'Preparando…';
    meta.textContent = lanHost !== '127.0.0.1' ? `${lanHost} · porta ${port}` : `porta ${port}`;
    msg.innerHTML = 'Use <strong>Preparar rede</strong> se o QR ainda mostrar só este PC.';
  } else {
    badge.textContent = 'Somente local';
    meta.textContent = `127.0.0.1 · porta ${port}`;
    msg.textContent = 'Ative o Modo LAN e prepare a rede para conectar celular ou tablet na Wi‑Fi.';
  }
}

function paintUrls(root, routes, ctx) {
  const box = hubEl(root, '[data-hub-urls]');
  if (!box) return;
  const sig = routes.map((r) => r[1]).join('|');
  if (box.dataset.sig === sig) return;
  box.dataset.sig = sig;
  box.innerHTML = routes.map(([label, url], i) => `
    <div class="network-hub__url-row">
      <span class="network-hub__url-label">${esc(label)}</span>
      <input type="text" readonly value="${String(url).replace(/"/g, '&quot;')}" data-hub-url-input="${i}" />
      <button type="button" class="network-hub__btn network-hub__btn--ghost network-hub__btn--sm" data-hub-url-copy="${i}">Copiar</button>
      <button type="button" class="network-hub__btn network-hub__btn--ghost network-hub__btn--sm" data-hub-url-open="${i}">Abrir</button>
    </div>`).join('');
  box.querySelectorAll('[data-hub-url-copy]').forEach((btn) => {
    btn.onclick = () => {
      const inp = box.querySelector(`[data-hub-url-input="${btn.dataset.hubUrlCopy}"]`);
      navigator.clipboard?.writeText(inp?.value || '');
      ctx.toast?.('URL copiada', 'success');
    };
  });
  box.querySelectorAll('[data-hub-url-open]').forEach((btn) => {
    btn.onclick = () => {
      const inp = box.querySelector(`[data-hub-url-input="${btn.dataset.hubUrlOpen}"]`);
      if (inp?.value) window.open(inp.value, '_blank');
    };
  });
}

async function paintPin(root, ctx, lanBindOk, lanMode) {
  const section = hubEl(root, '[data-hub-pin-section]');
  const host = hubEl(root, '[data-hub-pin-host]');
  if (!section || !host) return;
  if (lanBindOk) {
    section.hidden = false;
    if (!ctx.pinMounted || !host.querySelector('.network-pin-card')) {
      ctx.pinMounted = true;
      await mountLivePin(host, {
        toast: ctx.toast,
        onPinChanged: () => {
          root.classList.add('network-hub--pin-pulse');
          setTimeout(() => root.classList.remove('network-hub--pin-pulse'), 700);
          root.querySelectorAll('.network-hub__qr-card').forEach((card) => {
            card.classList.add('is-refreshing');
            requestAnimationFrame(() => card.classList.remove('is-refreshing'));
          });
        },
      });
    }
  } else if (lanMode) {
    ctx.pinMounted = false;
    section.hidden = false;
    stopPinTimer(host);
    host.innerHTML = `<p class="network-hub__pin-wait">PIN disponível após confirmar o UAC em <strong>Preparar rede</strong>.</p>`;
  } else {
    ctx.pinMounted = false;
    section.hidden = true;
    stopPinTimer(host);
    host.innerHTML = '';
  }
}

async function paintPairList(root, ctx) {
  const list = hubEl(root, '[data-hub-pair-list]');
  if (!list) return;
  try {
    const data = await networkPairList();
    const devices = Array.isArray(data?.devices) ? data.devices : [];
    if (!devices.length) {
      list.innerHTML = '<li class="network-hub__list-empty">Nenhum aparelho pareado ainda</li>';
      return;
    }
    list.innerHTML = devices.map((d) => {
      const id = esc(deviceId(d));
      const name = esc(deviceName(d));
      const pending = !!(d.pending || d.Pending);
      const auth = !!(d.authorized || d.Authorized);
      const status = pending && !auth ? 'Pendente' : (auth ? 'Autorizado' : 'Revogado');
      const actions = pending && !auth
        ? `<button type="button" class="network-hub__btn network-hub__btn--sm" data-pair-approve="${id}">Aprovar</button>
           <button type="button" class="network-hub__btn network-hub__btn--sm" data-pair-revoke="${id}">Recusar</button>`
        : `<button type="button" class="network-hub__btn network-hub__btn--sm" data-pair-revoke="${id}">Revogar</button>`;
      return `<li class="network-hub__list-item ${pending && !auth ? 'is-warn' : (auth ? 'is-ok' : '')}">
        <div><strong>${name}</strong> <span class="network-hub__hint">${status}</span></div>
        <div class="network-hub__list-actions">${actions}</div>
      </li>`;
    }).join('');
    list.querySelectorAll('[data-pair-approve]').forEach((btn) => {
      btn.onclick = async () => {
        const res = await networkPairApprove(btn.getAttribute('data-pair-approve'), '');
        ctx.toast?.(res?.ok ? 'Aparelho aprovado' : 'Falha ao aprovar', res?.ok ? 'success' : 'warn');
        void paintPairList(root, ctx);
      };
    });
    list.querySelectorAll('[data-pair-revoke]').forEach((btn) => {
      btn.onclick = async () => {
        const res = await networkPairRevoke(btn.getAttribute('data-pair-revoke'));
        ctx.toast?.(res?.ok ? 'Pareamento removido' : 'Falha ao revogar', res?.ok ? 'success' : 'warn');
        void paintPairList(root, ctx);
      };
    });
  } catch {
    list.innerHTML = '<li class="network-hub__list-empty">Lista indisponível</li>';
  }
}

async function paintPresence(root) {
  const list = hubEl(root, '[data-hub-presence-list]');
  if (!list) return;
  const roleLabel = (r) => ({
    remote: 'Remote',
    stage: 'Púlpito',
    screen: 'Projetor',
    control: 'Controle',
  }[r] || r);
  try {
    const raw = await fetchJson('/api/clients/registry?maxAge=60000', 5000);
    const devices = normalizeDeviceRegistry(raw);
    if (!devices.length) {
      list.innerHTML = '<li class="network-hub__list-empty">Nenhum aparelho online</li>';
      return;
    }
    list.innerHTML = devices.map((c) => {
      const age = c.ageMs != null ? `${Math.round(c.ageMs / 1000)}s` : '—';
      const on = c.online ? 'is-on' : '';
      const ip = c.remoteIp ? ` · ${esc(c.remoteIp)}` : '';
      return `<li class="network-hub__list-item ${on}">
        <span class="network-hub__presence-dot ${on}"></span>
        <div><strong>${esc(c.label)}</strong>
          <span class="network-hub__hint">${esc(roleLabel(c.role))}${ip} · há ${age}</span></div>
      </li>`;
    }).join('');
  } catch {
    try {
      const raw = await fetchJson('/api/clients/presence?maxAge=60000', 5000);
      const clients = normalizePresence(raw);
      if (!clients.length) {
        list.innerHTML = '<li class="network-hub__list-empty">Nenhum cliente recente</li>';
        return;
      }
      list.innerHTML = clients.map((c) => {
        const age = c.ageMs != null ? `${Math.round(c.ageMs / 1000)}s` : '—';
        return `<li class="network-hub__list-item ${c.online ? 'is-on' : ''}">
          <span class="network-hub__presence-dot ${c.online ? 'is-on' : ''}"></span>
          <strong>${esc(c.label)}</strong> · ${esc(c.role)} · há ${age}
        </li>`;
      }).join('');
    } catch {
      list.innerHTML = '<li class="network-hub__list-empty">Presença indisponível</li>';
    }
  }
}

export async function refreshNetworkHub(container, lastHealth = {}) {
  const ctx = _hubs.get(container);
  if (!ctx?.root) return;
  ctx.lastHealth = lastHealth;
  const root = ctx.root;
  const urls = await resolveUrls(lastHealth);
  const prevSig = ctx.urlSig || '';
  const nextSig = `${urls.remoteUrl}|${urls.stageUrl}|${urls.tokenSig}|${urls.lanBindOk}`;
  ctx.urlSig = nextSig;

  paintStatus(root, urls);

  const lanCb = hubEl(root, '[data-hub-lan]');
  if (lanCb && document.activeElement !== lanCb) {
    lanCb.checked = urls.lanMode;
  }

  await paintPin(root, ctx, urls.lanBindOk, urls.lanMode);

  const qrRemote = hubEl(root, '[data-hub-qr-remote]');
  const qrStage = hubEl(root, '[data-hub-qr-stage]');
  await paintQr(qrRemote, urls.remoteUrl, root);
  await paintQr(qrStage, urls.stageUrl, root);
  if (prevSig && prevSig !== nextSig) {
    root.querySelectorAll('.network-hub__qr-card').forEach((card) => {
      card.classList.add('is-refreshing');
      requestAnimationFrame(() => card.classList.remove('is-refreshing'));
    });
  }

  const routes = [
    ['Remote', urls.remoteUrl],
    ['Púlpito', urls.stageUrl],
    ['Controle', urls.lanBindOk
      ? `http://${urls.lanHost}:${urls.port}/control.html`
      : `http://127.0.0.1:${urls.port}/control.html`],
  ];
  paintUrls(root, routes, ctx);

  await paintPairList(root, ctx);
  await paintPresence(root);
}

async function runPrepareLan(ctx) {
  ctx.toast?.('Preparando rede…', 'info');
  const reg = await networkRegisterPorts(false);
  if (reg?.pending || reg?.needsElevation || reg?.NeedsElevation) {
    ctx.toast?.('Confirme o UAC do Windows (Sim)…', 'info');
    beginRebindGrace(25000);
    await waitForLanBind(50000);
  } else if (reg?.ok || reg?.Success) {
    ctx.toast?.('Rede preparada', 'success');
  } else {
    ctx.toast?.(reg?.message || 'Use Preparar rede novamente', 'warn');
  }
  await refreshNetworkHub(ctx.container, ctx.lastHealth);
}

function wireHubEvents(ctx) {
  const { root, container } = ctx;
  if (root.dataset.wired) return;
  root.dataset.wired = '1';

  hubEl(root, '[data-hub-lan]')?.addEventListener('change', async (e) => {
    const on = !!e.target.checked;
    e.target.disabled = true;
    try {
      if (on) {
        await enableLanModeFlow({
          savePrefs: ctx.savePrefs,
          getPrefs: ctx.getPrefs,
          requestSoftRestart: ctx.requestSoftRestart,
          toast: ctx.toast,
        });
        if (!ctx.lastHealth?.lanBindOk) await runPrepareLan(ctx);
      } else {
        await disableLanModeFlow({
          savePrefs: ctx.savePrefs,
          getPrefs: ctx.getPrefs,
          toast: ctx.toast,
        });
      }
      let health = {};
      try {
        health = await fetch('/api/health', { cache: 'no-store' }).then((r) => r.json());
      } catch { /* lan-info no refresh */ }
      ctx.lastHealth = health;
      await refreshNetworkHub(container, health);
    } finally {
      e.target.disabled = false;
    }
  });

  hubEl(root, '[data-hub-prepare]')?.addEventListener('click', () => { void runPrepareLan(ctx); });

  hubEl(root, '[data-hub-firewall]')?.addEventListener('click', async () => {
    ctx.toast?.('Reparando firewall…', 'info');
    const res = await networkRepairFirewall();
    if (res?.pending || res?.requiresElevation) {
      ctx.toast?.('Confirme o UAC (Sim)…', 'info');
    } else if (res?.ok) {
      ctx.toast?.(res.message || 'Firewall atualizado', 'success');
    } else {
      ctx.toast?.(res?.message || 'Não foi possível reparar', 'warn');
    }
    await refreshNetworkHub(container, ctx.lastHealth);
  });

  hubEl(root, '[data-hub-wizard]')?.addEventListener('click', async () => {
    const wrap = hubEl(root, '[data-hub-wizard-wrap]');
    const host = hubEl(root, '[data-hub-wizard-host]');
    if (!wrap || !host) return;
    wrap.hidden = false;
    const { mountNetworkWizard } = await import('./network-wizard.js');
    mountNetworkWizard(host, {
      toast: ctx.toast,
      ensureLanMode: async () => {
        hubEl(root, '[data-hub-lan]').checked = true;
        ctx.savePrefs?.({ ...ctx.getPrefs?.(), lanMode: true });
        return runPrepareLan(ctx);
      },
      onComplete: () => refreshNetworkHub(container, ctx.lastHealth),
    });
  });

  hubEl(root, '[data-hub-wizard-close]')?.addEventListener('click', () => {
    const wrap = hubEl(root, '[data-hub-wizard-wrap]');
    const host = hubEl(root, '[data-hub-wizard-host]');
    if (wrap) wrap.hidden = true;
    if (host) host.innerHTML = '';
  });

  hubEl(root, '[data-hub-refresh-devices]')?.addEventListener('click', () => {
    void paintPairList(root, ctx);
    void paintPresence(root);
  });

  root.querySelectorAll('[data-hub-tab]').forEach((tab) => {
    tab.addEventListener('click', () => {
      const id = tab.dataset.hubTab;
      root.querySelectorAll('[data-hub-tab]').forEach((t) => t.classList.toggle('is-active', t === tab));
      root.querySelectorAll('[data-hub-panel]').forEach((p) => {
        const on = p.dataset.hubPanel === id;
        p.classList.toggle('is-active', on);
        p.hidden = !on;
      });
    });
  });
}

export function mountNetworkHub(container, options = {}) {
  if (!container) return null;
  const surface = options.surface || 'panel';
  container.innerHTML = hubHtml(surface);
  const root = container.querySelector('[data-network-hub]');
  const ctx = {
    container,
    root,
    surface,
    toast: options.toast || (() => {}),
    getPrefs: options.getPrefs || (() => ({})),
    savePrefs: options.savePrefs || (() => {}),
    requestSoftRestart: options.requestSoftRestart || (async () => {}),
    lastHealth: {},
    pollId: null,
    pinMounted: false,
  };
  _hubs.set(container, ctx);
  wireHubEvents(ctx);
  return ctx;
}

export function startNetworkHubPoll(container, getHealth = () => ({})) {
  const ctx = _hubs.get(container);
  if (!ctx) return;
  stopNetworkHubPoll(container);
  ctx.pollId = setInterval(() => {
    void (async () => {
      const h = await Promise.resolve(getHealth());
      await refreshNetworkHub(container, h && typeof h === 'object' && !Array.isArray(h) ? h : {});
    })();
  }, POLL_MS);
}

export function stopNetworkHubPoll(container) {
  const ctx = _hubs.get(container);
  if (ctx?.pollId) {
    clearInterval(ctx.pollId);
    ctx.pollId = null;
  }
}

export function destroyNetworkHub(container) {
  stopNetworkHubPoll(container);
  const ctx = _hubs.get(container);
  if (ctx?.root) stopPinTimer(ctx.root);
  _hubs.delete(container);
  if (container) container.innerHTML = '';
}
