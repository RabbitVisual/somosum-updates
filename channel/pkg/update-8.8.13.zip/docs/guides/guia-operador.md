# Guia do operador — SOMOSUM

> **Versão:** 8.8.13 · **Público:** operadores de mídia na igreja  
> **Idioma:** português do Brasil

Manual prático do dia a dia. Para detalhes técnicos, use o portal `/docs/` (tecla **D** no Controle).

---

## 1. Ligar e começar

1. Duplo clique em **`SOMOSUM.exe`** (raiz da pasta ou atalho).
2. Abre o **Painel Gerencial** e o ícone na bandeja do Windows.
3. No Painel → **Telas** (ou na bandeja): abra **Controle**, depois **Projeção** no monitor do projetor (**F11**).
4. No Controle: tecla **?** = tour guiado · tecla **D** = documentação.

**Nunca** abra `control.html` pelo Explorer (`file://`) — o app precisa do servidor local.

---

## 2. Quem faz o quê

| Janela | Responsabilidade |
|--------|------------------|
| **Painel Gerencial** | Rede, monitores, Loja, backup, desempenho, igreja, versão/novidades |
| **Controle** | Ordem do culto, slides, bibliotecas, Designer, plugins |
| **Projeção** | Tela da congregação |
| **Stage (Púlpito)** | Retorno para pregador / músicos / cantores |
| **Remote** | Celular ou 2º PC na mesma Wi‑Fi |

### Mapa do Painel

| Grupo | Seção | Para quê |
|-------|--------|----------|
| Culto | **Início** | Checklist e atalhos |
| Culto | **Telas** | Abrir Controle, Projeção, Púlpito, Remote |
| Culto | **Loja** | Recursos extras / plugins |
| Este computador | **Rede** | Wi‑Fi, código, celular |
| Este computador | **Operação** | Status neste PC |
| Este computador | **Monitores** | Projetor 1 e 2 |
| Este computador | **Desempenho** | CPU e memória |
| Este computador | **Dados** | Cópia de segurança |
| Igreja e ajuda | **Igreja** | Nome, logo, boas-vindas |
| Igreja e ajuda | **Sobre** | Versão, novidades, mapa |

---

## 3. Ritual de culto (checklist)

| Momento | Ação |
|---------|------|
| −60 min | Abrir SOMOSUM · status ok no Painel / topbar |
| −45 min | Abrir projeção no projetor · testar F11 |
| −30 min | Montar ou carregar a ordem · testar 3 slides |
| −15 min | Abrir Stage no monitor de retorno (perfil Pregador, tela cheia) |
| −5 min | Pré-culto (se usar) |
| Durante | Setas / Espaço para avançar · B = preto · L = logo |
| Pós-culto | Encerrar pela **bandeja** (não mate o processo no Gerenciador) |

---

## 4. Púlpito (Stage · Pregador)

1. No Controle: **Janelas** ou **Central Stage** → aba **Púlpito**.
2. Escolha o **monitor de retorno** do pregador.
3. Marque **Tela cheia**.
4. Clique **Abrir Púlpito tela cheia (Pregador)**.

---

## 5. Rede (celular / Remote)

1. Painel → **Rede** → ativar **Modo LAN**.
2. **Preparar rede** (pode pedir UAC / administrador).
3. Espere **LAN pronta** com IP da Wi‑Fi (se ficar em 127.0.0.1, o tablet não abre).
4. Escaneie o QR ou abra a URL no celular na mesma Wi‑Fi.

---

## 6. Backup

- Dados do usuário: pasta `model\data\`
- Exportar: **Painel → Dados** ou **Ajustes → Backup** no Controle
- Guarde o ZIP fora do PC do culto (pendrive / nuvem da igreja)

---

## 7. Atualizar o SOMOSUM

1. Painel → **Sobre** → **Procurar novidades** (precisa de internet só para baixar).
2. Confirme o reinício quando pedido.
3. O app reabre sozinho e mostra o que mudou.
4. Em **Sobre**, confira a versão e os cards **O que há de novo**.

---

## 8. Atalhos essenciais

| Tecla | Ação |
|-------|------|
| **?** | Tour guiado |
| **D** | Documentação |
| Ajuda → Verificar atualização | Procurar versão nova |
| **← →** / **Espaço** | Slide anterior / próximo |
| **B** | Tela preta |
| **L** | Logo |
| **Esc** | Limpar overlay |
| **Ctrl+S** | Salvar ordem |

Personalize em **Ajustes → Atalhos**.

---

## 9. Problemas comuns

| Sintoma | O que fazer |
|---------|-------------|
| Projeção preta / desatualizada | Reabrir Projeção · Painel → Operação / Diagnóstico |
| Stage sem modo Pregador | Abrir pela aba Púlpito |
| Celular não conecta | Preparar rede + mesma Wi‑Fi + firewall |
| Atualização fechou e não reabriu | Abra de novo o `SOMOSUM.exe` na raiz · confira Sobre |
| “Publicador desconhecido” | Normal sem certificado comercial — autor: Reinan Rodrigues |

---

## 10. Suporte

- Autor: Reinan Rodrigues · `r.rodriguesjs@gmail.com`
- Diagnóstico: Painel → Operação
- Docs offline: tecla **D**
