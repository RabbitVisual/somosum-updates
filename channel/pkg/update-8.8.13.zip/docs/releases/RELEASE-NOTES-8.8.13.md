# Release Notes — SOMOSUM 8.8.13

**Data:** 2026-08-19  
**Tipo:** padrão de fábrica deste PC + Púlpito/Remote estáveis

## Destaques

### Padrão de fábrica (Ajustes → Sistema)
- Novo botão **Restaurar padrão deste PC**.
- O SOMOSUM detecta sozinho o computador (mais leve ou desempenho) e liga as opções certas: projeção automática, resolução nativa, modo produção, sincronização Controle ↔ telas.
- Não apaga igreja, músicas, cultos nem o Modo LAN.

### Púlpito e Remote
- O Púlpito deixa de redesenhar a tela a cada sincronização (sem piscar).
- O Remote atualiza o cabeçalho no pulso da rede, sem recarregar a tela inteira.

## Como atualizar
1. Em **8.8.12**: Ajuda → Verificar atualização → **8.8.13** → confirme o reinício.
2. Se estiver atrás: suba de 1 em 1 até **8.8.13**.

## Verificação rápida
- [ ] Sobre = **8.8.13**
- [ ] Ajustes → Sistema → Restaurar padrão deste PC
- [ ] Púlpito e Remote acompanham o slide sem piscar
