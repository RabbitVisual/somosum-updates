/**
 * AppMeta — Single Source of Truth (SSOT) para versionamento SOMOSUM.
 * Regenerado por scripts/bump-version.js — não editar campos de versão manualmente.
 */
export const APP_META = Object.freeze({
  version: '8.8.13',
  build: '20260819T200859Z',
  buildDate: '2026-08-19',
  channel: 'stable',
  allowInspection: true,
  protocol: 3,
  minProtocol: 3,
  assetRevision: '8.8.13',
  dbSchemaVersion: 4,
  engineMin: '8.8.13',
  surfaces: Object.freeze({
    control: Object.freeze({ minVersion: '8.8.13', entry: 'control.html', label: 'Controle' }),
    screen: Object.freeze({ minVersion: '8.8.13', entry: 'screen.html', label: 'Projeção' }),
    stage: Object.freeze({ minVersion: '8.8.13', entry: 'stage.html', label: 'Púlpito' }),
    remote: Object.freeze({ minVersion: '8.8.13', entry: 'remote.html', label: 'Remote' }),
  }),
});

/** @deprecated use APP_META.version — mantido para compat */
export const APP_VERSION = APP_META.version;

export const APP_AUTHOR = 'Reinan Rodrigues';
export const APP_AUTHOR_EMAIL = 'r.rodriguesjs@gmail.com';
export const APP_AUTHOR_PHONE = '75992034656';
export const APP_PRODUCT = 'SOMOSUM';
export const APP_TAGLINE = 'Sistema de Projecao para Cultos - 100% offline';
export const APP_CREDITS = `Desenvolvido por ${APP_AUTHOR}`;
export const APP_DOCS_PATH = '/docs/';

export function getAppMeta() {
  if (typeof window !== 'undefined' && window.__SOMOSUM_META__) {
    return { ...APP_META, ...window.__SOMOSUM_META__ };
  }
  return APP_META;
}

export function installAppMeta(meta) {
  if (typeof window === 'undefined' || !meta) return APP_META;
  window.__SOMOSUM_META__ = meta;
  window.SOMOSUM_VERSION = meta.version || APP_META.version;
  window.SOMOSUM_PROTOCOL = meta.protocol ?? APP_META.protocol;
  window.SOMOSUM_ASSET_REVISION = meta.assetRevision || meta.version || APP_META.assetRevision;
  return getAppMeta();
}

export function creditsLine(version = getAppMeta().version) {
  return `${APP_PRODUCT} v${version} · ${APP_CREDITS}`;
}

export function formatPhoneBr(phone = APP_AUTHOR_PHONE) {
  const d = String(phone).replace(/\D/g, '');
  if (d.length === 11) return `(${d.slice(0, 2)}) ${d.slice(2, 7)}-${d.slice(7)}`;
  if (d.length === 10) return `(${d.slice(0, 2)}) ${d.slice(2, 6)}-${d.slice(6)}`;
  return phone;
}

export function docsUrl(port) {
  if (port) return `http://127.0.0.1:${port}${APP_DOCS_PATH}`;
  return APP_DOCS_PATH;
}

export function metaSummaryLine(meta = getAppMeta()) {
  return [
    `v${meta.version}`,
    meta.build ? `build ${meta.build}` : '',
    meta.protocol != null ? `protocol ${meta.protocol}` : '',
    meta.assetRevision ? `assets ${meta.assetRevision}` : '',
  ].filter(Boolean).join(' · ');
}
