/**
 * Restaura preferências de fábrica inteligentes para ESTE PC.
 * Não apaga igreja, cultos, músicas, rede LAN nem mapas MIDI.
 */
import { getPrefs, getDefaultPrefs, savePrefs, flushPrefsToDisk } from './store.js';
import { applyRenderMode } from './performance/render-prefs.js';
import { enableProductionMode } from './production-mode.js';

function detectWeakHardware() {
  try {
    return window.SOMOSUM_PERFORMANCE?.detectWeakHardware?.() || { weak: false };
  } catch {
    return { weak: false };
  }
}

function deviceMemoryGb() {
  try {
    return Number(navigator.deviceMemory) || 0;
  } catch {
    return 0;
  }
}

/** Perfil automático deste computador — o operador não escolhe. */
export function describeInstallProfile() {
  const hw = detectWeakHardware();
  const mem = deviceMemoryGb();
  const cores = Number(navigator.hardwareConcurrency) || 0;
  if (hw.weak || (mem > 0 && mem <= 4) || (cores > 0 && cores <= 2)) {
    return {
      id: 'eco',
      label: 'PC mais leve',
      detail: hw.reason || (mem ? `${mem} GB RAM` : `${cores} núcleos`),
      lowSpec: true,
      production: true,
      renderMode: 'auto',
      transition: 'none',
    };
  }
  return {
    id: 'performance',
    label: 'PC deste culto',
    detail: mem >= 8 ? `${mem} GB RAM` : (cores ? `${cores} núcleos` : 'automático'),
    lowSpec: false,
    production: true,
    renderMode: 'auto',
    transition: 'fade',
  };
}

export function buildFactoryPrefs(current = getPrefs(), profile = describeInstallProfile()) {
  const base = getDefaultPrefs();
  const cur = current || {};
  const native = window.somosumNativeShell || window.somosumRuntimeShell;
  const next = {
    ...base,
    ...cur,
    theme: base.theme,
    projectionTheme: cur.projectionTheme || base.projectionTheme,
    church: { ...base.church, ...(cur.church || {}) },
    navigation: { ...cur.navigation },
    layout: { ...base.layout, ...(cur.layout || {}) },
    ui: {
      ...base.ui,
      chromeTheme: cur.ui?.chromeTheme || 'dark',
      lowSpec: !!profile.lowSpec,
      reducedMotion: !!profile.lowSpec,
      scale: 1,
      fontScale: 1,
      highContrast: false,
    },
    lowSpec: !!profile.lowSpec,
    favorites: cur.favorites || base.favorites,
    shortcuts: cur.shortcuts || {},
    bibleVersion: cur.bibleVersion || base.bibleVersion,
    bibleQuickBook: cur.bibleQuickBook || base.bibleQuickBook,
    transition: profile.transition,
    showClock: false,
    showFooterVerse: true,
    versesPerSlide: 2,
    projectionFontBoost: 1.15,
    globalLyricsStyle: { ...base.globalLyricsStyle },
    lyricsFx: profile.lowSpec
      ? { ambient: 'none', lineEntrance: 'none', highlightPulse: false }
      : { ...base.lyricsFx },
    autoLive: true,
    slideStripLyricsMode: cur.slideStripLyricsMode || base.slideStripLyricsMode,
    rehearsalMode: false,
    productionMode: true,
    production: cur.production || null,
    blockCountdownOnErrors: false,
    highContrast: false,
    render: { ...base.render, mode: 'auto' },
    displayEngine: {
      ...base.displayEngine,
      projectorDeviceName: cur.displayEngine?.projectorDeviceName || '',
      stageDeviceName: cur.displayEngine?.stageDeviceName || '',
      knownDisplays: Array.isArray(cur.displayEngine?.knownDisplays)
        ? cur.displayEngine.knownDisplays
        : [],
      preferNativeProjectorMode: true,
      maxLegibility: true,
      videoFitDefault: 'cover',
      videoLegibility: 'shadow',
      videoLegibilityStrength: 0.45,
    },
    ambient: { ...base.ambient, ...(cur.ambient || {}), playing: false },
    countdown: {
      ...base.countdown,
      serviceTime: cur.countdown?.serviceTime || base.countdown.serviceTime,
      durationMinutes: cur.countdown?.durationMinutes || base.countdown.durationMinutes,
      active: false,
      phase: 'idle',
    },
    countdownPresets: Array.isArray(cur.countdownPresets) && cur.countdownPresets.length
      ? cur.countdownPresets
      : base.countdownPresets,
    runtimeEngine: {
      ...base.runtimeEngine,
      enabled: !!native,
      bridgePreferred: true,
      legacyFallback: false,
      authoritativeSync: true,
      authoritativeRecovery: true,
    },
    midi: cur.midi && typeof cur.midi === 'object' ? cur.midi : base.midi,
    lanMode: !!cur.lanMode,
    lanTls: !!cur.lanTls,
  };
  return applyRenderMode(next, 'auto');
}

export async function restoreFactoryPrefs() {
  const profile = describeInstallProfile();
  const next = buildFactoryPrefs(getPrefs(), profile);
  savePrefs(next);
  try { await flushPrefsToDisk(); } catch { /* local já gravou */ }
  window.__SOMOSUM_LOW_SPEC = !!profile.lowSpec;
  try {
    document.documentElement.classList.toggle('somosum-low-spec', !!profile.lowSpec);
    document.documentElement.classList.toggle('su-reduce-motion', !!profile.lowSpec);
  } catch { /* ignore */ }
  try {
    enableProductionMode();
  } catch { /* ignore */ }
  try {
    window.Engine?.shell?.setPreferNativeProjectorMode?.(true);
  } catch { /* ignore */ }
  try {
    const { ResourceGovernor } = await import('../runtime/resource-governor.js');
    ResourceGovernor.forceProfile(profile.lowSpec
      ? (window.__SOMOSUM_LIVE_ACTIVE ? 'live-eco' : 'eco')
      : 'performance');
  } catch { /* ignore */ }
  try { await flushPrefsToDisk(); } catch { /* ignore */ }
  return { prefs: getPrefs(), profile };
}
