import {
  getPrefs, savePrefs, importBackup, getAllAssets, getProgram,
  saveAsset, deleteAsset, fileToDataUrl, assetDiskPath,
  DEFAULT_CHURCH_WELCOME_BG, DEFAULT_CHURCH_LOGO,
} from '../../../../core/store.js';
import {
  ensureControlNetworkHub,
  refreshControlNetworkHub,
} from '../control-network.js';
import { applyTheme, THEMES, resolvePrefsAtmosphereId } from '../../../../core/themes.js';
import { createDefaultProgram, createProgramForCultoType } from '../../../../program/programa-templates.js';
import { MessageTypes } from '../../../../core/bus.js';
import { esc } from '../../../utils/escape.js';
import {
  applyRenderMode,
  describeRenderPrefs,
} from '../../../../core/performance/render-prefs.js';
import {
  openLogoCropDialog,
  bindChurchIdentityPickers,
} from '../../../../ui/church-identity-editor.js';
import { url as assetUrl } from '../../../../core/asset-registry.js';

export function bindSettingsHandlersPart2(app, main) {
  ensureControlNetworkHub((m, k) => app.toast(m, k));
  void refreshControlNetworkHub(main, (m, k) => app.toast(m, k));

  main.querySelector('#set-open-docs')?.addEventListener('click', () => {
    try {
      if (window.Engine?.shell?.openDocsPanel) {
        window.Engine.shell.openDocsPanel('');
        return;
      }
    } catch { /* fallback */ }
    window.open('/docs/index.html', '_blank', 'noopener');
  });

  main.querySelector('#set-start-tour')?.addEventListener('click', async () => {
    const { startTour } = await import('../../../../ui/onboarding-tour.js');
    startTour(app);
  });

  main.querySelector('#set-reset-tour')?.addEventListener('click', async () => {
    const { resetTour, startTour } = await import('../../../../ui/onboarding-tour.js');
    resetTour();
    app.toast('Tour reiniciado');
    startTour(app);
  });

  main.querySelector('#set-restart-server')?.addEventListener('click', async () => {
    if (!confirm('Reiniciar o servidor local? As abas reconectam automaticamente.')) return;
    app.toast('Reiniciando servidor…', 'warn');
    const { requestSoftRestart } = await import('../../../../core/server-restart.js');
    const ok = await requestSoftRestart();
    app.toast(ok ? 'Servidor online' : 'Timeout — tente pela bandeja', ok ? 'success' : 'error');
  });

  void (async () => {
    const hint = main.querySelector('#set-factory-profile-hint');
    if (!hint) return;
    try {
      const { describeInstallProfile } = await import('../../../../core/factory-restore.js');
      const p = describeInstallProfile();
      hint.textContent = `Perfil detectado: ${p.label}${p.detail ? ` (${p.detail})` : ''}. Projeção automática, resolução nativa e sincronização Controle ↔ Púlpito ↔ Remote.`;
    } catch { /* ignore */ }
  })();

  main.querySelector('#set-restore-factory')?.addEventListener('click', async () => {
    if (!confirm('Restaurar o padrão de fábrica deste PC?\n\nQualidade, projeção e sincronização voltam ao recomendado para este computador.\nIgreja, músicas, cultos e Modo LAN permanecem.')) return;
    const btn = main.querySelector('#set-restore-factory');
    if (btn) btn.disabled = true;
    try {
      const { restoreFactoryPrefs } = await import('../../../../core/factory-restore.js');
      const { profile } = await restoreFactoryPrefs();
      app.prefs = getPrefs();
      try {
        app.syncProjectionPrefs?.({ church: app.prefs.church, prefs: app.prefs });
        app.pushFullState?.({ force: true, skipPreview: false });
      } catch { /* ignore */ }
      window.dispatchEvent(new CustomEvent('somosum-prefs-changed', { detail: { factoryRestore: true, profile } }));
      app.toast(`Padrão deste PC aplicado (${profile.label}). Projeção e Púlpito/Remote alinhados.`, 'success');
      if (app.view === 'settings') app.renderSettingsView?.(main);
    } catch (e) {
      app.toast(String(e?.message || e || 'Não foi possível restaurar'), 'error');
    } finally {
      if (btn) btn.disabled = false;
    }
  });

  main.querySelector('#set-check-updates')?.addEventListener('click', async () => {
    const st = main.querySelector('#set-update-status');
    if (st) st.textContent = 'Procurando…';
    try {
      const { checkAppUpdateManual } = await import('../../../../ui/app-update-dialog.js');
      const r = await checkAppUpdateManual();
      if (st) st.textContent = r.message || 'Pronto.';
      if (r.message) app.toast(r.message, r.ok ? 'info' : 'warn');
    } catch (e) {
      if (st) st.textContent = 'Não deu para procurar agora. Confira a internet.';
      app.toast(String(e?.message || e), 'error');
    }
  });

  main.querySelector('#set-open-diagnostics')?.addEventListener('click', () => {
    if (window.Engine?.shell?.openDiagnosticsPanel) {
      window.Engine.shell.openDiagnosticsPanel();
      return;
    }
    window.open('/launcher/diagnostics.html', 'somosum-diagnostics', 'width=960,height=780');
  });

  main.querySelector('#set-run-diagnostics')?.addEventListener('click', async () => {
    const el = main.querySelector('#set-diag-summary');
    if (el) el.textContent = 'Analisando…';
    try {
      const { runServerDiagnostics } = await import('../../../../core/system-diagnostics.js');
      const result = await runServerDiagnostics({
        includeClient: true,
        screenConnected: app.screenConnected,
      });
      const s = result.summary;
      const status = s.fail ? 'Problemas encontrados' : (s.warn ? 'Atenção' : 'Sistema OK');
      if (el) {
        el.textContent = `${status} — ${s.ok} OK, ${s.warn} avisos, ${s.fail} falhas`;
        el.classList.toggle('is-warn', s.fail > 0 || s.warn > 0);
      }
      if (s.fail > 0) {
        const first = result.checks.find((c) => c.status === 'fail');
        if (first) app.toast(`${first.title}: ${first.solution || first.detail}`, 'warn');
      } else {
        app.toast('Diagnóstico OK — sistema pronto', 'success');
      }
    } catch {
      if (el) el.textContent = 'Falha ao analisar — abra o diagnóstico completo';
      app.toast('Erro no diagnóstico', 'error');
    }
  });

  main.querySelector('#set-clock')?.addEventListener('change', (e) => {
    app.syncProjectionPrefs({ showClock: e.target.checked });
    app.toast(e.target.checked ? 'Relógio ativado na projeção' : 'Relógio desativado');
  });

  main.querySelector('#set-foot')?.addEventListener('change', (e) => {
    app.syncProjectionPrefs({ showFooterVerse: e.target.checked });
  });

  main.querySelectorAll('.theme-card').forEach((card) => {
    card.addEventListener('click', () => {
      const id = card.dataset.theme;
      app.prefs.projectionTheme = id;
      app.prefs.theme = id;
      applyTheme(id);
      app.prefs = savePrefs(app.prefs);
      main.querySelectorAll('.theme-card').forEach((c) => c.classList.toggle('is-active', c === card));
      card.classList.add('is-previewing');
      setTimeout(() => card.classList.remove('is-previewing'), 600);
      app.bus.send(MessageTypes.SETTINGS, app.prefs);
      app.pushFullState?.();
      app.refreshStage?.({ skipOutbound: true });
      app._setSettingsSyncChip('ok');
      app.toast(`Tema da projeção: ${THEMES[id]?.name || id}`, 'success');
    });
  });

  main.querySelector('#set-high-contrast')?.addEventListener('change', (e) => {
    const ui = { ...(app.prefs.ui || {}), highContrast: e.target.checked };
    app.syncProjectionPrefs({ highContrast: e.target.checked, ui });
    document.documentElement.classList.toggle('high-contrast-mode', e.target.checked);
    import('../../../../ui/apply-ui-prefs.js').then(({ applyUiPrefs }) => applyUiPrefs({ ...app.prefs, highContrast: e.target.checked, ui }));
  });
  const applyChrome = (mode) => {
    const ui = { ...(app.prefs.ui || {}), chromeTheme: mode };
    app.syncProjectionPrefs({ ui });
    import('../../../../ui/apply-ui-prefs.js').then(({ applyUiPrefs }) => applyUiPrefs({ ...app.prefs, ui }));
    main.querySelector('#set-chrome-dark')?.classList.toggle('is-active', mode === 'dark');
    main.querySelector('#set-chrome-light')?.classList.toggle('is-active', mode === 'light');
    app.toast(mode === 'dark' ? 'Tema escuro aplicado em todo o sistema' : 'Tema claro aplicado em todo o sistema', 'success');
  };
  main.querySelector('#set-chrome-dark')?.addEventListener('click', () => applyChrome('dark'));
  main.querySelector('#set-chrome-light')?.addEventListener('click', () => applyChrome('light'));
  if (app.prefs.highContrast || app.prefs.ui?.highContrast) document.documentElement.classList.add('high-contrast-mode');

  const applyScale = () => {
    const scale = Number(main.querySelector('#set-ui-scale')?.value) || 1;
    const fontScale = Number(main.querySelector('#set-font-scale')?.value) || 1;
    const ui = { ...(app.prefs.ui || {}), scale, fontScale };
    app.syncProjectionPrefs({ ui });
    import('../../../../ui/apply-ui-prefs.js').then(({ applyUiPrefs }) => applyUiPrefs({ ...app.prefs, ui }));
    app.toast('Escala da interface atualizada', 'success');
  };
  main.querySelector('#set-ui-scale')?.addEventListener('change', applyScale);
  main.querySelector('#set-font-scale')?.addEventListener('change', applyScale);

  const syncLyricsFx = (patch) => {
    const lyricsFx = { ...app.prefs.lyricsFx, ...patch };
    app.syncProjectionPrefs({ lyricsFx });
  };
  main.querySelector('#set-lyrics-ambient')?.addEventListener('change', (e) => {
    syncLyricsFx({ ambient: e.target.value });
    app.toast('Efeito de louvor atualizado — veja no projetor');
  });
  main.querySelector('#set-lyrics-stagger')?.addEventListener('change', (e) => {
    syncLyricsFx({ lineEntrance: e.target.checked ? 'stagger' : 'none' });
  });
  main.querySelector('#set-lyrics-pulse')?.addEventListener('change', (e) => {
    syncLyricsFx({ highlightPulse: e.target.checked });
  });
  main.querySelector('#set-lyrics-strip-snippets')?.addEventListener('change', (e) => {
    app.syncProjectionPrefs({
      slideStripLyricsMode: e.target.checked ? 'snippets' : 'numbers',
    });
    if (app.view === 'program') app.renderSlideStrip?.(app.program.getCurrentMeta());
    if (app.view === 'live') {
      app.renderLiveSequenceHeader?.();
      app.renderLiveSequenceBlocks?.();
      app.renderSlideStrip?.(app.program.getCurrentMeta());
    }
  });

  void (async () => {
    const { geniusStatus, configureGeniusToken, removeGeniusToken } = await import('../../../../worship/lyrics-engine/lyrics-fetcher.js');
    const statusEl = main.querySelector('#set-genius-status');
    const refreshGeniusStatus = async () => {
      const st = await geniusStatus();
      if (statusEl) {
        statusEl.textContent = st.configured
          ? 'Genius configurado — busca estruturada ativa.'
          : 'Genius não configurado — providers PT-BR e descoberta web continuam disponíveis.';
      }
    };
    await refreshGeniusStatus();
    main.querySelector('#set-genius-save')?.addEventListener('click', async () => {
      const token = main.querySelector('#set-genius-token')?.value?.trim();
      if (!token) {
        app.toast('Informe o token de acesso.', 'warn');
        return;
      }
      await configureGeniusToken(token);
      main.querySelector('#set-genius-token').value = '';
      await refreshGeniusStatus();
      app.toast('Token Genius salvo com segurança no servidor.', 'success');
    });
    main.querySelector('#set-genius-remove')?.addEventListener('click', async () => {
      await removeGeniusToken();
      await refreshGeniusStatus();
      app.toast('Token Genius removido.', 'success');
    });
    main.querySelector('#set-genius-test')?.addEventListener('click', async () => {
      const st = await geniusStatus();
      if (!st.configured) {
        app.toast('Genius não configurado.', 'warn');
        return;
      }
      try {
        const { geniusSearch } = await import('../../../../worship/lyrics-engine/lyrics-fetcher.js');
        const data = await geniusSearch('Amazing Grace', { signal: AbortSignal.timeout(10000) });
        if (data?.response?.hits?.length) {
          app.toast('Genius OK — busca funcionando.', 'success');
          if (statusEl) statusEl.textContent = 'Genius configurado e validado — busca estruturada ativa.';
        } else {
          app.toast('Genius respondeu, mas sem resultados de teste.', 'warn');
        }
      } catch (err) {
        const invalid = err?.message === 'genius_auth_invalid';
        if (invalid) {
          await removeGeniusToken();
          await refreshGeniusStatus();
          app.toast('Token Genius inválido ou expirado — removido. Cole um novo token.', 'warn');
          if (statusEl) {
            statusEl.textContent = 'Token inválido — gere um novo em genius.com/api-clients e salve aqui.';
          }
        } else {
          app.toast(`Falha ao testar Genius: ${err?.message || err}`, 'error');
        }
      }
    });
  })();

  bindChurchIdentityPickers(main, {
    idPrefix: 'set',
    onLogoFile: async (file, setStatus) => {
      const cropped = await openLogoCropDialog(file);
      if (!cropped) {
        setStatus('logo', 'Recorte cancelado.', false);
        return;
      }
      setStatus('logo', 'Salvando logo…');
      await saveAsset('logo', cropped, 'image/png');
      app.assets.logo = cropped;
      app.prefs = savePrefs({
        ...app.prefs,
        church: {
          ...(app.prefs.church || {}),
          logoPath: assetDiskPath('logo', 'image/png'),
        },
      });
      app.syncAssets();
      app.syncProjectionPrefs?.({ church: app.prefs.church });
      app.toast('Logo da igreja atualizada na projeção', 'success');
      if (app.view === 'settings') app.renderSettingsView?.(main);
    },
    onBgFile: async (file, setStatus) => {
      const mime = file.type || 'image/png';
      const kind = mime.includes('video') ? 'video' : 'image';
      const dataUrl = await fileToDataUrl(file);
      await saveAsset('welcomeBg', dataUrl, mime);
      app.assets.welcomeBg = dataUrl;
      app.prefs = savePrefs({
        ...app.prefs,
        church: {
          ...(app.prefs.church || {}),
          welcomeBgPath: assetDiskPath('welcomeBg', mime),
          welcomeBgKind: kind,
        },
      });
      app.syncAssets();
      app.syncProjectionPrefs?.({ church: app.prefs.church });
      app.toast(kind === 'video' ? 'Vídeo de fundo atualizado na projeção' : 'Foto de fundo atualizada na projeção', 'success');
      if (app.view === 'settings') app.renderSettingsView?.(main);
    },
    onLogoReset: async () => {
      await deleteAsset('logo');
      app.assets.logo = null;
      app.prefs = savePrefs({
        ...app.prefs,
        church: {
          ...(app.prefs.church || {}),
          logoPath: DEFAULT_CHURCH_LOGO,
        },
      });
      app.syncAssets();
      app.syncProjectionPrefs?.({ church: app.prefs.church });
      app.toast('Logo restaurada ao padrão do sistema');
      if (app.view === 'settings') app.renderSettingsView?.(main);
    },
    onBgReset: async () => {
      await deleteAsset('welcomeBg');
      app.assets.welcomeBg = null;
      app.prefs = savePrefs({
        ...app.prefs,
        church: {
          ...(app.prefs.church || {}),
          welcomeBgPath: DEFAULT_CHURCH_WELCOME_BG,
          welcomeBgKind: 'image',
        },
      });
      app.syncAssets();
      app.syncProjectionPrefs?.({ church: app.prefs.church });
      app.toast('Fundo restaurado ao padrão do sistema');
      if (app.view === 'settings') app.renderSettingsView?.(main);
    },
  });

  main.querySelector('#set-production-mode')?.addEventListener('change', async (e) => {
    if (e.target.checked && !confirm('Ativar Modo Produção? Backup automático e cache reduzido durante o culto.')) {
      e.target.checked = false;
      return;
    }
    const { enableProductionMode, disableProductionMode } = await import('../../../../core/production-mode.js');
    if (e.target.checked) {
      enableProductionMode();
      app.toast('Modo Produção ativado', 'success');
    } else {
      disableProductionMode();
      app.toast('Modo Produção desativado');
    }
    app.prefs = getPrefs();
  });

  main.querySelector('#set-low-spec')?.addEventListener('change', async (e) => {
    const on = !!e.target.checked;
    const ui = {
      ...(app.prefs.ui || {}),
      lowSpec: on,
      reducedMotion: on || !!app.prefs.ui?.reducedMotion,
    };
    // Low-Spec: também corta transição padrão na preferência (animações pesadas)
    let nextPrefs = {
      ...app.prefs,
      lowSpec: on,
      ui,
      ...(on ? { transition: 'none' } : {}),
    };
    // Re-resolve projeção fluida (auto → economia)
    nextPrefs = applyRenderMode(nextPrefs, nextPrefs.render?.mode || 'auto');
    app.prefs = nextPrefs;
    window.__SOMOSUM_LOW_SPEC = on;
    document.documentElement.classList.toggle('somosum-low-spec', on);
    document.documentElement.classList.toggle('su-reduce-motion', on || !!ui.reducedMotion);
    await savePrefs({
      lowSpec: on,
      ui,
      ...(on ? { transition: 'none' } : {}),
      render: nextPrefs.render,
    });
    try {
      const { ResourceGovernor } = await import('../../../../runtime/resource-governor.js');
      ResourceGovernor.forceProfile(on
        ? (window.__SOMOSUM_LIVE_ACTIVE ? 'live-eco' : 'eco')
        : 'performance');
    } catch { /* ignore */ }
    // Propaga prefs à Projeção (slide-engine aplica eco / FX)
    try {
      app.pushFullState?.({ force: true, skipPreview: true });
    } catch { /* ignore */ }
    app.toast(on
      ? 'Modo Low-Spec ativado — animações e caches reduzidos'
      : 'Modo Low-Spec desativado', on ? 'success' : 'info');
    const status = main.querySelector('#set-render-status');
    if (status) {
      const d = describeRenderPrefs(app.prefs);
      status.textContent = `${d.statusLabel} — ${d.reason}`;
    }
  });

  const applyRenderFromUi = async () => {
    const picked = main.querySelector('input[name="set-render-mode"]:checked')?.value || 'auto';
    const next = applyRenderMode(app.prefs, picked);
    app.prefs = savePrefs({ render: next.render });
    try {
      window.__SOMOSUM_RENDER = next.render;
      document.documentElement.dataset.renderEngine = next.render.engine;
      document.documentElement.dataset.renderMode = next.render.mode;
    } catch { /* ignore */ }
    try {
      app.pushFullState?.({ force: true, skipPreview: true });
    } catch { /* ignore */ }
    const status = main.querySelector('#set-render-status');
    if (status) {
      const d = describeRenderPrefs(app.prefs);
      status.textContent = `${d.statusLabel} — ${d.reason}`;
    }
    app.toast(`Projeção: ${describeRenderPrefs(app.prefs).statusLabel}`, 'success');
  };
  main.querySelector('#set-render-apply')?.addEventListener('click', () => { void applyRenderFromUi(); });
  main.querySelectorAll('input[name="set-render-mode"]').forEach((el) => {
    el.addEventListener('change', () => { void applyRenderFromUi(); });
  });

  main.querySelector('#set-save').onclick = () => {
    app.saveChurchAndCore(main, { toast: true });
    app.pushFullState?.();
  };

  main.querySelector('#set-export').onclick = async () => {
    const { exportBackupWithChecksum } = await import('../../../../core/store.js');
    const data = await exportBackupWithChecksum();
    const a = document.createElement('a');
    const blob = URL.createObjectURL(new Blob([JSON.stringify(data, null, 2)]));
    a.href = blob;
    a.download = `somosum-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(blob);
    app.toast('Backup exportado', 'success');
  };
  main.querySelector('#set-ccli-csv')?.addEventListener('click', async () => {
    try {
      const { exportCsv } = await import('../../../../worship/ccli-usage.js');
      const csv = await exportCsv();
      const a = document.createElement('a');
      const blob = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' }));
      a.href = blob;
      a.download = `ccli-uso-${new Date().toISOString().slice(0, 10)}.csv`;
      a.click();
      URL.revokeObjectURL(blob);
      app.toast('CSV CCLI exportado', 'success');
    } catch {
      app.toast('Falha ao exportar CSV CCLI', 'warn');
    }
  });
  main.querySelector('#set-ccli-pdf')?.addEventListener('click', async () => {
    try {
      const { exportPdfHtml } = await import('../../../../worship/ccli-usage.js');
      const html = await exportPdfHtml();
      const w = window.open('', '_blank');
      if (!w) {
        app.toast('Permita pop-ups para imprimir o PDF', 'warn');
        return;
      }
      w.document.open();
      w.document.write(html);
      w.document.close();
    } catch {
      app.toast('Falha ao gerar relatório CCLI', 'warn');
    }
  });
  main.querySelector('#set-backup-incremental')?.addEventListener('click', async () => {
    const { BackupManager } = await import('../../../../core/backup/backup-manager.js');
    const result = await BackupManager.runIncremental();
    app.toast(result ? 'Backup incremental criado' : 'Falha no backup incremental', result ? 'success' : 'warn');
  });
  main.querySelector('#set-import').onchange = async (e) => {
    const f = e.target.files[0]; if (!f) return;
    try {
      await importBackup(JSON.parse(await f.text()));
      app.prefs = getPrefs();
      app.assets = await getAllAssets();
      applyTheme(resolvePrefsAtmosphereId(app.prefs));
      app.program.setPrefs(app.prefs);
      app.program.setItems((await getProgram()) || createDefaultProgram());
      await app.program.rebuild();
      app.render();
      app.pushFullState?.();
      app.toast('Backup restaurado', 'success');
    } catch (err) { alert(err.message); }
  };
  main.querySelector('#set-reset').onclick = async () => {
    const cultoType = app.cultoIndex?.cultos?.find((c) => c.id === app.cultoIndex?.activeId)?.type
      || 'domingo';
    const label = cultoType === 'quarta'
      ? 'Culto de Oração (quarta)'
      : cultoType === 'especial'
        ? 'Culto Especial'
        : 'Culto de Celebração (domingo)';
    if (!confirm(`Restaurar a ordem padrão — ${label}? Letras e mídias não serão apagadas.`)) return;
    app.program.setItems(createProgramForCultoType(cultoType), { resetNav: true });
    await app.program.rebuild();
    app.program.goToItem(0);
    app.markProgramDirty();
    app.refreshProgramUI();
    app.toast('Programa restaurado — use Salvar no Programa para gravar');
  };
}
