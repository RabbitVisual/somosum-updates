# SOMOSUM v8.8.13 — Projeção para igrejas

Sistema local de projeção para cultos — **100% offline**.

**Autor: [Reinan Rodrigues](mailto:r.rodriguesjs@gmail.com)** · (75) 99203-4656

**Versão:** [`VERSION`](VERSION) (sincronizada com o launcher, installer e docs).

---

## Início rápido

| Passo | Ação |
|-------|------|
| 1 | Duplo clique em **`SOMOSUM.exe`** na raiz (ou atalho do instalador) |
| 2 | Abre o **Painel Gerencial** (hub do culto neste PC) + ícone na bandeja |
| 3 | Painel → **Telas** (ou bandeja): Controle / Projeção / Stage / Remote |
| 4 | Projeção no projetor — **F11** · Tema claro/escuro — Painel ou Ajustes → Sistema |
| 5 | Tour no Controle — tecla **?** · Manual — tecla **D** · Novidades — Painel → **Sobre** |

Com o app em execução: **http://127.0.0.1:PORTA/docs/**

---

## Documentação

| Público | Onde |
|---------|------|
| Operador | Portal `/docs/` (`docs/index.html`) |
| **Programadores (técnico completo)** | [`docs/DOCUMENTACAO-TECNICA-PROGRAMADORES.md`](docs/DOCUMENTACAO-TECNICA-PROGRAMADORES.md) |
| Plugins (API 2 / Studio) | [`docs/guides/plugins.md`](docs/guides/plugins.md) · [`docs/architecture/Projetor.md`](docs/architecture/Projetor.md) (monitores) |
| Desenvolvimento | Pasta [`docs/`](docs/) (guias, arquitetura, checklists) |
| Release 8.7.9 | [`docs/releases/RELEASE-NOTES-8.7.9.md`](docs/releases/RELEASE-NOTES-8.7.9.md) |
| Guia do operador | [`docs/guides/guia-operador.md`](docs/guides/guia-operador.md) |
| Funcionamento atual | [`docs/guides/funcionamento-atual.md`](docs/guides/funcionamento-atual.md) |
| Atualizações | [`docs/guides/atualizacao.md`](docs/guides/atualizacao.md) |
| Estrutura MVC | [`docs/architecture/estrutura-mvc.md`](docs/architecture/estrutura-mvc.md) |
| Segurança LAN | [`docs/enterprise/THREAT-MODEL.md`](docs/enterprise/THREAT-MODEL.md) |
| Instalador / confiança | [`installer/CONFIABILIDADE.md`](installer/CONFIABILIDADE.md) · [`LEIA-ME.txt`](LEIA-ME.txt) |
| Changelog | [`docs/changelog.md`](docs/changelog.md) |

---

## Build (produção vs local)

| Cenário | Comando | Saída |
|---------|---------|--------|
| **Local** — corrigir/melhorar no seu PC | `.\somosum.ps1 compile` | `app\SOMOSUM.exe` |
| **Produção** — instalar na igreja / release | `.\somosum.ps1 build` | `dist\SOMOSUM-Setup.exe`, ZIPs |

```powershell
# Dia a dia (servidor local / dev):
.\somosum.ps1 compile

# Release completo (Setup Inno + gates):
.\somosum.ps1 build
```

Aliases: `dev`/`exe` → compile · `release`/`setup`/`prod` → build

Documentação: [`scripts/README.md`](scripts/README.md)

Saídas: `app\SOMOSUM.exe`, trampolim `SOMOSUM.exe` na raiz, instalador em `dist\SOMOSUM-Setup.exe`.
Pasta padrão do instalador: `%LOCALAPPDATA%\SOMOSUM`.

---

## Estrutura MVC do projeto

Layout explícito na raiz (URLs públicas estáveis via `ContentLayout`):

| Camada | Pasta | Conteúdo |
|--------|-------|----------|
| **Model** | [`model/`](model/) | `data/`, `storage/`, `content/` (seed) |
| **View** | [`view/`](view/) | `html/`, `css/`, `fonts/`, `IMG/`, `audio/`, `vendor/` |
| **Controller** | [`controller/`](controller/) | `js/`, `launcher/`, `runtime/` |

Na raiz permanecem: **`SOMOSUM.exe`** (trampolim), `app/`, `docs/`, `scripts/`, `VERSION`, meta (`README`, `LEIA-ME`).

Mapa completo: [`docs/architecture/arquitetura.md`](docs/architecture/arquitetura.md) §2.6.

**Validar layout MVC:** `powershell -File scripts\validate-mvc-layout.ps1`

---

| Papel | Pastas principais |
|-------|-------------------|
| Entrada | `SOMOSUM.exe` (trampolim), `app\SOMOSUM.exe` (runtime) |
| Model | `model/data/`, `model/storage/`, `model/content/` |
| View | `view/html/`, `view/css/`, `view/IMG/`, … |
| Controller | `controller/js/`, `controller/launcher/`, `controller/runtime/` |
| Docs / build | `docs/`, `scripts/`, `installer/`, `dist/` |

---

## Licença / uso

Uso gratuito para igrejas. Ver [LICENSE](LICENSE).

| Distribuição | Canal |
|--------------|--------|
| **Setup.exe** | Google Drive (instalação nova) |
| **Código-fonte** | Repositório privado GitHub `RabbitVisual/SOMOSUM` |
| **Atualizações delta** | [somosum-updates](https://github.com/RabbitVisual/somosum-updates) (público, sem código) |
| **Packs (plugins/hinários/mídia)** | [somosum-catalog](https://github.com/RabbitVisual/somosum-catalog) |

Publicar atualização: `.\scripts\publish-app-update.ps1` — guia em [`docs/guides/atualizacao.md`](docs/guides/atualizacao.md).

Propriedade, distribuição e manutenção: **Reinan Rodrigues**.
