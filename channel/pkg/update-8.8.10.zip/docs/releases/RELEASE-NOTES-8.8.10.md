# Release Notes — SOMOSUM 8.8.10

**Data:** 2026-08-19  
**Tipo:** identificação nativa HDMI/VGA + resolução EDID

## Destaques

### Projetor — cabo e resolução verdadeira
- O Windows informa o **tipo de cabo** (HDMI, VGA, DVI, DisplayPort) e o **modo nativo do EDID** — não o maior modo que a placa de vídeo inventa (ex.: 1080p num SVGA).
- Ao abrir a Projeção, o SOMOSUM escolhe a tela HDMI/VGA secundária e aplica a **resolução nativa** com Hz estável (60/59/50), para a imagem ficar nítida no projetor.
- A lista de monitores mostra cabo e resolução nativa (ex.: HDMI · nativo 1024×768).

### Continua da 8.8.9
- Tela cheia sem faixa preta; vídeo/fundo preenchendo o quadro; ordem do culto (inspetor, PPTX, mensagem).

## Como atualizar
1. Em **8.8.9**: Ajuda → Verificar atualização → **8.8.10** → confirme o reinício.
2. Se estiver atrás: suba de 1 em 1 até **8.8.10**.
3. Windows em **Estender estas telas** (não Espelhar). Ligue o projetor, abra **Projeção**.

## Verificação rápida
- [ ] Sobre = **8.8.10**
- [ ] Lista de monitores: HDMI ou VGA no projetor
- [ ] Imagem nítida na resolução do aparelho (sem “esticar” 1080 num projetor 800×600)
