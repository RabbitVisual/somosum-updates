# Atualizações do sistema SOMOSUM

## Visão geral

| Componente | Onde |
|------------|------|
| Código-fonte | Repositório **privado** `RabbitVisual/SOMOSUM` |
| Setup completo | **Google Drive** (instalação nova) |
| Atualizações delta | Repositório **público** [somosum-updates](https://github.com/RabbitVisual/somosum-updates) |

As igrejas **não** baixam o código-fonte. Recebem um **pacote delta** (ZIP) com apenas os arquivos liberados na correção.

## No app (operador) — fluxo atual (8.8.10)

1. **Painel → Sobre → Procurar novidades** (ou Controle → Ajustes → Sistema), com internet.
2. Se houver versão mais nova: escolher **Atualizar agora**, **Depois** ou **Ignorar esta versão**.
3. O canal aplica **uma versão de cada vez** (na ordem). Se você estiver atrás, o app oferece o próximo passo e, após reiniciar, peça de novo até chegar na mais recente.
4. O download é leve (só o que mudou). Cultos, músicas e configurações permanecem no PC.
5. Ao terminar o download: tela **Atualização concluída** — confirme se deseja **reiniciar agora**.
6. Ao confirmar: o SOMOSUM prepara o apply, limpa arquivos temporários, fecha e **reabre sozinho** (alguns segundos).
7. Na reabertura: tela de **boas-vindas** com a versão e o que mudou; em seguida Painel → **Sobre** mostra os mesmos destaques ao vivo.

Também disponível no Controle: **Ajustes → Sistema → Procurar novidades**.

1. **Painel → Sobre → Procurar novidades** (ou Controle → Ajustes → Sistema), com internet.
2. Se houver versão mais nova: escolher **Atualizar agora**, **Depois** ou **Ignorar esta versão**.
3. O canal aplica **uma versão de cada vez** (na ordem). Se você estiver atrás, o app oferece o próximo passo e, após reiniciar, peça de novo até chegar na mais recente.
4. O download é leve (só o que mudou). Cultos, músicas e configurações permanecem no PC.
5. Ao terminar o download: tela **Atualização concluída** — confirme se deseja **reiniciar agora**.
6. Ao confirmar: o SOMOSUM prepara o apply, limpa arquivos temporários, fecha e **reabre sozinho** (alguns segundos).
7. Na reabertura: tela de **boas-vindas** com a versão e o que mudou; em seguida Painel → **Sobre** mostra os mesmos destaques ao vivo.

Também disponível no Controle: **Ajustes → Sistema → Procurar novidades**.

## Publicar uma correção (desenvolvedor)

```powershell
# 1. Bump de versão
node scripts/bump-version.js X.Y.Z

# 2. Gerar pacote delta + latest.json + history.json
#    --from = versão imediatamente anterior no canal (obrigatório)
node scripts/build-app-update.mjs --notes docs/releases/RELEASE-NOTES-X.Y.Z.md --from X.Y.(Z-1)

# 3. Publicar no GitHub (channel + Release)
.\scripts\publish-app-update.ps1
```

**Regra:** na escada (`history.json`), cada passo tem `minVersion` = versão anterior. O cliente 8.8.1+ sobe de 1 em 1.

**Compatibilidade 8.7 / 8.0+:** o `latest.json` pode declarar `minVersion` 8.0.0 para destravar clientes antigos (sem history). Quem já tem history continua aplicando só o próximo passo da escada (8.7.9 → … → ponta).
### Arquivos incluídos no delta

Allowlist (nunca `model/data` da igreja):

- `controller/`, `view/`, `model/content/`, `app/`, `docs/`
- `VERSION`, `build-manifest.json`

Use `--list update-files.txt` para lista explícita ou `--full` para rebuild amplo.

## Formato do pacote

```
update-X.Y.Z.zip
  update-manifest.json   # from, to, replace[], delete[]
  notes/X.Y.Z.md
  controller/js/...
  view/css/...
  VERSION
```

## Segurança

- sha256 obrigatório no `latest.json`
- Allowlist no servidor (`AppUpdateAllowlist.cs`)
- Aplicação na reinicialização via trampolim `SOMOSUM.exe` (`AppUpdateApplyStandalone`)
- Reinício agendado (cmd com atraso) para liberar locks de arquivo

## Tamanho do pacote (obrigatório)

O download passa por `/api/catalog/proxy` (**máx. ~120 MB**) e o stage por POST (**máx. ~48 MB**).  
Delta saudável: **&lt; ~40 MB** (ideal 5–25 MB).

**Não incluir** no ZIP: `view/audio/`, `view/vendor/` grande, `model/content/packs/`, `app/runtimes/`, `app/tools/`.  
Áudio e packs ficam no **instalador completo**; o canal delta só leva código/UI/docs + DLLs leves (`Somosum.Engine.dll`, EXE).

Se o build passar de ~100 MB → enxugar e republicar (`gh release upload … --clobber`). Pacote inchado gera **413 Payload Too Large** no cliente.

## Gate

```powershell
.\scripts\tests\test-app-update.ps1
```
