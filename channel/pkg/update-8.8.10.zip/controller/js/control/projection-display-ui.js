/** UI de monitores na topbar + botão Projeção. */
export function wireProjectionDisplayUi(app) {
  Object.assign(app, {
    updateProjectionButtonLabel() {
      const btn = document.getElementById('btn-open-screen');
      const topSel = document.getElementById('topbar-projector-display');
      const wrap = document.getElementById('topbar-monitor-wrap');
      const shell = window.Engine?.shell;
      const hasNative = !!shell?.isAvailable?.();

      let list = [];
      try {
        list = shell?.getDisplays?.() || [];
      } catch { list = []; }

      const roleLabel = (d, i, projectorIdx, recommendedIdx) => {
        if (d.role === 'operator' || (d.primary && d.role !== 'projection')) {
          return ' · Seu monitor (Controle)';
        }
        if (d.role === 'projection2') return ' · Projetor 2';
        if (d.role === 'stage') return ' · Retorno (Stage)';
        if (d.role === 'projection' || i === projectorIdx) {
          return i === recommendedIdx || d.isProjector
            ? ' · Projetor (recomendado)'
            : ' · Projetor (congregação)';
        }
        if (d.isProjector || i === recommendedIdx) return ' · Projetor (sugerido)';
        return ' · auxiliar';
      };

      const formatOption = (d, i, projectorIdx, recommendedIdx) => {
        const w = d.currentMode?.w || d.width || d.bounds?.w || '?';
        const h = d.currentMode?.h || d.height || d.bounds?.h || '?';
        const name = d.friendlyName ? ` · ${d.friendlyName}` : '';
        const role = roleLabel(d, i, projectorIdx, recommendedIdx);
        const dpi = d.dpiScale && d.dpiScale !== 1 ? ` · ${Math.round(d.dpiScale * 100)}%` : '';
        const mirror = d.isMirrored ? ' · espelho Windows' : '';
        const conn = d.connectionHint && d.connectionHint !== 'unknown' && d.connectionHint !== 'internal'
          ? ` · ${String(d.connectionHint).toUpperCase()}`
          : '';
        const native = d.recommendedMode?.w && d.recommendedMode?.h
          ? ` · nativo ${d.recommendedMode.w}×${d.recommendedMode.h}`
          : '';
        return `<option value="${i}">Tela ${i + 1}${name} (${w}×${h})${conn}${native}${role}${dpi}${mirror}</option>`;
      };

      if (topSel) {
        if (!list.length) {
          topSel.innerHTML = '<option value="0">Seu monitor (este PC)</option>';
          topSel.disabled = !hasNative;
          if (wrap) {
            wrap.title = hasNative
              ? 'Conecte HDMI / projetor e use Atualizar em Ajustes → Projeção'
              : 'Abra pelo SOMOSUM.exe para escolher monitores';
          }
        } else {
          const current = hasNative && typeof shell.getProjectorDisplayIndex === 'function'
            ? shell.getProjectorDisplayIndex()
            : 0;
          const recommended = list.findIndex((d) => !d.primary && d.isProjector);
          const fallbackRec = list.findIndex((d) => !d.primary);
          const recommendedIdx = recommended >= 0 ? recommended : fallbackRec;
          const projectorIdx = current >= 0 ? current : (recommendedIdx >= 0 ? recommendedIdx : 0);
          const mirrored = list.some((d) => d.isMirrored);
          topSel.innerHTML = list.map((d, i) => formatOption(d, i, projectorIdx, recommendedIdx)).join('');
          topSel.value = String(Math.min(Math.max(0, current), list.length - 1));
          topSel.disabled = !hasNative;
          if (wrap) {
            wrap.hidden = false;
            if (mirrored) {
              wrap.title = 'Windows em modo espelho — Stage/segundo projetor podem falhar. Use Estender estas telas.';
            } else {
              wrap.title = list.length > 1
                ? 'Projetor (congregação) — escolha o HDMI/VGA. Stage/Remote usam rede.'
                : 'Só um monitor — o botão Projeção abre janela de teste (não confundir com Janelas → Simular projeção)';
            }
          }
        }
      }

      if (!btn) return;
      if (!hasNative) {
        btn.textContent = 'Projeção';
        btn.title = 'Abre projeção em janela para testar sem projetor';
        return;
      }
      try {
        const idx = typeof shell.getProjectorDisplayIndex === 'function'
          ? shell.getProjectorDisplayIndex()
          : (list.length > 1 ? 1 : 0);
        const d = list[idx];
        const label = d
          ? (d.primary && d.role !== 'projection' ? 'Seu monitor' : `Projetor · Tela ${idx + 1}`)
          : `Tela ${idx + 1}`;
        // Sempre "Projeção" — não confundir com Janelas → Simular projeção (painel flutuante).
        btn.textContent = list.length > 1 ? `Projeção · ${idx + 1}` : 'Projeção';
        const mirrorWarn = list.some((x) => x.isMirrored) ? ' Aviso: modo espelho Windows.' : '';
        btn.title = list.length > 1
          ? `Abrir projeção em tela cheia — ${label}.${mirrorWarn}`
          : '1 monitor: abre janela de teste (não tela cheia). Painel pequeno: Janelas → Simular projeção';
      } catch {
        btn.textContent = 'Projeção';
        btn.title = 'Abrir projeção';
      }
    },
  });
}
