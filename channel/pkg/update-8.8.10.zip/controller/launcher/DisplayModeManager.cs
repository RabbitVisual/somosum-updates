using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;

namespace SomosumLauncher
{
    /// <summary>
    /// Aplica / restaura resolução nativa no device do projetor (ChangeDisplaySettingsEx).
    /// </summary>
    internal static class DisplayModeManager
    {
        private const int ENUM_CURRENT_SETTINGS = -1;
        private const int CDS_UPDATEREGISTRY = 0x00000001;
        private const int CDS_NORESET = 0x10000000;
        private const int DISP_CHANGE_SUCCESSFUL = 0;
        private const int DM_PELSWIDTH = 0x80000;
        private const int DM_PELSHEIGHT = 0x100000;
        private const int DM_DISPLAYFREQUENCY = 0x400000;
        private const int DM_BITSPERPEL = 0x40000;

        private static readonly Dictionary<string, ModeSnapshot> _saved =
            new Dictionary<string, ModeSnapshot>(StringComparer.OrdinalIgnoreCase);

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
        private struct DEVMODE
        {
            private const int CCHDEVICENAME = 32;
            private const int CCHFORMNAME = 32;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = CCHDEVICENAME)]
            public string dmDeviceName;
            public short dmSpecVersion;
            public short dmDriverVersion;
            public short dmSize;
            public short dmDriverExtra;
            public int dmFields;
            public int dmPositionX;
            public int dmPositionY;
            public int dmDisplayOrientation;
            public int dmDisplayFixedOutput;
            public short dmColor;
            public short dmDuplex;
            public short dmYResolution;
            public short dmTTCOption;
            public short dmCollate;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = CCHFORMNAME)]
            public string dmFormName;
            public short dmLogPixels;
            public int dmBitsPerPel;
            public int dmPelsWidth;
            public int dmPelsHeight;
            public int dmDisplayFlags;
            public int dmDisplayFrequency;
            public int dmICMMethod;
            public int dmICMIntent;
            public int dmMediaType;
            public int dmDitherType;
            public int dmReserved1;
            public int dmReserved2;
            public int dmPanningWidth;
            public int dmPanningHeight;
        }

        private struct ModeSnapshot
        {
            public int W;
            public int H;
            public int Hz;
            public int Bits;
        }

        [DllImport("user32.dll", CharSet = CharSet.Ansi)]
        private static extern bool EnumDisplaySettings(string lpszDeviceName, int iModeNum, ref DEVMODE lpDevMode);

        [DllImport("user32.dll", CharSet = CharSet.Ansi)]
        private static extern int ChangeDisplaySettingsEx(
            string lpszDeviceName, ref DEVMODE lpDevMode, IntPtr hwnd, int dwflags, IntPtr lParam);

        [DllImport("user32.dll", CharSet = CharSet.Ansi)]
        private static extern int ChangeDisplaySettingsEx(
            string lpszDeviceName, IntPtr lpDevMode, IntPtr hwnd, int dwflags, IntPtr lParam);

        public static bool ApplyMode(string deviceName, int width, int height, int hz)
        {
            if (string.IsNullOrEmpty(deviceName) || width <= 0 || height <= 0) return false;

            var current = new DEVMODE();
            current.dmSize = (short)Marshal.SizeOf(typeof(DEVMODE));
            if (!EnumDisplaySettings(deviceName, ENUM_CURRENT_SETTINGS, ref current)) return false;

            if (current.dmPelsWidth == width && current.dmPelsHeight == height
                && (hz <= 0 || current.dmDisplayFrequency == hz))
            {
                return true;
            }

            if (!_saved.ContainsKey(deviceName))
            {
                _saved[deviceName] = new ModeSnapshot
                {
                    W = current.dmPelsWidth,
                    H = current.dmPelsHeight,
                    Hz = current.dmDisplayFrequency,
                    Bits = current.dmBitsPerPel > 0 ? current.dmBitsPerPel : 32,
                };
            }

            // Melhor Hz nativo: preferir o pedido, depois 60/59/50 — não o máximo (instável em projetor)
            int bestHz = PickStableHz(deviceName, width, height, hz > 0 ? hz : current.dmDisplayFrequency);

            var dm = current;
            dm.dmSize = (short)Marshal.SizeOf(typeof(DEVMODE));
            dm.dmPelsWidth = width;
            dm.dmPelsHeight = height;
            dm.dmDisplayFrequency = bestHz > 0 ? bestHz : 60;
            if (dm.dmBitsPerPel <= 0) dm.dmBitsPerPel = 32;
            dm.dmFields = DM_PELSWIDTH | DM_PELSHEIGHT | DM_DISPLAYFREQUENCY | DM_BITSPERPEL;

            var result = ChangeDisplaySettingsEx(deviceName, ref dm, IntPtr.Zero, CDS_UPDATEREGISTRY, IntPtr.Zero);
            if (result != DISP_CHANGE_SUCCESSFUL)
            {
                // Tenta sem registrar (sessão atual)
                result = ChangeDisplaySettingsEx(deviceName, ref dm, IntPtr.Zero, 0, IntPtr.Zero);
            }
            if (result == DISP_CHANGE_SUCCESSFUL)
            {
                DisplayEnumerator.InvalidateCache();
                return true;
            }
            return false;
        }

        public static bool RestoreMode(string deviceName)
        {
            if (string.IsNullOrEmpty(deviceName)) return false;
            if (!_saved.TryGetValue(deviceName, out var snap)) return false;

            var dm = new DEVMODE();
            dm.dmSize = (short)Marshal.SizeOf(typeof(DEVMODE));
            if (!EnumDisplaySettings(deviceName, ENUM_CURRENT_SETTINGS, ref dm)) return false;

            dm.dmPelsWidth = snap.W;
            dm.dmPelsHeight = snap.H;
            dm.dmDisplayFrequency = snap.Hz > 0 ? snap.Hz : 60;
            dm.dmBitsPerPel = snap.Bits > 0 ? snap.Bits : 32;
            dm.dmFields = DM_PELSWIDTH | DM_PELSHEIGHT | DM_DISPLAYFREQUENCY | DM_BITSPERPEL;

            var result = ChangeDisplaySettingsEx(deviceName, ref dm, IntPtr.Zero, CDS_UPDATEREGISTRY, IntPtr.Zero);
            if (result != DISP_CHANGE_SUCCESSFUL)
                result = ChangeDisplaySettingsEx(deviceName, ref dm, IntPtr.Zero, 0, IntPtr.Zero);

            _saved.Remove(deviceName);
            if (result == DISP_CHANGE_SUCCESSFUL)
            {
                DisplayEnumerator.InvalidateCache();
                return true;
            }
            return false;
        }

        public static void RestoreAll()
        {
            var keys = new List<string>(_saved.Keys);
            foreach (var key in keys)
                RestoreMode(key);
        }

        private static int PickStableHz(string deviceName, int width, int height, int preferred)
        {
            var list = new List<int>();
            var probe = new DEVMODE();
            probe.dmSize = (short)Marshal.SizeOf(typeof(DEVMODE));
            var modeIdx = 0;
            while (EnumDisplaySettings(deviceName, modeIdx++, ref probe))
            {
                if (probe.dmPelsWidth == width && probe.dmPelsHeight == height && probe.dmDisplayFrequency > 0)
                    list.Add(probe.dmDisplayFrequency);
            }
            if (list.Count == 0) return preferred > 0 ? preferred : 60;
            if (preferred > 0 && list.Contains(preferred)) return preferred;
            foreach (var cand in new[] { 60, 59, 50, 75, 30 })
            {
                if (list.Contains(cand)) return cand;
            }
            list.Sort();
            var target = preferred > 0 ? preferred : 60;
            var best = list[0];
            var bestDelta = Math.Abs(best - target);
            foreach (var hz in list)
            {
                var d = Math.Abs(hz - target);
                if (d < bestDelta)
                {
                    best = hz;
                    bestDelta = d;
                }
            }
            return best;
        }
    }
}
