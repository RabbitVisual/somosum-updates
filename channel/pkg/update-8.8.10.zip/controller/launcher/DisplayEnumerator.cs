using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;

namespace SomosumLauncher
{
    internal static class DisplayEnumerator
    {
        private const int ENUM_CURRENT_SETTINGS = -1;
        private const int ENUM_REGISTRY_SETTINGS = -2;
        private static Dictionary<string, string> _adapterNames;
        private static string _cachedSnapshotJson;
        private static Dictionary<string, DisplayConfigProbe.TargetInfo> _ccdCache;
        private static long _ccdCacheAt;
        private static long _cachedSnapshotAt;
        private static int _cachedProjectorIndex = -1;
        private static int _cachedStageIndex = -1;
        private static int _cachedProjector2Index = -2;
        private const int DM_PELSWIDTH = 0x80000;
        private const int DM_PELSHEIGHT = 0x100000;
        private const int DM_DISPLAYFREQUENCY = 0x400000;
        private const int DM_BITSPERPEL = 0x40000;
        private const int DM_DISPLAYORIENTATION = 0x80;

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
        private struct DEVMODE
        {
            private const int CCHDEVICENAME = 32;
            private const int CCHFORMNAME = 32;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = CCHDEVICENAME)]
            public string dmDeviceName;
            public short dmSpecVersion;
            public short dmDriverVersion;
            public short dmSize;
            public short dmDriverExtra;
            public int dmFields;
            public int dmPositionX;
            public int dmPositionY;
            public int dmDisplayOrientation;
            public int dmDisplayFixedOutput;
            public short dmColor;
            public short dmDuplex;
            public short dmYResolution;
            public short dmTTCOption;
            public short dmCollate;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = CCHFORMNAME)]
            public string dmFormName;
            public short dmLogPixels;
            public int dmBitsPerPel;
            public int dmPelsWidth;
            public int dmPelsHeight;
            public int dmDisplayFlags;
            public int dmDisplayFrequency;
            public int dmICMMethod;
            public int dmICMIntent;
            public int dmMediaType;
            public int dmDitherType;
            public int dmReserved1;
            public int dmReserved2;
            public int dmPanningWidth;
            public int dmPanningHeight;
        }

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
        private struct DISPLAY_DEVICE
        {
            public int cb;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)]
            public string DeviceName;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)]
            public string DeviceString;
            public int StateFlags;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)]
            public string DeviceID;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)]
            public string DeviceKey;
        }

        private enum MonitorDpiType { Effective = 0, Angular = 1, Raw = 2 }

        [DllImport("user32.dll", CharSet = CharSet.Ansi)]
        private static extern bool EnumDisplaySettings(string lpszDeviceName, int iModeNum, ref DEVMODE lpDevMode);

        [DllImport("user32.dll", CharSet = CharSet.Ansi)]
        private static extern bool EnumDisplayDevices(string lpDevice, uint iDevNum, ref DISPLAY_DEVICE lpDisplayDevice, uint dwFlags);

        [DllImport("Shcore.dll")]
        private static extern int GetDpiForMonitor(IntPtr hmonitor, MonitorDpiType dpiType, out uint dpiX, out uint dpiY);

        [DllImport("user32.dll")]
        private static extern IntPtr MonitorFromPoint(POINT pt, uint dwFlags);

        [StructLayout(LayoutKind.Sequential)]
        private struct POINT
        {
            public int X;
            public int Y;
        }

        internal sealed class DisplayInfo
        {
            public int Index;
            public string DeviceName;
            public string FriendlyName;
            public string Manufacturer;
            public string Model;
            public string DeviceId;
            public string DisplayId;
            public bool Primary;
            public bool IsProjector;
            public bool IsMirrored;
            public Rectangle Bounds;
            public Rectangle WorkingArea;
            public double DpiScale;
            public int RefreshHz;
            public string Orientation;
            public int CurrentW;
            public int CurrentH;
            public int CurrentHz;
            public int RecommendedW;
            public int RecommendedH;
            public int RecommendedHz;
            public int MaxW;
            public int MaxH;
            public int MaxHz;
            public string AspectRatio;
            public string ConnectionHint;
            public bool? HdrCapable;
            public string ColorProfile;
            public string Role;
            public string DisplayHash;
        }

        public static DisplayInfo[] Enumerate(int projectorIndex, int stageIndex, int operatorIndex = 0, int projector2Index = -1)
        {
            var screens = DisplayHelper.GetAllDisplays();
            var list = new List<DisplayInfo>();
            for (int i = 0; i < screens.Length; i++)
            {
                var screen = screens[i];
                var info = BuildInfo(i, screen);
                if (i == projectorIndex) info.Role = "projection";
                else if (projector2Index >= 0 && i == projector2Index) info.Role = "projection2";
                else if (i == stageIndex) info.Role = "stage";
                else if (i == operatorIndex) info.Role = "operator";
                else info.Role = "unknown";
                list.Add(info);
            }
            var arr = list.ToArray();
            MarkMirroredDisplays(arr);
            return arr;
        }

        /// <summary>
        /// Modo espelho / clone: dois adapters com o mesmo retângulo virtual —
        /// Stage/segundo projetor ficam quebrados; UI deve avisar o operador.
        /// </summary>
        private static void MarkMirroredDisplays(DisplayInfo[] displays)
        {
            if (displays == null || displays.Length < 2) return;
            for (int i = 0; i < displays.Length; i++)
            {
                for (int j = i + 1; j < displays.Length; j++)
                {
                    if (displays[i].Bounds == displays[j].Bounds)
                    {
                        displays[i].IsMirrored = true;
                        displays[j].IsMirrored = true;
                    }
                }
            }
        }

        public static void InvalidateCache()
        {
            _cachedSnapshotJson = null;
            _cachedSnapshotAt = 0;
            _adapterNames = null;
            _ccdCache = null;
            _ccdCacheAt = 0;
        }

        private static Dictionary<string, DisplayConfigProbe.TargetInfo> CcdMap()
        {
            var now = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
            if (_ccdCache != null && now - _ccdCacheAt < 800)
                return _ccdCache;
            _ccdCache = DisplayConfigProbe.Probe();
            _ccdCacheAt = now;
            return _ccdCache;
        }

        public static string GetSnapshotJson(int projectorIndex, int stageIndex, int operatorIndex = 0, int projector2Index = -1)
        {
            var now = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
            if (_cachedSnapshotJson != null
                && now - _cachedSnapshotAt < 400
                && _cachedProjectorIndex == projectorIndex
                && _cachedStageIndex == stageIndex
                && _cachedProjector2Index == projector2Index)
            {
                return _cachedSnapshotJson;
            }

            var displays = Enumerate(projectorIndex, stageIndex, operatorIndex, projector2Index);
            var configVersion = ComputeConfigurationVersion(displays);
            var sb = new StringBuilder();
            sb.Append("{\"timestamp\":").Append(now);
            sb.Append(",\"capturedAt\":").Append(now);
            sb.Append(",\"configurationVersion\":\"").Append(EscapeJson(configVersion)).Append('"');
            sb.Append(",\"displays\":[");
            for (int i = 0; i < displays.Length; i++)
            {
                if (i > 0) sb.Append(',');
                sb.Append(SerializeDisplay(displays[i]));
            }
            sb.Append("]}");
            _cachedSnapshotJson = sb.ToString();
            _cachedSnapshotAt = now;
            _cachedProjectorIndex = projectorIndex;
            _cachedStageIndex = stageIndex;
            _cachedProjector2Index = projector2Index;
            return _cachedSnapshotJson;
        }

        public static string GetDisplaysDetailedJson(int projectorIndex, int stageIndex, int operatorIndex = 0, int projector2Index = -1)
        {
            return GetSnapshotJson(projectorIndex, stageIndex, operatorIndex, projector2Index);
        }

        private static DisplayInfo BuildInfo(int index, Screen screen)
        {
            var deviceName = screen.DeviceName ?? "";
            var friendly = GetFriendlyName(deviceName);
            var deviceId = GetDeviceId(deviceName);
            var identity = ParseIdentity(friendly, deviceId);
            var bounds = screen.Bounds;
            var working = screen.WorkingArea;
            var dpiScale = DpiHelper.GetDpiScaleForScreen(screen);
            var current = GetCurrentMode(deviceName);
            var ccd = (DisplayConfigProbe.TargetInfo)null;
            CcdMap().TryGetValue(deviceName, out ccd);
            var recommended = GetRecommendedMode(deviceName, ccd);
            var maxMode = GetNativeCapMode(deviceName, ccd, current, recommended);

            // DEVMODE = resolução real; bounds = tamanho lógico (DPI)
            var curW = current.W > 0 ? current.W : bounds.Width;
            var curH = current.H > 0 ? current.H : bounds.Height;
            var recW = recommended.W > 0 ? recommended.W : curW;
            var recH = recommended.H > 0 ? recommended.H : curH;
            var maxW = Math.Max(Math.Max(curW, recW), maxMode.W > 0 ? maxMode.W : 0);
            var maxH = Math.Max(Math.Max(curH, recH), maxMode.H > 0 ? maxMode.H : 0);
            if (maxW <= 0) maxW = bounds.Width;
            if (maxH <= 0) maxH = bounds.Height;

            var aspect = FormatAspect(recW, recH);
            var orientation = curW >= curH ? "landscape" : "portrait";
            if (current.Orientation == 1 || current.Orientation == 2) orientation = "portrait";
            if (current.Orientation == 2 || current.Orientation == 4) orientation = "landscape";

            var hash = ComputeDisplayHash(deviceName, deviceId, friendly, identity.Manufacturer, identity.Model, maxW, maxH);
            var displayId = BuildDisplayId(identity.Manufacturer, identity.Model, hash);
            var connection = !string.IsNullOrEmpty(ccd?.ConnectionHint) && ccd.ConnectionHint != "unknown"
                ? ccd.ConnectionHint
                : GuessConnection(friendly, deviceName);
            if (!string.IsNullOrWhiteSpace(ccd?.FriendlyName)
                && (string.IsNullOrWhiteSpace(friendly) || friendly.StartsWith("Generic", StringComparison.OrdinalIgnoreCase)
                    || friendly.IndexOf("PnP", StringComparison.OrdinalIgnoreCase) >= 0
                    || friendly.StartsWith("\\\\.\\", StringComparison.Ordinal)))
            {
                friendly = ccd.FriendlyName;
            }
            var isProjector = GuessIsProjector(friendly, deviceName, deviceId, aspect, maxW, maxH, screen.Primary, connection);

            return new DisplayInfo
            {
                Index = index,
                DeviceName = deviceName,
                FriendlyName = friendly,
                Manufacturer = identity.Manufacturer,
                Model = identity.Model,
                DeviceId = deviceId,
                DisplayId = displayId,
                Primary = screen.Primary,
                IsProjector = isProjector,
                Bounds = bounds,
                WorkingArea = working,
                DpiScale = dpiScale,
                RefreshHz = current.Hz > 0 ? current.Hz : 60,
                Orientation = orientation,
                CurrentW = curW,
                CurrentH = curH,
                CurrentHz = current.Hz > 0 ? current.Hz : 60,
                RecommendedW = recW,
                RecommendedH = recH,
                RecommendedHz = recommended.Hz > 0 ? recommended.Hz : (current.Hz > 0 ? current.Hz : 60),
                MaxW = maxW,
                MaxH = maxH,
                MaxHz = maxMode.Hz > 0 ? maxMode.Hz : (recommended.Hz > 0 ? recommended.Hz : 60),
                AspectRatio = aspect,
                ConnectionHint = connection,
                HdrCapable = DetectHdrCapable(current, recommended, friendly, deviceName),
                ColorProfile = ResolveColorProfile(current, recommended, friendly, deviceName),
                Role = "unknown",
                DisplayHash = hash,
                IsMirrored = false,
            };
        }

        private static string ResolveColorProfile(ModeInfo current, ModeInfo recommended, string friendly, string deviceName)
        {
            var hdr = DetectHdrCapable(current, recommended, friendly, deviceName);
            if (hdr == true) return "HDR";
            if (hdr == false) return "SDR";
            return "UNKNOWN";
        }

        private static string ComputeConfigurationVersion(DisplayInfo[] displays)
        {
            if (displays == null || displays.Length == 0) return "0-empty";
            unchecked
            {
                var hash = 17;
                foreach (var d in displays)
                {
                    hash = hash * 31 + (d.DisplayHash ?? "").GetHashCode();
                    hash = hash * 31 + d.Bounds.Width;
                    hash = hash * 31 + d.Bounds.Height;
                    hash = hash * 31 + d.CurrentW;
                    hash = hash * 31 + d.CurrentH;
                    hash = hash * 31 + (int)Math.Round(d.DpiScale * 100);
                }
                return displays.Length + "-" + hash.ToString("x8");
            }
        }

        private struct IdentityInfo
        {
            public string Manufacturer;
            public string Model;
        }

        private static IdentityInfo ParseIdentity(string friendly, string deviceId)
        {
            var text = (friendly ?? "").Trim();
            var manufacturer = "";
            var model = "";
            if (!string.IsNullOrEmpty(text))
            {
                var parts = text.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                if (parts.Length >= 1) manufacturer = parts[0];
                if (parts.Length >= 2) model = string.Join(" ", parts, 1, Math.Min(parts.Length - 1, 3));
            }
            if (string.IsNullOrEmpty(manufacturer) && !string.IsNullOrEmpty(deviceId))
            {
                // DeviceID often MONITOR\EPS1234\...
                var id = deviceId.ToUpperInvariant();
                var mon = id.IndexOf("MONITOR\\", StringComparison.Ordinal);
                if (mon >= 0 && id.Length > mon + 8)
                {
                    var rest = id.Substring(mon + 8);
                    var slash = rest.IndexOf('\\');
                    var code = slash > 0 ? rest.Substring(0, slash) : rest;
                    if (code.Length >= 3) manufacturer = code.Substring(0, 3);
                    if (code.Length > 3) model = code.Substring(3);
                }
            }
            return new IdentityInfo
            {
                Manufacturer = manufacturer ?? "",
                Model = model ?? "",
            };
        }

        private static string BuildDisplayId(string manufacturer, string model, string hash)
        {
            var m = string.IsNullOrEmpty(manufacturer) ? "UNK" : manufacturer.ToUpperInvariant();
            var mo = string.IsNullOrEmpty(model) ? "DISP" : model.ToUpperInvariant().Replace(" ", "-");
            return "DISPLAY-" + EscapeId(m) + "-" + EscapeId(mo) + "-" + (hash ?? "00000000");
        }

        private static string EscapeId(string s)
        {
            if (string.IsNullOrEmpty(s)) return "X";
            var sb = new StringBuilder();
            foreach (var c in s)
            {
                if (char.IsLetterOrDigit(c) || c == '-' || c == '_') sb.Append(c);
                else if (c == ' ') sb.Append('-');
            }
            return sb.Length > 0 ? sb.ToString() : "X";
        }

        private static bool GuessIsProjector(string friendly, string deviceName, string deviceId, string aspect, int maxW, int maxH, bool primary, string connection)
        {
            var text = ((friendly ?? "") + " " + (deviceName ?? "") + " " + (deviceId ?? "")).ToLowerInvariant();
            if (text.Contains("epson") || text.Contains("powerlite") || text.Contains("power lite")
                || text.Contains("benq") || text.Contains("optoma")
                || text.Contains("projector") || text.Contains("projetor")
                || text.Contains("infocus") || text.Contains("christie") || text.Contains("barco")
                || text.Contains("vivitek") || text.Contains("nec projector")
                || text.Contains("svga") || text.Contains("s18") || text.Contains("eb-x") || text.Contains("eb-s")
                || (text.Contains("viewsonic") && (text.Contains("pj") || text.Contains("pjd"))))
                return true;
            if (!primary && aspect == "4:3" && maxW > 0 && maxW <= 1600 && maxH > 0 && maxH <= 1200)
                return true;
            var cable = (connection ?? "").ToLowerInvariant();
            if (!primary && (cable == "hdmi" || cable == "vga" || cable == "dvi" || cable == "analog" || cable == "wireless"))
                return true;
            return false;
        }

        private static string GetDeviceId(string deviceName)
        {
            if (string.IsNullOrEmpty(deviceName)) return "";
            var dd = new DISPLAY_DEVICE { cb = Marshal.SizeOf(typeof(DISPLAY_DEVICE)) };
            if (!EnumDisplayDevices(deviceName, 0, ref dd, 0)) return "";
            return dd.DeviceID ?? "";
        }

        private static ModeInfo GetMaxMode(string deviceName)
        {
            var best = default(ModeInfo);
            var dm = new DEVMODE();
            dm.dmSize = (short)Marshal.SizeOf(typeof(DEVMODE));
            int i = 0;
            long bestPixels = 0;
            while (EnumDisplaySettings(deviceName, i++, ref dm))
            {
                long px = (long)dm.dmPelsWidth * dm.dmPelsHeight;
                if (px > bestPixels || (px == bestPixels && dm.dmDisplayFrequency > best.Hz))
                {
                    bestPixels = px;
                    best = new ModeInfo
                    {
                        W = dm.dmPelsWidth,
                        H = dm.dmPelsHeight,
                        Hz = dm.dmDisplayFrequency,
                        BitsPerPel = dm.dmBitsPerPel,
                    };
                }
            }
            return best;
        }

        private static string ComputeDisplayHash(string deviceName, string deviceId, string friendly, string manufacturer, string model, int maxW, int maxH)
        {
            // Preferir DeviceId (EDID) — friendly de GPU mudava o hash a cada driver
            var idPart = !string.IsNullOrEmpty(deviceId) ? deviceId : (deviceName ?? "");
            var raw = idPart + "|" + (manufacturer ?? "") + "|" + (model ?? "") + "|" + maxW + "x" + maxH;
            if (string.IsNullOrEmpty(deviceId) && string.IsNullOrEmpty(manufacturer) && string.IsNullOrEmpty(model))
                raw = (deviceName ?? "") + "|" + (friendly ?? "") + "|" + maxW + "x" + maxH;
            unchecked
            {
                int hash = 17;
                foreach (var c in raw)
                    hash = hash * 31 + c;
                return hash.ToString("x8");
            }
        }

        private struct ModeInfo
        {
            public int W;
            public int H;
            public int Hz;
            public int Orientation;
            public int BitsPerPel;
        }

        /// <summary>HDR só quando há evidência; null = desconhecido (não inventar SDR/HDR).</summary>
        private static bool? DetectHdrCapable(ModeInfo current, ModeInfo recommended, string friendly, string deviceName)
        {
            var text = ((friendly ?? "") + " " + (deviceName ?? "")).ToLowerInvariant();
            if (text.Contains("hdr") || text.Contains("dolby vision")) return true;
            var bpp = Math.Max(current.BitsPerPel, recommended.BitsPerPel);
            if (bpp >= 10) return true;
            if (bpp > 0 && bpp < 10) return false;
            return null;
        }

        private static ModeInfo GetCurrentMode(string deviceName)
        {
            var dm = new DEVMODE();
            dm.dmSize = (short)Marshal.SizeOf(typeof(DEVMODE));
            if (!EnumDisplaySettings(deviceName, ENUM_CURRENT_SETTINGS, ref dm))
                return default;
            return new ModeInfo
            {
                W = dm.dmPelsWidth,
                H = dm.dmPelsHeight,
                Hz = dm.dmDisplayFrequency,
                Orientation = dm.dmDisplayOrientation,
                BitsPerPel = dm.dmBitsPerPel,
            };
        }

        private static ModeInfo GetRecommendedMode(string deviceName, DisplayConfigProbe.TargetInfo ccd)
        {
            if (ccd != null && ccd.NativeW > 0 && ccd.NativeH > 0)
            {
                return new ModeInfo
                {
                    W = ccd.NativeW,
                    H = ccd.NativeH,
                    Hz = ccd.NativeHz > 0 ? ccd.NativeHz : 60,
                    BitsPerPel = 32,
                };
            }
            var current = GetCurrentMode(deviceName);
            var dm = new DEVMODE();
            dm.dmSize = (short)Marshal.SizeOf(typeof(DEVMODE));
            if (!EnumDisplaySettings(deviceName, ENUM_REGISTRY_SETTINGS, ref dm))
                return current;
            var reg = new ModeInfo { W = dm.dmPelsWidth, H = dm.dmPelsHeight, Hz = dm.dmDisplayFrequency, BitsPerPel = dm.dmBitsPerPel };
            if (current.W > 0 && current.H > 0 && reg.W > 0
                && current.W <= 1600
                && (double)current.W / Math.Max(1, current.H) < 1.4
                && reg.W > current.W * 1.15)
            {
                return current;
            }
            return reg;
        }

        /// <summary>
        /// Capacidade real do painel/projetor. Não usar o maior modo da GPU
        /// (muitos drivers anunciam 1080p em SVGA/VGA via scaling).
        /// </summary>
        private static ModeInfo GetNativeCapMode(string deviceName, DisplayConfigProbe.TargetInfo ccd, ModeInfo current, ModeInfo recommended)
        {
            if (ccd != null && ccd.NativeW > 0 && ccd.NativeH > 0)
            {
                return new ModeInfo
                {
                    W = ccd.NativeW,
                    H = ccd.NativeH,
                    Hz = ccd.NativeHz > 0 ? ccd.NativeHz : recommended.Hz,
                    BitsPerPel = 32,
                };
            }
            if (recommended.W > 0 && recommended.H > 0)
                return recommended;
            if (current.W > 0 && current.H > 0)
                return current;
            return GetMaxMode(deviceName);
        }

        private static void EnsureAdapterCache()
        {
            if (_adapterNames != null) return;
            _adapterNames = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            for (uint i = 0; ; i++)
            {
                var dd = new DISPLAY_DEVICE { cb = Marshal.SizeOf(typeof(DISPLAY_DEVICE)) };
                if (!EnumDisplayDevices(null, i, ref dd, 0)) break;
                if (string.IsNullOrEmpty(dd.DeviceName)) continue;
                var label = dd.DeviceString;
                if (string.IsNullOrWhiteSpace(label)) label = dd.DeviceName;
                _adapterNames[dd.DeviceName] = label.Trim();
            }
        }

        private static string GetFriendlyName(string deviceName)
        {
            if (string.IsNullOrEmpty(deviceName)) return "Monitor";
            // Monitor (EDID DeviceString), não o adapter GPU de EnumDisplayDevices(null,…)
            var dd = new DISPLAY_DEVICE { cb = Marshal.SizeOf(typeof(DISPLAY_DEVICE)) };
            if (EnumDisplayDevices(deviceName, 0, ref dd, 0))
            {
                var monitorLabel = dd.DeviceString;
                if (!string.IsNullOrWhiteSpace(monitorLabel))
                    return monitorLabel.Trim();
            }
            EnsureAdapterCache();
            if (_adapterNames != null && _adapterNames.TryGetValue(deviceName, out var friendly))
                return friendly;
            return deviceName;
        }

        private static string GuessConnection(string friendly, string deviceName)
        {
            var text = ((friendly ?? "") + " " + (deviceName ?? "")).ToLowerInvariant();
            if (text.Contains("hdmi")) return "hdmi";
            if (text.Contains("displayport") || text.Contains("display port")
                || text.Contains(" dp") || text.Contains("(dp") || text.Contains("dp-"))
                return "displayport";
            if (text.Contains("dvi")) return "dvi";
            if (text.Contains("vga")) return "vga";
            if (text.Contains("wireless") || text.Contains("miracast")) return "wireless";
            return "unknown";
        }

        private static string FormatAspect(int w, int h)
        {
            if (w <= 0 || h <= 0) return "unknown";
            var ratio = (double)w / h;
            if (Math.Abs(ratio - 4.0 / 3.0) < 0.04) return "4:3";
            if (Math.Abs(ratio - 16.0 / 9.0) < 0.04) return "16:9";
            if (Math.Abs(ratio - 16.0 / 10.0) < 0.04) return "16:10";
            if (Math.Abs(ratio - 21.0 / 9.0) < 0.06) return "21:9";
            if (Math.Abs(ratio - 32.0 / 9.0) < 0.08) return "32:9";
            if (ratio < 1.4) return "4:3";
            if (ratio > 2.2) return "ultrawide";
            return "16:9";
        }

        private static string SerializeDisplay(DisplayInfo d)
        {
            return string.Format(
                "{{\"index\":{0},\"deviceName\":\"{1}\",\"friendlyName\":\"{2}\",\"primary\":{3}," +
                "\"width\":{26},\"height\":{27}," +
                "\"bounds\":{{\"x\":{4},\"y\":{5},\"w\":{6},\"h\":{7}}}," +
                "\"workingArea\":{{\"x\":{8},\"y\":{9},\"w\":{10},\"h\":{11}}}," +
                "\"dpiScale\":{12},\"refreshHz\":{13},\"orientation\":\"{14}\"," +
                "\"currentMode\":{{\"w\":{15},\"h\":{16},\"hz\":{28}}}," +
                "\"recommendedMode\":{{\"w\":{17},\"h\":{18},\"hz\":{29}}}," +
                "\"maxMode\":{{\"w\":{19},\"h\":{20},\"hz\":{30}}}," +
                "\"aspectRatio\":\"{21}\",\"connectionHint\":\"{22}\",\"hdrCapable\":{23},\"colorProfile\":\"{36}\",\"role\":\"{24}\"," +
                "\"displayHash\":\"{25}\",\"displayId\":\"{31}\",\"manufacturer\":\"{32}\",\"model\":\"{33}\"," +
                "\"deviceId\":\"{34}\",\"isProjector\":{35},\"isMirrored\":{37}}}",
                d.Index,
                EscapeJson(d.DeviceName),
                EscapeJson(d.FriendlyName),
                d.Primary ? "true" : "false",
                d.Bounds.X, d.Bounds.Y, d.Bounds.Width, d.Bounds.Height,
                d.WorkingArea.X, d.WorkingArea.Y, d.WorkingArea.Width, d.WorkingArea.Height,
                d.DpiScale.ToString("0.###", System.Globalization.CultureInfo.InvariantCulture),
                d.RefreshHz,
                EscapeJson(d.Orientation),
                d.CurrentW, d.CurrentH,
                d.RecommendedW, d.RecommendedH,
                d.MaxW, d.MaxH,
                EscapeJson(d.AspectRatio),
                EscapeJson(d.ConnectionHint),
                FormatNullableBool(d.HdrCapable),
                EscapeJson(d.Role),
                EscapeJson(d.DisplayHash ?? ""),
                d.CurrentW,
                d.CurrentH,
                d.CurrentHz,
                d.RecommendedHz,
                d.MaxHz,
                EscapeJson(d.DisplayId ?? ""),
                EscapeJson(d.Manufacturer ?? ""),
                EscapeJson(d.Model ?? ""),
                EscapeJson(d.DeviceId ?? ""),
                d.IsProjector ? "true" : "false",
                EscapeJson(d.ColorProfile ?? "UNKNOWN"),
                d.IsMirrored ? "true" : "false");
        }

        private static string FormatNullableBool(bool? value)
        {
            if (!value.HasValue) return "null";
            return value.Value ? "true" : "false";
        }

        private static string EscapeJson(string s)
        {
            if (string.IsNullOrEmpty(s)) return "";
            return s.Replace("\\", "\\\\").Replace("\"", "\\\"");
        }
    }
}
