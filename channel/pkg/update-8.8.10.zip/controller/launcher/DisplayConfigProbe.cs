using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;

namespace SomosumLauncher
{
    /// <summary>
    /// CCD (QueryDisplayConfig): conector HDMI/VGA/DP e modo nativo EDID.
    /// EnumDisplaySettings sozinho lista modos da GPU (ex.: 1080p falso em SVGA).
    /// </summary>
    internal static class DisplayConfigProbe
    {
        private const uint QDC_ONLY_ACTIVE_PATHS = 0x00000002;
        private const int ERROR_SUCCESS = 0;
        private const int ERROR_INSUFFICIENT_BUFFER = 122;

        private enum DISPLAYCONFIG_DEVICE_INFO_TYPE : uint
        {
            GET_SOURCE_NAME = 1,
            GET_TARGET_NAME = 2,
            GET_TARGET_PREFERRED_MODE = 3,
        }

        private enum DISPLAYCONFIG_VIDEO_OUTPUT_TECHNOLOGY : uint
        {
            OTHER = 0xFFFFFFFF,
            HD15 = 0,
            SVIDEO = 1,
            COMPOSITE_VIDEO = 2,
            COMPONENT_VIDEO = 3,
            DVI = 4,
            HDMI = 5,
            LVDS = 6,
            D_JPN = 8,
            SDI = 9,
            DISPLAYPORT_EXTERNAL = 10,
            DISPLAYPORT_EMBEDDED = 11,
            UDI_EXTERNAL = 12,
            UDI_EMBEDDED = 13,
            SDTVDONGLE = 14,
            MIRACAST = 15,
            INDIRECT_WIRED = 16,
            INDIRECT_VIRTUAL = 17,
            INTERNAL = 0x80000000,
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct LUID
        {
            public uint LowPart;
            public int HighPart;
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct DISPLAYCONFIG_RATIONAL
        {
            public uint Numerator;
            public uint Denominator;
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct DISPLAYCONFIG_PATH_SOURCE_INFO
        {
            public LUID adapterId;
            public uint id;
            public uint modeInfoIdx;
            public uint statusFlags;
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct DISPLAYCONFIG_PATH_TARGET_INFO
        {
            public LUID adapterId;
            public uint id;
            public uint modeInfoIdx;
            public DISPLAYCONFIG_VIDEO_OUTPUT_TECHNOLOGY outputTechnology;
            public uint rotation;
            public uint scaling;
            public DISPLAYCONFIG_RATIONAL refreshRate;
            public uint scanLineOrdering;
            public int targetAvailable;
            public uint statusFlags;
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct DISPLAYCONFIG_PATH_INFO
        {
            public DISPLAYCONFIG_PATH_SOURCE_INFO sourceInfo;
            public DISPLAYCONFIG_PATH_TARGET_INFO targetInfo;
            public uint flags;
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct DISPLAYCONFIG_MODE_INFO
        {
            public uint infoType;
            public uint id;
            public LUID adapterId;
            public ulong a, b, c, d, e, f;
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct DISPLAYCONFIG_DEVICE_INFO_HEADER
        {
            public DISPLAYCONFIG_DEVICE_INFO_TYPE type;
            public uint size;
            public LUID adapterId;
            public uint id;
        }

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
        private struct DISPLAYCONFIG_SOURCE_DEVICE_NAME
        {
            public DISPLAYCONFIG_DEVICE_INFO_HEADER header;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)]
            public string viewGdiDeviceName;
        }

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
        private struct DISPLAYCONFIG_TARGET_DEVICE_NAME
        {
            public DISPLAYCONFIG_DEVICE_INFO_HEADER header;
            public uint flags;
            public DISPLAYCONFIG_VIDEO_OUTPUT_TECHNOLOGY outputTechnology;
            public ushort edidManufactureId;
            public ushort edidProductCodeId;
            public uint connectorInstance;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 64)]
            public string monitorFriendlyDeviceName;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)]
            public string monitorDevicePath;
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct DISPLAYCONFIG_2DREGION
        {
            public uint cx;
            public uint cy;
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct DISPLAYCONFIG_VIDEO_SIGNAL_INFO
        {
            public ulong pixelRate;
            public DISPLAYCONFIG_RATIONAL hSyncFreq;
            public DISPLAYCONFIG_RATIONAL vSyncFreq;
            public DISPLAYCONFIG_2DREGION activeSize;
            public DISPLAYCONFIG_2DREGION totalSize;
            public uint videoStandard;
            public uint scanLineOrdering;
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct DISPLAYCONFIG_TARGET_MODE
        {
            public DISPLAYCONFIG_VIDEO_SIGNAL_INFO targetVideoSignalInfo;
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct DISPLAYCONFIG_TARGET_PREFERRED_MODE
        {
            public DISPLAYCONFIG_DEVICE_INFO_HEADER header;
            public uint width;
            public uint height;
            public DISPLAYCONFIG_TARGET_MODE targetMode;
        }

        [DllImport("user32.dll")]
        private static extern int GetDisplayConfigBufferSizes(uint flags, out uint numPathArrayElements, out uint numModeInfoArrayElements);

        [DllImport("user32.dll")]
        private static extern int QueryDisplayConfig(
            uint flags,
            ref uint numPathArrayElements,
            [Out] DISPLAYCONFIG_PATH_INFO[] pathInfoArray,
            ref uint numModeInfoArrayElements,
            [Out] DISPLAYCONFIG_MODE_INFO[] modeInfoArray,
            IntPtr currentTopologyId);

        [DllImport("user32.dll")]
        private static extern int DisplayConfigGetDeviceInfo(ref DISPLAYCONFIG_SOURCE_DEVICE_NAME request);

        [DllImport("user32.dll")]
        private static extern int DisplayConfigGetDeviceInfo(ref DISPLAYCONFIG_TARGET_DEVICE_NAME request);

        [DllImport("user32.dll")]
        private static extern int DisplayConfigGetDeviceInfo(ref DISPLAYCONFIG_TARGET_PREFERRED_MODE request);

        internal sealed class TargetInfo
        {
            public string GdiDeviceName;
            public string ConnectionHint;
            public string FriendlyName;
            public int NativeW;
            public int NativeH;
            public int NativeHz;
        }

        public static Dictionary<string, TargetInfo> Probe()
        {
            var map = new Dictionary<string, TargetInfo>(StringComparer.OrdinalIgnoreCase);
            try
            {
                uint pathCount;
                uint modeCount;
                var rc = GetDisplayConfigBufferSizes(QDC_ONLY_ACTIVE_PATHS, out pathCount, out modeCount);
                if (rc != ERROR_SUCCESS || pathCount == 0) return map;

                var paths = new DISPLAYCONFIG_PATH_INFO[pathCount];
                var modes = new DISPLAYCONFIG_MODE_INFO[Math.Max(modeCount, 1)];
                rc = QueryDisplayConfig(QDC_ONLY_ACTIVE_PATHS, ref pathCount, paths, ref modeCount, modes, IntPtr.Zero);
                if (rc == ERROR_INSUFFICIENT_BUFFER)
                {
                    paths = new DISPLAYCONFIG_PATH_INFO[pathCount];
                    modes = new DISPLAYCONFIG_MODE_INFO[Math.Max(modeCount, 1)];
                    rc = QueryDisplayConfig(QDC_ONLY_ACTIVE_PATHS, ref pathCount, paths, ref modeCount, modes, IntPtr.Zero);
                }
                if (rc != ERROR_SUCCESS) return map;

                for (var i = 0; i < pathCount; i++)
                {
                    var path = paths[i];
                    var srcName = new DISPLAYCONFIG_SOURCE_DEVICE_NAME();
                    srcName.header.type = DISPLAYCONFIG_DEVICE_INFO_TYPE.GET_SOURCE_NAME;
                    srcName.header.size = (uint)Marshal.SizeOf(typeof(DISPLAYCONFIG_SOURCE_DEVICE_NAME));
                    srcName.header.adapterId = path.sourceInfo.adapterId;
                    srcName.header.id = path.sourceInfo.id;
                    if (DisplayConfigGetDeviceInfo(ref srcName) != ERROR_SUCCESS) continue;
                    var gdi = srcName.viewGdiDeviceName;
                    if (string.IsNullOrWhiteSpace(gdi)) continue;

                    var tgtName = new DISPLAYCONFIG_TARGET_DEVICE_NAME();
                    tgtName.header.type = DISPLAYCONFIG_DEVICE_INFO_TYPE.GET_TARGET_NAME;
                    tgtName.header.size = (uint)Marshal.SizeOf(typeof(DISPLAYCONFIG_TARGET_DEVICE_NAME));
                    tgtName.header.adapterId = path.targetInfo.adapterId;
                    tgtName.header.id = path.targetInfo.id;
                    var tech = path.targetInfo.outputTechnology;
                    var friendly = "";
                    if (DisplayConfigGetDeviceInfo(ref tgtName) == ERROR_SUCCESS)
                    {
                        tech = tgtName.outputTechnology;
                        friendly = tgtName.monitorFriendlyDeviceName ?? "";
                    }

                    var pref = new DISPLAYCONFIG_TARGET_PREFERRED_MODE();
                    pref.header.type = DISPLAYCONFIG_DEVICE_INFO_TYPE.GET_TARGET_PREFERRED_MODE;
                    pref.header.size = (uint)Marshal.SizeOf(typeof(DISPLAYCONFIG_TARGET_PREFERRED_MODE));
                    pref.header.adapterId = path.targetInfo.adapterId;
                    pref.header.id = path.targetInfo.id;
                    var nativeW = 0;
                    var nativeH = 0;
                    var nativeHz = 0;
                    if (DisplayConfigGetDeviceInfo(ref pref) == ERROR_SUCCESS)
                    {
                        nativeW = (int)pref.width;
                        nativeH = (int)pref.height;
                        var v = pref.targetMode.targetVideoSignalInfo.vSyncFreq;
                        if (v.Denominator > 0 && v.Numerator > 0)
                            nativeHz = (int)Math.Round(v.Numerator / (double)v.Denominator);
                    }
                    if (nativeHz <= 0 && path.targetInfo.refreshRate.Denominator > 0)
                    {
                        nativeHz = (int)Math.Round(
                            path.targetInfo.refreshRate.Numerator / (double)path.targetInfo.refreshRate.Denominator);
                    }

                    map[gdi.Trim()] = new TargetInfo
                    {
                        GdiDeviceName = gdi.Trim(),
                        ConnectionHint = MapTechnology(tech),
                        FriendlyName = (friendly ?? "").Trim(),
                        NativeW = nativeW,
                        NativeH = nativeH,
                        NativeHz = nativeHz > 0 ? nativeHz : 60,
                    };
                }
            }
            catch
            {
                return map;
            }
            return map;
        }

        private static string MapTechnology(DISPLAYCONFIG_VIDEO_OUTPUT_TECHNOLOGY tech)
        {
            switch (tech)
            {
                case DISPLAYCONFIG_VIDEO_OUTPUT_TECHNOLOGY.HDMI: return "hdmi";
                case DISPLAYCONFIG_VIDEO_OUTPUT_TECHNOLOGY.HD15: return "vga";
                case DISPLAYCONFIG_VIDEO_OUTPUT_TECHNOLOGY.DVI: return "dvi";
                case DISPLAYCONFIG_VIDEO_OUTPUT_TECHNOLOGY.DISPLAYPORT_EXTERNAL:
                case DISPLAYCONFIG_VIDEO_OUTPUT_TECHNOLOGY.DISPLAYPORT_EMBEDDED: return "displayport";
                case DISPLAYCONFIG_VIDEO_OUTPUT_TECHNOLOGY.MIRACAST: return "wireless";
                case DISPLAYCONFIG_VIDEO_OUTPUT_TECHNOLOGY.INTERNAL:
                case DISPLAYCONFIG_VIDEO_OUTPUT_TECHNOLOGY.LVDS: return "internal";
                case DISPLAYCONFIG_VIDEO_OUTPUT_TECHNOLOGY.COMPOSITE_VIDEO:
                case DISPLAYCONFIG_VIDEO_OUTPUT_TECHNOLOGY.SVIDEO:
                case DISPLAYCONFIG_VIDEO_OUTPUT_TECHNOLOGY.COMPONENT_VIDEO: return "analog";
                default: return "unknown";
            }
        }
    }
}
