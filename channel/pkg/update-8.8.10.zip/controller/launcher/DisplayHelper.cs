using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace SomosumLauncher
{
    internal static class DisplayHelper
    {
        public static Screen[] GetAllDisplays()
        {
            return Screen.AllScreens.OrderBy(s => s.Bounds.X).ThenBy(s => s.Bounds.Y).ToArray();
        }

        public static string GetDetailedSnapshotJson(int projectorIndex, int stageIndex, int operatorIndex = 0, int projector2Index = -1)
        {
            return DisplayEnumerator.GetSnapshotJson(projectorIndex, stageIndex, operatorIndex, projector2Index);
        }

        public static Screen GetProjectorScreen(int displayIndex)
        {
            return GetProjectorScreen(displayIndex, null);
        }

        public static Screen GetProjectorScreen(int displayIndex, string deviceName)
        {
            var screens = GetAllDisplays();
            if (screens.Length == 0) return Screen.PrimaryScreen;

            var byName = ResolveScreenIndex(deviceName, screens);
            if (byName >= 0) return screens[byName];

            if (displayIndex >= 0 && displayIndex < screens.Length)
                return screens[displayIndex];

            if (screens.Length > 1)
                return screens.FirstOrDefault(s => !s.Primary) ?? screens[1];
            return screens[0];
        }

        public static int ResolveScreenIndex(string deviceName, Screen[] screens)
        {
            if (screens == null || screens.Length == 0 || string.IsNullOrWhiteSpace(deviceName))
                return -1;
            for (var i = 0; i < screens.Length; i++)
            {
                if (string.Equals(screens[i].DeviceName, deviceName, StringComparison.OrdinalIgnoreCase))
                    return i;
            }
            return -1;
        }

        public static int ResolveProjectorIndex(int preferredIndex, string deviceName, Screen[] screens)
        {
            if (screens == null || screens.Length == 0) return 0;

            var byName = ResolveScreenIndex(deviceName, screens);
            if (byName >= 0) return byName;

            try
            {
                var infos = DisplayEnumerator.Enumerate(-1, -1, 0, -1);
                var cableBest = -1;
                for (var i = 0; i < infos.Length && i < screens.Length; i++)
                {
                    if (infos[i].Primary) continue;
                    if (infos[i].IsProjector) return i;
                    var c = (infos[i].ConnectionHint ?? "").ToLowerInvariant();
                    if (cableBest < 0 && (c == "hdmi" || c == "vga" || c == "dvi" || c == "analog" || c == "displayport" || c == "wireless"))
                        cableBest = i;
                }
                if (cableBest >= 0) return cableBest;
            }
            catch { /* fallback abaixo */ }

            if (preferredIndex >= 0 && preferredIndex < screens.Length && !screens[preferredIndex].Primary)
                return preferredIndex;

            if (screens.Length > 1)
            {
                for (var i = 0; i < screens.Length; i++)
                    if (!screens[i].Primary) return i;
                return 1;
            }
            return 0;
        }

        public static void OpenScreenInBrowser(string root, int port, int displayIndex, string version, bool kiosk = true, int output = 1, string deviceName = null)
        {
            var screen = GetProjectorScreen(displayIndex, deviceName);
            var bounds = screen.Bounds;
            var autofs = kiosk ? "autofs=1&" : "";
            var lite = "lite=1&production=1&";
            var outputQ = output > 1 ? ("output=" + output + "&") : "";
            var url = string.Format(
                LocalServer.Scheme() + "://127.0.0.1:{0}/screen.html?{1}{2}{3}v={4}",
                port,
                outputQ,
                autofs,
                lite,
                Uri.EscapeDataString(version ?? "3.5.0"));

            if (kiosk && (TryEdgeAppWindow(url, bounds, kiosk: true) || TryChromeAppWindow(url, bounds, kiosk: true)))
                return;

            if (!kiosk)
            {
                var wa = screen.WorkingArea;
                var w = Math.Min(1280, Math.Max(960, wa.Width - 80));
                var h = Math.Min(720, Math.Max(540, wa.Height - 120));
                bounds = new Rectangle(
                    wa.X + Math.Max(0, (wa.Width - w) / 2),
                    wa.Y + Math.Max(0, (wa.Height - h) / 2),
                    w, h);
                if (TryEdgeAppWindow(url, bounds, kiosk: false) || TryChromeAppWindow(url, bounds, kiosk: false))
                    return;
            }

            try
            {
                Process.Start(new ProcessStartInfo(url) { UseShellExecute = true });
            }
            catch
            {
                Process.Start("cmd.exe", "/c start \"\" \"" + url + "\"");
            }
        }

        public static void OpenControlInBrowser(int port, string version)
        {
            var bounds = Screen.PrimaryScreen != null
                ? Screen.PrimaryScreen.WorkingArea
                : new Rectangle(0, 0, 1360, 860);
            var url = string.Format(
                LocalServer.Scheme() + "://127.0.0.1:{0}/control.html?v={1}",
                port,
                Uri.EscapeDataString(version ?? "3.5.0"));

            if (TryEdgeAppWindow(url, bounds, kiosk: false) || TryChromeAppWindow(url, bounds, kiosk: false))
                return;

            try
            {
                Process.Start(new ProcessStartInfo(url) { UseShellExecute = true });
            }
            catch
            {
                Process.Start("cmd.exe", "/c start \"\" \"" + url + "\"");
            }
        }

        private static bool TryEdgeAppWindow(string url, Rectangle bounds, bool kiosk)
        {
            var edge = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86),
                "Microsoft", "Edge", "Application", "msedge.exe");
            if (!File.Exists(edge))
            {
                edge = Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),
                    "Microsoft", "Edge", "Application", "msedge.exe");
            }
            if (!File.Exists(edge)) return false;

            var args = kiosk
                ? string.Format(
                    "--new-window --window-position={0},{1} --window-size={2},{3} --start-fullscreen --app={4}",
                    bounds.X, bounds.Y, bounds.Width, bounds.Height, url)
                : string.Format(
                    "--new-window --window-position={0},{1} --window-size={2},{3} --app={4}",
                    bounds.X, bounds.Y, bounds.Width, bounds.Height, url);
            try
            {
                Process.Start(edge, args);
                return true;
            }
            catch { return false; }
        }

        private static bool TryChromeAppWindow(string url, Rectangle bounds, bool kiosk)
        {
            var chrome = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),
                "Google", "Chrome", "Application", "chrome.exe");
            if (!File.Exists(chrome)) return false;

            var args = kiosk
                ? string.Format(
                    "--new-window --window-position={0},{1} --window-size={2},{3} --start-fullscreen --app={4}",
                    bounds.X, bounds.Y, bounds.Width, bounds.Height, url)
                : string.Format(
                    "--new-window --window-position={0},{1} --window-size={2},{3} --app={4}",
                    bounds.X, bounds.Y, bounds.Width, bounds.Height, url);
            try
            {
                Process.Start(chrome, args);
                return true;
            }
            catch { return false; }
        }

        public static int PromptProjectorDisplay(IWin32Window owner)
        {
            var screens = GetAllDisplays();
            if (screens.Length <= 1) return 0;

            using (var dlg = new Form())
            {
                dlg.Text = "SOMOSUM — Configurar projetor";
                dlg.FormBorderStyle = FormBorderStyle.FixedDialog;
                dlg.StartPosition = FormStartPosition.CenterScreen;
                dlg.MinimizeBox = false;
                dlg.MaximizeBox = false;
                dlg.ClientSize = new Size(420, 180);

                var lbl = new Label
                {
                    AutoSize = false,
                    Size = new Size(400, 70),
                    Location = new Point(10, 10),
                    Text = "Qual monitor e o projetor?\n" + string.Join(" | ", screens.Select((s, i) =>
                        (i + 1) + ": " + s.Bounds.Width + "x" + s.Bounds.Height + (s.Primary ? "*" : "")))
                };
                var num = new NumericUpDown
                {
                    Minimum = 1,
                    Maximum = screens.Length,
                    Value = screens.Length > 1 ? 2 : 1,
                    Location = new Point(10, 90),
                    Width = 80
                };
                var ok = new Button { Text = "OK", DialogResult = DialogResult.OK, Location = new Point(220, 88) };
                var cancel = new Button { Text = "Cancelar", DialogResult = DialogResult.Cancel, Location = new Point(300, 88) };
                dlg.Controls.AddRange(new Control[] { lbl, num, ok, cancel });
                dlg.AcceptButton = ok;
                dlg.CancelButton = cancel;

                if (dlg.ShowDialog(owner) == DialogResult.OK)
                    return (int)num.Value - 1;
            }
            return screens.Length > 1 ? 1 : 0;
        }
    }
}
