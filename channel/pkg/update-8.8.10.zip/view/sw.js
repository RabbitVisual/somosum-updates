/* SOMOSUM PWA - network-first; revision via /api/app-meta */
var SOMOSUM_SHELL_PREFIX = 'somosum-shell-v8.8.10';
var ACTIVE_CACHE = SOMOSUM_SHELL_PREFIX;

self.addEventListener('message', function (e) {
  if (e.data && e.data.type === 'SET_REVISION' && e.data.revision) {
    ACTIVE_CACHE = 'somosum-shell-v' + e.data.revision;
  }
});

function shellUrls(revision) {
  var v = revision || '7.4.0';
  var q = '?v=' + encodeURIComponent(v);
  return [
    '/remote.html',
    '/css/tokens.css' + q,
    '/css/remote.css' + q,
    '/js/core/boot-asset-loader.js' + q,
    '/js/core/boot-inline.js' + q,
    '/js/remote/bootstrap.js' + q,
    '/IMG/LOGO/SOMOSUM.png',
    '/launcher/somosum.ico',
    '/IMG/CAPA-SOMOSUM.svg',
    '/manifest.webmanifest',
  ];
}

self.addEventListener('install', function (e) {
  e.waitUntil(
    fetch('/api/app-meta', { cache: 'no-store' })
      .then(function (r) { return r.ok ? r.json() : null; })
      .catch(function () { return null; })
      .then(function (meta) {
        var rev = (meta && (meta.assetRevision || meta.version)) || '7.4.0';
        ACTIVE_CACHE = 'somosum-shell-v' + rev;
        return caches.open(ACTIVE_CACHE).then(function (c) {
          return c.addAll(shellUrls(rev)).catch(function () {});
        });
      })
      .then(function () { return self.skipWaiting(); })
  );
});

self.addEventListener('activate', function (e) {
  e.waitUntil(
    caches.keys().then(function (keys) {
      return Promise.all(
        keys.filter(function (k) {
          return k.startsWith('somosum-shell-v') && k !== ACTIVE_CACHE;
        }).map(function (k) { return caches.delete(k); })
      );
    }).then(function () { return self.clients.claim(); })
  );
});

self.addEventListener('fetch', function (e) {
  var url = new URL(e.request.url);
  if (url.pathname.startsWith('/api/')) return;
  if (url.pathname.startsWith('/ws/')) return;
  if (e.request.method !== 'GET') return;

  var isCode = /\.(js|css|mjs)(\?|$)/i.test(url.pathname);
  if (isCode) {
    e.respondWith(
      fetch(e.request)
        .then(function (res) {
          if (res.ok) {
            var copy = res.clone();
            caches.open(ACTIVE_CACHE).then(function (c) { return c.put(e.request, copy); }).catch(function () {});
          }
          return res;
        })
        .catch(function () { return caches.match(e.request); })
    );
    return;
  }

  e.respondWith(
    fetch(e.request)
      .then(function (res) {
        if (res.ok && url.origin === self.location.origin) {
          var copy = res.clone();
          caches.open(ACTIVE_CACHE).then(function (c) { return c.put(e.request, copy); }).catch(function () {});
        }
        return res;
      })
      .catch(function () {
        return caches.match(e.request).then(function (r) {
          return r || caches.match('/remote.html');
        });
      })
  );
});
