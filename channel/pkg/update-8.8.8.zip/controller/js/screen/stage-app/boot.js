import '../../runtime/runtime-client.js';
import { esc, escAttr, rawHtml, setHtml } from '../../core/render-engine/index.js';
import { ProjectionBus, MessageTypes } from '../../core/bus.js';
import { getPrefs, initializeFromDisk } from '../../core/store.js';
import { applyTheme } from '../../core/themes.js';
import { resolvePrefsAtmosphereId } from '../../ui/theme/atmospheres.js';
import { loadCustomFonts } from '../../core/fonts.js';
import { renderLyricsLinesBlock, renderMessage } from '../../slides/templates.js';
import { renderInterlinearSlideHtml } from '../../bible/interlinear-render.js';
import { formatCountdownDigits } from '../../core/countdown.js';
import {
  getStageClientId,
  getStageDeviceLabel,
  setStageDeviceLabel,
  startPresenceHeartbeat,
} from '../../core/client-presence.js';
import { getRecoveryEngine } from '../../runtime/facades/recovery-runtime.js';
import { TaskScheduler } from '../../core/task-scheduler.js';
import { TaskIds } from '../../core/task-registry.js';
import { initUiScale } from '../../core/ui-scale.js';
import { RenderScheduler } from '../../core/render-scheduler.js';
import { getDesignDimensions } from '../../runtime/facades/display-runtime.js';
import {
  getChordViewState,
  setChordMode,
  renderChordChartHtml,
  wireStageChordControls,
} from '../stage-chords-view.js';
import {
  globalHighlightIndices,
  stanzaIsLive,
  normalizeLyricLine,
} from '../stage-chord-render.js';
import { normalizeStageLayout, stageLayoutLabel } from '../stage-layouts.js';
import { bindChromeThemeToggle } from '../../ui/chrome-theme.js';
import { applyUiPrefs } from '../../ui/apply-ui-prefs.js';
import {
  createMusicianSession,
  updateMusicianSession,
  shouldStabilizeMusicianView,
  patchMusicianLivePill,
  musicianSongKey,
} from '../stage-musician-session.js';
import { onStageSlideChange, scrollHighlightIntoView as scrollHighlightEl, getAutoScrollState, resolveStageScrollContainer, setAutoScrollMode, setAutoScrollPaused } from '../stage-auto-scroll.js';
import { faIcon } from '../../core/fa-icons.js';

const SLIDE_TYPE_LABELS = {
  welcome: 'Boas-vindas',
  lyrics: 'Louvor',
  'lyrics-title': 'Louvor',
  bible: 'Leitura bíblica',
  'bible-reader': 'Leitura bíblica',
  message: 'Mensagem',
  prayer: 'Oração',
  section: 'Seção',
  announcements: 'Comunicados',
  communion: 'Ceia do Senhor',
  theme: 'Tema / Divisa',
  participation: 'Participação',
  offering: 'Oferta',
  'visitor-welcome': 'Visitantes',
  custom: 'Personalizado',
  media: 'Mídia',
  blank: 'Em branco',
  logo: 'Logo',
  countdown: 'Pré-culto',
};

const FULL_LYRICS_KEY = 'somosum-stage-full-lyrics';
const LYRICS_VIEW_KEY = 'somosum-stage-lyrics-view';
const TELEPROMPTER_KEY = 'somosum-stage-teleprompter';

function slideTypeLabel(type) {
  return SLIDE_TYPE_LABELS[type] || type || 'Slide';
}

function lyricsKey(slide) {
  if (!slide?.lines?.length) return '';
  return `${slide.slideIndex ?? 0}:${slide.lines.join('\n')}`;
}

function scaledLyricsStyle(slide = {}, prefs = {}) {
  const style = slide.style || {};
  const base = style.fontSize || 54;
  const body = typeof document !== 'undefined' ? document.getElementById('stage-live-body') : null;
  const dims = getDesignDimensions(body);
  const aspect43 = dims.w / dims.h < 1.45;
  const maxLeg = prefs?.displayEngine?.maxLegibility || aspect43;
  // Tablet/celular: letras legíveis sem estourar a tela (antes floor 64px era excessivo)
  let floor = maxLeg && aspect43 ? 28 : 20;
  const vw = Math.max(2.2, Math.min(3.8, base * 0.05));
  const max = Math.max(floor, Math.round(base * (maxLeg ? 0.48 : 0.42)));
  return `
    --lyrics-font-size: clamp(${floor / 16}rem, ${vw}vw, ${max}px);
    --lyrics-line-height: ${style.lineHeight || 1.4};
    --lyrics-align: ${style.align || 'center'};
    --lyrics-text-transform: ${style.textTransform || 'none'};`;
}

function formatProgress(state) {
  const total = state.totalSlides || 0;
  const flat = (state.flatIndex ?? 0) + 1;
  if (!total) return '—';
  const part = (state.itemSlideIndex ?? 0) + 1;
  const parts = state.itemSlideCount > 1 ? ` · ${part}/${state.itemSlideCount}` : '';
  return `${flat}/${total}${parts}`;
}

function countdownRemainingMs(expiresAt) {
  if (!expiresAt) return null;
  return Math.max(0, expiresAt - Date.now());
}

function alertTargetsMe(target, clientId, layout) {
  if (!target || target === 'all') return true;
  if (Array.isArray(target)) {
    return target.some((t) => alertTargetsMe(t, clientId, layout));
  }
  const t = String(target);
  if (t === clientId) return true;
  const role = normalizeStageLayout(layout || '');
  if (t === 'preacher' || t === 'musician' || t === 'singer') {
    return role === t;
  }
  if (t === 'pulpit' || t === 'stage') return true;
  return false;
}


export async function bootstrapMain(ctx) {
const root = document.getElementById('stage-root');
  if (!root) return;

  setHtml(root, rawHtml(`
    <div class="stage-boot">
      <div class="stage-boot-inner">
        <div class="stage-boot-spinner" aria-hidden="true"></div>
        <p class="stage-boot-title">Púlpito</p>
        <p class="stage-boot-msg">Preparando painel do púlpito…</p>
      </div>
    </div>`));

  try {
    const { markAppReady } = await import('../../core/server-boot.js');
    markAppReady();
    initUiScale();
  } catch { /* ignore */ }

  await Promise.all([
    loadCustomFonts().catch(() => {}),
    initializeFromDisk().catch(() => {}),
  ]);
  const prefs = getPrefs();
  applyTheme(resolvePrefsAtmosphereId(prefs));

  const bus = new ProjectionBus('stage');
  const stagePro = {};
  (await import('../stage-extensions.js')).wireStagePro(stagePro);
  const { mountStageProUi } = await import('../stage-toolbar.js');
  let teardownStagePro = () => {};
  getRecoveryEngine().init({ role: 'stage', bus });
  const clientId = getStageClientId();
  let deviceLabel = getStageDeviceLabel();

  let state = {
    programItems: [],
    slide: null,
    prefs,
    churchName: prefs.church?.name || 'SOMOSUM',
    churchSubtitle: prefs.church?.subtitle || '',
    cultoTitle: prefs.navigation?.cultoTitle || '',
    nextItems: [],
    fullSongLyrics: null,
    chordChart: null,
    sermonScript: null,
    itemOperatorNote: '',
  };
  let controlOnline = false;
  let lastControlHeartbeat = 0;
  let lastLyricsKey = '';
  const musicianSession = createMusicianSession();
  let musicianRepeating = false;
  let shellBuilt = false;
  let lyricsViewMode = 'live'; // live = segue operador | full = letra completa
  let teleprompterMode = false;
  try {
    const storedView = localStorage.getItem(LYRICS_VIEW_KEY);
    if (storedView === 'live' || storedView === 'full') lyricsViewMode = storedView;
    else if (localStorage.getItem(FULL_LYRICS_KEY) === '1') lyricsViewMode = 'full';
  } catch { /* ignore */ }
  try { teleprompterMode = localStorage.getItem(TELEPROMPTER_KEY) === '1'; } catch { /* ignore */ }

  const setLyricsViewMode = (mode) => {
    lyricsViewMode = mode === 'full' ? 'full' : 'live';
    try {
      localStorage.setItem(LYRICS_VIEW_KEY, lyricsViewMode);
      localStorage.setItem(FULL_LYRICS_KEY, lyricsViewMode === 'full' ? '1' : '0');
    } catch { /* ignore */ }
  };

  const normalizeStageLayoutLocal = (layout) => normalizeStageLayout(layout);

  const getStageLayout = () => normalizeStageLayoutLocal(stagePro.getStageProLayout?.());

  const isMusicianChordView = () => {
    const layout = getStageLayout();
    if (layout !== 'musician') return false;
    const chordSt = getChordViewState();
    return !!chordSt.mode && !!state.chordChart?.source?.trim();
  };

  const refreshMusicianSession = (slide) => {
    const info = updateMusicianSession(musicianSession, state, slide);
    musicianRepeating = info.repeating;
    return info;
  };

  const applyProfileDefaults = (layout) => {
    const l = normalizeStageLayoutLocal(layout);
    if (l === 'singer') {
      setChordMode(false);
      setAutoScrollMode('follow');
      try {
        localStorage.setItem('somosum-stage-pro-autoscroll', JSON.stringify({
          mode: 'follow',
          speed: 1,
          paused: false,
        }));
      } catch { /* ignore */ }
    } else if (l === 'musician') {
      // Perfil Músico = cifra ligada. Não herdar '0' deixado pelo Cantor.
      setChordMode(true);
      setAutoScrollMode('manual');
      setAutoScrollPaused(false);
      try {
        localStorage.setItem('somosum-stage-pro-autoscroll', JSON.stringify({
          mode: 'manual',
          speed: 1,
          paused: false,
        }));
      } catch { /* ignore */ }
    } else if (l === 'preacher' && state.sermonScript?.blocks?.length) {
      teleprompterMode = true;
      try { localStorage.setItem(TELEPROMPTER_KEY, '1'); } catch { /* ignore */ }
    }
  };

  const applyStageLayout = (layout) => {
    const l = normalizeStageLayoutLocal(layout || getStageLayout());
    if (l !== stagePro.getStageProLayout?.()) stagePro.setStageProLayout?.(l);
    document.body.dataset.stageLayout = l;
    applyProfileDefaults(l);
    const shell = root.querySelector('.stage-shell');
    if (shell) {
      shell.dataset.layoutTransition = '1';
      setTimeout(() => { delete shell.dataset.layoutTransition; }, 280);
    }
    renderShell();
  };

  try {
    const stored = localStorage.getItem('somosum-stage-pro-layout');
    if (stored) {
      const migrated = normalizeStageLayoutLocal(stored);
      if (migrated !== stored) {
        localStorage.setItem('somosum-stage-pro-layout', migrated);
      }
    }
  } catch { /* ignore */ }

  const scheduleStagePatch = (surface, fn) => {
    if (window.__SOMOSUM_LIVE_ACTIVE) {
      RenderScheduler.markDirty(surface, { patch: fn, priority: 'live' });
    } else {
      fn();
    }
  };

  let operatorAlert = null;
  let operatorCountdown = null;
  let ebdCountdown = null;
  let railExpanded = window.innerWidth >= 768;

  startPresenceHeartbeat(() => ({
    stageLayout: getStageLayout(),
    itemTitle: state.itemTitle || state.current?.itemTitle || '',
    slideType: state.slide?.type || state.current?.slideType || '',
    hasAlert: !!(operatorAlert || operatorCountdown),
    ebdActive: !!ebdCountdown?.expiresAt,
  }));

  const scrollHighlightIntoView = (force = false) => {
    requestAnimationFrame(() => {
      const st = getAutoScrollState();
      if (!force && st.mode === 'follow' && st.paused) return;
      scrollHighlightEl(root);
    });
  };

  const lyricsTypesMatch = (a, b) => {
    if (!a || !b) return a === b;
    const lyricsLike = (t) => t === 'lyrics' || t === 'lyrics-title';
    if (lyricsLike(a) && lyricsLike(b)) return true;
    return a === b;
  };

  const isSlideOutOfSync = () => {
    const itemType = state.current?.slideType || state.slideType;
    const slideType = state.slide?.type;
    if (!itemType || !slideType) return false;
    return !lyricsTypesMatch(itemType, slideType);
  };

  let syncInFlight = false;
  const requestStageSync = async () => {
    if (syncInFlight) return;
    syncInFlight = true;
    const btn = document.getElementById('stage-sync-now');
    const banner = document.getElementById('stage-sync-banner');
    btn?.classList.add('is-busy');
    banner?.classList.add('is-busy');
    try {
      bus.send(MessageTypes.HEARTBEAT, {
        ready: true,
        needState: true,
        role: 'stage',
        clientId,
        deviceLabel,
        reason: 'manual-resync',
      });
      bus.hub?.boostPolling?.();
      await bus.resyncFromServer?.();
      if (state.slide) applySlide(state.slide, { forceRender: true });
      else patchLiveBody();
      updateSyncBanner();
    } catch { /* ignore */ } finally {
      syncInFlight = false;
      btn?.classList.remove('is-busy');
      banner?.classList.remove('is-busy');
    }
  };

  const updateSyncBanner = () => {
    const banner = document.getElementById('stage-sync-banner');
    if (!banner) return;
    const outOfSync = isSlideOutOfSync();
    banner.hidden = !outOfSync;
    banner.classList.toggle('is-visible', outOfSync);
  };

  const nextLyricsItem = () => (state.nextItems || []).find((it) => it.slideType === 'lyrics');

  const renderContextHint = (slideType) => {
    const layout = getStageLayout();
    const next = nextLyricsItem();
    if (layout === 'musician' && slideType !== 'lyrics' && slideType !== 'lyrics-title') {
      const msg = next
        ? `Item atual: ${slideTypeLabel(slideType)}. Próximo louvor: “${next.title}”.`
        : `Item atual: ${slideTypeLabel(slideType)}. A cifra aparece no próximo louvor.`;
      return `<p class="stage-context-hint">${esc(msg)}</p>`;
    }
    if (layout === 'singer' && slideType !== 'lyrics' && slideType !== 'lyrics-title') {
      const msg = next
        ? `No louvor “${next.title}”, use Ao vivo para seguir o operador ou Letra completa.`
        : 'Use Ao vivo para acompanhar o operador estrofe a estrofe.';
      return `<p class="stage-context-hint">${esc(msg)}</p>`;
    }
    return '';
  };

  const patchEbdBar = () => {
    const bar = document.getElementById('stage-ebd-bar');
    if (!bar) return;
    if (!ebdCountdown?.expiresAt) {
      bar.hidden = true;
      setHtml(bar, '');
      bar.classList.remove('is-urgent', 'is-warn');
      return;
    }
    const ms = countdownRemainingMs(ebdCountdown.expiresAt);
    if (ms <= 0) {
      ebdCountdown = null;
      bar.hidden = true;
      setHtml(bar, '');
      bar.classList.remove('is-urgent', 'is-warn');
      return;
    }
    const cd = formatCountdownDigits(ms);
    const urgent = ms <= 60_000;
    const warn = !urgent && ms <= 180_000;
    bar.hidden = false;
    bar.classList.toggle('is-urgent', urgent);
    bar.classList.toggle('is-warn', warn);
    setHtml(bar, rawHtml(`
      <span class="stage-ebd-label">${esc(ebdCountdown.label || 'EBD')}</span>
      <span class="stage-ebd-time">${esc(cd.display)}</span>
      <span class="stage-ebd-hint">Só no Stage · projeção intacta</span>`));
  };

  const renderAlertBanner = () => {
    if (operatorCountdown?.expiresAt) {
      const ms = countdownRemainingMs(operatorCountdown.expiresAt);
      if (ms <= 0) {
        operatorCountdown = null;
      } else {
        const cd = formatCountdownDigits(ms);
        return `
          <div class="stage-alert stage-alert--countdown stage-alert--urgent" id="stage-alert-banner" role="status" aria-live="assertive">
            <span class="stage-alert-icon" data-kind="countdown" aria-hidden="true">Tempo</span>
            <div class="stage-alert-body">
              <span class="stage-alert-kicker">Cronômetro do operador</span>
              <strong>${esc(operatorCountdown.text || 'Tempo restante')}</strong>
              <span class="stage-alert-countdown" id="stage-op-countdown">${esc(cd.display)}</span>
            </div>
            <button type="button" class="su-btn su-btn--sm stage-alert-stop" data-stage-dismiss-alert>Parar</button>
          </div>`;
      }
    }
    if (operatorAlert) {
      const pri = operatorAlert.priority === 'urgent' ? 'urgent' : 'normal';
      const kindLabel = pri === 'urgent' ? 'Urgente' : 'Aviso';
      return `
        <div class="stage-alert stage-alert--${pri}" id="stage-alert-banner" role="status" aria-live="polite">
          <span class="stage-alert-icon" data-kind="${pri}" aria-hidden="true">${kindLabel}</span>
          <div class="stage-alert-body">
            <span class="stage-alert-kicker">Mensagem do Controle</span>
            <strong>${esc(operatorAlert.text)}</strong>
          </div>
          <button type="button" class="su-btn su-btn--sm stage-alert-stop" data-stage-dismiss-alert>Parar</button>
        </div>`;
    }
    return '';
  };

  const renderLiveLyricsBlock = (slide) => {
    const ctx = { prefs: { ...state.prefs, lyricsFx: state.lyricsFx || state.prefs?.lyricsFx } };
    return `
      <div class="stage-live-panel stage-live-lyrics" style="${scaledLyricsStyle(slide, state.prefs)}">
        ${renderLyricsLinesBlock(slide, ctx.prefs, { highlightStanza: true, skipEntrance: true })}
      </div>`;
  };

  const renderFullLyrics = (slide) => {
    const full = state.fullSongLyrics;
    if (!full?.lines?.length) {
      return `
        <div class="stage-live-lyrics-wrap">
          ${renderLiveLyricsBlock(slide)}
          <p class="stage-live-fallback-hint">Letra completa indisponível — mostrando ao vivo com o operador</p>
        </div>`;
    }
    const hiSet = globalHighlightIndices(full.lines, slide);
    const stanzas = full.stanzas?.length ? full.stanzas : [full.lines];
    return `
      <div class="stage-live-panel stage-live-full-lyrics stage-live-panel--align-start" style="${scaledLyricsStyle(slide)}">
        <p class="stage-full-song-meta">${esc(full.title || '')}${full.artist ? ` · ${esc(full.artist)}` : ''}</p>
        <p class="stage-full-live-hint">Estrofe ao vivo · ${slide.lines?.length || 0} linha(s) no projetor</p>
        <div class="stage-full-scroll">
          ${(() => {
            let cursor = 0;
            return stanzas.map((stanza, si) => {
              const stanzaLive = stanzaIsLive(stanza, full.lines, hiSet);
              return `
            <div class="stage-full-stanza ${stanzaLive ? 'is-current-stanza' : ''}" data-stanza="${si}">
              ${stanza.map((line) => {
                const t = normalizeLyricLine(line);
                let globalIdx = -1;
                for (let i = cursor; i < full.lines.length; i += 1) {
                  const n = normalizeLyricLine(full.lines[i]);
                  if (n && (n === t || n.includes(t) || t.includes(n))) {
                    globalIdx = i;
                    cursor = i + 1;
                    break;
                  }
                }
                const isCurrent = globalIdx >= 0 && hiSet.has(globalIdx);
                return `<p class="stage-full-line ${isCurrent ? 'is-current' : ''}" data-idx="${globalIdx}">${esc(line)}</p>`;
              }).join('')}
            </div>`;
            }).join('');
          })()}
        </div>
      </div>`;
  };

  const renderTeleprompterScript = () => {
    const blocks = state.sermonScript?.blocks || [];
    if (!blocks.length) {
      return `<div class="stage-live-panel stage-live-message"><p class="muted">Cadastre o script no inspector da Mensagem.</p></div>`;
    }
    return `
      <div class="stage-teleprompter" id="stage-teleprompter">
        ${blocks.map((b) => {
          const cls = [
            'stage-tp-block',
            b.pause === 'heavy' ? 'stage-tp-pause-heavy' : '',
            b.rhythm === 'slow' ? 'stage-tp-rhythm-slow' : '',
            b.rhythm === 'list' ? 'stage-tp-list' : '',
          ].filter(Boolean).join(' ');
          return `<p class="${cls}">${esc(b.text)}</p>`;
        }).join('')}
      </div>`;
  };

  const renderLiveBody = () => {
    /* Countdown do operador fica só no banner — conteúdo ao vivo permanece visível. */

    if (state.countdownActive && state.countdown) {
      const cd = formatCountdownDigits(state.countdown.targetMs - Date.now());
      return `
        <div class="stage-live-panel stage-live-panel--countdown">
          <p class="stage-countdown-label">${esc(state.countdown.label || 'O culto começa em')}</p>
          <p class="stage-countdown-time" id="stage-countdown-time">${esc(cd?.display || '--:--')}</p>
          <p class="stage-countdown-phase">${esc(state.countdown.phase === 'announce' ? 'Avisos finais' : 'Pré-culto no ar')}</p>
        </div>`;
    }
    if (state.overlay === 'blank') {
      return `<div class="stage-live-panel stage-live-panel--muted"><p class="stage-live-status">Tela em branco no projetor</p></div>`;
    }
    if (state.overlay === 'logo') {
      return `<div class="stage-live-panel stage-live-panel--muted"><p class="stage-live-status">Logo da igreja no projetor</p></div>`;
    }
    if (state.bibleReaderLive && state.readerProgress) {
      const rp = state.readerProgress;
      return `
        <div class="stage-live-panel stage-live-panel--reader">
          <p class="stage-live-kicker">Leitura bíblica · congregação</p>
          <h2 class="stage-reader-title">${esc(rp.chapterTitle || 'Capítulo')}</h2>
          <p class="stage-reader-range">${esc(rp.slideRange || '')}</p>
          <p class="stage-reader-progress">Parte ${(rp.index ?? 0) + 1} de ${rp.total || '?'}</p>
        </div>`;
    }

    const slide = state.slide;
    if (!slide) {
      return `<div class="stage-live-panel stage-live-panel--waiting"><p class="stage-live-status">Aguardando o Controle iniciar a projeção…</p></div>`;
    }

    const type = slide.type;
    const layout = getStageLayout();
    const itemSlideType = state.current?.slideType || state.slideType;
    if (type === 'lyrics' && slide.lines?.length) {
      if (itemSlideType && itemSlideType !== 'lyrics' && itemSlideType !== 'lyrics-title') {
        return `
          <div class="stage-live-panel stage-live-panel--waiting">
            <p class="stage-live-status">Sincronizando slide…</p>
            <p class="stage-live-hint">Aguardando atualização do Controle</p>
            <button type="button" class="stage-sync-btn stage-sync-btn--inline" data-stage-sync-now>Sincronizar agora</button>
          </div>`;
      }
      const chordSt = getChordViewState();
      if (layout === 'musician' && chordSt.mode) {
        if (state.chordChart?.source) {
          refreshMusicianSession(slide);
          return renderChordChartHtml(state.chordChart, {
            transpose: chordSt.transpose,
            capo: chordSt.capo ?? state.chordChart.capo ?? 0,
            slide,
            stableView: true,
            repeating: musicianRepeating,
          });
        }
        return `
          <div class="stage-live-panel stage-live-panel--muted">
            <p class="stage-live-status">Esta música ainda não tem cifra ChordPro</p>
            <p class="stage-live-hint">Abra Louvores → busque no Cifra Club ou cole a cifra manualmente.</p>
          </div>`;
      }
      if (lyricsViewMode === 'full') {
        return renderFullLyrics(slide);
      }
      return renderLiveLyricsBlock(slide);
    }
    if (type === 'lyrics-title') {
      return `
        <div class="stage-live-panel stage-live-title">
          <p class="stage-live-kicker">Louvor</p>
          <h2 class="stage-song-title">${esc(slide.title || '')}</h2>
          ${slide.artist ? `<p class="stage-song-artist">${esc(slide.artist)}</p>` : ''}
        </div>`;
    }
    if (type === 'bible-interlinear' && (slide.verses?.length || slide.focusWord || slide.focusWords?.length)) {
      return renderInterlinearSlideHtml(slide, {
        surface: 'stage',
        liveView: state?.interlinearView || null,
      });
    }
    if (type === 'bible-responsive' && slide.segments?.length) {
      const rows = slide.segments.map((seg) => `
        <p class="stage-bible-verse stage-bible-resp-${seg.role}"><span class="stage-resp-label">${seg.role === 'leader' ? 'Dir.' : 'Cong.'}</span> <sup>${seg.number}</sup> ${esc(seg.text)}</p>`).join('');
      return `
        <div class="stage-live-panel stage-live-bible stage-live-responsive">
          <p class="stage-bible-ref">${esc(slide.reference || '')}</p>
          ${rows}
        </div>`;
    }
    if (type === 'bible') {
      if (slide.referenceOnly || !slide.verses?.length) {
        const parts = slide.referenceParts;
        const stacked = (slide.refLayout || 'stacked') === 'stacked' && parts?.bookName;
        return `
          <div class="stage-live-panel stage-live-bible">
            <p class="stage-live-kicker">Leitura bíblica</p>
            ${stacked ? `
              <div class="stage-bible-ref-stack">
                <h2 class="stage-bible-ref-book">${esc(parts.bookName)}</h2>
                <p class="stage-bible-ref-cvs">${esc(parts.chapterVerse)}${parts.version ? ` (${esc(parts.version)})` : ''}</p>
              </div>` : `
              <h2 class="stage-bible-ref">${esc(slide.reference || '')}</h2>`}
          </div>`;
      }
      const verses = (slide.verses || [])
        .map((v) => {
          const rtl = v.dir === 'rtl' || v.lang === 'he';
          const attr = rtl ? ' dir="rtl" lang="he"' : (v.lang === 'grc' ? ' lang="grc"' : '');
          return `<p class="stage-bible-verse${rtl ? ' stage-bible-verse--rtl' : ''}"${attr}><sup>${v.number}</sup> ${esc(v.text)}</p>`;
        })
        .join('');
      return `
        <div class="stage-live-panel stage-live-bible">
          <p class="stage-bible-ref">${esc(slide.reference || '')}</p>
          <div class="stage-bible-verses">${verses}</div>
        </div>`;
    }
    if (type === 'message') {
      const hint = renderContextHint(type);
      if (teleprompterMode && state.sermonScript?.blocks?.length) {
        return `
          <div class="stage-live-panel stage-live-panel--teleprompter">
            ${renderTeleprompterScript()}
            ${hint}
          </div>`;
      }
      return `
        <div class="stage-live-panel stage-live-message-pro">
          <div class="stage-message-frame" aria-label="Slide de mensagem">
            ${renderMessage(slide)}
          </div>
          ${hint}
        </div>`;
    }
    if (type === 'welcome') {
      return `
        <div class="stage-live-panel stage-live-welcome">
          <p class="stage-live-kicker">Boas-vindas</p>
          <h2 class="stage-welcome-title">${esc(slide.years || slide.title || 'Bem-vindos')}</h2>
          ${slide.theme ? `<p class="stage-welcome-theme">${esc(slide.theme)}</p>` : ''}
          ${slide.subtitle ? `<p class="stage-welcome-sub">${esc(slide.subtitle)}</p>` : ''}
        </div>`;
    }
    if (type === 'announcements' && slide.items?.length) {
      return `
        <div class="stage-live-panel stage-live-list">
          <p class="stage-live-kicker">Comunicados</p>
          <ul>${slide.items.map((it) => `<li>${esc(it.text || it)}</li>`).join('')}</ul>
        </div>`;
    }
    if (type === 'section') {
      return `
        <div class="stage-live-panel stage-live-section">
          <h2 class="stage-section-title">${esc(slide.title || slide.label || 'Seção')}</h2>
          ${slide.subtitle ? `<p class="stage-section-sub">${esc(slide.subtitle)}</p>` : ''}
          ${slide.text ? `<p class="stage-section-text">${esc(slide.text)}</p>` : ''}
        </div>`;
    }
    if (type === 'prayer') {
      return `
        <div class="stage-live-panel stage-live-prayer">
          <p class="stage-live-kicker">Oração</p>
          <h2 class="stage-section-title">${esc(slide.title || 'Oração')}</h2>
          ${slide.text ? `<p class="stage-section-text">${esc(slide.text).replace(/\n/g, '<br>')}</p>` : ''}
        </div>`;
    }
    if (type === 'offering') {
      return `
        <div class="stage-live-panel stage-live-offering">
          <p class="stage-live-kicker">Oferta</p>
          <h2 class="stage-section-title">${esc(slide.title || 'Oferta e Dízimos')}</h2>
          ${slide.subtitle ? `<p class="stage-section-sub">${esc(slide.subtitle)}</p>` : ''}
          ${slide.verse ? `<p class="stage-section-text">${esc(slide.verse)}</p>` : ''}
        </div>`;
    }
    if (type === 'communion') {
      const phase = slide.phase || {};
      return `
        <div class="stage-live-panel stage-live-communion">
          <p class="stage-live-kicker">Santa Ceia${slide.totalPhases > 1 ? ` · ${(slide.phaseIndex ?? 0) + 1}/${slide.totalPhases}` : ''}</p>
          <h2 class="stage-section-title">${esc(phase.title || slide.title || 'Santa Ceia')}</h2>
          ${phase.subtitle ? `<p class="stage-section-sub">${esc(phase.subtitle)}</p>` : ''}
          ${phase.text ? `<p class="stage-section-text">${esc(phase.text)}</p>` : ''}
        </div>`;
    }
    if (type === 'participation') {
      return `
        <div class="stage-live-panel stage-live-participation">
          <p class="stage-live-kicker">Participação</p>
          <h2 class="stage-section-title">${esc(slide.name || slide.title || 'Participação')}</h2>
          ${slide.song || slide.music ? `<p class="stage-section-sub">${esc(slide.song || slide.music)}</p>` : ''}
          ${slide.text ? `<p class="stage-section-text">${esc(slide.text)}</p>` : ''}
        </div>`;
    }
    if (type === 'visitor-welcome') {
      return `
        <div class="stage-live-panel stage-live-welcome">
          <p class="stage-live-kicker">Visitantes</p>
          <h2 class="stage-welcome-title">${esc(slide.title || 'Bem-vindos')}</h2>
          ${slide.subtitle ? `<p class="stage-welcome-sub">${esc(slide.subtitle)}</p>` : ''}
          ${slide.message ? `<p class="stage-section-text">${esc(slide.message)}</p>` : ''}
        </div>`;
    }
    if (slide.title || slide.text) {
      return `
        <div class="stage-live-panel stage-live-text">
          ${slide.title ? `<h2>${esc(slide.title)}</h2>` : ''}
          ${slide.subtitle ? `<p class="stage-section-sub">${esc(slide.subtitle)}</p>` : ''}
          ${slide.text ? `<p>${esc(slide.text)}</p>` : ''}
        </div>`;
    }
    return `<div class="stage-live-panel stage-live-panel--muted"><p class="stage-live-status">${esc(slideTypeLabel(type))}</p></div>`;
  };

  const renderProgramRail = () => {
    const items = state.programItems || [];
    const activeIdx = items.findIndex((it) => it.active);
    if (!items.length) {
      return `<p class="stage-rail-empty">Programa vazio — aguardando controle</p>`;
    }
    const nextBlock = (state.nextItems || []).length ? `
      <div class="stage-rail-next">
        <h3 class="stage-rail-next-label">Próximo</h3>
        <ul>${state.nextItems.slice(0, 3).map((it) =>
          `<li><span class="stage-rail-next-type">${esc(it.slideTypeLabel || slideTypeLabel(it.slideType))}</span> ${esc(it.title)}</li>`
        ).join('')}</ul>
      </div>` : '';

    return `
      <ol class="stage-rail-list">
        ${items.map((it) => `
          <li class="stage-rail-item ${it.active ? 'is-active' : ''} ${it.index < activeIdx ? 'is-done' : ''}">
            <span class="stage-rail-num">${it.index + 1}</span>
            <div class="stage-rail-body">
              <span class="stage-rail-type">${esc(it.slideTypeLabel || slideTypeLabel(it.slideType))}</span>
              <span class="stage-rail-title">${esc(it.title)}</span>
              ${it.active && state.itemSlideCount > 1
                ? `<span class="stage-rail-part">parte ${(state.itemSlideIndex ?? 0) + 1}/${state.itemSlideCount}</span>`
                : it.slideCount > 1 ? `<span class="stage-rail-part">${it.slideCount} partes</span>` : ''}
            </div>
          </li>`).join('')}
      </ol>${nextBlock}`;
  };

  const bindShellEvents = () => {
    root.querySelector('#stage-lyrics-view')?.addEventListener('click', (e) => {
      const btn = e.target.closest('[data-lyrics-view]');
      if (!btn) return;
      setLyricsViewMode(btn.dataset.lyricsView);
      root.querySelectorAll('[data-lyrics-view]').forEach((el) => {
        el.classList.toggle('is-active', el.dataset.lyricsView === lyricsViewMode);
      });
      patchLiveBody();
    });

    root.querySelector('#stage-sync-now')?.addEventListener('click', () => { void requestStageSync(); });
    root.querySelector('[data-stage-sync-now]')?.addEventListener('click', () => { void requestStageSync(); });
    root.querySelector('#stage-sync-banner-btn')?.addEventListener('click', () => { void requestStageSync(); });

    root.querySelector('#stage-teleprompter-mode')?.addEventListener('click', () => {
      teleprompterMode = !teleprompterMode;
      try { localStorage.setItem(TELEPROMPTER_KEY, teleprompterMode ? '1' : '0'); } catch { /* ignore */ }
      root.querySelector('#stage-teleprompter-mode')?.classList.toggle('is-active', teleprompterMode);
      patchLiveBody();
    });

    root.querySelector('#stage-rail-toggle')?.addEventListener('click', () => {
      railExpanded = !railExpanded;
      root.querySelector('.stage-rail')?.classList.toggle('is-collapsed', !railExpanded);
      const btn = root.querySelector('#stage-rail-toggle');
      if (btn) btn.textContent = railExpanded ? 'Ocultar' : 'Mostrar';
    });

    const labelEl = root.querySelector('#stage-device-label');
    if (labelEl) {
      const renameDevice = async () => {
        const value = await new Promise((resolve) => {
          const overlay = document.createElement('div');
          overlay.className = 'su-dialog-overlay is-visible';
          setHtml(overlay, rawHtml(`
            <div class="su-dialog" role="dialog" aria-modal="true">
              <h3 class="su-dialog__title">Nome desta tela</h3>
              <p class="su-dialog__message">Ex.: Violão, Púlpito, Coral — aparece na Central Stage.</p>
              <input class="su-dialog__input" type="text" maxlength="40" value="${esc(deviceLabel || '')}" />
              <div class="su-dialog__actions">
                <button type="button" class="su-btn su-btn--secondary" data-cancel>Cancelar</button>
                <button type="button" class="su-btn su-btn--primary" data-ok>Salvar</button>
              </div>
            </div>`));
          const input = overlay.querySelector('.su-dialog__input');
          const close = (v) => { overlay.remove(); resolve(v); };
          overlay.querySelector('[data-cancel]').onclick = () => close(null);
          overlay.querySelector('[data-ok]').onclick = () => close(input.value);
          overlay.onclick = (e) => { if (e.target === overlay) close(null); };
          input.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') close(input.value);
            if (e.key === 'Escape') close(null);
          });
          document.body.appendChild(overlay);
          requestAnimationFrame(() => input.focus());
        });
        if (value !== null) {
          deviceLabel = setStageDeviceLabel(value);
          labelEl.textContent = deviceLabel || 'Stage';
        }
      };
      let pressTimer = null;
      labelEl.addEventListener('touchstart', () => {
        pressTimer = setTimeout(() => { renameDevice(); }, 600);
      }, { passive: true });
      labelEl.addEventListener('touchend', () => clearTimeout(pressTimer));
      labelEl.addEventListener('click', () => {
        if (window.innerWidth > 768) renameDevice();
      });
    }
  };

  // --- UI continuation (same scope as bootstrapMain) ---
  const notifyAutoScroll = () => {
    const container = resolveStageScrollContainer(root);
    const bpm = stagePro.getMetronomeBpm?.() || state.chordChart?.bpm || null;
    onStageSlideChange({ bpm, container, forceFollow: getAutoScrollState().mode === 'follow' });
  };

  const patchLiveBodyImpl = () => {
    const body = document.getElementById('stage-live-body');
    if (!body) return;
    setHtml(body, rawHtml(renderLiveBody()));
    body.querySelector('[data-stage-sync-now]')?.addEventListener('click', () => { void requestStageSync(); });
    if (!isMusicianChordView()) {
      scrollHighlightIntoView();
    }
    notifyAutoScroll();
    updateSyncBanner();
  };

  const patchMusicianLiveOnly = () => {
    if (!isMusicianChordView() || !state.slide) return false;
    refreshMusicianSession(state.slide);
    if (!patchMusicianLivePill(root, state.slide, { repeating: musicianRepeating })) {
      return false;
    }
    updateSyncBanner();
    return true;
  };
  const patchLiveBody = () => scheduleStagePatch('stage', patchLiveBodyImpl);

  const refreshChordBar = () => {
    wireStageChordControls(root, {
      hasChart: !!state.chordChart?.source,
      layout: getStageLayout(),
      onChange: () => {
        patchLiveBodyImpl();
        refreshChordBar();
      },
    });
  };

  const renderShell = () => {
    const cur = state.current;
    const online = controlOnline && Date.now() - lastControlHeartbeat < 12000;
    const itemTitle = state.itemTitle || cur?.itemTitle || 'Aguardando o Controle…';
    const typeLabel = state.slideTypeLabel || slideTypeLabel(state.slide?.type || cur?.slideType);
    const stageLayout = getStageLayout();
    const isLyricsSlide = state.slide?.type === 'lyrics' || state.slide?.type === 'lyrics-title';
    const showLyricsViewToggle = isLyricsSlide && state.slide?.type === 'lyrics' && stageLayout === 'singer';
    const showTeleprompterToggle = state.slide?.type === 'message' && state.sermonScript?.blocks?.length;
    const wide = window.innerWidth >= 900;
    document.body.dataset.stageLayout = stageLayout;
    const isPreacher = stageLayout === 'preacher';
    const nextItem = (state.nextItems || [])[0];
    const nextLabel = nextItem
      ? `${slideTypeLabel(nextItem.type || nextItem.slideType)} · ${nextItem.title || nextItem.itemTitle || 'Próximo'}`
      : '';

    setHtml(root, rawHtml(`
      <div class="stage-shell ${isPreacher ? 'stage-shell--preacher' : ''}" data-stage-profile="${esc(stageLayout)}">
        <header class="stage-header stage-card ${isPreacher ? 'stage-header--preacher' : ''}">
          <div class="stage-header-main">
            ${isPreacher
              ? `<span class="stage-kicker stage-kicker--preacher">Púlpito · <strong id="stage-layout-badge">${esc(stageLayoutLabel(stageLayout))}</strong></span>`
              : `<span class="stage-kicker">Púlpito · <span class="stage-badge-stage">STAGE</span> · <strong id="stage-layout-badge">${esc(stageLayoutLabel(stageLayout))}</strong></span>`}
            <span class="stage-church">${esc(state.churchName)}</span>
            ${!isPreacher && state.churchSubtitle ? `<span class="stage-church-sub">${esc(state.churchSubtitle)}</span>` : ''}
            ${state.cultoTitle ? `<span class="stage-culto">${esc(state.cultoTitle)}</span>` : ''}
            ${!isPreacher ? `<button type="button" class="stage-device-label" id="stage-device-label" title="Toque longo ou clique para renomear">${esc(deviceLabel || 'Stage')}</button>` : `<button type="button" class="stage-device-label" id="stage-device-label" hidden>${esc(deviceLabel || 'Stage')}</button>`}
          </div>
          <div class="stage-header-meta">
            <button type="button" class="stage-theme-btn" data-chrome-theme-toggle title="Alternar tema claro/escuro" aria-pressed="true" aria-label="Tema">
              <i class="fa-duotone fa-circle-half-stroke" aria-hidden="true"></i>
              <span data-chrome-label>Escuro</span>
            </button>
            ${state.rehearsal ? '<span class="stage-badge stage-badge--rehearsal">Ensaio</span>' : ''}
            ${state.countdownActive ? '<span class="stage-badge stage-badge--countdown">Pré-culto</span>' : ''}
            ${state.overlay ? `<span class="stage-badge stage-badge--overlay">${esc(state.overlay === 'blank' ? 'Tela preta' : 'Logo')}</span>` : ''}
            <span class="stage-status ${online ? 'is-online' : 'is-offline'}" id="stage-status" title="${online ? 'Sincronizado com o Controle' : 'Abra o Controle no PC'}">
              <span class="stage-status-dot"></span>
              <span class="stage-status-text">${online ? 'Com o Controle' : 'Sem Controle'}</span>
            </span>
            <time class="stage-clock ${wide || isPreacher ? 'stage-clock--wide' : ''} ${isPreacher ? 'stage-clock--preacher' : ''}" id="stage-clock">--:--</time>
          </div>
        </header>

        <div class="stage-ops" id="stage-ops">
          <div class="stage-sync-banner" id="stage-sync-banner" hidden aria-live="polite">
            <span class="stage-sync-banner-text">Conteúdo desatualizado em relação ao Controle</span>
            <button type="button" class="stage-sync-btn" id="stage-sync-banner-btn">Sincronizar agora</button>
          </div>
          <div class="stage-ebd-bar" id="stage-ebd-bar" hidden aria-live="polite"></div>
          <div class="stage-alert-slot" id="stage-alert-slot">${renderAlertBanner()}</div>
        </div>
        <div id="stage-pro-bar" ${isPreacher ? 'hidden' : ''}></div>

        <main class="stage-main ${isPreacher ? 'stage-main--preacher' : ''}">
          <section class="stage-live stage-card" aria-label="Conteúdo ao vivo">
            <div class="stage-live-head">
              <div class="stage-live-meta">
                <span class="stage-type-pill">${esc(typeLabel)}</span>
                <span class="stage-progress" id="stage-progress">${esc(formatProgress(state))}</span>
                ${showLyricsViewToggle ? `
                <div class="stage-lyrics-view" id="stage-lyrics-view" role="group" aria-label="Modo de letra">
                  <button type="button" class="stage-mode-btn ${lyricsViewMode === 'live' ? 'is-active' : ''}" data-lyrics-view="live" title="Segue o operador em tempo real">Ao vivo</button>
                  <button type="button" class="stage-mode-btn ${lyricsViewMode === 'full' ? 'is-active' : ''}" data-lyrics-view="full" title="Letra completa do louvor">Letra completa</button>
                </div>` : ''}
                ${showTeleprompterToggle ? `<button type="button" class="stage-mode-btn ${teleprompterMode ? 'is-active' : ''}" id="stage-teleprompter-mode" title="Roteiro da mensagem">Teleponto</button>` : ''}
              </div>
              <h1 class="stage-item-title" id="stage-item-title">${esc(itemTitle)}</h1>
              ${isPreacher && nextLabel ? `<p class="stage-next-item" id="stage-next-item"><span class="stage-next-label">Próximo</span> ${esc(nextLabel)}</p>` : ''}
              ${state.itemOperatorNote ? `<p class="stage-note stage-note--operator" id="stage-op-note"><span class="stage-note-label">Operador</span><span class="stage-note-text">${esc(state.itemOperatorNote)}</span></p>` : '<p class="stage-note stage-note--operator" id="stage-op-note" hidden><span class="stage-note-label">Operador</span><span class="stage-note-text"></span></p>'}
              ${state.note ? `<p class="stage-note" id="stage-note"><span class="stage-note-label">Nota</span><span class="stage-note-text">${esc(state.note)}</span></p>` : '<p class="stage-note" id="stage-note" hidden><span class="stage-note-label">Nota</span><span class="stage-note-text"></span></p>'}
            </div>
            <div id="stage-chord-bar" class="stage-chord-bar"></div>
            <div class="stage-live-body" id="stage-live-body">
              ${renderLiveBody()}
            </div>
          </section>

          <aside class="stage-rail stage-card ${isPreacher ? 'is-collapsed stage-rail--preacher' : (!railExpanded ? 'is-collapsed' : '')}" aria-label="Ordem do culto" ${isPreacher ? 'hidden' : ''} ${stageLayout === 'musician' ? 'data-stage-rail="musician"' : ''}>
            <div class="stage-rail-head">
              <h2>Ordem do culto</h2>
              <button type="button" class="stage-rail-toggle" id="stage-rail-toggle">${(isPreacher ? false : railExpanded) ? 'Ocultar' : 'Mostrar'}</button>
            </div>
            <div class="stage-rail-scroll" id="stage-rail-scroll">
              ${renderProgramRail()}
            </div>
          </aside>
        </main>

        <footer class="stage-foot ${isPreacher ? 'stage-foot--preacher' : ''}">
          <span class="stage-foot-hint" id="stage-foot-hint">${isPreacher ? 'Confidence monitor · comandado pelo Controle' : stageLayout === 'musician' ? 'Cifra + ordem · comandado pelo Controle' : 'Comandado pelo Controle · acompanhe a ordem do culto'}</span>
          <div class="stage-foot-actions">
            <button type="button" class="stage-sync-btn stage-sync-btn--ghost" id="stage-sync-now" title="Sincronizar com o Controle">${faIcon('refresh')} Sincronizar</button>
            <span id="stage-sync-dot" class="stage-sync-dot" title="Sincronização">●</span>
          </div>
        </footer>
      </div>`));
    shellBuilt = true;
    bindShellEvents();
    applyUiPrefs(getPrefs());
    bindChromeThemeToggle(root);
    teardownStagePro();
    teardownStagePro = mountStageProUi(root, stagePro, {
      onLayoutChange: (layout) => applyStageLayout(layout),
    });
    refreshChordBar();
    patchEbdBar();
    scrollActiveRailItem();
    scrollHighlightIntoView();
    notifyAutoScroll();
    updateSyncBanner();
  };

  const patchAlertBannerImpl = () => {
    const slot = document.getElementById('stage-alert-slot');
    if (slot) {
      setHtml(slot, rawHtml(renderAlertBanner()));
      slot.querySelector('[data-stage-dismiss-alert]')?.addEventListener('click', () => {
        operatorAlert = null;
        operatorCountdown = null;
        patchAlertBannerImpl();
        patchLiveBody();
      });
    }
  };
  const patchAlertBanner = () => scheduleStagePatch('stage', patchAlertBannerImpl);

  const patchLyricsHighlight = () => {
    if (lyricsViewMode === 'full' && state.fullSongLyrics?.lines?.length) {
      patchLiveBody();
      return;
    }
    const lines = root.querySelectorAll('.stage-live-lyrics .lyrics-line');
    if (!lines.length) {
      patchLiveBody();
      return;
    }
    lines.forEach((el) => {
      el.classList.add('is-highlight', 'is-stanza-live');
      el.classList.toggle('lyrics-line-pulse', true);
    });
    notifyAutoScroll();
  };

  const patchHeaderMetaImpl = () => {
    const progress = document.getElementById('stage-progress');
    const title = document.getElementById('stage-item-title');
    const note = document.getElementById('stage-note');
    const opNote = document.getElementById('stage-op-note');
    const badge = document.getElementById('stage-layout-badge');
    const cur = state.current;
    if (progress) progress.textContent = formatProgress(state);
    if (title) title.textContent = state.itemTitle || cur?.itemTitle || 'Aguardando o Controle…';
    if (badge) badge.textContent = stageLayoutLabel(getStageLayout());
    const setNoteEl = (el, text) => {
      if (!el) return;
      const textEl = el.querySelector('.stage-note-text') || el;
      if (text) {
        el.hidden = false;
        textEl.textContent = text;
      } else {
        el.hidden = true;
        textEl.textContent = '';
      }
    };
    setNoteEl(note, state.note || '');
    setNoteEl(opNote, state.itemOperatorNote || '');
    const rail = document.getElementById('stage-rail-scroll');
    if (rail) setHtml(rail, rawHtml(renderProgramRail()));
    scrollActiveRailItem();
    updateModeToggles();
    refreshChordBar();
    updateSyncBanner();
  };
  const patchHeaderMeta = () => scheduleStagePatch('stage-meta', patchHeaderMetaImpl);

  const scrollActiveRailItem = () => {
    requestAnimationFrame(() => {
      root.querySelector('.stage-rail-item.is-active')
        ?.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
    });
  };

  const applySlide = (slide, { forceRender = false } = {}) => {
    if (!slide) return;
    const prevKey = lastLyricsKey;
    const prevSongKey = musicianSongKey(state);
    state.slide = slide;
    const nextKey = lyricsKey(slide);
    const layout = getStageLayout();
    const chordSt = getChordViewState();
    const musicianStable = !forceRender
      && shouldStabilizeMusicianView({
        layout,
        chordMode: chordSt.mode,
        slide,
        chartSource: state.chordChart?.source,
      })
      && musicianSongKey(state) === prevSongKey
      && prevSongKey;

    refreshMusicianSession(slide);

    if (musicianStable && patchMusicianLiveOnly()) {
      lastLyricsKey = nextKey;
      patchHeaderMeta();
      return;
    }

    const highlightOnly = slide.type === 'lyrics'
      && layout === 'singer'
      && lyricsKey(slide) === prevKey
      && prevKey
      && !forceRender
      && lyricsViewMode !== 'full';
    lastLyricsKey = nextKey;
    if (highlightOnly) {
      patchLyricsHighlight();
    } else {
      patchLiveBody();
    }
  };

  const applyStageAlert = (payload = {}) => {
    if (!alertTargetsMe(payload.target, clientId, getStageLayout())) return;
    if (payload.kind === 'ebd-countdown') {
      if (payload.action === 'stop' || !payload.expiresAt) {
        ebdCountdown = null;
      } else {
        ebdCountdown = {
          label: payload.label || 'EBD',
          expiresAt: payload.expiresAt,
        };
      }
      patchEbdBar();
      return;
    }
    /* dismiss limpa avisos/cronômetro do operador — NÃO apaga EBD */
    if (payload.kind === 'dismiss' || payload.kind === 'dismiss-alerts') {
      operatorAlert = null;
      operatorCountdown = null;
      patchAlertBanner();
      patchLiveBody();
      return;
    }
    if (payload.kind === 'countdown' && payload.expiresAt) {
      operatorCountdown = { text: payload.text, expiresAt: payload.expiresAt, icon: payload.icon };
      operatorAlert = null;
      patchAlertBanner();
      return;
    }
    operatorAlert = {
      text: payload.text,
      priority: payload.priority,
      icon: payload.icon,
      expiresAt: payload.expiresAt,
    };
    if (payload.expiresAt && payload.expiresAt < Date.now()) return;
    patchAlertBanner();
  };

  const applyStageState = (payload = {}, { fromControl = true } = {}) => {
    if (fromControl) {
      controlOnline = true;
      lastControlHeartbeat = Date.now();
    }
    const prevFlat = state.flatIndex;
    const prevItemTitle = state.itemTitle;
    if (payload.delta) {
      const {
        chordChart, fullSongLyrics, sermonScript, programItems, nextItems, ...rest
      } = payload;
      state = {
        ...state,
        ...rest,
        ...(chordChart !== undefined ? { chordChart } : {}),
        ...(fullSongLyrics !== undefined ? { fullSongLyrics } : {}),
        ...(sermonScript !== undefined ? { sermonScript } : {}),
        ...(programItems !== undefined ? { programItems } : {}),
        ...(nextItems !== undefined ? { nextItems } : {}),
      };
    } else {
      state = { ...state, ...payload };
      if (payload.chordChart === null) state.chordChart = null;
      if (payload.fullSongLyrics === null) state.fullSongLyrics = null;
      if (payload.sermonScript === null) state.sermonScript = null;
    }
    if (payload.chordChart?.bpm && stagePro.setMetronomeBpm) {
      stagePro.setMetronomeBpm(payload.chordChart.bpm);
      const bpmInput = document.getElementById('stage-pro-bpm');
      if (bpmInput) bpmInput.value = String(payload.chordChart.bpm);
    }
    const layout = getStageLayout();
    if (payload.chordChart?.source && layout === 'musician') {
      patchLiveBody();
      refreshChordBar();
    }
    const itemChanged = (payload.flatIndex !== undefined && payload.flatIndex !== prevFlat)
      || (payload.itemTitle !== undefined && payload.itemTitle !== prevItemTitle)
      || payload.current !== undefined;
    if (itemChanged) {
      musicianSession.songKey = '';
      musicianSession.maxSlideIndex = -1;
      musicianSession.lastSlideIndex = -1;
    }
    if (payload.slide) {
      const force = payload.forceRender === true || itemChanged;
      applySlide(payload.slide, { forceRender: force });
    } else if (payload.interlinearView || itemChanged) {
      patchLiveBody();
    }
    if (payload.fullSongLyrics?.lines?.length && lyricsViewMode === 'full') {
      patchLiveBody();
    }
    if (!shellBuilt) renderShell();
    else {
      patchHeaderMeta();
      if (!payload.slide && !itemChanged) patchLiveBody();
      refreshChordBar();
      updateModeToggles();
    }
    document.getElementById('stage-sync-dot')?.classList.add('is-live');
    updateConnectionBadge();
    updateSyncBanner();
  };

  const updateModeToggles = () => {
    const lyricsView = root.querySelector('#stage-lyrics-view');
    if (lyricsView) {
      const show = state.slide?.type === 'lyrics';
      lyricsView.hidden = !show;
      lyricsView.querySelectorAll('[data-lyrics-view]').forEach((btn) => {
        btn.classList.toggle('is-active', btn.dataset.lyricsView === lyricsViewMode);
      });
    }
    const tpBtn = root.querySelector('#stage-teleprompter-mode');
    if (tpBtn) {
      const show = state.slide?.type === 'message' && !!state.sermonScript?.blocks?.length;
      tpBtn.hidden = !show;
      tpBtn.classList.toggle('is-active', teleprompterMode);
    }
  };

  const updateConnectionBadge = () => {
    const online = controlOnline && Date.now() - lastControlHeartbeat < 12000;
    const el = document.getElementById('stage-status');
    if (!el) return;
    el.classList.toggle('is-online', online);
    el.classList.toggle('is-offline', !online);
    const text = el.querySelector('.stage-status-text');
    if (text) text.textContent = online ? 'Com o Controle' : 'Sem Controle';
  };

  const updateClocks = () => {
    const wide = window.innerWidth >= 900;
    const el = document.getElementById('stage-clock');
    if (el) {
      el.textContent = new Date().toLocaleTimeString('pt-BR', wide
        ? { hour: '2-digit', minute: '2-digit', second: '2-digit' }
        : { hour: '2-digit', minute: '2-digit' });
    }
    if (state.countdownActive && state.countdown?.targetMs) {
      const elCd = document.getElementById('stage-countdown-time');
      if (elCd) elCd.textContent = formatCountdownDigits(state.countdown.targetMs - Date.now()).display;
    }
    if (operatorCountdown?.expiresAt) {
      const ms = countdownRemainingMs(operatorCountdown.expiresAt);
      if (ms <= 0) {
        operatorCountdown = null;
        patchAlertBanner();
      } else {
        const cd = formatCountdownDigits(ms);
        const elOp = document.getElementById('stage-op-countdown');
        if (elOp) elOp.textContent = cd.display;
      }
    }
    if (operatorAlert?.expiresAt && operatorAlert.expiresAt < Date.now()) {
      operatorAlert = null;
      patchAlertBanner();
    }
    patchEbdBar();
    updateConnectionBadge();
  };

  bus.on((msg) => {
    if (msg.type === MessageTypes.STAGE_STATE) {
      applyStageState(msg.payload || {}, { fromControl: msg.from === 'control' || !msg.from });
      return;
    }
    if (msg.type === MessageTypes.STAGE_LAYOUT) {
      const p = msg.payload || {};
      if (!alertTargetsMe(p.target, clientId, getStageLayout())) return;
      const layout = p.layout;
      if (layout && stagePro.setStageProLayout) {
        stagePro.setStageProLayout(layout);
        applyStageLayout(layout);
      }
      document.getElementById('stage-sync-dot')?.classList.add('is-live');
      return;
    }
    if (msg.type === MessageTypes.STAGE_ALERT) {
      applyStageAlert(msg.payload || {});
      document.getElementById('stage-sync-dot')?.classList.add('is-live');
      return;
    }
    if (msg.type === MessageTypes.SLIDE) {
      const payload = msg.payload || {};
      const slide = payload.slide ?? payload;
      const nav = payload.stageNav;
      let songChanged = false;
      if (nav && typeof nav === 'object') {
        const prevTitle = state.itemTitle || '';
        const prevSongId = state.current?.songId || '';
        if (nav.itemTitle) state.itemTitle = nav.itemTitle;
        state.flatIndex = nav.flatIndex ?? state.flatIndex;
        state.itemSlideCount = nav.itemSlideCount ?? state.itemSlideCount;
        state.itemSlideIndex = nav.slideIndex ?? state.itemSlideIndex;
        if (nav.slideTypeLabel) state.slideTypeLabel = nav.slideTypeLabel;
        state.current = {
          ...(state.current || {}),
          itemIndex: nav.itemIndex,
          slideIndex: nav.slideIndex,
          itemTitle: nav.itemTitle || state.itemTitle,
          flatIndex: nav.flatIndex,
          ...(nav.songId ? { songId: nav.songId } : {}),
        };
        if (Array.isArray(state.programItems) && Number.isInteger(nav.itemIndex)) {
          state.programItems = state.programItems.map((it, i) => ({
            ...it,
            active: i === nav.itemIndex,
            currentSlideInItem: i === nav.itemIndex ? (nav.slideIndex ?? 0) : null,
          }));
        }
        songChanged = !!(nav.itemTitle && nav.itemTitle !== prevTitle)
          || !!(nav.songId && nav.songId !== prevSongId);
        if (songChanged) {
          musicianSession.songKey = '';
          musicianSession.maxSlideIndex = -1;
          musicianSession.lastSlideIndex = -1;
        }
        patchHeaderMeta();
      } else if (slide?.type === 'lyrics-title' && slide.title
        && state.itemTitle && state.itemTitle !== slide.title) {
        // Rede de segurança: SLIDE sem stageNav — alinha cabeçalho ao título da música.
        state.itemTitle = slide.title;
        if (state.current) state.current = { ...state.current, itemTitle: slide.title };
        musicianSession.songKey = '';
        songChanged = true;
        patchHeaderMeta();
      }
      applySlide(slide, { forceRender: songChanged });
      if (msg.from === 'control') {
        controlOnline = true;
        lastControlHeartbeat = Date.now();
        updateConnectionBadge();
        bus.hub?.boostPolling?.();
      }
      document.getElementById('stage-sync-dot')?.classList.add('is-live');
      return;
    }
    if (msg.type === MessageTypes.FULL_STATE) {
      const p = msg.payload || {};
      if (msg.from === 'control' || !msg.from) {
        controlOnline = true;
        lastControlHeartbeat = Date.now();
        updateConnectionBadge();
      }
      if (p.slide) applySlide(p.slide, { forceRender: true });
      if (p.prefs) state.prefs = p.prefs;
      if (p.theme) applyTheme(p.theme);
      if (p.countdown && typeof p.countdown === 'object') {
        if (p.countdown.active) {
          state.countdownActive = true;
          state.countdown = p.countdown;
        } else {
          state.countdownActive = false;
          state.countdown = null;
        }
        patchLiveBody();
      }
      if (p.programState && Object.prototype.hasOwnProperty.call(p.programState, 'overlay')) {
        state.overlay = p.programState.overlay || null;
        patchLiveBody();
      }
      document.getElementById('stage-sync-dot')?.classList.add('is-live');
      return;
    }
    if (msg.type === MessageTypes.OVERLAY) {
      const type = msg.payload?.type;
      state.overlay = type === 'clear' ? null : (type || null);
      patchLiveBody();
      return;
    }
    if (msg.type === MessageTypes.OVERLAY_LAYER) {
      // Stage espelha presença de overlay de plugins (stamp/tips) só no badge — render visual fica no Screen
      if (msg.payload?.clear) {
        state.overlayLayer = null;
      } else if (msg.payload?.overlayId) {
        state.overlayLayer = msg.payload.overlayId;
      }
      patchLiveBody();
      return;
    }
    if (msg.type === MessageTypes.COUNTDOWN) {
      const action = msg.payload?.action;
      if (action === 'stop') {
        state.countdownActive = false;
        state.countdown = null;
      } else if (msg.payload?.state) {
        state.countdownActive = true;
        state.countdown = msg.payload.state;
      }
      patchLiveBody();
      return;
    }
    if (msg.type === MessageTypes.STAGE_NOTE) {
      state.note = msg.payload?.text || '';
      patchHeaderMeta();
      return;
    }
    if (msg.type === MessageTypes.HEARTBEAT && msg.from === 'control') {
      controlOnline = true;
      lastControlHeartbeat = Date.now();
      updateConnectionBadge();
      bus.hub?.boostPolling?.();
      bus.send(MessageTypes.HEARTBEAT, { pong: true, role: 'stage', clientId, deviceLabel });
    }
  });

  // Re-sync após listeners (mesmo race do Remote)
  const markStageFromServer = async () => {
    try {
      const st = await bus.resyncFromServer?.();
      if (st?.type === MessageTypes.FULL_STATE || st?.from === 'control') {
        controlOnline = true;
        lastControlHeartbeat = Date.now();
        updateConnectionBadge();
      }
    } catch { /* ignore */ }
  };
  markStageFromServer();
  setTimeout(markStageFromServer, 800);

  bus.send(MessageTypes.HEARTBEAT, { ready: true, needState: true, role: 'stage', clientId, deviceLabel });

  let syncTries = 0;
  TaskScheduler.register({
    id: TaskIds.STAGE_RESYNC,
    kind: 'interval',
    intervalMs: 500,
    priority: 5,
    coalesce: true,
    fn: () => {
      syncTries += 1;
      if (state.programItems?.length || syncTries > 20) {
        TaskScheduler.unregister(TaskIds.STAGE_RESYNC);
        return;
      }
      bus.send(MessageTypes.HEARTBEAT, {
        ready: true,
        needState: syncTries === 1,
        role: 'stage',
        clientId,
        deviceLabel,
      });
    },
  });

  applyProfileDefaults(getStageLayout());

  renderShell();

  requestAnimationFrame(() => {
    requestAnimationFrame(() => {
      try {
        if (typeof window.__somosumFinishBootSplash === 'function') {
          void window.__somosumFinishBootSplash();
        } else {
          document.getElementById('boot-loading')?.remove();
        }
      } catch { /* ignore */ }
    });
  });

  TaskScheduler.register({
    id: TaskIds.STAGE_CLOCK,
    kind: 'interval',
    intervalMs: 1000,
    priority: 6,
    runWhenHidden: true,
    fn: () => updateClocks(),
  });

  TaskScheduler.register({
    id: TaskIds.STAGE_HEARTBEAT,
    kind: 'interval',
    intervalMs: 5000,
    priority: 5,
    runWhenHidden: true,
    fn: () => {
      bus.send(MessageTypes.HEARTBEAT, { ping: true, role: 'stage', clientId, deviceLabel });
    },
  });

    window.addEventListener('resize', () => {
      if (window.innerWidth >= 768 && !railExpanded) {
        railExpanded = true;
        root.querySelector('.stage-rail')?.classList.remove('is-collapsed');
      }
    });

  try {
    const lockScreen = async () => { await navigator.wakeLock?.request('screen'); };
    lockScreen();
    document.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'visible') lockScreen();
    });
  } catch { /* ignore */ }

  ctx.root = root;
  ctx.bus = bus;
  ctx.state = state;
}

