import { fontFamilyCss, applyTextTransform, fontWeightStyleCssDecl } from '../../core/fonts.js';
import { esc } from '../../core/render-engine/index.js';
import {
  lyricsBackgroundHtml,
  lyricsOverlayHtml,
  normalizeLyricsFx,
  renderLyricsAmbientLayer,
} from './registry-background.js';
import { applySlideLegibilityVars } from './shared.js';

function lyricsFxClasses(slide, baseClass, prefs = null) {
  const fx = normalizeLyricsFx(slide, prefs);
  const hasAmbient = fx.ambient && fx.ambient !== 'none';
  const hasLineFx = fx.lineEntrance === 'stagger' || fx.highlightPulse !== false;
  return `${baseClass}${hasAmbient || hasLineFx ? ' has-lyrics-fx' : ''}`;
}

function renderLyricsLinesInner(slide, prefs = null, options = {}) {
  const style = slide.style || {};
  const tt = style.textTransform || 'none';
  const fx = normalizeLyricsFx(slide, prefs);
  const useEntrance = !options.skipEntrance && fx.lineEntrance === 'stagger';
  const highlightStanza = options.highlightStanza === true;
  return (slide.lines || [])
    .map((line, i) => {
      const isHi = highlightStanza || slide.highlightIndex === i;
      const cls = [
        'lyrics-line',
        isHi ? 'is-highlight' : '',
        highlightStanza ? 'is-stanza-live' : '',
        useEntrance ? 'lyrics-line-enter' : '',
        isHi && fx.highlightPulse !== false ? 'lyrics-line-pulse' : '',
      ].filter(Boolean).join(' ');
      const delay = useEntrance ? ` style="animation-delay:${Math.min(i * 0.08, 0.48)}s"` : '';
      return `<p class="${cls}"${delay}>${esc(applyTextTransform(line, tt))}</p>`;
    })
    .join('') || '<p class="lyrics-placeholder">Letra não cadastrada — vincule na biblioteca</p>';
}

export function renderLyricsLinesBlock(slide, prefs = null, options = {}) {
  return `<div class="lyrics-lines">${renderLyricsLinesInner(slide, prefs, options)}</div>`;
}

function lyricsStyleVars(style = {}) {
  const ff = fontFamilyCss(style.fontFamily);
  const tt = style.textTransform || 'none';
  const titleColor = style.titleColor ? `--lyrics-title-color: ${style.titleColor};` : '';
  const textColor = style.textColor ? `--lyrics-text-color: ${style.textColor};` : '';
  const dim = Number(style.bgDim);
  const dimVal = Number.isFinite(dim) ? Math.max(0, Math.min(0.75, dim)) : 0;
  const effect = ['shadow', 'outline', 'plate', 'none'].includes(style.textEffect)
    ? style.textEffect
    : 'outline';
  return `
    --lyrics-font-size: ${style.fontSize || 54}px;
    --lyrics-line-height: ${style.lineHeight || 1.5};
    --lyrics-align: ${style.align || 'center'};
    --lyrics-mt: ${style.marginTop ?? 10}%;
    --lyrics-mb: ${style.marginBottom ?? 10}%;
    --lyrics-ml: ${style.marginLeft ?? 6}%;
    --lyrics-mr: ${style.marginRight ?? 6}%;
    --lyrics-font-family: ${ff};
    --lyrics-text-transform: ${tt};
    --slide-bg-dim: ${dimVal};
    --slide-text-effect: ${effect};
    ${fontWeightStyleCssDecl(style).replace(/--font-/g, '--lyrics-font-')}
    ${titleColor}
    ${textColor}`;
}

export function applyLyricsStyleVars(el, style = {}) {
  if (!el) return;
  const ff = fontFamilyCss(style.fontFamily);
  const tt = style.textTransform || 'none';
  el.style.setProperty('--lyrics-font-size', `${style.fontSize || 54}px`);
  el.style.setProperty('--lyrics-line-height', String(style.lineHeight || 1.5));
  el.style.setProperty('--lyrics-align', style.align || 'center');
  el.style.setProperty('--lyrics-mt', `${style.marginTop ?? 10}%`);
  el.style.setProperty('--lyrics-mb', `${style.marginBottom ?? 10}%`);
  el.style.setProperty('--lyrics-ml', `${style.marginLeft ?? 6}%`);
  el.style.setProperty('--lyrics-mr', `${style.marginRight ?? 6}%`);
  el.style.setProperty('--lyrics-font-family', ff);
  el.style.setProperty('--lyrics-text-transform', tt);
  const { fontWeight, fontStyle } = style;
  if (fontWeight != null) el.style.setProperty('--lyrics-font-weight', String(fontWeight));
  if (fontStyle) el.style.setProperty('--lyrics-font-style', fontStyle);
  if (style.titleColor) el.style.setProperty('--lyrics-title-color', style.titleColor);
  if (style.textColor) el.style.setProperty('--lyrics-text-color', style.textColor);
  if (style.align === 'left' || style.align === 'right' || style.align === 'center') {
    el.style.setProperty('text-align', style.align);
  }
  applySlideLegibilityVars(el, style);
}

export function lyricsStyleFingerprint(slide) {
  if (!slide) return '';
  const st = slide.style || {};
  const fx = slide.lyricsFx || {};
  return [
    st.fontSize ?? '',
    st.fontFamily ?? '',
    st.fontWeight ?? '',
    st.fontStyle ?? '',
    st.textTransform ?? '',
    st.align ?? '',
    st.titleColor ?? '',
    st.textColor ?? '',
    st.textEffect ?? '',
    st.bgDim ?? '',
    st.vAlign ?? '',
    st.linesPerSlide ?? '',
    st.splitMode ?? '',
    st.marginTop ?? '',
    st.marginBottom ?? '',
    st.marginLeft ?? '',
    st.marginRight ?? '',
    st.lineHeight ?? '',
    st.backgroundPreset ?? '',
    st.transition ?? slide.transition ?? '',
    fx.lineEntrance ?? '',
    fx.highlightPulse ? '1' : '0',
    fx.ambient ?? '',
  ].join('|');
}

export function renderLyricsTitle(slide, options = {}, context = {}) {
  const style = slide.style || {};
  const tt = style.textTransform || 'none';
  const prefs = context.prefs || null;
  const fx = normalizeLyricsFx(slide, prefs);
  const titleClass = fx.lineEntrance === 'stagger' ? 'lyrics-main-title lyrics-title-enter' : 'lyrics-main-title';
  const persistBg = options.persistBackground;
  const effect = ['shadow', 'outline', 'plate', 'none'].includes(style.textEffect) ? style.textEffect : 'outline';
  return `
    <div class="${lyricsFxClasses(slide, 'slide slide-lyrics-title', prefs)}${persistBg ? ' slide-lyrics--bg-persist' : ''}" data-type="lyrics-title" data-text-effect="${effect}" style="${lyricsStyleVars(style)}">
      ${persistBg ? '' : `${lyricsBackgroundHtml(slide)}${renderLyricsAmbientLayer(slide, prefs)}${lyricsOverlayHtml()}`}
      <div class="slide-content lyrics-title-content${fx.lineEntrance === 'stagger' ? '' : ' anim-fade-up'}">
        <p class="lyrics-title-label">Louvor</p>
        <h1 class="${titleClass}">${esc(applyTextTransform(slide.title, tt))}</h1>
        ${slide.artist ? `<p class="lyrics-artist-name">${esc(applyTextTransform(slide.artist, tt))}</p>` : ''}
      </div>
    </div>`;
}

export function renderLyrics(slide, options = {}, context = {}) {
  const style = slide.style || {};
  const prefs = context.prefs || null;
  const persistBg = options.persistBackground;
  const effect = ['shadow', 'outline', 'plate', 'none'].includes(style.textEffect) ? style.textEffect : 'outline';
  return `
    <div class="${lyricsFxClasses(slide, 'slide slide-lyrics', prefs)}${persistBg ? ' slide-lyrics--bg-persist' : ''}" data-type="lyrics" data-text-effect="${effect}" style="${lyricsStyleVars(style)}">
      ${persistBg ? '' : `${lyricsBackgroundHtml(slide)}${renderLyricsAmbientLayer(slide, prefs)}${lyricsOverlayHtml()}`}
      <div class="slide-content lyrics-body">
        ${renderLyricsLinesBlock(slide, prefs)}
      </div>
    </div>`;
}
