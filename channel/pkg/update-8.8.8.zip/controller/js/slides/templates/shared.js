import { fontFamilyCss, fontWeightStyleCssDecl } from '../../core/fonts.js';

let _renderOpts = {};

export function getRenderOpts() {
  return _renderOpts;
}

export function setRenderOpts(opts) {
  _renderOpts = opts || {};
}

export function templateDesignDims(slide = null) {
  const w = Number(slide?.designer?.width) || Number(slide?.designWidth);
  const h = Number(slide?.designer?.height) || Number(slide?.designHeight);
  if (w > 0 && h > 0) return { w, h };
  return { w: 1920, h: 1080 };
}

export function url(context, key, fallback) {
  return context.assets?.[key] || fallback;
}

export function defaultSlideGradientPreset(slide) {
  const type = slide?.type || '';
  if (type === 'prayer' || type === 'bible' || type === 'bible-responsive' || type === 'bible-reader') return 'dark';
  if (type === 'communion') return 'communion';
  if (slide?.style?.backgroundPreset) return slide.style.backgroundPreset;
  return 'theme';
}

export function gradientClassForPreset(preset) {
  if (preset === 'dark') return 'gradient-dark';
  if (preset === 'gold') return 'gradient-gold';
  if (preset === 'communion') return 'gradient-communion';
  if (preset === 'bible') return 'gradient-bible';
  return 'gradient-theme';
}

function slideAlignLayoutVars(align = 'center') {
  const a = align === 'left' || align === 'right' ? align : 'center';
  const justify = a === 'left' ? 'flex-start' : a === 'right' ? 'flex-end' : 'center';
  const mis = a === 'left' ? '0' : a === 'right' ? 'auto' : 'auto';
  const mie = a === 'left' ? 'auto' : a === 'right' ? '0' : 'auto';
  return {
    align: a,
    justify,
    mis,
    mie,
  };
}

function slideVAlignItems(vAlign = 'center') {
  if (vAlign === 'top') return 'flex-start';
  if (vAlign === 'bottom') return 'flex-end';
  return 'center';
}

function normalizeBgDim(style = {}) {
  const dim = Number(style.bgDim);
  return Number.isFinite(dim) ? Math.max(0, Math.min(0.75, dim)) : 0;
}

function normalizeTextEffect(style = {}) {
  const effect = style.textEffect || 'outline';
  return ['shadow', 'outline', 'plate', 'none'].includes(effect) ? effect : 'outline';
}

/** Escurecer fundo + efeito de texto — no slide e no layer persistido de vídeo. */
export function applySlideLegibilityVars(el, style = {}) {
  if (!el) return;
  const dim = normalizeBgDim(style);
  const effect = normalizeTextEffect(style);
  el.dataset.textEffect = effect;
  el.style.setProperty('--slide-bg-dim', String(dim));
  el.style.setProperty('--slide-text-effect', effect);
  const host = el.closest?.('.screen-viewport, .preview-inner, .screen-canvas, .preview-scaler')
    || el.parentElement;
  const persist = host?.querySelector?.('#lyrics-bg-persist, .lyrics-bg-persist');
  if (persist) {
    persist.style.setProperty('--slide-bg-dim', String(dim));
  }
  const viewport = el.closest?.('.screen-viewport') || host;
  if (viewport?.style) {
    viewport.style.setProperty('--slide-bg-dim', String(dim));
  }
}

function legibilityStyleDecls(style = {}) {
  const dim = normalizeBgDim(style);
  const effect = normalizeTextEffect(style);
  return `--slide-bg-dim: ${dim}; --slide-text-effect: ${effect};`;
}

export function slideStyleVars(style = {}) {
  const ff = fontFamilyCss(style.fontFamily);
  const tt = style.textTransform || 'none';
  const layout = slideAlignLayoutVars(style.align || 'center');
  const titleColor = style.titleColor ? `--slide-title-color: ${style.titleColor};` : '';
  const textColor = style.textColor ? `--slide-text-color: ${style.textColor};` : '';
  const refColor = style.refColor ? `--slide-ref-color: ${style.refColor};` : '';
  const refSize = style.refSize
    ? `--slide-ref-size: ${style.refSize}px;`
    : '';
  const nameSize = style.nameSize ?? style.titleSize;
  const nameDecl = nameSize ? `--part-name-size: ${nameSize}px;` : '';
  return `
    --slide-font-family: ${ff};
    ${fontWeightStyleCssDecl(style).replace(/--font-/g, '--slide-font-')}
    --slide-title-size: ${style.titleSize || 76}px;
    --slide-text-size: ${style.textSize || 32}px;
    --slide-text-transform: ${tt};
    --slide-align: ${layout.align};
    --slide-justify: ${layout.justify};
    --slide-align-items: ${slideVAlignItems(style.vAlign || 'center')};
    --slide-margin-inline-start: ${layout.mis};
    --slide-margin-inline-end: ${layout.mie};
    ${legibilityStyleDecls(style)}
    ${refSize}
    ${nameDecl}
    ${titleColor}
    ${textColor}
    ${refColor}`;
}

/** Aplica tokens do inspetor no DOM já montado (bíblia, oração, seção, etc.). */
export function applySlideStyleVars(el, style = {}) {
  if (!el || !style) return;
  const ff = fontFamilyCss(style.fontFamily);
  const tt = style.textTransform || 'none';
  const layout = slideAlignLayoutVars(style.align || 'center');
  el.style.setProperty('--slide-font-family', ff);
  el.style.setProperty('--slide-title-size', `${style.titleSize || 76}px`);
  el.style.setProperty('--slide-text-size', `${style.textSize || 32}px`);
  el.style.setProperty('--slide-text-transform', tt);
  el.style.setProperty('--slide-align', layout.align);
  el.style.setProperty('--slide-justify', layout.justify);
  el.style.setProperty('--slide-align-items', slideVAlignItems(style.vAlign || 'center'));
  el.style.setProperty('--slide-margin-inline-start', layout.mis);
  el.style.setProperty('--slide-margin-inline-end', layout.mie);
  if (style.refSize != null && style.refSize !== '') {
    el.style.setProperty('--slide-ref-size', `${style.refSize}px`);
  }
  if (style.fontWeight != null && style.fontWeight !== '') {
    el.style.setProperty('--slide-font-weight', String(Number(style.fontWeight) || 400));
  } else {
    el.style.removeProperty('--slide-font-weight');
  }
  if (style.fontStyle) {
    el.style.setProperty('--slide-font-style', style.fontStyle);
  } else {
    el.style.removeProperty('--slide-font-style');
  }
  if (style.titleColor) el.style.setProperty('--slide-title-color', style.titleColor);
  if (style.textColor) el.style.setProperty('--slide-text-color', style.textColor);
  if (style.refColor) el.style.setProperty('--slide-ref-color', style.refColor);
  const nameSize = style.nameSize ?? style.titleSize;
  if (nameSize != null && nameSize !== '') {
    el.style.setProperty('--part-name-size', `${nameSize}px`);
  }
  applySlideLegibilityVars(el, style);
  // Alinhamento horizontal direto no bloco (alguns templates usam text-align do elemento)
  if (layout.align === 'left' || layout.align === 'right' || layout.align === 'center') {
    el.style.setProperty('text-align', layout.align);
  }
}

function messageStyleTokens(style = {}) {
  const ff = fontFamilyCss(style.fontFamily);
  const tt = style.textTransform || 'none';
  const refSize = style.refSize ?? style.textSize ?? 34;
  const mottoSize = style.mottoSize ?? style.textSize ?? 30;
  const preacherSize = style.preacherSize ?? 32;
  const fromSize = style.fromSize ?? 22;
  const photoSize = style.photoSize ?? 200;
  const cardPct = style.cardWidth ?? 36;
  const cardPx = Math.round(templateDesignDims().w * cardPct / 100);
  const layout = slideAlignLayoutVars(style.align || 'left');
  return {
    themeSize: style.fontSize || 80,
    refSize,
    textSize: style.textSize || 30,
    mottoSize,
    preacherSize,
    fromSize,
    photoSize,
    cardPx,
    contentWidth: style.contentWidth ?? 94,
    fontFamily: ff,
    textTransform: tt,
    textAlign: layout.align,
    justify: layout.justify,
    mis: layout.mis,
    mie: layout.mie,
    titleColor: style.titleColor || '',
    refColor: style.refColor || '',
    weightDecl: fontWeightStyleCssDecl(style).replace(/--font-/g, '--msg-font-'),
  };
}

export function messageStyleVars(style = {}) {
  const t = messageStyleTokens(style);
  const titleColor = t.titleColor ? `--msg-theme-color: ${t.titleColor};` : '';
  const refColor = t.refColor ? `--msg-ref-color-override: ${t.refColor};` : '';
  const textColor = style.textColor ? `--msg-text-color: ${style.textColor};` : '';
  return `
    --msg-theme-size: ${t.themeSize}px;
    --msg-ref-size: ${t.refSize}px;
    --msg-text-size: ${t.textSize}px;
    --msg-motto-size: ${t.mottoSize}px;
    --msg-preacher-size: ${t.preacherSize}px;
    --msg-from-size: ${t.fromSize}px;
    --msg-photo-size: ${t.photoSize}px;
    --msg-card-width: ${t.cardPx}px;
    --msg-content-width: ${t.contentWidth}%;
    --msg-font-family: ${t.fontFamily};
    ${t.weightDecl}
    --msg-text-transform: ${t.textTransform};
    --msg-text-align: ${t.textAlign};
    --slide-justify: ${t.justify};
    --slide-margin-inline-start: ${t.mis};
    --slide-margin-inline-end: ${t.mie};
    ${legibilityStyleDecls(style)}
    ${titleColor}
    ${refColor}
    ${textColor}`;
}

/** Aplica tokens do inspetor no DOM já montado (projeção / prévia). */
export function applyMessageStyleVars(el, style = {}) {
  if (!el) return;
  const t = messageStyleTokens(style);
  el.style.setProperty('--msg-theme-size', `${t.themeSize}px`);
  el.style.setProperty('--msg-ref-size', `${t.refSize}px`);
  el.style.setProperty('--msg-text-size', `${t.textSize}px`);
  el.style.setProperty('--msg-motto-size', `${t.mottoSize}px`);
  el.style.setProperty('--msg-preacher-size', `${t.preacherSize}px`);
  el.style.setProperty('--msg-from-size', `${t.fromSize}px`);
  el.style.setProperty('--msg-photo-size', `${t.photoSize}px`);
  el.style.setProperty('--msg-card-width', `${t.cardPx}px`);
  el.style.setProperty('--msg-content-width', `${t.contentWidth}%`);
  el.style.setProperty('--msg-font-family', t.fontFamily);
  el.style.setProperty('--msg-text-transform', t.textTransform);
  el.style.setProperty('--msg-text-align', t.textAlign);
  el.style.setProperty('--slide-justify', t.justify);
  el.style.setProperty('--slide-margin-inline-start', t.mis);
  el.style.setProperty('--slide-margin-inline-end', t.mie);
  if (style.fontWeight != null && style.fontWeight !== '') {
    el.style.setProperty('--msg-font-weight', String(Number(style.fontWeight) || 400));
  } else {
    el.style.removeProperty('--msg-font-weight');
  }
  if (style.fontStyle) {
    el.style.setProperty('--msg-font-style', style.fontStyle);
  } else {
    el.style.removeProperty('--msg-font-style');
  }
  if (t.titleColor) el.style.setProperty('--msg-theme-color', t.titleColor);
  if (t.refColor) el.style.setProperty('--msg-ref-color-override', t.refColor);
  if (style.textColor) el.style.setProperty('--msg-text-color', style.textColor);
  applySlideLegibilityVars(el, style);
}

export function slidePersistClass(extra = '') {
  return getRenderOpts().persistBackground ? ` slide--bg-persist${extra ? ` ${extra}` : ''}` : (extra ? ` ${extra}` : '');
}

/** Atributo data-text-effect para CSS de contorno/placa no HTML inicial. */
export function slideTextEffectAttr(style = {}) {
  const effect = normalizeTextEffect(style);
  return ` data-text-effect="${effect}"`;
}
