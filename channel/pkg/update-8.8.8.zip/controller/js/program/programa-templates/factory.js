﻿import { generateId } from '../../core/store.js';
import { createCommunionItem } from '../../data/communion-defaults.js';
import {
  welcomeItem,
  introitoItem,
  themeSomosUmItem,
  prayerItem,
  sectionItem,
  lyricsItem,
  bibleReadingItem,
  bibleResponsiveItem,
  messageItem,
  announcementsItem,
} from './items.js';

function participationItem(data = {}) {
  const kind = data.participationKind || 'musical';
  const labels = {
    musical: 'Participação Musical',
    poesia: 'Participação Poesia',
    testemunho: 'Testemunho',
    outro: data.participationLabel || 'Participação',
  };
  const participationLabel = data.participationLabel || labels[kind] || 'Participação';
  const participantName = data.participantName || '';
  const title = data.title
    || (participantName ? `${participationLabel} — ${participantName}` : participationLabel);
  return {
    id: generateId(),
    type: 'participation',
    title,
    slideType: 'participation',
    songId: data.songId || null,
    data: {
      participationKind: kind,
      participationLabel,
      participantName,
      songId: data.songId || null,
      songTitle: data.songTitle || '',
      extraText: data.extraText || '',
    },
  };
}

export const PARTICIPATION_KINDS = [
  { id: 'musical', label: 'Participação Musical' },
  { id: 'poesia', label: 'Participação Poesia' },
  { id: 'testemunho', label: 'Testemunho' },
  { id: 'outro', label: 'Outro (personalizar)' },
];

export const SLIDE_TYPE_OPTIONS = [
  { type: 'welcome', label: 'Boas-Vindas', icon: 'hand-wave' },
  { type: 'bible-intro', label: 'Introito bíblico', icon: 'book-open' },
  { type: 'prayer', label: 'Oração', icon: 'hands-praying' },
  { type: 'section', label: 'Seção / Momento', icon: 'bookmark' },
  { type: 'participation', label: 'Participação', icon: 'microphone' },
  { type: 'lyrics', label: 'Louvor', icon: 'music' },
  { type: 'bible', label: 'Leitura bíblica', icon: 'book-bible' },
  { type: 'bible-interlinear', label: 'Estudo interlinear', icon: 'language' },
  { type: 'bible-responsive', label: 'Leitura responsiva', icon: 'people-arrows' },
  { type: 'message', label: 'Mensagem', icon: 'bullhorn' },
  { type: 'communion', label: 'Ceia do Senhor', icon: 'wine-glass' },
  { type: 'announcements', label: 'Comunicados', icon: 'bullhorn' },
  { type: 'theme', label: 'Tema / Divisa', icon: 'sparkles' },
  { type: 'media', label: 'Imagem / Vídeo', icon: 'photo-film' },
  { type: 'media-audio', label: 'Áudio no programa', icon: 'volume' },
  { type: 'deck', label: 'Apresentação (PPTX)', icon: 'presentation-screen' },
  { type: 'offering', label: 'Oferta / Dízimo', icon: 'hand-holding-heart' },
  { type: 'countdown', label: 'Contagem / Pausa', icon: 'hourglass-half' },
  { type: 'custom', label: 'Slide livre', icon: 'shapes' },
];

export function createProgramItem(type, wizardData = {}) {
  switch (type) {
    case 'welcome':
      return welcomeItem({
        title: wizardData.title,
        subtitle: wizardData.subtitle,
        theme: wizardData.theme,
        years: wizardData.years,
        badge: wizardData.badge,
        dateLine: wizardData.dateLine,
        extraLine: wizardData.extraLine,
        layout: wizardData.layout,
        animation: wizardData.animation,
        welcomePreset: wizardData.welcomePreset || wizardData.preset || 'domingo',
        showLogo: wizardData.showLogo,
        showChurchName: wizardData.showChurchName,
        showBadge: wizardData.showBadge,
        showTheme: wizardData.showTheme,
        showExtra: wizardData.showExtra,
        logoPosition: wizardData.logoPosition,
        bgMediaId: wizardData.bgMediaId || '',
        bgMedia: wizardData.bgMedia || '',
        bgKind: wizardData.bgKind || 'image',
      });
    case 'bible-intro':
      if (wizardData.bible) {
        return {
          id: generateId(),
          type: 'bible',
          title: wizardData.title || 'Introito Bíblico',
          slideType: 'bible',
          data: { role: 'introito' },
          bible: {
            displayMode: 'excerpt',
            showText: true,
            referenceOverride: '',
            ...wizardData.bible,
          },
        };
      }
      return introitoItem();
    case 'prayer':
      return prayerItem(wizardData.title || 'Oração');
    case 'section':
      return sectionItem(wizardData.title || 'Momento');
    case 'participation':
      return participationItem(wizardData);
    case 'lyrics': {
      const item = lyricsItem(wizardData.title || 'Louvor', 'Selecione ou cadastre a música');
      if (wizardData.songId) item.songId = wizardData.songId;
      // Biblioteca manda na divisão/tipografia — sem override no item
      if (item.data) {
        delete item.data.lyricsStyle;
        delete item.data.lyricsFx;
      }
      return item;
    }
    case 'bible': {
      const item = bibleReadingItem();
      if (wizardData.title) item.title = wizardData.title;
      if (wizardData.bible) item.bible = { ...item.bible, ...wizardData.bible };
      return item;
    }
    case 'bible-interlinear': {
      const item = bibleReadingItem();
      item.title = wizardData.title || 'Estudo Interlinear';
      item.bible = {
        ...(item.bible || {}),
        ...(wizardData.bible || {}),
        displayMode: 'interlinear',
        showText: true,
        originalLang: wizardData.bible?.originalLang || 'he',
        interlinear: wizardData.bible?.interlinear || {
          layout: 'study',
          chunkMode: 'verse',
          show: { original: true, gloss: true, translation: true },
        },
      };
      return item;
    }
    case 'bible-responsive': {
      const item = bibleResponsiveItem();
      if (wizardData.title) item.title = wizardData.title;
      if (wizardData.bible) item.bible = { ...item.bible, ...wizardData.bible };
      return item;
    }
    case 'message':
      return messageItem(wizardData);
    case 'communion': {
      const item = createCommunionItem(wizardData.title || 'Ceia do Senhor');
      if (wizardData.showElements !== undefined) item.data.showElements = wizardData.showElements;
      if (wizardData.useCommunionTheme !== undefined) item.data.useCommunionTheme = wizardData.useCommunionTheme;
      return item;
    }
    case 'announcements': {
      const item = announcementsItem();
      if (wizardData.title) {
        item.title = wizardData.title;
        item.data.title = wizardData.title;
      }
      if (wizardData.items?.length) item.data.items = wizardData.items;
      return item;
    }
    case 'theme': {
      const item = themeSomosUmItem();
      if (wizardData.title) item.title = wizardData.title;
      item.data = {
        ...item.data,
        theme: wizardData.theme ?? item.data.theme,
        motto: wizardData.motto ?? item.data.motto,
        mottoText: wizardData.mottoText ?? item.data.mottoText,
      };
      return item;
    }
    case 'media':
      return {
        id: generateId(),
        type: 'media',
        title: wizardData.title || 'Imagem / Vídeo',
        slideType: 'media',
        mediaId: wizardData.mediaId || null,
        data: { loop: wizardData.loop !== false },
      };
    case 'media-audio':
      return {
        id: generateId(),
        type: 'media-audio',
        title: wizardData.title || 'Áudio no programa',
        slideType: 'media-audio',
        placeholder: wizardData.hint || '',
        data: {
          audioPath: wizardData.audioPath || null,
          loop: wizardData.loop === true,
          hint: wizardData.hint || '',
          coverSrc: wizardData.coverSrc || '',
          screenTitle: wizardData.screenTitle || wizardData.title || 'Áudio',
        },
      };
    case 'deck':
    case 'pptx':
      return {
        id: generateId(),
        type: 'deck',
        title: wizardData.title || 'Apresentação',
        slideType: 'deck',
        data: {
          slides: Array.isArray(wizardData.slides) ? wizardData.slides : [],
          source: wizardData.source || 'pptx',
          sourceName: wizardData.sourceName || wizardData.title || '',
        },
      };
    case 'offering':
      return {
        id: generateId(),
        type: 'offering',
        title: wizardData.title || 'Oferta / Dízimo',
        slideType: 'offering',
        data: {
          title: wizardData.screenTitle || wizardData.title || 'Oferta e Dízimos',
          subtitle: wizardData.subtitle || '',
          verse: wizardData.verse || '',
          template: wizardData.template || 'classic',
        },
      };
    case 'countdown':
      return {
        id: generateId(),
        type: 'countdown',
        title: wizardData.title || 'Pausa',
        slideType: 'countdown',
        data: {
          title: wizardData.screenTitle || wizardData.title || 'Pausa',
          note: wizardData.note || '',
          durationMin: wizardData.durationMin || null,
        },
      };
    case 'custom':
      return {
        id: generateId(),
        type: 'custom',
        title: wizardData.title || 'Slide livre',
        slideType: 'custom',
        data: {
          text: wizardData.text || '',
          title: wizardData.screenTitle || wizardData.title || '',
          subtitle: wizardData.subtitle || '',
          align: wizardData.align || 'center',
          backgroundPreset: wizardData.backgroundPreset || 'dark',
        },
      };
    default:
      return {
        id: generateId(),
        type: 'custom',
        title: wizardData.title || 'Novo Item',
        slideType: 'custom',
        data: {
          text: wizardData.text || '',
          title: wizardData.screenTitle || wizardData.title || '',
        },
      };
  }
}
