/**
 * Pacotes temáticos de culto — identidade visual + ordem + defaults de slides.
 * Fonte única para createCulto / templates / welcome.
 * atmosphereId → js/ui/theme/atmospheres.js (SSOT de projeção).
 */
import { welcomePresetForCultoType } from '../slides/welcome-config.js';

/** @typedef {{ accent?: string, accentSoft?: string, animation?: string, layout?: string, overlayStrength?: string, bgMotion?: string, badgeStyle?: string, sparkles?: boolean }} WelcomeVisual */

/**
 * @typedef {object} CultoThemePack
 * @property {string} id
 * @property {string} label
 * @property {string} atmosphereId
 * @property {string} welcomePreset
 * @property {WelcomeVisual} visual
 * @property {string} programFactory
 * @property {{ lyricsStyle?: object, backgroundPreset?: string, messageStyle?: object }} slideDefaults
 */

/** @type {Record<string, CultoThemePack>} */
export const CULTO_THEME_PACKS = {
  domingo: {
    id: 'domingo',
    label: 'Celebração',
    atmosphereId: 'celebracao',
    welcomePreset: 'domingo',
    visual: {
      accent: '#d4c68d',
      accentSoft: 'rgba(212, 198, 141, 0.28)',
      animation: 'classic',
      layout: 'center',
      overlayStrength: 'strong',
      bgMotion: 'kenburns',
      badgeStyle: 'pill',
      sparkles: false,
    },
    programFactory: 'domingo',
    slideDefaults: {
      backgroundPreset: 'theme',
      lyricsStyle: { fontSize: 54, align: 'center', textTransform: 'none', linesPerSlide: 4 },
      messageStyle: { fontSize: 72, textTransform: 'uppercase' },
    },
  },
  quarta: {
    id: 'quarta',
    label: 'Oração',
    atmosphereId: 'oracao',
    welcomePreset: 'quarta',
    visual: {
      accent: '#9db4c8',
      accentSoft: 'rgba(157, 180, 200, 0.25)',
      animation: 'serene',
      layout: 'center',
      overlayStrength: 'strong',
      bgMotion: 'static',
      badgeStyle: 'line',
      sparkles: false,
    },
    programFactory: 'quarta',
    slideDefaults: {
      backgroundPreset: 'dark',
      lyricsStyle: { fontSize: 52, align: 'center', textTransform: 'none', linesPerSlide: 3 },
      messageStyle: { fontSize: 64, textTransform: 'none' },
    },
  },
  ceia: {
    id: 'ceia',
    label: 'Ceia do Senhor',
    atmosphereId: 'ceia',
    welcomePreset: 'domingo',
    visual: {
      accent: '#d4a853',
      accentSoft: 'rgba(212, 168, 83, 0.3)',
      animation: 'serene',
      layout: 'center',
      overlayStrength: 'strong',
      bgMotion: 'static',
      badgeStyle: 'line',
      sparkles: false,
    },
    programFactory: 'domingo',
    slideDefaults: {
      backgroundPreset: 'theme',
      lyricsStyle: { fontSize: 52, align: 'center', textTransform: 'none', linesPerSlide: 3 },
      messageStyle: { fontSize: 64, textTransform: 'none' },
    },
  },
  ebd: {
    id: 'ebd',
    label: 'EBD',
    atmosphereId: 'ebd',
    welcomePreset: 'domingo',
    visual: {
      accent: '#8ecf9a',
      accentSoft: 'rgba(142, 207, 154, 0.3)',
      animation: 'classic',
      layout: 'center',
      overlayStrength: 'medium',
      bgMotion: 'static',
      badgeStyle: 'pill',
      sparkles: false,
    },
    programFactory: 'domingo',
    slideDefaults: {
      backgroundPreset: 'theme',
      lyricsStyle: { fontSize: 54, align: 'center', textTransform: 'none', linesPerSlide: 4 },
      messageStyle: { fontSize: 64, textTransform: 'none' },
    },
  },
  mulheres: {
    id: 'mulheres',
    label: 'Mulheres',
    atmosphereId: 'mulheres',
    welcomePreset: 'mulheres',
    visual: {
      accent: '#e8b4b8',
      accentSoft: 'rgba(232, 180, 184, 0.32)',
      animation: 'elegant',
      layout: 'split-left',
      overlayStrength: 'medium',
      bgMotion: 'kenburns',
      badgeStyle: 'pill',
      sparkles: false,
    },
    programFactory: 'mulheres',
    slideDefaults: {
      backgroundPreset: 'gold',
      lyricsStyle: { fontSize: 52, align: 'center', textTransform: 'none', linesPerSlide: 4 },
      messageStyle: { fontSize: 68, textTransform: 'none' },
    },
  },
  homens: {
    id: 'homens',
    label: 'Homens',
    atmosphereId: 'homens',
    welcomePreset: 'homens',
    visual: {
      accent: '#7a9cc6',
      accentSoft: 'rgba(122, 156, 198, 0.28)',
      animation: 'classic',
      layout: 'split-left',
      overlayStrength: 'strong',
      bgMotion: 'kenburns',
      badgeStyle: 'line',
      sparkles: false,
    },
    programFactory: 'homens',
    slideDefaults: {
      backgroundPreset: 'dark',
      lyricsStyle: { fontSize: 54, align: 'center', textTransform: 'uppercase', linesPerSlide: 4 },
      messageStyle: { fontSize: 72, textTransform: 'uppercase' },
    },
  },
  jovens: {
    id: 'jovens',
    label: 'Jovens',
    atmosphereId: 'jovens',
    welcomePreset: 'jovens',
    visual: {
      accent: '#f0d78c',
      accentSoft: 'rgba(240, 215, 140, 0.4)',
      animation: 'pulse',
      layout: 'hero',
      overlayStrength: 'medium',
      bgMotion: 'kenburns',
      badgeStyle: 'pill',
      sparkles: true,
      logoSize: 200,
    },
    programFactory: 'jovens',
    slideDefaults: {
      backgroundPreset: 'theme',
      lyricsStyle: { fontSize: 56, align: 'center', textTransform: 'none', linesPerSlide: 3 },
      messageStyle: { fontSize: 70, textTransform: 'none' },
    },
  },
  adolescentes: {
    id: 'adolescentes',
    label: 'Adolescentes',
    atmosphereId: 'adolescentes',
    welcomePreset: 'jovens',
    visual: {
      accent: '#c9a0ff',
      accentSoft: 'rgba(201, 160, 255, 0.35)',
      animation: 'pulse',
      layout: 'hero',
      overlayStrength: 'medium',
      bgMotion: 'kenburns',
      badgeStyle: 'pill',
      sparkles: true,
    },
    programFactory: 'jovens',
    slideDefaults: {
      backgroundPreset: 'theme',
      lyricsStyle: { fontSize: 56, align: 'center', textTransform: 'none', linesPerSlide: 3 },
      messageStyle: { fontSize: 68, textTransform: 'none' },
    },
  },
  criancas: {
    id: 'criancas',
    label: 'Crianças',
    atmosphereId: 'criancas',
    welcomePreset: 'criancas',
    visual: {
      accent: '#7ec8e3',
      accentSoft: 'rgba(126, 200, 227, 0.35)',
      animation: 'playful',
      layout: 'hero',
      overlayStrength: 'light',
      bgMotion: 'kenburns',
      badgeStyle: 'pill',
      sparkles: true,
    },
    programFactory: 'criancas',
    slideDefaults: {
      backgroundPreset: 'theme',
      lyricsStyle: { fontSize: 58, align: 'center', textTransform: 'none', linesPerSlide: 2 },
      messageStyle: { fontSize: 56, textTransform: 'none' },
    },
  },
  missoes: {
    id: 'missoes',
    label: 'Missões',
    atmosphereId: 'missoes',
    welcomePreset: 'missoes',
    visual: {
      accent: '#c4a574',
      accentSoft: 'rgba(196, 165, 116, 0.3)',
      animation: 'rise',
      layout: 'hero',
      overlayStrength: 'medium',
      bgMotion: 'kenburns',
      badgeStyle: 'pill',
      sparkles: false,
    },
    programFactory: 'missoes',
    slideDefaults: {
      backgroundPreset: 'gold',
      lyricsStyle: { fontSize: 54, align: 'center', textTransform: 'none', linesPerSlide: 4 },
      messageStyle: { fontSize: 68, textTransform: 'uppercase' },
    },
  },
  especial: {
    id: 'especial',
    label: 'Especial',
    atmosphereId: 'especial',
    welcomePreset: 'especial',
    visual: {
      accent: '#d4c68d',
      accentSoft: 'rgba(212, 198, 141, 0.32)',
      animation: 'elegant',
      layout: 'hero',
      overlayStrength: 'strong',
      bgMotion: 'kenburns',
      badgeStyle: 'ribbon',
      sparkles: false,
    },
    programFactory: 'especial',
    slideDefaults: {
      backgroundPreset: 'theme',
      lyricsStyle: { fontSize: 54, align: 'center', textTransform: 'none', linesPerSlide: 4 },
      messageStyle: { fontSize: 72, textTransform: 'uppercase' },
    },
  },
  aniversario: {
    id: 'aniversario',
    label: 'Aniversário',
    atmosphereId: 'aniversario',
    welcomePreset: 'aniversario',
    visual: {
      accent: '#e8c97a',
      accentSoft: 'rgba(232, 201, 122, 0.35)',
      animation: 'anniversary',
      layout: 'split-left',
      overlayStrength: 'strong',
      bgMotion: 'kenburns',
      badgeStyle: 'ribbon',
      sparkles: true,
    },
    programFactory: 'aniversario',
    slideDefaults: {
      backgroundPreset: 'gold',
      lyricsStyle: { fontSize: 54, align: 'center', textTransform: 'none', linesPerSlide: 4 },
      messageStyle: { fontSize: 72, textTransform: 'uppercase' },
    },
  },
};

export function getCultoThemePack(cultoType = 'domingo') {
  return CULTO_THEME_PACKS[cultoType] || CULTO_THEME_PACKS.domingo;
}

export function listCultoThemePackIds() {
  return Object.keys(CULTO_THEME_PACKS);
}

/** Atmosfera de projeção ligada ao tipo de culto. */
export function atmosphereIdFromCultoType(cultoType = 'domingo') {
  return getCultoThemePack(cultoType).atmosphereId || 'somos-um';
}

/** Aplica tipografia/fundo padrão do pack nos itens gerados na criação.
 * Com songId, não sobrescreve divisão de slides da biblioteca (splitMode / linhas). */
export function applyPackSlideDefaults(items, pack) {
  if (!pack?.slideDefaults || !Array.isArray(items)) return items;
  const { lyricsStyle, backgroundPreset, messageStyle } = pack.slideDefaults;
  return items.map((item) => {
    if (item.slideType === 'lyrics' && (lyricsStyle || backgroundPreset)) {
      const packStyle = { ...(lyricsStyle || {}) };
      if (item.songId) {
        delete packStyle.splitMode;
        delete packStyle.linesPerSlide;
        delete packStyle.stanzasPerSlide;
      }
      return {
        ...item,
        data: {
          ...(item.data || {}),
          lyricsStyle: {
            ...(item.data?.lyricsStyle || {}),
            ...packStyle,
            ...(backgroundPreset ? { backgroundPreset } : {}),
          },
        },
      };
    }
    if ((item.slideType === 'message' || item.slideType === 'bible') && messageStyle) {
      const key = item.slideType === 'message' ? 'style' : 'style';
      return {
        ...item,
        data: {
          ...(item.data || {}),
          [key]: { ...(item.data?.[key] || {}), ...messageStyle },
        },
      };
    }
    return item;
  });
}

/** Campos visuais do pack para fundir no welcome item. */
export function welcomeVisualFromPack(cultoType) {
  const pack = getCultoThemePack(cultoType);
  return {
    welcomePreset: pack.welcomePreset || welcomePresetForCultoType(cultoType),
    ...pack.visual,
  };
}
