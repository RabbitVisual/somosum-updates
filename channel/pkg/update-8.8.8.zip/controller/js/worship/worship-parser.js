/**
 * Limpeza profissional de letras coladas — sem IA, heurísticas determinísticas.
 * Remove cifras/acordes e ruído de sites; preserva estrofes e marcadores.
 */

const INVISIBLE = /[\u200B-\u200D\uFEFF\u00AD]/g;

/** Linhas típicas de acorde (C Am F G, Bm7, C/E, etc.). */
const CHORD_TOKEN =
  /^(?:[A-G](?:#|b)?(?:m|maj|min|dim|aug|sus|add)?\d*(?:\/[A-G](?:#|b)?)?)$/i;

/** Linhas de tablatura / grade de cifra. */
const TAB_LINE = /^[\s|]*[-–—xX0-9|\\/]+[\s|]*$/;

/** Ruído comum ao copiar de Letras.mus.br / Vagalume / etc. */
const SITE_NOISE = [
  /^\s*compartilhar\s*$/i,
  /^\s*copiar\s+link\s*$/i,
  /^\s*tradu[cç][aã]o\s*$/i,
  /^\s*enviar\s+letra\s*$/i,
  /^\s*curtir\s*$/i,
  /^\s*favoritar\s*$/i,
  /^\s*adicionar\s+[àa]\s+playlist\s*$/i,
  /^\s*exibi[cç][oõ]es?\s*(de\s+letras?)?\s*$/i,
  /^\s*\d+\s*(exibi[cç][oõ]es?|views?)\s*$/i,
  /^\s*letras\.mus\.br\s*$/i,
  /^\s*vagalume\s*$/i,
  /^\s*cifra\s*club\s*$/i,
  /^\s*ver\s+tradu[cç][aã]o\s*$/i,
  /^\s*ouvir\s+(m[uú]sica|agora)\s*$/i,
  /^\s*tocar\s*$/i,
  /^\s*imprimir\s*$/i,
  /^\s*baixar\s*$/i,
  /^\s*contribuir\s*$/i,
  /^\s*corrigir\s*$/i,
  /^\s*reportar\s*(erro)?\s*$/i,
  /^\s*an[uú]ncio\s*$/i,
  /^\s*publicidade\s*$/i,
  /^\s*mais\s+acessados\s*$/i,
  /^\s*relacionad[oa]s?\s*$/i,
  /^\s*artista\s*$/i,
  /^\s*compositor\s*$/i,
];

/**
 * True se a linha for só acordes (espaçados) sem letra.
 * Ex.: "C   Am   F   G" ou "Bm7  C/E"
 */
export function isChordOnlyLine(line) {
  const t = String(line || '').trim();
  if (!t) return false;
  if (TAB_LINE.test(t)) return true;
  // Evita apagar linhas curtas que são letra real ("Eu", "Oh", "Amém")
  const tokens = t.split(/\s+/).filter(Boolean);
  if (!tokens.length) return false;
  if (tokens.length === 1 && tokens[0].length <= 4 && !/^[A-G](?:#|b)?/i.test(tokens[0])) {
    return false;
  }
  return tokens.every((tok) => CHORD_TOKEN.test(tok));
}

/** True se a linha for ruído de site / UI. */
export function isSiteNoiseLine(line) {
  const t = String(line || '').trim();
  if (!t) return false;
  return SITE_NOISE.some((re) => re.test(t));
}

/**
 * Remove linhas de cifra/acorde e ruído de página.
 * Preserva marcadores [Verso]/ [Refrão] e estrofes (linhas em branco).
 */
export function stripChordsFromPaste(text) {
  if (!text) return '';
  const lines = String(text).replace(/\r\n/g, '\n').replace(/\r/g, '\n').split('\n');
  const kept = [];
  for (const line of lines) {
    const trimmed = line.trimEnd();
    if (isChordOnlyLine(trimmed) || isSiteNoiseLine(trimmed)) continue;
    // Remove acordes embutidos no início da linha ("Am  Eu te amo" → "Eu te amo")
    let cleaned = trimmed.replace(
      /^(?:[A-G](?:#|b)?(?:m|maj|min|dim|aug|sus|add)?\d*(?:\/[A-G](?:#|b)?)?(?:\s+|$))+/,
      ''
    );
    // Se sobrou só espaços ou ficou vazia após strip parcial de acorde-only, pular
    if (cleaned !== trimmed && !cleaned.trim() && isChordOnlyLine(trimmed)) continue;
    kept.push(cleaned.trimEnd());
  }
  return kept.join('\n');
}

/** Remove espaços duplos, linhas vazias excessivas, tabs, cifras e caracteres invisíveis. */
export function cleanPastedLyrics(text) {
  if (!text) return '';
  let out = String(text)
    .replace(/\r\n/g, '\n')
    .replace(/\r/g, '\n')
    .replace(INVISIBLE, '')
    .replace(/\t/g, ' ')
    .replace(/[ \u00A0]{2,}/g, ' ')
    .replace(/^\d+[\.\)]\s*/gm, '')
    .replace(/^[•·▪▫]\s*/gm, '');

  out = stripChordsFromPaste(out);

  // Normaliza quebras de linha (máx. 1 linha em branco entre estrofes)
  out = out
    .split('\n')
    .map((line) => line.trimEnd())
    .join('\n')
    .replace(/\n{3,}/g, '\n\n')
    .trim();

  out = normalizePunctuation(out);
  out = organizeLyricsForWorship(out);
  return out;
}

/**
 * Organização inteligente para culto: cura quebras ruins e preserva estrofes
 * (linhas poéticas + \\n\\n) para cantar e projetar sem erro.
 */
export function organizeLyricsForWorship(text) {
  if (!text) return '';
  const raw = String(text).replace(/\r\n/g, '\n').replace(/\r/g, '\n').split('\n');
  const out = [];

  for (const row of raw) {
    const line = String(row || '').trim();
    if (!line) {
      if (out.length && out[out.length - 1] !== '') out.push('');
      continue;
    }
    if (out.length) {
      let prevIdx = out.length - 1;
      while (prevIdx >= 0 && out[prevIdx] === '') prevIdx -= 1;
      const prev = prevIdx >= 0 ? out[prevIdx] : '';
      // Fragmento de soft-wrap legado: ", é a hora…"
      if (prev && /^[,;.:]/.test(line)) {
        out[prevIdx] = `${prev}${line}`;
        continue;
      }
    }
    out.push(line);
  }

  while (out.length && out[0] === '') out.shift();
  while (out.length && out[out.length - 1] === '') out.pop();
  return out.join('\n').replace(/\n{3,}/g, '\n\n').trim();
}

/** Sugere 2/4/6 linhas por slide com base no tamanho médio das estrofes. */
export function suggestLinesPerSlide(lyrics) {
  const stanzas = String(lyrics || '')
    .split(/\n\s*\n/)
    .map((s) => s.split('\n').map((l) => l.trim()).filter(Boolean).length)
    .filter((n) => n > 0);
  if (!stanzas.length) return 4;
  const sorted = [...stanzas].sort((a, b) => a - b);
  const mid = sorted[Math.floor(sorted.length / 2)];
  if (mid <= 2) return 2;
  if (mid <= 4) return 4;
  return 6;
}

/** Padroniza espaços antes de pontuação — sem colapsar quebras de linha/estrofe. */
function normalizePunctuation(text) {
  return String(text || '')
    .split('\n')
    .map((line) => line
      .replace(/[^\S\n]+([,.!?;:])/g, '$1')
      .replace(/([,.!?;:])([^\s\n])/g, '$1 $2')
      .replace(/[^\S\n]{2,}/g, ' ')
      .trimEnd())
    .join('\n');
}

/** Detecta e marca blocos organizacionais a partir de rótulos comuns. */
export function detectBlocks(lyrics) {
  const lines = String(lyrics || '').split('\n');
  const blocks = [];
  const labelRe = /^\s*\[?\s*(verso|refr[aã]o|ponte|intro|introdu[cç][aã]o|final|instrumental|pr[eé][\s-]?refr[aã]o|tag)\s*\]?\s*:?\s*$/i;

  const typeMap = {
    verso: 'verse',
    refrão: 'chorus',
    refrao: 'chorus',
    ponte: 'bridge',
    intro: 'intro',
    introdução: 'intro',
    introducao: 'intro',
    final: 'outro',
    instrumental: 'instrumental',
    'pré-refrão': 'pre-chorus',
    'pre-refrão': 'pre-chorus',
    'pre-refrao': 'pre-chorus',
    tag: 'tag',
  };

  let current = null;
  let start = 0;

  for (let i = 0; i < lines.length; i++) {
    const m = lines[i].match(labelRe);
    if (!m) continue;
    const key = m[1].toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
    const normalizedKey = Object.keys(typeMap).find((k) =>
      key.includes(k.normalize('NFD').replace(/[\u0300-\u036f]/g, ''))
    );
    const type = typeMap[normalizedKey] || 'verse';

    if (current) {
      blocks.push({ type: current, startLine: start, endLine: i - 1 });
    }
    current = type;
    start = i + 1;
    lines[i] = ''; // remove label da letra
  }
  if (current) blocks.push({ type: current, startLine: start, endLine: lines.length - 1 });

  return { lyrics: lines.join('\n').replace(/\n{3,}/g, '\n\n').trim(), blocks };
}

/** Insere marcadores de bloco na letra (organizacional). */
export function insertBlockMarker(lyrics, lineIndex, blockType) {
  const labels = {
    verse: '[Verso]',
    chorus: '[Refrão]',
    bridge: '[Ponte]',
    intro: '[Introdução]',
    outro: '[Final]',
    instrumental: '[Instrumental]',
    'pre-chorus': '[Pré-refrão]',
    tag: '[Tag]',
  };
  const lines = String(lyrics || '').split('\n');
  const marker = labels[blockType] || `[${blockType}]`;
  lines.splice(Math.max(0, lineIndex), 0, marker, '');
  return lines.join('\n');
}
