/**
 * Biblioteca de Louvores — shell profissional, categorias claras, sem redundância.
 */
import {
  formatHinarioRefsList,
  DEFAULT_HINARIO_CATEGORIES,
  getHinarioSiglaForName,
  hinarioNamesEqual,
} from './hinario-catalog.js';
import { isSystemDefaultSong } from './default-hinarios.js';
import { getAllMedia } from '../core/store.js';
import { createProgramItem } from '../program/programa-templates.js';
import {
  initWorshipLibrary,
  refreshWorshipLibrary,
  searchWorship,
  getWorshipSong,
  saveWorshipSong,
  forceSaveWorshipSong,
  deleteWorshipSong,
  duplicateWorshipSong,
  recordSongUsage,
  toggleFavorite,
  importWorshipSongs,
  getWorshipStats,
  waitForIndex,
  getWorshipSongMap,
  cleanupWorshipDuplicates,
  restoreSystemDefaultSong,
  hasDefaultHinarioEdits,
  getHinarioCategoryCounts,
  getUserCategoryCounts,
} from './worship-store.js';
import { mergeSongFields } from './song-identity.js';
import {
  getCategories,
  addCategory,
  getPlaylists,
  savePlaylist,
  deletePlaylist,
  addSongToPlaylist,
} from './worship-meta.js';
import { cachePlaylistSongs } from './worship-cache.js';
import { createEmptySong } from './worship-schema.js';
import { WorshipEditor } from './worship-editor.js';
import { importFile, importDocxFile } from './worship-import.js';
import {
  exportSongTxt,
  exportSongSomosum,
  exportLibrarySomosum,
  exportSongDocx,
  downloadText,
} from './worship-export.js';
import { generateId } from '../core/store.js';
import { mountVirtualList } from '../ui/kit/virtual-list.js';
import { openContextMenu } from '../ui/kit/context-menu.js';
import { openLyricsImportStudio } from './lyrics-engine/ui/lyrics-import-studio.js';
import { openHolyricsImportPanel } from './ui/holyrics-import-panel.js';
import { openLyricsPrintStudio } from './ui/lyrics-print-studio.js';
import { openHinarioPackInstaller } from './ui/hinario-pack-installer.js';
import {
  fetchHinarioPackManifest,
  isHinarioPackInstalled,
} from './hinario-pack-service.js';
import { loadWorshipMeta } from './worship-meta.js';
import { faIconRaw } from '../core/fa-icons.js';

function esc(t) {
  const d = document.createElement('div');
  d.textContent = t ?? '';
  return d.innerHTML;
}

const SIDEBAR_TABS = [
  { id: 'all', label: 'Todas', icon: 'list' },
  { id: 'favorites', label: 'Favoritas', icon: 'star' },
  { id: 'recent', label: 'Recentes', icon: 'clock' },
  { id: 'most-used', label: 'Mais usadas', icon: 'fire' },
];

export class WorshipLibrary {
  constructor(container, app, callbacks = {}) {
    this.container = container;
    this.app = app;
    this.callbacks = callbacks;
    this.query = '';
    this.tab = 'all';
    this.selectedCategory = '';
    this.selectedId = null;
    this.playlists = [];
    this.categories = [];
    this.activePlaylistId = null;
    this.stats = null;
    this._searchTimer = null;
    this._results = [];
    this._disposers = [];
    this._virtualList = null;
    this._listDelegated = false;
    this._defaultEdited = false;
    this._organizeExpanded = false;
    this._installingHinarios = false;
    this._hinarioManifest = null;
    this._worshipMeta = null;
    this._defaultEditedCache = new Map();
    this._editCheckToken = 0;
    this._suspendListRefresh = false;
    this._pendingSearch = false;
    this._renderListRaf = null;
  }

  async init() {
    const initResult = await initWorshipLibrary();
    this._worshipMeta = await loadWorshipMeta();
    try {
      this._hinarioManifest = await fetchHinarioPackManifest();
    } catch {
      this._hinarioManifest = null;
    }
    this.categories = await getCategories();
    this.playlists = await getPlaylists();
    this.stats = getWorshipStats();
    this.mediaList = await getAllMedia();
    this.render();
    this.bindGlobalKeys();
    waitForIndex().then(() => this.runSearch());
    if (initResult.recovered) {
      this.toast('Biblioteca recuperada automaticamente do backup.');
    }
    if ((this.stats?.hinarioTotal ?? 0) === 0) {
      void this.promptInstallHinarios();
    }
    const deferDupes = typeof requestIdleCallback === 'function'
      ? (fn) => requestIdleCallback(fn, { timeout: 4000 })
      : (fn) => setTimeout(fn, 1500);
    deferDupes(() => void this.warnIfDuplicates());
  }

  async warnIfDuplicates() {
    try {
      const preview = await cleanupWorshipDuplicates({ dryRun: true });
      if (preview.merged > 0) {
        this.toast(
          `${preview.merged} duplicata(s) detectada(s). Use “Limpar duplicatas” na barra inferior.`,
          'warn'
        );
      }
    } catch { /* ignore */ }
  }

  async promptInstallHinarios() {
    if (this._installingHinarios) return;
    this.renderHinarios();
  }

  openHinarioInstaller() {
    void openHinarioPackInstaller({
      toast: (msg, type) => this.toast(msg, type),
      onInstalled: async () => {
        this._worshipMeta = await loadWorshipMeta();
        await refreshWorshipLibrary();
        this.categories = await getCategories();
        this.stats = getWorshipStats();
        this.renderOrganize();
        this.runSearch();
      },
    });
  }

  async installDefaultHinarios() {
    this.openHinarioInstaller();
  }

  async refresh() {
    await refreshWorshipLibrary();
    this.categories = await getCategories();
    this.playlists = await getPlaylists();
    this.stats = getWorshipStats();
    this.renderOrganize();
    await waitForIndex();
    this.runSearch(true);
    this.renderList();
  }

  /** Após salvar: não wipe do índice — a música já foi indexSong'd. */
  async afterSongSaved(song) {
    if (!song?.id) return;
    this.selectedId = song.id;
    this.query = '';
    this.selectedCategory = '';
    this.tab = 'all';
    this.activePlaylistId = null;
    this.categories = await getCategories();
    this.playlists = await getPlaylists();
    this.stats = getWorshipStats();
    const searchEl = this.container?.querySelector('#wl-search');
    if (searchEl) searchEl.value = '';
    this.renderOrganize();
    await waitForIndex();
    this.runSearch(true);
    this.select(song.id);
    this.renderList();
  }

  bindGlobalKeys() {
    const onKey = (e) => {
      if (e.target.matches('input, textarea, select') && !e.ctrlKey && !e.metaKey) return;
      if ((e.ctrlKey || e.metaKey) && e.key === 'f') {
        e.preventDefault();
        this.container.querySelector('#wl-search')?.focus();
      }
      if ((e.ctrlKey || e.metaKey) && e.key === 'n') {
        e.preventDefault();
        this.newSong();
      }
      if ((e.ctrlKey || e.metaKey) && e.key === 'd' && this.selectedId) {
        e.preventDefault();
        this.duplicateSelected();
      }
      if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key === 'I') {
        e.preventDefault();
        this.openImportStudio();
      }
    };
    document.addEventListener('keydown', onKey);
    this._disposers.push(() => document.removeEventListener('keydown', onKey));
  }

  destroy() {
    clearTimeout(this._searchTimer);
    this._searchTimer = null;
    if (this._renderListRaf) cancelAnimationFrame(this._renderListRaf);
    this._renderListRaf = null;
    this._virtualList?.dispose?.();
    this._virtualList = null;
    this.editor?.destroy?.();
    this.editor = null;
    this._disposers.forEach((d) => d());
    this._disposers = [];
  }

  runSearch(force = false) {
    if (this._suspendListRefresh && !force) {
      this._pendingSearch = true;
      return;
    }
    const playlist = this.playlists.find((p) => p.id === this.activePlaylistId);
    this._results = searchWorship(this.query, {
      tab: this.tab,
      category: this.selectedCategory || '',
      playlistSongIds: playlist?.songIds,
    });
    this.scheduleRenderList();
  }

  scheduleSearch() {
    clearTimeout(this._searchTimer);
    this._searchTimer = setTimeout(() => this.runSearch(), 120);
  }

  scheduleRenderList() {
    if (this._renderListRaf) return;
    this._renderListRaf = requestAnimationFrame(() => {
      this._renderListRaf = null;
      this.renderList();
    });
  }

  updateListStatsOnly() {
    const count = this.container.querySelector('#wl-count');
    if (!count) return;
    this.stats = getWorshipStats();
    const user = this.stats?.userTotal ?? 0;
    const hin = this.stats?.hinarioTotal ?? 0;
    const shown = this._suspendListRefresh ? user + hin : (this._results?.length ?? 0);
    count.textContent = this._suspendListRefresh
      ? `${shown} na biblioteca · importando…`
      : `${shown} exibidas · ${user} suas · ${hin} hinário`;
  }

  suspendListForImport() {
    this._suspendListRefresh = true;
    const list = this.container.querySelector('#wl-list');
    list?.classList.add('worship-list--importing');
    this.updateListStatsOnly();
  }

  resumeListAfterImport() {
    this._suspendListRefresh = false;
    const list = this.container.querySelector('#wl-list');
    list?.classList.remove('worship-list--importing');
    if (this._pendingSearch) {
      this._pendingSearch = false;
      this.runSearch(true);
    } else {
      this.stats = getWorshipStats();
      this.updateListStatsOnly();
      this.scheduleRenderList();
    }
  }

  async select(id) {
    const prevId = this.selectedId;
    this.selectedId = id;
    const song = id ? await getWorshipSong(id) : null;
    const cachedEdited = id ? this._defaultEditedCache.get(id) : false;
    this._defaultEdited = !!cachedEdited;
    this.editor?.setDraft(song, {
      openAssist: false,
      defaultEdited: cachedEdited ?? false,
    });
    if (this.editor) this.editor.categories = this.categories;
    if (this._virtualList && prevId !== id && !this._suspendListRefresh) {
      this._virtualList.repaintSelection(id);
    } else if (!this._suspendListRefresh) {
      this.scheduleRenderList();
    }

    if (!song?.id || !isSystemDefaultSong(song)) return;
    if (this._defaultEditedCache.has(song.id)) return;

    const token = ++this._editCheckToken;
    const runCheck = async () => {
      if (token !== this._editCheckToken || this.selectedId !== song.id) return;
      try {
        const edited = await hasDefaultHinarioEdits(song);
        this._defaultEditedCache.set(song.id, edited);
        if (token !== this._editCheckToken || this.selectedId !== song.id) return;
        this._defaultEdited = edited;
        this.editor?.setDefaultEdited?.(edited);
        this.renderToolbar();
      } catch { /* ignore */ }
    };
    if (typeof requestIdleCallback === 'function') {
      requestIdleCallback(() => { void runCheck(); }, { timeout: 800 });
    } else {
      setTimeout(() => { void runCheck(); }, 0);
    }
  }

  newSong() {
    this.openImportStudio();
  }

  openImportStudio(query = '') {
    const draft = this.editor?.getDraft?.();
    const q = query
      || [draft?.title, draft?.artist].filter(Boolean).join(' ').trim();
    openLyricsImportStudio({
      app: this.app,
      query: q,
      onToast: (msg, type) => this.toast(msg, type),
      onSaved: async (song) => {
        await this.afterSongSaved(song);
      },
      onOpenExisting: async (song) => {
        if (song?.id) await this.afterSongSaved(song);
      },
    });
  }

  openMuflPanel() {
    openHolyricsImportPanel({
      onToast: (msg, type) => this.toast(msg, type),
      getSelectedSong: () => {
        const draft = this.editor?.getDraft?.();
        if (draft?.title?.trim() && 'lyrics' in draft) return draft;
        if (this.selectedId) return getWorshipSongMap().get(this.selectedId) || null;
        return null;
      },
      onSuspendList: () => this.suspendListForImport(),
      onPartialRefresh: () => this.updateListStatsOnly(),
      onRefresh: async () => {
        this.stats = getWorshipStats();
        this.updateListStatsOnly();
      },
      onResumeList: async () => {
        this.resumeListAfterImport();
      },
    });
  }

  toast(msg, type = 'info') {
    this.callbacks.onToast?.(msg, type) || this.app?.toast?.(msg, type);
  }

  async saveDraft() {
    const draft = this.editor?.getDraft();
    if (!draft?.title?.trim()) {
      this.toast('Informe o título da música.');
      this.container.querySelector('#we-title')?.focus();
      return null;
    }

    const result = await saveWorshipSong(draft);
    if (result.action === 'duplicate') {
      const choice = this.resolveDuplicateDialog(result.duplicate, draft);
      if (choice === 'cancel') {
        this.toast('Não salva — música já existe na biblioteca.', 'warn');
        return null;
      }
      if (choice === 'open') {
        await this.select(result.duplicate.id);
        this.toast(`Aberta a existente: “${result.duplicate.title}”`, 'info');
        return result.duplicate;
      }
      if (choice === 'update') {
        const existing = await getWorshipSong(result.duplicate.id);
        const merged = mergeSongFields(existing || result.duplicate, draft);
        merged.id = result.duplicate.id;
        const saved = await forceSaveWorshipSong(merged);
        this.selectedId = saved.id;
        this.stats = getWorshipStats();
        this.runSearch();
        this.editor?.setDraft(saved, { openAssist: false });
        this.callbacks.onSave?.(saved);
        this.app?.program?.clearSongCache?.();
        this.toast(`Atualizada a música existente “${saved.title}”.`, 'success');
        return saved;
      }
      if (choice === 'keep-both') {
        const saved = await forceSaveWorshipSong({ ...draft, id: generateId() });
        this.selectedId = saved.id;
        this.stats = getWorshipStats();
        this.runSearch();
        this.callbacks.onSave?.(saved);
        this.app?.program?.clearSongCache?.();
        this.toast('Salva como cópia adicional (duplicata permitida).', 'warn');
        return saved;
      }
      return null;
    }

    const saved = result.song;
    this.selectedId = saved.id;
    this.stats = getWorshipStats();
    if (isSystemDefaultSong(saved)) {
      this._defaultEditedCache.delete(saved.id);
    }
    this._defaultEdited = isSystemDefaultSong(saved)
      ? await hasDefaultHinarioEdits(saved)
      : false;
    if (isSystemDefaultSong(saved)) {
      this._defaultEditedCache.set(saved.id, this._defaultEdited);
    }
    this.editor?.setDraft(saved, { openAssist: false, defaultEdited: this._defaultEdited });
    this.runSearch();
    this.renderToolbar();
    this.callbacks.onSave?.(saved);
    this.app?.program?.clearSongCache?.();
    this.toast(result.action === 'updated' ? 'Música atualizada!' : 'Música salva!');
    return saved;
  }

  /**
   * @returns {'update'|'open'|'keep-both'|'cancel'}
   */
  resolveDuplicateDialog(existing, incoming) {
    const artist = existing.artist ? ` — ${existing.artist}` : '';
    const msg = [
      'Esta música já existe na biblioteca.',
      '',
      `Existente: “${existing.title}”${artist}`,
      `Tentando salvar: “${incoming.title}”${incoming.artist ? ` — ${incoming.artist}` : ''}`,
      '',
      'OK = atualizar a existente com estes dados',
      'Cancelar = não criar duplicata (pode abrir a existente em seguida)',
    ].join('\n');
    if (confirm(msg)) return 'update';
    if (confirm(`Abrir a música existente “${existing.title}” no editor?`)) return 'open';
    return 'cancel';
  }

  async cleanupDuplicates() {
    const preview = await cleanupWorshipDuplicates({ dryRun: true });
    if (!preview.merged) {
      this.toast('Nenhuma duplicata encontrada. Biblioteca limpa.', 'success');
      return;
    }
    const names = (preview.clusters || [])
      .slice(0, 8)
      .map((c) => `• ${c.keep.title} (+${c.duplicates.length})`)
      .join('\n');
    if (!confirm(
      `Encontradas ${preview.merged} cópia(s) duplicada(s).\n\n${names}\n\nMesclar automaticamente (mantém a versão mais completa)?`
    )) return;
    const result = await cleanupWorshipDuplicates({ app: this.app });
    this.stats = getWorshipStats();
    await this.refresh();
    this.toast(`${result.merged} duplicata(s) mesclada(s) e removida(s).`, 'success');
  }

  async saveDraftAndAddToCulto() {
    const saved = await this.saveDraft();
    if (!saved) return;
    await this.addToCulto(saved.id);
  }

  async duplicateSelected() {
    if (!this.selectedId) return;
    const copy = await duplicateWorshipSong(this.selectedId);
    if (copy) {
      await this.select(copy.id);
      this.toast('Música duplicada.');
    }
  }

  async restoreDefaultSong() {
    const id = this.selectedId || this.editor?.getDraft()?.id;
    if (!id) return;
    const draft = this.editor?.getDraft();
    if (!draft?.systemDefault && !draft?.protected) {
      this.toast('Só hinos padrão do sistema podem ser restaurados.', 'warn');
      return;
    }
    if (!this._defaultEdited) {
      const live = this.editor?.getDraft();
      if (live?.id === id) {
        this._defaultEdited = await hasDefaultHinarioEdits(live);
      }
    }
    if (!this._defaultEdited) {
      this.toast('Este hino já está com a letra original.', 'success');
      return;
    }
    if (!confirm('Restaurar letra, cifra e metadados originais deste hino?\n\nSuas preferências de projeção e estatísticas de uso serão mantidas.')) {
      return;
    }
    try {
      const restored = await restoreSystemDefaultSong(id);
      this._defaultEdited = false;
      this._defaultEditedCache.set(restored.id, false);
      this.selectedId = restored.id;
      this.editor?.setDraft(restored, { openAssist: false, defaultEdited: false });
      this.stats = getWorshipStats();
      this.runSearch();
      this.callbacks.onSave?.(restored);
      this.app?.program?.clearSongCache?.();
      this.toast('Hino restaurado ao original do hinário.', 'success');
    } catch {
      this.toast('Não foi possível restaurar o hino original.', 'warn');
    }
  }

  async deleteSelected() {
    if (!this.selectedId) return;
    const song = await getWorshipSong(this.selectedId);
    if (song?.protected || song?.systemDefault) {
      this.toast('Este hino padrão do sistema não pode ser excluído. Você pode editar a letra ou duplicar.', 'warn');
      return;
    }
    if (!confirm('Excluir esta música permanentemente?')) return;
    try {
      await deleteWorshipSong(this.selectedId);
    } catch {
      this.toast('Não foi possível excluir este louvor.', 'warn');
      return;
    }
    this.selectedId = null;
    this.editor?.setDraft(null);
    this.stats = getWorshipStats();
    this.runSearch();
    this.callbacks.onDelete?.();
    this.toast('Música excluída.');
  }

  async addToCulto(songId) {
    const id = songId || this.selectedId;
    if (!id) {
      const draft = this.editor?.getDraft();
      if (draft?.title?.trim()) {
        const saved = await this.saveDraft();
        if (!saved) return;
        return this.addToCulto(saved.id);
      }
      return;
    }
    const song = await getWorshipSong(id);
    if (!song) return;
    // Sem override no item — tipografia/divisão vêm da biblioteca da música
    const item = createProgramItem('lyrics', { title: song.title, songId: song.id });
    if (item.data) {
      delete item.data.lyricsStyle;
      delete item.data.lyricsFx;
    }
    await this.app.insertProgramItem(item);
    await recordSongUsage(song.id);
    this.stats = getWorshipStats();
    this.toast(`"${song.title}" adicionada à ordem do culto.`);
    this.callbacks.onAddToCulto?.(song);
  }

  /** Projetar só se o louvor já estiver na ordem — não adiciona automaticamente. */
  async projectSong(songId) {
    const id = songId || this.selectedId;
    if (!id) return;
    const song = await getWorshipSong(id);
    if (!song) return;
    const idx = this.app.program?.items?.findIndex(
      (it) => it.slideType === 'lyrics' && it.songId === id
    ) ?? -1;
    if (idx < 0) {
      this.toast('Adicione à ordem do culto (+ Ordem) antes de projetar.', 'warn');
      return;
    }
    this.app.goToItem?.(idx);
    await this.app.program.rebuild?.();
    this.app.pushToProjector?.(true);
    this.app.refreshStage?.({ skipInspector: true });
    this.toast(`Projetando "${song.title}"`, 'success');
  }

  /** Abre o editor na aba Cifra (Stage) para colar ou buscar cifra. */
  async openChordEditor(songId) {
    const id = songId || this.selectedId;
    if (!id) return;
    await this.select(id);
    this.editor?.focusMainTab?.('chords');
    this.toast('Aba Cifra — busque no Cifra Club ou cole ChordPro manualmente.', 'info');
  }

  async toggleFav(id) {
    await toggleFavorite(id);
    this.stats = getWorshipStats();
    this.runSearch();
    if (this.selectedId === id) {
      const s = await getWorshipSong(id);
      this.editor?.setDraft(s, { openAssist: false });
    }
  }

  async handleImport(files) {
    const all = [];
    for (const file of files) {
      try {
        const ext = file.name.split('.').pop()?.toLowerCase();
        const items = ext === 'docx' ? await importDocxFile(file) : await importFile(file);
        all.push(...items);
      } catch (err) {
        this.toast(`Erro ao importar ${file.name}: ${err.message}`);
      }
    }
    if (!all.length) return;
    const saved = await importWorshipSongs(all);
    this.stats = getWorshipStats();
    this.runSearch();
    this.toast(`${saved.length} música(s) importada(s).`);
  }

  render() {
    this._virtualList?.dispose?.();
    this._virtualList = null;
    this._listDelegated = false;
    const returnBar = this.app._worshipReturnView === 'live' ? `
        <div class="worship-return-bar">
          <button type="button" class="btn btn-secondary btn-sm" id="wl-back-console">← Console ao vivo</button>
          <span class="worship-return-hint">Editor completo de louvores</span>
        </div>` : '';

    this.container.innerHTML = `
      <div class="worship-library worship-shell">
        ${returnBar}
        <aside class="worship-sidebar">
          <div class="worship-sidebar-top">
            <div class="worship-sidebar-head">
              <div class="worship-sidebar-brand">
                <span class="worship-sidebar-kicker">Biblioteca</span>
                <h2>Louvores</h2>
              </div>
              <button type="button" class="btn btn-primary btn-icon worship-sidebar-new" id="wl-new" title="Importar ou criar (Ctrl+N)">
                ${faIconRaw('plus', 'su-fa')}
              </button>
            </div>

            <div class="worship-search-panel">
              <label class="worship-search-field" for="wl-search">
                <span class="worship-search-ico" aria-hidden="true">${faIconRaw('search', 'su-fa su-fa--sm')}</span>
                <input type="search" id="wl-search" class="worship-search-input"
                  placeholder="Título, artista, tom, hinário ou letra…"
                  autocomplete="off" value="${esc(this.query || '')}" />
                <button type="button" class="worship-search-clear" id="wl-search-clear" title="Limpar busca" ${this.query ? '' : 'hidden'}>×</button>
              </label>
              <div class="worship-search-meta">
                <span id="wl-count">${this.stats?.total ?? 0} músicas</span>
                <button type="button" class="btn btn-ghost btn-sm" id="wl-import-studio" title="Estúdio de importação">Importar</button>
              </div>
            </div>

            <nav class="worship-filter-rail" id="wl-tabs" aria-label="Filtros da biblioteca">
              ${SIDEBAR_TABS.map((t) =>
                `<button type="button" data-tab="${t.id}" class="worship-filter-chip ${this.tab === t.id ? 'is-active' : ''}">
                  <span class="worship-filter-label">${t.label}</span>
                </button>`
              ).join('')}
            </nav>

            <div class="worship-hinarios-strip" id="wl-hinarios"></div>

            <div class="worship-list-head">
              <span class="worship-list-head-title">Resultados</span>
              <span class="worship-list-head-hint">Clique · duplo clique · ordem</span>
            </div>
          </div>

          <div class="worship-list" id="wl-list"></div>

          <details class="worship-organize-collapse" id="wl-organize" ${this._organizeExpanded ? 'open' : ''}>
            <summary class="worship-organize-collapse-summary">Organizar · categorias e listas</summary>
            <section class="worship-organize" aria-label="Organização da biblioteca">
              <div class="worship-organize-block" id="wl-categories"></div>
              <div class="worship-organize-block worship-organize-block--lists" id="wl-playlists"></div>
            </section>
          </details>

          <div class="worship-sidebar-foot">
            <div class="worship-import-export">
              <label class="btn btn-secondary btn-sm worship-foot-btn">Importar arquivo
                <input type="file" id="wl-import" accept=".txt,.html,.htm,.rtf,.docx,.json,.muf,.mufl" multiple hidden /></label>
              <button type="button" class="btn btn-secondary btn-sm worship-foot-btn" id="wl-import-mufl" title="Importar ou exportar .mufl (Holyrics)">.mufl</button>
              <button type="button" class="btn btn-secondary btn-sm worship-foot-btn" id="wl-export-lib">Exportar biblioteca</button>
              <button type="button" class="btn btn-ghost btn-sm worship-foot-btn" id="wl-cleanup-dupes" title="Mesclar músicas duplicadas">Limpar duplicatas</button>
            </div>
          </div>
        </aside>
        <main class="worship-main">
          <div class="worship-toolbar" id="wl-toolbar"></div>
          <div class="worship-editor-host" id="wl-editor"></div>
        </main>
      </div>`;

    this.editor = new WorshipEditor(this.container.querySelector('#wl-editor'), {
      onToast: (m, type) => this.toast(m, type),
      onSave: () => this.saveDraft(),
      onSaveAndAddToCulto: () => this.saveDraftAndAddToCulto(),
      onOpenImportStudio: () => this.openImportStudio(),
      onRestoreDefault: () => this.restoreDefaultSong(),
      onFetchChords: async (draft) => {
        const { fetchChordsForSong, chordFetchToastMessage } = await import('./lyrics-engine/providers/chord-fetch-provider.js');
        const fetched = await fetchChordsForSong({
          title: draft.title,
          artist: draft.artist || draft.composer,
          composer: draft.composer,
          category: draft.category,
          hinarioRefs: draft.hinarioRefs,
        });
        if (!fetched?.chordSource) {
          this.toast(chordFetchToastMessage(fetched), 'warn');
          return null;
        }
        return fetched;
      },
    });
    this.editor.mediaList = this.mediaList;
    this.editor.categories = this.categories;

    this.container.querySelector('#wl-back-console')?.addEventListener('click', () => {
      const songId = this.app._liveRestoreSongId ?? this.selectedId;
      this.app._worshipReturnView = null;
      this.app._liveRestoreSongId = songId || null;
      this.app.setView?.('live');
    });

    this.container.querySelector('#wl-new').onclick = () => this.openImportStudio();
    this.container.querySelector('#wl-import-studio')?.addEventListener('click', () => this.openImportStudio());
    this.container.querySelector('#wl-search').oninput = (e) => {
      this.query = e.target.value;
      const clearBtn = this.container.querySelector('#wl-search-clear');
      if (clearBtn) clearBtn.hidden = !String(this.query || '').trim();
      this.scheduleSearch();
    };
    this.container.querySelector('#wl-search-clear')?.addEventListener('click', () => {
      this.query = '';
      const input = this.container.querySelector('#wl-search');
      if (input) input.value = '';
      const clearBtn = this.container.querySelector('#wl-search-clear');
      if (clearBtn) clearBtn.hidden = true;
      this.runSearch();
      input?.focus();
    });
    this.container.querySelectorAll('#wl-tabs button').forEach((btn) => {
      btn.onclick = () => {
        this.tab = btn.dataset.tab;
        this.container.querySelectorAll('#wl-tabs button').forEach((b) =>
          b.classList.toggle('is-active', b === btn)
        );
        this.runSearch();
      };
    });

    this.container.querySelector('#wl-import').onchange = (e) => {
      if (e.target.files?.length) this.handleImport([...e.target.files]);
      e.target.value = '';
    };
    this.container.querySelector('#wl-import-mufl')?.addEventListener('click', () => this.openMuflPanel());
    this.container.querySelector('#wl-export-lib').onclick = () => {
      const songs = [...getWorshipSongMap().values()];
      downloadText('biblioteca-louvores.somosum.json', exportLibrarySomosum(songs));
    };
    this.container.querySelector('#wl-cleanup-dupes')?.addEventListener('click', () => {
      void this.cleanupDuplicates();
    });

    this.container.querySelector('#wl-organize')?.addEventListener('toggle', (e) => {
      this._organizeExpanded = e.target.open;
    });

    this.renderOrganize();
    this.renderToolbar();
    this.runSearch();
  }

  renderOrganize() {
    this.renderHinarios();
    this.renderCategories();
    this.renderPlaylists();
  }

  renderHinarios() {
    const host = this.container.querySelector('#wl-hinarios');
    if (!host) return;

    const hinTotal = this.stats?.hinarioTotal ?? 0;
    const counts = getHinarioCategoryCounts();
    const meta = this._worshipMeta || {};
    const packs = this._hinarioManifest?.packs || [];
    const hasPackCatalog = packs.length > 0;
    const installedPackCount = packs.filter((p) => isHinarioPackInstalled(meta, p.id)).length;
    const needsInstall = hinTotal === 0 && !this._installingHinarios;

    const chip = (value, label, count, active) => {
      const sigla = getHinarioSiglaForName(label);
      const pack = packs.find((p) => hinarioNamesEqual(p.category, label) || hinarioNamesEqual(p.name, label));
      const packInstalled = pack ? isHinarioPackInstalled(meta, pack.id) : count > 0;
      const dim = needsInstall && pack && !packInstalled;
      const shownCount = count || (packInstalled ? (pack?.count || 0) : 0);
      return `
      <button type="button" class="worship-cat-chip worship-hinario-chip ${active ? 'is-active' : ''} ${dim ? 'is-dim' : ''}" data-hinario="${esc(value)}"
        title="${esc(label)} · ${shownCount || pack?.count || 0} hinos${pack && !packInstalled ? ' · não instalado' : ''}">
        <span class="worship-cat-chip-name">${esc(sigla)}</span>
        <span class="worship-cat-chip-count">${shownCount || (pack && !packInstalled ? '—' : 0)}</span>
      </button>`;
    };

    host.innerHTML = `
      <div class="worship-hinarios-strip-head">
        <div>
          <h3 class="worship-organize-title">Hinários padrão</h3>
          <p class="worship-organize-hint">${hinTotal
            ? `${hinTotal} hinos · busque HC 571 ou toque na sigla`
            : hasPackCatalog
              ? `${installedPackCount}/${packs.length} hinários instalados · escolha quais deseja`
              : 'Instale o pack congregacional'}</p>
        </div>
        ${hasPackCatalog
          ? `<button type="button" class="btn btn-primary btn-sm" id="wl-install-hinarios">${needsInstall ? 'Escolher hinários…' : 'Gerenciar hinários…'}</button>`
          : ''}
        ${this._installingHinarios ? '<span class="worship-hinarios-loading">Instalando…</span>' : ''}
      </div>
      <div class="worship-cat-chips worship-hinario-chips" role="listbox" aria-label="Hinários congregacionais">
        ${DEFAULT_HINARIO_CATEGORIES.map((c) => {
          let n = counts.get(c) || 0;
          if (!n) {
            for (const [k, v] of counts.entries()) {
              if (hinarioNamesEqual(k, c)) { n = v; break; }
            }
          }
          return chip(c, c, n, this.selectedCategory === c || hinarioNamesEqual(this.selectedCategory, c));
        }).join('')}
      </div>`;

    host.querySelector('#wl-install-hinarios')?.addEventListener('click', () => {
      this.openHinarioInstaller();
    });

    host.querySelectorAll('[data-hinario]').forEach((btn) => {
      btn.addEventListener('click', async () => {
        const value = btn.dataset.hinario || '';
        const pack = packs.find((p) => p.category === value || p.name === value);
        if (needsInstall && pack && !isHinarioPackInstalled(meta, pack.id)) {
          this.openHinarioInstaller();
          return;
        }
        this.selectedCategory = this.selectedCategory === value ? '' : value;
        this.renderHinarios();
        this.renderCategories();
        this.runSearch();
      });
    });
  }

  renderCategories() {
    const host = this.container.querySelector('#wl-categories');
    if (!host) return;

    const counts = getUserCategoryCounts();
    const userTotal = this.stats?.userTotal ?? 0;
    const isHinarioCat = (name) => DEFAULT_HINARIO_CATEGORIES.some((c) => hinarioNamesEqual(c, name));
    const cats = (this.categories.length
      ? this.categories
      : [...counts.keys()].filter((c) => c !== '(sem categoria)'))
      .filter((c) => !isHinarioCat(c));
    const uncategorized = counts.get('(sem categoria)') || 0;
    const userCategoryActive = this.selectedCategory && !isHinarioCat(this.selectedCategory);

    const chip = (value, label, count, active) => `
      <button type="button" class="worship-cat-chip ${active ? 'is-active' : ''}" data-category="${esc(value)}"
        title="${esc(label)} · ${count}">
        <span class="worship-cat-chip-name">${esc(label)}</span>
        <span class="worship-cat-chip-count">${count}</span>
      </button>`;

    host.innerHTML = `
      <div class="worship-organize-head">
        <div>
          <h3 class="worship-organize-title">Suas categorias</h3>
          <p class="worship-organize-hint">Louvores próprios da igreja</p>
        </div>
        <button type="button" class="worship-organize-add" id="wl-add-category" title="Nova categoria">+</button>
      </div>
      <div class="worship-cat-chips" role="listbox" aria-label="Categorias">
        ${chip('', 'Todas', userTotal, !this.selectedCategory)}
        ${cats.map((c) => chip(c, c, counts.get(c) || 0, userCategoryActive && this.selectedCategory === c)).join('')}
        ${uncategorized ? chip('__none__', 'Sem categoria', uncategorized, userCategoryActive && this.selectedCategory === '__none__') : ''}
      </div>`;

    host.querySelector('#wl-add-category')?.addEventListener('click', async () => {
      const name = prompt('Nome da nova categoria:');
      if (!name?.trim()) return;
      this.categories = await addCategory(name.trim());
      this.renderCategories();
      if (this.editor) this.editor.categories = this.categories;
    });

    host.querySelectorAll('[data-category]').forEach((btn) => {
      btn.addEventListener('click', () => {
        const value = btn.dataset.category || '';
        this.selectedCategory = this.selectedCategory === value ? '' : value;
        this.renderHinarios();
        this.renderCategories();
        this.runSearch();
      });
    });
  }

  renderPlaylists() {
    const host = this.container.querySelector('#wl-playlists');
    if (!host) return;
    host.innerHTML = `
      <div class="worship-organize-head">
        <div>
          <h3 class="worship-organize-title">Listas do culto</h3>
          <p class="worship-organize-hint">Playlists para montar o programa</p>
        </div>
        <button type="button" class="worship-organize-add" id="wl-new-playlist" title="Nova lista">+</button>
      </div>
      <div class="worship-playlist-list">
        ${this.playlists.length ? this.playlists.map((p) => `
          <div class="worship-playlist-row ${p.id === this.activePlaylistId ? 'is-active' : ''}">
            <button type="button" class="worship-playlist-btn" data-id="${p.id}">
              <span class="worship-playlist-name">${esc(p.name)}</span>
              <span class="worship-playlist-count">${p.songIds?.length || 0}</span>
            </button>
            <button type="button" class="worship-playlist-del" data-del="${p.id}" title="Excluir lista" aria-label="Excluir lista">×</button>
          </div>`).join('') : '<p class="worship-organize-empty">Nenhuma lista ainda — use + para criar</p>'}
      </div>`;

    host.querySelector('#wl-new-playlist')?.addEventListener('click', async () => {
      const name = prompt('Nome da lista:');
      if (!name?.trim()) return;
      await savePlaylist({ name: name.trim(), songIds: [] });
      this.playlists = await getPlaylists();
      this.renderPlaylists();
    });

    host.querySelectorAll('.worship-playlist-btn').forEach((btn) => {
      btn.onclick = async () => {
        const id = btn.dataset.id;
        this.activePlaylistId = this.activePlaylistId === id ? null : id;
        const pl = this.playlists.find((p) => p.id === id);
        if (pl) {
          const songs = await Promise.all(pl.songIds.map((sid) => getWorshipSong(sid)));
          cachePlaylistSongs(id, songs.filter(Boolean));
        }
        this.renderPlaylists();
        this.runSearch();
      };
    });

    host.querySelectorAll('[data-del]').forEach((btn) => {
      btn.onclick = async (e) => {
        e.stopPropagation();
        if (!confirm('Excluir esta lista?')) return;
        await deletePlaylist(btn.dataset.del);
        if (this.activePlaylistId === btn.dataset.del) this.activePlaylistId = null;
        this.playlists = await getPlaylists();
        this.renderPlaylists();
        this.runSearch();
      };
    });
  }

  renderToolbar() {
    const tb = this.container.querySelector('#wl-toolbar');
    if (!tb) return;
    const has = !!this.selectedId || !!this.editor?.getDraft();
    const draft = this.editor?.getDraft?.();
    const isProtected = !!(draft?.protected || draft?.systemDefault);
    const showRestore = isProtected && this._defaultEdited;
    const hasLyrics = !!draft?.lyrics?.trim();
    const hasChords = !!draft?.chordSource?.trim();
    tb.innerHTML = has ? `
      <div class="worship-toolbar-primary">
        <button type="button" class="btn btn-primary" id="wl-save">Salvar</button>
        ${isProtected ? `<span class="worship-protected-badge" title="Hino padrão do sistema — editável, não excluível">Padrão do sistema${this._defaultEdited ? ' · editado' : ''}</span>` : ''}
        ${showRestore ? '<button type="button" class="btn btn-secondary" id="wl-restore-default" title="Voltar letra e cifra originais">Restaurar original</button>' : ''}
        <button type="button" class="btn btn-secondary" id="wl-import-toolbar" title="Estúdio de importação">Importar letra</button>
        <button type="button" class="btn btn-secondary" id="wl-fetch-chords-toolbar" title="Buscar cifra no Cifra Club">Buscar cifra</button>
        <button type="button" class="btn btn-secondary" id="wl-add-culto">+ Ordem</button>
        <button type="button" class="btn btn-secondary" id="wl-project">Projetar</button>
        <select id="wl-playlist-add" class="worship-select-sm" title="Adicionar à playlist">
          <option value="">＋ Lista</option>
          ${this.playlists.map((p) => `<option value="${p.id}">${esc(p.name)}</option>`).join('')}
        </select>
      </div>
      <div class="worship-toolbar-secondary">
        <div class="worship-toolbar-tracks" aria-label="Status das trilhas">
          <span class="lyrics-studio-track-chip ${hasLyrics ? 'is-ready' : 'is-empty'}">Letra</span>
          <span class="lyrics-studio-track-chip ${hasChords ? 'is-ready' : 'is-empty'}">Cifra</span>
        </div>
        <button type="button" class="btn btn-ghost btn-sm" id="wl-chord-tab" title="Aba Cifra">Cifra</button>
        <button type="button" class="btn btn-secondary btn-sm" id="wl-duplicate" title="Ctrl+D">Duplicar</button>
        <button type="button" class="btn btn-secondary btn-sm" id="wl-print" title="Imprimir letra A4">Imprimir</button>
        <div class="worship-export-menu">
          <button type="button" class="btn btn-secondary btn-sm" id="wl-export-toggle">Exportar ▾</button>
          <div class="worship-export-dropdown" id="wl-export-dd" hidden>
            <button type="button" data-exp="txt">TXT</button>
            <button type="button" data-exp="docx">DOCX</button>
            <button type="button" data-exp="print">Imprimir A4</button>
            <button type="button" data-exp="somosum">SOMOSUM JSON</button>
            <button type="button" data-exp="mufl">.mufl</button>
          </div>
        </div>
        <button type="button" class="btn btn-danger btn-sm" id="wl-delete" ${isProtected ? 'hidden' : ''}>Excluir</button>
      </div>
    ` : `<p class="worship-toolbar-empty muted">Crie ou selecione um louvor para editar.</p>`;

    tb.querySelector('#wl-save')?.addEventListener('click', () => this.saveDraft());
    tb.querySelector('#wl-restore-default')?.addEventListener('click', () => this.restoreDefaultSong());
    tb.querySelector('#wl-import-toolbar')?.addEventListener('click', () => this.openImportStudio());
    tb.querySelector('#wl-fetch-chords-toolbar')?.addEventListener('click', () => {
      this.editor?.focusMainTab?.('chords');
      requestAnimationFrame(() => {
        this.container.querySelector('#we-fetch-chords')?.click();
      });
    });
    tb.querySelector('#wl-add-culto')?.addEventListener('click', () => this.addToCulto());
    tb.querySelector('#wl-project')?.addEventListener('click', () => this.projectSong());
    tb.querySelector('#wl-chord-tab')?.addEventListener('click', () => this.openChordEditor());
    tb.querySelector('#wl-duplicate')?.addEventListener('click', () => this.duplicateSelected());
    tb.querySelector('#wl-delete')?.addEventListener('click', () => this.deleteSelected());
    tb.querySelector('#wl-print')?.addEventListener('click', () => {
      void (async () => {
        let song = this.editor?.getDraft?.();
        if (!song?.lyrics?.trim() && this.selectedId) {
          song = await getWorshipSong(this.selectedId) || song;
        }
        if (!song?.lyrics?.trim()) {
          this.toast('Nenhuma letra para imprimir.', 'warn');
          return;
        }
        openLyricsPrintStudio({ song, onToast: (m, t) => this.toast(m, t) });
      })();
    });

    const toggle = tb.querySelector('#wl-export-toggle');
    const dd = tb.querySelector('#wl-export-dd');
    toggle?.addEventListener('click', (e) => {
      e.stopPropagation();
      if (!dd) return;
      dd.hidden = !dd.hidden;
    });
    dd?.querySelectorAll('[data-exp]').forEach((btn) => {
      btn.onclick = () => {
        const s = this.editor?.getDraft();
        if (!s) return;
        const kind = btn.dataset.exp;
        if (kind === 'txt') downloadText(`${s.title || 'musica'}.txt`, exportSongTxt(s));
        else if (kind === 'docx') exportSongDocx(s);
        else if (kind === 'print') {
          void (async () => {
            let song = s;
            if (!song.lyrics?.trim() && song.id) {
              song = await getWorshipSong(song.id) || song;
            }
            openLyricsPrintStudio({ song, onToast: (m, t) => this.toast(m, t) });
          })();
        }
        else if (kind === 'somosum') downloadText(`${s.title || 'musica'}.somosum.json`, exportSongSomosum(s));
        else if (kind === 'mufl') {
          void import('./holyrics-mufl.js').then(async ({ encodeHolyricsMuflFromSong, holyricsMuflFileName }) => {
            const bytes = await encodeHolyricsMuflFromSong(s);
            downloadText(holyricsMuflFileName(s), bytes, 'application/octet-stream');
            this.toast(`Exportado: ${holyricsMuflFileName(s)}`, 'success');
          }).catch((err) => this.toast(err.message || 'Erro ao exportar .mufl', 'warn'));
        }
        dd.hidden = true;
      };
    });

    tb.querySelector('#wl-playlist-add')?.addEventListener('change', async (e) => {
      const plId = e.target.value;
      let songId = this.selectedId || this.editor?.getDraft()?.id;
      if (!plId) return;
      if (!songId && this.editor?.getDraft()?.title?.trim()) {
        const saved = await this.saveDraft();
        songId = saved?.id;
        this.selectedId = saved?.id;
      }
      if (!songId) return;
      await addSongToPlaylist(plId, songId);
      this.playlists = await getPlaylists();
      this.renderPlaylists();
      this.toast('Adicionada à lista.');
      e.target.value = '';
    });
  }

  renderList() {
    const list = this.container.querySelector('#wl-list');
    const count = this.container.querySelector('#wl-count');
    if (!list) return;
    if (count) {
      const user = this.stats?.userTotal ?? 0;
      const hin = this.stats?.hinarioTotal ?? 0;
      count.textContent = `${this._results.length} exibidas · ${user} suas · ${hin} hinário`;
    }

    this.bindListDelegation(list);

    if (!this._results.length) {
      this._virtualList?.dispose?.();
      this._virtualList = null;
      const q = (this.query || '').trim();
      const hinarioSel = DEFAULT_HINARIO_CATEGORIES.some((c) => hinarioNamesEqual(c, this.selectedCategory));
      const needsInstall = (this.stats?.hinarioTotal ?? 0) === 0;
      let hint = 'Suas músicas aparecem aqui. Para hinários: pesquise <strong>HC 571</strong> ou clique em uma coleção acima.';
      if (needsInstall) {
        hint = 'Hinários ainda não instalados. Clique <strong>Instalar</strong> acima ou busque suas músicas.';
      } else if (q) hint = `Nenhum resultado para “${esc(q)}”. Tente número do hinário (CC 15) ou parte da letra.`;
      else if (hinarioSel) hint = 'Nenhum hino nesta coleção — tente reinstalar o pack de hinários.';
      else if (this.selectedCategory) hint = 'Nenhum louvor nesta categoria.';
      list.innerHTML = `<div class="worship-empty">${hint}</div>`;
      this.renderToolbar();
      return;
    }

    const rowHeight = 56;
    const renderRow = (s) => {
      const hinario = formatHinarioRefsList(s.hinarioRefs);
      const metaParts = [hinario, s.artist, s.key, s.category].filter(Boolean);
      return `
      <div class="worship-song-item ${s.id === this.selectedId ? 'is-active' : ''}" data-id="${esc(s.id)}" title="Clique = editar · Duplo clique = ordem">
        <button type="button" class="worship-fav-btn ${s.favorite ? 'is-on' : ''}" data-fav="${esc(s.id)}" title="Favorita">★</button>
        <div class="worship-song-body">
          <div class="worship-song-title">${esc(s.title)}${hinario ? ` <span class="worship-hinario-badge">${esc(hinario)}</span>` : ''}${s.systemDefault ? ' <span class="worship-hinario-badge worship-hinario-badge--sys">Padrão</span>' : ''}</div>
          <div class="worship-song-meta">${esc(metaParts.join(' · ') || '—')}</div>
        </div>
      </div>`;
    };

    if (this._virtualList) {
      this._virtualList.refresh(this._results);
    } else {
      this._virtualList = mountVirtualList(list, {
        items: this._results,
        rowHeight,
        renderRow,
      });
    }
    this.renderToolbar();
  }

  /** Clique / duplo-clique / favorito — uma vez no host (virtual list troca nós). */
  bindListDelegation(list) {
    if (!list || this._listDelegated) return;
    this._listDelegated = true;
    list.addEventListener('click', (e) => {
      const fav = e.target.closest?.('[data-fav]');
      if (fav) {
        e.stopPropagation();
        this.toggleFav(fav.getAttribute('data-fav'));
        return;
      }
      const item = e.target.closest?.('.worship-song-item');
      if (!item?.dataset?.id) return;
      this.select(item.dataset.id);
      this.renderToolbar();
    });
    list.addEventListener('dblclick', (e) => {
      if (e.target.closest?.('.worship-fav-btn')) return;
      const item = e.target.closest?.('.worship-song-item');
      if (!item?.dataset?.id) return;
      e.preventDefault();
      this.addToCulto(item.dataset.id);
    });
    list.addEventListener('contextmenu', (e) => {
      const item = e.target.closest?.('.worship-song-item');
      if (!item?.dataset?.id) return;
      e.preventDefault();
      const id = item.dataset.id;
      const song = getWorshipSongMap().get(id);
      openContextMenu(e.clientX, e.clientY, [
        { label: 'Visualizar / Editar', action: () => this.select(id) },
        { label: 'Adicionar à ordem do culto', action: () => this.addToCulto(id) },
        { label: 'Projetar (se já na ordem)', action: () => this.projectSong(id) },
        { sep: true },
        { label: 'Adicionar / editar cifra (Stage)…', action: () => this.openChordEditor(id) },
        { label: 'Importar letra…', action: () => this.openImportStudio() },
        { label: 'Imprimir letra (A4)…', action: async () => {
          const full = await getWorshipSong(id);
          if (full) openLyricsPrintStudio({ song: full, onToast: (m, t) => this.toast(m, t) });
        } },
        ...(song?.protected || song?.systemDefault ? [{
          label: 'Restaurar letra original',
          action: () => { this.selectedId = id; this.restoreDefaultSong(); },
        }] : []),
        ...(song?.protected || song?.systemDefault ? [] : [{
          label: 'Excluir',
          danger: true,
          action: () => { this.selectedId = id; this.deleteSelected(); },
        }]),
      ]);
    });
  }
}
