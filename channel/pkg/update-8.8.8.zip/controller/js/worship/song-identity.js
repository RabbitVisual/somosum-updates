/**
 * Identidade e detecção de duplicatas na Biblioteca de Louvores.
 * Normaliza título/artista (hinário, acentos, pontuação) para matching profissional.
 */

function stripAccents(s) {
  return String(s || '')
    .normalize('NFD')
    .replace(/\p{M}/gu, '');
}

/** Remove sufixo de hinário e ruído comum de títulos. */
export function normalizeSongTitle(title) {
  return stripAccents(title)
    .toLowerCase()
    .replace(/[''`´]/g, '')
    .replace(/\s*[-–—]\s*(?:hc|cc|hcc|h\s*c)?\s*\d+\s*$/i, '')
    .replace(/\s*\(\s*(?:c[oó]pia|copy|2|ii)\s*\)\s*$/i, '')
    .replace(/[^a-z0-9\s]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

export function normalizeSongArtist(artist) {
  return stripAccents(artist)
    .toLowerCase()
    .replace(/[''`´]/g, '')
    .replace(/[^a-z0-9\s]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

/** Chave estável título|artista para Set/Map. */
export function songIdentityKey(songOrTitle, artistMaybe) {
  const title = typeof songOrTitle === 'object'
    ? songOrTitle?.title
    : songOrTitle;
  const artist = typeof songOrTitle === 'object'
    ? (songOrTitle?.artist || songOrTitle?.author || '')
    : (artistMaybe || '');
  return `${normalizeSongTitle(title)}|${normalizeSongArtist(artist)}`;
}

/** Fingerprint leve da letra (primeiras linhas significativas). */
export function lyricsFingerprint(lyrics) {
  const lines = String(lyrics || '')
    .replace(/\r\n/g, '\n')
    .split('\n')
    .map((l) => stripAccents(l).toLowerCase().replace(/[^a-z0-9\s]/g, '').trim())
    .filter((l) => l.length > 2)
    .slice(0, 6);
  return lines.join('|');
}

/**
 * Pontua quão similar `candidate` é a `existing`.
 * @returns {number} 0–1
 */
export function scoreSongSimilarity(candidate, existing) {
  if (!candidate || !existing) return 0;
  const ct = normalizeSongTitle(candidate.title);
  const et = normalizeSongTitle(existing.title);
  if (!ct || !et) return 0;

  let score = 0;
  if (ct === et) score += 0.55;
  else if (ct.includes(et) || et.includes(ct)) score += 0.35;
  else return 0;

  const ca = normalizeSongArtist(candidate.artist || candidate.author);
  const ea = normalizeSongArtist(existing.artist || existing.author);
  if (ca && ea) {
    if (ca === ea) score += 0.35;
    else if (ca.includes(ea) || ea.includes(ca)) score += 0.22;
    else score -= 0.15;
  } else {
    score += 0.12; // artista ausente — título forte ainda vale
  }

  const cf = lyricsFingerprint(candidate.lyrics);
  const ef = lyricsFingerprint(existing.lyrics);
  if (cf && ef && cf === ef) score += 0.15;
  else if (cf && ef && (cf.includes(ef.slice(0, 40)) || ef.includes(cf.slice(0, 40)))) {
    score += 0.08;
  }

  return Math.max(0, Math.min(1, score));
}

/**
 * Encontra possíveis duplicatas na biblioteca.
 * @param {object} candidate
 * @param {Iterable<object>} library
 * @param {{ excludeId?: string, minScore?: number }} [opts]
 */
export function findDuplicateSongs(candidate, library, { excludeId = null, minScore = 0.72 } = {}) {
  const list = Array.isArray(library) ? library : [...(library || [])];
  const hits = [];
  for (const song of list) {
    if (!song?.id) continue;
    if (excludeId && song.id === excludeId) continue;
    const score = scoreSongSimilarity(candidate, song);
    if (score >= minScore) {
      hits.push({ song, score });
    }
  }
  hits.sort((a, b) => b.score - a.score);
  return hits;
}

export function findBestDuplicate(candidate, library, opts = {}) {
  return findDuplicateSongs(candidate, library, opts)[0] || null;
}

/** Heurística: qual cópia é a “melhor” para manter. */
export function pickRicherSong(a, b) {
  const richness = (s) => {
    let n = 0;
    if (s.lyrics?.trim()) n += 3 + Math.min(4, Math.floor(String(s.lyrics).length / 400));
    if (s.chordSource?.trim()) n += 4;
    if (s.key) n += 1;
    if (s.category) n += 1;
    if (s.artist) n += 1;
    if (s.hinarioRefs?.length) n += 1;
    if (s.bpm) n += 0.5;
    if (s.favorite) n += 0.5;
    n += Math.min(2, (s.useCount || 0) * 0.2);
    return n;
  };
  return richness(a) >= richness(b) ? a : b;
}

/**
 * Mescla campos úteis de `donor` em `keeper` sem apagar conteúdo bom.
 */
export function mergeSongFields(keeper, donor) {
  const out = { ...keeper };
  const takeIfEmpty = (field) => {
    if (!String(out[field] || '').trim() && String(donor[field] || '').trim()) {
      out[field] = donor[field];
    }
  };
  ['subtitle', 'artist', 'composer', 'ministry', 'key', 'language', 'category', 'theme', 'notes', 'ccliNumber']
    .forEach(takeIfEmpty);
  if (donor.lyrics?.trim()) {
    const donorBreaks = (String(donor.lyrics).match(/\n\n/g) || []).length;
    const keepBreaks = (String(out.lyrics || '').match(/\n\n/g) || []).length;
    const longer = donor.lyrics.length > (out.lyrics || '').length * 1.15;
    if (!out.lyrics?.trim() || donorBreaks > keepBreaks || longer) {
      out.lyrics = donor.lyrics;
      if (donor.sections?.length) out.sections = donor.sections;
      if (donor.blocks?.length) out.blocks = donor.blocks;
    }
  }
  if (!out.chordSource?.trim() && donor.chordSource?.trim()) out.chordSource = donor.chordSource;
  if ((!out.blocks || !out.blocks.length) && donor.blocks?.length) out.blocks = donor.blocks;
  if ((!out.sections || !out.sections.length) && donor.sections?.length) out.sections = donor.sections;
  if (donor.style && typeof donor.style === 'object' && Object.keys(donor.style).length) {
    out.style = { ...(out.style && typeof out.style === 'object' ? out.style : {}), ...donor.style };
  }
  if ((!out.hinarioRefs || !out.hinarioRefs.length) && donor.hinarioRefs?.length) {
    out.hinarioRefs = donor.hinarioRefs;
  }
  if ((!out.tags || !out.tags.length) && donor.tags?.length) out.tags = donor.tags;
  if (!out.bpm && donor.bpm) out.bpm = donor.bpm;
  if (!out.capo && donor.capo) out.capo = donor.capo;
  out.favorite = !!(out.favorite || donor.favorite);
  out.useCount = Math.max(out.useCount || 0, donor.useCount || 0);
  out.lastUsedAt = Math.max(out.lastUsedAt || 0, donor.lastUsedAt || 0) || null;
  out.updatedAt = Date.now();
  return out;
}

/**
 * Agrupa biblioteca em clusters de duplicatas (id → grupo).
 * @returns {Array<{ keep: object, duplicates: object[] }>}
 */
export function clusterDuplicateSongs(library) {
  const list = [...(library || [])].filter(
    (s) => s?.id && s?.title && !s?.protected && !s?.systemDefault,
  );
  const used = new Set();
  const clusters = [];

  for (let i = 0; i < list.length; i += 1) {
    const a = list[i];
    if (used.has(a.id)) continue;
    const group = [a];
    used.add(a.id);
    for (let j = i + 1; j < list.length; j += 1) {
      const b = list[j];
      if (used.has(b.id)) continue;
      if (scoreSongSimilarity(a, b) >= 0.72) {
        group.push(b);
        used.add(b.id);
      }
    }
    if (group.length > 1) {
      let keep = group[0];
      for (let k = 1; k < group.length; k += 1) keep = pickRicherSong(keep, group[k]);
      clusters.push({
        keep,
        duplicates: group.filter((s) => s.id !== keep.id),
      });
    }
  }
  return clusters;
}
