import { normalizeSong } from '../worship-schema.js';
import { sectionsToSongLyricsAndBlocks, stripSectionMarkerLines } from './lyrics-projection-text.js';
import {
  saveWorshipSong,
  forceSaveWorshipSong,
  findWorshipDuplicates,
  getWorshipSong,
} from '../worship-store.js';
import { generateId } from '../../core/store.js';
import { randomId } from '../../core/uuid.js';
import { mergeSongFields } from '../song-identity.js';
import { formatLyricsForSlides } from '../../lyrics/lyrics-splitter.js';
import { organizeLyricsForWorship } from '../worship-parser.js';

const DEFAULT_IMPORT_STYLE = Object.freeze({
  splitMode: 'lines',
  linesPerSlide: 4,
  stanzasPerSlide: 1,
});

function resolveImportStyle(normalized = {}) {
  const raw = normalized.style && typeof normalized.style === 'object' ? normalized.style : {};
  const splitMode = raw.splitMode === 'stanzas' ? 'stanzas' : 'lines';
  const linesPerSlide = [2, 4, 6].includes(Number(raw.linesPerSlide))
    ? Number(raw.linesPerSlide)
    : DEFAULT_IMPORT_STYLE.linesPerSlide;
  const stanzasPerSlide = Math.max(1, Math.min(3, Number(raw.stanzasPerSlide) || 1));
  return { splitMode, linesPerSlide, stanzasPerSlide };
}

export function mapToSomosumSong(normalized, { id } = {}) {
  const sections = normalized.sections || [];
  let { lyrics, blocks } = sections.length
    ? sectionsToSongLyricsAndBlocks(sections)
    : { lyrics: stripSectionMarkerLines(normalized.plainLyrics || ''), blocks: [] };

  lyrics = organizeLyricsForWorship(lyrics || stripSectionMarkerLines(normalized.plainLyrics || ''));
  const style = resolveImportStyle(normalized);
  if (lyrics.trim() && (style.splitMode === 'lines' || style.splitMode === 'stanzas')) {
    lyrics = formatLyricsForSlides(lyrics, style);
  }

  return normalizeSong({
    id: id || generateId() || randomId(),
    title: normalized.title,
    artist: normalized.artist,
    composer: normalized.composer || '',
    language: normalized.language || 'Português',
    lyrics,
    chordSource: normalized.chordSource || '',
    key: normalized.key || '',
    bpm: normalized.bpm ?? null,
    capo: normalized.capo ?? 0,
    category: normalized.category || '',
    blocks,
    sections,
    source: normalized.source,
    importMeta: normalized.importMeta,
    style,
    tags: ['importado', 'lyrics-engine', ...(normalized.tags || [])].filter(Boolean),
  });
}

/**
 * Importa letra/cifra com proteção anti-duplicata.
 */
export async function importNormalizedSong(normalized, {
  addToProgram = false,
  app,
  onDuplicate,
} = {}) {
  const incoming = mapToSomosumSong(normalized);
  // Sempre gera candidato sem id fixo na busca — matching por título/artista
  const probe = { ...incoming, id: '' };
  const best = findWorshipDuplicates(probe)[0];

  let song;
  if (best) {
    const choice = (await onDuplicate?.({
      existing: best.song,
      incoming,
      score: best.score,
    })) ?? defaultDuplicateChoice({ existing: best.song, incoming });

    if (choice === 'cancel' || choice == null) {
      const err = new Error('duplicate_cancelled');
      err.code = 'duplicate_cancelled';
      err.existing = best.song;
      throw err;
    }
    if (choice === 'update') {
      const existing = await getWorshipSong(best.song.id);
      const merged = normalizeSong(mergeSongFields(existing || best.song, incoming));
      merged.id = best.song.id;
      song = await forceSaveWorshipSong(merged);
    } else if (choice === 'keep-both') {
      song = await forceSaveWorshipSong(incoming);
    } else {
      const err = new Error('duplicate_cancelled');
      err.code = 'duplicate_cancelled';
      err.existing = best.song;
      throw err;
    }
  } else {
    const result = await saveWorshipSong(incoming);
    song = result.song;
  }

  if (addToProgram && app) {
    const { createProgramItem } = await import('../../program/programa-templates.js');
    const item = createProgramItem('lyrics', { title: song.title, songId: song.id });
    if (item.data) {
      delete item.data.lyricsStyle;
      delete item.data.lyricsFx;
    }
    await app.insertProgramItem(item);
    app.program?.clearSongCache?.();
  }

  return song;
}

/** Diálogo padrão para resolução de duplicata. */
export function defaultDuplicateChoice({ existing, incoming }) {
  const artist = existing.artist ? ` — ${existing.artist}` : '';
  const msg = [
    'Esta música já existe na biblioteca:',
    '',
    `“${existing.title}”${artist}`,
    '',
    `Nova importação: “${incoming.title}”${incoming.artist ? ` — ${incoming.artist}` : ''}`,
    '',
    'OK = atualizar a existente (recomendado)',
    'Cancelar = não salvar duplicata',
  ].join('\n');
  return confirm(msg) ? 'update' : 'cancel';
}
