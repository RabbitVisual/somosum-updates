import { createLyricsSection } from './models/lyrics-section.js';
import { sectionsToSongLyricsAndBlocks } from './lyrics-projection-text.js';
import { detectSections, detectSectionsFromBlocks } from './lyrics-section-detector.js';
import { dedupeAdjacentParagraphs } from './lyrics-deduplicator.js';
import { computeImportConfidence } from './lyrics-confidence.js';
import { organizeLyricsForWorship } from '../worship-parser.js';

export function normalizeLyricsPipeline(plainText, { matchScore = 0.5 } = {}) {
  // Preserva refrões repetidos para detecção; só limpa chrome adjacente.
  const cleaned = organizeLyricsForWorship(dedupeAdjacentParagraphs(plainText));
  let sections = detectSections(cleaned);
  if (!sections.length) sections = detectSectionsFromBlocks(cleaned);

  const { lyrics, blocks } = sectionsToSongLyricsAndBlocks(sections);
  const confidence = computeImportConfidence(sections, matchScore);

  return {
    plainLyrics: lyrics || cleaned,
    sections: sections.map((s) => createLyricsSection({
      ...s,
      confidence: s.confidence < 0.5 && confidence > 0.5 ? s.confidence : s.confidence,
    })),
    blocks,
    confidence,
  };
}

export function updateSectionType(sections, index, newType) {
  return sections.map((s, i) => (i === index ? createLyricsSection({ ...s, type: newType }) : s));
}

export function mergeSections(sections, indexA, indexB) {
  const out = [...sections];
  const a = out[indexA];
  const b = out[indexB];
  if (!a || !b) return sections;
  out[indexA] = createLyricsSection({
    ...a,
    lines: [...(a.lines || []), '', ...(b.lines || [])],
  });
  out.splice(indexB, 1);
  return out;
}

export function splitSection(sections, index, lineIndex) {
  const sec = sections[index];
  if (!sec) return sections;
  const lines = [...(sec.lines || [])];
  const first = lines.slice(0, lineIndex);
  const second = lines.slice(lineIndex);
  const out = [...sections];
  out[index] = createLyricsSection({ ...sec, lines: first });
  out.splice(index + 1, 0, createLyricsSection({ type: 'unknown', label: '', lines: second, confidence: 0.4 }));
  return out;
}
