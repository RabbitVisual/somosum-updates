import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { cleanPastedLyrics } from '../../worship-parser.js';
import { normalizeLyricsPipeline } from '../lyrics-normalizer.js';
import { mapToSomosumSong } from '../lyrics-import-service.js';

const SAMPLE = `Deus não rejeita oração, oração é alimento
Nunca vi um justo sem resposta ou ficar no sofrimento
Basta somente esperar o que Deus irá fazer
Quando Ele estende Suas mãos, é a hora de vencer

Então, louve
Simplesmente louve
Tá chorando, louve
Precisando, louve
Tá sofrendo, louve
Não importa, louve
Seu louvor invade o céu

Deus vai na frente abrindo o caminho
Quebrando as correntes, tirando os espinhos`;

describe('lyrics stanza preserve', () => {
  it('cleanPastedLyrics keeps blank stanza separators', () => {
    const cleaned = cleanPastedLyrics(SAMPLE);
    assert.ok(cleaned.includes('\n\n'), 'deve manter \\n\\n entre estrofes');
    assert.ok(!cleaned.includes('vencer Então'), 'não pode colar fim de verso no refrão');
    assert.match(cleaned, /vencer\n\nEntão, louve/);
  });

  it('normalizeLyricsPipeline detects multiple sections from blank lines', () => {
    const cleaned = cleanPastedLyrics(SAMPLE);
    const { sections, plainLyrics } = normalizeLyricsPipeline(cleaned);
    assert.ok(sections.length >= 2, `esperado ≥2 seções, veio ${sections.length}`);
    assert.ok(plainLyrics.includes('\n\n'));
  });

  it('mapToSomosumSong stores style and formats by linesPerSlide', () => {
    const cleaned = cleanPastedLyrics(SAMPLE);
    const pipe = normalizeLyricsPipeline(cleaned);
    const song = mapToSomosumSong({
      title: 'Com Muito Louvor',
      artist: 'Cassiane',
      plainLyrics: pipe.plainLyrics,
      sections: pipe.sections,
      style: { splitMode: 'lines', linesPerSlide: 4 },
    });
    assert.equal(song.style.splitMode, 'lines');
    assert.equal(song.style.linesPerSlide, 4);
    assert.ok(song.lyrics.includes('\n\n'), 'letra salva deve ter blocos de slide');
  });
});
