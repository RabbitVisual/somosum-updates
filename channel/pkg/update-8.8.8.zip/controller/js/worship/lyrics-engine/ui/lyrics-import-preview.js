import { BLOCK_TYPES, DEFAULT_CATEGORIES } from '../../worship-schema.js';
import { createLyricsSection } from '../models/lyrics-section.js';
import { sectionsToProjectionLyrics, sectionsToSongLyricsAndBlocks } from '../lyrics-projection-text.js';
import { updateSectionType, mergeSections } from '../lyrics-normalizer.js';
import { averageSectionConfidence } from '../lyrics-section-detector.js';
import { openContextMenu } from '../../../ui/kit/context-menu.js';
import { suggestLinesPerSlide } from '../../worship-parser.js';

function esc(t) {
  const d = document.createElement('div');
  d.textContent = t ?? '';
  return d.innerHTML;
}

function escAttr(t) {
  return esc(t).replace(/"/g, '&quot;');
}

function confClass(c) {
  const n = Number(c) || 0;
  if (n >= 0.75) return 'is-high';
  if (n >= 0.5) return 'is-mid';
  return 'is-low';
}

/** Pré-visualização editável por estrofes (verso, refrão, ponte…). */
export class LyricsImportPreview {
  constructor(container, { onChange, onToast } = {}) {
    this.container = container;
    this.onChange = onChange;
    this.onToast = onToast || (() => {});
    this.normalized = null;
    this._previewTab = 'structure';
    /** Busca cifra: idle | loading | results | preview */
    this._cifraPhase = 'idle';
    this._cifraCandidates = [];
    this._cifraPreview = null;
    this._cifraSelectedUrl = '';
    this._cifraBusy = false;
    this.categories = [...DEFAULT_CATEGORIES];
    /** Como salvar/dividir slides na biblioteca e no projetor. */
    this._formatStyle = { splitMode: 'lines', linesPerSlide: 4, stanzasPerSlide: 1 };
  }

  setCategories(categories = []) {
    this.categories = categories?.length ? [...categories] : [...DEFAULT_CATEGORIES];
  }

  setNormalized(normalized) {
    this.normalized = normalized
      ? { ...normalized, sections: (normalized.sections || []).map((s) => ({ ...s, lines: [...(s.lines || [])] })) }
      : null;
    if (normalized?.chordSource?.trim()) {
      this._cifraPhase = 'idle';
      this._cifraPreview = null;
    }
    // Sugestão inteligente de linhas/slide a partir das estrofes importadas
    if (normalized && !normalized.style?.linesPerSlide) {
      const plain = normalized.plainLyrics
        || (normalized.sections || []).map((s) => (s.lines || []).join('\n')).join('\n\n');
      this._formatStyle = {
        ...this._formatStyle,
        linesPerSlide: suggestLinesPerSlide(plain),
        splitMode: 'lines',
      };
    }
    this.render();
  }

  /** Busca candidatos no Cifra Club após carregar letra (não aplica automaticamente). */
  async autoSearchCifra() {
    const n = this.normalized;
    if (!n || n.chordSource?.trim() || this._cifraBusy) return;
    await this.startCifraSearch({ auto: true });
  }

  async startCifraSearch({ auto = false } = {}) {
    const n = this.normalized;
    if (!n || this._cifraBusy) return;
    const title = String(n.title || '').trim();
    if (!title) {
      this.onToast('Informe o título antes de buscar cifra.', 'warn');
      return;
    }
    if (!auto) this._previewTab = 'chords';
    this._cifraPhase = 'loading';
    this._cifraCandidates = [];
    this._cifraPreview = null;
    this._cifraSelectedUrl = '';
    this.render();

    this._cifraBusy = true;
    try {
      const { searchCifraClubCandidates } = await import('../providers/chord-fetch-provider.js');
      const songInfo = {
        title,
        artist: n.artist || '',
        composer: n.composer || '',
        category: n.category || '',
        hinarioRefs: n.hinarioRefs || [],
      };
      const hits = await searchCifraClubCandidates(title, n.artist || '', { songInfo });
      this._cifraCandidates = hits;
      this._cifraPhase = hits.length ? 'results' : 'empty';
      if (!hits.length) {
        if (!auto) this.onToast('Nenhuma cifra encontrada — confira título/artista/hinário ou cole manualmente.', 'warn');
      } else if (auto) {
        this.onToast(`${hits.length} cifra(s) no Cifra Club — abra a aba Cifra (Stage) para escolher.`, 'info');
      }
    } catch (err) {
      this._cifraPhase = 'empty';
      this.onToast(`Busca de cifra falhou: ${err.message}`, 'warn');
    } finally {
      this._cifraBusy = false;
      this.render();
    }
  }

  async previewCifraCandidate(hit) {
    if (!hit?.url || this._cifraBusy) return;
    this._cifraSelectedUrl = hit.url;
    this._cifraPhase = 'loading';
    this.render();

    this._cifraBusy = true;
    try {
      const { fetchCifraFromUrl } = await import('../providers/chord-fetch-provider.js');
      const n = this.normalized;
      const fetched = await fetchCifraFromUrl(hit.url, {
        title: hit.title || n?.title,
        artist: hit.artist || n?.artist,
      });
      if (!fetched?.chordSource) {
        this._cifraPhase = 'results';
        this.onToast('Não foi possível extrair a cifra desta página.', 'warn');
        return;
      }
      this._cifraPreview = {
        ...fetched,
        matchTitle: hit.title,
        matchArtist: hit.artist,
      };
      this._cifraPhase = 'preview';
    } catch (err) {
      this._cifraPhase = 'results';
      this.onToast(`Erro ao carregar cifra: ${err.message}`, 'warn');
    } finally {
      this._cifraBusy = false;
      this.render();
    }
  }

  applyCifraPreview() {
    const p = this._cifraPreview;
    if (!p?.chordSource || !this.normalized) return;
    this.normalized.chordSource = p.chordSource;
    if (p.key) this.normalized.key = p.key;
    if (p.capo != null) this.normalized.capo = p.capo;
    if (p.bpm != null) this.normalized.bpm = p.bpm;
    if (Array.isArray(p.chordShapes)) this.normalized.chordShapes = p.chordShapes;
    if (p.tuning) this.normalized.tuning = p.tuning;
    this.normalized.chordSourceUrl = p.sourceUrl || this._cifraSelectedUrl;
    this.normalized.importMeta = {
      ...(this.normalized.importMeta || {}),
      chordSourceUrl: p.sourceUrl || this._cifraSelectedUrl,
      chordProvider: 'cifraclub',
    };
    this._cifraPhase = 'idle';
    this._cifraPreview = null;
    this.render();
    this.notify();
    this.onToast('Cifra aplicada — revise o texto e salve quando estiver pronto.', 'success');
  }

  backToCifraResults() {
    this._cifraPhase = this._cifraCandidates.length ? 'results' : 'idle';
    this._cifraPreview = null;
    this.render();
  }

  getNormalized() {
    if (!this.normalized) return null;
    const { lyrics, blocks } = sectionsToSongLyricsAndBlocks(this.normalized.sections || []);
    return {
      ...this.normalized,
      plainLyrics: lyrics || this.normalized.plainLyrics,
      blocks,
      key: this.normalized.key || '',
      bpm: this.normalized.bpm ?? null,
      capo: this.normalized.capo ?? 0,
      chordSource: this.normalized.chordSource || '',
      chordSourceUrl: this.normalized.chordSourceUrl || this.normalized.importMeta?.chordSourceUrl || '',
      style: { ...this._formatStyle },
    };
  }

  notify() {
    this.onChange?.(this.getNormalized());
  }

  render() {
    const n = this.normalized;
    if (!n) {
      this.container.innerHTML = `
        <p class="lyrics-studio-muted">Selecione um resultado à esquerda para ver a letra estruturada em estrofes.</p>`;
      return;
    }

    const conf = Math.round((n.importMeta?.confidence || averageSectionConfidence(n.sections)) * 100);
    const avgConf = averageSectionConfidence(n.sections);
    const provider = n.source?.provider || '—';
    let sections = n.sections?.length ? n.sections : null;
    if (!sections) {
      const plain = String(n.plainLyrics || '');
      const paras = plain.split(/\n\s*\n/).map((p) => p.trim()).filter(Boolean);
      if (paras.length > 1) {
        sections = paras.map((p, i) => createLyricsSection({
          type: 'verse',
          label: `Estrofe ${i + 1}`,
          lines: p.split('\n').map((l) => l.trimEnd()),
          confidence: 0.4,
        }));
      } else {
        sections = [createLyricsSection({
          type: 'unknown',
          label: 'Letra',
          lines: plain.split('\n').map((l) => l.trimEnd()),
          confidence: 0.3,
        })];
      }
    }

    if (!n.sections?.length) n.sections = sections;

    const projectionText = sectionsToProjectionLyrics(sections);
    const lowConfBanner = avgConf < 0.5
      ? '<p class="lyrics-studio-warn">Revise as seções — a detecção automática tem baixa confiança.</p>'
      : '';
    const fmt = this._formatStyle || { splitMode: 'lines', linesPerSlide: 4, stanzasPerSlide: 1 };
    const formatBar = `
      <div class="lyrics-studio-format-bar" role="group" aria-label="Como dividir na projeção">
        <span class="lyrics-studio-format-label">Salvar slides</span>
        <select id="lis-split-mode" title="Como agrupar a letra no projetor">
          <option value="lines" ${fmt.splitMode === 'lines' ? 'selected' : ''}>Por linhas</option>
          <option value="stanzas" ${fmt.splitMode === 'stanzas' ? 'selected' : ''}>Por estrofe</option>
        </select>
        <span class="lyrics-studio-format-label" id="lis-split-n-label">${fmt.splitMode === 'stanzas' ? 'Estrofes/slide' : 'Linhas/slide'}</span>
        <div class="lyrics-studio-format-chips" id="lis-split-n-chips">
          ${(fmt.splitMode === 'stanzas' ? [1, 2] : [2, 4, 6]).map((nVal) => {
            const cur = fmt.splitMode === 'stanzas' ? fmt.stanzasPerSlide : fmt.linesPerSlide;
            return `<button type="button" class="lyrics-studio-format-chip ${cur === nVal ? 'is-active' : ''}" data-split-n="${nVal}">${nVal}</button>`;
          }).join('')}
        </div>
        <p class="lyrics-studio-muted lyrics-studio-format-hint">A biblioteca e o projetor usam esta divisão ao adicionar o louvor.</p>
      </div>`;

    this.container.innerHTML = `
      <div class="lyrics-studio-preview-meta">
        <div class="lyrics-studio-fields">
          <label class="lyrics-studio-field">
            <span>Título</span>
            <input type="text" id="lis-prev-title" value="${esc(n.title)}" maxlength="200" />
          </label>
          <label class="lyrics-studio-field">
            <span>Artista</span>
            <input type="text" id="lis-prev-artist" value="${esc(n.artist)}" maxlength="200" />
          </label>
          <label class="lyrics-studio-field lyrics-studio-field--full">
            <span>Categoria</span>
            <select id="lis-prev-category">
              <option value="">— Sem categoria —</option>
              ${this.categories.map((c) =>
                `<option value="${escAttr(c)}" ${n.category === c ? 'selected' : ''}>${esc(c)}</option>`
              ).join('')}
              ${n.category && !this.categories.includes(n.category)
                ? `<option value="${escAttr(n.category)}" selected>${esc(n.category)}</option>`
                : ''}
            </select>
          </label>
        </div>
        <div class="lyrics-studio-preview-source">
          <span class="lyrics-studio-chip">${esc(provider)}</span>
          <span class="lyrics-studio-chip lyrics-studio-chip--muted">Confiança ${conf}%</span>
          ${n.category ? `<span class="lyrics-studio-chip lyrics-studio-chip--cat">${esc(n.category)}</span>` : ''}
        </div>
      </div>
      ${formatBar}
      ${lowConfBanner}
      <div class="lyrics-studio-preview-tabs" role="tablist">
        <button type="button" class="lyrics-studio-preview-tab ${this._previewTab === 'structure' ? 'is-active' : ''}" data-prev-tab="structure">Estrutura</button>
        <button type="button" class="lyrics-studio-preview-tab ${this._previewTab === 'projection' ? 'is-active' : ''}" data-prev-tab="projection">Projeção (público)</button>
        <button type="button" class="lyrics-studio-preview-tab ${this._previewTab === 'chords' ? 'is-active' : ''}" data-prev-tab="chords">
          Cifra (Stage)${this._cifraCandidates.length && !this.normalized?.chordSource?.trim() ? ` · ${this._cifraCandidates.length}` : ''}
        </button>
      </div>
      <div class="lyrics-studio-preview-body" id="lis-preview-body">
        ${this._previewTab === 'projection' ? this.projectionHtml(projectionText)
    : this._previewTab === 'chords' ? this.chordsHtml(n)
      : this.structureHtml(sections)}
      </div>`;

    this.bind();
  }

  projectionHtml(text) {
    return `
      <p class="lyrics-studio-muted">Como o público verá na projeção (sem Verso/Refrão):</p>
      <pre class="lyrics-studio-projection-pre">${esc(text || '(vazio)')}</pre>`;
  }

  chordsHtml(n) {
    const sourceUrl = n.chordSourceUrl || n.importMeta?.chordSourceUrl || '';
    const hasApplied = !!n.chordSource?.trim();
    const showEditor = this._cifraPhase === 'idle' || this._cifraPhase === 'empty' || hasApplied;

    return `
      <p class="lyrics-studio-muted">Cifra ChordPro — só no Púlpito/Stage. Busque no Cifra Club, revise a prévia e aplique.</p>
      <div class="lyrics-studio-chord-fields">
        <label class="lyrics-studio-field"><span>Tom</span><input type="text" id="lis-key" value="${esc(n.key || '')}" maxlength="8" placeholder="Ex.: G" /></label>
        <label class="lyrics-studio-field"><span>Capo</span><input type="number" id="lis-capo" min="0" max="11" value="${Number(n.capo) || 0}" /></label>
        <label class="lyrics-studio-field"><span>BPM</span><input type="number" id="lis-bpm" min="40" max="240" value="${n.bpm ?? ''}" placeholder="—" /></label>
      </div>
      <div class="lyrics-studio-chord-actions">
        <button type="button" class="btn btn-primary btn-sm" id="lis-fetch-chords" ${this._cifraBusy ? 'disabled' : ''}>
          ${this._cifraPhase === 'loading' ? 'Buscando…' : 'Buscar no Cifra Club'}
        </button>
        ${this._cifraCandidates.length && this._cifraPhase !== 'preview' ? `
          <button type="button" class="btn btn-ghost btn-sm" id="lis-cifra-show-results">Ver ${this._cifraCandidates.length} resultado(s)</button>
        ` : ''}
        <button type="button" class="btn btn-ghost btn-sm" id="lis-chord-to-lyrics">Gerar letra da cifra</button>
      </div>
      ${sourceUrl && hasApplied ? `
        <p class="lis-cifra-applied-source">Fonte: <a href="${escAttr(sourceUrl)}" target="_blank" rel="noopener">${esc(sourceUrl)}</a></p>
      ` : ''}
      ${this.cifraSearchPanelHtml()}
      ${showEditor ? `
        <label class="visually-hidden" for="lis-chord-source">Cifra ChordPro</label>
        <textarea class="lyrics-studio-chord-source" id="lis-chord-source" rows="12" spellcheck="false"
          placeholder="Cole ChordPro ou aplique uma cifra da busca acima…">${esc(n.chordSource || '')}</textarea>
      ` : ''}`;
  }

  cifraSearchPanelHtml() {
    if (this._cifraPhase === 'loading') {
      return `
        <div class="lis-cifra-panel lis-cifra-panel--loading">
          <div class="lis-cifra-spinner" aria-hidden="true"></div>
          <p>Buscando no Cifra Club…</p>
        </div>`;
    }
    if (this._cifraPhase === 'empty') {
      return `
        <div class="lis-cifra-panel lis-cifra-panel--empty">
          <p>Nenhuma cifra encontrada para este título/artista.</p>
          <p class="lyrics-studio-muted">Ajuste os campos acima ou cole a cifra manualmente.</p>
        </div>`;
    }
    if (this._cifraPhase === 'results') {
      return `
        <div class="lis-cifra-panel">
          <header class="lis-cifra-panel-head">
            <h4>Resultados no Cifra Club</h4>
            <span class="lyrics-studio-muted">${this._cifraCandidates.length} encontrada(s) — clique para pré-visualizar</span>
          </header>
          <ul class="lis-cifra-hits" role="list">
            ${this._cifraCandidates.map((h, i) => `
              <li>
                <button type="button" class="lis-cifra-hit" data-cifra-idx="${i}">
                  <span class="lis-cifra-hit-title">${esc(h.title)}</span>
                  <span class="lis-cifra-hit-artist">${esc(h.artist || '—')}</span>
                  <span class="lis-cifra-hit-badge">Cifra Club</span>
                </button>
              </li>
            `).join('')}
          </ul>
        </div>`;
    }
    if (this._cifraPhase === 'preview' && this._cifraPreview) {
      const p = this._cifraPreview;
      const excerpt = String(p.chordSource || '').split('\n').slice(0, 24).join('\n');
      const truncated = String(p.chordSource || '').split('\n').length > 24;
      return `
        <div class="lis-cifra-panel lis-cifra-panel--preview">
          <header class="lis-cifra-panel-head">
            <div>
              <h4>Prévia da cifra</h4>
              <p class="lis-cifra-preview-meta">${esc(p.matchTitle || '')}${p.matchArtist ? ` · ${esc(p.matchArtist)}` : ''}</p>
            </div>
            ${p.sourceUrl ? `<a class="lis-cifra-open-link" href="${escAttr(p.sourceUrl)}" target="_blank" rel="noopener">Abrir no site ↗</a>` : ''}
          </header>
          <div class="lis-cifra-preview-meta-row">
            ${p.key ? `<span class="lyrics-studio-chip">Tom ${esc(p.key)}</span>` : ''}
            ${p.capo ? `<span class="lyrics-studio-chip">Capo ${esc(String(p.capo))}</span>` : ''}
            ${p.bpm ? `<span class="lyrics-studio-chip">${esc(String(p.bpm))} BPM</span>` : ''}
          </div>
          <pre class="lis-cifra-preview-pre">${esc(excerpt)}${truncated ? '\n…' : ''}</pre>
          <div class="lis-cifra-preview-actions">
            <button type="button" class="btn btn-primary btn-sm" id="lis-cifra-apply">Usar esta cifra</button>
            <button type="button" class="btn btn-secondary btn-sm" id="lis-cifra-back">Escolher outra</button>
          </div>
        </div>`;
    }
    return '';
  }

  structureHtml(sections) {
    return `
      <div class="lyrics-studio-sections" id="lis-sections" role="list">
        ${sections.map((s, i) => this.sectionHtml(s, i, sections.length)).join('')}
      </div>
      <button type="button" class="btn btn-ghost btn-sm lyrics-studio-add-section" id="lis-add-section">
        + Adicionar estrofe
      </button>`;
  }

  bind() {
    this.container.querySelectorAll('[data-prev-tab]').forEach((btn) => {
      btn.addEventListener('click', () => {
        this._previewTab = btn.dataset.prevTab;
        this.render();
      });
    });

    this.container.querySelector('#lis-prev-title')?.addEventListener('input', (e) => {
      this.normalized.title = e.target.value;
      this.notify();
    });
    this.container.querySelector('#lis-prev-artist')?.addEventListener('input', (e) => {
      this.normalized.artist = e.target.value;
      this.notify();
    });
    this.container.querySelector('#lis-prev-category')?.addEventListener('change', (e) => {
      this.normalized.category = e.target.value;
      this.notify();
    });

    this.container.querySelector('#lis-split-mode')?.addEventListener('change', (e) => {
      const mode = e.target.value === 'stanzas' ? 'stanzas' : 'lines';
      this._formatStyle = {
        ...this._formatStyle,
        splitMode: mode,
        linesPerSlide: this._formatStyle.linesPerSlide || 4,
        stanzasPerSlide: this._formatStyle.stanzasPerSlide || 1,
      };
      this.render();
      this.notify();
    });
    this.container.querySelectorAll('[data-split-n]').forEach((btn) => {
      btn.addEventListener('click', () => {
        const nVal = Number(btn.dataset.splitN);
        if (this._formatStyle.splitMode === 'stanzas') {
          this._formatStyle = { ...this._formatStyle, stanzasPerSlide: nVal };
        } else {
          this._formatStyle = { ...this._formatStyle, linesPerSlide: nVal };
        }
        this.render();
        this.notify();
      });
    });

    this.container.querySelector('#lis-key')?.addEventListener('input', (e) => {
      this.normalized.key = e.target.value;
      this.notify();
    });
    this.container.querySelector('#lis-capo')?.addEventListener('input', (e) => {
      this.normalized.capo = Number(e.target.value) || 0;
      this.notify();
    });
    this.container.querySelector('#lis-bpm')?.addEventListener('input', (e) => {
      const v = e.target.value;
      this.normalized.bpm = v ? Number(v) : null;
      this.notify();
    });
    this.container.querySelector('#lis-chord-source')?.addEventListener('input', (e) => {
      this.normalized.chordSource = e.target.value;
      this.notify();
    });
    this.container.querySelector('#lis-fetch-chords')?.addEventListener('click', () => {
      void this.startCifraSearch();
    });
    this.container.querySelector('#lis-cifra-show-results')?.addEventListener('click', () => {
      this._cifraPhase = 'results';
      this.render();
    });
    this.container.querySelectorAll('[data-cifra-idx]').forEach((btn) => {
      btn.addEventListener('click', () => {
        const idx = Number(btn.dataset.cifraIdx);
        const hit = this._cifraCandidates[idx];
        if (hit) void this.previewCifraCandidate(hit);
      });
    });
    this.container.querySelector('#lis-cifra-apply')?.addEventListener('click', () => this.applyCifraPreview());
    this.container.querySelector('#lis-cifra-back')?.addEventListener('click', () => this.backToCifraResults());
    this.container.querySelector('#lis-chord-to-lyrics')?.addEventListener('click', async () => {
      const src = this.container.querySelector('#lis-chord-source')?.value?.trim();
      if (!src) return;
      try {
        const { chordProToPlainLyrics } = await import('../../chordpro-parser.js');
        const plain = chordProToPlainLyrics(src);
        const { detectSections } = await import('../lyrics-section-detector.js');
        const { normalizeLyricsPipeline } = await import('../lyrics-normalizer.js');
        const norm = normalizeLyricsPipeline(plain, { matchScore: 0.7 });
        this.normalized.sections = norm.sections;
        this.normalized.plainLyrics = norm.plainLyrics;
        this._previewTab = 'structure';
        this.render();
        this.notify();
      } catch { /* ignore */ }
    });

    this.container.querySelectorAll('[data-sec-type]').forEach((sel) => {
      sel.addEventListener('change', (e) => {
        const i = Number(e.target.dataset.secType);
        this.normalized.sections = updateSectionType(this.normalized.sections, i, e.target.value);
        this.render();
        this.notify();
      });
    });

    this.container.querySelectorAll('[data-sec-up]').forEach((btn) => {
      btn.addEventListener('click', () => {
        const i = Number(btn.dataset.secUp);
        if (i <= 0) return;
        const arr = [...this.normalized.sections];
        [arr[i - 1], arr[i]] = [arr[i], arr[i - 1]];
        this.normalized.sections = arr;
        this.render();
        this.notify();
      });
    });

    this.container.querySelectorAll('[data-sec-down]').forEach((btn) => {
      btn.addEventListener('click', () => {
        const i = Number(btn.dataset.secDown);
        const arr = [...this.normalized.sections];
        if (i >= arr.length - 1) return;
        [arr[i], arr[i + 1]] = [arr[i + 1], arr[i]];
        this.normalized.sections = arr;
        this.render();
        this.notify();
      });
    });

    this.container.querySelectorAll('[data-sec-merge]').forEach((btn) => {
      btn.addEventListener('click', () => {
        const i = Number(btn.dataset.secMerge);
        if (i >= this.normalized.sections.length - 1) return;
        this.normalized.sections = mergeSections(this.normalized.sections, i, i + 1);
        this.render();
        this.notify();
      });
    });

    this.container.querySelectorAll('[data-sec-del]').forEach((btn) => {
      btn.addEventListener('click', () => {
        const i = Number(btn.dataset.secDel);
        if (this.normalized.sections.length <= 1) {
          this.normalized.sections[0] = createLyricsSection({
            type: 'unknown', label: '', lines: [''], confidence: 0.3,
          });
        } else {
          this.normalized.sections.splice(i, 1);
        }
        this.render();
        this.notify();
      });
    });

    this.container.querySelectorAll('[data-sec-lines]').forEach((ta) => {
      ta.addEventListener('input', (e) => {
        const i = Number(e.target.dataset.secLines);
        this.normalized.sections[i] = createLyricsSection({
          ...this.normalized.sections[i],
          lines: e.target.value.split('\n'),
        });
        this.notify();
        this.autoResize(ta);
      });
      this.autoResize(ta);
    });

    this.container.querySelectorAll('.lyrics-studio-section').forEach((el, i) => {
      el.addEventListener('contextmenu', (e) => {
        e.preventDefault();
        openContextMenu(e.clientX, e.clientY, [
          { label: 'Marcar como refrão', action: () => {
            this.normalized.sections = updateSectionType(this.normalized.sections, i, 'chorus');
            this.render(); this.notify();
          } },
          { label: 'Marcar como verso', action: () => {
            this.normalized.sections = updateSectionType(this.normalized.sections, i, 'verse');
            this.render(); this.notify();
          } },
          { sep: true },
          { label: 'Mesclar com próxima', action: () => {
            if (i < this.normalized.sections.length - 1) {
              this.normalized.sections = mergeSections(this.normalized.sections, i, i + 1);
              this.render(); this.notify();
            }
          } },
          { label: 'Remover estrofe', danger: true, action: () => {
            if (this.normalized.sections.length > 1) {
              this.normalized.sections.splice(i, 1);
              this.render(); this.notify();
            }
          } },
        ]);
      });
    });

    this.container.querySelector('#lis-add-section')?.addEventListener('click', () => {
      this.normalized.sections.push(createLyricsSection({
        type: 'verse', label: '', lines: [''], confidence: 0.4,
      }));
      this.render();
      this.notify();
    });
  }

  autoResize(ta) {
    if (!ta) return;
    ta.style.height = 'auto';
    ta.style.height = `${Math.max(72, Math.min(280, ta.scrollHeight))}px`;
  }

  sectionHtml(s, i, total) {
    const types = BLOCK_TYPES.map((t) =>
      `<option value="${t.id}" ${s.type === t.id ? 'selected' : ''}>${esc(t.label)}</option>`
    ).join('');
    const label = BLOCK_TYPES.find((t) => t.id === s.type)?.label || 'Seção';
    const confPct = Math.round((Number(s.confidence) || 0) * 100);
    return `
      <article class="lyrics-studio-section" role="listitem" data-type="${esc(s.type)}">
        <header class="lyrics-studio-section-head">
          <span class="lyrics-studio-section-badge">${esc(label)}</span>
          <span class="lyrics-studio-conf ${confClass(s.confidence)}" title="Confiança ${confPct}%">${confPct}%</span>
          <select class="lyrics-studio-section-type" data-sec-type="${i}" aria-label="Tipo da estrofe">${types}</select>
          <div class="lyrics-studio-section-tools">
            <button type="button" class="btn btn-ghost btn-sm" data-sec-up="${i}" title="Mover para cima" ${i === 0 ? 'disabled' : ''}>↑</button>
            <button type="button" class="btn btn-ghost btn-sm" data-sec-down="${i}" title="Mover para baixo" ${i >= total - 1 ? 'disabled' : ''}>↓</button>
            <button type="button" class="btn btn-ghost btn-sm" data-sec-merge="${i}" title="Mesclar com próxima" ${i >= total - 1 ? 'disabled' : ''}>⊕</button>
            <button type="button" class="btn btn-ghost btn-sm" data-sec-del="${i}" title="Remover estrofe">×</button>
          </div>
        </header>
        <textarea class="lyrics-studio-section-lines" rows="3" data-sec-lines="${i}"
          spellcheck="false" placeholder="Linhas da estrofe…">${esc((s.lines || []).join('\n'))}</textarea>
      </article>`;
  }
}
