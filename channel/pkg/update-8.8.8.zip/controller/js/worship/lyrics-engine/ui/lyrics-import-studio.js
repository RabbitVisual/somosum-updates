import { searchLyrics, fetchAndNormalizeLyrics, cancelSearch, autoDiscoverLyrics } from '../lyrics-source-orchestrator.js';
import { importNormalizedSong, defaultDuplicateChoice } from '../lyrics-import-service.js';
import { isLyricsOnline } from '../lyrics-fetcher.js';
import { renderSearchResults } from './lyrics-search-results.js';
import { LyricsImportPreview } from './lyrics-import-preview.js';
import { renderProgress } from './lyrics-import-progress.js';
import { logLyrics } from '../lyrics-logger.js';

let _activeStudio = null;

function esc(t) {
  const d = document.createElement('div');
  d.textContent = t ?? '';
  return d.innerHTML;
}

/**
 * Import Studio — busca → resultados → revisão por estrofes → biblioteca/culto.
 * Experiência nativa (sem abrir navegador como fluxo principal).
 */
export class LyricsImportStudio {
  constructor({ app, onToast, onSaved, onOpenExisting } = {}) {
    this.app = app;
    this.onToast = onToast || (() => {});
    this.onSaved = onSaved;
    this.onOpenExisting = onOpenExisting;
    this.overlay = null;
    this._debounce = null;
    this._results = [];
    this._selected = null;
    this._previewData = null;
    this._online = true;
    this._busy = false;
    this._phase = 'search';
    this._onKey = null;
  }

  open(initialQuery = '') {
    if (this.overlay) {
      this.overlay.hidden = false;
      document.body.classList.add('lyrics-studio-open');
      this.hideResumeChip();
      if (initialQuery?.trim()) {
        const q = this.overlay.querySelector('#lis-query');
        if (q) q.value = initialQuery;
        this._lastQuery = initialQuery;
      }
      if (this._results?.length) this.restoreResultsUi();
      else if (this._previewData) {
        this.preview.setNormalized(this._previewData);
        this.setButtonsEnabled(true);
        this.updateDualTrackStatus(this._previewData);
      }
      this.overlay.querySelector('#lis-query')?.focus();
      _activeStudio = this;
      return;
    }
    this._phase = this._phase || 'search';
    this.overlay = document.createElement('div');
    this.overlay.className = 'lyrics-studio-overlay';
    this.overlay.setAttribute('role', 'presentation');
    this.overlay.innerHTML = `
      <div class="lyrics-studio" role="dialog" aria-modal="true" aria-labelledby="lis-title">
        <header class="lyrics-studio-head">
          <div class="lyrics-studio-brand">
            <p class="lyrics-studio-kicker">Biblioteca de Louvores</p>
            <h2 id="lis-title">Importar música</h2>
            <p class="lyrics-studio-lead">Busque, revise a letra (projeção) e a cifra (Stage) — tudo dentro do SOMOSUM.</p>
          </div>
          <div class="lyrics-studio-head-actions">
            <span class="lyrics-studio-badge" id="lis-offline-badge" hidden title="Somente biblioteca local">Sem rede</span>
            <button type="button" class="btn btn-ghost lyrics-studio-close" id="lis-close" aria-label="Fechar">×</button>
          </div>
        </header>

        <nav class="lyrics-studio-steps" aria-label="Etapas">
          <span class="lyrics-studio-step is-active" data-step="search">1. Buscar</span>
          <span class="lyrics-studio-step-sep" aria-hidden="true"></span>
          <span class="lyrics-studio-step" data-step="results">2. Escolher</span>
          <span class="lyrics-studio-step-sep" aria-hidden="true"></span>
          <span class="lyrics-studio-step" data-step="preview">3. Revisar</span>
          <span class="lyrics-studio-step-sep" aria-hidden="true"></span>
          <span class="lyrics-studio-step" data-step="save">4. Salvar</span>
        </nav>

        <div class="lyrics-studio-search-row">
          <div class="lyrics-studio-search-wrap">
            <label class="visually-hidden" for="lis-query">Buscar música</label>
            <input type="search" id="lis-query" class="lyrics-studio-search"
              placeholder="Título, artista ou trecho entre aspas — ex.: A Casa É Sua"
              autocomplete="off" value="${esc(initialQuery || this._lastQuery || '')}" />
            <button type="button" class="btn btn-primary" id="lis-search-btn">Buscar</button>
          </div>
          <button type="button" class="btn btn-secondary" id="lis-auto" title="Tenta vários provedores e escolhe a melhor letra">
            Busca automática
          </button>
        </div>

        <div class="lyrics-studio-status" id="lis-status" hidden>
          <div class="lyrics-studio-status-bar"><span id="lis-status-pulse"></span></div>
          <p class="lyrics-studio-progress" id="lis-progress" aria-live="polite"></p>
        </div>

        <div class="lyrics-studio-body">
          <section class="lyrics-studio-results-col" aria-label="Resultados da busca">
            <header class="lyrics-studio-col-head">
              <h3>Resultados</h3>
              <span class="lyrics-studio-count" id="lis-count"></span>
            </header>
            <div id="lis-results" class="lyrics-studio-results">
              <div class="lyrics-studio-empty">
                <strong>Como buscar</strong>
                <ul>
                  <li><code>A Casa É Sua</code> — só o título</li>
                  <li><code>A Casa É Sua Casa Worship</code> — título + artista</li>
                  <li><code>"essa casa é sua"</code> — trecho da letra</li>
                </ul>
                <p>Sem internet, a busca usa só a biblioteca local.</p>
              </div>
            </div>
          </section>

          <section class="lyrics-studio-preview-col" aria-label="Pré-visualização da letra">
            <header class="lyrics-studio-col-head">
              <h3>Revisão da letra</h3>
              <span class="lyrics-studio-hint" id="lis-preview-hint">Estrutura em estrofes</span>
            </header>
            <div id="lis-preview-host" class="lyrics-studio-preview-scroll">
              <p class="lyrics-studio-muted">Selecione um resultado e clique em <strong>Visualizar</strong> para revisar as estrofes.</p>
            </div>
          </section>
        </div>

        <footer class="lyrics-studio-foot">
          <div class="lyrics-studio-foot-left">
            <button type="button" class="btn btn-ghost" id="lis-minimize" title="Minimizar (Esc) — mantém busca e revisão">Minimizar</button>
            <div class="lyrics-studio-dual-track" id="lis-dual-track" aria-label="Conteúdo a salvar">
              <span class="lyrics-studio-track-chip" id="lis-track-lyrics">Letra · projeção</span>
              <span class="lyrics-studio-track-chip" id="lis-track-chords">Cifra · Stage</span>
            </div>
          </div>
          <div class="lyrics-studio-foot-actions">
            <button type="button" class="btn btn-secondary" id="lis-save" disabled>Salvar na Biblioteca</button>
            <button type="button" class="btn btn-primary" id="lis-save-culto" disabled>Salvar e Adicionar ao Culto</button>
          </div>
        </footer>
      </div>`;

    document.body.appendChild(this.overlay);
    document.body.classList.add('lyrics-studio-open');

    this.preview = new LyricsImportPreview(this.overlay.querySelector('#lis-preview-host'), {
      onChange: (n) => {
        this._previewData = n;
        this.setPhase('preview');
        this.updateDualTrackStatus(n);
      },
      onToast: (msg, type) => this.onToast(msg, type),
    });
    void import('../../worship-meta.js').then(({ getCategories }) => getCategories())
      .then((cats) => this.preview?.setCategories?.(cats))
      .catch(() => {});

    this.overlay.querySelector('#lis-close').onclick = () => this.requestClose();
    this.overlay.querySelector('#lis-minimize').onclick = () => this.hide();
    // Clique no fundo escuro NÃO fecha — evita perder busca/revisão acidentalmente
    this.overlay.addEventListener('click', (e) => {
      if (e.target === this.overlay) {
        e.stopPropagation();
      }
    });

    const queryEl = this.overlay.querySelector('#lis-query');
    queryEl.addEventListener('input', () => this.scheduleSearch());
    queryEl.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        void this.runSearch();
      }
    });
    this.overlay.querySelector('#lis-search-btn').onclick = () => this.runSearch();
    this.overlay.querySelector('#lis-auto').onclick = () => this.runAutoDiscover();
    this.overlay.querySelector('#lis-save').onclick = () => this.save(false);
    this.overlay.querySelector('#lis-save-culto').onclick = () => this.save(true);

    this._onKey = (e) => {
      if (e.key === 'Escape' && this.overlay && !this.overlay.hidden) {
        e.preventDefault();
        this.hide();
      }
    };
    document.addEventListener('keydown', this._onKey);

    void this.checkOnline();
    if (this._results?.length) {
      this.restoreResultsUi();
    } else if ((initialQuery || this._lastQuery || '').trim()) {
      this.scheduleSearch();
    } else if (this._previewData) {
      this.preview.setNormalized(this._previewData);
      this.setButtonsEnabled(true);
    }
    queryEl.focus();
    queryEl.select?.();
    _activeStudio = this;
    this.updateDualTrackStatus(this._previewData);
    this.hideResumeChip();
  }

  requestClose() {
    const hasWork = this._results?.length || this._previewData?.plainLyrics || this._previewData?.sections?.length;
    if (hasWork && !confirm('Fechar importação? A busca e a revisão serão descartadas.')) return;
    this.destroy();
  }

  updateDualTrackStatus(data) {
    const lyricsEl = this.overlay?.querySelector('#lis-track-lyrics');
    const chordsEl = this.overlay?.querySelector('#lis-track-chords');
    if (!lyricsEl || !chordsEl) return;
    const hasLyrics = !!(data?.plainLyrics?.trim() || data?.sections?.some((s) => s.lines?.some((l) => String(l).trim())));
    const hasChords = !!(data?.chordSource?.trim());
    lyricsEl.classList.toggle('is-ready', hasLyrics);
    lyricsEl.classList.toggle('is-empty', !hasLyrics);
    chordsEl.classList.toggle('is-ready', hasChords);
    chordsEl.classList.toggle('is-empty', !hasChords);
    lyricsEl.title = hasLyrics ? 'Letra limpa para projeção (público)' : 'Importe ou revise a letra na aba Estrutura';
    chordsEl.title = hasChords ? 'Cifra ChordPro para Púlpito/Stage (músicos)' : 'Opcional — aba Cifra ou busca automática';
  }

  showResumeChip() {
    let chip = document.getElementById('lis-resume-chip');
    if (!chip) {
      chip = document.createElement('button');
      chip.type = 'button';
      chip.id = 'lis-resume-chip';
      chip.className = 'lyrics-studio-resume-chip';
      chip.setAttribute('aria-label', 'Retomar importação de música');
      document.body.appendChild(chip);
    }
    const title = this._previewData?.title || this._lastQuery || 'música';
    chip.textContent = `Importar música (retomar) · ${title}`;
    chip.hidden = false;
    chip.onclick = () => {
      this.open();
      this.hideResumeChip();
    };
  }

  hideResumeChip() {
    const chip = document.getElementById('lis-resume-chip');
    if (chip) chip.hidden = true;
  }

  hide() {
    cancelSearch();
    clearTimeout(this._debounce);
    this._lastQuery = this.overlay?.querySelector('#lis-query')?.value || this._lastQuery || '';
    document.body.classList.remove('lyrics-studio-open');
    if (this.overlay) this.overlay.hidden = true;
    _activeStudio = this;
    const hasSession = this._results?.length || this._previewData || (this._lastQuery || '').trim();
    if (hasSession) this.showResumeChip();
  }

  destroy() {
    cancelSearch();
    clearTimeout(this._debounce);
    if (this._onKey) {
      document.removeEventListener('keydown', this._onKey);
      this._onKey = null;
    }
    document.body.classList.remove('lyrics-studio-open');
    this.hideResumeChip();
    this.overlay?.remove();
    this.overlay = null;
    this._results = [];
    this._selected = null;
    this._previewData = null;
    this._phase = 'search';
    if (_activeStudio === this) _activeStudio = null;
  }

  close() {
    this.destroy();
  }

  restoreResultsUi() {
    const resultsHost = this.overlay?.querySelector('#lis-results');
    const countEl = this.overlay?.querySelector('#lis-count');
    if (!resultsHost || !this._results?.length) return;
    if (countEl) countEl.textContent = String(this._results.length);
    this.setPhase('results');
    renderSearchResults(resultsHost, this._results, {
      selectedUrl: this._selected?.url,
      onSelect: (r) => { this._selected = r; this.restoreResultsUi(); },
      onPreview: (r) => this.loadPreview(r, this._lastQuery || ''),
      onImport: (r) => this.loadPreview(r, this._lastQuery || ''),
    });
    if (this._previewData) {
      this.preview.setNormalized(this._previewData);
      this.setButtonsEnabled(true);
    }
  }

  async fetchChordsForPreview(data) {
    if (!data) return;
    this._previewData = data;
    this.preview.setNormalized(data);
    await this.preview.startCifraSearch();
  }

  setPhase(phase) {
    this._phase = phase;
    const map = { search: 0, results: 1, preview: 2, save: 3 };
    const active = map[phase] ?? 0;
    this.overlay?.querySelectorAll('.lyrics-studio-step').forEach((el, i) => {
      el.classList.toggle('is-active', i === active);
      el.classList.toggle('is-done', i < active);
    });
  }

  async checkOnline() {
    this._online = await isLyricsOnline();
    const badge = this.overlay?.querySelector('#lis-offline-badge');
    if (badge) badge.hidden = this._online;
  }

  scheduleSearch() {
    clearTimeout(this._debounce);
    this._debounce = setTimeout(() => this.runSearch(), 320);
  }

  setBusy(on, label = '') {
    this._busy = on;
    const status = this.overlay?.querySelector('#lis-status');
    const progress = this.overlay?.querySelector('#lis-progress');
    if (status) status.hidden = !on && !label;
    renderProgress(progress, label || (on ? 'Aguarde…' : ''));
    if (status && !on && !label) status.hidden = true;
    this.overlay?.querySelector('#lis-search-btn')?.toggleAttribute('disabled', on);
    this.overlay?.querySelector('#lis-auto')?.toggleAttribute('disabled', on);
  }

  setButtonsEnabled(on) {
    this.overlay?.querySelector('#lis-save')?.toggleAttribute('disabled', !on);
    this.overlay?.querySelector('#lis-save-culto')?.toggleAttribute('disabled', !on);
    if (on) this.setPhase('save');
  }

  async runSearch() {
    if (!this.overlay || this._busy) return;
    const query = this.overlay.querySelector('#lis-query')?.value?.trim();
    this._lastQuery = query || '';
    const resultsHost = this.overlay.querySelector('#lis-results');
    const countEl = this.overlay.querySelector('#lis-count');
    if (!query) {
      resultsHost.innerHTML = `
        <div class="lyrics-studio-empty">
          <strong>Digite para buscar</strong>
          <p>Título, artista ou trecho entre aspas.</p>
        </div>`;
      if (countEl) countEl.textContent = '';
      return;
    }

    this.setPhase('search');
    this.setBusy(true, 'Pesquisando…');
    logLyrics('LYRICS_SEARCH', { queryLen: query.length });

    try {
      const { results, online } = await searchLyrics(query, {
        onProgress: (l) => this.setBusy(true, l),
      });
      this._results = results;
      this._online = online;
      await this.checkOnline();
      if (countEl) countEl.textContent = results.length ? `${results.length}` : '';
      this.setPhase('results');
      const paint = (selected) => {
        this._selected = selected || this._selected;
        renderSearchResults(resultsHost, results, {
          selectedUrl: this._selected?.url,
          onSelect: (r) => paint(r),
          onPreview: (r) => this.loadPreview(r, query),
          onImport: (r) => this.loadPreview(r, query),
        });
      };
      paint(this._selected);
      this.setBusy(false);
    } catch (err) {
      this.setBusy(false);
      resultsHost.innerHTML = `<p class="lyrics-studio-error">Busca falhou: ${esc(err.message)}</p>`;
      this.onToast(`Busca falhou: ${err.message}`, 'warn');
      logLyrics('LYRICS_SEARCH', { error: err.message }, 'WARN');
    }
  }

  async runAutoDiscover() {
    if (!this.overlay || this._busy) return;
    const query = this.overlay.querySelector('#lis-query')?.value?.trim();
    if (!query) {
      this.onToast('Digite um título ou trecho para a busca automática.', 'warn');
      this.overlay.querySelector('#lis-query')?.focus();
      return;
    }
    this.setBusy(true, 'Identificando música…');
    try {
      const { song, result } = await autoDiscoverLyrics(query, {
        onProgress: (l) => this.setBusy(true, l),
        skipChords: true,
      });
      this._previewData = song;
      this._selected = result;
      this.preview.setNormalized(song);
      this.setButtonsEnabled(true);
      this.updateDualTrackStatus(song);
      this.setPhase('preview');
      this.overlay.querySelector('#lis-preview-hint').textContent = 'Revise antes de salvar';
      this.setBusy(false);
      this.onToast('Letra encontrada — revise as estrofes antes de salvar.');
      void this.preview.autoSearchCifra();
    } catch {
      this.setBusy(false);
      this.onToast('Não foi possível encontrar automaticamente. Selecione um resultado.', 'warn');
      await this.runSearch();
    }
  }

  async loadPreview(result, query) {
    if (!result || this._busy) return;
    this._selected = result;
    this.setBusy(true, 'Obtendo conteúdo…');
    this.setButtonsEnabled(false);
    try {
      const normalized = await fetchAndNormalizeLyrics(result, query, {
        onProgress: (l) => this.setBusy(true, l),
        skipChords: true,
      });
      this._previewData = normalized;
      this.preview.setNormalized(normalized);
      this.setButtonsEnabled(true);
      this.updateDualTrackStatus(normalized);
      this.setPhase('preview');
      const n = normalized.sections?.length || 0;
      this.overlay.querySelector('#lis-preview-hint').textContent =
        n ? `${n} seção${n === 1 ? '' : 'ões'} detectada${n === 1 ? '' : 's'}` : 'Sem estrutura — edite à vontade';
      this.setBusy(false);
      logLyrics('LYRICS_EXTRACT', { provider: result.providerId, title: result.title });
      this.overlay.querySelector('#lis-preview-host')?.scrollTo?.({ top: 0 });
      void this.preview.autoSearchCifra();
    } catch (err) {
      this.setBusy(false);
      this.onToast(`Falha ao obter letra: ${err.message}`, 'warn');
      logLyrics('LYRICS_FETCH', { error: err.message }, 'WARN');
    }
  }

  async save(addToProgram) {
    if (this._busy) return;
    const data = this.preview?.getNormalized?.() || this._previewData;
    if (!data?.plainLyrics?.trim() && !data?.sections?.length) {
      this.onToast('Nenhuma letra para salvar. Visualize um resultado primeiro.', 'warn');
      return;
    }
    if (!String(data.title || '').trim()) {
      this.onToast('Informe o título da música.', 'warn');
      return;
    }
    this.setBusy(true, 'Salvando…');
    try {
      const song = await importNormalizedSong(data, {
        addToProgram,
        app: this.app,
        onDuplicate: (info) => defaultDuplicateChoice(info),
      });
      logLyrics('LYRICS_IMPORT', { id: song.id, title: song.title, hasChords: !!song.chordSource?.trim() });
      this.setBusy(false);
      const dual = song.chordSource?.trim() ? ' — letra (projeção) + cifra (Stage)' : '';
      this.onToast(addToProgram ? `Salvo${dual} e adicionado ao culto.` : `Salvo na biblioteca${dual}.`);
      this.onSaved?.(song);
      this.destroy();
    } catch (err) {
      this.setBusy(false);
      if (err?.code === 'duplicate_cancelled') {
        if (err.existing?.id) {
          this.onToast(`Já na biblioteca — abrindo “${err.existing.title}”.`, 'info');
          this.onOpenExisting?.(err.existing);
          this.onSaved?.(err.existing);
          this.destroy();
          return;
        }
        this.onToast('Importação cancelada — música já existe.', 'warn');
        return;
      }
      this.onToast(`Erro ao salvar: ${err.message}`, 'warn');
    }
  }
}

export function openLyricsImportStudio(opts = {}) {
  if (_activeStudio?.overlay) {
    _activeStudio.open(opts.query || '');
    return _activeStudio;
  }
  const studio = new LyricsImportStudio(opts);
  studio.open(opts.query || '');
  return studio;
}
