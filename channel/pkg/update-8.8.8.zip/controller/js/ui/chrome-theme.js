/**
 * Tema chrome global (claro/escuro) — operador em todo o sistema.
 * Persiste em prefs.ui.chromeTheme; não altera atmosferas de projeção.
 */
import { getPrefs, savePrefs } from '../core/store.js';

export const CHROME_THEMES = Object.freeze(['dark', 'light']);
const LEGACY_REMOTE_KEY = 'somosum.remote.theme';
const BOUND = new WeakSet();

export function resolveChromeTheme(prefs = null) {
  const p = prefs || (typeof getPrefs === 'function' ? getPrefs() : null) || {};
  const fromPrefs = p?.ui?.chromeTheme;
  if (fromPrefs === 'light' || fromPrefs === 'dark') return fromPrefs;
  try {
    const cached = localStorage.getItem('somosum.chromeTheme');
    if (cached === 'light' || cached === 'dark') return cached;
    const legacy = localStorage.getItem(LEGACY_REMOTE_KEY);
    if (legacy === 'light' || legacy === 'dark') return legacy;
  } catch { /* ignore */ }
  const prefersDark = typeof window !== 'undefined'
    && window.matchMedia?.('(prefers-color-scheme: dark)')?.matches;
  return prefersDark ? 'dark' : 'light';
}

export function applyChromeTheme(mode, { persist = false, prefs = null } = {}) {
  const next = mode === 'light' ? 'light' : 'dark';
  const root = document.documentElement;
  root.dataset.chrome = next;
  root.dataset.theme = next === 'dark' ? 'dark-studio' : 'light';
  try {
    localStorage.removeItem(LEGACY_REMOTE_KEY);
    localStorage.setItem('somosum.chromeTheme', next);
  } catch { /* ignore */ }
  if (persist && typeof savePrefs === 'function') {
    const cur = prefs || getPrefs();
    savePrefs({
      ...cur,
      ui: { ...(cur.ui || {}), chromeTheme: next },
    });
  }
  try {
    window.dispatchEvent(new CustomEvent('somosum-chrome-theme', { detail: { mode: next } }));
  } catch { /* ignore */ }
  return next;
}

export function toggleChromeTheme(opts = {}) {
  const cur = resolveChromeTheme(opts.prefs);
  return applyChromeTheme(cur === 'dark' ? 'light' : 'dark', { persist: true, ...opts });
}

function syncToggleButton(btn) {
  if (!btn) return;
  const mode = resolveChromeTheme();
  btn.setAttribute('aria-pressed', mode === 'dark' ? 'true' : 'false');
  btn.title = mode === 'dark' ? 'Tema claro' : 'Tema escuro';
  const label = btn.querySelector('[data-chrome-label]');
  if (label) label.textContent = mode === 'dark' ? 'Escuro' : 'Claro';
}

/**
 * Liga o botão [data-chrome-theme-toggle] dentro de `root`.
 * Seguro chamar de novo após re-render (não duplica listeners globais).
 */
export function bindChromeThemeToggle(root, { onChange } = {}) {
  const scope = root || document;
  const btn = scope.querySelector?.('[data-chrome-theme-toggle]');
  if (!btn) return;

  syncToggleButton(btn);

  if (!BOUND.has(btn)) {
    BOUND.add(btn);
    btn.addEventListener('click', () => {
      const next = toggleChromeTheme();
      // Atualiza todos os toggles visíveis (Control / Stage / Remote / Painel)
      document.querySelectorAll('[data-chrome-theme-toggle]').forEach(syncToggleButton);
      onChange?.(next);
    });
  }

  if (!window.__somosumChromeThemeSyncBound) {
    window.__somosumChromeThemeSyncBound = true;
    window.addEventListener('somosum-chrome-theme', () => {
      document.querySelectorAll('[data-chrome-theme-toggle]').forEach(syncToggleButton);
    });
  }
}
