import { parseLyrics } from './lyrics-parser.js';
import { resolveMediaSrc, resolveSystemLoopAlias } from '../core/media-url.js';

/** Soft-wrap opcional (desligado na projeção — Holyrics-like: N linhas = N linhas). */
const MAX_LINE_CHARS = 52;
const MAX_STANZA_LINES = 6;
const MIN_BREAK_INDEX = 12;

/**
 * Quebra linha longa por respiração. Pontuação fica na linha anterior
 * (nunca começa linha com ", ; . :").
 */
function splitLongLine(line, maxChars = MAX_LINE_CHARS) {
  const t = (line || '').trim();
  if (!t) return [];
  if (t.length <= maxChars) return [t];

  const pivot = Math.min(Math.floor(t.length * 0.65), Math.max(maxChars, Math.floor(t.length * 0.5)));
  const punct = [
    { token: ', ', keep: 1 },
    { token: '; ', keep: 1 },
    { token: ' — ', keep: 0 },
    { token: ' - ', keep: 0 },
  ];
  let best = null;
  for (const sep of punct) {
    const i = t.lastIndexOf(sep.token, pivot);
    if (i >= MIN_BREAK_INDEX && (!best || i > best.idx)) best = { idx: i, sep };
  }
  if (!best) {
    const i = t.lastIndexOf(' ', pivot);
    if (i >= MIN_BREAK_INDEX) best = { idx: i, sep: { token: ' ', keep: 0 } };
  }

  let left;
  let right;
  if (best) {
    left = t.slice(0, best.idx + best.sep.keep).trimEnd();
    right = t.slice(best.idx + best.sep.token.length).trim();
  } else {
    const mid = Math.floor(t.length / 2);
    left = t.slice(0, mid).trimEnd();
    right = t.slice(mid).trim();
  }

  if (!left || !right || /^[,;.:]/.test(right)) return [t];
  return [left, ...splitLongLine(right, maxChars)].filter(Boolean);
}

/** Une fragmentos que começam com pontuação (legado de soft-wrap ruim). */
function healLeadingPunctuation(lines) {
  const out = [];
  for (const raw of lines || []) {
    const line = String(raw || '').trim();
    if (!line) continue;
    if (out.length && /^[,;.:]/.test(line)) {
      out[out.length - 1] = `${out[out.length - 1]}${line}`;
    } else {
      out.push(line);
    }
  }
  return out;
}

/** Soft-wrap das linhas de um slide (só se explicitamente ligado). */
function softWrapSlideLines(lines, maxChars = MAX_LINE_CHARS) {
  const out = [];
  for (const line of healLeadingPunctuation(lines)) {
    if (!line?.trim()) continue;
    out.push(...splitLongLine(line, maxChars));
  }
  return healLeadingPunctuation(out);
}

function poeticLines(rawText) {
  const { stanzas, lines } = parseLyrics(rawText);
  return { stanzas, lines: healLeadingPunctuation(lines.filter((l) => l?.trim())) };
}

function makeSlide(lines, highlightIndex, slideIndex) {
  return {
    type: 'lyrics',
    lines,
    highlightIndex,
    slideIndex,
  };
}

export function createLyricsTitleSlide(song, style, background) {
  return {
    type: 'lyrics-title',
    title: song?.title || 'Música',
    artist: song?.artist || '',
    style,
    background,
  };
}

export async function resolveSlideBackground(style, getMediaFn) {
  if (style?.backgroundMediaId && getMediaFn) {
    const m = await getMediaFn(style.backgroundMediaId);
    if (m) {
      const src = resolveMediaSrc(m);
      if (src) {
        const isVideo = m.kind === 'video'
          || m.category === 'fundo-animado'
          || m.category === 'loop'
          || String(m.mimeType || m.mime || '').includes('video')
          || /\.(mp4|webm|mov)(\?|$)/i.test(src);
        return { type: isVideo ? 'video' : 'image', src };
      }
    }
    const alias = resolveSystemLoopAlias(style.backgroundMediaId);
    if (alias) {
      return {
        type: /\.mp4|\.webm|mov/i.test(alias) ? 'video' : 'image',
        src: alias,
      };
    }
  }
  return { type: 'gradient', preset: style?.backgroundPreset || 'theme' };
}

/** @deprecated use resolveSlideBackground */
export const resolveLyricsBackground = resolveSlideBackground;

export function buildLyricsSlides(song, style, options = {}) {
  const background = options.background || { type: 'gradient', preset: 'theme' };
  const slides = [createLyricsTitleSlide(song, style, background)];

  if (!song?.lyrics?.trim()) {
    slides.push({
      type: 'lyrics',
      lines: [options.placeholder || 'Cadastre ou vincule uma música na biblioteca de letras.'],
      style,
      background,
    });
    return slides;
  }

  splitLyricsIntoSlides(song.lyrics, style, song).forEach((s) => {
    slides.push({ ...s, style, background });
  });
  return slides;
}

/**
 * Agrupa linhas poéticas originais (quebra \\n) em slides.
 * Por padrão NÃO faz soft-wrap: "4 linhas" = 4 linhas na tela (como Holyrics).
 * Soft-wrap só com options.softWrap === true ou style.softWrap === true.
 */
export function splitLyricsIntoSlides(rawText, style = {}, song = null, options = {}) {
  const softWrap = options.softWrap === true || style.softWrap === true;
  const { stanzas, lines: rawLines } = poeticLines(rawText);

  const mode = style.splitMode || 'lines';
  const linesPerSlide = Math.max(1, Math.min(style.linesPerSlide || 4, 6));
  const stanzasPerSlide = Math.max(1, style.stanzasPerSlide || 1);
  const hi = style.highlightLine !== false ? 0 : -1;

  const finalize = (chunk, index) => {
    const cleaned = healLeadingPunctuation(chunk.filter((l) => l?.trim()));
    const visual = softWrap ? softWrapSlideLines(cleaned) : cleaned;
    return makeSlide(visual.length ? visual : cleaned, hi, index);
  };

  if (mode === 'line') {
    return rawLines.map((line, index) => finalize([line], index));
  }

  if (mode === 'lines') {
    const slides = [];
    for (let i = 0; i < rawLines.length; i += linesPerSlide) {
      const chunk = rawLines.slice(i, i + linesPerSlide);
      slides.push(finalize(chunk, slides.length));
    }
    return slides;
  }

  if (mode === 'stanzas') {
    const slides = [];
    for (let i = 0; i < stanzas.length; i += stanzasPerSlide) {
      let chunk = healLeadingPunctuation(
        stanzas.slice(i, i + stanzasPerSlide).flat().filter((l) => l?.trim()),
      );
      while (chunk.length > MAX_STANZA_LINES) {
        slides.push(finalize(chunk.slice(0, MAX_STANZA_LINES), slides.length));
        chunk = chunk.slice(MAX_STANZA_LINES);
      }
      if (chunk.length) {
        slides.push(finalize(chunk, slides.length));
      }
    }
    return slides;
  }

  return stanzas.flatMap((stanza) => {
    const poetic = healLeadingPunctuation(stanza.filter((l) => l?.trim()));
    const chunks = [];
    for (let i = 0; i < poetic.length; i += MAX_STANZA_LINES) {
      chunks.push(poetic.slice(i, i + MAX_STANZA_LINES));
    }
    return chunks.map((linesChunk, index) => finalize(linesChunk, index));
  });
}

/**
 * Reorganiza a letra com linha em branco entre cada slide (visual no editor).
 * Preserva linhas poéticas intactas — sem cortar frase no meio.
 */
export function formatLyricsForSlides(rawText, style = {}) {
  const slides = splitLyricsIntoSlides(rawText, style, null, { softWrap: false });
  if (!slides.length) return rawText || '';
  return slides.map((s) => s.lines.join('\n')).join('\n\n');
}

function pickStyleValue(override, songStyle, globalStyle, key, fallback) {
  if (override && Object.prototype.hasOwnProperty.call(override, key) && override[key] !== undefined) {
    return override[key];
  }
  if (songStyle && songStyle[key] !== undefined && songStyle[key] !== null && songStyle[key] !== '') {
    return songStyle[key];
  }
  if (globalStyle && globalStyle[key] !== undefined && globalStyle[key] !== null && globalStyle[key] !== '') {
    return globalStyle[key];
  }
  return fallback;
}

/** Divisão de slides: biblioteca da música manda sobre override do item/tema. */
function pickSongSplitValue(override, songStyle, globalStyle, key, fallback) {
  if (songStyle && songStyle[key] !== undefined && songStyle[key] !== null && songStyle[key] !== '') {
    return songStyle[key];
  }
  if (override && Object.prototype.hasOwnProperty.call(override, key) && override[key] !== undefined) {
    return override[key];
  }
  if (globalStyle && globalStyle[key] !== undefined && globalStyle[key] !== null && globalStyle[key] !== '') {
    return globalStyle[key];
  }
  return fallback;
}

export function getLyricsStyle(song, globalStyle, itemOverride = null) {
  const g = globalStyle || {};
  const s = song?.style || {};
  const o = itemOverride || {};
  return {
    fontSize: pickStyleValue(o, s, g, 'fontSize', 54),
    lineHeight: pickStyleValue(o, s, g, 'lineHeight', 1.45),
    align: pickStyleValue(o, s, g, 'align', 'center'),
    marginTop: pickStyleValue(o, s, g, 'marginTop', 10),
    marginBottom: pickStyleValue(o, s, g, 'marginBottom', 10),
    marginLeft: pickStyleValue(o, s, g, 'marginLeft', 6),
    marginRight: pickStyleValue(o, s, g, 'marginRight', 6),
    splitMode: pickSongSplitValue(o, s, g, 'splitMode', 'lines'),
    linesPerSlide: pickSongSplitValue(o, s, g, 'linesPerSlide', 4),
    stanzasPerSlide: pickSongSplitValue(o, s, g, 'stanzasPerSlide', 1),
    highlightLine: pickStyleValue(o, s, g, 'highlightLine', false),
    backgroundPreset: pickStyleValue(o, s, g, 'backgroundPreset', 'theme'),
    backgroundMediaId: pickStyleValue(o, s, g, 'backgroundMediaId', null),
    titleColor: pickStyleValue(o, s, g, 'titleColor', null),
    textColor: pickStyleValue(o, s, g, 'textColor', null),
    textEffect: pickStyleValue(o, s, g, 'textEffect', 'outline'),
    bgDim: pickStyleValue(o, s, g, 'bgDim', 0.28),
    vAlign: pickStyleValue(o, s, g, 'vAlign', 'center'),
    fontFamily: pickStyleValue(o, s, g, 'fontFamily', null),
    fontWeight: pickStyleValue(o, s, g, 'fontWeight', 800),
    fontStyle: pickStyleValue(o, s, g, 'fontStyle', null),
    textTransform: pickStyleValue(o, s, g, 'textTransform', 'none'),
    transition: o.transition ?? s.transition ?? g.transition ?? null,
  };
}

export { MAX_LINE_CHARS, MAX_STANZA_LINES, softWrapSlideLines, splitLongLine };
