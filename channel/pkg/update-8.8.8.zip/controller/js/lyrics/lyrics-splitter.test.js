import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import {
  splitLyricsIntoSlides,
  formatLyricsForSlides,
  softWrapSlideLines,
} from './lyrics-splitter.js';

const CULT_EXAMPLE = [
  'Musica que da pra cantar em duas etapas',
  'Linha 3 e sete exemplo exeplo',
  'Musica que da pra cantar em duas etapas',
  'Linha 3 e sete exemplo exeplo',
].join('\n');

describe('splitLyricsIntoSlides — linhas poéticas', () => {
  it('2 linhas por slide agrupa frases completas (exemplo do culto)', () => {
    const slides = splitLyricsIntoSlides(CULT_EXAMPLE, {
      splitMode: 'lines',
      linesPerSlide: 2,
      highlightLine: false,
    }, null, { softWrap: false });

    assert.equal(slides.length, 2);
    assert.deepEqual(slides[0].lines, [
      'Musica que da pra cantar em duas etapas',
      'Linha 3 e sete exemplo exeplo',
    ]);
    assert.deepEqual(slides[1].lines, [
      'Musica que da pra cantar em duas etapas',
      'Linha 3 e sete exemplo exeplo',
    ]);
  });

  it('4 linhas por slide = exatamente 4 linhas na projeção (sem soft-wrap)', () => {
    const text = [
      'Deus não rejeita oração, oração é alimento',
      'Nunca vi um justo sem resposta ou ficar no sofrimento',
      'Basta somente esperar o que Deus irá fazer',
      'Quando Ele estende Suas mãos, é a hora de vencer',
      'Então, louve',
      'Simplesmente louve',
    ].join('\n');
    const slides = splitLyricsIntoSlides(text, {
      splitMode: 'lines',
      linesPerSlide: 4,
      highlightLine: false,
    });
    assert.equal(slides[0].lines.length, 4);
    assert.ok(!slides[0].lines.some((l) => /^,/.test(l)), 'não pode começar linha com vírgula');
    assert.deepEqual(slides[0].lines[3], 'Quando Ele estende Suas mãos, é a hora de vencer');
  });

  it('não corta frase no meio antes de agrupar (softWrap na projeção)', () => {
    const slides = splitLyricsIntoSlides(CULT_EXAMPLE, {
      splitMode: 'lines',
      linesPerSlide: 2,
      highlightLine: false,
    });

    assert.equal(slides.length, 2);
    assert.equal(slides[0].lines.length, 2);
    assert.deepEqual(slides[0].lines, [
      'Musica que da pra cantar em duas etapas',
      'Linha 3 e sete exemplo exeplo',
    ]);
  });

  it('mode line = 1 linha poética por slide', () => {
    const slides = splitLyricsIntoSlides(CULT_EXAMPLE, {
      splitMode: 'line',
      highlightLine: false,
    }, null, { softWrap: false });
    assert.equal(slides.length, 4);
    assert.deepEqual(slides[0].lines, ['Musica que da pra cantar em duas etapas']);
  });

  it('estrofes: flush na fronteira; format preserva linhas', () => {
    const text = 'Aaa bbb ccc ddd eee fff\nLinha dois\n\nEstrofe B linha 1\nEstrofe B linha 2';
    const slides = splitLyricsIntoSlides(text, {
      splitMode: 'stanzas',
      stanzasPerSlide: 1,
      highlightLine: false,
    }, null, { softWrap: false });
    assert.equal(slides.length, 2);
    assert.deepEqual(slides[1].lines, ['Estrofe B linha 1', 'Estrofe B linha 2']);
  });
});

describe('formatLyricsForSlides', () => {
  it('insere branco entre slides sem destruir frases', () => {
    const out = formatLyricsForSlides(CULT_EXAMPLE, {
      splitMode: 'lines',
      linesPerSlide: 2,
    });
    assert.equal(
      out,
      [
        'Musica que da pra cantar em duas etapas',
        'Linha 3 e sete exemplo exeplo',
        '',
        'Musica que da pra cantar em duas etapas',
        'Linha 3 e sete exemplo exeplo',
      ].join('\n'),
    );
    assert.ok(!out.includes('Musica que da\npra cantar'));
  });
});

describe('softWrapSlideLines', () => {
  it('quebra linha longa por espaço perto de 60%, não no meio da palavra cega', () => {
    const long = 'Musica que da pra cantar em duas etapas e ainda mais texto longo aqui';
    const parts = softWrapSlideLines([long]);
    assert.ok(parts.length >= 2);
    assert.ok(parts.every((p) => p.length > 0));
    assert.equal(parts.join(' ').replace(/\s+/g, ' '), long);
  });

  it('nunca deixa vírgula no início da linha seguinte', () => {
    const long = 'Quando Ele estende Suas mãos, é a hora de vencer e celebrar o nome';
    const parts = softWrapSlideLines([long], 28);
    assert.ok(parts.every((p) => !/^[,;.:]/.test(p)));
    assert.ok(parts.some((p) => p.endsWith(',') || p.includes('mãos')));
  });

  it('cura fragmentos legados que começam com vírgula', () => {
    const parts = softWrapSlideLines([
      'Quando Ele estende Suas mãos',
      ', é a hora de vencer',
    ]);
    assert.equal(parts.length, 1);
    assert.equal(parts[0], 'Quando Ele estende Suas mãos, é a hora de vencer');
  });
});
