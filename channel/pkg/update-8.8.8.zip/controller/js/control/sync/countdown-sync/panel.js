﻿import { MessageTypes } from '../../../core/bus.js';
import {
  getCountdownFromPrefs,
  normalizeCountdownConfig,
  computeTargetMs,
  formatCountdownDigits,
  computeAnnounceDurationSec,
  COUNTDOWN_BG_MODES,
  COUNTDOWN_LAYOUTS,
  normalizeCountdownBgMode,
  normalizeCountdownLayout,
  countdownPhaseLabel,
  isEphemeralMediaSrc,
} from '../../../core/countdown.js';
import { DEFAULT_COUNTDOWN_NOTICES } from '../../../data/countdown-verses.js';
import { loadAmbientTracks } from '../../../core/ambient-audio.js';
import { playBellSound, preloadBellSound, setKnownAudioPaths, unlockBellAudio } from '../../../core/bell-sound.js';
import { esc, escAttr } from '../../utils/escape.js';
import { TaskScheduler } from '../../../core/task-scheduler.js';
import { TaskIds } from '../../../core/task-registry.js';
import { fontPickerHtml, loadCustomFonts } from '../../../core/fonts.js';
import { savePrefs, saveMediaFile } from '../../../core/store.js';
import { resolveMediaSrc } from '../../../core/media-url.js';

/** Countdown / pré-culto — extraído de control-app */

export function countdownSyncPanel() {
  return {
      refreshCountdownPanel() {
        const panel = document.getElementById('countdown-panel');
        const state = this.getCountdownState();
        const topBtn = document.getElementById('btn-countdown');
        const live = this.isCountdownLive();
        let remainingDisplay = '';
        if (live) {
          const remaining = Math.max(0, state.targetMs - Date.now());
          remainingDisplay = formatCountdownDigits(remaining).display;
        }
        if (topBtn) {
          topBtn.classList.toggle('is-live', live);
          topBtn.textContent = live
            ? (remainingDisplay ? `Pré-culto · ${remainingDisplay}` : 'Pré-culto ativo')
            : 'Pré-culto';
          topBtn.title = live
            ? 'Pré-culto em andamento — abra o painel para parar · atalho C inicia/para'
            : 'Abrir painel Pré-culto · atalho C inicia/para a contagem';
        }
        if (!panel) return;

        const startBtn = panel.querySelector('#cd-start');
        const stopBtn = panel.querySelector('#cd-stop');
        if (startBtn) {
          startBtn.disabled = live;
          startBtn.textContent = live ? 'Em andamento…' : 'Iniciar na projeção';
        }
        if (stopBtn) stopBtn.disabled = !live;

        const status = panel.querySelector('#cd-status');
        if (status) {
          if (live) {
            const amb = this.getAmbientState?.();
            const ambNote = amb?.playing ? ' · música ativa' : '';
            status.textContent = `No ar · ${remainingDisplay} restantes · ${countdownPhaseLabel(state.phase)}${ambNote}`;
            status.classList.add('is-live');
          } else {
            status.textContent = 'Pronto — escolha o tempo, revise o visual e inicie na projeção';
            status.classList.remove('is-live');
          }
        }

        const amb = this.getAmbientState?.() || {};
        const ambPill = panel.querySelector('#cd-ambient-pill');
        if (ambPill) {
          ambPill.textContent = amb.playing
            ? `Música: ${(amb.trackPath || '').split('/').pop() || 'ativa'}`
            : amb.trackPath
              ? 'Música pronta (pausada)'
              : 'Sem música de fundo';
          ambPill.classList.toggle('is-live', !!amb.playing);
        }
        const ambTitle = panel.querySelector('#cd-ambient-title');
        if (ambTitle) {
          ambTitle.textContent = amb.playing
            ? ((amb.trackPath || '').split('/').pop() || 'Tocando')
            : amb.trackPath
              ? ((amb.trackPath || '').split('/').pop() || 'Pronta')
              : 'Nenhuma faixa';
        }
        const ambQuick = panel.querySelector('#cd-ambient-quick');
        if (ambQuick) {
          ambQuick.textContent = amb.playing ? 'Pausar' : 'Tocar';
          ambQuick.disabled = !amb.trackPath && !amb.playing;
          ambQuick.classList.toggle('is-active', !!amb.playing);
        }
        const ambCard = panel.querySelector('#cd-ambient-card');
        ambCard?.classList.toggle('is-live', !!amb.playing);

        panel.querySelectorAll('.cd-mode-block').forEach((el) => {
          el.style.display = 'none';
        });
        const mode = panel.querySelector('#cd-mode')?.value || state.mode;
        panel.querySelector(mode === 'time' ? '#cd-mode-time' : '#cd-mode-duration')?.style.setProperty('display', '');
        panel.classList.toggle('is-minimized', !!state.panelMinimized);
        this.updateCountdownDock();
      },

      initCountdownPanel() {
        document.getElementById('countdown-panel')?.remove();
        const state = this.getCountdownState();
        const noticesText = (state.notices || DEFAULT_COUNTDOWN_NOTICES)
          .map((n) => `${n.icon} ${n.text}`)
          .join('\n');
        void loadCustomFonts({ injectFaces: true });
        const fontOptsHtml = fontPickerHtml(state.clockFontFamily || '', { includeEmpty: true });
        const layoutId = normalizeCountdownLayout(state.layoutStyle);

        const panel = document.createElement('div');
        panel.id = 'countdown-panel';
        panel.className = `countdown-panel su-op-sheet${this.countdownPanelOpen ? ' is-open' : ''}${state.panelMinimized ? ' is-minimized' : ''}`;
        panel.innerHTML = `
          <div class="su-op-sheet__head countdown-panel-head">
            <div class="su-op-sheet__title">
              <strong>Pré-culto</strong>
              <span class="su-op-sheet__sub countdown-panel-sub">Contagem regressiva na projeção</span>
            </div>
            <div class="su-op-sheet__head-actions countdown-panel-head-actions">
              <button type="button" class="btn btn-secondary btn-icon" id="cd-minimize" title="Modo compacto">▾</button>
              <button type="button" class="btn btn-secondary btn-icon" id="cd-close" title="Fechar">✕</button>
            </div>
          </div>
          <div class="su-op-sheet__status" id="cd-status">Pronto — escolha o tempo, revise o visual e inicie na projeção</div>
          <div class="su-op-music-card" id="cd-ambient-card">
            <div class="su-op-music-card__meta">
              <span class="su-op-music-card__label">Música neste PC</span>
              <span class="su-op-music-card__title" id="cd-ambient-title">Nenhuma faixa</span>
              <span class="countdown-live-pill" id="cd-ambient-pill" hidden>Sem música de fundo</span>
            </div>
            <button type="button" class="btn btn-secondary btn-sm" id="cd-ambient-quick" title="Tocar ou pausar">Tocar</button>
            <button type="button" class="btn btn-secondary btn-sm" id="cd-open-ambient" title="Abrir painel Música">Música…</button>
          </div>

          <div class="su-op-sheet__body">
          <details class="countdown-section su-op-section" open>
            <summary>Tempo</summary>
            <div class="form-block" style="border:none;padding:0 0 .55rem">
              <label>Como contar</label>
              <select id="cd-mode">
                <option value="duration" ${state.mode !== 'time' ? 'selected' : ''}>Por duração (a partir de agora)</option>
                <option value="time" ${state.mode === 'time' ? 'selected' : ''}>Até o horário do culto</option>
              </select>
            </div>
            <div id="cd-mode-duration" class="cd-mode-block">
              <div class="form-block" style="border:none;padding:0 0 .55rem">
                <label>Minutos</label>
                <input type="number" id="cd-duration" min="1" max="180" value="${state.durationMinutes || 10}" />
              </div>
              <div class="cd-presets">
                <button type="button" class="btn btn-secondary btn-sm" data-mins="5">5 min</button>
                <button type="button" class="btn btn-secondary btn-sm" data-mins="10">10 min</button>
                <button type="button" class="btn btn-secondary btn-sm" data-mins="15">15 min</button>
                <button type="button" class="btn btn-secondary btn-sm" data-mins="30">30 min</button>
              </div>
            </div>
            <div id="cd-mode-time" class="cd-mode-block" style="display:none">
              <div class="form-row-2">
                <div class="form-block" style="border:none;padding:0"><label>Horário</label><input type="time" id="cd-time" value="${escAttr(state.serviceTime || '19:30')}" /></div>
                <div class="form-block" style="border:none;padding:0"><label>Data (opcional)</label><input type="date" id="cd-date" value="${escAttr(state.serviceDate || '')}" /></div>
              </div>
            </div>
          </details>

          <details class="countdown-section su-op-section" open>
            <summary>Visual na projeção</summary>
            <p class="form-hint">Mudanças atualizam o projetor na hora se a contagem já estiver no ar.</p>
            <div class="form-block" style="border:none;padding:0 0 .65rem">
              <label>Estilo do slide</label>
              <div class="countdown-layout-grid" id="cd-layout-grid" role="listbox">
                ${COUNTDOWN_LAYOUTS.map((lay) => {
                  const on = layoutId === lay.id;
                  return `<button type="button" class="countdown-layout-card${on ? ' is-selected' : ''}" data-layout="${lay.id}" role="option" aria-selected="${on ? 'true' : 'false'}" title="${escAttr(lay.hint)}">
                    <span class="countdown-layout-name">${esc(lay.label)}</span>
                    <span class="countdown-layout-hint">${esc(lay.hint)}</span>
                  </button>`;
                }).join('')}
              </div>
              <input type="hidden" id="cd-layout" value="${escAttr(layoutId)}" />
            </div>
            <div class="form-block" style="border:none;padding:0 0 .55rem">
              <label for="cd-font">Fonte do relógio</label>
              <select id="cd-font" class="font-select">
                ${fontOptsHtml}
              </select>
            </div>
            <div class="countdown-bg-preview" id="cd-bg-preview" aria-hidden="true"></div>
            <label class="form-hint" style="display:block;margin:.35rem 0 .25rem">Fundo / atmosfera</label>
            <div class="countdown-bg-grid" id="cd-bg-grid" role="listbox" aria-label="Tipo de fundo">
              ${COUNTDOWN_BG_MODES.map((bg) => {
                const selected = normalizeCountdownBgMode(state.backgroundMode) === bg.id;
                return `<button type="button" class="countdown-bg-swatch is-${bg.id}${selected ? ' is-selected' : ''}" data-bg="${bg.id}" role="option" aria-selected="${selected ? 'true' : 'false'}" title="${escAttr(bg.hint)}">
                  <span class="countdown-bg-swatch-visual" aria-hidden="true"></span>
                  <span class="countdown-bg-swatch-label">${esc(bg.label)}</span>
                  <span class="countdown-bg-swatch-hint">${esc(bg.hint)}</span>
                </button>`;
              }).join('')}
            </div>
            <input type="hidden" id="cd-bg-mode" value="${escAttr(normalizeCountdownBgMode(state.backgroundMode))}" />
            <div class="cd-media-picker" id="cd-media-picker" style="${normalizeCountdownBgMode(state.backgroundMode) === 'media' ? '' : 'display:none'}">
              <label>Arquivo de vídeo ou imagem</label>
              <input type="text" id="cd-media-src" placeholder="Caminho ou URL (ex.: system/media/...)" value="${escAttr(state.customMediaSrc || '')}" />
              <div class="form-row-2" style="margin-top:.4rem">
                <select id="cd-media-kind">
                  <option value="image" ${state.customMediaKind !== 'video' ? 'selected' : ''}>Imagem</option>
                  <option value="video" ${state.customMediaKind === 'video' ? 'selected' : ''}>Vídeo</option>
                </select>
                <label class="btn btn-secondary btn-sm" style="cursor:pointer;text-align:center">
                  Escolher arquivo
                  <input type="file" id="cd-media-file" accept="image/*,video/mp4,video/webm,video/quicktime" hidden />
                </label>
              </div>
              <p class="form-hint">Preferência: coloque o arquivo em <code>system/media</code> ou use o vídeo da igreja.</p>
            </div>
            <div class="ambient-volume-row" style="margin:.55rem 0">
              <label for="cd-bg-dim">Escurecer fundo</label>
              <input type="range" id="cd-bg-dim" min="0" max="90" value="${Math.round((state.backgroundDim ?? 0.45) * 100)}" />
              <span id="cd-bg-dim-readout">${Math.round((state.backgroundDim ?? 0.45) * 100)}%</span>
            </div>
          </details>

          <details class="countdown-section su-op-section">
            <summary>Textos e som</summary>
            <div class="form-block" style="border:none;padding:.45rem 0 .55rem">
              <label>Texto acima do relógio</label>
              <input id="cd-label" value="${escAttr(state.label || 'O culto começa em')}" />
            </div>
            <div class="form-block" style="border:none;padding:0 0 .55rem">
              <label>Título ao zerar</label>
              <input id="cd-announce-title" value="${escAttr(state.announcementTitle || 'O Culto vai Começar')}" />
            </div>
            <div class="form-row-2" style="margin-bottom:.55rem">
              <div class="form-block" style="border:none;padding:0"><label>Novo versículo (seg)</label><input type="number" id="cd-verse-interval" min="12" max="120" value="${state.verseIntervalSec || 22}" /></div>
              <div class="form-block" style="border:none;padding:0"><label>Destaque tela cheia (seg)</label><input type="number" id="cd-spotlight-sec" min="5" max="20" value="${state.verseSpotlightSec || 8}" /></div>
            </div>
            <div class="form-row-2" style="margin-bottom:.55rem">
              <div class="form-block" style="border:none;padding:0"><label>Destaque por aviso (seg)</label><input type="number" id="cd-notice-spot" min="3" max="12" step="0.5" value="${state.noticeSpotlightSec ?? 5}" /></div>
              <div class="form-block" style="border:none;padding:0"><label>Duração mínima avisos (seg)</label><input type="number" id="cd-announce-sec" min="8" max="120" value="${state.announcementDurationSec || 20}" /></div>
              <div class="form-block" style="border:none;padding:0"><label>Transição SOMOS UM (seg)</label><input type="number" id="cd-transition-sec" min="4" max="15" value="${state.transitionDurationSec || 6}" /></div>
            </div>
            <div class="form-block" style="border:none;padding:0 0 .55rem">
              <label><input type="checkbox" id="cd-branding" ${state.showBranding !== false ? 'checked' : ''} /> Logo e identidade da igreja</label>
            </div>
            <div class="form-block" style="border:none;padding:0 0 .55rem">
              <label><input type="checkbox" id="cd-verses" ${state.showRandomVerses !== false ? 'checked' : ''} /> Versículos aleatórios na tela</label>
            </div>
            <div class="form-block" style="border:none;padding:0 0 .55rem">
              <label><input type="checkbox" id="cd-motto" ${state.includeEventMotto !== false ? 'checked' : ''} /> Incluir divisa do evento (João 17.11)</label>
            </div>
            <div class="form-block" style="border:none;padding:0 0 .55rem">
              <label><input type="checkbox" id="cd-auto-welcome" ${state.autoGoToWelcome !== false ? 'checked' : ''} /> Ao terminar, ir para Boas-vindas</label>
            </div>
            <hr style="border:none;border-top:1px solid rgba(212,198,141,.12);margin:.55rem 0" />
            <div class="form-block" style="border:none;padding:0 0 .55rem">
              <label><input type="checkbox" id="cd-bell" ${state.playBell !== false ? 'checked' : ''} /> Sino ao zerar a contagem</label>
            </div>
            <div class="form-block" style="border:none;padding:0 0 .55rem">
              <label>Som do sino</label>
              <select id="cd-bell-track">
                <option value="">Sino sintético (recomendado)</option>
                ${(this.ambientTracks || []).map((t) =>
                  `<option value="${escAttr(t.path)}" ${state.bellPath === t.path ? 'selected' : ''}>${esc(t.name || t.fileName)}</option>`
                ).join('')}
              </select>
            </div>
            <div class="ambient-volume-row" style="margin-bottom:.55rem">
              <label for="cd-bell-vol">Volume do sino</label>
              <input type="range" id="cd-bell-vol" min="20" max="100" value="${Math.round((state.bellVolume ?? 0.7) * 100)}" />
              <span id="cd-bell-vol-readout">${Math.round((state.bellVolume ?? 0.7) * 100)}%</span>
            </div>
            <button type="button" class="btn btn-secondary btn-sm" id="cd-bell-test" style="margin-bottom:.65rem">Testar sino</button>
            <div class="form-block" style="border:none;padding:0 0 .55rem">
              <label><input type="checkbox" id="cd-fade-ambient" ${state.fadeAmbientOnEnd !== false ? 'checked' : ''} /> Diminuir o volume da música ao final</label>
            </div>
            <div class="form-row-2" style="margin-bottom:.55rem">
              <div class="form-block" style="border:none;padding:0">
                <label>Quando diminuir</label>
                <select id="cd-fade-start">
                  <option value="transition" ${state.ambientFadeStart !== 'announce' ? 'selected' : ''}>Na transição</option>
                  <option value="announce" ${state.ambientFadeStart === 'announce' ? 'selected' : ''}>Nos avisos (mais cedo)</option>
                </select>
              </div>
              <div class="form-block" style="border:none;padding:0">
                <label>Duração (segundos)</label>
                <input type="number" id="cd-fade-sec" min="1" max="20" value="${state.ambientFadeSec || 4}" />
              </div>
            </div>
            <div class="form-block" style="border:none;padding:0 0 .55rem">
              <label>Avisos ao zerar (um por linha — ícone + texto)</label>
              <textarea id="cd-notices" rows="4">${esc(noticesText)}</textarea>
            </div>
          </details>
          </div>

          <div class="su-op-sheet__foot countdown-panel-actions">
            <button type="button" class="btn btn-primary" id="cd-start" ${this.isCountdownLive() ? 'disabled' : ''}>${this.isCountdownLive() ? 'Em andamento…' : 'Iniciar na projeção'}</button>
            <button type="button" class="btn btn-danger" id="cd-stop" ${this.isCountdownLive() ? '' : 'disabled'}>Parar</button>
            <p class="su-op-sheet__hint form-hint"><kbd>C</kbd> inicia ou para a contagem</p>
          </div>
        `;
        document.body.appendChild(panel);

        const saveConfig = () => {
          const config = this.readCountdownConfigFromPanel();
          const current = this.getCountdownState();
          this.prefs = savePrefs({
            ...this.prefs,
            countdown: { ...current, ...config, active: current.active, phase: current.phase, targetMs: current.targetMs, startedAt: current.startedAt },
          });
          if (this.isCountdownLive()) this.syncCountdown();
        };

        const refreshBgPreview = () => {
          const preview = panel.querySelector('#cd-bg-preview');
          if (!preview) return;
          const mode = normalizeCountdownBgMode(panel.querySelector('#cd-bg-mode')?.value || 'midnight');
          const mediaPicker = panel.querySelector('#cd-media-picker');
          if (mediaPicker) mediaPicker.style.display = mode === 'media' ? '' : 'none';
          preview.className = `countdown-bg-preview is-${mode}`;
          if (mode === 'welcome' || mode === 'media') {
            const urls = this.getAssetUrls?.() || {};
            const customRaw = panel.querySelector('#cd-media-src')?.value?.trim();
            const customSrc = isEphemeralMediaSrc(customRaw) ? '' : customRaw;
            const url = mode === 'media'
              ? (customSrc || urls.welcomeBg || 'IMG/FRENTE_DA_IGREJA.png')
              : (urls.welcomeBg || 'IMG/FRENTE_DA_IGREJA.png');
            const kind = mode === 'media'
              ? (panel.querySelector('#cd-media-kind')?.value === 'video' || /\.(mp4|webm|mov)(\?|$)/i.test(url) ? 'video' : 'image')
              : (urls.welcomeBgKind || 'image');
            preview.className = `countdown-bg-preview is-${mode}${kind === 'video' ? ' is-video' : ''}`;
            if (kind === 'video') {
              preview.style.backgroundImage = '';
              let vid = preview.querySelector('video');
              if (!vid) {
                vid = document.createElement('video');
                vid.muted = true;
                vid.loop = true;
                vid.playsInline = true;
                vid.autoplay = true;
                preview.appendChild(vid);
              }
              if (vid.getAttribute('src') !== url) vid.src = url;
              vid.play().catch(() => {});
            } else {
              preview.querySelector('video')?.remove();
              preview.style.backgroundImage = `url('${url}')`;
            }
          } else {
            preview.querySelector('video')?.remove();
            preview.style.backgroundImage = '';
          }
          panel.querySelectorAll('.countdown-bg-swatch').forEach((btn) => {
            const on = btn.dataset.bg === mode;
            btn.classList.toggle('is-selected', on);
            btn.setAttribute('aria-selected', on ? 'true' : 'false');
          });
        };

        const setBgMode = (mode) => {
          const next = normalizeCountdownBgMode(mode);
          const input = panel.querySelector('#cd-bg-mode');
          if (input) input.value = next;
          refreshBgPreview();
          saveConfig();
        };

        panel.querySelectorAll('.countdown-bg-swatch').forEach((btn) => {
          btn.addEventListener('click', () => setBgMode(btn.dataset.bg));
        });

        panel.querySelectorAll('.countdown-layout-card').forEach((btn) => {
          btn.addEventListener('click', () => {
            const id = normalizeCountdownLayout(btn.dataset.layout);
            const input = panel.querySelector('#cd-layout');
            if (input) input.value = id;
            panel.querySelectorAll('.countdown-layout-card').forEach((b) => {
              const on = b.dataset.layout === id;
              b.classList.toggle('is-selected', on);
              b.setAttribute('aria-selected', on ? 'true' : 'false');
            });
            saveConfig();
          });
        });

        panel.querySelector('#cd-media-file')?.addEventListener('change', async (e) => {
          const file = e.target.files?.[0];
          if (!file) return;
          const srcInput = panel.querySelector('#cd-media-src');
          const kindInput = panel.querySelector('#cd-media-kind');
          this.toast?.('Salvando mídia do pré-culto…');
          try {
            const saved = await saveMediaFile(file, { category: 'background' });
            const durable = resolveMediaSrc(saved) || saved?.src || saved?.path || '';
            if (!durable || isEphemeralMediaSrc(durable)) {
              throw new Error('URL permanente indisponível');
            }
            if (srcInput) srcInput.value = durable;
            if (kindInput) kindInput.value = (saved?.kind === 'video' || file.type.startsWith('video/')) ? 'video' : 'image';
            setBgMode('media');
            refreshBgPreview();
            saveConfig();
            this.toast?.('Mídia do pré-culto salva na biblioteca');
          } catch (err) {
            console.warn('[countdown] media upload', err);
            this.toast?.('Não foi possível salvar a mídia. Use um caminho em system/media ou a biblioteca.');
          } finally {
            e.target.value = '';
          }
        });

        panel.querySelector('#cd-media-src')?.addEventListener('change', () => {
          refreshBgPreview();
          saveConfig();
        });
        panel.querySelector('#cd-media-kind')?.addEventListener('change', () => {
          refreshBgPreview();
          saveConfig();
        });

        panel.querySelector('#cd-close')?.addEventListener('click', () => this.toggleCountdownPanel(false));
        panel.querySelector('#cd-minimize')?.addEventListener('click', () => this.toggleCountdownPanelMinimized());

        panel.querySelector('#cd-open-ambient')?.addEventListener('click', () => {
          this.toggleAmbientPanel?.(true);
        });
        panel.querySelector('#cd-ambient-quick')?.addEventListener('click', async () => {
          const amb = this.getAmbientState?.() || {};
          const trackPath = amb.trackPath;
          if (!trackPath) {
            this.toggleAmbientPanel?.(true);
            this.toast?.('Escolha uma faixa no painel Música');
            return;
          }
          const playing = !amb.playing;
          if (playing) {
            this.controlAmbient?.preloadTrack?.(trackPath);
            await this.controlAmbient?.warmStart?.();
          }
          this.setAmbientState?.({ trackPath, playing });
        });
        panel.querySelector('#cd-mode')?.addEventListener('change', () => this.refreshCountdownPanel());

        panel.querySelectorAll('[data-mins]').forEach((btn) => {
          btn.addEventListener('click', () => {
            panel.querySelector('#cd-duration').value = btn.dataset.mins;
          });
        });

        panel.querySelectorAll('input, select, textarea').forEach((el) => {
          if (el.id === 'cd-bg-mode') return;
          el.addEventListener('change', saveConfig);
        });

        panel.querySelector('#cd-start')?.addEventListener('click', () => {
          saveConfig();
          this.startCountdown();
        });

        panel.querySelector('#cd-stop')?.addEventListener('click', () => this.stopCountdown());

        panel.querySelector('#cd-bell-vol')?.addEventListener('input', (e) => {
          panel.querySelector('#cd-bell-vol-readout').textContent = `${e.target.value}%`;
        });

        panel.querySelector('#cd-bg-dim')?.addEventListener('input', (e) => {
          panel.querySelector('#cd-bg-dim-readout').textContent = `${e.target.value}%`;
          refreshBgPreview();
        });
        panel.querySelector('#cd-bg-dim')?.addEventListener('change', saveConfig);

        panel.querySelector('#cd-bell-test')?.addEventListener('click', async () => {
          unlockBellAudio();
          const cfg = this.readCountdownConfigFromPanel();
          if (cfg.bellPath) preloadBellSound(cfg.bellPath);
          const usedFile = cfg.bellPath && this.ambientTracks.some((t) => t.path === cfg.bellPath);
          const ok = await playBellSound({
            bellPath: usedFile ? cfg.bellPath : null,
            volume: cfg.bellVolume ?? 0.7,
          });
          if (usedFile && ok) {
            this.toast('Sino tocado');
          } else if (ok) {
            this.toast('Sino sintético — coloque sino.mp3 em audio/ para som real');
          } else {
            this.toast('Clique na página e tente novamente');
          }
        });

        refreshBgPreview();
        this.refreshCountdownPanel();

        loadCustomFonts({ injectFaces: true }).then(() => {
          const sel = panel.querySelector('#cd-font');
          if (!sel || !panel.isConnected) return;
          const cur = sel.value || state.clockFontFamily || '';
          sel.innerHTML = fontPickerHtml(cur, { includeEmpty: true });
        }).catch(() => {});
      }
  };
}
