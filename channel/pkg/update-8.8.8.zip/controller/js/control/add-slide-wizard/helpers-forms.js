﻿import { createProgramItem, SLIDE_TYPE_OPTIONS, PARTICIPATION_KINDS } from '../../program/programa-templates.js';
import {
  DEFAULT_WELCOME_NORMAL,
  WELCOME_PRESETS,
  resolveWelcomePreset,
  resolveWelcomeBackground,
} from '../../slides/welcome-config.js';
import { welcomeBackgroundPickerHtml, bindWelcomeBackgroundPicker, resolveMediaSrc } from '../../core/media-url.js';
import { getVersions, getPassage } from '../../bible/bible-service.js';
import { BOOKS } from '../../bible/books-map.js';
import { bindBibleRefPicker } from '../../bible/bible-picker.js';
import { loadAmbientTracks } from '../../core/ambient-audio.js';
import { getAllSongs, getSong } from '../../core/store.js';
import {
  messageModeOptionsHtml,
  applyMessageWizardModeUI,
  getMessageMode,
} from '../../slides/message-display-modes.js';

export function esc(t) {
  const d = document.createElement('div');
  d.textContent = t ?? '';
  return d.innerHTML;
}

export function escAttr(t) {
  return esc(t).replace(/"/g, '&quot;');
}

export const TYPE_LABELS = Object.fromEntries(SLIDE_TYPE_OPTIONS.map((o) => [o.type, o.label]));

export const FREE_INTENTS = [
  { id: 'texto', label: 'Texto / cartão livre', hint: 'Título, subtítulo e texto — personalize livremente' },
  { id: 'titulo', label: 'Só título em tela cheia', hint: 'Como um momento/seção — só o título na projeção' },
  { id: 'louvor', label: 'Louvor (música da biblioteca)', hint: 'Escolhe o louvor e vê a letra — vira item de Louvor na ordem' },
  { id: 'biblia', label: 'Leitura bíblica', hint: 'Referência e modo — vira item de Leitura bíblica' },
  { id: 'oracao', label: 'Oração', hint: 'Título em tela cheia para oração' },
  { id: 'comunicado', label: 'Comunicado rápido', hint: 'Avisos em lista — vira Comunicados' },
  { id: 'designer', label: 'Canvas no Designer', hint: 'Slide em branco e abre o Designer para montar do zero' },
];

export function itemTitleField(defaultTitle) {
  return `<div class="form-block"><label>Nome na ordem do culto</label><input id="wiz-item-title" value="${escAttr(defaultTitle)}" /></div>`;
}

export function songsList(app) {
  return Array.isArray(app.songs) ? app.songs : [];
}

export function songOptionsHtml(songs, selectedId = '') {
  return songs.map((s) => {
    const meta = [s.artist, s.category].filter(Boolean).join(' · ');
    const label = meta ? `${s.title} — ${meta}` : s.title;
    return `<option value="${escAttr(s.id)}" data-search="${escAttr(`${s.title} ${s.artist || ''} ${s.lyrics || ''}`.toLowerCase())}" ${selectedId === s.id ? 'selected' : ''}>${esc(label)}</option>`;
  }).join('');
}

export function lyricsBrowserHtml(app, { titleDefault = 'Louvor', showIntentNote = false } = {}) {
  const songs = songsList(app);
  return `
    ${itemTitleField(titleDefault)}
    ${showIntentNote ? '<p class="form-hint">Este estilo cria um <strong>Louvor</strong> real na ordem (letra slide a slide).</p>' : ''}
    <div class="form-block">
      <label>Buscar na biblioteca de louvores</label>
      <input type="search" id="wiz-song-filter" placeholder="Digite título, artista ou trecho da letra…" autocomplete="off" />
    </div>
    <div class="form-block">
      <label>Música (${songs.length} na biblioteca)</label>
      <select id="wiz-song" size="${Math.min(8, Math.max(4, songs.length || 4))}" class="wiz-song-select">
        <option value="">— Escolher depois no inspetor / aba Louvores —</option>
        ${songOptionsHtml(songs)}
      </select>
    </div>
    <label class="checkbox-inline"><input type="checkbox" id="wiz-sync-song-title" checked /> Usar o nome da música como nome na ordem</label>
    <div class="wiz-song-preview" id="wiz-song-preview">
      <p class="form-hint">Selecione um louvor para ler a letra aqui.</p>
    </div>
    <p class="form-hint">Cadastre ou edite letras na aba <strong>Louvores</strong>. Após adicionar, refine tipografia no inspetor.</p>`;
}

export function bibleModeSelect(defaultMode = 'excerpt', modes = null) {
  const opts = modes || [
    { v: 'excerpt', l: 'Introito — referência + trecho' },
    { v: 'verses', l: 'Texto completo do(s) versículo(s)' },
    { v: 'reference', l: 'Só referência na tela' },
    { v: 'chapter', l: 'Capítulo completo (ex.: Números 2)' },
  ];
  return `
    <div class="form-block">
      <label>Modo na projeção</label>
      <select id="wiz-bible-mode">
        ${opts.map((o) => `<option value="${o.v}" ${defaultMode === o.v ? 'selected' : ''}>${o.l}</option>`).join('')}
      </select>
    </div>`;
}

export function biblePickerHtml(prefix, initial = {}, version = 'naa') {
  const b = initial || {};
  return `
    <div class="form-block"><label>Versão</label>
      <select id="${prefix}-ver">${getVersions().map((v) =>
        `<option value="${v.key}" ${(b.version || version) === v.key ? 'selected' : ''}>${v.abbrev} — ${v.name}</option>`
      ).join('')}</select>
    </div>
    <div class="form-block"><label>Livro</label>
      <select id="${prefix}-book">${BOOKS.map((bk) =>
        `<option value="${bk.abbrev}" ${b.book === bk.abbrev ? 'selected' : ''}>${bk.name}</option>`
      ).join('')}</select>
    </div>
    <div class="form-block form-row-2 bible-ref-grid">
      <div><label>Capítulo</label><select id="${prefix}-ch"><option value="">Carregando...</option></select></div>
      <div><label>V. início</label><select id="${prefix}-vs"><option value="">—</option></select></div>
      <div><label>V. fim</label><select id="${prefix}-ve"><option value="">—</option></select></div>
    </div>
    <p class="form-hint" id="${prefix}-bounds">Carregando limites do livro...</p>`;
}

export function bibleExcerptBlock() {
  return `
    <div id="wiz-excerpt-wrap">
      <div class="form-block">
        <label>Referência na tela</label>
        <input id="wiz-ref-override" placeholder="João 17.11 (NAA)" />
        <p class="form-hint">Deixe vazio para gerar automaticamente a partir do livro/capítulo/versículo.</p>
      </div>
      <div class="form-block">
        <label>Trecho bíblico (editável)</label>
        <textarea id="wiz-excerpt" rows="6" placeholder="Cole ou carregue o texto do versículo"></textarea>
      </div>
      <div class="wizard-bible-actions">
        <button type="button" class="btn btn-secondary" id="wiz-load-excerpt">Carregar trecho do versículo</button>
        <button type="button" class="btn btn-secondary" id="wiz-load-full">Carregar versículos completos</button>
      </div>
    </div>
    <p class="form-hint" id="wiz-verses-hint" style="display:none">Os versículos selecionados serão exibidos na projeção (um ou mais slides).</p>`;
}

export function bibleIntroWizardHtml(app) {
  return `
    ${itemTitleField('Introito Bíblico')}
    <p class="form-hint">Introito: ex. <em>João 17.11 (NAA): “...para que sejam um...”</em></p>
    ${biblePickerHtml('wiz', {}, app.prefs.bibleVersion || 'naa')}
    ${bibleModeSelect('excerpt')}
    ${bibleExcerptBlock()}
    <label class="checkbox-inline"><input type="checkbox" id="wiz-open-designer" /> Editar no Designer após adicionar</label>`;
}

export function bibleResponsiveWizardHtml(app, { titleDefault = 'Leitura Responsiva' } = {}) {
  return `
    ${itemTitleField(titleDefault)}
    ${biblePickerHtml('wiz', {}, app.prefs.bibleVersion || 'naa')}
    <p class="form-hint">Versículos ímpares = dirigente · pares = congregação. Ambos visíveis no Stage.</p>`;
}

export function bibleInterlinearWizardHtml(app) {
  return `
    ${itemTitleField('Estudo Interlinear')}
    <p class="form-hint">Original + significado (Strong) + tradução PT — ideal para aula (ex.: Gênesis 1). AT: palavra a palavra; NT: texto grego tokenizado (sem Strong por palavra).</p>
    ${biblePickerHtml('wiz', { book: 'gn', chapter: 1, verseStart: 1, verseEnd: 3 }, app.prefs.bibleVersion || 'naa')}
    <div class="form-block"><label>Idioma original</label>
      <select id="wiz-bible-original-lang">
        <option value="he" selected>Hebraico (AT)</option>
        <option value="grc">Grego (NT)</option>
      </select>
    </div>
    <div class="form-block"><label>Layout</label>
      <select id="wiz-bible-il-layout">
        <option value="study" selected>Estudo (setas original → significado)</option>
        <option value="classic">Clássico</option>
        <option value="word">Palavra a palavra (slides 1, 2, 3…)</option>
        <option value="verse-only">Só original</option>
      </select>
    </div>
    <div class="il-show-toggles">
      <label class="checkbox-inline"><input type="checkbox" id="wiz-il-show-original" checked /> Original</label>
      <label class="checkbox-inline"><input type="checkbox" id="wiz-il-show-gloss" checked /> Significado</label>
      <label class="checkbox-inline"><input type="checkbox" id="wiz-il-show-translation" checked /> Tradução PT</label>
      <label class="checkbox-inline"><input type="checkbox" id="wiz-il-show-strong" /> Strong</label>
    </div>`;
}

export function bibleReadingWizardHtml(app, { titleDefault = 'Leitura Bíblica', compact = false } = {}) {
  return `
    ${itemTitleField(titleDefault)}
    ${compact ? '<p class="form-hint">Cria um item de <strong>Leitura bíblica</strong> completo na ordem.</p>' : ''}
    ${biblePickerHtml('wiz', {}, app.prefs.bibleVersion || 'naa')}
    ${bibleModeSelect('reference', [
      { v: 'reference', l: 'Só referência (Livro Cap:Versículos)' },
      { v: 'chapter', l: 'Capítulo completo (ex.: Números 2) — sem texto' },
      { v: 'verses', l: 'Texto completo do(s) versículo(s) na projeção' },
      { v: 'excerpt', l: 'Referência + trecho editável' },
      { v: 'interlinear', l: 'Interlinear / estudo (original + significado)' },
    ])}
    <div id="wiz-bible-il-extra" style="display:none">
      <div class="form-block"><label>Idioma original</label>
        <select id="wiz-bible-original-lang">
          <option value="he" selected>Hebraico (AT)</option>
          <option value="grc">Grego (NT)</option>
        </select>
        <p class="form-hint">AT: Strong palavra a palavra. NT: grego tokenizado sem Strong por palavra.</p>
      </div>
      <div class="form-block"><label>Layout</label>
        <select id="wiz-bible-il-layout">
          <option value="study" selected>Estudo</option>
          <option value="classic">Clássico</option>
          <option value="word">Palavra a palavra</option>
          <option value="verse-only">Só original</option>
        </select>
      </div>
      <div class="il-show-toggles">
        <label class="checkbox-inline"><input type="checkbox" id="wiz-il-show-original" checked /> Original</label>
        <label class="checkbox-inline"><input type="checkbox" id="wiz-il-show-gloss" checked /> Significado</label>
        <label class="checkbox-inline"><input type="checkbox" id="wiz-il-show-translation" checked /> Tradução PT</label>
        <label class="checkbox-inline"><input type="checkbox" id="wiz-il-show-strong" /> Strong</label>
      </div>
    </div>
    ${bibleExcerptBlock()}
    <label class="checkbox-inline"><input type="checkbox" id="wiz-open-designer" /> Editar no Designer após adicionar</label>`;
}

export function messageMottoBlock() {
  return `
    <h3 class="form-section-title" style="margin-top:.75rem">Trecho / Divisa do versículo</h3>
    <p class="form-hint">Carregue o versículo e edite só a parte que quer na projeção — como a divisa abaixo do tema.</p>
    ${bibleExcerptBlock()}
    <label class="checkbox-inline" style="display:block;margin-top:.5rem">
      <input type="checkbox" id="wiz-msg-show-motto" checked /> Mostrar trecho/divisa na projeção
    </label>`;
}

export function messageWizardHtml(app) {
  const v = app.prefs.bibleVersion || 'naa';
  return `
    ${itemTitleField('Mensagem Bíblica')}
    <div class="form-block"><label>Modo de exibição</label>
      <select id="wiz-msg-mode">${messageModeOptionsHtml('ref_pregador')}</select>
      <p class="form-hint" id="wiz-msg-mode-hint">${getMessageMode('ref_pregador').hint}</p>
    </div>
    <div id="wiz-theme-wrap" style="display:none"><div class="form-block"><label>Tema</label><input id="wiz-theme" value="" /></div></div>
    <div id="wiz-bible-wrap">${biblePickerHtml('wiz', {}, v)}</div>
    <div id="wiz-msg-motto-wrap">${messageMottoBlock()}</div>
    <div id="wiz-preacher-wrap">
    <div class="form-row-2">
      <div class="form-block"><label>Pregador</label><input id="wiz-preacher" value="" /></div>
      <div class="form-block"><label>De onde é</label><input id="wiz-from" value="" /></div>
    </div>
    </div>`;
}

export function freeIntentPanelHtml(intent, app) {
  switch (intent) {
    case 'titulo':
      return `
        ${itemTitleField('Momento')}
        <div class="form-block"><label>Título na projeção</label>
          <input id="wiz-title-only" value="" placeholder="Ex.: Momento de Louvor" /></div>
        <p class="form-hint">Cria um <strong>Seção / Momento</strong> — título em tela cheia.</p>`;
    case 'louvor':
      return lyricsBrowserHtml(app, { titleDefault: 'Louvor', showIntentNote: true });
    case 'biblia':
      return bibleReadingWizardHtml(app, { compact: true });
    case 'oracao':
      return `
        ${itemTitleField('Oração')}
        <div class="form-block"><label>Título na projeção</label>
          <input id="wiz-prayer-screen" value="" placeholder="Ex.: Oração inicial" /></div>
        <p class="form-hint">Cria um item de <strong>Oração</strong> na ordem.</p>`;
    case 'comunicado':
      return `
        ${itemTitleField('Comunicados')}
        <div class="form-block"><label>Avisos (um por linha)</label>
          <textarea id="wiz-free-ann" rows="5" placeholder="📅 Reunião de jovens — sábado 19h"></textarea></div>`;
    case 'designer':
      return `
        ${itemTitleField('Slide Designer')}
        <p class="form-hint">Cria um slide em branco e abre o <strong>Designer</strong> para camadas, fundos e tipografia livre.</p>`;
    case 'texto':
    default:
      return `
        ${itemTitleField('Slide livre')}
        <div class="form-block"><label>Título na projeção</label>
          <input id="wiz-screen-title" value="" placeholder="Se vazio, usa o nome na ordem" /></div>
        <div class="form-block"><label>Subtítulo (opcional)</label>
          <input id="wiz-subtitle" value="" placeholder="Linha de apoio abaixo do título" /></div>
        <div class="form-block"><label>Texto / conteúdo</label>
          <textarea id="wiz-text" rows="7" placeholder="Digite ou cole o conteúdo do slide"></textarea></div>
        <div class="form-row-2">
          <div class="form-block"><label>Alinhamento</label>
            <select id="wiz-align">
              <option value="center">Centro</option>
              <option value="left">Esquerda</option>
              <option value="right">Direita</option>
            </select>
          </div>
          <div class="form-block"><label>Fundo</label>
            <select id="wiz-bg-preset">
              <option value="dark">Escuro</option>
              <option value="gold">Dourado</option>
              <option value="theme">Tema</option>
              <option value="bible">Bíblia</option>
              <option value="communion">Ceia do Senhor</option>
            </select>
          </div>
        </div>
        <label class="checkbox-inline"><input type="checkbox" id="wiz-open-designer" /> Editar no Designer após adicionar</label>`;
  }
}

export function customFreeWizardHtml(app) {
  return `
    <div class="form-block">
      <label>O que deseja criar?</label>
      <select id="wiz-free-intent" class="wiz-free-intent">
        ${FREE_INTENTS.map((i) => `<option value="${i.id}">${esc(i.label)}</option>`).join('')}
      </select>
      <p class="form-hint" id="wiz-free-hint">${esc(FREE_INTENTS[0].hint)}</p>
    </div>
    <div id="wiz-free-mount" class="wiz-free-mount">${freeIntentPanelHtml('texto', app)}</div>`;
}

export function wizardBodyForType(type, app) {
  const church = app.prefs.church || {};
  switch (type) {
    case 'welcome': {
      const w = resolveWelcomePreset('domingo', church);
      const assetUrls = app.getAssetUrls?.() || {};
      const churchBg = assetUrls.welcomeBg
        || (church.welcomeBgPath
          ? (String(church.welcomeBgPath).startsWith('/') ? church.welcomeBgPath : `/${String(church.welcomeBgPath).replace(/^\/+/, '')}`)
          : 'IMG/FRENTE_DA_IGREJA.png');
      const churchBgLabel = church.name?.trim()
        ? `Foto — ${church.name.trim()}`
        : 'Foto da igreja (Ajustes → Igreja)';
      const bgPicker = welcomeBackgroundPickerHtml(app.mediaList || [], {
        selectedId: '',
        churchBg,
        churchBgLabel,
        idField: 'wiz-w-bg-media-id',
        kindField: 'wiz-w-bg-kind',
      });
      return `
        ${itemTitleField('Boas-Vindas')}
        <div class="form-block"><label>Modelo visual</label>
          <select id="wiz-welcome-preset">
            ${WELCOME_PRESETS.map((p) =>
              `<option value="${escAttr(p.id)}" ${p.id === 'domingo' ? 'selected' : ''}>${esc(p.label)}</option>`
            ).join('')}
          </select>
          <p class="form-hint" id="wiz-welcome-preset-hint">${esc(WELCOME_PRESETS[0].description)}</p>
        </div>
        <div class="form-block"><label>Título na tela</label><input id="wiz-years" value="${escAttr(w.years || church.defaultWelcomeTitle || 'Bem-vindos')}" /></div>
        <div class="form-row-2">
          <div class="form-block"><label>Etiqueta</label><input id="wiz-badge" value="${escAttr(w.badge)}" placeholder="Ex.: Culto de Celebração" /></div>
          <div class="form-block"><label>Tema</label><input id="wiz-theme" value="${escAttr(w.theme || church.defaultTheme || '')}" /></div>
        </div>
        <div class="form-block"><label>Linha de apoio</label><input id="wiz-extra" value="${escAttr(w.extraLine || '')}" placeholder="Frase elegante sob o título" /></div>
        <div class="form-block"><label>Fundo na projeção</label>
          ${bgPicker.html}
        </div>
        <details class="wiz-welcome-more">
          <summary>Opções avançadas</summary>
          <div class="form-block"><label>Subtítulo</label><input id="wiz-subtitle" value="${escAttr(w.subtitle || '')}" /></div>
          <div class="form-block"><label>Data (opcional)</label><input id="wiz-date" value="${escAttr(w.dateLine || '')}" /></div>
          <div class="wiz-welcome-toggles">
            <label><input type="checkbox" id="wiz-w-show-logo" checked /> Logo</label>
            <label><input type="checkbox" id="wiz-w-show-church" checked /> Nome da igreja</label>
            <label><input type="checkbox" id="wiz-w-show-badge" checked /> Etiqueta</label>
            <label><input type="checkbox" id="wiz-w-show-theme" checked /> Tema</label>
            <label><input type="checkbox" id="wiz-w-show-extra" checked /> Linha de apoio</label>
          </div>
          <p class="form-hint">Tipografia e animação: refine no inspetor após adicionar.</p>
        </details>
        <label class="checkbox-inline"><input type="checkbox" id="wiz-open-designer" /> Editar no Designer após adicionar</label>`;
    }
    case 'bible-intro':
      return bibleIntroWizardHtml(app);
    case 'prayer':
      return `
        ${itemTitleField('Oração')}
        <div class="form-block"><label>Sugestão rápida</label>
          <select id="wiz-prayer-preset">
            <option value="">— Personalizar —</option>
            <option value="Oração inicial">Oração inicial</option>
            <option value="Oração de Gratidão">Oração de Gratidão</option>
            <option value="Oração Final / Bênção Apostólica">Oração Final / Bênção</option>
            <option value="Oração pelo Pregador">Oração pelo Pregador</option>
          </select>
        </div>
        <p class="form-hint">Na projeção aparece o título em tela cheia.</p>`;
    case 'section':
      return `
        ${itemTitleField('Momento')}
        <div class="form-block"><label>Sugestão rápida</label>
          <select id="wiz-section-preset">
            <option value="">— Personalizar —</option>
            <option value="Momento de louvores">Momento de louvores</option>
            <option value="Dedicação de Vidas e Bens">Dedicação de Vidas e Bens</option>
            <option value="Confraternização">Confraternização</option>
            <option value="Momento de oração">Momento de oração</option>
            <option value="Palavra">Palavra</option>
          </select>
        </div>
        <p class="form-hint">Marcador visual na ordem — título em tela cheia na projeção.</p>`;
    case 'participation':
      return `
        ${itemTitleField('Participação')}
        <div class="form-block"><label>Tipo de participação</label>
          <select id="wiz-part-kind">
            ${PARTICIPATION_KINDS.map((k) => `<option value="${k.id}">${esc(k.label)}</option>`).join('')}
          </select>
        </div>
        <div class="form-block" id="wiz-part-label-wrap" style="display:none"><label>Título na tela</label>
          <input id="wiz-part-label" placeholder="Participação especial" />
        </div>
        <div class="form-block"><label>Nome do participante</label>
          <input id="wiz-part-name" placeholder="Ex.: Verônica Silva" />
        </div>
        <div class="form-block" id="wiz-part-song-wrap">
          <label>Buscar música</label>
          <input type="search" id="wiz-part-song-filter" placeholder="Filtrar louvores…" />
          <select id="wiz-part-song" class="wiz-song-select" size="5">
            <option value="">— Selecionar depois —</option>
            ${songOptionsHtml(songsList(app))}
          </select>
        </div>
        <div class="form-block"><label>Texto extra (opcional)</label>
          <input id="wiz-part-extra" placeholder="Ex.: Louvor especial de encerramento" />
        </div>`;
    case 'lyrics':
      return lyricsBrowserHtml(app, { titleDefault: 'Louvor' });
    case 'bible':
      return bibleReadingWizardHtml(app);
    case 'bible-interlinear':
      return bibleInterlinearWizardHtml(app);
    case 'bible-responsive':
      return bibleResponsiveWizardHtml(app);
    case 'message':
      return messageWizardHtml(app);
    case 'communion':
      return `
        ${itemTitleField('Ceia do Senhor')}
        <p class="form-hint">Quatro fases prontas — Abertura, Pão, Cálice e Meditação — com textos bíblicos (NAA) e visual trigo &amp; vinho.</p>
        <label class="comm-option"><input type="checkbox" id="wiz-comm-elements" checked />
          <span>Ilustrações de trigo e cálice na projeção</span></label>
        <label class="comm-option"><input type="checkbox" id="wiz-comm-theme" checked />
          <span>Paleta trigo &amp; vinho automática</span></label>`;
    case 'announcements':
      return `
        ${itemTitleField('Comunicados')}
        <div class="form-block"><label>Avisos (um por linha — emoji opcional no início)</label>
          <textarea id="wiz-items" rows="6" placeholder="📅 Reunião de jovens — sábado 19h"></textarea></div>`;
    case 'theme':
      return `
        ${itemTitleField('Tema / Divisa')}
        <div class="form-block"><label>Tema</label><input id="wiz-theme" value="SOMOS UM" /></div>
        <div class="form-block"><label>Divisa (referência)</label><input id="wiz-motto" value="João 17.11 (NAA)" placeholder="João 17.11 (NAA)" /></div>
        <div class="form-block"><label>Texto da divisa</label>
          <textarea id="wiz-motto-text" rows="3">...para que sejam um, assim como somos um.</textarea></div>`;
    case 'media':
      return `
        ${itemTitleField('Imagem / Vídeo')}
        <div class="form-block"><label>Arquivo da biblioteca</label>
          <select id="wiz-media"><option value="">— Selecione —</option>
            ${(app.mediaList || []).map((m) => `<option value="${m.id}">${esc(m.name)} (${m.kind})</option>`).join('')}
          </select></div>
        <label class="checkbox-inline"><input type="checkbox" id="wiz-media-loop" checked /> Repetir vídeo (loop)</label>
        <p class="form-hint">Envie imagens/vídeos na aba Mídia se a lista estiver vazia.</p>`;
    case 'media-audio': {
      const tracks = app.ambientTracks || [];
      return `
        ${itemTitleField('Áudio no programa')}
        <p class="form-hint">Áudio toca na projeção enquanto este item estiver ativo (ex.: fundo musical de oração).</p>
        <div class="form-block"><label>Título na tela</label>
          <input id="wiz-screen-title" value="Fundo musical" placeholder="Ex.: Fundo musical" /></div>
        <div class="form-block"><label>Arquivo de áudio</label>
          <select id="wiz-audio">
            <option value="">— Escolher depois no inspetor —</option>
            ${tracks.map((t) => `<option value="${escAttr(t.path)}">${esc(t.fileName || t.path)}</option>`).join('')}
          </select>
        </div>
        <label class="checkbox-inline"><input type="checkbox" id="wiz-audio-loop" /> Repetir em loop</label>
        <div class="form-block"><label>Nota / duração (opcional)</label>
          <input id="wiz-audio-hint" placeholder="Ex.: ~5 minutos de oração" /></div>`;
    }
    case 'offering':
      return `
        ${itemTitleField('Oferta / Dízimo')}
        <div class="form-block"><label>Template visual</label>
          <select id="wiz-offering-tpl" class="su-select">
            <option value="classic">Clássico — Oferta e Dízimos</option>
            <option value="dizimo">Dízimo</option>
            <option value="oferta">Oferta</option>
            <option value="mission">Oferta Missionária</option>
            <option value="sacred">Sagrado / contribuição</option>
            <option value="compact">Compacto (foco no QR)</option>
            <option value="split">Dividido (QR + dados)</option>
          </select>
          <p class="form-hint">O QR PIX vem do plugin Oferta PIX (Ajustes → Plugins). Escolha também onde o QR discreto aparece nas Boas-vindas.</p>
        </div>
        <div class="form-block"><label>Título na projeção</label>
          <input id="wiz-screen-title" value="Oferta e Dízimos" /></div>
        <div class="form-block"><label>Subtítulo (opcional)</label>
          <input id="wiz-offering-sub" placeholder="Ex.: Com alegria e gratidão" /></div>
        <div class="form-block"><label>Versículo / texto (opcional)</label>
          <textarea id="wiz-offering-verse" rows="3" placeholder="Ex.: Cada um contribua segundo o propósito do coração."></textarea></div>`;
    case 'countdown':
      return `
        ${itemTitleField('Pausa')}
        <p class="form-hint">Slide de pausa na ordem. Contagem regressiva pré-culto: botão <strong>Pré-culto</strong> na barra superior.</p>
        <div class="form-block"><label>Título na projeção</label>
          <input id="wiz-screen-title" value="Pausa" /></div>
        <div class="form-block"><label>Duração sugerida (minutos)</label>
          <input type="number" id="wiz-pause-min" min="1" max="60" step="1" placeholder="Ex.: 5" /></div>
        <div class="form-block"><label>Nota na tela (opcional)</label>
          <input id="wiz-pause-note" placeholder="Ex.: Momento de oração silenciosa" /></div>`;
    case 'custom':
      return customFreeWizardHtml(app);
    default:
      return `
        <p class="form-hint wizard-unknown">Tipo <strong>${esc(type)}</strong> sem formulário dedicado.</p>
        ${itemTitleField(TYPE_LABELS[type] || 'Item')}`;
  }
}
