import { getAllMedia, savePrefs } from '../../core/store.js';
import { APP_VERSION, creditsLine } from '../../core/app-meta.js';
import { url as assetUrl, importModule } from '../../core/asset-registry.js';
import { bootDesignerSurface, teardownDesignerSurface } from '../../designer/designer-boot.js';
import { WorshipLibrary } from '../../worship/worship-library.js';
import { LazyLoader } from '../../core/performance/lazy-loader.js';
import { livePreviewDockHtml, bindLivePreviewDock, restorePreviewChromeToDock } from './live-preview-dock.js';
import { renderUnifiedLibraryView } from '../../library/unified-library.js';
import { mountStatusBar } from '../../ui/kit/status-bar.js';
import { bindShellTooltips } from '../../ui/kit/tooltip.js';
import { showSkeletonOverlay, skeletonVariantForView } from '../../ui/kit/skeleton-overlay.js';
import { workspaceForView } from '../workspaces.js';
import { applyUiPrefs } from '../../ui/apply-ui-prefs.js';
import { bindChromeThemeToggle } from '../../ui/chrome-theme.js';
import { faNavIconClass } from '../../core/fa-icons.js';
import { PRODUCT_LOGO_REL } from '../../core/brand-assets.js';
import { escAttr, rawHtml, setHtml } from '../../core/render-engine/index.js';
import { menubarHtml, bindMenubar } from '../ui/menubar.js';

const VIEW_LABELS = {
  live: 'Abrindo Console ao vivo…',
  cultos: 'Abrindo Cultos…',
  program: 'Abrindo Programa…',
  lyrics: 'Abrindo Louvores…',
  media: 'Abrindo Mídia…',
  bible: 'Abrindo Bíblia…',
  library: 'Abrindo Biblioteca…',
  designer: 'Abrindo Designer…',
  settings: 'Abrindo Ajustes…',
  'plugin-store': 'Abrindo Loja de Plugins…',
};

const NAV_GROUPS = [
  {
    id: 'culto',
    label: 'Culto',
    items: [
      { id: 'live', title: 'Console ao vivo', label: 'Ao vivo', iconKey: 'live', hint: 'Ordem, prévia e projeção' },
      { id: 'cultos', title: 'Cultos e agenda', label: 'Cultos', iconKey: 'cultos', hint: 'Agenda e novo culto' },
    ],
  },
  {
    id: 'biblioteca',
    label: 'Biblioteca',
    items: [
      { id: 'lyrics', title: 'Biblioteca de Louvores', label: 'Louvores', iconKey: 'lyrics', hint: 'Letras, cifras e slides' },
      { id: 'bible', title: 'Bíblia', label: 'Bíblia', iconKey: 'bible', hint: 'Passagens e versões' },
      { id: 'media', title: 'Mídia', label: 'Mídia', iconKey: 'media', hint: 'Imagens e vídeos' },
    ],
  },
  {
    id: 'ferramentas',
    label: 'Ferramentas',
    items: [
      { id: 'designer', title: 'Designer de slides', label: 'Designer', iconKey: 'designer', hint: 'Slides personalizados' },
      { id: 'settings', title: 'Ajustes e ajuda', label: 'Ajustes', iconKey: 'settings', hint: 'Preferências' },
    ],
  },
];

async function resolveNavGroups() {
  try {
    const { mergeNavGroups, onContributionsChanged } = await import('../../plugins/contributions.js');
    if (!window.__SOMOSUM_NAV_CONTRIB_WIRED) {
      window.__SOMOSUM_NAV_CONTRIB_WIRED = true;
      onContributionsChanged((kind) => {
        if (kind !== 'nav' && kind !== '*') return;
        const app = window.__SOMOSUM_CONTROL_APP;
        app?.renderSidebarNav?.();
      });
    }
    return mergeNavGroups(NAV_GROUPS);
  } catch {
    return NAV_GROUPS;
  }
}

/** Shell principal — topbar, sidebar agrupada e workspace */
export function wireShellView() {
  return {
    render() {
      try {
        document.querySelectorAll('.somosum-tour-backdrop,.somosum-tour-highlight,.somosum-tour-card').forEach((el) => el.remove());
        const logo = this.getAssetUrls?.()?.logo || PRODUCT_LOGO_REL;
        const churchName = this.prefs?.church?.name?.trim() || 'SOMOSUM';
        const ver = window.SOMOSUM_VERSION || APP_VERSION;
        const ambientPlaying = !!this.getAmbientState?.()?.playing;
        const countdownLive = !!this.isCountdownLive?.();
        const rehearsal = !!this.isRehearsal?.();
        const appEl = document.getElementById('app');
        if (!appEl) return;

        setHtml(appEl, rawHtml(`
          <div class="control-atmosphere" aria-hidden="true"></div>
          <div id="low-spec-banner" class="low-spec-banner" hidden role="status" aria-live="polite">
            <span class="low-spec-banner__text" id="low-spec-banner-text"></span>
            <button type="button" class="low-spec-banner__dismiss" id="low-spec-banner-dismiss" title="Desligar modo economia">Desligar</button>
          </div>
          <div class="control-chrome-head">
          ${menubarHtml()}
          <header class="topbar topbar--broadcast">
            <div class="topbar-brand">
              <button type="button" class="btn btn-secondary btn-icon topbar-sidebar-toggle" id="btn-sidebar-toggle" title="Recolher menu lateral" aria-label="Recolher menu lateral" aria-pressed="false">☰</button>
              <img src="${escAttr(logo)}" alt="" />
              <div>
                <p class="topbar-kicker">SOMOSUM · Controle · v${escAttr(ver)}</p>
                <h1 id="topbar-brand-title">${escAttr(churchName)}</h1>
              </div>
            </div>
            <time class="topbar-clock" id="topbar-clock" datetime="" aria-live="off"></time>
            <div class="topbar-actions">
              <div class="topbar-status topbar-status--compact" id="topbar-status" title="Estado do sistema — clique para detalhes">
                <div class="status-unified" id="status-unified">Sistema…</div>
                <span class="server-health-badge topbar-health-detail" id="server-health" hidden>Servidor OK</span>
                <span class="server-health-badge health-secondary topbar-health-detail" id="projection-health" hidden>Aguardando tela</span>
                <span class="server-health-badge health-secondary topbar-health-detail" id="sync-health" hidden>Sync OK</span>
                <span class="server-health-badge health-secondary topbar-health-detail" id="save-health" hidden>Salvo</span>
              </div>
              <div class="live-badge" id="live-badge"><span class="status-dot"></span><span id="live-text">Aguardando tela</span></div>
              <div class="topbar-ops topbar-ops--primary" role="group" aria-label="Operação ao vivo">
                <button type="button" class="btn btn-secondary rehearsal-btn ${rehearsal ? 'is-active' : ''}" id="btn-rehearsal" title="Alternar ensaio / ao vivo">${rehearsal ? 'Ensaio' : 'Ao vivo'}</button>
                <button type="button" class="btn btn-secondary countdown-top-btn ${countdownLive ? 'is-live' : ''}" id="btn-countdown" title="Abrir painel Pré-culto · atalho C inicia/para a contagem">${countdownLive ? 'Pré-culto ativo' : 'Pré-culto'}</button>
                <button type="button" class="btn btn-secondary ambient-top-btn ${ambientPlaying ? 'is-playing' : ''}" id="btn-ambient" title="Música de fundo neste PC (mesa de som)">${ambientPlaying ? 'Música · tocando' : 'Música'}</button>
                <button type="button" class="btn btn-primary" id="btn-open-screen" title="Abrir projeção (F5)">Projeção</button>
              </div>
              <div class="topbar-ops topbar-ops--secondary" role="group" aria-label="Monitor da projeção">
                <label class="topbar-monitor" id="topbar-monitor-wrap" title="Escolha o monitor ou HDMI da projeção">
                  <span class="topbar-monitor-label">Tela</span>
                  <select id="topbar-projector-display" class="topbar-monitor-select" aria-label="Monitor da projeção">
                    <option value="">Detectando…</option>
                  </select>
                </label>
              </div>
              <button type="button" class="btn btn-secondary btn-icon topbar-chrome-theme" data-chrome-theme-toggle title="Alternar tema claro/escuro" aria-pressed="true" aria-label="Tema">
                <i class="fa-duotone fa-circle-half-stroke" aria-hidden="true"></i>
                <span class="topbar-chrome-theme__label" data-chrome-label>Escuro</span>
              </button>
            </div>
          </header>
          </div>
          <div class="workspace has-live-dock" id="su-workspace">
            <nav class="sidebar su-sidebar-nav control-icon-rail" id="sidebar" data-dock="sidebar" aria-label="Navegação principal"></nav>
            <div class="main-view" id="main-view" data-region="su-main"></div>
            ${livePreviewDockHtml()}
          </div>
          <footer class="su-status-bar control-credits" id="su-status"></footer>`));

        applyUiPrefs(this.prefs);
        bindChromeThemeToggle(document.getElementById('app') || document.body);
        queueMicrotask(() => this._bindLowSpecBanner?.());
        const layout = this.prefs?.layout || {};
        const sidebar = document.getElementById('sidebar');
        const workspace = document.getElementById('su-workspace');
        const dock = document.getElementById('live-preview-dock');
        const collapsed = layout.sidebarCollapsed !== false;
        if (sidebar) {
          sidebar.classList.toggle('is-collapsed', collapsed);
          sidebar.classList.toggle('is-expanded', !collapsed);
          sidebar.dataset.collapsed = collapsed ? '1' : '0';
          if (!collapsed && layout.sidebarWidth) sidebar.style.width = `${layout.sidebarWidth}px`;
          else sidebar.style.width = '';
        }
        workspace?.classList.toggle('sidebar-collapsed', collapsed);
        const toggleBtn = document.getElementById('btn-sidebar-toggle');
        if (toggleBtn) {
          toggleBtn.setAttribute('aria-pressed', collapsed ? 'true' : 'false');
          toggleBtn.title = collapsed ? 'Expandir menu lateral' : 'Recolher menu lateral';
        }
        if (dock && layout.dockWidth) {
          dock.style.flexBasis = `${layout.dockWidth}px`;
          dock.style.width = `${layout.dockWidth}px`;
        }

        this._statusBar = mountStatusBar(document.getElementById('su-status'), {
          left: [
            { id: 'credits', html: creditsLine(ver) },
            { id: 'workspace', html: '', className: '' },
            { id: 'lan', html: '<span class="su-status-bar__chip" id="status-lan-chip">LAN</span>', className: '' },
          ],
          right: [
            { id: 'alert', html: '', className: '' },
            { id: 'sync', html: 'Sync', className: 'is-ok' },
            { id: 'health', html: 'OK', className: 'is-ok' },
            { id: 'save', html: 'Salvo', className: '' },
          ],
        });

        this.renderSidebarNav();
        this.bindShellActions();
        bindMenubar(this);
        this.bindSidebarToggle?.();
        this.startTopbarClock?.();
        this._disposeShellTooltips?.();
        this._disposeShellTooltips = bindShellTooltips(document.getElementById('app'));
        this.bindTopbarMonitorSelect();
        bindLivePreviewDock(this);
        this.renderView();
        this.renderNav();
        this.updateProjectionButtonLabel?.();
        this.syncLiveDockVisibility();
        this.enhanceTopbar?.();
        this.health?.check?.();
        this.refreshCountdownPanel?.();
        this.refreshAmbientPanel?.();
        this.refreshStage?.({ skipInspector: true });
        this.refreshStatusBar?.();
      } catch (err) {
        console.error('[SOMOSUM] shell render', err);
        const appEl = document.getElementById('app');
        if (appEl) {
          setHtml(appEl, rawHtml(`
            <div style="font-family:Segoe UI,sans-serif;background:#0a0a0a;color:#d4c68d;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:2rem;text-align:center">
              <div style="max-width:420px">
                <h1 style="font-size:1.25rem;margin:0 0 .75rem">Falha ao montar o Controle</h1>
                <p style="color:#888;line-height:1.6;margin:0 0 1rem">${escAttr(err?.message || String(err))}</p>
                <button type="button" onclick="location.reload()" style="background:#d4c68d;color:#111;border:none;padding:.7rem 1.4rem;border-radius:8px;cursor:pointer;font-weight:600">Recarregar</button>
              </div>
            </div>`));
        }
      }
    },

    renderSidebarNav() {
      const sidebar = document.getElementById('sidebar');
      if (!sidebar) return;
      void resolveNavGroups().then((groups) => {
        if (!document.getElementById('sidebar')) return;
        const expanded = !sidebar.classList.contains('is-collapsed');
        setHtml(sidebar, rawHtml(groups.map((group) => `
        <div class="nav-group" data-group="${group.id}">
          ${expanded ? `<span class="nav-group-label">${group.label}</span>` : ''}
          ${group.items.map((n) => `
            <button type="button" class="nav-btn ${this.view === n.id ? 'is-active' : ''}" data-view="${escAttr(n.id)}" title="${escAttr(n.title)}">
              <span class="nav-ico" aria-hidden="true"><i class="${faNavIconClass(n.iconKey)}" aria-hidden="true"></i></span>
              ${expanded ? `<span class="nav-copy"><span class="nav-label">${n.label}</span></span>` : ''}
            </button>`).join('')}
        </div>`).join('')));

        sidebar.querySelectorAll('.nav-btn').forEach((btn) => {
          btn.onclick = () => {
            if (typeof this.setView === 'function') this.setView(btn.dataset.view);
            else {
              this.view = btn.dataset.view;
              this.renderView();
              this.renderNav();
            }
            if (this.view === 'designer' || this.view === 'lyrics' || this.view === 'library') return;
            if (this.view === 'live') return;
            this.refreshStage?.({ skipInspector: this.view !== 'program' });
          };
        });
      });
    },

    /**
     * Oculta dock Projetor quando a tela tem prévia própria (Louvores/Designer)
     * ou quando o Programa hospeda o chrome na coluna central.
     */
    syncLiveDockVisibility() {
      const workspace = document.querySelector('.workspace.has-live-dock');
      if (!workspace) return;
      const ws = workspaceForView(this.view);
      const collapse = ws.collapseDock
        || this.view === 'lyrics'
        || this.view === 'designer'
        || this.view === 'program'
        || this.view === 'live'
        || this.view === 'library'
        || this.view === 'cultos'
        || this.view === 'settings'
        || this.view === 'plugin-store'
        || String(this.view || '').startsWith('plugin:');
      workspace.classList.toggle('live-dock-collapsed', collapse);
    },

    refreshStatusBar() {
      const bar = this._statusBar;
      if (!bar) return;
      const ws = workspaceForView(this.view);
      bar.set('workspace', ws.label);
      bar.set('sync', this.screenConnected ? 'Sync OK' : 'Sync…', this.screenConnected ? 'is-ok' : 'is-warn');
      bar.set('health', 'OK', 'is-ok');
      const lanChip = document.getElementById('status-lan-chip');
      if (lanChip) {
        const hasRemote = !!this.prefs?.remote?.enabled;
        lanChip.textContent = hasRemote ? 'Remote ON' : 'LAN';
        lanChip.classList.toggle('is-on', !!this.screenConnected || hasRemote);
      }
      if (!this.screenConnected && this.view === 'live') {
        bar.set('alert', '<span class="su-status-bar__alert">Projeção desconectada</span>', 'is-alert');
      } else {
        bar.set('alert', '', '');
      }
    },

    bindSidebarToggle() {
      const btn = document.getElementById('btn-sidebar-toggle');
      const sidebar = document.getElementById('sidebar');
      const workspace = document.getElementById('su-workspace');
      if (!btn || btn.dataset.bound === '1') return;
      btn.dataset.bound = '1';
      btn.addEventListener('click', () => {
        const next = !sidebar?.classList.contains('is-collapsed');
        sidebar?.classList.toggle('is-collapsed', next);
        sidebar?.classList.toggle('is-expanded', !next);
        workspace?.classList.toggle('sidebar-collapsed', next);
        sidebar && (sidebar.dataset.collapsed = next ? '1' : '0');
        btn.setAttribute('aria-pressed', next ? 'true' : 'false');
        btn.title = next ? 'Expandir menu lateral' : 'Recolher menu lateral';
        this.prefs = savePrefs({
          ...this.prefs,
          layout: { ...(this.prefs.layout || {}), sidebarCollapsed: next },
        });
        sidebar.style.width = '';
        this.renderSidebarNav?.();
        window.dispatchEvent(new Event('resize'));
      });
    },

    startTopbarClock() {
      const el = document.getElementById('topbar-clock');
      if (!el) return;
      if (this._clockTimer) clearInterval(this._clockTimer);
      const tick = () => {
        const now = new Date();
        el.textContent = now.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
        el.dateTime = now.toISOString();
      };
      tick();
      this._clockTimer = setInterval(tick, 30000);
    },

    bindShellActions() {
      document.getElementById('btn-open-screen')?.addEventListener('click', () => {
        this.openProjectionScreen();
        document.documentElement.classList.add('control-shell--presenting');
      });
      this.updateProjectionButtonLabel();
      window.addEventListener('somosum-native-ready', () => this.updateProjectionButtonLabel());

      document.getElementById('btn-ambient')?.addEventListener('click', () => this.toggleAmbientPanel());
      document.getElementById('btn-countdown')?.addEventListener('click', () => this.toggleCountdownPanel());

      document.getElementById('btn-rehearsal')?.addEventListener('click', () => {
        this.toggleRehearsal?.();
        const btn = document.getElementById('btn-rehearsal');
        if (btn) {
          const on = this.isRehearsal?.();
          btn.classList.toggle('is-active', !!on);
          btn.textContent = on ? 'Ensaio' : 'Ao vivo';
        }
        this.enhanceUpdatePreviewBadge?.();
      });

      document.getElementById('status-unified')?.addEventListener('click', () => {
        document.querySelectorAll('.topbar-health-detail').forEach((el) => {
          el.hidden = !el.hidden;
        });
      });
    },

    bindTopbarMonitorSelect() {
      const sel = document.getElementById('topbar-projector-display');
      if (!sel || sel.dataset.bound === '1') return;
      sel.dataset.bound = '1';

      const applySelection = (idx) => {
        if (!Number.isFinite(idx)) return;
        window.Engine?.shell?.setProjectorDisplay?.(idx);
        const settingsSel = document.getElementById('set-projector-display');
        if (settingsSel && settingsSel.value !== String(idx)) {
          settingsSel.value = String(idx);
        }
        try {
          const list = window.Engine?.shell?.getDisplays?.() || [];
          const device = list[idx]?.deviceName;
          if (device) {
            this.prefs = savePrefs({
              ...this.prefs,
              displayEngine: {
                ...(this.prefs.displayEngine || {}),
                projectorDeviceName: device,
              },
            });
          }
        } catch { /* ignore */ }
        this.updateProjectionButtonLabel?.();
        this.toast?.(`Projeção na tela ${idx + 1}`);
      };

      sel.addEventListener('change', () => {
        const idx = parseInt(sel.value, 10);
        applySelection(idx);
      });

      const refresh = () => this.updateProjectionButtonLabel?.();
      window.addEventListener('somosum-display-changed', refresh);
      window.addEventListener('engine-display-changed', refresh);
      window.addEventListener('somosum-native-ready', refresh);
    },

    renderNav() {
      document.querySelectorAll('.nav-btn').forEach((b) => {
        b.classList.toggle('is-active', b.dataset.view === this.view);
      });
    },

    renderView() {
      const main = document.getElementById('main-view');
      if (!main) return;
      // Chrome do projetor pode estar na coluna do Programa — devolver ao dock
      // antes de qualquer innerHTML no main (evita destruir #stage-preview).
      restorePreviewChromeToDock();

      const prevView = this._lastRenderedView;
      if (prevView === 'live' && this.view !== 'live') {
        this._liveLibrary?.destroy?.();
        this._liveLibrary = null;
      }
      if (prevView === 'lyrics' && this.view !== 'lyrics') {
        this._worshipLibrary?.destroy?.();
        this._worshipLibrary = null;
        this.lyricsEditor = null;
        this._worshipReady = null;
      }

      const bootBusy = !!document.getElementById('boot-loading');
      const variant = skeletonVariantForView(this.view);
      const hideSkel = bootBusy
        ? () => {}
        : showSkeletonOverlay(main, {
            variant,
            message: VIEW_LABELS[this.view] || 'Carregando…',
            minMs: 420,
          });

      try {
        // `program` legado → Live Console (sem dock ← Projetar →).
        if (this.view === 'program') this.view = 'live';
        if (this.view === 'live') this.renderLiveConsoleView(main);
        else if (this.view === 'cultos') this.renderCultosView(main);
        else if (this.view === 'lyrics') this.renderLyricsView(main, hideSkel);
        else if (this.view === 'media') this.renderMediaView(main, hideSkel);
        else if (this.view === 'bible') void this.renderBibleView(main, hideSkel);
        else if (this.view === 'library') renderUnifiedLibraryView(this, main);
        else if (this.view === 'designer') this.renderDesignerView(main, hideSkel);
        else if (this.view === 'settings') this.renderSettingsView(main);
        else if (this.view === 'plugin-store') {
          try { localStorage.setItem('somosum.panel.section', 'loja'); } catch { /* ignore */ }
          if (window.Engine?.shell?.openManagementPanel) {
            window.Engine.shell.openManagementPanel('loja');
          } else {
            window.open('/launcher/panel.html?section=loja', 'somosum-management');
          }
          this.setView?.('settings');
          hideSkel?.();
        }
        else this.renderPluginView(main);
      } catch (err) {
        console.error('[SOMOSUM] renderView', err);
        setHtml(main, rawHtml(`<div class="view-panel is-active" style="padding:2rem;color:#f59e0b">Erro ao abrir esta tela. Use Ctrl+F5 ou reinicie o SOMOSUM.<br><small style="color:#888">${escAttr(err?.message || '')}</small></div>`));
      }
      this.syncLiveDockVisibility?.();
      this.refreshStatusBar?.();
      main.querySelector('.view-panel')?.classList.add('su-motion-view');

      // Views síncronas: esconde após paint. Async (lyrics/media/designer) chamam hideSkel sozinhas.
      if (!['lyrics', 'media', 'designer'].includes(this.view)) {
        requestAnimationFrame(() => requestAnimationFrame(() => hideSkel()));
      }
      this._lastRenderedView = this.view;
    },

    renderLyricsView(main, hideSkel) {
      setHtml(main, rawHtml(`<div class="view-panel is-active full-panel" id="lyrics-root"></div>`));
      if (this._worshipLibrary) this._worshipLibrary.destroy?.();
      this._worshipLibrary = new WorshipLibrary(document.getElementById('lyrics-root'), this, {
        onSave: async () => {
          try {
            const { getAllSongs } = await import('../../core/store.js');
            this.songs = await getAllSongs();
          } catch { /* ignore */ }
          this.program?.clearSongCache?.();
          await this.program?.rebuild?.();
          this.syncProjectorState?.(false);
        },
        onDelete: async () => {
          try {
            const { getAllSongs } = await import('../../core/store.js');
            this.songs = await getAllSongs();
          } catch { /* ignore */ }
          this.program?.clearSongCache?.();
        },
        onAddToCulto: () => {
          this.program?.clearSongCache?.();
          this.markProgramDirty?.();
        },
        onToast: (msg) => this.toast?.(msg, 'info'),
      });
      this.lyricsEditor = this._worshipLibrary;
      this._worshipReady = this._worshipLibrary.init()
        .then(() => this._worshipLibrary)
        .catch((err) => {
          console.error('[SOMOSUM] worship init', err);
          return this._worshipLibrary;
        });
      requestAnimationFrame(() => requestAnimationFrame(() => hideSkel?.()));
    },

    renderMediaView(main, hideSkel) {
      import('../../media/media-library.js').then(({ MediaLibrary }) => {
        if (!this._mediaLibrary) this._mediaLibrary = new MediaLibrary(this);
        this._mediaLibrary.mount(main);
        requestAnimationFrame(() => requestAnimationFrame(() => hideSkel?.()));
      }).catch(() => hideSkel?.());
    },

    async renderBibleView(main, hideSkel) {
      try {
        const { renderBibleView } = await LazyLoader.load('bible-reader');
        await this.ensureBibleReader?.();
        const { preloadVersion } = await import('../../bible/bible-service.js');
        void preloadVersion(this.prefs?.bibleVersion || 'naa').catch(() => {});
        renderBibleView(this, main);
      } catch (err) {
        console.error('[SOMOSUM] bible view', err);
        setHtml(main, rawHtml('<div class="view-panel is-active" style="padding:2rem;color:#f59e0b">Não foi possível abrir a Bíblia. Tente novamente.</div>'));
      } finally {
        requestAnimationFrame(() => requestAnimationFrame(() => hideSkel?.()));
      }
    },

    renderDesignerView(main, hideSkel) {
      setHtml(main, rawHtml('<div class="designer-view-root" id="designer-root"></div>'));
      teardownDesignerSurface();
      this._designer?.destroy();
      this._designer = null;
      void getAllMedia().then((list) => {
        this.mediaList = list;
      }).catch(() => {});
      void (async () => {
        let boot;
        try {
          boot = await bootDesignerSurface();
        } catch (err) {
          setHtml(main, rawHtml(`<div class="designer-error" style="padding:2rem;color:#f59e0b;line-height:1.6">${String(err?.message || err || 'Falha ao preparar o Designer').replace(/[<>&]/g, '')}</div>`));
          hideSkel?.();
          return;
        }
        if (this.view !== 'designer') {
          teardownDesignerSurface();
          hideSkel?.();
          return;
        }
        const { SlideDesigner } = await importModule('/js/designer/slide-designer.js');
        if (this.view !== 'designer') {
          teardownDesignerSurface();
          hideSkel?.();
          return;
        }
        const root = main.querySelector('#designer-root');
        if (!root) {
          teardownDesignerSurface();
          hideSkel?.();
          return;
        }
        this._designer = new SlideDesigner(root, this);
        if (boot?.fonts?.length) this._designer._fonts = boot.fonts;
        await this._designer.mount();
        const pendingIdx = this._designerPendingItem;
        if (pendingIdx != null) {
          const item = this.program.items[pendingIdx];
          this._designer?.loadFromItem(item);
          this._designer?.setSourceItemIndex?.(pendingIdx);
          this._designerPendingItem = null;
        }
        requestAnimationFrame(() => requestAnimationFrame(() => hideSkel?.()));
      })().catch((err) => {
        console.error('[SOMOSUM designer]', err);
        teardownDesignerSurface();
        this.toast?.('Falha ao carregar o Designer — pressione Ctrl+F5', 'error');
        hideSkel?.();
      });
    },

    renderPluginStoreView(main, hideSkel) {
      setHtml(main, rawHtml(`<div class="view-panel is-active full-panel" id="plugin-store-mount"></div>`));
      void import('../../plugins/ui/plugin-store.js').then(({ mountPluginStore }) => {
        const el = document.getElementById('plugin-store-mount');
        return mountPluginStore(el, this);
      }).catch((err) => {
        console.error('[SOMOSUM] plugin store', err);
        setHtml(main, rawHtml(`<div class="view-panel is-active" style="padding:2rem;color:#f59e0b">Erro ao abrir a Loja de Plugins.<br><small style="color:#888">${escAttr(err?.message || '')}</small></div>`));
      }).finally(() => {
        requestAnimationFrame(() => requestAnimationFrame(() => hideSkel?.()));
      });
    },

    renderPluginView(main) {
      const viewId = this.view;
      setHtml(main, rawHtml(`<div class="view-panel is-active plugin-host-view" id="plugin-view-root" data-plugin-view="${escAttr(viewId)}"></div>`));
      const root = main.querySelector('#plugin-view-root');
      void import('../../plugins/contributions.js').then(({ listContributions }) => {
        const views = listContributions('view');
        const match = views.find((v) => v.viewId === viewId || v.id === viewId || `plugin:${v.pluginId}` === viewId);
        if (!match?.render) {
          setHtml(root, rawHtml('<p class="form-hint" style="padding:1.5rem">Plugin view indisponível.</p>'));
          return;
        }
        try {
          match.render(root, this);
        } catch (err) {
          setHtml(root, rawHtml(`<p class="form-hint" style="padding:1.5rem">Erro: ${escAttr(err?.message || String(err))}</p>`));
        }
      });
    },
  };
}
