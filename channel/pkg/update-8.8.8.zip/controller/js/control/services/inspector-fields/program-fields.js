import { getAllSongs } from '../../../core/store.js';
import { shouldBlockHeavyInspectorSync } from '../../../core/live-culto-mode.js';
import { getCustomFontList, fontPickerHtml } from '../../../core/fonts.js';
import { fontPickerPairHtml as renderFontPickerPair, bindFontPickerPair, readFontPickerPair } from '../../../core/font-picker-ui.js';
import { esc, escAttr, rawHtml, setHtml } from '../../../core/render-engine/index.js';
import { formatCultoDate } from '../../utils/culto-date.js';
import { showAddSlideWizard } from '../../add-slide-wizard.js';
import { slideBackgroundPickerHtml, bindSlideBackgroundPicker, syncWelcomeBackgroundPickerUI } from '../../../core/media-url.js';

export const programInspectorFields = {
  bindProgramOrderInspector(el, meta) {
    const total = this.program.items.length;
    const pos = meta.itemIndex + 1;
    el.querySelector('#insp-dup')?.addEventListener('click', () => {
      this.duplicateProgramItem(meta.itemIndex);
    });
    el.querySelector('#insp-move-pos')?.addEventListener('click', () => {
      const input = el.querySelector('#insp-position');
      const val = Number(input?.value);
      if (!val || val < 1 || val > total) {
        this.toast(`Informe uma posicao entre 1 e ${total}`, 'warn');
        return;
      }
      this.moveProgramItemToPosition(meta.itemIndex, val);
    });
    el.querySelector('#insp-position')?.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') el.querySelector('#insp-move-pos')?.click();
    });
  },

  programOrderToolsHtml(meta) {
    const total = this.program.items.length;
    const pos = meta.itemIndex + 1;
    return `
          <div class="form-block program-order-tools">
            <label>Ordem no culto</label>
            <p class="form-hint">Posição ${pos} de ${total}. Duplique a seção ou mova para outro momento.</p>
            <div class="program-order-row">
              <span class="program-order-pos-label">#</span>
              <input type="number" id="insp-position" min="1" max="${total}" value="${pos}" class="program-order-pos-input" title="Posição na ordem" />
              <button type="button" class="btn btn-secondary btn-sm" id="insp-move-pos">Mover</button>
              <button type="button" class="btn btn-secondary btn-sm" id="insp-dup" title="Duplicar seção completa">Duplicar</button>
            </div>
          </div>`;
  },

  renderCultoBanner() {
    const el = document.getElementById('culto-active-banner');
    if (!el) return;
    const activeId = this.cultoIndex.activeId;
    if (!activeId) {
      setHtml(el, '<span class="culto-banner-warn">Nenhum culto ativo — selecione ou crie um no Calendário</span>');
      el.classList.add('is-empty');
      el.hidden = false;
      return;
    }
    el.classList.remove('is-empty');
    const meta = this.cultoIndex.cultos.find((c) => c.id === activeId);
    if (!meta) {
      el.textContent = '';
      el.hidden = true;
      return;
    }
    el.hidden = false;
    const dateLabel = formatCultoDate(meta.date, {
      weekday: 'short', day: '2-digit', month: '2-digit',
    });
    const time = meta.serviceTime ? ` · ${meta.serviceTime}` : '';
    const estimatedSec = this.program.items.reduce((sum, item) => sum + (Number(item.rehearsal?.estimatedSec) || 0), 0);
    const estimatedMin = estimatedSec ? ` · ensaio ~${Math.round(estimatedSec / 60)} min` : '';
    setHtml(el, rawHtml(`
          <span class="culto-banner-label">Editando culto:</span>
          <strong>${esc(meta.title)}</strong>
          <span class="culto-banner-meta">${esc(dateLabel)}${esc(time)} · ${this.program.items.length} itens${esc(estimatedMin)}</span>
          <button type="button" class="btn btn-secondary btn-sm culto-banner-link" id="btn-switch-culto">Trocar culto</button>`));
    el.querySelector('#btn-switch-culto')?.addEventListener('click', () => {
      this.showCultoSwitchModal();
    });
  },

  bindAddSlideMenu() {
    const addBtn = document.getElementById('btn-add');
    const addMenu = document.getElementById('add-slide-menu');
    if (!addBtn || !addMenu) return;

    const positionMenu = () => {
      const r = addBtn.getBoundingClientRect();
      addMenu.style.top = `${Math.min(r.bottom + 4, window.innerHeight - 8)}px`;
      addMenu.style.left = `${Math.max(8, r.right - 260)}px`;
      addMenu.style.maxHeight = `${Math.max(200, window.innerHeight - r.bottom - 12)}px`;
    };

    addBtn.onclick = (e) => {
      e.stopPropagation();
      if (!this.cultoIndex.activeId) {
        this.toast('Selecione ou crie um culto no Calendário');
        return;
      }
      if (!addMenu.dataset.portaled) {
        document.body.appendChild(addMenu);
        addMenu.dataset.portaled = '1';
      }
      const opening = !addMenu.classList.contains('is-open');
      addMenu.classList.toggle('is-open');
      if (opening) positionMenu();
    };

    addMenu.onclick = (e) => e.stopPropagation();
    addMenu.querySelectorAll('.add-slide-option').forEach((btn) => {
      btn.onclick = (e) => {
        e.stopPropagation();
        addMenu.classList.remove('is-open');
        showAddSlideWizard(this, btn.dataset.type);
      };
    });

    if (!this._addMenuDocBound) {
      this._addMenuDocBound = true;
      document.addEventListener('click', (e) => {
        const menu = document.getElementById('add-slide-menu');
        if (menu?.classList.contains('is-open') && !e.target.closest('.add-slide-wrap') && !e.target.closest('#add-slide-menu')) {
          menu.classList.remove('is-open');
        }
      });
      window.addEventListener('resize', () => {
        if (document.getElementById('add-slide-menu')?.classList.contains('is-open')) positionMenu();
      });
    }
  },

  async syncAfterSongChange() {
    if (shouldBlockHeavyInspectorSync()) return;
    this.program.clearSongCache();
    this.songs = await getAllSongs();
    await this.program.rebuild();
    // syncAll já chama refreshStage — evita double refresh
    this.syncAll(false);
  },

  fontOptionsHtml(selected = '') {
    const extra = this.customFonts?.length ? this.customFonts : getCustomFontList();
    return fontPickerHtml(selected, { includeEmpty: true, extra });
  },

  fontPickerPairHtml(family, style = {}, ids = {}) {
    const extra = this.customFonts?.length ? this.customFonts : getCustomFontList();
    return renderFontPickerPair(family, {
      familyId: ids.familyId || 'insp-style-font',
      variantId: ids.variantId || 'insp-style-font-variant',
      fontWeight: style.fontWeight,
      fontStyle: style.fontStyle,
      includeEmpty: true,
      extra,
    });
  },

  defaultProgramStyle(type) {
    const defaults = {
      welcome: { titleSize: 92, textSize: 30, textTransform: 'none', align: 'center', titleColor: '#fff8ec', textColor: '#ffffff', fontFamily: 'Montserrat' },
      section: { titleSize: 86, textSize: 30, textTransform: 'uppercase', align: 'center', titleColor: '#ffffff', textColor: '#a8a8a8', fontFamily: 'Montserrat' },
      prayer: { titleSize: 86, textSize: 30, textTransform: 'uppercase', align: 'center', titleColor: '#d4af37', textColor: '#ffffff', fontFamily: 'Montserrat', backgroundPreset: 'dark' },
      bible: { titleSize: 92, textSize: 52, textTransform: 'uppercase', align: 'center', vAlign: 'center', titleColor: '#d4af37', textColor: '#ffffff', refColor: '#d4af37', fontFamily: 'Open Sans' },
      custom: { titleSize: 76, textSize: 34, textTransform: 'none', align: 'center', titleColor: '#d4af37', textColor: '#ffffff', fontFamily: 'Open Sans' },
      announcements: { titleSize: 72, textSize: 32, textTransform: 'none', align: 'left', titleColor: '#d4af37', textColor: '#ffffff', fontFamily: 'Open Sans' },
      theme: { titleSize: 86, textSize: 34, textTransform: 'none', align: 'center', titleColor: '#d4af37', textColor: '#ffffff', fontFamily: 'Montserrat' },
      media: { titleSize: 34, textSize: 28, textTransform: 'none', align: 'center', titleColor: '#ffffff', textColor: '#ffffff', fontFamily: 'Open Sans' },
      participation: { titleSize: 52, textSize: 36, nameSize: 88, textTransform: 'none', align: 'center', titleColor: '#d4af37', textColor: '#ffffff', fontFamily: 'Montserrat', textEffect: 'outline', bgDim: 0.28 },
      communion: { titleSize: 72, textSize: 34, textTransform: 'none', align: 'center', titleColor: '#f5efe6', textColor: '#f5efe6', refColor: '#c9a227', fontFamily: 'Montserrat', textEffect: 'outline', bgDim: 0.28 },
      offering: { titleSize: 72, textSize: 32, textTransform: 'none', align: 'center', titleColor: '#d4af37', textColor: '#ffffff', fontFamily: 'Montserrat' },
      countdown: { titleSize: 72, textSize: 28, textTransform: 'none', align: 'center', titleColor: '#ffffff', textColor: '#ffffff', fontFamily: 'Montserrat' },
    };
    return defaults[type] || defaults.custom;
  },

  slideStyleColorControlsHtml(st, { showRef = false, idPrefix = 'insp-style' } = {}) {
    const titleColor = st.titleColor || '#ffffff';
    const textColor = st.textColor || '#ffffff';
    const refColor = st.refColor || '#d4af37';
    return `
              <div class="font-toolbar-group insp-color-row">
                <span class="font-toolbar-label">Cores na tela</span>
                <label class="insp-color-chip" title="Cor do título">
                  <span>Título</span>
                  <input type="color" id="${idPrefix}-title-color" value="${escAttr(titleColor)}" />
                </label>
                <label class="insp-color-chip" title="Cor do texto">
                  <span>Texto</span>
                  <input type="color" id="${idPrefix}-text-color" value="${escAttr(textColor)}" />
                </label>
                ${showRef ? `
                <label class="insp-color-chip" title="Cor da referência">
                  <span>Ref.</span>
                  <input type="color" id="${idPrefix}-ref-color" value="${escAttr(refColor)}" />
                </label>` : ''}
              </div>`;
  },

  /** Fundo escurecido + contorno/placa — legibilidade em vídeo claro */
  slideLegibilityControlsHtml(st = {}, { idPrefix = 'insp-style' } = {}) {
    const effect = st.textEffect || 'outline';
    const dimRaw = Number(st.bgDim);
    const dimPct = Math.round((Number.isFinite(dimRaw) ? dimRaw : 0.28) * 100);
    return `
              <div class="font-toolbar-group">
                <span class="font-toolbar-label">Texto legível</span>
                <select id="${idPrefix}-text-effect" title="Quando o fundo é claro demais">
                  <option value="shadow" ${effect === 'shadow' ? 'selected' : ''}>Sombra</option>
                  <option value="outline" ${effect === 'outline' ? 'selected' : ''}>Contorno</option>
                  <option value="plate" ${effect === 'plate' ? 'selected' : ''}>Placa (preenchimento)</option>
                  <option value="none" ${effect === 'none' ? 'selected' : ''}>Nenhum</option>
                </select>
              </div>
              <div class="font-toolbar-group">
                <span class="font-toolbar-label">Escurecer fundo</span>
                <input type="range" id="${idPrefix}-bg-dim" min="0" max="75" step="5" value="${dimPct}"
                  title="Útil com vídeo/imagem claros" aria-label="Escurecer fundo" />
                <span class="font-size-readout" id="${idPrefix}-bg-dim-readout">${dimPct}%</span>
              </div>
              <div class="font-toolbar-group">
                <span class="font-toolbar-label">Posição</span>
                <select id="${idPrefix}-valign">
                  <option value="center" ${(st.vAlign || 'center') === 'center' ? 'selected' : ''}>Centro</option>
                  <option value="top" ${st.vAlign === 'top' ? 'selected' : ''}>Topo</option>
                  <option value="bottom" ${st.vAlign === 'bottom' ? 'selected' : ''}>Base</option>
                </select>
              </div>`;
  },

  readSlideLegibilityStyle(el, idPrefix = 'insp-style') {
    const dimRaw = Number(el.querySelector(`#${idPrefix}-bg-dim`)?.value);
    return {
      textEffect: el.querySelector(`#${idPrefix}-text-effect`)?.value || 'outline',
      bgDim: Number.isFinite(dimRaw) ? Math.max(0, Math.min(0.75, dimRaw / 100)) : 0.28,
      vAlign: el.querySelector(`#${idPrefix}-valign`)?.value || 'center',
    };
  },

  bindSlideLegibilityControls(el, meta, { idPrefix = 'insp-style' } = {}) {
    const dim = el.querySelector(`#${idPrefix}-bg-dim`);
    const readout = el.querySelector(`#${idPrefix}-bg-dim-readout`);
    const live = () => this.scheduleInspectorLiveSync?.(meta, el, 80);
    dim?.addEventListener('input', () => {
      if (readout) readout.textContent = `${dim.value}%`;
      live();
    });
    el.querySelector(`#${idPrefix}-text-effect`)?.addEventListener('change', live);
    el.querySelector(`#${idPrefix}-valign`)?.addEventListener('change', live);
  },

  slideBackgroundInspectorHtml(item, { idPrefix = 'insp-slide' } = {}) {
    const st = { ...this.defaultProgramStyle(item.slideType), ...(item.data?.style || {}) };
    const preset = st.backgroundPreset || 'theme';
    const { html } = slideBackgroundPickerHtml(this.mediaList || [], {
      selectedId: st.backgroundMediaId || '',
      idField: `${idPrefix}-bg-media-id`,
      kindField: `${idPrefix}-bg-kind`,
    });
    return `
          <section class="insp-card">
            <header class="insp-card-head">
              <h3 class="form-section-title">Fundo na projeção</h3>
              <p class="form-hint insp-card-lead">Vídeo em loop ou imagem — igual ao slide Bem-vindo.</p>
            </header>
            <div class="form-block">
              <label>Gradiente / tema</label>
              <div class="insp-visual-tiles" id="${idPrefix}-bg-preset-tiles" role="listbox" aria-label="Gradiente">
                <button type="button" class="insp-visual-tile${preset === 'theme' ? ' is-selected' : ''}" data-preset="theme">Tema</button>
                <button type="button" class="insp-visual-tile insp-visual-tile--dark${preset === 'dark' ? ' is-selected' : ''}" data-preset="dark">Escuro</button>
                <button type="button" class="insp-visual-tile insp-visual-tile--gold${preset === 'gold' ? ' is-selected' : ''}" data-preset="gold">Dourado</button>
              </div>
              <select id="${idPrefix}-bg-preset" hidden>
                <option value="theme" ${preset === 'theme' ? 'selected' : ''}>Tema</option>
                <option value="dark" ${preset === 'dark' ? 'selected' : ''}>Escuro</option>
                <option value="gold" ${preset === 'gold' ? 'selected' : ''}>Dourado</option>
              </select>
            </div>
            ${html}
          </section>`;
  },

  bindSlideBackgroundInspector(el, meta, { idPrefix = 'insp-slide', onChange } = {}) {
    const presetSel = el.querySelector(`#${idPrefix}-bg-preset`);
    const tiles = el.querySelector(`#${idPrefix}-bg-preset-tiles`);
    const syncPresetTiles = () => {
      const v = presetSel?.value || 'theme';
      tiles?.querySelectorAll('.insp-visual-tile').forEach((btn) => {
        btn.classList.toggle('is-selected', btn.getAttribute('data-preset') === v);
      });
    };
    tiles?.addEventListener('click', (ev) => {
      const btn = ev.target?.closest?.('.insp-visual-tile');
      if (!btn || !tiles.contains(btn)) return;
      const preset = btn.getAttribute('data-preset') || 'theme';
      if (presetSel) presetSel.value = preset;
      syncPresetTiles();
      const mediaId = el.querySelector(`#${idPrefix}-bg-media-id`);
      if (mediaId) mediaId.value = '';
      syncWelcomeBackgroundPickerUI(el, { id: '', kind: 'image', label: 'Gradiente / tema' });
      onChange?.();
      this.scheduleInspectorLiveSync?.(meta, el, 120);
    });
    presetSel?.addEventListener('change', () => {
      syncPresetTiles();
      onChange?.();
    });
    bindSlideBackgroundPicker(el, {
      onChange: ({ id }) => {
        if (id && presetSel) presetSel.value = 'theme';
        syncPresetTiles();
        onChange?.();
        this.scheduleInspectorLiveSync?.(meta, el, 120);
      },
    });
  },

  readSlideBackgroundStyle(el, idPrefix = 'insp-slide', prev = null) {
    const mediaEl = el.querySelector(`#${idPrefix}-bg-media-id`);
    const presetEl = el.querySelector(`#${idPrefix}-bg-preset`);
    // Se o controle de fundo não está neste fragmento, preserva o fundo atual do item
    // em vez de zerá-lo (evita perder o fundo definido pela galeria "Fundo" ao vivo).
    if (!mediaEl && !presetEl) {
      return {
        backgroundMediaId: prev?.backgroundMediaId ?? null,
        backgroundPreset: prev?.backgroundPreset ?? 'theme',
      };
    }
    return {
      backgroundMediaId: mediaEl?.value || null,
      backgroundPreset: presetEl?.value || 'theme',
    };
  },

  programStyleControlsHtml(item) {
    const st = { ...this.defaultProgramStyle(item.slideType), ...(item.data?.style || {}) };
    return `
          ${this.slideBackgroundInspectorHtml(item)}
          <section class="insp-card">
            <header class="insp-card-head">
              <h3 class="form-section-title">Legibilidade na projeção</h3>
              <p class="form-hint insp-card-lead">Alinhar move o bloco na tela (não só o texto). Ajuste ao vivo conforme o projetor.</p>
            </header>
            <div class="font-toolbar program-font-toolbar insp-font-grid">
              <div class="font-toolbar-group">
                <span class="font-toolbar-label">Título</span>
                <button type="button" class="btn btn-secondary btn-icon font-size-btn" id="insp-style-title-minus">A−</button>
                <span class="font-size-readout" id="insp-style-title-readout">${st.titleSize}</span>
                <button type="button" class="btn btn-secondary btn-icon font-size-btn" id="insp-style-title-plus">A+</button>
              </div>
              <div class="font-toolbar-group">
                <span class="font-toolbar-label">Texto</span>
                <button type="button" class="btn btn-secondary btn-icon font-size-btn" id="insp-style-text-minus">A−</button>
                <span class="font-size-readout" id="insp-style-text-readout">${st.textSize}</span>
                <button type="button" class="btn btn-secondary btn-icon font-size-btn" id="insp-style-text-plus">A+</button>
              </div>
              ${this.slideStyleColorControlsHtml(st)}
              <div class="font-toolbar-group font-picker-group">
                <span class="font-toolbar-label">Fonte</span>
                ${this.fontPickerPairHtml(st.fontFamily || '', st, { familyId: 'insp-style-font', variantId: 'insp-style-font-variant' })}
                <button type="button" class="btn btn-secondary btn-sm" id="insp-fonts-reload" title="Lê view/fonts e view/FONTE de novo">Recarregar fontes</button>
              </div>
              <div class="font-toolbar-group">
                <span class="font-toolbar-label">Caixa</span>
                <select id="insp-style-transform">
                  <option value="none" ${(st.textTransform || 'none') === 'none' ? 'selected' : ''}>Normal</option>
                  <option value="uppercase" ${st.textTransform === 'uppercase' ? 'selected' : ''}>MAIÚSCULAS</option>
                  <option value="lowercase" ${st.textTransform === 'lowercase' ? 'selected' : ''}>minúsculas</option>
                  <option value="capitalize" ${st.textTransform === 'capitalize' ? 'selected' : ''}>Primeira Maiúscula</option>
                </select>
              </div>
              <div class="font-toolbar-group">
                <span class="font-toolbar-label">Alinhar</span>
                <select id="insp-style-align">
                  <option value="center" ${(st.align || 'center') === 'center' ? 'selected' : ''}>Centro</option>
                  <option value="left" ${st.align === 'left' ? 'selected' : ''}>Esquerda</option>
                  <option value="right" ${st.align === 'right' ? 'selected' : ''}>Direita</option>
                </select>
              </div>
              ${this.slideLegibilityControlsHtml(st)}
            </div>
          </section>`;
  },

  bindProgramStyleToolbar(el, meta = null) {
    const bindStep = (minusId, plusId, readoutId, min, max, step) => {
      const readout = el.querySelector(readoutId);
      el.querySelector(minusId)?.addEventListener('click', () => {
        const n = Math.max(min, (Number(readout.textContent) || min) - step);
        readout.textContent = n;
      });
      el.querySelector(plusId)?.addEventListener('click', () => {
        const n = Math.min(max, (Number(readout.textContent) || min) + step);
        readout.textContent = n;
      });
    };
    bindStep('#insp-style-title-minus', '#insp-style-title-plus', '#insp-style-title-readout', 24, 140, 4);
    bindStep('#insp-style-text-minus', '#insp-style-text-plus', '#insp-style-text-readout', 18, 100, 2);
    bindStep('#insp-style-ref-minus', '#insp-style-ref-plus', '#insp-style-ref-readout', 18, 100, 2);
    bindFontPickerPair(el, {
      familySelector: '#insp-style-font',
      variantSelector: '#insp-style-font-variant',
    });
    this.bindSlideLegibilityControls(el, meta);
    el.querySelector('#insp-fonts-reload')?.addEventListener('click', async () => {
      try {
        const { reloadCustomFonts, fontPickerOptionsHtml } = await import('../../../core/fonts.js');
        await reloadCustomFonts();
        const fam = el.querySelector('#insp-style-font');
        if (fam) {
          const cur = fam.value;
          fam.innerHTML = fontPickerOptionsHtml(cur);
        }
        try {
          this.bus?.send?.(
            (await import('../../../core/bus.js')).MessageTypes.FONTS_RELOAD,
            { at: Date.now() },
          );
        } catch { /* ignore */ }
        this.toast?.('Fontes atualizadas — pasta fonts/ e FONTE/');
      } catch (err) {
        this.toast?.(`Erro ao recarregar fontes: ${err?.message || err}`);
      }
    });
  },

  readProgramStyle(el, type, prev = null) {
    const fallback = this.defaultProgramStyle(type);
    const base = {
      titleSize: Number(el.querySelector('#insp-style-title-readout')?.textContent) || fallback.titleSize,
      textSize: Number(el.querySelector('#insp-style-text-readout')?.textContent) || fallback.textSize,
      refSize: Number(el.querySelector('#insp-style-ref-readout')?.textContent) || fallback.refSize || null,
      ...readFontPickerPair(el, {
        familySelector: '#insp-style-font',
        variantSelector: '#insp-style-font-variant',
      }),
      textTransform: el.querySelector('#insp-style-transform')?.value || fallback.textTransform,
      align: el.querySelector('#insp-style-align')?.value || fallback.align,
      titleColor: el.querySelector('#insp-style-title-color')?.value || fallback.titleColor || null,
      textColor: el.querySelector('#insp-style-text-color')?.value || fallback.textColor || null,
      refColor: el.querySelector('#insp-style-ref-color')?.value || fallback.refColor || null,
      ...this.readSlideLegibilityStyle(el),
      ...this.readSlideBackgroundStyle(el, 'insp-slide', prev),
    };
    if (type === 'participation') {
      base.nameSize = base.titleSize || fallback.nameSize || 88;
    }
    return base;
  },
};
