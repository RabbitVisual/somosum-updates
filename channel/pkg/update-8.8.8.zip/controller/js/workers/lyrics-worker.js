/**
 * Worker: agrupa por linhas poéticas (\\n).
 * N linhas por slide = N linhas na tela (sem soft-wrap que parte frases).
 */
function healLeadingPunctuation(lines) {
  const out = [];
  for (const raw of lines || []) {
    const line = String(raw || '').trim();
    if (!line) continue;
    if (out.length && /^[,;.:]/.test(line)) {
      out[out.length - 1] = `${out[out.length - 1]}${line}`;
    } else {
      out.push(line);
    }
  }
  return out;
}

function splitLines(text, maxLines) {
  const raw = healLeadingPunctuation(
    String(text || '').split(/\r?\n/).map((l) => l.trim()).filter(Boolean),
  );
  const slides = [];
  const n = Math.max(1, maxLines);
  for (let i = 0; i < raw.length; i += n) {
    slides.push(raw.slice(i, i + n));
  }
  return slides.length ? slides : [[]];
}

self.onmessage = (e) => {
  const { id, lyrics, linesPerSlide = 4 } = e.data || {};
  try {
    const slides = splitLines(lyrics, Math.max(1, linesPerSlide));
    self.postMessage({ id, ok: true, result: { slides } });
  } catch (err) {
    self.postMessage({ id, ok: false, error: err?.message || String(err) });
  }
};
