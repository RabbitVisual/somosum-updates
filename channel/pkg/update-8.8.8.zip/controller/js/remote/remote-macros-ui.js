/** Remote — macros (Ações). Layout/fila de debug ficam recolhidos. */
function esc(t) {
  const d = document.createElement('div');
  d.textContent = t ?? '';
  return d.innerHTML;
}

let recordingLocal = false;
let recordBuffer = [];

export function renderRemoteMacrosTab(remotePro, { controlOnline, sendCmd }) {
  void controlOnline;
  void sendCmd;
  const macros = remotePro.macros || {};
  const names = Object.keys(macros);
  const layout = remotePro.layout || 'compact';
  const queue = remotePro.queue || [];

  return `
    <section class="remote-pro-section remote-section-card">
      <h2>Macros</h2>
      <p class="remote-order-hint">Grave uma sequência (próximo, blank, logo…) ou use o preset.</p>
      <ul class="remote-macro-list">
        ${names.length ? names.map((name) => `
          <li>
            <button type="button" class="su-btn remote-btn remote-btn-action remote-macro-run" data-macro="${esc(name)}">
              ${esc(name)} <span class="muted">(${macros[name].length} passos)</span>
            </button>
          </li>`).join('') : '<li class="muted">Nenhuma macro — grave ou salve o preset abaixo</li>'}
      </ul>
      <div class="remote-macro-create">
        <input type="text" id="remote-macro-name" placeholder="Nome da macro" maxlength="40" />
        <button type="button" class="su-btn remote-btn" id="remote-macro-record">${recordingLocal ? 'Parar gravação' : 'Gravar sequência'}</button>
        <button type="button" class="su-btn remote-btn" id="remote-macro-save">Preset blank→logo→limpar</button>
      </div>
      <p class="remote-order-hint" id="remote-macro-status">${recordingLocal ? `Gravando… ${recordBuffer.length} passos` : ''}</p>
    </section>
    <details class="remote-pro-section remote-section-card remote-advanced">
      <summary>Avançado · layout e fila</summary>
      <div class="remote-pro-layouts" style="margin-top:.75rem">
        <button type="button" class="su-btn remote-btn ${layout === 'compact' ? 'is-active' : ''}" data-layout="compact">Compacto</button>
        <button type="button" class="su-btn remote-btn ${layout === 'large' ? 'is-active' : ''}" data-layout="large">Grande</button>
        <button type="button" class="su-btn remote-btn ${layout === 'operador' ? 'is-active' : ''}" data-layout="operador">Operador</button>
        <button type="button" class="su-btn remote-btn ${layout === 'minimal' ? 'is-active' : ''}" data-layout="minimal">Mínimo</button>
      </div>
      <h3 style="margin:1rem 0 .4rem;font-size:.9rem">Fila local</h3>
      <ul class="remote-queue-list">
        ${queue.length ? queue.slice(-8).reverse().map((q) =>
          `<li><span class="remote-type">${esc(q.action)}</span> <span class="muted">${new Date(q.ts).toLocaleTimeString('pt-BR')}</span></li>`
        ).join('') : '<li class="muted">Vazia</li>'}
      </ul>
    </details>`;
}

export function bindRemoteProTab(root, remotePro, { controlOnline, sendCmd, rerender }) {
  void controlOnline;
  root.querySelectorAll('[data-layout]').forEach((btn) => {
    btn.onclick = () => {
      remotePro.setRemoteLayout?.(btn.dataset.layout);
      rerender();
    };
  });
  root.querySelectorAll('.remote-macro-run').forEach((btn) => {
    btn.onclick = async () => {
      const name = btn.dataset.macro;
      await remotePro.runMacro?.(name, (step) => {
        remotePro.enqueueRemoteAction?.({ macro: name, step });
        sendCmd(step.action || step, step.extra || {});
      });
    };
  });
  root.querySelector('#remote-macro-save')?.addEventListener('click', () => {
    const name = root.querySelector('#remote-macro-name')?.value?.trim();
    if (!name) return;
    const steps = [
      { action: 'blank' },
      { action: 'logo' },
      { action: 'clearOverlay' },
    ];
    remotePro.saveMacro?.(name, steps);
    import('../ux/macro-recorder.js').then(({ saveNamedMacro }) => saveNamedMacro(name, steps)).catch(() => {});
    rerender();
  });
  root.querySelector('#remote-macro-record')?.addEventListener('click', async () => {
    const name = root.querySelector('#remote-macro-name')?.value?.trim() || `macro-${Date.now()}`;
    if (!recordingLocal) {
      recordingLocal = true;
      recordBuffer = [];
      root._macroCapture = (action, extra) => {
        if (!recordingLocal) return;
        recordBuffer.push({ action, ...(extra && Object.keys(extra).length ? { extra } : {}) });
        const st2 = root.querySelector('#remote-macro-status');
        if (st2) st2.textContent = `Gravando… ${recordBuffer.length} passos`;
      };
      const st = root.querySelector('#remote-macro-status');
      if (st) st.textContent = 'Gravando — use os botões de Controle/overlays';
      rerender();
      return;
    }
    recordingLocal = false;
    const steps = recordBuffer.slice();
    recordBuffer = [];
    root._macroCapture = null;
    if (steps.length) {
      remotePro.saveMacro?.(name, steps);
      try {
        const { saveNamedMacro } = await import('../ux/macro-recorder.js');
        await saveNamedMacro(name, steps);
      } catch { /* ignore */ }
    }
    rerender();
  });
}

/** Call from remote-app sendCmd when recording macros tab is active. */
export function captureRemoteMacroStep(root, action, extra) {
  if (root?._macroCapture) root._macroCapture(action, extra);
}

export function pushMacroRecordStep(action, extra) {
  if (!recordingLocal) return;
  recordBuffer.push({ action, extra });
}
