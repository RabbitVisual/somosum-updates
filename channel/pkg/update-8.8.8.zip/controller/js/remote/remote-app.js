import '../runtime/runtime-client.js';
import { esc, escAttr, rawHtml, setHtml } from '../core/render-engine/index.js';
import { ProjectionBus, MessageTypes } from '../core/bus.js';
import { loadRemoteToken } from '../runtime/facades/sync-runtime.js';
import { waitForServerBoot } from '../core/storage/adapters/server-adapter.js';
import { getRecoveryEngine } from '../runtime/facades/recovery-runtime.js';
import { TaskScheduler } from '../core/task-scheduler.js';
import { TaskIds } from '../core/task-registry.js';
import { RenderScheduler } from '../core/render-scheduler.js';
import { assertCompatible, showCompatBanner } from '../core/protocol-compat.js';
import { markAppReady } from '../core/server-boot.js';
import { initRemoteTheme, bindThemeToggle } from './remote-theme.js';
import {
  renderQuickActionsHtml,
  createLocalTimer,
  bindLocalTimerControls,
} from './remote-quick-actions.js';
import { renderAlertsTabHtml, bindAlertsTab } from './remote-alerts-ui.js';
import { renderLibraryTabHtml } from './remote-library-ui.js';
import { bindStudioPanel } from './remote-studio-ui.js';
import { faRemoteTabIcon, faIcon } from '../core/fa-icons.js';

const SLIDE_TYPE_LABELS = {
  lyrics: 'Louvor',
  'lyrics-title': 'Capa louvor',
  bible: 'Biblia',
  'bible-reader': 'Leitura biblica',
  message: 'Mensagem',
  welcome: 'Boas-vindas',
  announcements: 'Comunicados',
  communion: 'Ceia do Senhor',
  participation: 'Participação',
  countdown: 'Pre-culto',
  blank: 'Tela preta',
  logo: 'Logo',
};

function getUrlToken() {
  return new URLSearchParams(location.search).get('token') || '';
}

function slideTypeLabel(type) {
  return SLIDE_TYPE_LABELS[type] || type || 'Slide';
}

function showPinScreen(onSubmit) {
  dismissRemoteSplash();
  setHtml(document.getElementById('remote-root'), rawHtml(`
    <div class="remote-pin-screen">
      <h1>Autenticação</h1>
      <p>Digite o PIN de 6 dígitos do PC (Rede / Ajustes). Cada PIN vale <strong>1 uso</strong> — depois o PC gera outro.</p>
      <input type="tel" inputmode="numeric" pattern="[0-9]*" maxlength="6" class="remote-pin-input" id="remote-pin" autocomplete="one-time-code" />
      <label class="remote-pin-trust"><input type="checkbox" id="remote-trust" checked /> Confiar neste dispositivo (reconectar sem PIN)</label>
      <button type="button" class="su-btn su-btn--primary su-btn--lg remote-btn remote-btn-primary remote-btn-lg" id="remote-pin-submit">Entrar</button>
      <p class="remote-pin-hint" id="remote-pin-error"></p>
    </div>`));
  const input = document.getElementById('remote-pin');
  const btn = document.getElementById('remote-pin-submit');
  const submit = async () => {
    const pin = input.value.trim();
    const trust = document.getElementById('remote-trust')?.checked;
    btn.disabled = true;
    try {
      await onSubmit(pin, trust);
    } catch (e) {
      document.getElementById('remote-pin-error').textContent = e.message || 'PIN inválido';
      btn.disabled = false;
    }
  };
  btn.addEventListener('click', submit);
  input.addEventListener('keydown', (e) => { if (e.key === 'Enter') submit(); });
  input.focus();
}

async function verifyPin(pin, trust) {
  const res = await fetch('/api/network/pin/verify', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ pin, trust, name: 'Celular' }),
  });
  const data = await res.json();
  if (!data.ok) {
    if (data.error === 'pin_locked' || res.status === 429) {
      const secs = Number(data.retryAfterSeconds) || 60;
      throw new Error(`Muitas tentativas. Aguarde ${secs}s e tente novamente.`);
    }
    throw new Error(
      data.error === 'session_failed'
        ? 'Falha ao criar sessão. Atualize o PIN no PC e tente de novo.'
        : data.error === 'pin_invalid'
          ? 'PIN inválido ou expirado. Veja o PIN atual no PC.'
          : (data.error || 'PIN inválido')
    );
  }
  if (data.token) {
    const { storeSessionToken } = await import('../runtime/facades/sync-runtime.js');
    storeSessionToken(data.token, { trust: !!trust });
  }
}

function dismissRemoteSplash() {
  try {
    if (typeof window.__somosumFinishBootSplash === 'function') {
      void window.__somosumFinishBootSplash();
    } else {
      document.getElementById('boot-loading')?.remove();
    }
  } catch { /* ignore */ }
}

function showTokenError() {
  dismissRemoteSplash();
  setHtml(document.getElementById('remote-root'), rawHtml(`
    <div class="remote-error">
      <div>
        <h1>Token invalido</h1>
        <p>Abra o Remote pelo link em <strong>Ajustes → Rede local</strong> no painel de controle.<br>O URL inclui <code>?token=...</code> para acesso seguro na rede.</p>
      </div>
    </div>`));
}

function showOfflineError(retryDelayMs = 1000) {
  dismissRemoteSplash();
  const isLan = !['127.0.0.1', 'localhost', '::1'].includes(location.hostname);
  setHtml(document.getElementById('remote-root'), rawHtml(`
    <div class="remote-error">
      <div>
        <h1>Nao conectou ao PC</h1>
        <p>${isLan
          ? 'O celular precisa estar na <strong>mesma rede Wi-Fi</strong> do computador (nao use dados moveis).<br><br>1. No PC, ative <strong>Modo LAN</strong> e use <strong>Preparar rede</strong><br>2. Confirme a permissao do Windows se solicitado<br>3. Escaneie o QR de novo'
          : 'Verifique se o SOMOSUM esta aberto no PC de controle.'}</p>
        <button type="button" class="su-btn su-btn--primary remote-btn remote-btn-primary" id="remote-retry">Tentar novamente</button>
      </div>
    </div>`));
  document.getElementById('remote-retry')?.addEventListener('click', () => location.reload());
  if (isLan) {
    setTimeout(() => location.reload(), Math.min(retryDelayMs, 15000));
  }
}

async function main() {
  initRemoteTheme();
  const root = document.getElementById('remote-root');
  // Liga o scheduler ANTES de qualquer sync — sem isso o poll HTTP nunca roda no celular.
  markAppReady();
  TaskScheduler.start();

  setHtml(root, rawHtml(`<p class="remote-loading">Conectando ao PC…</p>`));
  const serverOk = await waitForServerBoot(40, 300);
  if (!serverOk) {
    showOfflineError();
    return;
  }

  // Remote NÃO baixe programa/letras/mídia — só sincroniza via bus (rápido na Wi‑Fi).
  const urlToken = getUrlToken();
  const isLocal = ['127.0.0.1', 'localhost', '::1'].includes(location.hostname);
  const { getStoredSessionToken, validateStoredSession, clearStoredSessionToken } = await import('../runtime/facades/sync-runtime.js');

  // Pair-token do QR só abre o link; PIN libera o aparelho.
  // Sessão confiável válida no servidor → reconecta sem PIN; senão pede PIN novo.
  if (!isLocal) {
    const hasValidSession = getStoredSessionToken()
      ? await validateStoredSession()
      : false;
    if (!hasValidSession) {
      clearStoredSessionToken();
      await new Promise((resolve) => {
        showPinScreen(async (pin, trust) => {
          await verifyPin(pin, trust);
          resolve();
        });
      });
    }
  }

  const expected = await loadRemoteToken();
  // Pair-token do QR e sessão do PIN podem diferir — ambos válidos.
  // Só rejeita URL “errada” quando não há sessão PIN e o token não bate.
  if (urlToken && expected && !isLocal && urlToken !== expected) {
    const sess = getStoredSessionToken();
    if (!(sess && expected === sess)) {
      showTokenError();
      return;
    }
  }

  const bus = new ProjectionBus('remote');
  const remoteApi = {};
  const remotePro = (await import('./remote-extensions.js')).wireRemotePro(remoteApi);
  Object.assign(remotePro, remoteApi);
  const { renderRemoteMacrosTab, bindRemoteProTab } = await import('./remote-macros-ui.js');
  let pluginRemoteActions = [];
  void (async () => {
    try {
      const { ensurePluginsLoaded } = await import('../plugins/plugin-host.js');
      await ensurePluginsLoaded();
      const { listRemoteActionsFromContributions } = await import('../plugins/plugin-api.js');
      const actions = listRemoteActionsFromContributions();
      pluginRemoteActions = actions;
      scheduleRemotePatch(() => {
        if (tab === 'macros') patchRemoteUi({ full: true });
        else patchRemoteHeader();
      });
    } catch { /* ignore */ }
  })();
  getRecoveryEngine().init({ role: 'remote', bus });
  let stageState = {
    current: null,
    nextItems: [],
    programItems: [],
    flatIndex: 0,
    totalSlides: 0,
    overlay: null,
    countdownActive: false,
    ambient: { playing: false, hasTrack: false },
    bibleRef: { book: 'Lc', chapter: 1, version: 'naa' },
    slide: null,
  };
  let countdownDurationMins = 10;
  let controlOnline = false;
  let lastHeartbeat = 0;
  let touchStartX = 0;
  let touchStartY = 0;
  let tab = 'control';
  let lastCommandAt = 0;
  let cmdStatus = 'idle'; // idle | sending | sent | failed
  let pendingCmdId = null;
  let lastAckAt = 0;
  let hasActiveAlert = false;
  let shellMounted = false;
  let localTimerLabel = '00:00';

  const cmdStatusLabel = () => {
    const online = controlOnline && Date.now() - lastHeartbeat < 12000;
    if (!online) return 'Sem Controle';
    if (cmdStatus === 'sending') return 'Enviando…';
    if (cmdStatus === 'failed') return 'Falhou';
    if (cmdStatus === 'sent' && Date.now() - lastCommandAt < 1800) return 'Enviado';
    if (Date.now() - lastAckAt < 2500) return 'Confirmado';
    return 'Com o Controle';
  };

  const localTimer = createLocalTimer((label, running) => {
    localTimerLabel = label;
    const el = root.querySelector('[data-local-timer]');
    if (el) el.textContent = label;
    const toggle = root.querySelector('[data-local-timer-toggle]');
    if (toggle) {
      setHtml(toggle, rawHtml(running
        ? `${faIcon('pause', 'su-fa su-fa--inline-btn')} Pausar`
        : `${faIcon('play', 'su-fa su-fa--inline-btn')} Iniciar`));
    }
  });

  const vibrate = (ms = 12) => { try { navigator.vibrate?.(ms); } catch { /* ignore */ } };

  const showRemoteToast = (text, tone = 'info') => {
    let el = root.querySelector('.remote-toast');
    if (!el) {
      el = document.createElement('div');
      el.className = 'remote-toast';
      el.setAttribute('role', 'status');
      el.setAttribute('aria-live', 'polite');
      root.appendChild(el);
    }
    el.textContent = text;
    el.dataset.tone = tone;
    el.classList.add('is-visible');
    clearTimeout(showRemoteToast._t);
    showRemoteToast._t = setTimeout(() => el.classList.remove('is-visible'), 2600);
  };

  const clearRemoteAlert = () => {
    clearInterval(showRemoteAlertBanner._timer);
    root.querySelector('.remote-alert-banner')?.remove();
  };

  const showRemoteAlertBanner = (payload = {}) => {
    clearRemoteAlert();
    const appEl = root.querySelector('.remote-app');
    if (!appEl) {
      showRemoteToast(payload.text || 'Aviso do Controle', payload.priority === 'urgent' ? 'warn' : 'info');
      return;
    }
    const pri = payload.priority === 'urgent' || payload.kind === 'countdown' ? 'urgent' : 'normal';
    const banner = document.createElement('div');
    banner.className = `remote-alert-banner remote-alert-banner--${pri}`;
    banner.setAttribute('role', 'status');
    banner.setAttribute('aria-live', pri === 'urgent' ? 'assertive' : 'polite');
    const kindLabel = payload.kind === 'countdown'
      ? 'Tempo'
      : (payload.kind === 'info' ? 'Info' : (pri === 'urgent' || payload.kind === 'urgent' ? 'Urgente' : 'Aviso'));
    const fromRemote = payload.source === 'remote';
    setHtml(banner, rawHtml(`
      <span class="remote-alert-kind">${esc(kindLabel)}</span>
      <div class="remote-alert-body">
        <span class="remote-alert-kicker">${fromRemote ? 'Equipe' : 'Do Controle'}</span>
        <strong>${esc(payload.text || 'Mensagem')}</strong>
      </div>
      <div class="remote-alert-actions">
        <button type="button" class="su-btn su-btn--sm remote-btn remote-alert-stop" data-dismiss-alert>Parar aviso</button>
        <button type="button" class="remote-alert-dismiss" aria-label="Ocultar aviso">OK</button>
      </div>`));
    banner.querySelector('.remote-alert-dismiss').onclick = () => {
      clearRemoteAlert();
      hasActiveAlert = false;
      if (tab === 'control' || tab === 'library') {
        scheduleRemotePatch(() => patchRemoteUi({ full: true }));
      }
    };
    banner.querySelector('[data-dismiss-alert]')?.addEventListener('click', () => {
      void sendCmd('dismissAlert');
      clearRemoteAlert();
      hasActiveAlert = false;
      if (tab === 'control' || tab === 'library') {
        scheduleRemotePatch(() => patchRemoteUi({ full: true }));
      }
    });
    const head = appEl.querySelector('.remote-head');
    if (head?.nextSibling) appEl.insertBefore(banner, head.nextSibling);
    else appEl.prepend(banner);
    if (payload.kind === 'countdown' && payload.expiresAt) {
      clearInterval(showRemoteAlertBanner._timer);
      const end = payload.expiresAt;
      const base = payload.text || 'Tempo';
      const tick = () => {
        const left = end - Date.now();
        if (left <= 0) {
          clearInterval(showRemoteAlertBanner._timer);
          banner.remove();
          return;
        }
        const s = Math.ceil(left / 1000);
        const m = Math.floor(s / 60);
        const sec = String(s % 60).padStart(2, '0');
        const strong = banner.querySelector('strong');
        if (strong) strong.textContent = `${base} · ${m}:${sec}`;
      };
      tick();
      showRemoteAlertBanner._timer = setInterval(tick, 250);
    }
  };

  const applyOptimisticNav = (action, extra = {}) => {
    if (action === 'countdownStart' || (action === 'timer' && extra.force === 'start')) {
      stageState.countdownActive = true;
      return;
    }
    if (action === 'countdownStop' || (action === 'timer' && extra.force === 'stop')) {
      stageState.countdownActive = false;
      return;
    }
    if (action === 'timer' || action === 'countdown') {
      stageState.countdownActive = !stageState.countdownActive;
      return;
    }
    if (action === 'ambientPlay') {
      stageState.ambient = { ...(stageState.ambient || {}), playing: true, hasTrack: true };
      return;
    }
    if (action === 'ambientPause' || action === 'ambientStop') {
      stageState.ambient = { ...(stageState.ambient || {}), playing: false };
      return;
    }
    if (action === 'ambientToggle') {
      const playing = !stageState.ambient?.playing;
      stageState.ambient = { ...(stageState.ambient || {}), playing, hasTrack: true };
      return;
    }
    if (action === 'readerStop') {
      stageState.bibleReaderLive = false;
      stageState.readerProgress = null;
      return;
    }
    if (action === 'readerStart' || action === 'readerGo') {
      stageState.bibleRef = {
        book: extra.book || stageState.bibleRef?.book || 'Lc',
        chapter: Number(extra.chapter) || stageState.bibleRef?.chapter || 1,
        version: extra.version || stageState.bibleRef?.version || 'naa',
      };
      return;
    }
    if ((action === 'next' || action === 'prev') && stageState.bibleReaderLive) {
      const rp = stageState.readerProgress;
      if (rp && Number.isFinite(rp.index) && Number.isFinite(rp.total)) {
        const nextIdx = action === 'next'
          ? Math.min(Math.max(0, rp.total - 1), rp.index + 1)
          : Math.max(0, rp.index - 1);
        stageState.readerProgress = { ...rp, index: nextIdx };
      }
      return;
    }
    const items = stageState.programItems;
    if (!items?.length) return;
    const pick = (idx) => items.find((it) => it.index === idx) || items[idx];
    if (action === 'goToItem' && Number.isFinite(extra.itemIndex)) {
      const idx = extra.itemIndex;
      const it = pick(idx);
      if (!it) return;
      stageState.programItems = items.map((row) => ({
        ...row,
        active: row.index === idx,
        currentSlideInItem: row.index === idx ? 0 : null,
      }));
      stageState.current = {
        ...(stageState.current || {}),
        itemIndex: idx,
        itemTitle: it.title,
        slideType: it.slideType,
        slideIndex: 0,
        slideCount: it.slideCount,
      };
      stageState.itemTitle = it.title;
      stageState.slideTypeLabel = slideTypeLabel(it.slideType);
      stageState.itemSlideIndex = 0;
      stageState.itemSlideCount = it.slideCount;
      return;
    }
    if (action === 'goToSlide' && Number.isFinite(extra.itemIndex) && Number.isFinite(extra.slideIndex)) {
      const idx = extra.itemIndex;
      const si = extra.slideIndex;
      const it = pick(idx);
      stageState.programItems = items.map((row) => ({
        ...row,
        active: row.index === idx,
        currentSlideInItem: row.index === idx ? si : null,
      }));
      if (it) {
        stageState.current = {
          ...(stageState.current || {}),
          itemIndex: idx,
          itemTitle: it.title,
          slideType: it.slideType,
          slideIndex: si,
          slideCount: it.slideCount,
        };
        stageState.itemSlideIndex = si;
        stageState.itemSlideCount = it.slideCount;
        stageState.itemTitle = it.title;
        stageState.slideTypeLabel = slideTypeLabel(it.slideType);
      }
      return;
    }
    const activeIdx = stageState.current?.itemIndex ?? items.find((it) => it.active)?.index;
    if (!Number.isFinite(activeIdx) || activeIdx < 0) return;
    const active = pick(activeIdx);
    if (!active) return;
    if (action === 'next' || action === 'prev') {
      const curPart = stageState.itemSlideIndex ?? stageState.current?.slideIndex ?? 0;
      const maxPart = Math.max(0, (active.slideCount || 1) - 1);
      let targetIdx = activeIdx;
      let nextPart = curPart;
      if (action === 'next') {
        if (curPart < maxPart) {
          nextPart = curPart + 1;
        } else {
          const pos = items.findIndex((it) => it.index === activeIdx);
          const nextItem = pos >= 0 && pos < items.length - 1 ? items[pos + 1] : null;
          if (!nextItem) return;
          targetIdx = nextItem.index;
          nextPart = 0;
        }
      } else if (curPart > 0) {
        nextPart = curPart - 1;
      } else {
        const pos = items.findIndex((it) => it.index === activeIdx);
        const prevItem = pos > 0 ? items[pos - 1] : null;
        if (!prevItem) return;
        targetIdx = prevItem.index;
        nextPart = Math.max(0, (prevItem.slideCount || 1) - 1);
      }
      const target = pick(targetIdx);
      if (!target) return;
      stageState.programItems = items.map((row) => ({
        ...row,
        active: row.index === targetIdx,
        currentSlideInItem: row.index === targetIdx ? nextPart : null,
      }));
      stageState.itemSlideIndex = nextPart;
      stageState.itemSlideCount = target.slideCount;
      stageState.itemTitle = target.title;
      stageState.slideTypeLabel = slideTypeLabel(target.slideType);
      stageState.current = {
        ...(stageState.current || {}),
        itemIndex: targetIdx,
        itemTitle: target.title,
        slideType: target.slideType,
        slideIndex: nextPart,
        slideCount: target.slideCount,
      };
      if (Number.isFinite(stageState.flatIndex)) {
        stageState.flatIndex = action === 'next'
          ? stageState.flatIndex + 1
          : Math.max(0, stageState.flatIndex - 1);
      }
    } else if (action === 'first') {
      const it = items[0];
      stageState.programItems = items.map((row, i) => ({
        ...row,
        active: i === 0,
        currentSlideInItem: i === 0 ? 0 : null,
      }));
      if (it) {
        stageState.current = {
          ...(stageState.current || {}),
          itemIndex: it.index ?? 0,
          itemTitle: it.title,
          slideType: it.slideType,
          slideIndex: 0,
          slideCount: it.slideCount,
        };
        stageState.itemTitle = it.title;
        stageState.slideTypeLabel = slideTypeLabel(it.slideType);
        stageState.itemSlideIndex = 0;
      }
    } else if (action === 'last') {
      const last = items.length - 1;
      const it = items[last];
      stageState.programItems = items.map((row, i) => ({
        ...row,
        active: i === last,
        currentSlideInItem: i === last ? 0 : null,
      }));
      if (it) {
        stageState.current = {
          ...(stageState.current || {}),
          itemIndex: it.index ?? last,
          itemTitle: it.title,
          slideType: it.slideType,
          slideIndex: 0,
          slideCount: it.slideCount,
        };
        stageState.itemTitle = it.title;
        stageState.slideTypeLabel = slideTypeLabel(it.slideType);
        stageState.itemSlideIndex = 0;
      }
    }
  };

  const applyNavFromAck = (payload = {}) => {
    const itemIdx = payload.itemIndex;
    if (!Number.isFinite(itemIdx) || itemIdx < 0) return;
    if (stageState.programItems?.length) {
      stageState.programItems = stageState.programItems.map((row) => ({
        ...row,
        active: row.index === itemIdx,
        currentSlideInItem: row.index === itemIdx
          ? (payload.slideIndex ?? row.currentSlideInItem ?? 0)
          : null,
      }));
    }
    stageState.current = {
      ...(stageState.current || {}),
      itemIndex: itemIdx,
      slideIndex: payload.slideIndex ?? 0,
      itemTitle: payload.itemTitle || stageState.current?.itemTitle,
      slideType: payload.slideType || stageState.current?.slideType,
    };
    if (payload.itemTitle) stageState.itemTitle = payload.itemTitle;
    if (payload.slideType) stageState.slideTypeLabel = slideTypeLabel(payload.slideType);
    if (Number.isFinite(payload.flatIndex)) stageState.flatIndex = payload.flatIndex;
    if (Number.isFinite(payload.totalSlides)) stageState.totalSlides = payload.totalSlides;
    stageState.itemSlideIndex = payload.slideIndex ?? stageState.itemSlideIndex ?? 0;
  };

  const mergeStagePayload = (payload = {}) => {
    const prevBible = !!stageState.bibleReaderLive;
    stageState = { ...stageState, ...payload };
    if (payload.ambient && typeof payload.ambient === 'object') {
      stageState.ambient = { ...(stageState.ambient || {}), ...payload.ambient };
    }
    if (payload.countdown && typeof payload.countdown === 'object') {
      stageState.countdownActive = !!payload.countdown.active || !!payload.countdownActive;
      if (Number.isFinite(Number(payload.countdown.durationMinutes))) {
        countdownDurationMins = Number(payload.countdown.durationMinutes);
      }
    }
    if (Object.prototype.hasOwnProperty.call(payload, 'bibleReaderLive')) {
      stageState.bibleReaderLive = !!payload.bibleReaderLive;
      if (!payload.bibleReaderLive) stageState.readerProgress = null;
    } else if (payload.delta === false && prevBible && !payload.readerProgress) {
      stageState.bibleReaderLive = false;
      stageState.readerProgress = null;
    }
    if (payload.bibleRef) stageState.bibleRef = { ...(stageState.bibleRef || {}), ...payload.bibleRef };
    const itemIdx = payload.current?.itemIndex;
    if (Number.isFinite(itemIdx) && itemIdx >= 0 && stageState.programItems?.length) {
      if (!payload.programItems) {
        stageState.programItems = stageState.programItems.map((row) => ({
          ...row,
          active: row.index === itemIdx,
          currentSlideInItem: row.index === itemIdx
            ? (payload.itemSlideIndex ?? payload.current?.slideIndex ?? row.currentSlideInItem ?? 0)
            : null,
        }));
      }
    }
    if (Array.isArray(payload.programItems) && payload.programItems.length) {
      stageState.programItems = payload.programItems;
    }
    if (payload.current) stageState.current = payload.current;
  };

  const patchOrderSelection = () => {
    if (tab !== 'order' || !shellMounted) return;
    const list = root.querySelector('.remote-order-list');
    if (!list) {
      patchOrderTab();
      return;
    }
    list.querySelectorAll('.remote-order-item').forEach((btn) => {
      const idx = parseInt(btn.getAttribute('data-go'), 10);
      const row = stageState.programItems?.find((it) => it.index === idx);
      const active = !!row?.active;
      btn.classList.toggle('is-active', active);
      let nowEl = btn.querySelector('.remote-order-now');
      if (active && row?.slideCount > 1 && row.currentSlideInItem != null) {
        const txt = `Parte ${row.currentSlideInItem + 1} de ${row.slideCount}`;
        if (!nowEl) {
          nowEl = document.createElement('span');
          nowEl.className = 'remote-order-now';
          btn.appendChild(nowEl);
        }
        nowEl.textContent = txt;
      } else if (nowEl) {
        nowEl.remove();
      }
    });
    patchRemoteHeader();
  };

  const afterCmdBoost = () => {
    bus.hub?.boostPolling?.({ burstMs: 3500 });
    void bus.hub?.flushPoll?.();
  };

  const paintOptimisticUi = () => {
    if (tab === 'order') patchOrderSelection();
    else if (tab === 'control' || tab === 'library') {
      scheduleRemotePatch(() => {
        if (tab === 'library') patchRemoteUi({ full: true });
        else patchControlLive();
      });
    } else patchRemoteHeader();
  };

  const sendCmd = async (action, extra = {}) => {
    vibrate();
    cmdStatus = 'sending';
    lastCommandAt = Date.now();
    let payload = { ...extra };
    if (action === 'countdownStart' && !Number.isFinite(payload.durationMinutes)) {
      payload.durationMinutes = countdownDurationMins;
    }
    if ((action === 'timer' || action === 'countdown') && !payload.force && !stageState.countdownActive
      && !Number.isFinite(payload.durationMinutes)) {
      payload.durationMinutes = countdownDurationMins;
    }
    applyOptimisticNav(action, payload);
    paintOptimisticUi();
    afterCmdBoost();
    import('./remote-macros-ui.js').then((m) => m.captureRemoteMacroStep?.(root, action, payload)).catch(() => {});
    import('../ux/macro-recorder.js').then((m) => {
      if (m.isRecording()) m.recordAction(action, payload);
    }).catch(() => {});
    if (action === 'pluginDemo') {
      showRemoteToast('Plugin: sinal enviado ao operador');
      const { message, push } = await bus.sendAsync(MessageTypes.REMOTE_CMD, { action, ...payload });
      pendingCmdId = message.id;
      if (!push?.ok) {
        cmdStatus = 'failed';
        showRemoteToast('Falha ao enviar comando', 'warn');
      } else {
        cmdStatus = 'sent';
      }
      afterCmdBoost();
      patchRemoteHeader();
      return;
    }
    remotePro.enqueueRemoteAction?.({ action, ...payload });
    const { message, push } = await bus.sendAsync(MessageTypes.REMOTE_CMD, { action, ...payload });
    pendingCmdId = message.id;
    if (!push?.ok) {
      if (push?.error === 'network') {
        await new Promise((r) => setTimeout(r, 280));
        const retry = await bus.sendAsync(MessageTypes.REMOTE_CMD, { action, ...payload });
        if (retry.push?.ok) {
          cmdStatus = 'sent';
          pendingCmdId = retry.message.id;
          afterCmdBoost();
          paintOptimisticUi();
          return;
        }
      }
      cmdStatus = 'failed';
      const msg = push?.error === 'auth'
        ? 'Token inválido — escaneie o QR de novo'
        : push?.error === 'rate_limit'
          ? 'Muitos comandos — aguarde um instante'
          : 'Falha ao enviar — verifique a rede';
      showRemoteToast(msg, 'warn');
      patchRemoteHeader();
      return;
    }
    cmdStatus = 'sent';
    afterCmdBoost();
    paintOptimisticUi();
    setTimeout(() => {
      if (cmdStatus === 'sent' && pendingCmdId === message.id) {
        cmdStatus = 'idle';
        patchRemoteHeader();
      }
    }, 3000);
  };

  const formatProgress = () => {
    const cur = stageState.current;
    const total = stageState.totalSlides || 0;
    const flat = (stageState.flatIndex ?? 0) + 1;
    if (!total) return '—';
    const part = (cur?.slideIndex ?? 0) + 1;
    const parts = cur?.slideCount ? ` · parte ${part}/${cur.slideCount}` : '';
    return `${flat}/${total}${parts}`;
  };

  const renderLyricsParts = () => {
    const count = stageState.itemSlideCount || stageState.current?.slideCount || 0;
    const activeIdx = stageState.itemSlideIndex ?? stageState.current?.slideIndex ?? 0;
    const itemIndex = stageState.current?.itemIndex;
    if (count <= 1 || !Number.isFinite(itemIndex)) return '';
    const chips = Array.from({ length: count }, (_, i) => {
      const label = i === 0 ? 'Capa' : String(i);
      return `<button type="button" class="remote-part-chip ${i === activeIdx ? 'is-active' : ''}" data-part="${i}" >${label}</button>`;
    }).join('');
    return `
      <section class="remote-parts">
        <h2>Partes do louvor</h2>
        <div class="remote-part-strip">${chips}</div>
      </section>`;
  };

  const renderControlTab = () => {
    const readerLive = stageState.bibleReaderLive;
    const rp = stageState.readerProgress;
    const online = controlOnline && Date.now() - lastHeartbeat < 12000;
    if (readerLive && rp) {
      return `
        <div class="remote-section-card remote-bible-live">
          <div class="remote-progress">
            <span class="remote-progress-label">Leitura bíblica</span>
            <strong>${esc(rp.chapterTitle || '')}</strong>
            <span class="remote-overlay-pill">${esc(rp.slideRange || '')} · ${(rp.index ?? 0) + 1}/${rp.total || '?'}</span>
          </div>
          <div class="remote-transport">
            <button type="button" class="su-btn su-btn--lg remote-btn remote-btn-lg btn-icon" data-cmd="prev">${faIcon('prev')} Anterior</button>
            <button type="button" class="su-btn su-btn--primary su-btn--lg remote-btn remote-btn-lg remote-btn-primary btn-icon" data-cmd="next">${faIcon('next')} Próximo</button>
          </div>
          <div class="remote-studio-actions remote-studio-actions--row">
            <button type="button" class="su-btn remote-btn" data-cmd="readerChapterPrev">${faIcon('prev', 'su-fa su-fa--inline-btn')} Cap. −</button>
            <button type="button" class="su-btn remote-btn" data-cmd="readerChapterNext">${faIcon('next', 'su-fa su-fa--inline-btn')} Cap. +</button>
            <button type="button" class="su-btn su-btn--warn remote-btn remote-btn-action" data-cmd="readerStop">Parar leitura</button>
          </div>
        </div>`;
    }
    const note = stageState.note || stageState.itemOperatorNote || '';
    return `
    ${!online ? `
      <div class="remote-offline-banner" role="status">
        <div>
          <strong>Aguardando o Controle</strong>
          <span>Abra o Controle no PC — o Remote só envia comandos; quem comanda é o Controle.</span>
        </div>
        <button type="button" class="remote-retry-inline" data-retry-ping>Reconectar</button>
      </div>` : ''}
    <div class="remote-section-card remote-now-card">
      <h2>Agora na projeção</h2>
      <p class="remote-now-title">${esc(nowTitle())}</p>
      <p class="remote-now-meta">${esc(formatProgress())}${stageState.slideTypeLabel || stageState.current?.slideType ? ` · ${esc(stageState.slideTypeLabel || slideTypeLabel(stageState.current?.slideType))}` : ''}</p>
      <div class="remote-pill-row">
        ${stageState.overlay ? `<span class="remote-overlay-pill">${esc(stageState.overlay === 'blank' ? 'Tela preta' : 'Logo')}</span>` : ''}
        ${stageState.countdownActive ? '<span class="remote-overlay-pill is-countdown">Pré-culto</span>' : ''}
        ${stageState.ambient?.playing ? '<span class="remote-overlay-pill">Música</span>' : ''}
        ${stageState.rehearsal ? '<span class="remote-overlay-pill is-rehearsal">Ensaio</span>' : ''}
      </div>
      ${note ? `<p class="remote-stage-note"><span class="remote-stage-note-label">Nota</span> ${esc(note)}</p>` : ''}
    </div>
    <div class="remote-section-card">
      <h2>Avançar culto</h2>
      <p class="remote-hint">Comandos vão para o Controle, que sincroniza Stage e Projeção.</p>
      <div class="remote-transport">
        <button type="button" class="su-btn su-btn--lg remote-btn remote-btn-lg btn-icon" data-cmd="prev">${faIcon('prev')} Anterior</button>
        <button type="button" class="su-btn su-btn--primary su-btn--lg remote-btn remote-btn-lg remote-btn-primary btn-icon" data-cmd="next">${faIcon('next')} Próximo</button>
      </div>
      <div class="remote-transport-secondary">
        <button type="button" class="su-btn remote-btn" data-cmd="first">${faIcon('prev', 'su-fa su-fa--inline-btn')} Início</button>
        <button type="button" class="su-btn remote-btn" data-cmd="last">${faIcon('next', 'su-fa su-fa--inline-btn')} Fim</button>
      </div>
    </div>
    <div class="remote-section-card">
      <h2>Atalhos</h2>
      <p class="remote-hint">Pré-culto, overlays e Bíblia ficam na <strong>Biblioteca</strong> — sem duplicar aqui.</p>
      ${renderQuickActionsHtml({
        controlOnline: online,
        countdownActive: !!stageState.countdownActive,
        timerLabel: localTimerLabel,
        hasActiveAlert,
      })}
    </div>
    <section class="remote-section-card remote-list">
      <h2>A seguir</h2>
      <ul>${(stageState.nextItems || []).slice(0, 3).map((it) =>
        `<li class="remote-next-highlight"><span class="remote-type">${esc(slideTypeLabel(it.slideType))}</span> ${esc(it.title)}</li>`
      ).join('') || '<li class="muted">Fim do programa</li>'}</ul>
    </section>
    ${renderLyricsParts()}`;
  };

  const renderLibraryTab = () => renderLibraryTabHtml({
    countdownActive: !!stageState.countdownActive,
    hasActiveAlert,
    timerLabel: localTimerLabel,
    durationMinutes: countdownDurationMins,
    ambient: stageState.ambient || {},
    bibleReaderLive: !!stageState.bibleReaderLive,
    readerProgress: stageState.readerProgress,
    bibleRef: stageState.bibleRef || {},
  });

  const renderAlertsTab = () => renderAlertsTabHtml({ hasActiveAlert });

  const renderMacrosTab = () => {
    const byPlugin = new Map();
    for (const a of pluginRemoteActions) {
      const key = a.pluginId || a.group || 'plugins';
      if (!byPlugin.has(key)) byPlugin.set(key, []);
      byPlugin.get(key).push(a);
    }
    const pluginBlocks = [...byPlugin.entries()].map(([gid, list]) => `
      <div class="remote-plugin-group">
        <h3 class="remote-plugin-group__title">${esc(gid === 'plugins' ? 'Plugins' : gid)}</h3>
        <div class="remote-plugin-grid">
          ${list.map((a) =>
            `<button type="button" class="su-btn remote-btn remote-btn-action" data-cmd="${esc(a.cmd || a.id)}"${a.prompt ? ` data-prompt="${escAttr(a.prompt)}"` : ''}>${esc(a.label || a.id)}</button>`
          ).join('')}
        </div>
      </div>`).join('');

    return `
    ${pluginRemoteActions.length ? `
    <section class="remote-section-card remote-plugin-actions">
      <h2>Plugins do culto</h2>
      <p class="remote-hint">Atalhos dos plugins ativos — sem repetir overlays do Controle.</p>
      ${pluginBlocks}
    </section>` : `
    <section class="remote-section-card">
      <h2>Plugins do culto</h2>
      <p class="remote-hint muted">Nenhum atalho de plugin ativo. Ative plugins na Loja pelo Controle.</p>
    </section>`}
    ${renderRemoteMacrosTab(remotePro, { controlOnline, sendCmd })}`;
  };

  const renderOrderTab = () => `
    <section class="remote-order">
      <h2>Ordem do culto</h2>
      <p class="remote-order-hint">Toque para ir ao item. Busque pelo título.</p>
      <div class="remote-order-search">
        <input type="search" id="remote-order-filter" placeholder="Buscar na ordem…" autocomplete="off" />
      </div>
      <ul class="remote-order-list">
        ${(stageState.programItems || []).map((it) => `
          <li>
            <button type="button" class="remote-order-item ${it.active ? 'is-active' : ''}" data-go="${it.index}" data-title="${escAttr(it.title || '')}">
              <span class="remote-order-row">
                <span class="remote-order-type">${esc(slideTypeLabel(it.slideType))}</span>
                ${it.slideCount > 1 ? `<span class="remote-order-parts">${it.slideCount} partes</span>` : ''}
              </span>
              <span class="remote-order-title">${esc(it.title)}</span>
              ${it.active && it.currentSlideInItem != null && it.slideCount > 1
                ? `<span class="remote-order-now">Parte ${it.currentSlideInItem + 1} de ${it.slideCount}</span>` : ''}
            </button>
          </li>`).join('') || '<li class="muted">Programa vazio</li>'}
      </ul>
    </section>`;

  const bindRemoteEvents = () => {
    root.querySelectorAll('[data-cmd]').forEach((btn) => {
      if (btn.dataset.cmd === 'countdownStart' && btn.closest('[data-studio="preculto"]')) return;
      btn.onclick = () => {
        const cmd = btn.dataset.cmd;
        const promptLabel = btn.dataset.prompt;
        if (promptLabel) {
          const value = window.prompt(promptLabel, '');
          if (value == null) return;
          const text = String(value).trim();
          if (!text) return;
          void sendCmd(cmd, { text });
          return;
        }
        void sendCmd(cmd);
      };
    });
    root.querySelectorAll('[data-go]').forEach((btn) => {
      btn.onclick = () => { void sendCmd('goToItem', { itemIndex: parseInt(btn.dataset.go, 10) }); };
    });
    root.querySelectorAll('[data-part]').forEach((btn) => {
      btn.onclick = () => {
        const itemIndex = stageState.current?.itemIndex;
        if (!Number.isFinite(itemIndex)) return;
        void sendCmd('goToSlide', { itemIndex, slideIndex: parseInt(btn.dataset.part, 10) });
      };
    });
    root.querySelectorAll('[data-tab-jump]').forEach((btn) => {
      btn.onclick = () => {
        const next = btn.dataset.tabJump;
        const tabBtn = root.querySelector(`[data-tab="${next}"]`);
        if (tabBtn) tabBtn.click();
      };
    });
    bindStudioPanel(root, {
      sendCmd,
      getDuration: () => countdownDurationMins,
      setDuration: (mins) => { countdownDurationMins = mins; },
    });
    root.querySelector('#remote-order-filter')?.addEventListener('input', (e) => {
      const q = String(e.target.value || '').trim().toLowerCase();
      root.querySelectorAll('.remote-order-item').forEach((btn) => {
        const title = (btn.dataset.title || btn.textContent || '').toLowerCase();
        const li = btn.closest('li');
        if (li) li.style.display = !q || title.includes(q) ? '' : 'none';
      });
    });
    root.querySelector('[data-retry-ping]')?.addEventListener('click', () => {
      bus.hub?.boostPolling?.({ burstMs: 4000 });
      bus.resyncFromServer?.();
      lastNeedStateAt = 0;
      bus.send(MessageTypes.HEARTBEAT, { ready: true, needState: true, role: 'remote' });
      scheduleRemotePatch(() => patchRemoteUi({ full: true }));
    });
    root.querySelectorAll('[data-tab]').forEach((btn) => {
      btn.onclick = () => {
        if (tab === btn.dataset.tab) return;
        tab = btn.dataset.tab;
        // Troca só o painel — shell (header/tabs/footer) permanece montado
        root.querySelectorAll('[data-tab]').forEach((b) => {
          const on = b.dataset.tab === tab;
          b.classList.toggle('is-active', on);
          b.setAttribute('aria-selected', on ? 'true' : 'false');
        });
        const panel = root.querySelector('.remote-tab-panel');
        if (panel) {
          setHtml(panel, rawHtml(panelContent()));
          bindRemoteEvents();
        } else {
          render(true);
        }
        const footHint = root.querySelector('.remote-foot span:last-child');
        if (footHint) {
          footHint.textContent = tab === 'control'
            ? 'Deslize para trocar de slide'
            : 'Comandos sincronizados com o Controle';
        }
      };
    });
    if (tab === 'macros') {
      bindRemoteProTab(root, remotePro, {
        controlOnline,
        sendCmd,
        rerender: () => {
          const panel = root.querySelector('.remote-tab-panel');
          if (panel && tab === 'macros') {
            setHtml(panel, rawHtml(panelContent()));
            bindRemoteEvents();
          } else render(true);
        },
      });
    }
    if (tab === 'alerts') {
      bindAlertsTab(root, { sendCmd, toast: showRemoteToast });
    }
    bindLocalTimerControls(root, localTimer);
  };

  const scheduleRemotePatch = (fn) => {
    if (window.__SOMOSUM_LIVE_ACTIVE) {
      RenderScheduler.markDirty('remote', { patch: fn, priority: 'live' });
    } else {
      fn();
    }
  };

  const nowTitle = () => {
    const cur = stageState.current;
    if (cur) return cur.itemTitle || stageState.itemTitle || '—';
    if (controlOnline && Date.now() - lastHeartbeat < 12000) {
      return stageState.programItems?.length
        ? 'Abra um item na Ordem'
        : 'Conectado — abra um culto no Controle';
    }
    return 'Aguardando o Controle…';
  };

  const patchRemoteHeader = () => {
    const cur = stageState.current;
    const online = controlOnline && Date.now() - lastHeartbeat < 12000;
    const nowEl = root.querySelector('.remote-now');
    const metaEl = root.querySelector('.remote-meta');
    const statusEl = root.querySelector('.remote-status');
    const churchEl = root.querySelector('.remote-church');
    if (churchEl && stageState.churchName) churchEl.textContent = stageState.churchName;
    if (nowEl) nowEl.textContent = nowTitle();
    if (metaEl) {
      if (cur) {
        metaEl.hidden = false;
        metaEl.textContent = `${stageState.slideTypeLabel || slideTypeLabel(cur.slideType)}${stageState.cultoTitle ? ` · ${stageState.cultoTitle}` : ''}`;
      } else {
        metaEl.hidden = true;
        metaEl.textContent = '';
      }
    }
    if (statusEl) {
      statusEl.classList.toggle('is-online', online);
      statusEl.classList.toggle('is-offline', !online);
      statusEl.title = online ? 'Sincronizado com o Controle' : 'Abra o Controle no PC';
      const label = statusEl.querySelector('.remote-status-label');
      if (label) {
        label.textContent = cmdStatusLabel();
      }
      statusEl.classList.toggle('is-cmd-failed', cmdStatus === 'failed');
      statusEl.classList.toggle('is-cmd-sent', cmdStatus === 'sent' || Date.now() - lastAckAt < 2500);
    }
  };

  const patchControlLive = () => {
    if (tab !== 'control' || !shellMounted) return false;
    const panel = root.querySelector('.remote-tab-panel');
    if (!panel) return false;
    const readerLive = !!stageState.bibleReaderLive;
    const hasReaderUi = !!panel.querySelector('[data-cmd="readerStop"]');
    const hasOffline = !!panel.querySelector('.remote-offline-banner');
    const online = controlOnline && Date.now() - lastHeartbeat < 12000;
    if (readerLive !== hasReaderUi || (!online) !== hasOffline) {
      return patchControlTab();
    }
    const expectsCdStop = !!stageState.countdownActive;
    const hasCdStop = !!panel.querySelector('[data-cmd="countdownStop"]');
    if (!readerLive && panel.querySelector('.remote-quick') && expectsCdStop !== hasCdStop) {
      return patchControlTab();
    }
    if (readerLive) {
      const rp = stageState.readerProgress;
      const titleEl = panel.querySelector('.remote-progress strong');
      const rangeEl = panel.querySelector('.remote-overlay-pill');
      if (titleEl && rp?.chapterTitle != null) titleEl.textContent = rp.chapterTitle || '';
      if (rangeEl && rp) {
        rangeEl.textContent = `${rp.slideRange || ''} · ${(rp.index ?? 0) + 1}/${rp.total || '?'}`;
      }
      patchRemoteHeader();
      return true;
    }
    const titleEl = panel.querySelector('.remote-now-title');
    const metaEl = panel.querySelector('.remote-now-meta');
    if (!titleEl || !metaEl) return patchControlTab();
    titleEl.textContent = nowTitle();
    const typeLabel = stageState.slideTypeLabel || slideTypeLabel(stageState.current?.slideType);
    metaEl.textContent = `${formatProgress()}${typeLabel ? ` · ${typeLabel}` : ''}`;
    const pillRow = panel.querySelector('.remote-pill-row');
    if (pillRow) {
      const pills = [];
      if (stageState.overlay) {
        pills.push(`<span class="remote-overlay-pill">${esc(stageState.overlay === 'blank' ? 'Tela preta' : 'Logo')}</span>`);
      }
      if (stageState.countdownActive) pills.push('<span class="remote-overlay-pill is-countdown">Pré-culto</span>');
      if (stageState.rehearsal) pills.push('<span class="remote-overlay-pill is-rehearsal">Ensaio</span>');
      setHtml(pillRow, rawHtml(pills.join('')));
    }
    const note = stageState.note || stageState.itemOperatorNote || '';
    let noteEl = panel.querySelector('.remote-stage-note');
    const nowCard = panel.querySelector('.remote-now-card');
    if (note && nowCard) {
      if (!noteEl) {
        noteEl = document.createElement('p');
        noteEl.className = 'remote-stage-note';
        nowCard.appendChild(noteEl);
      }
      setHtml(noteEl, rawHtml(`<span class="remote-stage-note-label">Nota</span> ${esc(note)}`));
    } else if (noteEl) {
      noteEl.remove();
    }
    const nextList = panel.querySelector('.remote-list ul');
    if (nextList) {
      const rows = (stageState.nextItems || []).slice(0, 3);
      setHtml(nextList, rawHtml(rows.length
        ? rows.map((it) =>
          `<li class="remote-next-highlight"><span class="remote-type">${esc(slideTypeLabel(it.slideType))}</span> ${esc(it.title)}</li>`
        ).join('')
        : '<li class="muted">Fim do programa</li>'));
    }
    const count = stageState.itemSlideCount || stageState.current?.slideCount || 0;
    const itemIndex = stageState.current?.itemIndex;
    const wantParts = count > 1 && Number.isFinite(itemIndex);
    let partsSec = panel.querySelector('.remote-parts');
    const bindParts = (sec) => {
      sec.querySelectorAll('[data-part]').forEach((btn) => {
        btn.onclick = () => {
          const idx = stageState.current?.itemIndex;
          if (!Number.isFinite(idx)) return;
          void sendCmd('goToSlide', { itemIndex: idx, slideIndex: parseInt(btn.dataset.part, 10) });
        };
      });
    };
    if (wantParts) {
      const html = renderLyricsParts();
      const wrap = document.createElement('div');
      setHtml(wrap, rawHtml(html));
      const fresh = wrap.firstElementChild;
      if (fresh) {
        if (partsSec) partsSec.replaceWith(fresh);
        else panel.appendChild(fresh);
        bindParts(fresh);
      }
    } else if (partsSec) {
      partsSec.remove();
    }
    patchRemoteHeader();
    return true;
  };

  const patchControlTab = () => {
    if (tab !== 'control' || !shellMounted) return false;
    const panel = root.querySelector('.remote-tab-panel');
    if (!panel) return false;
    patchRemoteHeader();
    setHtml(panel, rawHtml(renderControlTab()));
    bindRemoteEvents();
    return true;
  };

  const patchOrderTab = () => {
    if (tab !== 'order' || !shellMounted) return false;
    const panel = root.querySelector('.remote-tab-panel');
    if (!panel) return false;
    patchRemoteHeader();
    setHtml(panel, rawHtml(renderOrderTab()));
    bindRemoteEvents();
    return true;
  };

  const panelContent = () => {
    if (tab === 'control') return renderControlTab();
    if (tab === 'order') return renderOrderTab();
    if (tab === 'library') return renderLibraryTab();
    if (tab === 'alerts') return renderAlertsTab();
    return renderMacrosTab();
  };

  const patchRemoteUi = ({ full = false } = {}) => {
    if (!shellMounted) return false;
    if (tab === 'control') {
      if (full) return patchControlLive();
      patchRemoteHeader();
      return true;
    }
    if (tab === 'order') {
      if (full) return patchOrderTab();
      patchOrderSelection();
      return true;
    }
    if (full && (tab === 'library' || tab === 'alerts' || tab === 'macros')) {
      const panel = root.querySelector('.remote-tab-panel');
      if (!panel) return false;
      patchRemoteHeader();
      setHtml(panel, rawHtml(panelContent()));
      bindRemoteEvents();
      return true;
    }
    patchRemoteHeader();
    return tab === 'library' || tab === 'alerts' || tab === 'macros';
  };

  const render = (forceFull = false) => {
    if (!forceFull && patchRemoteUi()) return;
    const cur = stageState.current;
    const online = controlOnline && Date.now() - lastHeartbeat < 12000;
    const churchLine = stageState.churchName || 'SOMOSUM';
    const cultoLine = stageState.cultoTitle || stageState.churchSubtitle || '';
    setHtml(root, rawHtml(`
      <div class="remote-app" data-remote-layout="operador">
        <header class="remote-head">
          <div class="remote-head-main">
            <p class="remote-church">${esc(churchLine)}</p>
            <h1>Remote</h1>
            <p class="remote-now">${esc(nowTitle())}</p>
            <p class="remote-meta" ${cur ? '' : 'hidden'}>${cur ? `${esc(stageState.slideTypeLabel || slideTypeLabel(cur.slideType))}${cultoLine ? ` · ${esc(cultoLine)}` : ''}` : ''}</p>
          </div>
          <div class="remote-head-actions">
            <button type="button" class="remote-theme-btn" data-chrome-theme-toggle title="Alternar aparência">
              <span data-chrome-label>Aparência</span>
            </button>
            <span class="remote-status ${online ? 'is-online' : 'is-offline'}" title="${online ? 'Sincronizado com o Controle' : 'Abra o Controle no PC'}">
              <span class="remote-status-dot"></span>
              <span class="remote-status-label">${cmdStatusLabel()}</span>
            </span>
          </div>
        </header>
        <nav class="remote-tabs remote-bottom-nav remote-bottom-nav--5" role="tablist" aria-label="Navegação do Remote">
          <button type="button" role="tab" class="remote-tab ${tab === 'control' ? 'is-active' : ''}" data-tab="control" aria-selected="${tab === 'control'}">${faRemoteTabIcon('control')}<span>Controle</span></button>
          <button type="button" role="tab" class="remote-tab ${tab === 'order' ? 'is-active' : ''}" data-tab="order" aria-selected="${tab === 'order'}">${faRemoteTabIcon('order')}<span>Ordem</span></button>
          <button type="button" role="tab" class="remote-tab ${tab === 'library' ? 'is-active' : ''}" data-tab="library" aria-selected="${tab === 'library'}">${faRemoteTabIcon('library')}<span>Biblioteca</span></button>
          <button type="button" role="tab" class="remote-tab ${tab === 'alerts' ? 'is-active' : ''}" data-tab="alerts" aria-selected="${tab === 'alerts'}">${faRemoteTabIcon('alerts')}<span>Avisos</span></button>
          <button type="button" role="tab" class="remote-tab ${tab === 'macros' ? 'is-active' : ''}" data-tab="macros" aria-selected="${tab === 'macros'}">${faRemoteTabIcon('macros')}<span>Ações</span></button>
        </nav>
        <div class="remote-tab-panel">
          ${panelContent()}
        </div>
        <footer class="remote-foot">
          <span>${esc(location.hostname)}:${esc(location.port || '8765')}</span>
          <span>${tab === 'control' ? 'Deslize para trocar de slide' : 'Comandos sincronizados com o Controle'}</span>
        </footer>
      </div>`));

    bindRemoteEvents();
    bindThemeToggle(root);
    shellMounted = true;
  };

  const onTouchStart = (e) => {
    const t = e.changedTouches?.[0];
    if (!t) return;
    touchStartX = t.clientX;
    touchStartY = t.clientY;
  };

  const onTouchEnd = (e) => {
    if (tab !== 'control') return;
    if (e.target?.closest?.('.remote-order, .remote-tab-panel input, button')) {
      /* allow buttons; still allow swipe on panel empty areas */
    }
    if (e.target?.closest?.('.remote-order-list, .remote-part-strip')) return;
    const t = e.changedTouches?.[0];
    if (!t) return;
    const dx = t.clientX - touchStartX;
    const dy = t.clientY - touchStartY;
    if (Math.abs(dx) < 48 || Math.abs(dx) < Math.abs(dy)) return;
    sendCmd(dx < 0 ? 'next' : 'prev');
  };

  let lastNeedStateAt = 0;
  const requestStateIfEmpty = () => {
    if (stageState.current) return;
    const now = Date.now();
    if (now - lastNeedStateAt < 2500) return;
    lastNeedStateAt = now;
    bus.send(MessageTypes.HEARTBEAT, { needState: true, role: 'remote' });
  };

  bus.on((msg) => {
    if (msg.type === MessageTypes.REMOTE_ACK && msg.from === 'control') {
      const p = msg.payload || {};
      if (p.cmdId && p.cmdId === pendingCmdId) {
        pendingCmdId = null;
        lastAckAt = Date.now();
        cmdStatus = p.ok === false ? 'failed' : 'idle';
      }
      if (p.ok !== false && Number.isFinite(p.itemIndex) && p.itemIndex >= 0) {
        applyNavFromAck(p);
        if (tab === 'order' || tab === 'control') {
          scheduleRemotePatch(() => {
            if (tab === 'order') patchOrderSelection();
            else patchControlLive();
          });
        }
      }
      patchRemoteHeader();
      bus.hub?.boostPolling?.({ burstMs: 1200 });
      return;
    }
    if (msg.type === MessageTypes.STAGE_STATE) {
      if (msg.from === 'control') {
        controlOnline = true;
        lastHeartbeat = Date.now();
      }
      const prevCd = !!stageState.countdownActive;
      const prevBible = !!stageState.bibleReaderLive;
      const prevAmb = !!stageState.ambient?.playing;
      const prevItemsLen = stageState.programItems?.length || 0;
      mergeStagePayload(msg.payload || {});
      const structChanged = prevCd !== !!stageState.countdownActive
        || prevBible !== !!stageState.bibleReaderLive
        || prevAmb !== !!stageState.ambient?.playing
        || prevItemsLen !== (stageState.programItems?.length || 0);
      if (tab === 'control' || tab === 'order' || tab === 'library') {
        scheduleRemotePatch(() => {
          if (tab === 'order') {
            if (Array.isArray(msg.payload?.programItems)
              || prevItemsLen !== (stageState.programItems?.length || 0)) {
              patchOrderTab();
            } else {
              patchOrderSelection();
            }
          } else if (tab === 'library' && structChanged) {
            patchRemoteUi({ full: true });
          } else if (tab === 'control') {
            patchControlLive();
          } else {
            patchRemoteHeader();
          }
        });
      } else if (tab === 'alerts' || tab === 'macros') {
        scheduleRemotePatch(() => patchRemoteHeader());
      } else {
        scheduleRemotePatch(() => patchRemoteUi({ full: false }));
      }
    }
    if (msg.type === MessageTypes.STAGE_ALERT) {
      const p = msg.payload || {};
      if (p.silent || p.kind === 'ebd-countdown') return;
      if (p.kind === 'dismiss' || p.kind === 'dismiss-alerts') {
        clearRemoteAlert();
        hasActiveAlert = false;
        if (tab === 'control' || tab === 'library') {
          scheduleRemotePatch(() => patchRemoteUi({ full: true }));
        } else {
          scheduleRemotePatch(() => patchRemoteHeader());
        }
        return;
      }
      if (p.kind === 'note' || p.kind === 'countdown' || p.kind === 'info' || p.kind === 'urgent') {
        hasActiveAlert = true;
        showRemoteAlertBanner(p);
        vibrate(20);
        if (tab === 'control' || tab === 'library') {
          scheduleRemotePatch(() => patchRemoteUi({ full: true }));
        } else {
          scheduleRemotePatch(() => patchRemoteHeader());
        }
      }
    }
    if (msg.type === MessageTypes.FULL_STATE && (msg.from === 'control' || !msg.from)) {
      controlOnline = true;
      lastHeartbeat = Date.now();
      if (msg.payload?.clientMeta) {
        const compat = assertCompatible(window.__SOMOSUM_META__, msg.payload.clientMeta);
        showCompatBanner(compat);
      }
      applyFullStateToStage(msg.payload || {});
      scheduleRemotePatch(() => {
        if (!shellMounted) render(true);
        else if (tab === 'control') patchControlLive();
        else if (tab === 'order') patchOrderSelection();
        else if (tab === 'library') patchRemoteUi({ full: true });
        else patchRemoteHeader();
      });
    }
    if (msg.type === MessageTypes.HEARTBEAT && msg.from === 'control') {
      controlOnline = true;
      lastHeartbeat = Date.now();
      // Responde só a ping — nunca a pong (evita storm ping-pong)
      if (msg.payload?.ping) {
        bus.send(MessageTypes.HEARTBEAT, { pong: true, role: 'remote' });
      }
      if (!stageState.current) requestStateIfEmpty();
      scheduleRemotePatch(() => patchRemoteUi({ full: false }));
    }
    if (msg.type === MessageTypes.SLIDE && msg.from === 'control') {
      controlOnline = true;
      lastHeartbeat = Date.now();
      const slide = msg.payload?.slide;
      if (slide) {
        const nav = msg.payload?.stageNav || {};
        const title = nav.itemTitle || slide.title || slide.reference || slideTypeLabel(slide.type);
        stageState = {
          ...stageState,
          slide,
          current: {
            ...(stageState.current || {}),
            itemTitle: title,
            slideType: nav.slideTypeLabel || slide.type || stageState.current?.slideType,
            itemIndex: Number.isFinite(nav.itemIndex) ? nav.itemIndex : (stageState.current?.itemIndex ?? 0),
            slideIndex: Number.isFinite(nav.slideIndex) ? nav.slideIndex : (stageState.current?.slideIndex ?? 0),
            slideCount: Number.isFinite(nav.itemSlideCount) ? nav.itemSlideCount : (stageState.current?.slideCount ?? 1),
          },
          itemTitle: title || stageState.itemTitle,
          slideTypeLabel: slideTypeLabel(nav.slideTypeLabel || slide.type),
          flatIndex: Number.isFinite(nav.flatIndex) ? nav.flatIndex : stageState.flatIndex,
          overlay: msg.payload?.programState?.overlay ?? msg.payload?.overlay ?? stageState.overlay,
        };
        scheduleRemotePatch(() => {
          if (tab === 'control') patchControlLive();
          else if (tab === 'order') patchOrderSelection();
          else patchRemoteHeader();
        });
      }
    }
  });

  function applyFullStateToStage(payload) {
    const slide = payload.slide;
    const ps = payload.programState || {};
    const church = payload.prefs?.church || {};
    const nav = payload.prefs?.navigation || {};
    const title = slide?.title || slide?.reference || slideTypeLabel(slide?.type);
    const amb = payload.prefs?.ambient || payload.ambient;
    stageState = {
      ...stageState,
      slide: slide || stageState.slide,
      overlay: ps.overlay ?? stageState.overlay,
      flatIndex: Number.isFinite(ps.currentIndex) ? ps.currentIndex : stageState.flatIndex,
      totalSlides: stageState.totalSlides || (slide ? Math.max(1, stageState.totalSlides || 0) : stageState.totalSlides),
      countdownActive: !!(payload.countdown?.active ?? stageState.countdownActive),
      ambient: amb
        ? {
          playing: !!amb.playing,
          hasTrack: !!(amb.trackPath || amb.hasTrack),
          volume: amb.volume,
          autoWithCountdown: amb.autoWithCountdown !== false,
        }
        : (stageState.ambient || { playing: false, hasTrack: false }),
      churchName: church.name || stageState.churchName,
      churchSubtitle: church.subtitle || stageState.churchSubtitle,
      cultoTitle: nav.cultoTitle || stageState.cultoTitle,
      itemTitle: title || stageState.itemTitle,
      slideTypeLabel: slide ? slideTypeLabel(slide.type) : stageState.slideTypeLabel,
      current: stageState.current || (slide ? {
        itemTitle: title || 'Slide',
        slideType: slide.type,
        itemIndex: 0,
        slideIndex: 0,
        slideCount: 1,
      } : null),
    };
    if (Number.isFinite(Number(payload.countdown?.durationMinutes))) {
      countdownDurationMins = Number(payload.countdown.durationMinutes);
    }
  }

  const markFromServerState = async () => {
    try {
      const state = await bus.resyncFromServer?.() || await bus.hub?.fetchState?.({ apply: true });
      if (state?.type === MessageTypes.FULL_STATE || state?.from === 'control') {
        controlOnline = true;
        lastHeartbeat = Date.now();
        if (state?.payload) applyFullStateToStage(state.payload);
        scheduleRemotePatch(() => {
          if (!shellMounted) render(true);
          else if (tab === 'control') patchControlLive();
          else if (tab === 'library') patchRemoteUi({ full: true });
          else patchRemoteHeader();
        });
      }
      if (!stageState.current) requestStateIfEmpty();
    } catch { /* ignore */ }
  };
  markFromServerState();
  setTimeout(markFromServerState, 800);

  TaskScheduler.register({
    id: TaskIds.REMOTE_RESYNC,
    kind: 'interval',
    intervalMs: 12000,
    priority: 5,
    coalesce: true,
    fn: () => {
      bus.send(MessageTypes.HEARTBEAT, {
        ping: true,
        role: 'remote',
        needState: !stageState.current,
      });
      if (!stageState.current) void markFromServerState();
    },
  });

  TaskScheduler.register({
    id: TaskIds.REMOTE_OFFLINE,
    kind: 'interval',
    intervalMs: 3000,
    priority: 8,
    fn: () => {
      if (controlOnline && Date.now() - lastHeartbeat > 12000) {
        controlOnline = false;
        scheduleRemotePatch(() => {
          if (tab === 'control' || tab === 'library') patchRemoteUi({ full: true });
          else patchRemoteHeader();
        });
      }
    },
  });

  document.addEventListener('touchstart', onTouchStart, { passive: true });
  document.addEventListener('touchend', onTouchEnd, { passive: true });

  render();
  requestAnimationFrame(() => {
    requestAnimationFrame(() => {
      try {
        if (typeof window.__somosumFinishBootSplash === 'function') {
          void window.__somosumFinishBootSplash();
        } else {
          document.getElementById('boot-loading')?.remove();
        }
      } catch { /* ignore */ }
    });
  });
  // Handshake: ready + needState força STAGE_STATE no Controle (dedupe não bloqueia)
  bus.send(MessageTypes.HEARTBEAT, { ready: true, needState: true, role: 'remote' });
  setTimeout(() => {
    if (!stageState.current) {
      bus.send(MessageTypes.HEARTBEAT, { needState: true, role: 'remote' });
      void markFromServerState();
    }
  }, 1200);

  if ('wakeLock' in navigator) {
    const lock = async () => {
      try { await navigator.wakeLock.request('screen'); } catch { /* ignore */ }
    };
    lock();
    document.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'visible') lock();
    });
  }
}

main().catch((err) => {
  console.error('[SOMOSUM remote boot]', err);
  dismissRemoteSplash();
  const root = document.getElementById('remote-root');
  if (root) {
    setHtml(root, rawHtml(`
      <div class="remote-error">
        <div>
          <h1>Erro ao iniciar</h1>
          <p>Não foi possível carregar o Remote. Recarregue a página ou reinicie o SOMOSUM no PC.</p>
          <button type="button" class="su-btn su-btn--primary remote-btn remote-btn-primary" onclick="location.reload()">Tentar novamente</button>
        </div>
      </div>`));
  }
});
