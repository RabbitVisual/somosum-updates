/**
 * Tema claro/escuro — Remote (chrome global + data-remote-theme para CSS do Remote).
 */
import {
  applyChromeTheme,
  bindChromeThemeToggle as bindGlobalChromeToggle,
  resolveChromeTheme,
  toggleChromeTheme,
} from '../ui/chrome-theme.js';
import { getPrefs } from '../core/store.js';

function syncRemoteThemeAttr(mode) {
  const next = mode === 'light' ? 'light' : 'dark';
  try {
    document.documentElement.dataset.remoteTheme = next;
  } catch { /* ignore */ }
  return next;
}

export function initRemoteTheme() {
  const mode = resolveChromeTheme(getPrefs());
  applyChromeTheme(mode);
  syncRemoteThemeAttr(mode);
  return mode;
}

export function applyTheme(mode) {
  const next = applyChromeTheme(mode === 'light' ? 'light' : 'dark', { persist: true, prefs: getPrefs() });
  syncRemoteThemeAttr(next);
  return next;
}

export function toggleTheme() {
  const next = toggleChromeTheme({ prefs: getPrefs() });
  syncRemoteThemeAttr(next);
  return next;
}

export function bindThemeToggle(root) {
  bindGlobalChromeToggle(root, {
    onChange: (mode) => syncRemoteThemeAttr(mode),
  });
}
