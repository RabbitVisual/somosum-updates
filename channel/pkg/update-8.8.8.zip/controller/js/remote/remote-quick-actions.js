/**
 * Ações rápidas do Remote (Controle) — sem duplicar overlays/pré-culto da Biblioteca.
 */
import { faBtnIcon, faIcon } from '../core/fa-icons.js';

export function renderQuickActionsHtml({
  controlOnline,
  countdownActive,
  timerLabel,
  hasActiveAlert = false,
}) {
  void controlOnline;
  void timerLabel;
  void countdownActive;
  return `
    <div class="remote-quick remote-quick-grid remote-quick-grid--compact">
      <button type="button" class="su-btn remote-btn remote-btn-action" data-tab-jump="library">${faBtnIcon('countdown')} Pré-culto / Bíblia</button>
      <button type="button" class="su-btn remote-btn remote-btn-action" data-tab-jump="library">${faBtnIcon('blank')} Overlays</button>
      <button type="button" class="su-btn remote-btn remote-btn-action" data-cmd="openSongs">${faBtnIcon('lyrics')} Louvores</button>
      <button type="button" class="su-btn remote-btn remote-btn-action" data-tab-jump="alerts">${faBtnIcon('alert')} Avisos</button>
    </div>
    ${hasActiveAlert ? `
      <button type="button" class="su-btn su-btn--warn remote-btn remote-btn-action remote-btn-stop-alert" data-cmd="dismissAlert" style="margin-top:.55rem;width:100%">
        ${faIcon('close', 'su-fa su-fa--inline-btn')} Parar aviso do Controle
      </button>` : ''}
    <p class="remote-hint" style="margin-top:.55rem">Overlays e pré-culto com duração ficam na aba <strong>Biblioteca</strong>.</p>`;
}

export function createLocalTimer(onTick) {
  let startedAt = 0;
  let elapsed = 0;
  let running = false;
  let interval = null;

  const format = (sec) => {
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  };

  const emit = () => {
    const sec = running
      ? elapsed + Math.floor((Date.now() - startedAt) / 1000)
      : elapsed;
    onTick?.(format(sec), running);
  };

  return {
    toggle() {
      if (running) {
        elapsed += Math.floor((Date.now() - startedAt) / 1000);
        running = false;
        clearInterval(interval);
        interval = null;
      } else {
        startedAt = Date.now();
        running = true;
        interval = setInterval(emit, 500);
      }
      emit();
    },
    reset() {
      running = false;
      elapsed = 0;
      startedAt = 0;
      clearInterval(interval);
      interval = null;
      onTick?.('00:00', false);
    },
  };
}

export function bindLocalTimerControls(root, timer) {
  root.querySelector('[data-local-timer-toggle]')?.addEventListener('click', () => timer.toggle());
  root.querySelector('[data-local-timer-reset]')?.addEventListener('click', () => timer.reset());
}
