import { COUNTDOWN_VERSE_POOL, DEFAULT_COUNTDOWN_NOTICES } from '../data/countdown-verses.js';

/** Fundos do pré-culto (UI limpa — legado mapeado em normalizeCountdownBgMode). */
export const COUNTDOWN_BG_MODES = [
  { id: 'welcome', label: 'Foto/vídeo da igreja', hint: 'Mídia definida em Ajustes → Igreja' },
  { id: 'media', label: 'Mídia personalizada', hint: 'Escolha um vídeo ou imagem só para o pré-culto' },
  { id: 'midnight', label: 'Noite dourada', hint: 'Azul-noite com poeira de ouro' },
  { id: 'dark', label: 'Preto profundo', hint: 'Fundo sóbrio para tipografia forte' },
];

/** Estilos de composição na tela (templates de pré-culto). */
export const COUNTDOWN_LAYOUTS = [
  { id: 'classic', label: 'Clássico', hint: 'Logo no topo, relógio grande e versículo' },
  { id: 'minimal', label: 'Minimalista', hint: 'Relógio limpo, pouco texto' },
  { id: 'cinematic', label: 'Cinematográfico', hint: 'Fundo em destaque, relógio na base' },
];

export const COUNTDOWN_PHASE_LABELS = {
  idle: 'Parado',
  running: 'Contando',
  announce: 'Avisos',
  transition: 'Transição',
};

const BG_MODE_IDS = new Set(COUNTDOWN_BG_MODES.map((m) => m.id));
const LAYOUT_IDS = new Set(COUNTDOWN_LAYOUTS.map((m) => m.id));

/** Modes antigas → modo atual (prefs/cultos salvos). */
const LEGACY_BG_MODE = {
  gradient: 'midnight',
  aurora: 'midnight',
  sacred: 'midnight',
  candle: 'dark',
  stars: 'midnight',
  velvet: 'dark',
  crosslight: 'midnight',
  none: 'dark',
};

const LEGACY_LAYOUT = {
  centered: 'classic',
  church: 'classic',
};

export function normalizeCountdownBgMode(raw) {
  if (LEGACY_BG_MODE[raw]) return LEGACY_BG_MODE[raw];
  return BG_MODE_IDS.has(raw) ? raw : 'welcome';
}

/** blob:/data: não sobrevivem ao reload — nunca persistir em prefs. */
export function isEphemeralMediaSrc(src = '') {
  const s = String(src || '').trim().toLowerCase();
  return !s || s.startsWith('blob:') || s.startsWith('data:');
}

/** Remove mídia efêmera do countdown; se modo media ficar sem src, volta para welcome. */
export function sanitizeCountdownPersistedMedia(countdown = {}) {
  const cd = { ...countdown };
  let changed = false;
  if (isEphemeralMediaSrc(cd.customMediaSrc)) {
    if (cd.customMediaSrc) changed = true;
    cd.customMediaSrc = '';
  }
  if (normalizeCountdownBgMode(cd.backgroundMode) === 'media' && !String(cd.customMediaSrc || '').trim()) {
    cd.backgroundMode = 'welcome';
    changed = true;
  }
  return { countdown: cd, changed };
}

export function normalizeCountdownLayout(raw) {
  if (LEGACY_LAYOUT[raw]) return LEGACY_LAYOUT[raw];
  return LAYOUT_IDS.has(raw) ? raw : 'classic';
}

export function countdownPhaseLabel(phase) {
  return COUNTDOWN_PHASE_LABELS[phase] || 'Preparando';
}

export const DEFAULT_COUNTDOWN = {
  mode: 'duration',
  serviceTime: '19:30',
  serviceDate: null,
  durationMinutes: 10,
  label: 'O culto começa em',
  announcementTitle: 'O Culto vai Começar',
  announcementDurationSec: 20,
  noticeSpotlightSec: 5,
  transitionDurationSec: 6,
  showBranding: true,
  showRandomVerses: true,
  verseIntervalSec: 22,
  verseSpotlightSec: 8,
  includeEventMotto: true,
  hideFooter: true,
  hideClock: true,
  autoGoToWelcome: true,
  playBell: true,
  bellPath: null,
  bellVolume: 0.7,
  fadeAmbientOnEnd: true,
  ambientFadeStart: 'transition',
  ambientFadeSec: 4,
  backgroundMode: 'midnight',
  backgroundDim: 0.45,
  customMediaSrc: '',
  customMediaKind: 'image',
  layoutStyle: 'classic',
  clockFontFamily: '',
  notices: DEFAULT_COUNTDOWN_NOTICES,
  active: false,
  phase: 'idle',
  targetMs: null,
  startedAt: null,
};

export const DEFAULT_COUNTDOWN_PRESETS = [
  {
    id: 'pre-culto-10',
    name: 'Pré-culto 10 min',
    mode: 'duration',
    durationMinutes: 10,
    label: 'O culto começa em',
    backgroundMode: 'midnight',
    backgroundDim: 0.45,
    layoutStyle: 'classic',
  },
  {
    id: 'pre-culto-15',
    name: 'Pré-culto 15 min',
    mode: 'duration',
    durationMinutes: 15,
    label: 'O culto começa em',
    backgroundMode: 'midnight',
    backgroundDim: 0.5,
    layoutStyle: 'classic',
  },
  {
    id: 'culto-1930',
    name: 'Culto 19:30',
    mode: 'time',
    serviceTime: '19:30',
    serviceDate: null,
    label: 'O culto começa em',
    backgroundMode: 'welcome',
    backgroundDim: 0.38,
    layoutStyle: 'classic',
  },
  {
    id: 'cinema-10',
    name: 'Cinematográfico 10 min',
    mode: 'duration',
    durationMinutes: 10,
    label: 'O culto começa em',
    backgroundMode: 'dark',
    backgroundDim: 0.55,
    layoutStyle: 'cinematic',
  },
  {
    id: 'minimal-5',
    name: 'Minimalista 5 min',
    mode: 'duration',
    durationMinutes: 5,
    label: 'Começa em',
    backgroundMode: 'dark',
    backgroundDim: 0.35,
    layoutStyle: 'minimal',
    showRandomVerses: false,
  },
  {
    id: 'estrelas-15',
    name: 'Noite 15 min',
    mode: 'duration',
    durationMinutes: 15,
    label: 'O culto começa em',
    backgroundMode: 'midnight',
    backgroundDim: 0.4,
    layoutStyle: 'classic',
  },
];

export function stripRuntimeCountdownFields(config = {}) {
  const {
    active,
    phase,
    targetMs,
    startedAt,
    panelMinimized,
    assets,
    prefs,
    bibleVersion,
    welcomeSlide,
    ...rest
  } = config || {};
  void active;
  void phase;
  void targetMs;
  void startedAt;
  void panelMinimized;
  void assets;
  void prefs;
  void bibleVersion;
  void welcomeSlide;
  return rest;
}

export function normalizeCountdownPreset(raw = {}) {
  const id = String(raw.id || `modelo-${Date.now()}`).replace(/[^a-z0-9_-]+/gi, '-').slice(0, 48) || 'modelo';
  const name = String(raw.name || raw.label || 'Modelo personalizado').trim().slice(0, 60) || 'Modelo personalizado';
  return {
    id,
    name,
    ...normalizeCountdownConfig(stripRuntimeCountdownFields(raw)),
  };
}

export function normalizeCountdownPresets(list) {
  const source = Array.isArray(list) ? list : [];
  const seen = new Set();
  return source.map(normalizeCountdownPreset).filter((preset) => {
    if (seen.has(preset.id)) return false;
    seen.add(preset.id);
    return true;
  });
}

export function normalizeCountdownConfig(raw = {}) {
  const duration = Number(raw.durationMinutes);
  const verseInterval = Number(raw.verseIntervalSec);
  const announceSec = Number(raw.announcementDurationSec);
  const transSec = Number(raw.transitionDurationSec);
  const bellVol = Number(raw.bellVolume);
  const fadeSec = Number(raw.ambientFadeSec);
  const spotlightSec = Number(raw.verseSpotlightSec);
  const noticeSpot = Number(raw.noticeSpotlightSec);
  const notices = Array.isArray(raw.notices) && raw.notices.length
    ? raw.notices
    : DEFAULT_COUNTDOWN_NOTICES;
  const dimRaw = Number(raw.backgroundDim);
  const customMediaSrc = (() => {
    const src = String(raw.customMediaSrc || '').trim();
    return isEphemeralMediaSrc(src) ? '' : src;
  })();
  let backgroundMode = normalizeCountdownBgMode(raw.backgroundMode || DEFAULT_COUNTDOWN.backgroundMode);
  if (backgroundMode === 'media' && !customMediaSrc) backgroundMode = 'welcome';

  return {
    mode: raw.mode === 'time' ? 'time' : 'duration',
    serviceTime: raw.serviceTime || DEFAULT_COUNTDOWN.serviceTime,
    serviceDate: raw.serviceDate || null,
    durationMinutes: Number.isFinite(duration) ? Math.max(1, Math.min(180, duration)) : 10,
    // Opcional: duração exata em segundos (plugins / atalhos). Se ausente, usa minutos.
    durationSeconds: (() => {
      const sec = Number(raw.durationSeconds);
      return Number.isFinite(sec) && sec > 0 ? Math.max(1, Math.min(180 * 60, Math.floor(sec))) : null;
    })(),
    label: raw.label || DEFAULT_COUNTDOWN.label,
    announcementTitle: raw.announcementTitle || DEFAULT_COUNTDOWN.announcementTitle,
    announcementDurationSec: Number.isFinite(announceSec) ? Math.max(5, Math.min(90, announceSec)) : 14,
    noticeSpotlightSec: Number.isFinite(noticeSpot) ? Math.max(3, Math.min(12, noticeSpot)) : 5,
    transitionDurationSec: Number.isFinite(transSec) ? Math.max(3, Math.min(15, transSec)) : 6,
    showBranding: raw.showBranding !== false,
    showRandomVerses: raw.showRandomVerses !== false,
    verseIntervalSec: Number.isFinite(verseInterval) ? Math.max(8, Math.min(120, verseInterval)) : 22,
    verseSpotlightSec: Number.isFinite(spotlightSec) ? Math.max(5, Math.min(25, spotlightSec)) : 10,
    includeEventMotto: raw.includeEventMotto !== false,
    hideFooter: raw.hideFooter !== false,
    hideClock: raw.hideClock !== false,
    autoGoToWelcome: raw.autoGoToWelcome !== false,
    playBell: raw.playBell !== false,
    bellPath: raw.bellPath || null,
    bellVolume: Number.isFinite(bellVol) ? Math.min(1, Math.max(0.1, bellVol)) : 0.7,
    fadeAmbientOnEnd: raw.fadeAmbientOnEnd !== false,
    ambientFadeStart: raw.ambientFadeStart === 'announce' ? 'announce' : 'transition',
    ambientFadeSec: Number.isFinite(fadeSec) ? Math.max(1, Math.min(20, fadeSec)) : 4,
    backgroundMode,
    backgroundDim: Number.isFinite(dimRaw) ? Math.min(0.9, Math.max(0, dimRaw)) : DEFAULT_COUNTDOWN.backgroundDim,
    customMediaSrc,
    customMediaKind: raw.customMediaKind === 'video' || /\.(mp4|webm|mov)(\?|$)/i.test(customMediaSrc)
      ? 'video'
      : 'image',
    layoutStyle: normalizeCountdownLayout(raw.layoutStyle || DEFAULT_COUNTDOWN.layoutStyle),
    clockFontFamily: String(raw.clockFontFamily || '').trim(),
    notices,
  };
}

export function normalizeCountdownState(raw = {}) {
  const config = normalizeCountdownConfig(raw);
  return {
    ...config,
    active: !!raw.active,
    phase: ['idle', 'running', 'announce', 'transition'].includes(raw.phase) ? raw.phase : 'idle',
    targetMs: raw.targetMs ? Number(raw.targetMs) : null,
    startedAt: raw.startedAt ? Number(raw.startedAt) : null,
  };
}

export function getCountdownFromPrefs(prefs = {}) {
  return normalizeCountdownState({ ...DEFAULT_COUNTDOWN, ...(prefs.countdown || {}) });
}

/** Duração mínima da fase de avisos conforme quantidade e tempo em destaque. */
export function computeAnnounceDurationSec(state = {}) {
  const notices = Array.isArray(state.notices) ? state.notices.length : 0;
  const perNotice = Number(state.noticeSpotlightSec) || 5;
  const headerLead = 2;
  const gap = 0.75;
  const settle = 0.85;
  const tail = 3;
  const computed = headerLead + notices * (perNotice + gap + settle) + tail;
  const configured = Number(state.announcementDurationSec);
  const floor = Number.isFinite(configured) ? configured : 20;
  return Math.max(floor, Math.ceil(computed * 10) / 10);
}

export function computeTargetMs(config, now = Date.now()) {
  if (config.mode === 'time') {
    const [hh, mm] = (config.serviceTime || '19:30').split(':').map(Number);
    const base = config.serviceDate
      ? new Date(`${config.serviceDate}T00:00:00`)
      : new Date(now);
    const target = new Date(base);
    target.setHours(hh || 19, mm || 30, 0, 0);
    if (!config.serviceDate && target.getTime() <= now) {
      target.setDate(target.getDate() + 1);
    }
    return target.getTime();
  }
  const sec = Number(config.durationSeconds);
  if (Number.isFinite(sec) && sec > 0) {
    return now + Math.max(1, Math.min(180 * 60, Math.floor(sec))) * 1000;
  }
  const mins = config.durationMinutes || 10;
  return now + mins * 60 * 1000;
}

export function formatCountdownDigits(ms) {
  const total = Math.max(0, Math.floor(ms / 1000));
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = total % 60;
  const pad = (n) => String(n).padStart(2, '0');
  return { h, m, s, display: h > 0 ? `${pad(h)}:${pad(m)}:${pad(s)}` : `${pad(m)}:${pad(s)}` };
}

export function pickRandomVerseRef(pool = COUNTDOWN_VERSE_POOL, excludeKey = null) {
  const list = pool.length ? pool : COUNTDOWN_VERSE_POOL;
  if (list.length === 1) return list[0];
  let pick;
  let guard = 0;
  do {
    pick = list[Math.floor(Math.random() * list.length)];
    guard++;
  } while (guard < 8 && excludeKey && verseKey(pick) === excludeKey);
  return pick;
}

export function verseKey(ref) {
  if (!ref) return '';
  return `${ref.book}-${ref.chapter}-${ref.verseStart}-${ref.verseEnd || ref.verseStart}`;
}

export function buildCountdownPayload(state, welcomeSlide = null) {
  return {
    action: state.active ? 'sync' : 'stop',
    state: {
      ...state,
      welcomeSlide,
    },
  };
}
