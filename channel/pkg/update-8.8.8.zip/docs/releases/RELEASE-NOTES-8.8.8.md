# Release Notes — SOMOSUM 8.8.8

**Data:** 2026-08-12  
**Tipo:** letras para culto + wizard + Pré-culto + tema claro

## Destaques

### Letras — buscar, salvar e projetar para cantar
- Importação (letra.mus.br e afins) **preserva estrofes** — sem amontoar frases.
- Ao salvar: escolha **2 / 4 / 6 linhas** (ou por estrofe); a biblioteca grava essa divisão.
- Projeção: **N linhas = N linhas** na tela (sem partir frase na vírgula).
- Organização inteligente cura quebras ruins e sugere o número de linhas pelo tamanho das estrofes.
- Ao adicionar à ordem, vale a config da **biblioteca** (não um override que bagunça a música).

### Wizard Adicionar slide
- Participação Musical e outros tipos: modal fecha e adiciona de verdade (corrigido `wireSongFilter`).
- Filtro de louvor na busca funciona no Chrome (reconstrói a lista).

### Controle / Stage / Pré-culto
- Modo claro legível nos botões do operador.
- Stage Pregador sem cortar elementos fora da tela.
- Pré-culto mais limpo: sem Modelos salvos; poucos fundos e layouts.

## Como atualizar
1. Em **8.8.7**: Ajuda → Verificar atualização → **8.8.8** → confirme o reinício.
2. Se estiver atrás: suba de 1 em 1 até **8.8.8**.
3. Reimporte louvores antigos amontoados (ou atualize na busca) para recuperar estrofes.

## Verificação rápida
- [ ] Sobre = **8.8.8**
- [ ] Buscar letra → estrofes separadas → salvar com 4 linhas → projetar com 4 frases intactas
- [ ] Adicionar Participação Musical funciona
- [ ] Pré-culto sem bloco Modelos
