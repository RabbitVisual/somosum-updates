import {
  getAllSongs,
  getSong,
  saveSong,
  deleteSong,
  getProgram,
  saveProgram,
  getPrefs,
  savePrefs,
  exportBackup,
  importBackup,
  generateId,
  getAllMedia,
} from '../core/store.js';
import { parseLyrics, cleanPastedLyrics } from './lyrics-parser.js';
import {
  splitLyricsIntoSlides,
  getLyricsStyle,
  formatLyricsForSlides,
  buildLyricsSlides,
  resolveLyricsBackground,
} from './lyrics-splitter.js';
import { renderPreview } from '../slides/slide-engine.js';
import { observeStagePreviewFit } from '../ui/stage-preview-fit.js';
import { mediaBackgroundOptionsHtml } from '../core/media-url.js';
import { faIconRaw } from '../core/fa-icons.js';

export class LyricsEditor {
  constructor(container, callbacks = {}) {
    this.container = container;
    this.callbacks = callbacks;
    this.songs = [];
    this.selectedId = null;
    this.draft = null;
    this.mediaList = [];
    this.syncTimer = null;
  }

  async init() {
    this.songs = await getAllSongs();
    this.mediaList = await getAllMedia();
    this.render();
  }

  async refresh() {
    this.songs = await getAllSongs();
    this.mediaList = await getAllMedia();
    this.render();
  }

  select(id) {
    this.selectedId = id;
    const song = this.songs.find((s) => s.id === id);
    this.draft = song ? structuredClone(song) : null;
    this.render();
  }

  newSong() {
    this.selectedId = null;
    this.draft = {
      id: generateId(),
      title: 'Nova Música',
      artist: '',
      lyrics: '',
      tags: [],
      style: {},
      createdAt: Date.now(),
    };
    this.render();
  }

  async saveDraft() {
    if (!this.draft) return;
    const saved = await saveSong(this.draft);
    this.selectedId = saved.id;
    await this.refresh();
    this.draft = structuredClone(saved);
    this.callbacks.onSave?.(saved);
    this.showToast('Música salva!');
    this.render();
  }

  async remove(id) {
    if (!confirm('Excluir esta música permanentemente?')) return;
    await deleteSong(id);
    if (this.selectedId === id) {
      this.selectedId = null;
      this.draft = null;
    }
    await this.refresh();
    this.callbacks.onDelete?.();
    this.render();
  }

  updateDraft(field, value, sync = true) {
    if (!this.draft) return;
    if (field.startsWith('style.')) {
      const key = field.slice(6);
      this.draft.style = { ...this.draft.style, [key]: value };
    } else {
      this.draft[field] = value;
    }
    this.renderEditor();
    this.renderPreview();
    if (sync && field.startsWith('style.')) this.scheduleStyleSync();
  }

  scheduleStyleSync() {
    clearTimeout(this.syncTimer);
    this.syncTimer = setTimeout(() => this.flushStyleSync(), 400);
  }

  async flushStyleSync() {
    if (!this.draft?.id || !this.selectedId) return;
    await saveSong(this.draft);
    this.callbacks.onStyleChange?.(this.draft);
  }

  bumpFontSize(delta) {
    if (!this.draft) return;
    const prefs = getPrefs();
    const current = this.draft.style?.fontSize ?? prefs.globalLyricsStyle?.fontSize ?? 54;
    const next = Math.min(120, Math.max(20, current + delta));
    this.updateDraft('style.fontSize', next);
  }

  pasteLyrics() {
    navigator.clipboard.readText().then((text) => {
      const cleaned = cleanPastedLyrics(text);
      this.draft.lyrics = cleaned;
      this.applySlidePreset('lines', 4, false);
      this.showToast('Letra colada — 4 linhas por tela aplicado. Ajuste abaixo se quiser.');
    }).catch(() => {
      this.showToast('Não foi possível acessar a área de transferência.');
    });
  }

  applySlidePreset(mode, count, reformat = true) {
    if (!this.draft) return;
    const style = { ...this.draft.style };

    if (mode === 'lines') {
      style.splitMode = 'lines';
      style.linesPerSlide = count;
      delete style.stanzasPerSlide;
    } else if (mode === 'stanzas') {
      style.splitMode = 'stanzas';
      style.stanzasPerSlide = count;
    } else {
      style.splitMode = 'stanza';
      delete style.linesPerSlide;
      delete style.stanzasPerSlide;
    }

    this.draft.style = style;

    if (reformat && this.draft.lyrics?.trim()) {
      const prefs = getPrefs();
      const resolved = getLyricsStyle(this.draft, prefs.globalLyricsStyle);
      this.draft.lyrics = formatLyricsForSlides(this.draft.lyrics, resolved);
    }

    this.renderEditor();
    this.renderPreview();
  }

  getActivePreset() {
    const st = this.draft?.style || {};
    const mode = st.splitMode || 'stanza';
    if (mode === 'lines') return `lines-${st.linesPerSlide || 4}`;
    if (mode === 'stanzas') return `stanzas-${st.stanzasPerSlide || 1}`;
    return 'stanza-1';
  }

  async getPreviewSlides() {
    if (!this.draft) return [];
    const prefs = getPrefs();
    const style = getLyricsStyle(this.draft, prefs.globalLyricsStyle);
    const background = await resolveLyricsBackground(style, (id) =>
      this.mediaList.find((m) => m.id === id) || null
    );
    return buildLyricsSlides(this.draft, style, { background });
  }

  showToast(msg) {
    const existing = document.querySelector('.toast');
    if (existing) existing.remove();
    const el = document.createElement('div');
    el.className = 'toast';
    el.textContent = msg;
    document.body.appendChild(el);
    setTimeout(() => el.remove(), 2500);
  }

  render() {
    this.container.innerHTML = `
      <div class="lyrics-layout">
        <div class="panel">
          <div class="panel-header" style="display:flex;justify-content:space-between;align-items:center">
            <span>Biblioteca</span>
            <button class="btn btn-primary btn-icon" id="lyrics-new" title="Nova música">+</button>
          </div>
          <div class="panel-body" id="lyrics-list"></div>
        </div>
        <div class="panel" style="border-right:none">
          <div class="panel-header">Editor de Letras</div>
          <div class="panel-body" id="lyrics-editor" style="overflow-y:auto"></div>
        </div>
        <div class="panel">
          <div class="panel-header">Preview & Formatação</div>
          <div class="panel-body" id="lyrics-preview-panel" style="overflow-y:auto"></div>
        </div>
      </div>`;

    this.container.querySelector('#lyrics-new').onclick = () => this.newSong();
    this.renderList();
    this.renderEditor();
    this.renderPreview();
  }

  renderList() {
    const list = this.container.querySelector('#lyrics-list');
    if (!this.songs.length) {
      list.innerHTML = '<div class="empty-state">Nenhuma música cadastrada.<br>Clique + para adicionar.</div>';
      return;
    }
    list.innerHTML = this.songs
      .map(
        (s) => `
      <div class="song-list-item ${s.id === this.selectedId ? 'is-active' : ''}" data-id="${s.id}">
        <div class="song-title">${esc(s.title)}</div>
        <div class="song-artist">${esc(s.artist || 'Sem artista')}</div>
      </div>`
      )
      .join('');

    list.querySelectorAll('.song-list-item').forEach((el) => {
      el.onclick = () => this.select(el.dataset.id);
    });
  }

  renderEditor() {
    const editor = this.container.querySelector('#lyrics-editor');
    if (!this.draft) {
      editor.innerHTML = '<div class="empty-state">Selecione ou crie uma música.</div>';
      return;
    }

    const d = this.draft;
    const st = d.style || {};

    editor.innerHTML = `
      <div class="form-grid">
        <div class="form-row-2">
          <div class="form-row">
            <label>Título</label>
            <input type="text" id="le-title" value="${escAttr(d.title)}" />
          </div>
          <div class="form-row">
            <label>Artista / Autor</label>
            <input type="text" id="le-artist" value="${escAttr(d.artist || '')}" />
          </div>
        </div>
        <div class="form-row">
          <label>Letra <small>(linha em branco = novo slide na projeção)</small></label>
          <textarea id="le-lyrics" rows="14">${esc(d.lyrics || '')}</textarea>
        </div>
        <div style="display:flex;gap:.5rem;flex-wrap:wrap">
          <button class="btn btn-secondary" id="le-paste">Colar da Internet</button>
          <button class="btn btn-primary" id="le-save">Salvar Música</button>
          ${this.selectedId ? `<button class="btn btn-danger" id="le-delete">Excluir</button>` : ''}
        </div>
        <hr style="border-color:var(--color-border)" />
        <h3 style="color:var(--color-gold);font-size:.9rem;margin:0 0 .5rem">Linhas / estrofes por tela</h3>
        <p class="form-hint" style="margin-top:0">Escolha a divisão — a letra será reorganizada automaticamente (linha em branco = novo slide).</p>
        <div class="slide-preset-bar" id="le-presets">
          <button type="button" class="slide-preset-btn" data-preset="lines-2">2 linhas</button>
          <button type="button" class="slide-preset-btn" data-preset="lines-4">4 linhas</button>
          <button type="button" class="slide-preset-btn" data-preset="lines-6">6 linhas</button>
          <button type="button" class="slide-preset-btn" data-preset="stanza-1">1 estrofe</button>
          <button type="button" class="slide-preset-btn" data-preset="stanzas-2">2 estrofes</button>
        </div>
        <h3 style="color:var(--color-gold);font-size:.9rem;margin:.75rem 0 .5rem">Fundo na projeção</h3>
        <div class="form-row-2">
          <div class="form-row">
            <label>Gradiente</label>
            <select id="le-bg-preset">
              <option value="theme" ${(st.backgroundPreset || 'theme') === 'theme' ? 'selected' : ''}>Tema (padrão)</option>
              <option value="dark" ${st.backgroundPreset === 'dark' ? 'selected' : ''}>Escuro</option>
              <option value="gold" ${st.backgroundPreset === 'gold' ? 'selected' : ''}>Dourado</option>
            </select>
          </div>
          <div class="form-row">
            <label>Vídeo / imagem (loop)</label>
            <select id="le-bg-media">
              ${mediaBackgroundOptionsHtml(this.mediaList, st.backgroundMediaId)}
            </select>
          </div>
        </div>
        <p class="form-hint">Fundos do sistema e da aba Mídia. Vídeos em loop atrás da letra (formato SOMOSUM MP4/WebP). Gradiente desativa a mídia.</p>
        <h3 style="color:var(--color-gold);font-size:.9rem">Formatação na Projeção</h3>
        <div class="font-toolbar">
          <div class="font-toolbar-group">
            <span class="font-toolbar-label">Tamanho</span>
            <button type="button" class="btn btn-secondary btn-icon font-size-btn" id="le-font-minus" title="Diminuir">A−</button>
            <span class="font-size-readout" id="le-font-readout">${st.fontSize ?? '54'}</span>
            <button type="button" class="btn btn-secondary btn-icon font-size-btn" id="le-font-plus" title="Aumentar">A+</button>
          </div>
          <div class="font-toolbar-group">
            <span class="font-toolbar-label">Fonte</span>
            <select id="le-fontFamily" class="font-select">
              ${this.callbacks.fontOptionsHtml?.(st.fontFamily || '') || '<option value="">Padrão do sistema</option>'}
            </select>
          </div>
          <div class="font-toolbar-group">
            <span class="font-toolbar-label">Texto</span>
            <select id="le-textTransform">
              <option value="none" ${(st.textTransform || 'none') === 'none' ? 'selected' : ''}>Normal</option>
              <option value="uppercase" ${st.textTransform === 'uppercase' ? 'selected' : ''}>MAIÚSCULAS</option>
              <option value="lowercase" ${st.textTransform === 'lowercase' ? 'selected' : ''}>minúsculas</option>
              <option value="capitalize" ${st.textTransform === 'capitalize' ? 'selected' : ''}>Primeira Maiúscula</option>
            </select>
          </div>
        </div>
        <div class="form-row-2">
          <div class="form-row">
            <label>Tamanho da fonte (px)</label>
            <input type="number" id="le-fontSize" min="20" max="120" value="${st.fontSize ?? ''}" placeholder="Padrão global" />
          </div>
          <div class="form-row">
            <label>Altura de linha</label>
            <input type="number" id="le-lineHeight" min="1" max="2.5" step="0.05" value="${st.lineHeight ?? ''}" placeholder="1.45" />
          </div>
        </div>
        <div class="form-row-2">
          <div class="form-row">
            <label>Alinhamento</label>
            <select id="le-align">
              <option value="" ${!st.align ? 'selected' : ''}>Padrão (centro)</option>
              <option value="center" ${st.align === 'center' ? 'selected' : ''}>Centro</option>
              <option value="left" ${st.align === 'left' ? 'selected' : ''}>Esquerda</option>
            </select>
          </div>
          <div class="form-row">
            <label>Modo de slide</label>
            <select id="le-splitMode">
              <option value="" ${!st.splitMode ? 'selected' : ''}>Padrão (estrofe)</option>
              <option value="stanza" ${st.splitMode === 'stanza' ? 'selected' : ''}>Por estrofe</option>
              <option value="stanzas" ${st.splitMode === 'stanzas' ? 'selected' : ''}>N estrofes por slide</option>
              <option value="line" ${st.splitMode === 'line' ? 'selected' : ''}>Por linha</option>
              <option value="lines" ${st.splitMode === 'lines' ? 'selected' : ''}>N linhas por slide</option>
            </select>
          </div>
        </div>
        <div class="form-row-2">
          <div class="form-row">
            <label>Linhas por slide</label>
            <input type="number" id="le-linesPerSlide" min="1" max="12" value="${st.linesPerSlide ?? ''}" placeholder="4" />
          </div>
          <div class="form-row">
            <label>Estrofes por slide</label>
            <input type="number" id="le-stanzasPerSlide" min="1" max="6" value="${st.stanzasPerSlide ?? ''}" placeholder="1" />
          </div>
        </div>
        <div class="form-row">
          <label>Margens (%)</label>
          <div class="form-row-4">
            <input type="number" id="le-marginTop" min="0" max="30" value="${st.marginTop ?? ''}" placeholder="Sup" title="Superior" />
            <input type="number" id="le-marginBottom" min="0" max="30" value="${st.marginBottom ?? ''}" placeholder="Inf" title="Inferior" />
            <input type="number" id="le-marginLeft" min="0" max="30" value="${st.marginLeft ?? ''}" placeholder="Esq" title="Esquerda" />
            <input type="number" id="le-marginRight" min="0" max="30" value="${st.marginRight ?? ''}" placeholder="Dir" title="Direita" />
          </div>
        </div>
        <div class="form-row">
          <label><input type="checkbox" id="le-highlightLine" ${st.highlightLine ? 'checked' : ''} /> Destacar linha atual (modo linha)</label>
        </div>
        <p style="font-size:.8rem;color:var(--color-muted)">
          Estrofes detectadas: <strong id="le-stanza-count">0</strong> |
          Slides gerados: <strong id="le-slide-count">0</strong>
        </p>
      </div>`;

    editor.querySelector('#le-title').oninput = (e) => this.updateDraft('title', e.target.value);
    editor.querySelector('#le-artist').oninput = (e) => this.updateDraft('artist', e.target.value);
    editor.querySelector('#le-lyrics').oninput = (e) => this.updateDraft('lyrics', e.target.value);
    editor.querySelector('#le-paste').onclick = () => this.pasteLyrics();
    editor.querySelector('#le-save').onclick = () => this.saveDraft();
    editor.querySelector('#le-delete')?.addEventListener('click', () => this.remove(this.selectedId));

    const styleFields = [
      ['le-fontSize', 'style.fontSize', (v) => (v ? Number(v) : undefined)],
      ['le-lineHeight', 'style.lineHeight', (v) => (v ? Number(v) : undefined)],
      ['le-align', 'style.align', (v) => v || undefined],
      ['le-splitMode', 'style.splitMode', (v) => v || undefined],
      ['le-linesPerSlide', 'style.linesPerSlide', (v) => (v ? Number(v) : undefined)],
      ['le-stanzasPerSlide', 'style.stanzasPerSlide', (v) => (v ? Number(v) : undefined)],
      ['le-marginTop', 'style.marginTop', (v) => (v !== '' ? Number(v) : undefined)],
      ['le-marginBottom', 'style.marginBottom', (v) => (v !== '' ? Number(v) : undefined)],
      ['le-marginLeft', 'style.marginLeft', (v) => (v !== '' ? Number(v) : undefined)],
      ['le-marginRight', 'style.marginRight', (v) => (v !== '' ? Number(v) : undefined)],
    ];

    const activePreset = this.getActivePreset();
    editor.querySelectorAll('.slide-preset-btn').forEach((btn) => {
      btn.classList.toggle('is-active', btn.dataset.preset === activePreset);
      btn.onclick = () => {
        const [mode, count] = btn.dataset.preset.split('-');
        const n = Number(count);
        if (mode === 'lines') this.applySlidePreset('lines', n);
        else if (mode === 'stanzas') this.applySlidePreset('stanzas', n);
        else this.applySlidePreset('stanza', 1);
      };
    });

    styleFields.forEach(([id, field, transform]) => {
      const el = editor.querySelector(`#${id}`);
      if (!el) return;
      const isSplitField = ['le-splitMode', 'le-linesPerSlide', 'le-stanzasPerSlide'].includes(id);
      if (isSplitField) {
        el.onchange = () => {
          if (!this.draft) return;
          const key = field.slice(6);
          this.draft.style = { ...this.draft.style, [key]: transform(el.value) };
          if (this.draft.lyrics?.trim()) {
            const prefs = getPrefs();
            const resolved = getLyricsStyle(this.draft, prefs.globalLyricsStyle);
            this.draft.lyrics = formatLyricsForSlides(this.draft.lyrics, resolved);
          }
          this.renderEditor();
          this.renderPreview();
          this.scheduleStyleSync();
        };
      } else {
        el.oninput = () => this.updateDraft(field, transform(el.value));
        el.onchange = () => this.updateDraft(field, transform(el.value));
      }
    });

    editor.querySelector('#le-highlightLine').onchange = (e) =>
      this.updateDraft('style.highlightLine', e.target.checked);

    editor.querySelector('#le-font-minus')?.addEventListener('click', () => this.bumpFontSize(-4));
    editor.querySelector('#le-font-plus')?.addEventListener('click', () => this.bumpFontSize(4));
    editor.querySelector('#le-fontFamily')?.addEventListener('change', (e) =>
      this.updateDraft('style.fontFamily', e.target.value || null)
    );
    editor.querySelector('#le-textTransform')?.addEventListener('change', (e) =>
      this.updateDraft('style.textTransform', e.target.value)
    );

    editor.querySelector('#le-bg-preset')?.addEventListener('change', (e) => {
      if (!this.draft) return;
      this.draft.style = {
        ...this.draft.style,
        backgroundPreset: e.target.value,
        backgroundMediaId: null,
      };
      this.renderEditor();
      this.renderPreview();
      this.scheduleStyleSync();
    });
    editor.querySelector('#le-bg-media')?.addEventListener('change', (e) => {
      if (!this.draft) return;
      this.draft.style = {
        ...this.draft.style,
        backgroundMediaId: e.target.value || null,
      };
      this.renderEditor();
      this.renderPreview();
      this.scheduleStyleSync();
    });

    const { stanzas } = parseLyrics(d.lyrics);
    const prefs = getPrefs();
    const style = getLyricsStyle(d, prefs.globalLyricsStyle);
    const lyricSlideCount = d.lyrics?.trim() ? splitLyricsIntoSlides(d.lyrics, style).length : 1;
    editor.querySelector('#le-stanza-count').textContent = stanzas.length;
    editor.querySelector('#le-slide-count').textContent = lyricSlideCount + 1;
  }

  async renderPreview() {
    const panel = this.container.querySelector('#lyrics-preview-panel');
    if (!panel) return;

    if (!this.draft) {
      panel.innerHTML = '<div class="empty-state">Selecione ou crie uma música.</div>';
      return;
    }

    const prefs = getPrefs();
    const slides = await this.getPreviewSlides();

    panel.innerHTML = `
      <p style="font-size:.85rem;color:var(--color-muted);margin-bottom:.5rem" id="lyrics-preview-label">
        Preview — capa (slide 1)
      </p>
      <div class="lyrics-preview-box" id="lyrics-preview-box"></div>
      <div style="margin-top:.75rem;display:flex;gap:.35rem;flex-wrap:wrap" id="slide-nav"></div>`;

    const box = panel.querySelector('#lyrics-preview-box');
    const label = panel.querySelector('#lyrics-preview-label');
    let idx = 0;

    const show = (i) => {
      idx = i;
      const slide = slides[i];
      if (!slide || !box) return;
      const isTitle = slide.type === 'lyrics-title';
      label.textContent = isTitle
        ? `Preview — capa · slide ${i + 1} de ${slides.length}`
        : `Preview — letra · slide ${i + 1} de ${slides.length}`;
      box.innerHTML = `<div class="lyrics-preview-scaler preview-scaler">${renderPreview(slide, {}, prefs)}</div>`;
      const scaler = box.querySelector('.lyrics-preview-scaler');
      if (box._previewFitDispose) {
        try { box._previewFitDispose(); } catch { /* ignore */ }
      }
      box._previewFitDispose = observeStagePreviewFit(box, scaler);
      scaler?.querySelectorAll('video').forEach((v) => v.play()?.catch(() => {}));
    };

    show(0);

    const nav = panel.querySelector('#slide-nav');
    nav.innerHTML = slides
      .map((s, i) => {
        const lbl = s.type === 'lyrics-title' ? faIconRaw('music', 'su-fa su-fa--sm') : i;
        return `<button type="button" class="btn btn-secondary btn-icon slide-nav-btn ${i === 0 ? 'is-active' : ''}" data-i="${i}">${lbl}</button>`;
      })
      .join('');
    nav.querySelectorAll('.slide-nav-btn').forEach((btn) => {
      btn.onclick = () => {
        nav.querySelectorAll('.slide-nav-btn').forEach((b) => b.classList.remove('is-active'));
        btn.classList.add('is-active');
        show(Number(btn.dataset.i));
      };
    });
  }

  getSongs() {
    return this.songs;
  }
}

function esc(text) {
  const d = document.createElement('div');
  d.textContent = text ?? '';
  return d.innerHTML;
}

function escAttr(text) {
  return esc(text).replace(/"/g, '&quot;');
}
