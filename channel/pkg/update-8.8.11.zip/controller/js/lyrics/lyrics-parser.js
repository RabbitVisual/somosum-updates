import {
  isSectionMarkerLine,
  stripSectionMarkerLines,
} from '../worship/lyrics-engine/lyrics-projection-text.js';

export { isSectionMarkerLine, stripSectionMarkerLines };

export function parseLyrics(rawText) {
  if (!rawText) return { stanzas: [], lines: [] };

  const normalized = stripSectionMarkerLines(rawText.replace(/\r\n/g, '\n').trim());
  const stanzas = normalized
    .split(/\n\s*\n/)
    .map((block) =>
      block
        .split('\n')
        .map((l) => l.trim())
        .filter((l) => l && !isSectionMarkerLine(l))
    )
    .filter((s) => s.length > 0);

  const lines = stanzas.flat();
  return { stanzas, lines };
}

export function cleanPastedLyrics(text) {
  return stripSectionMarkerLines(
    text
      .replace(/\r\n/g, '\n')
      .replace(/^\d+\.\s*/gm, '')
      .replace(/\t/g, ' ')
      .replace(/[ ]{2,}/g, ' ')
      .trim()
  );
}
