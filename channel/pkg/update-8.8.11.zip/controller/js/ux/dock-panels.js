/** Dock panels redimensionáveis com persistência em prefs.layout */
import { getPrefs, savePrefsLocal } from '../core/store.js';

function persistLayout(partial) {
  const layout = { ...(getPrefs().layout || {}), ...partial };
  savePrefsLocal({ layout });
}

export function initDockPanels() {
  const sidebar = document.getElementById('sidebar');
  const dock = document.getElementById('live-preview-dock');

  const wireResize = (panel, edge, onWidth) => {
    if (!panel || panel.querySelector('.dock-resize-handle')) return;
    const handle = document.createElement('div');
    handle.className = 'dock-resize-handle';
    handle.setAttribute('aria-hidden', 'true');
    if (edge === 'right') handle.style.cssText = 'position:absolute;top:0;right:0;width:4px;height:100%;cursor:ew-resize;z-index:5';
    else handle.style.cssText = 'position:absolute;top:0;left:0;width:4px;height:100%;cursor:ew-resize;z-index:5';
    panel.style.position = panel.style.position || 'relative';
    panel.appendChild(handle);
    let startX = 0;
    let startW = 0;
    handle.addEventListener('mousedown', (e) => {
      e.preventDefault();
      startX = e.clientX;
      startW = panel.offsetWidth;
      const onMove = (ev) => {
        const dw = edge === 'right' ? ev.clientX - startX : startX - ev.clientX;
        const w = Math.max(140, Math.min(480, startW + dw));
        onWidth(w);
      };
      const onUp = () => {
        document.removeEventListener('mousemove', onMove);
        document.removeEventListener('mouseup', onUp);
      };
      document.addEventListener('mousemove', onMove);
      document.addEventListener('mouseup', onUp);
    });
  };

  if (sidebar) {
    wireResize(sidebar, 'right', (w) => {
      sidebar.style.width = `${w}px`;
      persistLayout({ sidebarWidth: w });
    });
  }
  if (dock) {
    wireResize(dock, 'left', (w) => {
      dock.style.flexBasis = `${w}px`;
      dock.style.width = `${w}px`;
      persistLayout({ dockWidth: w });
    });
  }

  document.querySelectorAll('[data-dock]:not(#sidebar):not(#live-preview-dock)').forEach((panel) => {
    if (panel.querySelector('.dock-resize-handle')) return;
    const handle = document.createElement('div');
    handle.className = 'dock-resize-handle';
    panel.appendChild(handle);
    let startX = 0;
    let startW = 0;
    handle.addEventListener('mousedown', (e) => {
      startX = e.clientX;
      startW = panel.offsetWidth;
      const onMove = (ev) => {
        const dw = ev.clientX - startX;
        panel.style.width = `${Math.max(200, startW + dw)}px`;
      };
      const onUp = () => {
        document.removeEventListener('mousemove', onMove);
        document.removeEventListener('mouseup', onUp);
      };
      document.addEventListener('mousemove', onMove);
      document.addEventListener('mouseup', onUp);
    });
  });
}
