const COMMANDS = [];
let _paletteApp = null;

export function registerCommand({ id, label, keywords = [], run }) {
  const existing = COMMANDS.findIndex((c) => c.id === id);
  if (existing >= 0) COMMANDS.splice(existing, 1);
  COMMANDS.push({ id, label, keywords, run });
}

function dynamicSearchResults(q, app) {
  if (!app || !q || q.length < 2) return [];
  const qq = q.toLowerCase().trim();
  const out = [];
  try {
    const { searchWorship } = requireWorshipSearch();
    if (searchWorship) {
      searchWorship(qq, { tab: 'all' }).slice(0, 6).forEach((song) => {
        out.push({
          id: `song:${song.id}`,
          label: `Louvor: ${song.title}`,
          keywords: [song.title, song.author, 'musica', 'louvor'],
          run: async () => {
            app.setView?.('live');
            await app.openLiveSong?.(song.id, true);
          },
        });
      });
    }
  } catch { /* worship index may not be ready */ }

  (app.program?.items || []).forEach((item, idx) => {
    const title = item.title || item.slideType || '';
    if (!title.toLowerCase().includes(qq)) return;
    out.push({
      id: `ordem:${idx}`,
      label: `Ordem #${idx + 1}: ${title}`,
      keywords: [title, 'ordem', 'programa'],
      run: () => {
        app.setView?.('live');
        app.goToItem?.(idx);
        app.clearMediaOnAir?.();
        app.pushToProjector?.(true);
      },
    });
  });
  return out.slice(0, 8);
}

function requireWorshipSearch() {
  if (typeof window !== 'undefined' && window.__SOMOSUM_WORSHIP_SEARCH__) {
    return window.__SOMOSUM_WORSHIP_SEARCH__;
  }
  return {};
}

export function openCommandPalette(onSelect, app) {
  _paletteApp = app || _paletteApp;
  let overlay = document.getElementById('somosum-cmd-palette');
  if (overlay) { overlay.remove(); return; }
  overlay = document.createElement('div');
  overlay.id = 'somosum-cmd-palette';
  overlay.className = 'su-cmd-palette somosum-cmd-palette';
  overlay.innerHTML = `
    <div class="su-cmd-panel somosum-cmd-panel" role="dialog" aria-label="Paleta de comandos">
      <input type="search" id="somosum-cmd-input" class="su-focus" placeholder="Buscar louvor, ordem ou comando… (Ctrl+K)" autocomplete="off" />
      <ul id="somosum-cmd-list" role="listbox"></ul>
    </div>`;
  document.body.appendChild(overlay);
  const input = overlay.querySelector('#somosum-cmd-input');
  const list = overlay.querySelector('#somosum-cmd-list');
  let active = 0;
  let lastMatches = [];

  const render = (q = '') => {
    const qq = q.toLowerCase().trim();
    const staticMatches = COMMANDS.filter((c) =>
      !qq
      || c.label.toLowerCase().includes(qq)
      || c.keywords.some((k) => String(k).toLowerCase().includes(qq))
    );
    const dynamic = dynamicSearchResults(q, _paletteApp);
    const seen = new Set();
    const matches = [...dynamic, ...staticMatches].filter((c) => {
      if (seen.has(c.id)) return false;
      seen.add(c.id);
      return true;
    }).slice(0, 20);
    active = 0;
    list.innerHTML = matches.map((c, i) =>
      `<li role="option" data-cmd="${c.id}" class="${i === 0 ? 'is-active' : ''}">${c.label}</li>`
    ).join('') || '<li class="is-empty">Nenhum resultado</li>';
    lastMatches = matches;
    return matches;
  };

  render();
  input.focus();
  input.addEventListener('input', () => { render(input.value); });

  const runAt = (id) => {
    const cmd = lastMatches.find((c) => c.id === id) || COMMANDS.find((c) => c.id === id);
    if (cmd) { cmd.run(); onSelect?.(cmd); overlay.remove(); }
  };

  list.addEventListener('click', (e) => {
    const id = e.target.closest('[data-cmd]')?.dataset?.cmd;
    if (id) runAt(id);
  });
  overlay.addEventListener('click', (e) => { if (e.target === overlay) overlay.remove(); });
  input.addEventListener('keydown', (e) => {
    const items = [...list.querySelectorAll('[data-cmd]')];
    if (e.key === 'Escape') { overlay.remove(); return; }
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      active = Math.min(items.length - 1, active + 1);
      items.forEach((li, i) => li.classList.toggle('is-active', i === active));
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      active = Math.max(0, active - 1);
      items.forEach((li, i) => li.classList.toggle('is-active', i === active));
    } else if (e.key === 'Enter') {
      e.preventDefault();
      const id = items[active]?.dataset?.cmd || lastMatches[0]?.id;
      if (id) runAt(id);
    }
  });
}

export function wireCommandPalette(app) {
  _paletteApp = app;

  void import('../worship/worship-store.js').then((mod) => {
    window.__SOMOSUM_WORSHIP_SEARCH__ = { searchWorship: mod.searchWorship };
  }).catch(() => {});

  const go = (view) => () => app.setView?.(view);
  registerCommand({ id: 'goto-live', label: 'Ir para Console ao vivo', keywords: ['ao vivo', 'console', 'live', 'programa'], run: go('live') });
  registerCommand({ id: 'goto-cultos', label: 'Ir para Cultos', keywords: ['calendario', 'culto'], run: go('cultos') });
  registerCommand({ id: 'goto-designer', label: 'Ir para Designer', keywords: ['slide', 'konva'], run: go('designer') });
  registerCommand({ id: 'goto-settings', label: 'Abrir Ajustes', keywords: ['config', 'backup'], run: go('settings') });
  registerCommand({
    id: 'plugin-hub',
    label: 'Configurar plugins do culto',
    keywords: ['plugin', 'plugins', 'pix', 'extensao', 'hub'],
    run: () => {
      void import('../plugins/plugin-hub.js').then(({ openPluginHub }) => openPluginHub(app));
    },
  });
  registerCommand({
    id: 'goto-plugins-settings',
    label: 'Ajustes → Plugins',
    keywords: ['plugin', 'ajustes', 'instalar'],
    run: () => {
      app.setView?.('settings');
      try { location.hash = 'settings-plugins'; } catch { /* */ }
    },
  });
  registerCommand({ id: 'blank', label: 'Tela preta', keywords: ['blank', 'preto'], run: () => app.broadcastOverlay?.('blank') });
  registerCommand({ id: 'logo', label: 'Exibir logo', keywords: ['logo'], run: () => app.broadcastOverlay?.('logo') });
  registerCommand({ id: 'clear-overlay', label: 'Limpar overlay', keywords: ['clear', 'limpar'], run: () => app.broadcastOverlay?.('clear') });
  registerCommand({ id: 'project', label: 'Projetar slide atual', keywords: ['projetar', 'ao vivo', 'live'], run: () => app.pushToProjector?.(true) });
  registerCommand({ id: 'prev', label: 'Slide anterior', keywords: ['anterior', 'prev'], run: () => app.prevSlide?.() || app.navigate?.('prev') });
  registerCommand({ id: 'next', label: 'Próximo slide', keywords: ['proximo', 'next'], run: () => app.nextSlide?.() || app.navigate?.('next') });
  registerCommand({
    id: 'macro-record',
    label: 'Gravar macro',
    keywords: ['macro', 'gravar', 'recorder'],
    run: async () => {
      const { startRecording } = await import('./macro-recorder.js');
      startRecording();
      app.toast?.('Gravando macro — use next/blank/logo…', 'info');
    },
  });
  registerCommand({
    id: 'macro-stop-save',
    label: 'Parar e salvar macro',
    keywords: ['macro', 'salvar'],
    run: async () => {
      const { stopRecording, saveNamedMacro } = await import('./macro-recorder.js');
      const steps = stopRecording();
      const name = window.prompt('Nome da macro', `macro-${Date.now()}`) || `macro-${Date.now()}`;
      await saveNamedMacro(name, steps);
      app.toast?.(`Macro “${name}” salva (${steps.length} passos)`, 'success');
    },
  });
  registerCommand({
    id: 'macro-play',
    label: 'Reproduzir macro…',
    keywords: ['macro', 'play', 'rodar'],
    run: async () => {
      const { listMacros, playMacro } = await import('./macro-recorder.js');
      const macros = await listMacros();
      const names = Object.keys(macros);
      if (!names.length) {
        app.toast?.('Nenhuma macro salva', 'warn');
        return;
      }
      const name = window.prompt(`Macro:\n${names.join('\n')}`, names[0]);
      if (!name || !macros[name]) return;
      await playMacro(name, (step) => {
        const a = step.action;
        if (a === 'next') app.nextSlide?.() || app.navigate?.('next');
        else if (a === 'prev') app.prevSlide?.() || app.navigate?.('prev');
        else if (a === 'blank') app.broadcastOverlay?.('blank');
        else if (a === 'logo') app.broadcastOverlay?.('logo');
        else if (a === 'clearOverlay') app.broadcastOverlay?.('clear');
        else if (a === 'countdown' || a === 'timer') app.toggleCountdownLive?.();
        else if (a === 'goToItem') app.goToItem?.(step.extra?.itemIndex);
      });
      app.toast?.(`Macro “${name}” executada`, 'success');
    },
  });
  registerCommand({
    id: 'backup-now',
    label: 'Backup agora',
    keywords: ['backup', 'salvar'],
    run: async () => {
      try {
        await fetch('/api/backup/incremental', { method: 'POST' });
        app.toast?.('Backup incremental criado', 'success');
      } catch {
        app.toast?.('Falha no backup', 'warn');
      }
    },
  });

  document.addEventListener('keydown', (e) => {
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
      e.preventDefault();
      openCommandPalette(undefined, app);
    }
  });
}
