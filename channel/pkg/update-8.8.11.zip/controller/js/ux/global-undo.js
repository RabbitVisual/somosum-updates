/**
 * Undo/Redo global da ordem de culto (U1-C).
 * Usa HistoryStack; sobrevive troca de aba; limpa ao trocar culto.
 */
import { HistoryStack } from '../core/history-stack.js';

function snapshotOf(app) {
  const items = app?.program?.items;
  if (!Array.isArray(items)) return null;
  return {
    items: typeof structuredClone === 'function'
      ? structuredClone(items)
      : JSON.parse(JSON.stringify(items)),
    currentIndex: Number(app.program?.currentIndex) || 0,
  };
}

function snapshotsEqual(a, b) {
  if (!a || !b) return false;
  if (a.currentIndex !== b.currentIndex) return false;
  try {
    return JSON.stringify(a.items) === JSON.stringify(b.items);
  } catch {
    return false;
  }
}

function isEditableTarget(el) {
  if (!el) return false;
  const tag = el.tagName?.toLowerCase();
  if (tag === 'input' || tag === 'textarea' || tag === 'select') return true;
  if (el.isContentEditable) return true;
  return !!el.closest?.('[contenteditable="true"], .su-cmd-palette, #somosum-quick-search');
}

export function createProgramHistory(app, { limit = 50 } = {}) {
  const history = new HistoryStack(limit);
  let applying = false;
  let seeded = false;

  const api = {
    history,
    canUndo: () => history.canUndo(),
    canRedo: () => history.canRedo(),

    seed() {
      const snap = snapshotOf(app);
      if (!snap) return;
      history.clear();
      history.push(snap);
      seeded = true;
    },

    clear() {
      history.clear();
      seeded = false;
    },

    record() {
      if (applying) return;
      const snap = snapshotOf(app);
      if (!snap) return;
      if (!seeded) {
        history.clear();
        history.push(snap);
        seeded = true;
        return;
      }
      const tip = history.stack[history.index];
      if (snapshotsEqual(tip, snap)) return;
      history.push(snap);
    },

    async apply(snap) {
      if (!snap || !app?.program) return;
      applying = true;
      try {
        app.program.setItems(
          typeof structuredClone === 'function'
            ? structuredClone(snap.items)
            : JSON.parse(JSON.stringify(snap.items)),
          { resetNav: false },
        );
        app.program.clearSongCache?.();
        await app.program.rebuild?.();
        const idx = Math.max(0, Math.min(snap.currentIndex, app.program.items.length - 1));
        if (app.program.items[idx]) app.program.goToItem(idx);
        app.markProgramDirty?.();
        if (app.view === 'program') {
          app.refreshProgramUI?.({ parts: { banner: true, rundown: true, stage: true, inspector: true } });
        }
        app.syncProjectorState?.(false, { skipInspector: true });
      } finally {
        applying = false;
      }
    },

    async undo() {
      const snap = history.undo();
      if (!snap) return false;
      await api.apply(snap);
      app.toast?.('Desfeito', 'info');
      return true;
    },

    async redo() {
      const snap = history.redo();
      if (!snap) return false;
      await api.apply(snap);
      app.toast?.('Refeito', 'info');
      return true;
    },
  };

  return api;
}

export function wireGlobalUndo(app) {
  if (!app) return () => {};
  if (!app.programHistory) {
    app.programHistory = createProgramHistory(app);
    app.programHistory.seed();
  }

  const onKey = (e) => {
    if (!(e.ctrlKey || e.metaKey) || e.altKey) return;
    if (isEditableTarget(e.target)) return;
    if (app.view === 'designer') return;
    const key = e.key?.toLowerCase();
    if (key === 'z' && !e.shiftKey) {
      e.preventDefault();
      void app.programHistory.undo();
    } else if (key === 'y' || (key === 'z' && e.shiftKey)) {
      e.preventDefault();
      void app.programHistory.redo();
    }
  };

  window.addEventListener('keydown', onKey);
  return () => window.removeEventListener('keydown', onKey);
}
