/**
 * Macro recorder — grava ações do culto e persiste (U2-D).
 * Formato compartilhado com remote-pro: { [name]: [{ action, extra? }] }
 */
import { DiskAdapter } from '../core/storage/adapters/disk-adapter.js';

const MACROS_PATH = 'macros.json';
const LS_KEY = 'somosum-macros';
const RECORDABLE = new Set([
  'next', 'prev', 'blank', 'logo', 'clearOverlay', 'countdown', 'goToItem', 'first', 'last', 'timer',
]);

let recording = false;
/** @type {{ action: string, extra?: object }[]} */
let buffer = [];
/** @type {Record<string, { action: string, extra?: object }[]>} */
let cache = null;

function canUseDisk() {
  try {
    return typeof location !== 'undefined' && location.protocol !== 'file:';
  } catch {
    return false;
  }
}

async function ensureLoaded() {
  if (cache) return cache;
  if (canUseDisk()) {
    try {
      const disk = await DiskAdapter.load(MACROS_PATH);
      if (disk && typeof disk === 'object') {
        cache = disk;
        return cache;
      }
    } catch { /* ignore */ }
  }
  try {
    if (typeof localStorage !== 'undefined') {
      cache = JSON.parse(localStorage.getItem(LS_KEY) || '{}');
    } else {
      cache = {};
    }
  } catch {
    cache = {};
  }
  return cache;
}

function persist() {
  if (!cache) return;
  try {
    if (typeof localStorage !== 'undefined') localStorage.setItem(LS_KEY, JSON.stringify(cache));
  } catch { /* */ }
  if (canUseDisk()) {
    try { DiskAdapter.saveDebounced(MACROS_PATH, cache); } catch { /* */ }
  }
}

export function isRecording() {
  return recording;
}

export function startRecording() {
  recording = true;
  buffer = [];
  return true;
}

export function recordAction(action, extra = {}) {
  if (!recording) return false;
  const a = typeof action === 'string' ? action : action?.action;
  if (!a || !RECORDABLE.has(a)) return false;
  const step = { action: a };
  if (extra && Object.keys(extra).length) step.extra = { ...extra };
  buffer.push(step);
  return true;
}

export function stopRecording() {
  recording = false;
  const steps = buffer.slice();
  buffer = [];
  return steps;
}

export function getRecordingBuffer() {
  return buffer.slice();
}

export async function listMacros() {
  await ensureLoaded();
  return { ...cache };
}

export async function saveNamedMacro(name, steps) {
  if (!name || !Array.isArray(steps)) return false;
  await ensureLoaded();
  cache[name] = steps.map((s) => (
    typeof s === 'string' ? { action: s } : { action: s.action, ...(s.extra ? { extra: s.extra } : {}) }
  ));
  persist();
  return true;
}

export async function deleteMacro(name) {
  await ensureLoaded();
  delete cache[name];
  persist();
}

export async function playMacro(name, exec) {
  await ensureLoaded();
  const steps = cache[name];
  if (!steps?.length || typeof exec !== 'function') return false;
  for (const step of steps) {
    // eslint-disable-next-line no-await-in-loop
    await exec(step);
    // eslint-disable-next-line no-await-in-loop
    await new Promise((r) => setTimeout(r, 120));
  }
  return true;
}

export { RECORDABLE, MACROS_PATH };
