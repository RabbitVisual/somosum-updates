/**
 * Quick Search universal (U1-B) — Ctrl+Shift+F.
 * Busca offline em músicas, cultos, bíblia, mídia e itens do programa.
 */
import { hinarioRefsToSearchText } from '../worship/hinario-catalog.js';
import { rankFuzzy } from './fuzzy.js';
import { searchWorship } from '../worship/worship-store.js';
import { listCultos } from '../program/culto-manager.js';
import { getAllMedia } from '../core/store.js';

const TYPE_LABEL = {
  song: 'Música',
  culto: 'Culto',
  bible: 'Bíblia',
  media: 'Mídia',
  program: 'Programa',
};

function esc(s) {
  return String(s || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

async function buildResults(app, query) {
  const q = String(query || '').trim();
  if (q.length < 1) return [];
  const candidates = [];

  try {
    const songs = await searchWorship(q, { limit: 40 });
    for (const s of songs || []) {
      candidates.push({
        type: 'song',
        label: s.title || 'Sem título',
        meta: [s.artist, s.key].filter(Boolean).join(' · '),
        haystack: [s.title, s.artist, s.composer, s.key, s.category, hinarioRefsToSearchText(s.hinarioRefs), s.lyrics].filter(Boolean).join(' '),
        item: s,
      });
    }
  } catch { /* offline miss */ }

  try {
    const cultos = await listCultos();
    for (const c of cultos || []) {
      candidates.push({
        type: 'culto',
        label: c.title || c.name || 'Culto',
        meta: [c.date, c.type].filter(Boolean).join(' · '),
        haystack: [c.title, c.name, c.date, c.type, c.theme].filter(Boolean).join(' '),
        item: c,
      });
    }
  } catch { /* */ }

  try {
    const media = await getAllMedia();
    for (const m of (media || []).slice(0, 200)) {
      candidates.push({
        type: 'media',
        label: m.name || m.id || 'Mídia',
        meta: m.category || m.kind || '',
        haystack: [m.name, m.category, m.kind, m.id].filter(Boolean).join(' '),
        item: m,
      });
    }
  } catch { /* */ }

  const items = app?.program?.items || [];
  items.forEach((it, index) => {
    candidates.push({
      type: 'program',
      label: it.title || `Item ${index + 1}`,
      meta: `${index + 1} · ${it.type || it.slideType || ''}`,
      haystack: [it.title, it.type, it.slideType, it.data?.reference].filter(Boolean).join(' '),
      item: { ...it, index },
    });
  });

  // Bíblia: busca simples por texto digitado (referência livre)
  if (q.length >= 3) {
    candidates.push({
      type: 'bible',
      label: q,
      meta: 'Abrir Bíblia / buscar referência',
      haystack: q,
      item: { ref: q, reference: q },
    });
  }

  return rankFuzzy(q, candidates, { limit: 28 });
}

async function runResult(app, row) {
  if (!row) return;
  const { type, item } = row;
  if (type === 'song') {
    app.setView?.('lyrics');
    app.openWorshipSong?.(item.id) || app.focusWorshipSong?.(item.id);
    app.toast?.(`Louvor: ${item.title}`, 'info');
    return;
  }
  if (type === 'culto') {
    app.setView?.('cultos');
    if (item.id && app.openCulto) await app.openCulto(item.id);
    else if (item.id && app.loadCulto) await app.loadCulto(item.id);
    return;
  }
  if (type === 'media') {
    app.setView?.('media');
    return;
  }
  if (type === 'program') {
    app.setView?.('live');
    const idx = item.index;
    if (Number.isFinite(idx)) {
      app.program?.goToItem?.(idx);
      app.persistNavigation?.();
      app.refreshProgramUI?.();
    }
    return;
  }
  if (type === 'bible') {
    app.setView?.('bible');
    if (item.ref || item.reference) {
      app.toast?.(`Bíblia: ${item.ref || item.reference}`, 'info');
    }
  }
}

export function openQuickSearch(app) {
  let overlay = document.getElementById('somosum-quick-search');
  if (overlay) { overlay.remove(); return; }

  overlay = document.createElement('div');
  overlay.id = 'somosum-quick-search';
  overlay.className = 'su-cmd-palette somosum-cmd-palette';
  overlay.innerHTML = `
    <div class="su-cmd-panel somosum-cmd-panel" role="dialog" aria-label="Busca rápida">
      <input type="search" id="somosum-qs-input" class="su-focus" placeholder="Buscar músicas, cultos, bíblia, mídia, ordem…" autocomplete="off" />
      <ul id="somosum-qs-list" role="listbox"></ul>
    </div>`;
  document.body.appendChild(overlay);

  const input = overlay.querySelector('#somosum-qs-input');
  const list = overlay.querySelector('#somosum-qs-list');
  let active = 0;
  let matches = [];
  let timer = null;
  let seq = 0;

  const render = (rows) => {
    matches = rows;
    active = 0;
    list.innerHTML = rows.length
      ? rows.map((r, i) => `
        <li role="option" data-idx="${i}" class="${i === 0 ? 'is-active' : ''}">
          <span class="su-cmd-badge">${esc(TYPE_LABEL[r.type] || r.type)}</span>
          <span class="su-cmd-label">${esc(r.label)}</span>
          <span class="su-cmd-meta">${esc(r.meta || '')}</span>
        </li>`).join('')
      : '<li class="is-empty">Nenhum resultado</li>';
  };

  const search = (q) => {
    clearTimeout(timer);
    timer = setTimeout(async () => {
      const my = ++seq;
      const t0 = performance.now();
      const rows = await buildResults(app, q);
      if (my !== seq) return;
      const ms = performance.now() - t0;
      if (ms > 300) console.info('[SOMOSUM] quick-search', Math.round(ms), 'ms');
      render(rows);
    }, 50);
  };

  input.focus();
  input.addEventListener('input', () => search(input.value));

  const runAt = (idx) => {
    const row = matches[idx];
    if (!row) return;
    overlay.remove();
    void runResult(app, row);
  };

  list.addEventListener('click', (e) => {
    const li = e.target.closest('[data-idx]');
    if (li) runAt(Number(li.dataset.idx));
  });
  overlay.addEventListener('click', (e) => { if (e.target === overlay) overlay.remove(); });
  input.addEventListener('keydown', (e) => {
    const items = [...list.querySelectorAll('[data-idx]')];
    if (e.key === 'Escape') { overlay.remove(); return; }
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      active = Math.min(items.length - 1, active + 1);
      items.forEach((li, i) => li.classList.toggle('is-active', i === active));
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      active = Math.max(0, active - 1);
      items.forEach((li, i) => li.classList.toggle('is-active', i === active));
    } else if (e.key === 'Enter') {
      e.preventDefault();
      runAt(active);
    }
  });
}

export function wireQuickSearch(app) {
  window.addEventListener('keydown', (e) => {
    if (!(e.ctrlKey || e.metaKey) || !e.shiftKey) return;
    if (e.code !== 'KeyF') return;
    const tag = e.target?.tagName?.toLowerCase();
    if (tag === 'input' || tag === 'textarea') return;
    e.preventDefault();
    openQuickSearch(app);
  });
}
