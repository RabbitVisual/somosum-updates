/** Fuzzy offline leve — NFD + substring/prefix + 1-edit em tokens ≥4. */

export function fold(s) {
  return String(s || '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .trim();
}

function editDistance1(a, b) {
  if (a === b) return 0;
  const la = a.length;
  const lb = b.length;
  if (Math.abs(la - lb) > 1) return 2;
  if (la > lb) return editDistance1(b, a);
  let i = 0;
  let j = 0;
  let edits = 0;
  while (i < la && j < lb) {
    if (a[i] === b[j]) {
      i += 1;
      j += 1;
      continue;
    }
    edits += 1;
    if (edits > 1) return 2;
    if (la === lb) {
      i += 1;
      j += 1;
    } else {
      j += 1;
    }
  }
  if (j < lb || i < la) edits += 1;
  return edits;
}

/**
 * Score match: higher is better. 0 = no match.
 * @param {string} query
 * @param {string} haystack
 */
export function scoreMatch(query, haystack) {
  const q = fold(query);
  const h = fold(haystack);
  if (!q || !h) return 0;
  if (h === q) return 1000;
  if (h.startsWith(q)) return 800 + Math.min(50, q.length);
  if (h.includes(q)) return 500 + Math.min(40, q.length);

  const qTokens = q.split(/\s+/).filter(Boolean);
  const hTokens = h.split(/[\s/|,;:\-_.]+/).filter(Boolean);
  if (!qTokens.length) return 0;

  let score = 0;
  let matched = 0;
  for (const qt of qTokens) {
    let best = 0;
    for (const ht of hTokens) {
      if (ht === qt) best = Math.max(best, 120);
      else if (ht.startsWith(qt)) best = Math.max(best, 90);
      else if (ht.includes(qt)) best = Math.max(best, 60);
      else if (qt.length >= 4 && ht.length >= 4 && editDistance1(qt, ht) <= 1) best = Math.max(best, 45);
    }
    if (best > 0) {
      matched += 1;
      score += best;
    }
  }
  if (matched === 0) return 0;
  if (matched < qTokens.length) score = Math.floor(score * (matched / qTokens.length));
  return score;
}

/**
 * Rank items by fuzzy score.
 * @param {string} query
 * @param {Array<{haystack:string, item:any}>} candidates
 * @param {{limit?:number}} opts
 */
export function rankFuzzy(query, candidates, { limit = 24 } = {}) {
  const scored = [];
  for (const c of candidates) {
    const s = scoreMatch(query, c.haystack);
    if (s > 0) scored.push({ score: s, item: c.item, type: c.type, label: c.label, meta: c.meta });
  }
  scored.sort((a, b) => b.score - a.score);
  return scored.slice(0, limit);
}
