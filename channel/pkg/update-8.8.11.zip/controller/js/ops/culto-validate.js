/**
 * Validação pré-culto (Low-Spec Pro / Etapa 2A) — read-only, sem sync.
 * Verifica programa, existência de mídia e fontes.
 */
import { resolveMediaSrc } from '../core/media-url.js';
import { dataPublicUrl } from '../core/data-public-url.js';

async function fetchJson(path) {
  try {
    const r = await fetch(path, { cache: 'no-store' });
    if (!r.ok) return null;
    return await r.json();
  } catch {
    return null;
  }
}

async function urlExists(url) {
  if (!url || typeof url !== 'string') return false;
  if (url.startsWith('data:')) return true;
  try {
    let r = await fetch(url, { method: 'HEAD', cache: 'no-store' });
    if (r.ok) return true;
    // Alguns hosts Kestrel não implementam HEAD — tenta GET leve
    r = await fetch(url, { method: 'GET', cache: 'no-store', headers: { Range: 'bytes=0-0' } });
    return r.ok || r.status === 206;
  } catch {
    return false;
  }
}

function collectMediaRefs(items = []) {
  const refs = [];
  for (const item of items) {
    const title = item.title || item.id || 'item';
    const ids = [
      item.mediaId,
      item.backgroundMediaId,
      item.data?.mediaId,
      item.data?.backgroundMediaId,
      item.globalLyricsStyle?.backgroundMediaId,
    ].filter(Boolean);
    for (const id of ids) {
      refs.push({ kind: 'mediaId', id: String(id), title });
    }
    const paths = [
      item.data?.audioPath,
      item.data?.bgImage,
      item.bgImage,
      item.data?.videoPath,
    ].filter(Boolean);
    for (const p of paths) {
      refs.push({ kind: 'path', path: String(p), title });
    }
  }
  return refs;
}

function structuralIssues(items = []) {
  const issues = [];
  const warnings = [];
  if (!items.length) {
    issues.push('Ordem do culto vazia');
    return { issues, warnings };
  }
  for (const item of items) {
    if (item.slideType === 'lyrics' && !item.songId) {
      issues.push(`Louvor sem música: ${item.title || '?'}`);
    }
    if (item.slideType === 'bible' && !item.bible?.book) {
      issues.push(`Leitura sem referência: ${item.title || '?'}`);
    }
    if (item.slideType === 'message' && !item.data?.preacher) {
      warnings.push('Mensagem sem pregador definido');
    }
    if (item.slideType === 'announcements') {
      const list = item.data?.items || [];
      const text = item.data?.text || '';
      if (!list.length && !String(text).trim()) warnings.push('Comunicados vazios');
    }
  }
  return { issues, warnings };
}

/** Validação síncrona de items (Worship Engine pré-live). */
export function validateCultoProgram(items = [], { mediaList = [], songs = [] } = {}) {
  const structural = structuralIssues(items);
  const issues = [...structural.issues];
  const warnings = [...structural.warnings];
  const byId = new Map((mediaList || []).map((m) => [String(m.id), m]));
  for (const ref of collectMediaRefs(items)) {
    if (ref.kind === 'mediaId' && !byId.has(ref.id)) {
      warnings.push(`Mídia não indexada (${ref.title}): ${ref.id}`);
    }
  }
  for (const item of items) {
    if (item.slideType === 'lyrics' && item.songId) {
      const song = (songs || []).find((s) => s.id === item.songId);
      if (!song) issues.push(`Música não encontrada: ${item.title || item.songId}`);
    }
  }
  return { ok: issues.length === 0, issues, warnings };
}

/**
 * @returns {Promise<{ ready: boolean, issues: string[], warnings: string[], fonts: object, mediaChecked: number }>}
 */
export async function validateCultoPackage() {
  const issues = [];
  const warnings = [];

  const program = await fetchJson('/api/data/programa.json');
  const items = Array.isArray(program?.items) ? program.items : (Array.isArray(program) ? program : []);
  const structural = structuralIssues(items);
  issues.push(...structural.issues);
  warnings.push(...structural.warnings);

  const mediaIndex = await fetchJson('/api/data/media/index.json');
  const mediaList = Array.isArray(mediaIndex?.media) ? mediaIndex.media : [];
  const byId = new Map(mediaList.map((m) => [String(m.id), m]));

  const refs = collectMediaRefs(items);
  let mediaChecked = 0;
  for (const ref of refs) {
    mediaChecked += 1;
    let url = null;
    if (ref.kind === 'mediaId') {
      const entry = byId.get(ref.id);
      if (!entry) {
        // Pode ser mídia do sistema
        url = resolveMediaSrc({ id: ref.id }) || dataPublicUrl(`media/${ref.id}`);
      } else {
        url = resolveMediaSrc(entry) || entry.path || dataPublicUrl(`media/${entry.path || entry.id}`);
      }
    } else {
      url = ref.path.startsWith('/') || ref.path.startsWith('http')
        ? ref.path
        : (resolveMediaSrc({ path: ref.path }) || `/${ref.path.replace(/^\/+/, '')}`);
    }
    const ok = await urlExists(url);
    if (!ok) {
      issues.push(`Mídia ausente (${ref.title}): ${ref.id || ref.path}`);
    }
  }

  let fonts = { count: 0, ok: false };
  try {
    const r = await fetch('/api/fonts', { cache: 'no-store' });
    if (r.ok) {
      const list = await r.json();
      const arr = Array.isArray(list) ? list : (list?.fonts || []);
      fonts = { count: arr.length, ok: arr.length > 0 };
      if (!arr.length) warnings.push('Nenhuma fonte custom em /fonts (usa fontes do sistema)');
    } else {
      warnings.push('Não foi possível listar fontes (/api/fonts)');
    }
  } catch {
    warnings.push('Falha ao verificar fontes');
  }

  return {
    ready: issues.length === 0,
    issues,
    warnings,
    fonts,
    mediaChecked,
    itemCount: items.length,
  };
}

export function formatCultoValidationReport(result) {
  const lines = [
    `Validar Culto — ${result.ready ? 'PRONTO' : 'PENDÊNCIAS'}`,
    `Itens: ${result.itemCount || 0} · Mídias checadas: ${result.mediaChecked || 0} · Fontes: ${result.fonts?.count ?? '?'}`,
    '',
  ];
  if (result.issues?.length) {
    lines.push('Problemas:');
    result.issues.forEach((i) => lines.push(`  ✗ ${i}`));
  }
  if (result.warnings?.length) {
    lines.push('Avisos:');
    result.warnings.forEach((w) => lines.push(`  ! ${w}`));
  }
  if (result.ready && !result.warnings?.length) {
    lines.push('Tudo configurado — pode iniciar o culto.');
  }
  return lines.join('\n');
}
