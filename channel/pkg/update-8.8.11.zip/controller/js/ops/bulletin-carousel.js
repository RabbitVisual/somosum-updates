/**
 * Carrossel de avisos — dois modos:
 * 1) Imagens fullscreen
 * 2) Boletim: fundo + avisos de texto (um por slide)
 * Persistência em data/avisos/index.json.
 */
import { getAllMedia, saveMediaFile } from '../core/store.js';
import { resolveMediaSrc } from '../core/media-url.js';
import { DiskAdapter } from '../core/storage/adapters/disk-adapter.js';
import { dataPublicUrl } from '../core/data-public-url.js';
import { esc, escAttr } from '../control/utils/escape.js';
import { faIcon } from '../core/fa-icons.js';

const DEFAULT_INDEX = () => ({
  mode: 'images',
  intervalSec: 8,
  images: [],
  bulletin: {
    title: 'Avisos',
    backgroundSrc: '',
    notices: [],
  },
});

export async function loadAvisosIndex() {
  try {
    const res = await fetch(dataPublicUrl('avisos/index.json'), { cache: 'no-store' });
    if (!res.ok) return DEFAULT_INDEX();
    const data = await res.json();
    return normalizeIndex(data);
  } catch {
    return DEFAULT_INDEX();
  }
}

function normalizeNotice(n = {}, i = 0) {
  return {
    id: n.id || `n-${i}-${Date.now()}`,
    text: String(n.text ?? ''),
    headline: String(n.headline ?? ''),
  };
}

function noticeHasContent(n) {
  return String(n?.text || '').trim().length > 0;
}

function normalizeIndex(data = {}, { keepEmptyNotices = true } = {}) {
  const mode = data.mode === 'bulletin' ? 'bulletin' : 'images';
  const bulletin = data.bulletin && typeof data.bulletin === 'object' ? data.bulletin : {};
  let notices = Array.isArray(bulletin.notices)
    ? bulletin.notices.map((n, i) => normalizeNotice(n, i))
    : [];
  if (!keepEmptyNotices) {
    notices = notices
      .map((n) => ({ ...n, text: n.text.trim(), headline: n.headline.trim() }))
      .filter(noticeHasContent);
  }
  return {
    mode,
    intervalSec: Math.max(3, Number(data.intervalSec) || 8),
    images: normalizeDraftImages(data.images),
    bulletin: {
      title: bulletin.title || 'Avisos',
      backgroundSrc: bulletin.backgroundSrc || '',
      notices,
    },
  };
}

export async function saveAvisosIndex(index, opts = {}) {
  const normalized = normalizeIndex(index, { keepEmptyNotices: opts.keepEmptyNotices !== false });
  const payload = {
    mode: normalized.mode,
    intervalSec: normalized.intervalSec,
    images: normalized.images,
    bulletin: {
      ...normalized.bulletin,
      notices: normalized.bulletin.notices.map((n) => ({
        id: n.id,
        text: String(n.text || ''),
        headline: String(n.headline || ''),
      })),
    },
  };
  const ok = await DiskAdapter.save('avisos/index.json', payload, { silent: opts.silent === true });
  if (!ok) throw new Error('Não foi possível salvar data/avisos/index.json');
  return payload;
}

export function buildBulletinSlides(index = {}) {
  const data = normalizeIndex(index, { keepEmptyNotices: true });
  if (data.mode === 'bulletin') {
    const bg = data.bulletin.backgroundSrc || '';
    const defaultTitle = data.bulletin.title || 'Avisos';
    const notices = (data.bulletin.notices || []).filter(noticeHasContent);
    if (!notices.length) return [];
    return notices.map((n) => ({
      type: 'announcements',
      carouselNotice: true,
      title: (n.headline || '').trim() || defaultTitle,
      items: [{ text: n.text.trim(), icon: '' }],
      backgroundSrc: bg,
      showCaption: false,
      style: {
        titleSize: 56,
        textSize: 40,
        textTransform: 'none',
        align: 'center',
      },
    }));
  }

  return (data.images || []).map((entry) => {
    const src = typeof entry === 'string' ? entry : entry.src;
    if (!src) return null;
    return {
      type: 'media',
      src,
      title: '',
      showCaption: false,
      style: { fit: 'contain', background: '#000' },
    };
  }).filter(Boolean);
}

function normalizeDraftImages(images = []) {
  return (images || []).map((entry, i) => {
    if (typeof entry === 'string') return { src: entry, title: `Aviso ${i + 1}` };
    return {
      src: entry.src,
      title: entry.title || `Aviso ${i + 1}`,
    };
  }).filter((e) => e.src);
}

function draftSlideCount(draft) {
  if (draft.mode === 'bulletin') {
    return (draft.bulletin?.notices || []).filter(noticeHasContent).length;
  }
  return (draft.images || []).length;
}

/** Mixin ControlApp */
export function wireBulletinCarousel() {
  let timer = null;
  let slides = [];
  let idx = 0;
  let running = false;

  const stopTimer = () => {
    if (timer) clearInterval(timer);
    timer = null;
    slides = [];
    idx = 0;
    running = false;
  };

  return {
    isBulletinCarouselRunning() {
      return running;
    },

    async startBulletinCarousel() {
      return this.openBulletinCarouselSetup?.();
    },

    stopBulletinCarousel({ clearScreen = true, silent = false } = {}) {
      const wasRunning = running;
      stopTimer();
      if (clearScreen) {
        this.broadcastOverlay?.('blank');
      }
      if (!silent) {
        this.toast?.(
          wasRunning ? 'Carrossel encerrado — projetor em tela preta' : 'Carrossel já estava parado',
          wasRunning ? 'success' : 'info'
        );
      }
      return wasRunning;
    },

    async _runBulletinCarousel(index) {
      stopTimer();
      const slidesBuilt = buildBulletinSlides(index);
      if (!slidesBuilt.length) {
        this.toast?.(
          index.mode === 'bulletin'
            ? 'Adicione ao menos um aviso de texto para iniciar'
            : 'Adicione ao menos uma imagem para iniciar',
          'warn'
        );
        return false;
      }
      slides = slidesBuilt;
      idx = 0;
      const ok = this.sendSlideToProjector?.(slides[0], true);
      if (ok === false) {
        this.toast?.('Não foi possível projetar — verifique pré-culto/ensaio', 'warn');
        stopTimer();
        return false;
      }
      running = true;
      const ms = Math.max(3000, (index.intervalSec || 8) * 1000);
      const app = this;
      timer = setInterval(() => {
        idx = (idx + 1) % slides.length;
        app.sendSlideToProjector?.(slides[idx], true);
      }, ms);
      this.toast?.(`Carrossel no ar · ${slides.length} slide(s)`, 'success');
      return true;
    },

    async openBulletinCarouselSetup() {
      this.closeModal?.();
      const index = await loadAvisosIndex();
      const draft = JSON.parse(JSON.stringify(index));

      const modal = document.createElement('div');
      modal.className = 'somosum-modal';
      modal.id = 'bulletin-carousel-modal';

      const persist = async (message, { silent = false, remount = false } = {}) => {
        readForm();
        syncNoticesFromDom();
        try {
          const saved = await saveAvisosIndex(draft, { silent: silent || !message });
          // Não sobrescrever o rascunho com avisos em edição a cada tecla
          if (remount) Object.assign(draft, normalizeIndex(saved, { keepEmptyNotices: true }));
          if (message) this.toast?.(message, 'success');
          return true;
        } catch (err) {
          if (!silent) this.toast?.(err.message || 'Erro ao salvar avisos', 'warn');
          return false;
        }
      };

      let quietTimer = null;
      const persistQuiet = () => {
        clearTimeout(quietTimer);
        quietTimer = setTimeout(() => {
          persist(null, { silent: true, remount: false });
        }, 500);
      };

      const readForm = () => {
        const n = Number(modal.querySelector('#bulletin-interval')?.value);
        draft.intervalSec = Number.isFinite(n) ? Math.max(3, Math.min(120, n)) : 8;
        const titleEl = modal.querySelector('#bulletin-title');
        if (titleEl) draft.bulletin.title = titleEl.value.trim() || 'Avisos';
      };

      const refreshStartButton = () => {
        const btn = modal.querySelector('#bulletin-start');
        if (!btn) return;
        const canStart = draftSlideCount(draft) > 0;
        btn.disabled = !canStart;
        btn.innerHTML = `${faIcon('play', 'su-fa su-fa--inline-btn')} ${canStart ? 'Salvar e iniciar' : 'Adicione o texto do aviso'}`;
      };

      const refreshPreviewMock = () => {
        const span = modal.querySelector('.bulletin-preview-mock-copy span');
        const p = modal.querySelector('.bulletin-preview-mock-copy p');
        if (!span || !p) return;
        const n0 = draft.bulletin.notices?.[0];
        span.textContent = (n0?.headline || '').trim() || draft.bulletin.title || 'Avisos';
        p.textContent = (n0?.text || '').trim() || 'Seu primeiro aviso aparece aqui…';
      };

      const setMode = async (mode) => {
        syncNoticesFromDom();
        readForm();
        draft.mode = mode === 'bulletin' ? 'bulletin' : 'images';
        try {
          await saveAvisosIndex(draft, { silent: true });
        } catch (err) {
          this.toast?.(err.message || 'Modo alterado só nesta sessão (falha ao salvar)', 'warn');
        }
        paint();
      };

      const statusHtml = () => {
        if (running) {
          return `<span class="bulletin-status is-live">${faIcon('live', 'su-fa su-fa--sm')} No ar · slide ${idx + 1}/${slides.length || '?'}</span>`;
        }
        return `<span class="bulletin-status is-idle">${faIcon('pause', 'su-fa su-fa--sm')} Parado</span>`;
      };

      const renderImagesList = () => {
        if (!draft.images.length) {
          return `
            <div class="bulletin-empty">
              <p class="bulletin-empty-title">Nenhuma imagem</p>
              <p class="form-hint">Monte o boletim visual com artes da biblioteca ou do computador. Cada imagem ocupa tela cheia no projetor.</p>
              <div class="bulletin-empty-actions">
                <button type="button" class="btn btn-primary" data-act="add-lib">${faIcon('media', 'su-fa su-fa--inline-btn')} Biblioteca</button>
                <button type="button" class="btn btn-secondary" data-act="add-files">${faIcon('image', 'su-fa su-fa--inline-btn')} Arquivos</button>
              </div>
            </div>`;
        }
        return `
          <ul class="bulletin-slide-list">
            ${draft.images.map((img, i) => `
              <li class="bulletin-slide-item" data-i="${i}">
                <img class="bulletin-thumb" src="${escAttr(img.src)}" alt="" loading="lazy" />
                <div class="bulletin-slide-meta">
                  <input type="text" class="bulletin-title-input" data-img-title="${i}" value="${escAttr(img.title)}" placeholder="Nome interno (não aparece na projeção)" />
                  <span class="form-hint">${esc(img.src)}</span>
                </div>
                <div class="bulletin-slide-actions">
                  <button type="button" class="btn btn-secondary btn-icon" data-img-up="${i}" title="Subir" ${i === 0 ? 'disabled' : ''}>${faIcon('arrow-up')}</button>
                  <button type="button" class="btn btn-secondary btn-icon" data-img-down="${i}" title="Descer" ${i === draft.images.length - 1 ? 'disabled' : ''}>${faIcon('arrow-down')}</button>
                  <button type="button" class="btn btn-secondary btn-icon" data-img-remove="${i}" title="Excluir (salva na hora)">${faIcon('delete')}</button>
                </div>
              </li>`).join('')}
          </ul>`;
      };

      const renderBulletinEditor = () => {
        const notices = draft.bulletin.notices || [];
        const bg = draft.bulletin.backgroundSrc || '';
        return `
          <div class="bulletin-bg-block">
            <label>Foto de fundo</label>
            <div class="bulletin-bg-row">
              ${bg
                ? `<img class="bulletin-bg-preview" src="${escAttr(bg)}" alt="" />`
                : `<div class="bulletin-bg-placeholder">${faIcon('image', 'su-fa su-fa--lg')}<span>Sem fundo</span></div>`}
              <div class="bulletin-bg-actions">
                <button type="button" class="btn btn-secondary btn-sm" data-act="bg-lib">${faIcon('media', 'su-fa su-fa--inline-btn')} Biblioteca</button>
                <button type="button" class="btn btn-secondary btn-sm" data-act="bg-file">${faIcon('image', 'su-fa su-fa--inline-btn')} Arquivo</button>
                ${bg ? `<button type="button" class="btn btn-secondary btn-sm" data-act="bg-clear">${faIcon('close', 'su-fa su-fa--inline-btn')} Remover fundo</button>` : ''}
              </div>
            </div>
            <p class="form-hint">O fundo fica atrás de todos os avisos. Cada aviso vira um slide do carrossel.</p>
          </div>
          <div class="form-block">
            <label for="bulletin-title">Título padrão na tela</label>
            <input type="text" id="bulletin-title" value="${escAttr(draft.bulletin.title || 'Avisos')}" placeholder="Ex.: Comunicados da semana" />
          </div>
          <div class="bulletin-notices-head">
            <strong>Avisos em sequência</strong>
            <button type="button" class="btn btn-primary btn-sm" data-act="add-notice">${faIcon('add', 'su-fa su-fa--inline-btn')} Novo aviso</button>
          </div>
          ${!notices.length ? `
            <div class="bulletin-empty bulletin-empty--soft">
              <p class="bulletin-empty-title">Nenhum aviso de texto</p>
              <p class="form-hint">Ex.: “Dia 17 — Café da manhã às 8h · Culto às 18h30 · Reunião de jovens às 20h”.</p>
            </div>` : `
            <ul class="bulletin-notice-list">
              ${notices.map((n, i) => `
                <li class="bulletin-notice-item" data-ni="${i}">
                  <span class="bulletin-notice-num">${i + 1}</span>
                  <div class="bulletin-notice-fields">
                    <input type="text" data-notice-headline="${i}" value="${escAttr(n.headline || '')}" placeholder="Título opcional deste slide (senão usa o título padrão)" />
                    <textarea data-notice-text="${i}" rows="3" placeholder="Texto do aviso (data, eventos, horários…)">${esc(n.text || '')}</textarea>
                  </div>
                  <div class="bulletin-slide-actions">
                    <button type="button" class="btn btn-secondary btn-icon" data-notice-up="${i}" title="Subir" ${i === 0 ? 'disabled' : ''}>${faIcon('arrow-up')}</button>
                    <button type="button" class="btn btn-secondary btn-icon" data-notice-down="${i}" title="Descer" ${i === notices.length - 1 ? 'disabled' : ''}>${faIcon('arrow-down')}</button>
                    <button type="button" class="btn btn-secondary btn-icon" data-notice-remove="${i}" title="Excluir (salva na hora)">${faIcon('delete')}</button>
                  </div>
                </li>`).join('')}
            </ul>`}
          <div class="bulletin-preview-mock" aria-hidden="true">
            <div class="bulletin-preview-mock-bg" ${bg ? `style="background-image:url('${escAttr(bg)}')"` : ''}></div>
            <div class="bulletin-preview-mock-shade"></div>
            <div class="bulletin-preview-mock-copy">
              <span>${esc((notices[0]?.headline) || draft.bulletin.title || 'Avisos')}</span>
              <p>${esc(notices[0]?.text || 'Seu primeiro aviso aparece aqui…')}</p>
            </div>
          </div>`;
      };

      const paint = ({ focusNoticeIndex = null, restoreScroll = true } = {}) => {
        const hostPrev = modal.querySelector('#bulletin-list-host');
        const scrollTop = restoreScroll ? (hostPrev?.scrollTop || 0) : 0;
        const count = draftSlideCount(draft);
        const canStart = count > 0;
        modal.innerHTML = `
          <div class="somosum-modal-backdrop" data-close></div>
          <div class="somosum-modal-card somosum-modal-card--wide bulletin-modal-card">
            <header class="bulletin-modal-head">
              <div>
                <p class="bulletin-kicker">Pré-culto · Projetor</p>
                <h3>Carrossel de avisos</h3>
                <p class="form-hint">Dois modos: só imagens, ou fundo + avisos de texto em sequência.</p>
              </div>
              ${statusHtml()}
            </header>

            <div class="bulletin-mode-tabs" role="tablist">
              <button type="button" class="bulletin-mode-tab ${draft.mode === 'images' ? 'is-active' : ''}" data-mode="images" role="tab">
                ${faIcon('image', 'su-fa su-fa--inline-btn')} Só imagens
              </button>
              <button type="button" class="bulletin-mode-tab ${draft.mode === 'bulletin' ? 'is-active' : ''}" data-mode="bulletin" role="tab">
                ${faIcon('bullhorn', 'su-fa su-fa--inline-btn')} Fundo + avisos
              </button>
            </div>

            <div class="bulletin-toolbar-row">
              <div class="form-block" style="margin:0;min-width:9rem">
                <label for="bulletin-interval">Tempo por slide (s)</label>
                <input type="number" id="bulletin-interval" min="3" max="120" value="${draft.intervalSec}" />
              </div>
              ${draft.mode === 'images' ? `
                <div class="bulletin-toolbar">
                  <button type="button" class="btn btn-secondary btn-sm" data-act="add-lib">${faIcon('media', 'su-fa su-fa--inline-btn')} Biblioteca</button>
                  <button type="button" class="btn btn-secondary btn-sm" data-act="add-files">${faIcon('image', 'su-fa su-fa--inline-btn')} Arquivos</button>
                  <input type="file" id="bulletin-file-input" accept="image/png,image/jpeg,image/webp,image/gif" multiple hidden />
                </div>` : `
                <input type="file" id="bulletin-bg-file" accept="image/png,image/jpeg,image/webp,image/gif" hidden />`}
            </div>

            <div id="bulletin-list-host" class="bulletin-list-host">
              ${draft.mode === 'bulletin' ? renderBulletinEditor() : renderImagesList()}
            </div>

            <div class="somosum-modal-actions bulletin-modal-actions">
              <button type="button" class="btn btn-secondary" data-close>Fechar</button>
              <button type="button" class="btn btn-secondary" id="bulletin-stop" ${running ? '' : 'disabled'}>
                ${faIcon('pause', 'su-fa su-fa--inline-btn')} Parar
              </button>
              <button type="button" class="btn btn-secondary" id="bulletin-clear" title="Apaga todo o carrossel do disco">
                ${faIcon('delete', 'su-fa su-fa--inline-btn')} Limpar tudo
              </button>
              <button type="button" class="btn btn-secondary" id="bulletin-save">${faIcon('save', 'su-fa su-fa--inline-btn')} Salvar</button>
              <button type="button" class="btn btn-primary" id="bulletin-start" ${canStart ? '' : 'disabled'}>
                ${faIcon('play', 'su-fa su-fa--inline-btn')} ${canStart ? 'Salvar e iniciar' : 'Adicione o texto do aviso'}
              </button>
            </div>
          </div>`;
        bind();
        const host = modal.querySelector('#bulletin-list-host');
        if (host && restoreScroll) host.scrollTop = scrollTop;
        if (focusNoticeIndex != null) {
          const headline = modal.querySelector(`[data-notice-headline="${focusNoticeIndex}"]`);
          const item = modal.querySelector(`.bulletin-notice-item[data-ni="${focusNoticeIndex}"]`);
          item?.scrollIntoView({ block: 'nearest' });
          headline?.focus({ preventScroll: true });
        }
      };

      const openLibraryPicker = async ({ forBackground = false } = {}) => {
        const media = (await getAllMedia()).filter((m) => {
          const kind = m.kind || '';
          const mime = m.mimeType || m.mime || '';
          return kind === 'image' || mime.startsWith('image/');
        });
        if (!media.length) {
          this.toast?.('Biblioteca sem imagens — envie arquivos ou vá em Mídia', 'warn');
          return;
        }
        const picker = document.createElement('div');
        picker.className = 'somosum-modal bulletin-lib-picker';
        picker.innerHTML = `
          <div class="somosum-modal-backdrop" data-lib-close></div>
          <div class="somosum-modal-card somosum-modal-card--wide">
            <h3>${forBackground ? 'Escolher fundo' : 'Escolher imagens'}</h3>
            <p class="form-hint">${forBackground ? 'Uma imagem de fundo para o boletim.' : 'Marque os avisos do carrossel.'}</p>
            <ul class="bulletin-lib-list">
              ${media.map((m) => {
                const src = resolveMediaSrc(m) || m.src || '';
                return `
                  <li>
                    <label class="bulletin-lib-item">
                      <input type="${forBackground ? 'radio' : 'checkbox'}" name="bulletin-lib" data-src="${escAttr(src)}" data-title="${escAttr(m.name || m.title || 'Aviso')}" />
                      <img src="${escAttr(src)}" alt="" loading="lazy" />
                      <span>${esc(m.name || m.title || m.id)}</span>
                    </label>
                  </li>`;
              }).join('')}
            </ul>
            <div class="somosum-modal-actions">
              <button type="button" class="btn btn-secondary" data-lib-close>Cancelar</button>
              <button type="button" class="btn btn-primary" id="bulletin-lib-confirm">Confirmar</button>
            </div>
          </div>`;
        document.body.appendChild(picker);
        const closePicker = () => picker.remove();
        picker.querySelectorAll('[data-lib-close]').forEach((el) => {
          el.addEventListener('click', closePicker);
        });
        picker.querySelector('#bulletin-lib-confirm')?.addEventListener('click', async () => {
          if (forBackground) {
            const cb = picker.querySelector('input[type=radio]:checked');
            const src = cb?.getAttribute('data-src');
            if (src) {
              draft.bulletin.backgroundSrc = src;
              await persist('Fundo atualizado');
            }
          } else {
            picker.querySelectorAll('input[type=checkbox]:checked').forEach((cb) => {
              const src = cb.getAttribute('data-src');
              if (!src || draft.images.some((x) => x.src === src)) return;
              draft.images.push({
                src,
                title: cb.getAttribute('data-title') || `Aviso ${draft.images.length + 1}`,
              });
            });
            await persist('Imagens adicionadas');
          }
          closePicker();
          paint();
        });
      };

      const addFiles = async (files) => {
        const list = [...(files || [])].filter((f) => f.type.startsWith('image/'));
        if (!list.length) {
          this.toast?.('Selecione imagens (PNG, JPG, WebP…)', 'warn');
          return;
        }
        this.toast?.(`Importando ${list.length} imagem(ns)…`, 'info');
        for (const file of list) {
          try {
            const saved = await saveMediaFile(file, { category: 'image' });
            const src = resolveMediaSrc(saved) || saved?.src;
            if (!src) continue;
            draft.images.push({
              src,
              title: (file.name || 'Aviso').replace(/\.[^.]+$/, ''),
            });
          } catch (err) {
            this.toast?.(`Falha ao importar ${file.name}: ${err.message}`, 'warn');
          }
        }
        await persist('Imagens importadas e salvas');
        paint();
      };

      const setBackgroundFile = async (file) => {
        if (!file?.type?.startsWith('image/')) {
          this.toast?.('Selecione uma imagem de fundo', 'warn');
          return;
        }
        try {
          const saved = await saveMediaFile(file, { category: 'image' });
          const src = resolveMediaSrc(saved) || saved?.src;
          if (!src) return;
          draft.bulletin.backgroundSrc = src;
          await persist('Fundo salvo');
          paint();
        } catch (err) {
          this.toast?.(err.message || 'Falha ao salvar fundo', 'warn');
        }
      };

      const closeModal = () => {
        clearTimeout(quietTimer);
        quietTimer = null;
        modal.remove();
      };

      const syncNoticesFromDom = () => {
        modal.querySelectorAll('[data-notice-text]').forEach((ta) => {
          const i = Number(ta.getAttribute('data-notice-text'));
          if (!draft.bulletin.notices[i]) return;
          draft.bulletin.notices[i].text = ta.value;
          const hl = modal.querySelector(`[data-notice-headline="${i}"]`);
          if (hl) draft.bulletin.notices[i].headline = hl.value;
        });
      };

      const onNoticeFieldEdit = () => {
        syncNoticesFromDom();
        refreshPreviewMock();
        refreshStartButton();
        persistQuiet();
      };

      const bind = () => {
        modal.querySelectorAll('[data-close]').forEach((el) => {
          el.onclick = () => closeModal();
        });

        modal.querySelectorAll('.bulletin-mode-tab').forEach((btn) => {
          btn.addEventListener('click', () => {
            const next = btn.dataset.mode === 'bulletin' ? 'bulletin' : 'images';
            if (draft.mode === next) return;
            readForm();
            syncNoticesFromDom();
            setMode(next);
          });
        });

        modal.querySelector('#bulletin-interval')?.addEventListener('change', async () => {
          readForm();
          await persist('Tempo atualizado', { remount: false });
        });

        modal.querySelectorAll('[data-act]').forEach((btn) => {
          btn.addEventListener('click', async () => {
            const act = btn.getAttribute('data-act');
            if (act === 'add-lib') return openLibraryPicker();
            if (act === 'add-files') return modal.querySelector('#bulletin-file-input')?.click();
            if (act === 'bg-lib') return openLibraryPicker({ forBackground: true });
            if (act === 'bg-file') return modal.querySelector('#bulletin-bg-file')?.click();
            if (act === 'bg-clear') {
              draft.bulletin.backgroundSrc = '';
              await persist('Fundo removido', { remount: false });
              paint();
              return;
            }
            if (act === 'add-notice') {
              syncNoticesFromDom();
              draft.bulletin.notices.push({
                id: `n-${Date.now()}`,
                headline: '',
                text: '',
              });
              const focusIdx = draft.bulletin.notices.length - 1;
              await persist(null, { silent: true, remount: false });
              paint({ focusNoticeIndex: focusIdx, restoreScroll: false });
            }
          });
        });

        modal.querySelector('#bulletin-file-input')?.addEventListener('change', (e) => {
          addFiles(e.target.files);
          e.target.value = '';
        });
        modal.querySelector('#bulletin-bg-file')?.addEventListener('change', (e) => {
          const file = e.target.files?.[0];
          e.target.value = '';
          if (file) setBackgroundFile(file);
        });

        modal.querySelectorAll('[data-img-remove]').forEach((btn) => {
          btn.addEventListener('click', async () => {
            const i = Number(btn.getAttribute('data-img-remove'));
            draft.images.splice(i, 1);
            await persist('Imagem excluída', { remount: false });
            paint();
          });
        });
        modal.querySelectorAll('[data-img-up]').forEach((btn) => {
          btn.addEventListener('click', async () => {
            const i = Number(btn.getAttribute('data-img-up'));
            if (i <= 0) return;
            [draft.images[i - 1], draft.images[i]] = [draft.images[i], draft.images[i - 1]];
            await persist(null, { silent: true, remount: false });
            paint();
          });
        });
        modal.querySelectorAll('[data-img-down]').forEach((btn) => {
          btn.addEventListener('click', async () => {
            const i = Number(btn.getAttribute('data-img-down'));
            if (i >= draft.images.length - 1) return;
            [draft.images[i], draft.images[i + 1]] = [draft.images[i + 1], draft.images[i]];
            await persist(null, { silent: true, remount: false });
            paint();
          });
        });
        modal.querySelectorAll('[data-img-title]').forEach((input) => {
          input.addEventListener('change', async () => {
            const i = Number(input.getAttribute('data-img-title'));
            if (draft.images[i]) {
              draft.images[i].title = input.value.trim() || `Aviso ${i + 1}`;
              await persist(null, { silent: true, remount: false });
            }
          });
        });

        modal.querySelectorAll('[data-notice-remove]').forEach((btn) => {
          btn.addEventListener('click', async () => {
            syncNoticesFromDom();
            const i = Number(btn.getAttribute('data-notice-remove'));
            draft.bulletin.notices.splice(i, 1);
            await persist('Aviso excluído', { remount: false });
            paint();
          });
        });
        modal.querySelectorAll('[data-notice-up]').forEach((btn) => {
          btn.addEventListener('click', async () => {
            syncNoticesFromDom();
            const i = Number(btn.getAttribute('data-notice-up'));
            if (i <= 0) return;
            const arr = draft.bulletin.notices;
            [arr[i - 1], arr[i]] = [arr[i], arr[i - 1]];
            await persist(null, { silent: true, remount: false });
            paint();
          });
        });
        modal.querySelectorAll('[data-notice-down]').forEach((btn) => {
          btn.addEventListener('click', async () => {
            syncNoticesFromDom();
            const i = Number(btn.getAttribute('data-notice-down'));
            const arr = draft.bulletin.notices;
            if (i >= arr.length - 1) return;
            [arr[i], arr[i + 1]] = [arr[i + 1], arr[i]];
            await persist(null, { silent: true, remount: false });
            paint();
          });
        });
        modal.querySelectorAll('[data-notice-text], [data-notice-headline]').forEach((el) => {
          el.addEventListener('input', onNoticeFieldEdit);
          el.addEventListener('blur', onNoticeFieldEdit);
        });

        modal.querySelector('#bulletin-stop')?.addEventListener('click', () => {
          this.stopBulletinCarousel?.({ clearScreen: true });
          paint();
        });

        modal.querySelector('#bulletin-clear')?.addEventListener('click', async () => {
          if (!confirm('Limpar todo o carrossel? Isso apaga imagens e avisos salvos em disco.')) return;
          this.stopBulletinCarousel?.({ clearScreen: true, silent: true });
          Object.assign(draft, DEFAULT_INDEX());
          await persist('Carrossel limpo e excluído do disco', { remount: false });
          paint();
        });

        modal.querySelector('#bulletin-save')?.addEventListener('click', async () => {
          if (draft.mode === 'bulletin') syncNoticesFromDom();
          readForm();
          await persist('Avisos salvos', { remount: false });
          refreshStartButton();
          refreshPreviewMock();
        });

        modal.querySelector('#bulletin-start')?.addEventListener('click', async () => {
          if (draft.mode === 'bulletin') syncNoticesFromDom();
          readForm();
          if (!draftSlideCount(draft)) {
            this.toast?.('Escreva o texto de pelo menos um aviso', 'warn');
            return;
          }
          let saved = normalizeIndex(draft, { keepEmptyNotices: true });
          try {
            saved = await saveAvisosIndex(draft, { silent: false });
          } catch {
            this.toast?.('Não deu para gravar em disco — iniciando só nesta sessão', 'warn');
          }
          modal.remove();
          clearTimeout(quietTimer);
          quietTimer = null;
          await this._runBulletinCarousel(saved);
        });

        modal.querySelector('#bulletin-title')?.addEventListener('input', () => {
          readForm();
          refreshPreviewMock();
          persistQuiet();
        });
      };

      document.body.appendChild(modal);
      paint();
    },
  };
}
