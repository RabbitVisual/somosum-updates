/**
 * Pacote USB de culto (U3-F) — export/import JSON offline sem rede.
 */
import {
  getPrefs,
  getProgram,
  saveProgram,
  getAllSongs,
  getSong,
  saveSong,
  getAllMedia,
  savePrefs,
} from '../core/store.js';
import { forceSaveWorshipSong } from '../worship/worship-store.js';

export const CULTO_PACKAGE_VERSION = 1;

function mediaPathOnly(m) {
  if (!m) return null;
  return {
    id: m.id,
    name: m.name || m.title || '',
    kind: m.kind || m.type || '',
    path: m.path || null,
    src: typeof m.src === 'string' && !m.src.startsWith('data:') ? m.src : null,
    mimeType: m.mimeType || null,
  };
}

function collectSongIds(items = []) {
  const ids = new Set();
  for (const it of items) {
    if (it?.songId) ids.add(it.songId);
    if (it?.data?.songId) ids.add(it.data.songId);
  }
  return [...ids];
}

function prefsSubset(prefs) {
  if (!prefs || typeof prefs !== 'object') return {};
  return {
    theme: prefs.theme,
    church: prefs.church,
    bibleVersion: prefs.bibleVersion,
    transition: prefs.transition,
    showClock: prefs.showClock,
    showFooterVerse: prefs.showFooterVerse,
    versesPerSlide: prefs.versesPerSlide,
    projectionFontBoost: prefs.projectionFontBoost,
    globalLyricsStyle: prefs.globalLyricsStyle,
    lyricsFx: prefs.lyricsFx,
    navigation: {
      activeCultoId: prefs.navigation?.activeCultoId || null,
    },
  };
}

/**
 * Monta pacote JSON do culto atual (programa + músicas referenciadas + refs).
 */
export async function exportCultoPackage() {
  const prefs = getPrefs();
  const program = (await getProgram()) || [];
  const songIds = collectSongIds(program);
  const songs = [];
  for (const id of songIds) {
    try {
      const song = await getSong(id);
      if (song) songs.push(song);
    } catch { /* skip */ }
  }
  // Fallback: se getSong vazio (biblioteca worship), tenta lista completa filtrada
  if (songs.length === 0 && songIds.length) {
    try {
      const all = await getAllSongs();
      for (const s of all || []) {
        if (songIds.includes(s.id)) songs.push(s);
      }
    } catch { /* ignore */ }
  }

  let bibleHistory = [];
  try {
    const { listReadings } = await import('../bible/reading-history.js');
    const cultoId = prefs.navigation?.activeCultoId;
    bibleHistory = await listReadings({ cultoId, limit: 100 });
  } catch { /* optional */ }

  let ccliUsage = [];
  try {
    const { listUsage } = await import('../worship/ccli-usage.js');
    const cultoId = prefs.navigation?.activeCultoId;
    ccliUsage = await listUsage({ cultoId, limit: 200 });
  } catch { /* optional */ }

  let mediaRefs = [];
  try {
    const media = await getAllMedia();
    const usedIds = new Set();
    for (const it of program) {
      if (it?.mediaId) usedIds.add(it.mediaId);
      if (it?.data?.backgroundMediaId) usedIds.add(it.data.backgroundMediaId);
      if (it?.data?.mediaId) usedIds.add(it.data.mediaId);
    }
    mediaRefs = (media || [])
      .filter((m) => usedIds.has(m.id))
      .map(mediaPathOnly)
      .filter(Boolean);
  } catch { /* optional */ }

  return {
    version: CULTO_PACKAGE_VERSION,
    kind: 'culto-package',
    exportedAt: new Date().toISOString(),
    prefs: prefsSubset(prefs),
    program: {
      items: program,
      activeCultoId: prefs.navigation?.activeCultoId || null,
    },
    songs,
    bibleHistory,
    ccliUsage,
    mediaRefs,
  };
}

/**
 * Valida e aplica pacote USB.
 * @param {object} json
 * @param {{ replaceProgram?: boolean, confirmReplace?: () => boolean }} [opts]
 */
export async function importCultoPackage(json, opts = {}) {
  if (!json || typeof json !== 'object') {
    throw new Error('Pacote inválido.');
  }
  if (json.version == null || !json.exportedAt) {
    throw new Error('Pacote inválido: faltam version/exportedAt.');
  }
  if (Number(json.version) > CULTO_PACKAGE_VERSION) {
    throw new Error('Pacote de versão mais nova — atualize o SOMOSUM.');
  }

  const items = Array.isArray(json.program?.items)
    ? json.program.items
    : (Array.isArray(json.items) ? json.items : null);

  if (!items) {
    throw new Error('Pacote sem itens de programa.');
  }

  const replace = opts.replaceProgram !== false;
  if (replace) {
    const confirmFn = opts.confirmReplace;
    if (typeof confirmFn === 'function' && !confirmFn()) {
      return { ok: false, cancelled: true };
    }
    await saveProgram(items);
  }

  if (json.prefs && typeof json.prefs === 'object') {
    const current = getPrefs();
    const patch = {
      ...json.prefs,
      navigation: {
        ...current.navigation,
        ...(json.prefs.navigation || {}),
        ...(json.program?.activeCultoId
          ? { activeCultoId: json.program.activeCultoId }
          : {}),
      },
    };
    savePrefs(patch);
  }

  // Songs: merge by id
  if (Array.isArray(json.songs) && json.songs.length) {
    for (const song of json.songs) {
      if (song?.id) await forceSaveWorshipSong(song);
    }
  }

  return {
    ok: true,
    itemCount: items.length,
    songCount: Array.isArray(json.songs) ? json.songs.length : 0,
    exportedAt: json.exportedAt,
  };
}

/** Download helper for UI. */
export function downloadJson(filename, data) {
  const a = document.createElement('a');
  const blob = URL.createObjectURL(new Blob([JSON.stringify(data, null, 2)], {
    type: 'application/json;charset=utf-8',
  }));
  a.href = blob;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(blob);
}
