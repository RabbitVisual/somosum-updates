import { DiskAdapter } from '../core/storage/adapters/disk-adapter.js';
import { generateId } from '../core/store.js';

export async function listDesignerTemplates() {
  const index = await DiskAdapter.load('templates/index.json');
  return (index?.templates || []).filter((t) => t.kind === 'designer' || t.id?.startsWith('ds-'));
}

export async function saveDesignerTemplate(name, slideData, existingId = null) {
  const index = (await DiskAdapter.load('templates/index.json')) || { templates: [] };
  const now = new Date().toISOString();
  let id = existingId;

  if (id) {
    const entry = index.templates.find((t) => t.id === id);
    if (entry) {
      entry.name = name || entry.name;
      entry.kind = 'designer';
      entry.updatedAt = now;
    } else {
      index.templates.push({ id, name: name || 'Template Designer', kind: 'designer', updatedAt: now });
    }
  } else {
    id = `ds-${generateId().slice(0, 8)}`;
    index.templates = index.templates.filter((t) => t.id !== id);
    index.templates.push({
      id,
      name: name || 'Template Designer',
      kind: 'designer',
      updatedAt: now,
    });
  }

  await DiskAdapter.save('templates/index.json', index);
  await DiskAdapter.save(`templates/${id}.json`, {
    slide: slideData,
    meta: {
      layerCount: slideData?.layers?.length || 0,
      title: slideData?.title || name,
    },
  });
  return id;
}

export async function loadDesignerTemplate(id) {
  const data = await DiskAdapter.load(`templates/${id}.json`);
  return data?.slide || null;
}

export async function deleteDesignerTemplate(id) {
  const index = (await DiskAdapter.load('templates/index.json')) || { templates: [] };
  index.templates = index.templates.filter((t) => t.id !== id);
  await DiskAdapter.save('templates/index.json', index);
}
