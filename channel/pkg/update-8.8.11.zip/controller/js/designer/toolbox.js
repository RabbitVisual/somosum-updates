/** Barra de ferramentas do designer — grupos claros e só o essencial aberto */

import { faBtnIcon, DS_ICONS as I } from './fa-icon.js';

export const TEXT_TOOLS = [
  { id: 'text', icon: I.text, label: 'Texto livre' },
];

export const SHAPE_TOOLS = [
  { id: 'rect', icon: I.rect, label: 'Retângulo' },
  { id: 'circle', icon: I.circle, label: 'Círculo' },
  { id: 'line', icon: I.line, label: 'Linha' },
];

export const MEDIA_TOOLS = [
  { id: 'image', icon: I.image, label: 'Imagem' },
  { id: 'media-library', icon: I.folder, label: 'Biblioteca' },
  { id: 'logo', icon: I.logo, label: 'Logo da igreja' },
  { id: 'frame-rect', icon: I.frameRect, label: 'Moldura ret.' },
  { id: 'frame-rounded', icon: I.frameRounded, label: 'Moldura arred.' },
  { id: 'frame-circle', icon: I.frameCircle, label: 'Moldura circ.' },
  { id: 'frame-ellipse', icon: I.frameEllipse, label: 'Moldura elipse' },
  { id: 'frame-star', icon: I.frameStar, label: 'Moldura estrela' },
  { id: 'frame-hex', icon: I.frameHex, label: 'Moldura hex.' },
  { id: 'frame-diamond', icon: I.frameDiamond, label: 'Moldura losango' },
  { id: 'frame-mask', icon: I.frameMask, label: 'Moldura PNG' },
];

export const PREACHER_TOOLS = [
  { id: 'preacher-card', icon: I.preacher, label: 'Card pregador' },
];

export const ALIGN_TOOLS = [
  { id: 'align-left', icon: I.alignLeft, label: 'Esquerda' },
  { id: 'align-center-h', icon: I.alignCenterH, label: 'Centro H' },
  { id: 'align-right', icon: I.alignRight, label: 'Direita' },
  { id: 'align-top', icon: I.alignTop, label: 'Topo' },
  { id: 'align-middle', icon: I.alignMiddle, label: 'Meio V' },
  { id: 'align-bottom', icon: I.alignBottom, label: 'Base' },
  { id: 'align-center', icon: I.alignCenter, label: 'Centro' },
  { id: 'distribute-h', icon: I.distributeH, label: 'Distribuir H' },
  { id: 'distribute-v', icon: I.distributeV, label: 'Distribuir V' },
];

export const LAYER_TOOLS = [
  { id: 'layer-front', icon: I.layerFront, label: 'Frente' },
  { id: 'layer-forward', icon: I.layerForward, label: 'Acima' },
  { id: 'layer-backward', icon: I.layerBackward, label: 'Abaixo' },
  { id: 'layer-back', icon: I.layerBack, label: 'Fundo' },
  { id: 'duplicate', icon: I.duplicate, label: 'Duplicar' },
  { id: 'delete', icon: I.delete, label: 'Excluir' },
  { id: 'group', icon: I.group, label: 'Agrupar' },
  { id: 'ungroup', icon: I.ungroup, label: 'Desagrupar' },
];

function toolBtn(t, cls = 'designer-tool') {
  const compact = cls.includes('designer-tool-icon');
  const ico = faBtnIcon(t.icon);
  const label = compact ? '' : ` <span>${t.label}</span>`;
  return `<button type="button" class="${cls}" data-tool="${t.id}" title="${t.label}">${ico}${label}</button>`;
}

function group(label, tools, { open = true, className = '', compact = false } = {}) {
  const cls = compact ? 'designer-tool designer-tool-compact' : 'designer-tool';
  const body = tools.map((t) => toolBtn(t, compact ? cls : (className.includes('icon') ? 'designer-tool designer-tool-icon' : cls))).join('');
  return `
    <details class="designer-tool-group ${className}" ${open ? 'open' : ''}>
      <summary class="designer-tool-label">${label}</summary>
      <div class="designer-tool-group-body">${body}</div>
    </details>`;
}

export function bindToolbox(container, handlers) {
  if (!container) return;

  const iconHtml = (items) => items.map((t) => toolBtn(t, 'designer-tool designer-tool-icon')).join('');

  container.innerHTML = `
    <p class="designer-tool-intro">1. Escolha um <strong>Modelo</strong> · 2. Adicione elementos · 3. Ajuste no painel direito · 4. Salve na Ordem</p>
    <div class="designer-tool-search">
      ${faBtnIcon(I.search)}
      <input type="search" id="designer-tool-filter" placeholder="Buscar ferramenta…" autocomplete="off" />
    </div>
    <div id="designer-tool-groups">
    ${group('1. Texto e blocos', [
      ...TEXT_TOOLS,
      { id: 'block-title', icon: I.blockTitle, label: 'Bloco título' },
      { id: 'block-verse', icon: I.blockVerse, label: 'Bloco versículo' },
      { id: 'block-logo', icon: I.blockLogo, label: 'Bloco logo' },
      ...PREACHER_TOOLS,
    ], { open: true })}
    ${group('2. Formas', SHAPE_TOOLS, { open: true })}
    ${group('3. Mídia e molduras', MEDIA_TOOLS, { open: false, className: 'designer-tool-group-media', compact: true })}
    <details class="designer-tool-group" open>
      <summary class="designer-tool-label">4. Master slides</summary>
      <div class="designer-tool-group-body" id="designer-masters-host">
        <button type="button" class="designer-tool" data-tool="master-apply">${faBtnIcon(I.master)} <span>Aplicar master…</span></button>
      </div>
    </details>
    <details class="designer-tool-group designer-tool-group-align">
      <summary class="designer-tool-label">5. Alinhar / Distribuir</summary>
      <div class="designer-tool-group-body">${iconHtml(ALIGN_TOOLS)}</div>
    </details>
    <details class="designer-tool-group designer-tool-group-layer">
      <summary class="designer-tool-label">6. Camadas</summary>
      <div class="designer-tool-group-body">${iconHtml(LAYER_TOOLS)}</div>
    </details>
    </div>
    <p class="designer-tool-hint">Fontes da pasta <code>fonts/</code> · aba Mídia. Modelos de Boas-vindas · aba Modelos. Shift+clique = multi-seleção.</p>`;

  container.querySelectorAll('[data-tool]').forEach((btn) => {
    btn.addEventListener('click', () => handlers[btn.dataset.tool]?.());
  });

  const filter = container.querySelector('#designer-tool-filter');
  filter?.addEventListener('input', (e) => {
    const q = String(e.target.value || '').trim().toLowerCase();
    container.querySelectorAll('#designer-tool-groups .designer-tool-group').forEach((grp) => {
      const tools = grp.querySelectorAll('[data-tool]');
      let any = false;
      tools.forEach((btn) => {
        const label = (btn.title || btn.textContent || '').toLowerCase();
        const show = !q || label.includes(q);
        btn.style.display = show ? '' : 'none';
        if (show) any = true;
      });
      grp.style.display = any || !q ? '' : 'none';
      if (q && any) grp.open = true;
    });
  });
}
