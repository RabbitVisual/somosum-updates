/**
 * Boot do Designer — FA Pro + Konva + fontes de slide (produção).
 */
import { ensureFontAwesomeReady } from '../core/fa-icons.js';
import { loadCustomFonts, getCustomFontList } from '../core/fonts.js';
import { loadDesignerAssets } from '../core/asset-registry.js';

const KONVA_WAIT_MS = 8000;
const KONVA_POLL_MS = 50;

export async function bootDesignerSurface() {
  await loadDesignerAssets();

  const faOk = await ensureFontAwesomeReady();
  if (!faOk) {
    console.warn('[SOMOSUM:designer] Font Awesome Pro ainda carregando — ícones podem falhar momentaneamente');
  }

  const konvaDeadline = Date.now() + KONVA_WAIT_MS;
  while (!window.Konva && Date.now() < konvaDeadline) {
    await new Promise((r) => setTimeout(r, KONVA_POLL_MS));
  }
  if (!window.Konva) {
    throw new Error('Konva não carregou. Reinicie o SOMOSUM.exe e pressione Ctrl+F5.');
  }

  await loadCustomFonts({ injectFaces: true });
  document.documentElement.dataset.designerOpen = '1';

  return { fonts: getCustomFontList(), fontAwesomeReady: faOk };
}

export function teardownDesignerSurface() {
  try {
    delete document.documentElement.dataset.designerOpen;
  } catch { /* ignore */ }
}
