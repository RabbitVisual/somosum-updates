/** Program integration and projection actions for SlideDesigner. */

import { randomId } from '../core/uuid.js';
import {
  inferProgramItemFromDesigner,
  buildDesignerSkin,
  hasDesignerSkin,
  getDesignerSkin,
  applyContentToLayers,
  templateIdForProgramItem,
  buildContentCtxFromItem,
  backgroundFromProgramItem,
} from './content-bindings.js';
import { buildDesignerPreset } from './designer-presets.js';
import { getSafeZoneViolations } from './safe-zone.js';

export const designerProgramMethods = {

  isDirty() {
    return !!this._dirty;
  },

  _markDirty() {
    this._dirty = true;
    this._updateDirtyBadge?.();
    this._scheduleAutosave?.();
  },

  _clearDirty() {
    this._dirty = false;
    this._updateDirtyBadge?.();
  },

  _scheduleAutosave() {
    if (this._sourceItemIndex == null) return;
    clearTimeout(this._autosaveTimer);
    this._autosaveTimer = setTimeout(() => {
      void this.saveToSourceItem({ silent: true });
    }, 800);
  },

  async _gateSafeZone(opts = {}) {
    const silent = !!opts.silent;
    if (silent) {
      const eng = this._getEngine?.() || this.canvas;
      if (!eng) return true;
      return getSafeZoneViolations(eng).length === 0;
    }
    if (typeof this._ensureSafeZoneClear === 'function') {
      return this._ensureSafeZoneClear();
    }
    return true;
  },

  _updateDirtyBadge() {
    const badge = this.root?.querySelector('#ds-dirty-badge');
    if (!badge) return;
    const linked = this._sourceItemIndex != null;
    if (this._dirty) {
      badge.textContent = 'Alterações não salvas';
    } else {
      badge.textContent = linked ? 'Salvo na Ordem' : 'Salvo';
    }
    badge.classList.toggle('is-dirty', !!this._dirty);
    badge.classList.toggle('is-clean', !this._dirty);
  },

  _churchMeta() {
    return this.app.prefs?.church || {};
  },

  _applySkinToItem(item, slide) {
    const skin = buildDesignerSkin(slide);
    const inferred = inferProgramItemFromDesigner(slide, {
      id: item.id,
      bible: item.bible,
      welcome: item.data,
      data: item.data,
      church: this._churchMeta(),
      title: slide.title || item.title,
    });

    if (inferred.slideType !== 'custom' && (item.slideType === 'custom' || !item.slideType)) {
      item.slideType = inferred.slideType;
      item.type = inferred.type || inferred.slideType;
    }

    if (inferred.slideType === 'bible' || item.slideType === 'bible') {
      item.slideType = 'bible';
      item.type = 'bible';
      const nextBible = { ...(item.bible || {}), ...(inferred.bible || {}) };
      if (item.bible?.excerptText?.trim()) nextBible.excerptText = item.bible.excerptText;
      if (item.bible?.referenceOverride?.trim()) nextBible.referenceOverride = item.bible.referenceOverride;
      if (item.bible?.book) {
        nextBible.book = item.bible.book;
        nextBible.chapter = item.bible.chapter;
        nextBible.verseStart = item.bible.verseStart;
        nextBible.verseEnd = item.bible.verseEnd;
        nextBible.version = item.bible.version || nextBible.version;
        nextBible.displayMode = item.bible.displayMode || nextBible.displayMode;
      }
      item.bible = nextBible;
      const role = item.data?.role === 'introito' || inferred.data?.role === 'introito'
        ? 'introito'
        : item.data?.role;
      item.data = {
        ...(item.data || {}),
        ...(inferred.data || {}),
        role: role || inferred.data?.role,
        designer: skin,
        layers: skin.layers,
        background: skin.background,
        templateId: skin.templateId || slide.templateId,
        previewDataUrl: skin.previewDataUrl,
      };
    } else if (inferred.slideType === 'welcome' || item.slideType === 'welcome') {
      item.slideType = 'welcome';
      item.type = 'welcome';
      item.data = {
        ...(item.data || {}),
        ...(inferred.data || {}),
        designer: skin,
        layers: skin.layers,
        background: skin.background,
        templateId: skin.templateId || slide.templateId,
        previewDataUrl: skin.previewDataUrl,
      };
    } else if (inferred.slideType === 'message' || item.slideType === 'message') {
      item.slideType = 'message';
      item.type = 'message';
      item.data = {
        ...(item.data || {}),
        ...(inferred.data || {}),
        designer: skin,
        layers: skin.layers,
        background: skin.background,
        templateId: skin.templateId || slide.templateId,
        previewDataUrl: skin.previewDataUrl,
      };
      if (inferred.bible || item.bible) {
        item.bible = { ...(item.bible || {}), ...(inferred.bible || {}) };
      }
    } else {
      item.slideType = item.slideType === 'custom' || !item.slideType ? 'custom' : item.slideType;
      item.data = {
        ...(item.data || {}),
        title: slide.title,
        text: slide.text,
        designer: skin,
        layers: skin.layers,
        background: skin.background,
        templateId: skin.templateId || slide.templateId,
        previewDataUrl: skin.previewDataUrl,
      };
    }
    item.title = slide.title || item.title;
  },

  async saveToSourceItem(opts = {}) {
    const silent = !!opts.silent;
    if (this._sourceItemIndex == null) {
      if (!silent) this.app.toast('Abra o Designer a partir de um item do programa', 'warn');
      return;
    }
    const ok = await this._gateSafeZone({ silent });
    if (!ok) return;
    this.persistCurrentSlide({ includePreview: !silent });
    const slide = this.slides[this.slideIndex];
    const item = this.app.program.items[this._sourceItemIndex];
    if (!item) return;
    this._applySkinToItem(item, slide);
    await this.app.persistProgram({ keepNavigation: true });
    this.app.invalidatePreviewCache?.();
    if (!silent) this.app.refreshStage?.();
    this._clearDirty();
    if (!silent) this.app.toast('Design salvo — conteúdo da Ordem preservado');
  },

  async addToProgram() {
    if (!(await this._gateSafeZone())) return;
    this.persistCurrentSlide({ includePreview: true });
    let insertAt = null;
    const cur = this.app.program?.currentIndex;
    if (typeof cur === 'number' && cur >= 0) {
      const useCurrent = confirm(
        `Inserir ${this.slides.length} slide(s) após o item atual "${this.app.program.items[cur]?.title || 'item'}"?\n\nOK = inserir aqui · Cancelar = adicionar no final`,
      );
      insertAt = useCurrent ? cur + 1 : null;
    }
    for (let i = 0; i < this.slides.length; i++) {
      const slide = this.slides[i];
      const inferred = inferProgramItemFromDesigner(slide, {
        church: this._churchMeta(),
        title: slide.title || `Slide Designer ${i + 1}`,
      });
      await this.app.insertProgramItem({
        id: inferred.id || randomId(),
        slideType: inferred.slideType,
        type: inferred.type || inferred.slideType,
        title: inferred.title,
        data: inferred.data,
        ...(inferred.bible ? { bible: inferred.bible } : {}),
      }, insertAt != null ? insertAt + i : null);
    }
    this._clearDirty();
    this.app.toast(`${this.slides.length} slide(s) adicionado(s) ao programa`);
    if (typeof this.app.setView === 'function') this.app.setView('live');
    else {
      this.app.view = 'live';
      this.app.render();
    }
  },

  async projectCurrent() {
    if (!(await this._gateSafeZone())) return;
    // Espera logo/foto das molduras — senão o projetor recebe círculo vazio
    await this.canvas?.waitForMediaReady?.(8000);
    this.persistCurrentSlide({ includePreview: true });
    const { prepareCustomSlideForSync } = await import('./content-bindings.js');
    const raw = { ...this.slides[this.slideIndex], type: 'custom' };
    const payload = prepareCustomSlideForSync(raw);
    const sent = this.app.sendSlideToProjector?.(payload, true);
    if (!sent) {
      this.app.toast?.('Não foi possível enviar ao projetor (ensaio ou pré-culto?)', 'warn');
      return;
    }
    this.app.toast('Slide enviado ao projetor');
  },

  refreshContentFromSourceItem() {
    const idx = this._sourceItemIndex;
    const item = idx != null ? this.app?.program?.items?.[idx] : null;
    if (!item || !this.canvas) {
      this.app?.toast?.('Abra o Designer a partir de um item da Ordem', 'warn');
      return;
    }
    this.persistCurrentSlide({ markDirty: false, skipLayers: true });
    const slide = this.slides[this.slideIndex];
    if (!slide?.layers?.length) return;
    const ctx = buildContentCtxFromItem(item);
    slide.layers = applyContentToLayers(slide.layers, ctx);
    const bg = backgroundFromProgramItem(item, slide.background);
    if (bg) slide.background = bg;
    this._loadSlideOntoCanvas(slide);
    this.propsPanel?.setBackground(slide.background || this._getBackground());
    this.canvas?.scheduleFitTextBoxes?.();
    this.refreshLayers();
    this._markDirty();
    this.app?.toast?.('Conteúdo atualizado a partir da Ordem');
  },

  loadFromItem(item) {
    if (!item) return;
    const wasEmpty = !hasDesignerSkin(item);
    const templateId = templateIdForProgramItem(item);
    const assets = this.app?.getAssetUrls?.() || {};
    const church = this.app?.prefs?.church || {};
    const skin = getDesignerSkin(item);
    let layers = skin?.layers?.length ? skin.layers.map((l) => ({ ...l })) : [];
    let background = backgroundFromProgramItem(item, skin?.background || null);
    const previewDataUrl = skin?.previewDataUrl || item.data?.previewDataUrl;

    if (!layers.length) {
      const preset = buildDesignerPreset(templateId, assets, church);
      layers = Array.isArray(preset?.layers) ? preset.layers.map((l) => ({ ...l })) : [];
      if (!background) background = preset?.background || { type: 'color', value: '#0a0a0a' };
    }

    const ctx = buildContentCtxFromItem(item);
    if (layers.length) {
      layers = applyContentToLayers(layers, ctx);
    }

    const slide = {
      title: item.data?.title || item.title,
      text: item.data?.text || item.bible?.excerptText || '',
      layers,
      background: background || { type: 'color', value: '#0a0a0a' },
      designer: { version: 3, width: 1920, height: 1080 },
      templateId,
      previewDataUrl,
    };
    this.slides = [slide];
    this.slideIndex = 0;
    if (slide.layers?.length) {
      this._loadSlideOntoCanvas(slide);
    } else {
      this.applyPreset(templateId || 'blank', false);
    }
    this.propsPanel?.setBackground(slide.background || this._getBackground());
    this.canvas?.scheduleFitTextBoxes?.();
    this.renderSlideTabs();
    this.renderPresets();
    this.refreshLayers();
    this._syncSaveButtons?.();
    if (wasEmpty && this.slides[0]?.layers?.length) {
      this._markDirty();
      void this.saveToSourceItem?.({ silent: true });
    } else {
      this._clearDirty();
    }
    this._updateDirtyBadge?.();
  },

  async confirmLeaveDesigner() {
    if (!this._dirty) return true;
    const save = confirm('Há alterações não salvas no Designer.\n\nOK = Salvar e sair · Cancelar = permanecer');
    if (save) {
      await this.savePrimaryAction();
      return !this._dirty;
    }
    const discard = confirm('Descartar alterações e sair do Designer?');
    if (discard) {
      this._clearDirty();
      return true;
    }
    return false;
  },

};

export { hasDesignerSkin };
