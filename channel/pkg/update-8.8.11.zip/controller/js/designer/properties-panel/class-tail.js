import { FONT_STACKS } from '../designer-colors.js';
import { preloadFontsForCanvas, getCustomFontList, SYSTEM_FONT_STACKS } from '../../core/fonts.js';
import { bindFontPickerPair, readFontPickerPair } from '../../core/font-picker-ui.js';
import { getShadowState, applyShadowState } from '../konva-shadow.js';
import { esc, escAttr } from './class-bind.js';

export const propertiesPanelTail = {
  bindPhotoCard() {
    const emit = (patch) => this.onChange?.({ type: 'photoCardProps', patch });
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    input.hidden = true;
    document.body.appendChild(input);
    this.container.querySelector('#dp-card-pick')?.addEventListener('click', () => input.click());
    input.onchange = (e) => {
      const f = e.target.files?.[0];
      if (!f) return;
      const reader = new FileReader();
      reader.onload = () => this.onChange?.({ type: 'photoCardFill', src: reader.result });
      reader.readAsDataURL(f);
      e.target.value = '';
    };
    this.container.querySelector('#dp-card-label')?.addEventListener('input', (e) => {
      emit({ cardLabel: e.target.value });
    });
    this.container.querySelector('#dp-card-name')?.addEventListener('input', (e) => {
      emit({ cardName: e.target.value, cardTitle: e.target.value });
    });
    this.container.querySelector('#dp-card-from')?.addEventListener('input', (e) => {
      emit({ cardFrom: e.target.value, cardSubtitle: e.target.value });
    });
    this.container.querySelector('#dp-card-fit')?.addEventListener('change', (e) => {
      emit({ fillFit: e.target.value });
    });
    this.container.querySelector('#dp-card-scale')?.addEventListener('input', (e) => {
      emit({ fillScale: Number(e.target.value) });
    });
    this.container.querySelector('#dp-card-offx')?.addEventListener('input', (e) => {
      emit({ fillOffsetX: Number(e.target.value) });
    });
    this.container.querySelector('#dp-card-offy')?.addEventListener('input', (e) => {
      emit({ fillOffsetY: Number(e.target.value) });
    });
    this.container.querySelector('#dp-card-photo-size')?.addEventListener('input', (e) => {
      emit({ photoSize: Number(e.target.value) });
    });
    this.container.querySelector('#dp-card-label-size')?.addEventListener('input', (e) => {
      emit({ labelSize: Number(e.target.value) });
    });
    this.container.querySelector('#dp-card-title-size')?.addEventListener('input', (e) => {
      emit({ titleSize: Number(e.target.value) });
    });
    this.container.querySelector('#dp-card-subtitle-size')?.addEventListener('input', (e) => {
      emit({ subtitleSize: Number(e.target.value) });
    });
    this.container.querySelector('#dp-card-radius')?.addEventListener('input', (e) => {
      emit({ cornerRadius: Number(e.target.value) });
    });
  },

  frameSection() {
    const shape = this.node.attrs.clipShape || 'rect';
    const fit = this.node.attrs.fillFit || 'cover';
    const scale = this.node.attrs.fillScale || 1;
    const offX = this.node.attrs.fillOffsetX || 0;
    const offY = this.node.attrs.fillOffsetY || 0;
    const radius = this.node.attrs.cornerRadius || 24;
    const stroke = this.node.attrs.stroke || '#d4c68d';
    const strokeWidth = this.node.attrs.strokeWidth ?? 2;
    const dashed = this.node.attrs.strokeDashed !== false;
    const role = this.node.attrs.role || '';
    const hasFill = !!(this.node.attrs.fillSrc);
    const fillEdit = !!this.node.attrs._fillEdit;
    const strokeColor = /^#[0-9a-fA-F]{6}$/.test(stroke) ? stroke : '#d4c68d';
    return `
      <section class="designer-props-section">
        <h4 class="designer-props-title">Moldura / Máscara</h4>
        <p class="form-hint">Escolha imagem ou vídeo abaixo, ou arraste da aba Mídia para a moldura. Use Zoom / Deslocamento para enquadrar.</p>
        <div class="form-block">
          <label>Forma do recorte</label>
          <select id="dp-frame-shape">
            <option value="rect" ${shape === 'rect' ? 'selected' : ''}>Retangular</option>
            <option value="rounded" ${shape === 'rounded' ? 'selected' : ''}>Arredondado</option>
            <option value="circle" ${shape === 'circle' ? 'selected' : ''}>Circular</option>
            <option value="ellipse" ${shape === 'ellipse' ? 'selected' : ''}>Elipse</option>
            <option value="star" ${shape === 'star' ? 'selected' : ''}>Estrela</option>
            <option value="hexagon" ${shape === 'hexagon' ? 'selected' : ''}>Hexágono</option>
            <option value="diamond" ${shape === 'diamond' ? 'selected' : ''}>Losango</option>
          </select>
        </div>
        ${shape === 'rounded' || shape === 'rect' ? `<div class="form-block"><label>Arredondamento</label><input type="range" id="dp-frame-radius" min="0" max="120" value="${shape === 'rect' ? 0 : radius}" /><span class="designer-range-val">${shape === 'rect' ? 0 : radius}px</span></div>` : ''}
        <div class="form-block form-row-2">
          <div>
            <label>Cor da borda</label>
            <input type="color" id="dp-frame-stroke" value="${strokeColor}" />
          </div>
          <div>
            <label>Espessura</label>
            <input type="number" id="dp-frame-stroke-w" min="0" max="40" step="1" value="${strokeWidth}" />
          </div>
        </div>
        <div class="form-block">
          <label><input type="checkbox" id="dp-frame-dashed" ${dashed ? 'checked' : ''} /> Traçado tracejado</label>
        </div>
        <div class="form-block"><label>Papel (slot)</label>
          <select id="dp-frame-role">
            <option value="">Nenhum (fixo)</option>
            <option value="photo" ${role === 'photo' ? 'selected' : ''}>Foto (conteúdo)</option>
          </select>
        </div>
        <div class="form-block">
          <label>Ajuste da mídia</label>
          <select id="dp-frame-fit">
            <option value="cover" ${fit === 'cover' ? 'selected' : ''}>Preencher (cover)</option>
            <option value="contain" ${fit === 'contain' ? 'selected' : ''}>Conter (contain)</option>
          </select>
        </div>
        <div class="form-block"><label>Zoom da mídia</label><input type="range" id="dp-frame-scale" min="0.5" max="3" step="0.05" value="${scale}" /><span class="designer-range-val">${Math.round(scale * 100)}%</span></div>
        <div class="form-block form-row-2">
          <div><label>Desloc. X</label><input type="number" id="dp-frame-offx" value="${offX}" step="1" /></div>
          <div><label>Desloc. Y</label><input type="number" id="dp-frame-offy" value="${offY}" step="1" /></div>
        </div>
        <div class="form-block designer-frame-actions">
          <button type="button" class="btn btn-secondary btn-sm" id="dp-frame-pick">Escolher imagem/vídeo…</button>
          ${hasFill ? `<button type="button" class="btn btn-secondary btn-sm" id="dp-frame-fill-edit">${fillEdit ? 'Concluir ajuste' : 'Reposicionar mídia'}</button>` : ''}
          ${hasFill ? '<button type="button" class="btn btn-secondary btn-sm" id="dp-frame-clear">Remover mídia</button>' : ''}
          <button type="button" class="btn btn-secondary btn-sm" id="dp-frame-mask">Trocar moldura PNG…</button>
        </div>
      </section>`;
  },

  bindFrame() {
    const emitProps = (patch) => this.onChange?.({ type: 'frameProps', patch });

    // Reutiliza inputs (evita vazamento e handlers fantasmas a cada remount)
    if (!this._framePickInput) {
      this._framePickInput = document.createElement('input');
      this._framePickInput.type = 'file';
      this._framePickInput.accept = 'image/*,video/mp4,video/webm,video/quicktime';
      this._framePickInput.hidden = true;
      document.body.appendChild(this._framePickInput);
    }
    if (!this._frameMaskInput) {
      this._frameMaskInput = document.createElement('input');
      this._frameMaskInput.type = 'file';
      this._frameMaskInput.accept = 'image/png,image/webp,image/jpeg';
      this._frameMaskInput.hidden = true;
      document.body.appendChild(this._frameMaskInput);
    }
    const input = this._framePickInput;
    const maskInput = this._frameMaskInput;

    this.container.querySelector('#dp-frame-pick')?.addEventListener('click', () => input.click());
    input.onchange = (e) => {
      const f = e.target.files?.[0];
      if (!f) return;
      const isVideo = f.type.startsWith('video/');
      const reader = new FileReader();
      reader.onload = () => {
        this.onChange?.({ type: 'frameFill', src: reader.result, kind: isVideo ? 'video' : 'image' });
      };
      reader.readAsDataURL(f);
      e.target.value = '';
    };

    this.container.querySelector('#dp-frame-mask')?.addEventListener('click', () => maskInput.click());
    maskInput.onchange = (e) => {
      const f = e.target.files?.[0];
      if (!f) return;
      const reader = new FileReader();
      reader.onload = () => {
        emitProps({ maskSrc: reader.result });
      };
      reader.readAsDataURL(f);
      e.target.value = '';
    };

    this.container.querySelector('#dp-frame-clear')?.addEventListener('click', () => {
      this.onChange?.({ type: 'frameClear' });
    });

    this.container.querySelector('#dp-frame-fill-edit')?.addEventListener('click', () => {
      this.onChange?.({ type: 'frameFillEdit', enabled: !this.node.attrs._fillEdit });
    });

    this.container.querySelector('#dp-frame-shape')?.addEventListener('change', (e) => {
      const clipShape = e.target.value;
      const patch = { clipShape };
      if (clipShape === 'rounded' && !this.node.attrs.cornerRadius) patch.cornerRadius = 24;
      this.onChange?.({ type: 'frameProps', patch, rerender: true });
    });

    this.container.querySelector('#dp-frame-stroke')?.addEventListener('input', (e) => {
      emitProps({ stroke: e.target.value });
    });

    this.container.querySelector('#dp-frame-stroke-w')?.addEventListener('input', (e) => {
      emitProps({ strokeWidth: Number(e.target.value) || 0 });
    });

    this.container.querySelector('#dp-frame-dashed')?.addEventListener('change', (e) => {
      emitProps({ strokeDashed: !!e.target.checked });
    });

    this.container.querySelector('#dp-frame-role')?.addEventListener('change', (e) => {
      this.onChange?.({ type: 'frameProps', patch: { role: e.target.value || '' }, rerender: false });
    });

    this.container.querySelector('#dp-frame-fit')?.addEventListener('change', (e) => {
      emitProps({ fillFit: e.target.value });
    });

    this.container.querySelector('#dp-frame-scale')?.addEventListener('input', (e) => {
      const v = Number(e.target.value);
      const label = this.container.querySelector('#dp-frame-scale')?.nextElementSibling;
      if (label) label.textContent = `${Math.round(v * 100)}%`;
      emitProps({ fillScale: v });
    });

    this.container.querySelector('#dp-frame-offx')?.addEventListener('input', (e) => {
      emitProps({ fillOffsetX: Number(e.target.value) || 0 });
    });

    this.container.querySelector('#dp-frame-offy')?.addEventListener('input', (e) => {
      emitProps({ fillOffsetY: Number(e.target.value) || 0 });
    });

    this.container.querySelector('#dp-frame-radius')?.addEventListener('input', (e) => {
      const v = Number(e.target.value);
      const label = e.target.nextElementSibling;
      if (label) label.textContent = `${v}px`;
      const patch = { cornerRadius: v };
      // Não muda clipShape no meio do drag se o slider já está visível (rect+rounded)
      if (this.node.attrs.clipShape === 'rect' && v > 0) {
        this.node.attrs.clipShape = 'rounded';
        patch.clipShape = 'rounded';
      }
      emitProps(patch);
    });
  },



  positionSection() {
    const sx = this.node.scaleX?.() || 1;
    const sy = this.node.scaleY?.() || 1;
    const isFrame = this.node.name?.() === 'frame';
    const rawW = isFrame ? (this.node.attrs.width || 400) : (this.node.width?.() || 0);
    const rawH = isFrame ? (this.node.attrs.height || 400) : (this.node.height?.() || 0);
    const w = Math.round(Math.abs(rawW * sx));
    const h = Math.round(Math.abs(rawH * sy));
    return `
      <details class="designer-props-accordion" open>
        <summary>Posição &amp; tamanho</summary>
        <div class="form-block form-row-2">
          <div><label>X</label><input type="number" id="dp-x" value="${Math.round(this.node.x())}" /></div>
          <div><label>Y</label><input type="number" id="dp-y" value="${Math.round(this.node.y())}" /></div>
        </div>
        <div class="form-block form-row-2">
          <div><label>Largura</label><input type="number" id="dp-w" value="${w}" min="1" /></div>
          <div><label>Altura</label><input type="number" id="dp-h" value="${h}" min="1" /></div>
        </div>
        <div class="form-block"><label>Rotação</label><input type="range" id="dp-rotation" min="-180" max="180" value="${Math.round(this.node.rotation?.() || 0)}" />
          <span class="designer-range-val">${Math.round(this.node.rotation?.() || 0)}°</span>
        </div>
        <div class="form-block"><label>Atalhos de rotação</label>
          <div class="designer-align-btns" style="flex-wrap:wrap;gap:.35rem">
            <button type="button" class="btn btn-secondary btn-sm" id="dp-rot-m90">−90°</button>
            <button type="button" class="btn btn-secondary btn-sm" id="dp-rot-p90">+90°</button>
            <button type="button" class="btn btn-secondary btn-sm" id="dp-rot-0">0°</button>
          </div>
        </div>
      </details>`;
  },

  effectsSection() {
    const sh = getShadowState(this.node);
    const blur = Math.round(sh.blur || 0);
    let color = sh.color || 'rgba(0,0,0,0.55)';
    if (color.startsWith('rgba') || color.startsWith('rgb')) {
      // keep as-is for display; color input needs hex
      color = '#000000';
    } else if (!/^#[0-9a-fA-F]{6}$/.test(color)) {
      color = '#000000';
    }
    return `
      <details class="designer-props-accordion" open>
        <summary>Efeitos</summary>
        <div class="form-block"><label>Opacidade</label><input type="range" id="dp-opacity" min="0" max="1" step="0.05" value="${this.node.opacity?.() ?? 1}" />
          <span class="designer-range-val" id="dp-opacity-val">${Math.round((this.node.opacity?.() ?? 1) * 100)}%</span>
        </div>
        <div class="form-block"><label>Sombra (blur)</label>
          <input type="range" id="dp-shadow" min="0" max="40" step="1" value="${blur}" />
          <span class="designer-range-val" id="dp-shadow-val">${blur}px</span>
        </div>
        <div class="form-block form-row-2">
          <div><label>Sombra X</label><input type="number" id="dp-shadow-x" value="${Math.round(sh.offsetX || 0)}" step="1" /></div>
          <div><label>Sombra Y</label><input type="number" id="dp-shadow-y" value="${Math.round(sh.offsetY || 0)}" step="1" /></div>
        </div>
        <div class="form-block"><label>Cor da sombra</label><input type="color" id="dp-shadow-color" value="${color}" /></div>
        <div class="form-block"><label>Espelhar / inverter</label>
          <div class="designer-align-btns" style="flex-wrap:wrap;gap:.35rem">
            <button type="button" class="btn btn-secondary btn-sm" id="dp-flip-h" title="Espelhar horizontal">Espelhar H</button>
            <button type="button" class="btn btn-secondary btn-sm" id="dp-flip-v" title="Espelhar vertical">Espelhar V</button>
            <button type="button" class="btn btn-secondary btn-sm" id="dp-flip-invert" title="Inverter (espelhar H)">Inverter</button>
          </div>
        </div>
      </details>`;
  },

  commonSection() {

    return `${this.positionSection()}${this.effectsSection()}`;

  },



  fontOptions(selected) {
    const custom = [...new Set([...(this.fonts || []), ...getCustomFontList()].filter(Boolean))];
    const system = [...new Set([...SYSTEM_FONT_STACKS, ...FONT_STACKS].filter(Boolean))]
      .filter((f) => !custom.includes(f));
    const all = [...custom, ...system];
    if (selected && !all.includes(selected)) all.unshift(selected);
    const opt = (f) => `<option value="${escAttr(f)}" ${f === selected ? 'selected' : ''}>${esc(f)}</option>`;
    let html = '';
    if (custom.length) {
      html += `<optgroup label="Pasta fonts/">${custom.map(opt).join('')}</optgroup>`;
    }
    if (system.length) {
      html += `<optgroup label="Sistema">${system.map(opt).join('')}</optgroup>`;
    }
    if (!html && selected) html = opt(selected);
    return html;
  },



  bindCanvas() {

    const emitBg = (bg) => this.onBackground?.(bg);

    const current = () => ({ ...(this.background || { type: 'color', value: '#0a0a0a' }) });

    this.container.querySelectorAll('.designer-bg-btn[data-bg-color]').forEach((btn) => {

      btn.onclick = () => emitBg({ type: 'color', value: btn.dataset.bgColor, dim: current().dim || 0 });

    });

    this.container.querySelectorAll('.designer-bg-btn[data-bg-grad]').forEach((btn) => {

      btn.onclick = () => emitBg({ type: 'gradient', preset: btn.dataset.bgGrad, dim: current().dim || 0 });

    });

    const colorIn = this.container.querySelector('#dp-bg-color');

    const hexIn = this.container.querySelector('#dp-bg-hex');

    colorIn?.addEventListener('input', (e) => {

      hexIn.value = e.target.value;

      emitBg({ type: 'color', value: e.target.value, dim: Number(this.container.querySelector('#dp-bg-dim')?.value || 0) });

    });

    hexIn?.addEventListener('change', (e) => emitBg({ type: 'color', value: e.target.value, dim: Number(this.container.querySelector('#dp-bg-dim')?.value || 0) }));

    this.container.querySelector('#dp-bg-dim')?.addEventListener('input', (e) => {

      const v = this.container.querySelector('#dp-bg-dim-val');

      if (v) v.textContent = `${Math.round(Number(e.target.value) * 100)}%`;

      const bg = current();

      emitBg({ ...bg, dim: Number(e.target.value) });

    });

    this.container.querySelector('#dp-bg-fit')?.addEventListener('change', (e) => {

      const bg = current();

      if (bg.type === 'image' || bg.type === 'video') emitBg({ ...bg, fit: e.target.value });

    });

    this.container.querySelector('#dp-bg-pick-image')?.addEventListener('click', () => {

      this.onBackground?.({ type: 'pick-image', dim: Number(this.container.querySelector('#dp-bg-dim')?.value || 0), fit: this.container.querySelector('#dp-bg-fit')?.value || 'cover' });

    });

    this.container.querySelector('#dp-bg-pick-video')?.addEventListener('click', () => {

      this.onBackground?.({ type: 'pick-video', dim: Number(this.container.querySelector('#dp-bg-dim')?.value || 0.35), fit: this.container.querySelector('#dp-bg-fit')?.value || 'cover' });

    });

  },



  bindText() {

    const emit = () => this.onChange?.(this.node);

    this.bindCanvas();

    this.bindCommon();

    this.bindSwatches('dp-text', (c) => { this.node.fill(c); emit(); });



    this.container.querySelector('#dp-text')?.addEventListener('input', (e) => {

      this.node.text(e.target.value);

      if ((this.node.getAttr?.('textFit') || this.node.attrs?.textFit) === 'fit') {
        this.onChange?.({ type: 'fitText' });
      } else {
        emit();
      }

    });

    this.container.querySelector('#dp-size')?.addEventListener('input', (e) => {

      this.node.fontSize(Number(e.target.value));

      emit();

    });

    const applyFontPair = async () => {
      const { fontFamily, fontWeight, fontStyle } = readFontPickerPair(this.container, {
        familySelector: '#dp-font',
        variantSelector: '#dp-font-variant',
      });
      const fam = fontFamily || 'Segoe UI';
      await preloadFontsForCanvas([fam]);
      this.node.fontFamily(fam);
      const bold = (fontWeight || 400) >= 600;
      const italic = fontStyle === 'italic';
      const konvaStyle = bold && italic ? 'bold italic' : bold ? 'bold' : italic ? 'italic' : 'normal';
      this.node.fontStyle(konvaStyle);
      this.node.setAttr?.('fontWeight', fontWeight || 400);
      this.node.setAttr?.('fontStyleDetail', fontStyle || 'normal');
      emit();
    };

    bindFontPickerPair(this.container, {
      familySelector: '#dp-font',
      variantSelector: '#dp-font-variant',
      onChange: () => { void applyFontPair(); },
    });

    this.container.querySelector('#dp-letter-spacing')?.addEventListener('input', (e) => {
      const v = Math.round(Number(e.target.value) || 0);
      if (this.node.letterSpacing) this.node.letterSpacing(v);
      else this.node.setAttr('letterSpacing', v);
      const lab = this.container.querySelector('#dp-letter-spacing-val');
      if (lab) lab.textContent = String(v);
      emit();
    });

    const nudgeLetter = (delta) => {
      const el = this.container.querySelector('#dp-letter-spacing');
      if (!el) return;
      const next = Math.max(-4, Math.min(40, Math.round(Number(el.value) || 0) + delta));
      el.value = String(next);
      el.dispatchEvent(new Event('input', { bubbles: true }));
    };
    this.container.querySelector('#dp-letter-dec')?.addEventListener('click', () => nudgeLetter(-1));
    this.container.querySelector('#dp-letter-inc')?.addEventListener('click', () => nudgeLetter(1));

    this.container.querySelector('#dp-line-height')?.addEventListener('input', (e) => {
      const v = Math.round((Number(e.target.value) || 1) * 100) / 100;
      if (this.node.lineHeight) this.node.lineHeight(v);
      else this.node.setAttr('lineHeight', v);
      const lab = this.container.querySelector('#dp-line-height-val');
      if (lab) lab.textContent = v.toFixed(2);
      emit();
    });

    const nudgeLine = (delta) => {
      const el = this.container.querySelector('#dp-line-height');
      if (!el) return;
      const next = Math.max(0.8, Math.min(3, Math.round(((Number(el.value) || 1.2) + delta) * 100) / 100));
      el.value = String(next);
      el.dispatchEvent(new Event('input', { bubbles: true }));
    };
    this.container.querySelector('#dp-line-dec')?.addEventListener('click', () => nudgeLine(-0.05));
    this.container.querySelector('#dp-line-inc')?.addEventListener('click', () => nudgeLine(0.05));

    this.container.querySelector('#dp-text-stroke')?.addEventListener('input', (e) => {
      this.node.stroke(e.target.value);
      if (!(this.node.strokeWidth?.() > 0)) this.node.strokeWidth(1);
      emit();
    });

    this.container.querySelector('#dp-text-stroke-w')?.addEventListener('input', (e) => {
      const w = Number(e.target.value) || 0;
      this.node.strokeWidth(w);
      if (w <= 0) this.node.stroke(null);
      emit();
    });

    this.container.querySelector('#dp-role')?.addEventListener('change', (e) => {

      this.node.setAttr('role', e.target.value);

      emit();

    });

    this.container.querySelector('#dp-fill')?.addEventListener('input', (e) => {

      this.node.fill(e.target.value);

      this.container.querySelector('#dp-fill-hex').value = e.target.value;

      emit();

    });

    this.container.querySelectorAll('.designer-align-btn[data-align]').forEach((btn) => {

      btn.onclick = () => {

        this.node.align(btn.dataset.align);

        this.container.querySelectorAll('.designer-align-btn[data-align]').forEach((b) => b.classList.toggle('is-active', b === btn));

        emit();

      };

    });

    this.container.querySelector('#dp-text-fit-wrap')?.addEventListener('click', () => {
      this.node.setAttr('textFit', 'wrap');
      this.container.querySelector('#dp-text-fit-wrap')?.classList.add('is-active');
      this.container.querySelector('#dp-text-fit-auto')?.classList.remove('is-active');
      this.onChange?.({ type: 'textFit', mode: 'wrap' });
    });

    this.container.querySelector('#dp-text-fit-auto')?.addEventListener('click', () => {
      this.node.setAttr('textFit', 'fit');
      this.container.querySelector('#dp-text-fit-auto')?.classList.add('is-active');
      this.container.querySelector('#dp-text-fit-wrap')?.classList.remove('is-active');
      this.onChange?.({ type: 'textFit', mode: 'fit' });
    });

    this.container.querySelector('#dp-fit-text-now')?.addEventListener('click', () => {
      this.node.setAttr('textFit', 'fit');
      this.container.querySelector('#dp-text-fit-auto')?.classList.add('is-active');
      this.container.querySelector('#dp-text-fit-wrap')?.classList.remove('is-active');
      this.onChange?.({ type: 'fitText' });
    });

  },



  bindShape(cls) {

    const emit = () => this.onChange?.(this.node);

    this.bindSwatches('dp-fill-shape', (c) => { if (this.node.fill) { this.node.fill(c); emit(); } });

    this.bindSwatches('dp-stroke', (c) => { this.node.stroke(c); emit(); });



    this.container.querySelector('#dp-shape-fill')?.addEventListener('input', (e) => {

      this.node.fill(e.target.value);

      emit();

    });

    this.container.querySelector('#dp-stroke')?.addEventListener('input', (e) => {

      this.node.stroke(e.target.value);

      emit();

    });

    this.container.querySelector('#dp-stroke-w')?.addEventListener('input', (e) => {

      this.node.strokeWidth(Number(e.target.value));

      emit();

    });

    this.container.querySelector('#dp-radius')?.addEventListener('input', (e) => {
      const v = Number(e.target.value);
      this.node.cornerRadius(v);
      const label = e.target.nextElementSibling;
      if (label?.classList?.contains('designer-range-val')) label.textContent = `${v}px`;
      emit();
    });

    this.container.querySelector('#dp-radius-c')?.addEventListener('input', (e) => {
      this.node.radius(Number(e.target.value));
      emit();
    });
  },



  bindCommon() {

    const emit = () => this.onChange?.(this.node);

    this.bindCanvas();



    this.container.querySelector('#dp-x')?.addEventListener('input', (e) => {

      this.node.x(Number(e.target.value));

      emit();

    });

    this.container.querySelector('#dp-y')?.addEventListener('input', (e) => {

      this.node.y(Number(e.target.value));

      emit();

    });

    this.container.querySelector('#dp-w')?.addEventListener('input', (e) => {
      const w = Number(e.target.value);
      if (this.node.name?.() === 'frame' && this.onChange) {
        this.onChange({ type: 'frameProps', patch: { width: w } });
        return;
      }
      if (this.node.width) this.node.width(w);
      emit();
    });

    this.container.querySelector('#dp-h')?.addEventListener('input', (e) => {
      const h = Number(e.target.value);
      if (this.node.name?.() === 'frame' && this.onChange) {
        this.onChange({ type: 'frameProps', patch: { height: h } });
        return;
      }
      if (this.node.height) this.node.height(h);
      emit();
    });

    this.container.querySelector('#dp-opacity')?.addEventListener('input', (e) => {

      this.node.opacity(Number(e.target.value));

      const v = this.container.querySelector('#dp-opacity-val');

      if (v) v.textContent = `${Math.round(Number(e.target.value) * 100)}%`;

      emit();

    });

    this.container.querySelector('#dp-shadow')?.addEventListener('input', (e) => {
      if (!this.node) return;
      const blur = Number(e.target.value);
      const col = this.container.querySelector('#dp-shadow-color')?.value || '#000000';
      applyShadowState(this.node, {
        blur,
        color: blur > 0 ? col : 'transparent',
      });
      const v = this.container.querySelector('#dp-shadow-val');
      if (v) v.textContent = `${blur}px`;
      emit();
    });

    this.container.querySelector('#dp-shadow-x')?.addEventListener('input', (e) => {
      if (!this.node) return;
      const sh = getShadowState(this.node);
      applyShadowState(this.node, {
        offset: { x: Number(e.target.value) || 0, y: sh.offsetY || 0 },
        blur: Math.max(sh.blur || 0, 1),
      });
      emit();
    });

    this.container.querySelector('#dp-shadow-y')?.addEventListener('input', (e) => {
      if (!this.node) return;
      const sh = getShadowState(this.node);
      applyShadowState(this.node, {
        offset: { x: sh.offsetX || 0, y: Number(e.target.value) || 0 },
        blur: Math.max(sh.blur || 0, 1),
      });
      emit();
    });

    this.container.querySelector('#dp-shadow-color')?.addEventListener('input', (e) => {
      if (!this.node) return;
      const sh = getShadowState(this.node);
      applyShadowState(this.node, {
        color: e.target.value,
        blur: sh.blur || 0,
      });
      emit();
    });

    this.container.querySelector('#dp-image-replace')?.addEventListener('click', () => {
      const input = document.createElement('input');
      input.type = 'file';
      input.accept = 'image/*';
      input.hidden = true;
      document.body.appendChild(input);
      input.onchange = (ev) => {
        const f = ev.target.files?.[0];
        if (!f) return;
        const reader = new FileReader();
        reader.onload = () => this.onChange?.({ type: 'imageReplace', src: reader.result });
        reader.readAsDataURL(f);
        ev.target.value = '';
        input.remove();
      };
      input.click();
    });

    this.container.querySelector('#dp-rotation')?.addEventListener('input', (e) => {

      this.node.rotation(Number(e.target.value));

      emit();

    });

    this.container.querySelector('#dp-rot-m90')?.addEventListener('click', () => {
      this.onChange?.({ type: 'rotateBy', delta: -90 });
    });
    this.container.querySelector('#dp-rot-p90')?.addEventListener('click', () => {
      this.onChange?.({ type: 'rotateBy', delta: 90 });
    });
    this.container.querySelector('#dp-rot-0')?.addEventListener('click', () => {
      this.onChange?.({ type: 'rotateReset' });
    });
    this.container.querySelector('#dp-flip-h')?.addEventListener('click', () => {
      this.onChange?.({ type: 'flip', axis: 'h' });
    });
    this.container.querySelector('#dp-flip-v')?.addEventListener('click', () => {
      this.onChange?.({ type: 'flip', axis: 'v' });
    });
    this.container.querySelector('#dp-flip-invert')?.addEventListener('click', () => {
      this.onChange?.({ type: 'flip', axis: 'h' });
    });

  }
};
