/** Painel de propriedades — texto, formas, cores, fundo, fontes */



import { CHURCH_PALETTE, BG_PRESETS, GRADIENT_BG_PRESETS, FONT_STACKS, colorSwatchesHtml } from '.././designer-colors.js';
import { preloadFontsForCanvas, getCustomFontList, SYSTEM_FONT_STACKS } from '../../core/fonts.js';
import { fontPickerPairHtml } from '../../core/font-picker-ui.js';
import { faBtnIcon, DS_ICONS as I } from '.././fa-icon.js';
import { getShadowState, applyShadowState } from '.././konva-shadow.js';
import { esc, escAttr, toHexInput } from './class-bind.js';

export class PropertiesPanel {

  constructor(container, { onChange, onBackground, fonts = [] } = {}) {

    this.container = container;

    this.onChange = onChange;

    this.onBackground = onBackground;

    this.fonts = fonts;

    this.node = null;

    this.background = null;

    this.activeTab = 'design';

  }



  setActiveTab(tab) {

    this.activeTab = tab || 'design';

    if (this.node) this.render();

    else this.renderCanvasOnly();

  }



  wrapPropsTabs({ design = '', position = '', effects = '' }) {

    const tab = this.activeTab || 'design';

    return `

      <div class="designer-props-panels">

        <div class="designer-props-tab-pane${tab === 'design' ? ' is-active' : ''}" data-props-panel="design">${design}</div>

        <div class="designer-props-tab-pane${tab === 'position' ? ' is-active' : ''}" data-props-panel="position">${position}</div>

        <div class="designer-props-tab-pane${tab === 'effects' ? ' is-active' : ''}" data-props-panel="effects">${effects}</div>

      </div>`;

  }



  setFonts(fonts = []) {

    this.fonts = fonts;

    if (this.node) this.render();

  }



  setNode(node, opts = {}) {
    const prevId = this.node?.id?.() ?? this.node?.attrs?.id;
    const nextId = node?.id?.() ?? node?.attrs?.id;
    const sameNode = !!(node && this.node && (node === this.node || (prevId && prevId === nextId)));
    this.node = node;

    if (!node) {
      this.renderCanvasOnly();
      return;
    }

    // soft: mantém DOM/foco (sliders) — só atualiza referência do nó
    if (opts.soft && sameNode && this.container?.querySelector('.designer-props-panels')) {
      return;
    }

    this.render();
  }

  /** Re-render explícito (mudança estrutural de UI: forma, slots, etc.). */
  forceRender() {
    if (!this.node) {
      this.renderCanvasOnly();
      return;
    }
    this.render();
  }



  setBackground(bg, opts = {}) {

    this.background = bg;

    if (this.node) return;

    // soft: não remonta o DOM durante arraste de sliders (dim, etc.)
    if (opts.soft && this.container?.querySelector('#dp-bg-dim')) {
      const dim = Number(bg?.dim ?? 0) || 0;
      const dimEl = this.container.querySelector('#dp-bg-dim');
      const dimVal = this.container.querySelector('#dp-bg-dim-val');
      if (dimEl && document.activeElement !== dimEl) dimEl.value = String(dim);
      if (dimVal) dimVal.textContent = `${Math.round(dim * 100)}%`;
      return;
    }

    this.renderCanvasOnly();

  }



  renderCanvasOnly() {

    if (!this.container) return;

    this.container.innerHTML = this.canvasSection()
      + '<div class="designer-empty designer-empty--guide">'
      + '<strong>Nenhum elemento selecionado</strong>'
      + '<span>O painel mostra o <em>fundo</em> do slide (pré-culto). Clique em um texto, forma ou card no canvas para editar tipografia e posição.</span>'
      + '</div>';

    this.bindCanvas();

  }



  render() {

    if (!this.container) return;

    if (!this.node) {

      this.renderCanvasOnly();

      return;

    }



    const cls = this.node.getClassName?.();

    void cls;



    if (cls === 'Text') {

      this.container.innerHTML = this.wrapPropsTabs({

        design: this.canvasSection() + this.textSection(),

        position: this.positionSection(),

        effects: this.effectsSection(),

      });

      this.bindText();

      return;

    }



    if (cls === 'Image') {

      this.container.innerHTML = this.wrapPropsTabs({

        design: this.canvasSection() + this.imageSection(),

        position: this.positionSection(),

        effects: this.effectsSection(),

      });

      this.bindCommon();

      return;

    }



    if (cls === 'Rect' || cls === 'Circle' || cls === 'Line') {

      this.container.innerHTML = this.wrapPropsTabs({

        design: this.canvasSection() + this.shapeSection(cls),

        position: this.positionSection(),

        effects: this.effectsSection(),

      });

      this.bindCommon();

      this.bindShape(cls);

      return;

    }

    if (cls === 'Group' && this.node.name?.() === 'photo-card') {

      this.container.innerHTML = this.wrapPropsTabs({

        design: this.photoCardSection() + this.canvasSectionCollapsed(),

        position: this.positionSection(),

        effects: this.effectsSection(),

      });

      this.bindCommon();

      this.bindPhotoCard();

      this.bindCanvas();

      return;

    }

    if (cls === 'Group' && this.node.name?.() === 'frame') {

      this.container.innerHTML = this.wrapPropsTabs({

        design: this.frameSection() + this.canvasSectionCollapsed(),

        position: this.positionSection(),

        effects: this.effectsSection(),

      });

      this.bindCommon();

      this.bindFrame();

      this.bindCanvas();

      return;

    }



    this.container.innerHTML = this.wrapPropsTabs({

      design: this.canvasSection(),

      position: this.positionSection(),

      effects: this.effectsSection(),

    });

    this.bindCommon();

  }



  canvasSection() {

    const bg = this.background || { type: 'color', value: '#0a0a0a' };

    const bgVal = bg.type === 'color' ? bg.value : '#0a0a0a';

    const dim = Number(bg.dim || 0);

    const fit = bg.fit === 'contain' ? 'contain' : 'cover';

    return `

      <section class="designer-props-section">

        <h4 class="designer-props-title">Fundo do slide</h4>

        <div class="designer-bg-presets">

          ${BG_PRESETS.map((b) =>

            `<button type="button" class="designer-bg-btn" data-bg-color="${b.value}" title="${b.label}">${b.label}</button>`

          ).join('')}

        </div>

        <p class="designer-props-sub">Gradientes</p>

        <div class="designer-bg-presets">

          ${GRADIENT_BG_PRESETS.map((b) =>

            `<button type="button" class="designer-bg-btn designer-bg-grad" data-bg-grad="${b.id}" title="${b.label}">${b.label}</button>`

          ).join('')}

        </div>

        <div class="form-block">

          <label>Cor sólida</label>

          <div class="designer-color-row">

            <input type="color" id="dp-bg-color" value="${toHexInput(bgVal)}" />

            <input type="text" id="dp-bg-hex" value="${escAttr(bgVal || '#0a0a0a')}" class="designer-hex-input" />

          </div>

        </div>

        <div class="form-block form-row-2">

          <div><label>Escurecer (dim)</label>

            <input type="range" id="dp-bg-dim" min="0" max="0.8" step="0.05" value="${dim}" />

            <span class="designer-range-val" id="dp-bg-dim-val">${Math.round(dim * 100)}%</span>

          </div>

          <div><label>Encaixe imagem</label>

            <select id="dp-bg-fit">

              <option value="cover" ${fit === 'cover' ? 'selected' : ''}>Cobrir</option>

              <option value="contain" ${fit === 'contain' ? 'selected' : ''}>Conter</option>

            </select>

          </div>

        </div>

        <button type="button" class="btn btn-secondary btn-sm" id="dp-bg-pick-image">Escolher imagem de fundo…</button>

        <button type="button" class="btn btn-secondary btn-sm" id="dp-bg-pick-video">Fundo animado (vídeo)…</button>

        ${bg.type === 'video' && bg.src ? `<p class="form-hint">Vídeo ativo${bg.mediaId ? ` · ${escAttr(bg.mediaId)}` : ''}</p>` : ''}

      </section>`;

  }

  fontPickerHtmlForNode() {
    const family = this.node.fontFamily() || '';
    const styleStr = String(this.node.fontStyle?.() || 'normal');
    const weight = Number(this.node.getAttr?.('fontWeight'))
      || (styleStr.includes('bold') ? 700 : 400);
    const fontStyle = styleStr.includes('italic') ? 'italic' : 'normal';
    return fontPickerPairHtml(family, {
      familyId: 'dp-font',
      variantId: 'dp-font-variant',
      fontWeight: weight,
      fontStyle,
      includeEmpty: false,
      extra: this.fonts || [],
    });
  }

  /** Fundo do slide recolhido — não esconde as props do card/moldura */
  canvasSectionCollapsed() {
    return `<details class="designer-props-accordion"><summary>Fundo do slide</summary>${this.canvasSection()}</details>`;
  }

  textSection() {
    return `

      <section class="designer-props-section">

        <h4 class="designer-props-title">Texto</h4>

        <div class="form-block"><label>Conteúdo</label><textarea id="dp-text" rows="4">${esc(this.node.text())}</textarea></div>

        <div class="form-block"><label>Papel (slot de conteúdo)</label>
          <select id="dp-role">
            <option value="">Nenhum (fixo)</option>
            <optgroup label="Geral">
              <option value="title" ${this.node.attrs?.role === 'title' ? 'selected' : ''}>Título genérico</option>
              <option value="body" ${this.node.attrs?.role === 'body' ? 'selected' : ''}>Corpo / subtítulo</option>
              <option value="caption" ${this.node.attrs?.role === 'caption' ? 'selected' : ''}>Legenda</option>
            </optgroup>
            <optgroup label="Bíblia / Introito">
              <option value="reference" ${this.node.attrs?.role === 'reference' ? 'selected' : ''}>Referência bíblica</option>
              <option value="verse" ${this.node.attrs?.role === 'verse' ? 'selected' : ''}>Texto bíblico</option>
            </optgroup>
            <optgroup label="Boas-vindas">
              <option value="years" ${this.node.attrs?.role === 'years' ? 'selected' : ''}>Anos / título</option>
              <option value="theme" ${this.node.attrs?.role === 'theme' ? 'selected' : ''}>Tema do culto</option>
              <option value="subtitle" ${this.node.attrs?.role === 'subtitle' ? 'selected' : ''}>Linha extra</option>
              <option value="badge" ${this.node.attrs?.role === 'badge' ? 'selected' : ''}>Badge</option>
              <option value="churchName" ${this.node.attrs?.role === 'churchName' ? 'selected' : ''}>Nome da igreja</option>
            </optgroup>
            <optgroup label="Mídia">
              <option value="logo" ${this.node.attrs?.role === 'logo' ? 'selected' : ''}>Logo</option>
              <option value="photo" ${this.node.attrs?.role === 'photo' ? 'selected' : ''}>Foto (moldura)</option>
            </optgroup>
            <optgroup label="Citação">
              <option value="quote" ${this.node.attrs?.role === 'quote' ? 'selected' : ''}>Citação</option>
              <option value="author" ${this.node.attrs?.role === 'author' ? 'selected' : ''}>Autor</option>
              <option value="ref" ${this.node.attrs?.role === 'ref' ? 'selected' : ''}>Referência</option>
            </optgroup>
          </select>
          <p class="form-hint" style="margin-top:.35rem">Na Ordem, o conteúdo deste papel atualiza automaticamente sem mudar o layout.</p>
        </div>

        <div class="form-block">
          <label>Tamanho</label>
          <input type="number" id="dp-size" value="${this.node.fontSize()}" min="12" max="240" />
        </div>

        <div class="form-block designer-font-picker">
          <label>Fonte</label>
          ${this.fontPickerHtmlForNode()}
          <p class="form-hint" style="margin-top:.35rem">Pasta da família + estilo (Regular, Bold, ExtraBold…)</p>
        </div>

        <div class="form-block"><label>Cor do texto</label>

          ${colorSwatchesHtml(this.node.fill(), 'dp-text')}

          <div class="designer-color-row">

            <input type="color" id="dp-fill" value="${toHexInput(this.node.fill())}" />

            <input type="text" id="dp-fill-hex" value="${escAttr(this.node.fill())}" class="designer-hex-input" />

          </div>

        </div>

        <div class="form-block"><label>Alinhamento do texto</label>

          <div class="designer-align-btns">

            ${['left', 'center', 'right'].map((a) => {

              const ico = a === 'left' ? I.alignLeft : a === 'right' ? I.alignRight : I.alignCenterH;

              return `<button type="button" class="designer-align-btn${this.node.align() === a ? ' is-active' : ''}" data-align="${a}">${faBtnIcon(ico)}</button>`;

            }).join('')}

          </div>

        </div>

        <div class="form-block designer-spacing-block">
          <label>Espaçamento</label>
          <div class="designer-spacing-row">
            <span class="designer-spacing-label" title="Espaço entre letras">Letras &lt;&gt;</span>
            <button type="button" class="designer-spacing-btn" id="dp-letter-dec" title="Diminuir espaço entre letras">−</button>
            <input type="range" id="dp-letter-spacing" min="-4" max="40" step="1" value="${Math.round(this.node.letterSpacing?.() || 0)}" />
            <button type="button" class="designer-spacing-btn" id="dp-letter-inc" title="Aumentar espaço entre letras">+</button>
            <span class="designer-range-val" id="dp-letter-spacing-val">${Math.round(this.node.letterSpacing?.() || 0)}</span>
          </div>
          <div class="designer-spacing-row">
            <span class="designer-spacing-label" title="Espaço entre linhas (Enter no texto)">Linhas ↕</span>
            <button type="button" class="designer-spacing-btn" id="dp-line-dec" title="Aproximar linhas">−</button>
            <input type="range" id="dp-line-height" min="0.8" max="3" step="0.05" value="${Number(this.node.lineHeight?.() || 1.2).toFixed(2)}" />
            <button type="button" class="designer-spacing-btn" id="dp-line-inc" title="Afastar linhas">+</button>
            <span class="designer-range-val" id="dp-line-height-val">${Number(this.node.lineHeight?.() || 1.2).toFixed(2)}</span>
          </div>
          <p class="form-hint" style="margin-top:.4rem">No conteúdo, use <strong>Enter</strong> para uma linha abaixo da outra. “Linhas ↕” controla o espaço vertical entre elas.</p>
        </div>

        <div class="form-block"><label>Contorno do texto</label>
          <div class="designer-color-row">
            <input type="color" id="dp-text-stroke" value="${toHexInput(this.node.stroke?.() || '#000000')}" />
            <input type="number" id="dp-text-stroke-w" value="${this.node.strokeWidth?.() || 0}" min="0" max="12" step="0.5" title="Espessura" />
          </div>
          <p class="form-hint" style="margin-top:.35rem">Espessura 0 = sem contorno.</p>
        </div>

        <div class="form-block"><label>Caixa de texto</label>
          <div class="designer-align-btns" style="flex-wrap:wrap;gap:.35rem">
            <button type="button" class="designer-align-btn${(this.node.getAttr?.('textFit') || this.node.attrs?.textFit || 'wrap') === 'wrap' ? ' is-active' : ''}" id="dp-text-fit-wrap" title="Largura fixa com quebra de linha">Caixa fixa</button>
            <button type="button" class="designer-align-btn${(this.node.getAttr?.('textFit') || this.node.attrs?.textFit) === 'fit' ? ' is-active' : ''}" id="dp-text-fit-auto" title="Ajustar largura ao conteúdo">Ajustar ao texto</button>
            <button type="button" class="btn btn-secondary btn-sm" id="dp-fit-text-now" title="Recalcular largura agora">Ajustar agora</button>
          </div>
          <p class="form-hint" style="margin-top:.35rem">Referências curtas usam caixa justa; versículos longos usam caixa fixa com wrap.</p>
        </div>

      </section>`;

  }



  shapeSection(cls) {

    const isLine = cls === 'Line';

    return `

      <section class="designer-props-section">

        <h4 class="designer-props-title">Forma</h4>

        ${!isLine ? `

        <div class="form-block"><label>Preenchimento</label>

          ${colorSwatchesHtml(this.node.fill?.(), 'dp-fill-shape')}

          <div class="designer-color-row">

            <input type="color" id="dp-shape-fill" value="${toHexInput(this.node.fill?.())}" />

          </div>

        </div>` : ''}

        <div class="form-block"><label>Contorno</label>

          ${colorSwatchesHtml(this.node.stroke?.(), 'dp-stroke')}

          <div class="designer-color-row">

            <input type="color" id="dp-stroke" value="${toHexInput(this.node.stroke?.() || '#d4c68d')}" />

            <input type="number" id="dp-stroke-w" value="${this.node.strokeWidth?.() || 0}" min="0" max="24" title="Espessura" />

          </div>

        </div>

        ${cls === 'Rect' ? `<div class="form-block"><label>Arredondamento</label><input type="range" id="dp-radius" min="0" max="80" value="${this.node.cornerRadius?.() || 0}" /></div>` : ''}

        ${cls === 'Circle' ? `<div class="form-block"><label>Raio</label><input type="number" id="dp-radius-c" value="${Math.round(this.node.radius?.() || 80)}" min="8" max="500" /></div>` : ''}

      </section>`;

  }



  imageSection() {
    const role = this.node.attrs?.role || '';
    const src = this.node.attrs?.src || this.node.image?.()?.src || '';
    return `
      <section class="designer-props-section">
        <h4 class="designer-props-title">Imagem</h4>
        <p class="form-hint">Arraste no canvas para posicionar. Use as alças para redimensionar.</p>
        <div class="form-block"><label>Papel (slot)</label>
          <select id="dp-role">
            <option value="">Nenhum (fixo)</option>
            <option value="logo" ${role === 'logo' ? 'selected' : ''}>Logo</option>
            <option value="photo" ${role === 'photo' ? 'selected' : ''}>Foto</option>
          </select>
        </div>
        <div class="form-block designer-frame-actions">
          <button type="button" class="btn btn-secondary btn-sm" id="dp-image-replace">Trocar imagem...</button>
        </div>
        ${src ? `<p class="form-hint" style="opacity:.7;font-size:.75rem;word-break:break-all">${String(src).slice(0, 64)}${String(src).length > 64 ? '…' : ''}</p>` : ''}
      </section>`;
  }

  photoCardSection() {
    const label = this.node.attrs.cardLabel || this.node.findOne('.card-label')?.text?.() || 'Pregador';
    const name = this.node.attrs.cardName || this.node.findOne('.card-name')?.text?.() || this.node.findOne('.card-title')?.text?.() || '';
    const from = this.node.attrs.cardFrom || this.node.findOne('.card-from')?.text?.() || this.node.findOne('.card-subtitle')?.text?.() || '';
    const fit = this.node.attrs.fillFit || 'cover';
    const scale = this.node.attrs.fillScale || 1;
    const offX = this.node.attrs.fillOffsetX || 0;
    const offY = this.node.attrs.fillOffsetY || 0;
    const photoSize = this.node.attrs.photoSize || 200;
    const labelSize = this.node.attrs.labelSize || 22;
    const titleSize = this.node.attrs.titleSize || 32;
    const subtitleSize = this.node.attrs.subtitleSize || 22;
    const cornerRadius = this.node.attrs.cornerRadius ?? 18;
    return `
      <p class="designer-props-hint">Card estilo mensagem bíblica — arraste o painel inteiro no canvas.</p>
      <details class="designer-props-accordion" open>
        <summary>Conteúdo</summary>
        <div class="form-block"><label>Rótulo</label><input type="text" id="dp-card-label" value="${escAttr(label)}" maxlength="40" placeholder="Pregador" /></div>
        <div class="form-block"><label>Nome</label><input type="text" id="dp-card-name" value="${escAttr(name)}" maxlength="80" /></div>
        <div class="form-block"><label>Igreja / cidade</label><input type="text" id="dp-card-from" value="${escAttr(from)}" maxlength="120" /></div>
        <div class="form-block form-row-2">
          <div><label>Tam. rótulo</label><input type="number" id="dp-card-label-size" min="12" max="36" value="${labelSize}" /></div>
          <div><label>Tam. nome</label><input type="number" id="dp-card-title-size" min="16" max="72" value="${titleSize}" /></div>
        </div>
        <div class="form-block"><label>Tam. igreja</label><input type="number" id="dp-card-subtitle-size" min="12" max="48" value="${subtitleSize}" /></div>
      </details>
      <details class="designer-props-accordion">
        <summary>Foto</summary>
        <div class="form-block"><button type="button" class="btn btn-secondary btn-sm" id="dp-card-pick">Escolher imagem...</button></div>
        <div class="form-block"><label>Tamanho da foto</label><input type="range" id="dp-card-photo-size" min="120" max="320" step="4" value="${photoSize}" /><span class="designer-range-val">${photoSize}px</span></div>
        <div class="form-block">
          <label>Ajuste da foto</label>
          <select id="dp-card-fit">
            <option value="cover" ${fit === 'cover' ? 'selected' : ''}>Preencher</option>
            <option value="contain" ${fit === 'contain' ? 'selected' : ''}>Conter</option>
          </select>
        </div>
        <div class="form-block"><label>Zoom foto</label><input type="range" id="dp-card-scale" min="0.5" max="3" step="0.05" value="${scale}" /><span class="designer-range-val">${Math.round(scale * 100)}%</span></div>
        <div class="form-block form-row-2">
          <div><label>Desloc. X</label><input type="number" id="dp-card-offx" value="${offX}" step="1" /></div>
          <div><label>Desloc. Y</label><input type="number" id="dp-card-offy" value="${offY}" step="1" /></div>
        </div>
      </details>
      <details class="designer-props-accordion">
        <summary>Visual</summary>
        <div class="form-block"><label>Arredondamento painel</label><input type="range" id="dp-card-radius" min="0" max="48" value="${cornerRadius}" /><span class="designer-range-val">${cornerRadius}px</span></div>
      </details>`;
  }

}