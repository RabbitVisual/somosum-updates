export { PropertiesPanel } from './class-head.js';
import { PropertiesPanel } from './class-head.js';
import { propertiesPanelTail } from './class-tail.js';
import { propertiesPanelBind } from './class-bind.js';
Object.assign(PropertiesPanel.prototype, propertiesPanelTail, propertiesPanelBind);
