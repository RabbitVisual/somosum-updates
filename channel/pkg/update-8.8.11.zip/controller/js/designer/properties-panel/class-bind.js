export const propertiesPanelBind = {
  bindSwatches(prefix, onPick) {
    this.container.querySelectorAll(`#${prefix}-swatches .designer-swatch`).forEach((btn) => {
      btn.onclick = () => {
        this.container.querySelectorAll(`#${prefix}-swatches .designer-swatch`).forEach((b) => b.classList.remove('is-active'));
        btn.classList.add('is-active');
        onPick(btn.dataset.color);
      };
    });
  },
};

export function esc(t) {
  const d = document.createElement('div');
  d.textContent = t ?? '';
  return d.innerHTML;
}

export function escAttr(t) {
  return esc(t).replace(/"/g, '&quot;');
}

export function toHexInput(color) {
  if (!color || color.startsWith('rgba')) return '#0a0a0a';
  if (color.startsWith('#')) return color.length === 7 ? color : '#0a0a0a';
  return '#ffffff';
}
