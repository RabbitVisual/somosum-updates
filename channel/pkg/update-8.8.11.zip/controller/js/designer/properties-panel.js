export { PropertiesPanel } from './properties-panel/index.js';
