/** Background and undo/redo history for CanvasEngine. */

import { DESIGN_W, DESIGN_H } from './slide-exporter.js';

const GRADIENT_PRESETS = {
  dark: { colors: ['#0a0a0a', '#1a1a1a'], angle: 180 },
  gold: { colors: ['#1a1510', '#3d2e18', '#1a1510'], angle: 160 },
  theme: { colors: ['#0c0a14', '#1a1530', '#12101a'], angle: 200 },
  charcoal: { colors: ['#0e0e0e', '#242424'], angle: 180 },
  communion: { colors: ['#080604', '#2a1810', '#0d0a08'], angle: 150 },
  bible: { colors: ['#0a1018', '#142030', '#0a1018'], angle: 190 },
};

function gradientEndpoints(angleDeg = 180) {
  const rad = ((angleDeg % 360) * Math.PI) / 180;
  const cx = DESIGN_W / 2;
  const cy = DESIGN_H / 2;
  const len = Math.max(DESIGN_W, DESIGN_H);
  return {
    start: { x: cx - Math.cos(rad) * len / 2, y: cy - Math.sin(rad) * len / 2 },
    end: { x: cx + Math.cos(rad) * len / 2, y: cy + Math.sin(rad) * len / 2 },
  };
}

function applySolidFill(rect, color) {
  rect.fill(color || '#0a0a0a');
  rect.fillLinearGradientColorStops(null);
  rect.fillPriority('color');
}

function applyGradientFill(rect, colors, angle = 180) {
  const stops = [];
  const list = colors?.length ? colors : ['#0a0a0a', '#1a1a1a'];
  list.forEach((c, i) => {
    stops.push(list.length === 1 ? 0 : i / (list.length - 1), c);
  });
  const { start, end } = gradientEndpoints(angle);
  rect.fillPriority('linear-gradient');
  rect.fillLinearGradientStartPoint(start);
  rect.fillLinearGradientEndPoint(end);
  rect.fillLinearGradientColorStops(stops);
  rect.fill(list[0]);
}

export const canvasBackgroundMethods = {

  _removeBgImage() {
    if (this._bgImageNode) {
      this._bgImageNode.destroy();
      this._bgImageNode = null;
    }
    if (this._bgDimNode) {
      this._bgDimNode.destroy();
      this._bgDimNode = null;
    }
  },

  _ensureBgDim(opacity) {
    if (opacity <= 0) {
      if (this._bgDimNode) {
        this._bgDimNode.destroy();
        this._bgDimNode = null;
      }
      return;
    }
    if (!this._bgDimNode) {
      this._bgDimNode = new Konva.Rect({
        x: 0,
        y: 0,
        width: DESIGN_W,
        height: DESIGN_H,
        fill: '#000',
        name: 'design-bg-dim',
        listening: false,
        perfectDrawEnabled: false,
      });
      this.layer.add(this._bgDimNode);
    }
    this._bgDimNode.opacity(Math.min(0.85, Math.max(0, opacity)));
    this._bgDimNode.visible(true);
  },

  _getBgVideoEl() {
    if (this._bgVideoEl?.isConnected) return this._bgVideoEl;
    const wrap = this.container?.closest?.('#designer-canvas-wrap')
      || this.container?.parentElement;
    const el = wrap?.querySelector?.('#designer-bg-video');
    this._bgVideoEl = el || null;
    return this._bgVideoEl;
  },

  _clearBgVideo() {
    const el = this._getBgVideoEl();
    if (el) {
      try { el.pause(); } catch { /* ignore */ }
      el.removeAttribute('src');
      el.load?.();
      el.hidden = true;
      el.classList.remove('is-active');
    }
    this._bgVideoState = null;
    if (this.container) this.container.style.background = '';
  },

  setVideoPreviewActive(active) {
    const el = this._getBgVideoEl();
    if (!el || !this._bgVideoState?.src) return;
    if (active && !document.hidden) {
      el.muted = true;
      el.play?.().catch(() => {});
    } else {
      try { el.pause(); } catch { /* ignore */ }
    }
  },

  setBackground(bg = {}, opts = {}) {
    const designBg = this.layer.findOne('.design-bg');
    if (!designBg) return;
    const silent = !!opts.silent;

    const dim = Number(bg.dim ?? bg.overlay ?? 0) || 0;
    const fit = bg.fit === 'contain' ? 'contain' : 'cover';

    if (bg.type === 'video' && (bg.src || bg.mediaId)) {
      this._removeBgImage();
      designBg.visible(false);
      const el = this._getBgVideoEl();
      const src = bg.src || '';
      this._bgVideoState = {
        type: 'video',
        src,
        mediaId: bg.mediaId || '',
        fit,
        dim,
      };
      if (el && src) {
        el.hidden = false;
        el.classList.add('is-active');
        el.style.objectFit = fit;
        el.muted = true;
        el.loop = true;
        el.playsInline = true;
        el.preload = 'metadata';
        if (el.getAttribute('src') !== src) {
          el.src = src;
        }
        if (this.container) this.container.style.background = 'transparent';
        if (!document.hidden) {
          el.play?.().catch(() => {});
        }
      }
      this._ensureBgDim(dim);
      this._restackSystemNodes();
      this.layer.batchDraw();
      if (!silent) this.onChange?.();
      return;
    }

    this._clearBgVideo();

    if (bg.type === 'image' && bg.src) {
      designBg.visible(false);
      this._removeBgImage();
      const img = new Image();
      img.onload = () => {
        const iw = img.naturalWidth || DESIGN_W;
        const ih = img.naturalHeight || DESIGN_H;
        let w = DESIGN_W;
        let h = DESIGN_H;
        let x = 0;
        let y = 0;
        const scale = fit === 'contain'
          ? Math.min(DESIGN_W / iw, DESIGN_H / ih)
          : Math.max(DESIGN_W / iw, DESIGN_H / ih);
        w = iw * scale;
        h = ih * scale;
        x = (DESIGN_W - w) / 2 + (Number(bg.offsetX) || 0);
        y = (DESIGN_H - h) / 2 + (Number(bg.offsetY) || 0);
        this._bgImageNode = new Konva.Image({
          x,
          y,
          image: img,
          width: w,
          height: h,
          name: 'design-bg-image',
          listening: false,
          perfectDrawEnabled: false,
        });
        this._bgImageNode.setAttr('src', bg.src);
        this._bgImageNode.setAttr('fit', fit);
        this._bgImageNode.setAttr('dim', dim);
        this._bgImageNode.setAttr('offsetX', Number(bg.offsetX) || 0);
        this._bgImageNode.setAttr('offsetY', Number(bg.offsetY) || 0);
        this.layer.add(this._bgImageNode);
        this._ensureBgDim(dim);
        this._restackSystemNodes();
        this.layer.batchDraw();
        if (!silent) this.onChange?.();
      };
      img.src = bg.src;
      return;
    }

    this._removeBgImage();
    designBg.visible(true);

    if (bg.type === 'color') {
      applySolidFill(designBg, bg.value || '#0a0a0a');
      designBg.setAttr('bgType', 'color');
      designBg.setAttr('bgValue', bg.value || '#0a0a0a');
      designBg.setAttr('bgPreset', '');
    } else if (bg.type === 'gradient' || bg.preset) {
      const presetId = bg.preset || 'dark';
      const preset = GRADIENT_PRESETS[presetId] || GRADIENT_PRESETS.dark;
      const colors = bg.colors?.length ? bg.colors : preset.colors;
      const angle = bg.angle != null ? bg.angle : preset.angle;
      applyGradientFill(designBg, colors, angle);
      designBg.setAttr('bgType', 'gradient');
      designBg.setAttr('bgPreset', presetId);
      designBg.setAttr('bgColors', colors);
      designBg.setAttr('bgAngle', angle);
    } else {
      applySolidFill(designBg, '#0a0a0a');
      designBg.setAttr('bgType', 'color');
      designBg.setAttr('bgValue', '#0a0a0a');
    }

    this._ensureBgDim(dim);
    designBg.setAttr('bgDim', dim);
    this._restackSystemNodes();
    this.layer.batchDraw();
    if (!silent) this.onChange?.();
  },

  getBackground() {
    if (this._bgVideoState?.type === 'video' && this._bgVideoState.src) {
      return { ...this._bgVideoState };
    }
    if (this._bgImageNode?.visible?.()) {
      return {
        type: 'image',
        src: this._bgImageNode.attrs.src || '',
        fit: this._bgImageNode.attrs.fit || 'cover',
        dim: this._bgImageNode.attrs.dim || 0,
        offsetX: this._bgImageNode.attrs.offsetX || 0,
        offsetY: this._bgImageNode.attrs.offsetY || 0,
      };
    }
    const designBg = this.layer.findOne('.design-bg');
    if (!designBg) return { type: 'color', value: '#0a0a0a' };
    const bgType = designBg.getAttr('bgType') || 'color';
    const dim = designBg.getAttr('bgDim') || 0;
    if (bgType === 'gradient') {
      return {
        type: 'gradient',
        preset: designBg.getAttr('bgPreset') || 'dark',
        colors: designBg.getAttr('bgColors') || null,
        angle: designBg.getAttr('bgAngle') || 180,
        dim,
      };
    }
    return { type: 'color', value: designBg.getAttr('bgValue') || designBg.fill?.() || '#0a0a0a', dim };
  },

  _pushHistory() {
    const json = this.stage.toJSON();
    this._history = this._history.slice(0, this._historyIdx + 1);
    this._history.push(json);
    if (this._history.length > 40) this._history.shift();
    this._historyIdx = this._history.length - 1;
  },

  undo() {
    if (this._historyIdx <= 0) return;
    this._historyIdx -= 1;
    this._restoreHistory(this._history[this._historyIdx]);
  },

  redo() {
    if (this._historyIdx >= this._history.length - 1) return;
    this._historyIdx += 1;
    this._restoreHistory(this._history[this._historyIdx]);
  },

  _restoreHistory(json) {
    if (!json) return;
    const stage = Konva.Node.create(json, this.container);
    this.stage.destroy();
    this.stage = stage;
    this.layer = this.stage.getLayers()[0];
    this.transformer = this.stage.findOne('Transformer')
      || this.layer.getChildren().find((n) => n.getClassName?.() === 'Transformer');
    if (!this.transformer) this._createTransformer();
    this._bgImageNode = this.layer.findOne('.design-bg-image') || null;
    this._bgDimNode = this.layer.findOne('.design-bg-dim') || null;
    this.selectedNodes = [];
    this._bindStageEvents();
    this.selectNode(null);
    this.onChange?.();
  },

};

export { GRADIENT_PRESETS };
