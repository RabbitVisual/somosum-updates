/** Layer alignment, ordering, and panel list helpers for CanvasEngine. */

import { DESIGN_W, DESIGN_H, importLayersToKonva } from './slide-exporter.js';
import { bindFrameDrag } from './frame-utils.js';
import { bindPhotoCardDrag } from './photo-card.js';
import { SAFE_PAD } from './safe-zone.js';
import { applyShadowState, getShadowState } from './konva-shadow.js';

export const canvasLayerMethods = {

  _nodeSize(node) {
    const cls = node.getClassName?.();
    if (cls === 'Circle') {
      const r = node.radius() * Math.abs(node.scaleX?.() || 1);
      return { w: r * 2, h: r * 2 };
    }
    if (cls === 'Line') {
      const pts = node.points();
      const xs = [pts[0], pts[2] || 0];
      const ys = [pts[1], pts[3] || 0];
      return { w: Math.abs(xs[1] - xs[0]) || 1, h: Math.abs(ys[1] - ys[0]) || 1 };
    }
    return {
      w: Math.abs((node.width?.() || 0) * (node.scaleX?.() || 1)),
      h: Math.abs((node.height?.() || 0) * (node.scaleY?.() || 1)),
    };
  },

  alignSelected(mode) {
    const nodes = (this.selectedNodes?.length ? this.selectedNodes : (this.selectedNode ? [this.selectedNode] : []))
      .filter((n) => n && !this._isSystemNode(n));
    if (!nodes.length) return;
    const pad = SAFE_PAD;

    if (nodes.length === 1) {
      const node = nodes[0];
      const { w, h } = this._nodeSize(node);
      if (mode === 'left' || mode === 'center' || mode === 'right' || mode === 'center-h') {
        if (mode === 'left') node.x(pad);
        else if (mode === 'right') node.x(DESIGN_W - w - pad);
        else node.x((DESIGN_W - w) / 2);
      }
      if (mode === 'top' || mode === 'middle' || mode === 'bottom' || mode === 'center-v') {
        if (mode === 'top') node.y(pad);
        else if (mode === 'bottom') node.y(DESIGN_H - h - pad);
        else node.y((DESIGN_H - h) / 2);
      }
      if (mode === 'center') {
        node.x((DESIGN_W - w) / 2);
        node.y((DESIGN_H - h) / 2);
      }
    } else {
      const boxes = nodes.map((n) => ({ n, ...this._nodeSize(n), x: n.x(), y: n.y() }));
      const minX = Math.min(...boxes.map((b) => b.x));
      const maxX = Math.max(...boxes.map((b) => b.x + b.w));
      const minY = Math.min(...boxes.map((b) => b.y));
      const maxY = Math.max(...boxes.map((b) => b.y + b.h));
      const midX = (minX + maxX) / 2;
      const midY = (minY + maxY) / 2;
      for (const b of boxes) {
        if (mode === 'left') b.n.x(minX);
        else if (mode === 'right') b.n.x(maxX - b.w);
        else if (mode === 'center-h' || mode === 'center') b.n.x(midX - b.w / 2);
        if (mode === 'top') b.n.y(minY);
        else if (mode === 'bottom') b.n.y(maxY - b.h);
        else if (mode === 'center-v' || mode === 'center') b.n.y(midY - b.h / 2);
      }
    }

    this.layer.batchDraw();
    this.onChange?.();
    this._pushHistory();
    this.onSelect?.(this.selectedNode);
  },

  distributeSelected(axis = 'h') {
    const nodes = (this.selectedNodes?.length ? this.selectedNodes : [])
      .filter((n) => n && !this._isSystemNode(n));
    if (nodes.length < 3) return;
    const boxes = nodes.map((n) => ({ n, ...this._nodeSize(n), x: n.x(), y: n.y() }));
    if (axis === 'h') {
      boxes.sort((a, b) => a.x - b.x);
      const first = boxes[0];
      const last = boxes[boxes.length - 1];
      const span = (last.x + last.w) - first.x;
      const totalW = boxes.reduce((s, b) => s + b.w, 0);
      const gap = (span - totalW) / (boxes.length - 1);
      let cursor = first.x;
      for (const b of boxes) {
        b.n.x(cursor);
        cursor += b.w + gap;
      }
    } else {
      boxes.sort((a, b) => a.y - b.y);
      const first = boxes[0];
      const last = boxes[boxes.length - 1];
      const span = (last.y + last.h) - first.y;
      const totalH = boxes.reduce((s, b) => s + b.h, 0);
      const gap = (span - totalH) / (boxes.length - 1);
      let cursor = first.y;
      for (const b of boxes) {
        b.n.y(cursor);
        cursor += b.h + gap;
      }
    }
    this.layer.batchDraw();
    this.onChange?.();
    this._pushHistory();
  },

  layerOrder(action) {
    const node = this.selectedNode;
    if (!node || this._isSystemNode(node)) return;
    if (action === 'front') node.moveToTop();
    else if (action === 'back') node.moveToBottom();
    else if (action === 'forward') node.moveUp();
    else if (action === 'backward') node.moveDown();
    this._restackSystemNodes();
    this.layer.batchDraw();
    this.onChange?.();
    this._pushHistory();
    this.refreshLayers?.();
  },

  deleteSelected() {
    const nodes = (this.selectedNodes?.length ? [...this.selectedNodes] : (this.selectedNode ? [this.selectedNode] : []))
      .filter((n) => n && !this._isSystemNode(n));
    if (!nodes.length) return;
    nodes.forEach((n) => n.destroy());
    this.selectNode(null);
    this.onChange?.();
    this._pushHistory();
  },

  duplicateSelected() {
    const node = this.selectedNode;
    if (!node || this._isSystemNode(node)) return;
    const clone = node.clone({
      x: node.x() + 24,
      y: node.y() + 24,
      id: `${node.id() || 'ly'}-copy-${Date.now()}`,
    });
    const nm = clone.name?.();
    if (nm === 'photo-card') {
      const hit = clone.findOne('.card-hit');
      if (hit?.attrs) hit.attrs._dragBound = false;
      bindPhotoCardDrag(clone, {
        onPointerDown: (g) => {
          if (this.selectedNode !== g) this.selectNode(g);
        },
      });
    } else if (nm === 'frame') {
      const hit = clone.findOne('.frame-hit');
      if (hit?.attrs) hit.attrs._dragBound = false;
      bindFrameDrag(clone, {
        onPointerDown: (g) => {
          if (this.selectedNode !== g) this.selectNode(g);
        },
      });
    }
    this.layer.add(clone);
    this._restackSystemNodes();
    this.selectNode(clone);
    this.onChange?.();
    this._pushHistory();
    return clone;
  },

  groupSelected() {
    const nodes = (this.selectedNodes?.length ? [...this.selectedNodes] : [])
      .filter((n) => n && !this._isSystemNode(n) && n.name?.() !== 'designer-group');
    if (nodes.length < 2) return null;
    let minX = Infinity;
    let minY = Infinity;
    for (const n of nodes) {
      minX = Math.min(minX, n.x());
      minY = Math.min(minY, n.y());
    }
    const group = new Konva.Group({
      x: minX,
      y: minY,
      draggable: true,
      name: 'designer-group',
      id: `grp-${Date.now()}`,
    });
    for (const n of nodes) {
      n.moveTo(group);
      n.x(n.x() - minX);
      n.y(n.y() - minY);
    }
    this.layer.add(group);
    this._restackSystemNodes();
    this.selectNode(group);
    this.onChange?.();
    this._pushHistory();
    this.refreshLayers?.();
    return group;
  },

  ungroupSelected() {
    const group = this.selectedNode;
    if (!group || group.name?.() !== 'designer-group') return false;
    const children = group.getChildren?.()?.slice() || [];
    for (const child of children) {
      const absX = group.x() + child.x();
      const absY = group.y() + child.y();
      child.moveTo(this.layer);
      child.x(absX);
      child.y(absY);
    }
    group.destroy();
    this.selectNode(children[0] || null);
    this.onChange?.();
    this._pushHistory();
    this.refreshLayers?.();
    return true;
  },

  /**
   * Flip selection around visual center. axis: 'h' | 'v'
   */
  flipSelected(axis = 'h') {
    const nodes = (this.selectedNodes?.length ? this.selectedNodes : (this.selectedNode ? [this.selectedNode] : []))
      .filter((n) => n && !this._isSystemNode(n));
    if (!nodes.length) return;
    for (const node of nodes) {
      const before = node.getClientRect?.({ relativeTo: this.layer, skipShadow: true }) || {
        x: node.x(), y: node.y(), width: this._nodeSize(node).w, height: this._nodeSize(node).h,
      };
      if (axis === 'v') {
        node.scaleY(-(node.scaleY?.() || 1));
      } else {
        node.scaleX(-(node.scaleX?.() || 1));
      }
      const after = node.getClientRect?.({ relativeTo: this.layer, skipShadow: true }) || before;
      node.x(node.x() + (before.x - after.x));
      node.y(node.y() + (before.y - after.y));
    }
    this.layer.batchDraw();
    this.onChange?.();
    this._pushHistory();
    this.onSelect?.(this.selectedNode);
  },

  rotateSelected(deltaDeg) {
    const nodes = (this.selectedNodes?.length ? this.selectedNodes : (this.selectedNode ? [this.selectedNode] : []))
      .filter((n) => n && !this._isSystemNode(n));
    if (!nodes.length) return;
    for (const node of nodes) {
      const next = ((node.rotation?.() || 0) + deltaDeg);
      const norm = ((next % 360) + 540) % 360 - 180;
      node.rotation(norm);
    }
    this.layer.batchDraw();
    this.onChange?.();
    this._pushHistory();
    this.onSelect?.(this.selectedNode);
  },

  resetRotationSelected() {
    const nodes = (this.selectedNodes?.length ? this.selectedNodes : (this.selectedNode ? [this.selectedNode] : []))
      .filter((n) => n && !this._isSystemNode(n));
    if (!nodes.length) return;
    for (const node of nodes) node.rotation?.(0);
    this.layer.batchDraw();
    this.onChange?.();
    this._pushHistory();
    this.onSelect?.(this.selectedNode);
  },

  toggleLockSelected() {
    const node = this.selectedNode;
    if (!node || this._isSystemNode(node)) return;
    const locked = node.draggable?.() === false;
    node.draggable(!locked);
    this.layer.batchDraw();
    this.onChange?.();
    this._pushHistory();
    this.refreshLayers?.();
    this.onSelect?.(node);
  },

  copyStyleSelected() {
    const node = this.selectedNode;
    if (!node || this._isSystemNode(node)) return null;
    const sh = getShadowState(node);
    const style = {
      fontSize: node.fontSize?.(),
      fontFamily: node.fontFamily?.(),
      fontStyle: node.fontStyle?.(),
      fill: node.fill?.(),
      align: node.align?.(),
      letterSpacing: node.letterSpacing?.(),
      lineHeight: node.lineHeight?.(),
      opacity: node.opacity?.(),
      shadowBlur: sh.blur,
      shadowColor: sh.color,
      shadowOffsetX: sh.offsetX,
      shadowOffsetY: sh.offsetY,
      stroke: node.stroke?.(),
      strokeWidth: node.strokeWidth?.(),
    };
    this._styleClipboard = style;
    return style;
  },

  pasteStyleSelected() {
    const node = this.selectedNode;
    const style = this._styleClipboard;
    if (!node || !style || this._isSystemNode(node)) return false;
    if (node.getClassName?.() === 'Text') {
      if (style.fontSize != null) node.fontSize(style.fontSize);
      if (style.fontFamily) node.fontFamily(style.fontFamily);
      if (style.fontStyle) node.fontStyle(style.fontStyle);
      if (style.fill) node.fill(style.fill);
      if (style.align) node.align(style.align);
      if (style.letterSpacing != null && node.letterSpacing) node.letterSpacing(style.letterSpacing);
      if (style.lineHeight != null && node.lineHeight) node.lineHeight(style.lineHeight);
      if (style.strokeWidth != null) {
        node.strokeWidth(style.strokeWidth);
        node.stroke(style.strokeWidth > 0 ? (style.stroke || '#000') : null);
      }
    } else if (style.fill && node.fill) {
      node.fill(style.fill);
    }
    if (style.opacity != null) node.opacity(style.opacity);
    if (style.shadowBlur != null) {
      applyShadowState(node, {
        blur: style.shadowBlur,
        color: style.shadowColor || 'rgba(0,0,0,0.55)',
        offsetX: style.shadowOffsetX || 0,
        offsetY: style.shadowOffsetY || 0,
      });
    }
    this.layer.batchDraw();
    this.onChange?.();
    this._pushHistory();
    this.onSelect?.(node);
    return true;
  },

  copySelectedToClipboard() {
    const node = this.selectedNode;
    if (!node || this._isSystemNode(node)) return null;
    this._nodeClipboard = node.clone({
      id: `${node.id() || 'ly'}-clip-${Date.now()}`,
      x: node.x(),
      y: node.y(),
    });
    return this._nodeClipboard;
  },

  pasteClipboardNode(offset = 24) {
    if (!this._nodeClipboard || !this.layer) return null;
    const clone = this._nodeClipboard.clone({
      x: this._nodeClipboard.x() + offset,
      y: this._nodeClipboard.y() + offset,
      id: `${this._nodeClipboard.id() || 'ly'}-paste-${Date.now()}`,
    });
    this.layer.add(clone);
    this._restackSystemNodes();
    this.selectNode(clone);
    this.onChange?.();
    this._pushHistory();
    return clone;
  },

  /**
   * Mede largura real do texto sem depender de wrap/width atuais
   * (getTextWidth() com caixa estreita devolve ~1 letra → empilha C/B/A/V).
   */
  _measureTextNaturalWidth(node) {
    if (!node || node.getClassName?.() !== 'Text') return 0;
    const fs = node.fontSize?.() || 48;
    const ls = Number(node.letterSpacing?.() || 0);
    const family = node.fontFamily?.() || 'Segoe UI';
    const style = node.fontStyle?.() || 'normal';
    const lines = String(node.text?.() || '').split('\n');
    // Piso por caracteres — evita caixa estreita quando a fonte ainda não carregou
    let max = 0;
    for (const line of lines) {
      max = Math.max(max, (line || '').length * fs * 0.58 + ls * Math.max(0, (line || '').length));
    }
    try {
      // Preferir Canvas 2D com a fonte real — Konva pode medir antes do font load
      const canvas = this._measureCanvas || (this._measureCanvas = document.createElement('canvas'));
      const ctx = canvas.getContext('2d');
      if (ctx) {
        const weight = /bold/i.test(style) ? 'bold' : 'normal';
        const italic = /italic/i.test(style) ? 'italic' : 'normal';
        ctx.font = `${italic} ${weight} ${fs}px ${family}`;
        for (const line of lines) {
          const metrics = ctx.measureText(line || ' ');
          max = Math.max(max, (metrics.width || 0) + ls * Math.max(0, (line || '').length));
        }
      }
    } catch { /* fall through */ }
    try {
      for (const line of lines) {
        if (typeof node._getTextWidth === 'function') {
          max = Math.max(max, node._getTextWidth(line));
        } else if (typeof node.measureSize === 'function') {
          max = Math.max(max, (node.measureSize(line).width || 0) + ls * line.length);
        }
      }
    } catch { /* ignore */ }
    return Math.max(max, fs * 0.75);
  },

  /** Corrige caixa estreita / wrap errado após resize ou load corrompido. */
  healTextLayout(node = this.selectedNode) {
    if (!node || node.getClassName?.() !== 'Text') return false;
    const fit = node.getAttr?.('textFit') || node.attrs?.textFit || 'wrap';
    const role = node.getAttr?.('role') || node.attrs?.role || '';
    const measured = this._measureTextNaturalWidth(node);
    const w = Number(node.width()) || 0;
    const fs = node.fontSize?.() || 48;
    const maxW = DESIGN_W - SAFE_PAD * 2;
    const textLen = String(node.text?.() || '').length;
    let changed = false;

    // Título cortado ou caixa estreita → sempre caixa larga com wrap
    if (role === 'title' && textLen > 6 && (fit !== 'fit' || (w > 0 && measured > w - 4))) {
      const align = node.align?.() || 'left';
      const oldX = node.x();
      const newW = Math.min(maxW, Math.max(w, Math.ceil(measured + Math.max(40, fs * 0.45)), Math.round(maxW * 0.85)));
      if (Math.abs(newW - w) > 2) {
        if (align === 'center') node.x(oldX + (w - newW) / 2);
        else if (align === 'right') node.x(oldX + (w - newW));
        node.width(newW);
        node.setAttr('wrapWidth', newW);
        changed = true;
      }
      if (typeof node.wrap === 'function') node.wrap('word');
      node.setAttr('textFit', 'wrap');
      return true;
    }

    // Texto cortado (medido > caixa) → expandir
    if (w > 0 && measured > w - 4) {
      if (fit === 'fit') return this.fitTextBox(node, { silent: true });
      const align = node.align?.() || 'left';
      const oldX = node.x();
      const newW = Math.min(maxW, Math.max(w, Math.ceil(measured + Math.max(32, fs * 0.35)), 640));
      if (align === 'center') node.x(oldX + (w - newW) / 2);
      else if (align === 'right') node.x(oldX + (w - newW));
      node.width(newW);
      node.setAttr('wrapWidth', newW);
      if (typeof node.wrap === 'function') node.wrap('word');
      return true;
    }
    if (fit === 'fit') {
      return this.fitTextBox(node, { silent: true });
    }
    const minBox = Math.max(160, Math.ceil(fs * 3));
    if (w > 0 && w < minBox) {
      const align = node.align?.() || 'left';
      const oldX = node.x();
      const newW = Math.min(maxW, Math.max(minBox, 800));
      if (align === 'center') node.x(oldX + (w - newW) / 2);
      else if (align === 'right') node.x(oldX + (w - newW));
      node.width(newW);
      node.setAttr('wrapWidth', newW);
      changed = true;
    }
    if (typeof node.wrap === 'function') node.wrap('word');
    if ((node.getAttr?.('textFit') || node.attrs?.textFit) !== 'wrap') {
      node.setAttr('textFit', 'wrap');
      changed = true;
    }
    return changed;
  },

  /**
   * Shrink/grow Konva.Text layout width to measured glyph width; keep alignment anchor.
   */
  fitTextBox(node = this.selectedNode, opts = {}) {
    if (!node || node.getClassName?.() !== 'Text') return false;
    const silent = !!opts.silent;
    const align = node.align?.() || 'left';
    const oldW = Number(node.width()) || 0;
    const oldX = node.x();
    const prevFit = node.getAttr?.('textFit') || node.attrs?.textFit || 'wrap';
    if (prevFit !== 'fit' && oldW > 40) {
      node.setAttr('wrapWidth', oldW);
    }

    const measured = this._measureTextNaturalWidth(node);
    const fs = node.fontSize?.() || 48;
    const pad = Math.max(28, Math.ceil(fs * 0.4));
    const maxW = DESIGN_W - SAFE_PAD * 2;
    const newW = Math.min(maxW, Math.max(Math.ceil(fs * 1.5), Math.ceil(measured + pad)));

    if (align === 'center' && oldW > 0) node.x(oldX + (oldW - newW) / 2);
    else if (align === 'right' && oldW > 0) node.x(oldX + (oldW - newW));
    node.width(newW);
    // fit = uma linha (quebra só com Enter explícito no texto)
    if (typeof node.wrap === 'function') node.wrap('none');
    node.setAttr('textFit', 'fit');
    this.layer?.batchDraw?.();
    if (!silent) {
      this.onChange?.();
      this._pushHistory?.();
    }
    return true;
  },

  setTextFitMode(mode = 'wrap', node = this.selectedNode) {
    if (!node || node.getClassName?.() !== 'Text') return false;
    const next = mode === 'fit' ? 'fit' : 'wrap';
    if (next === 'fit') {
      return this.fitTextBox(node);
    }

    const align = node.align?.() || 'left';
    const oldW = Number(node.width()) || 0;
    const oldX = node.x();
    const saved = Number(node.getAttr?.('wrapWidth') || node.attrs?.wrapWidth) || 0;
    const maxW = DESIGN_W - SAFE_PAD * 2;
    const fs = node.fontSize?.() || 48;
    const minBox = Math.max(200, Math.ceil(fs * 4));
    let newW = saved >= minBox ? saved : 0;
    if (!newW) {
      const measured = this._measureTextNaturalWidth(node);
      newW = Math.max(oldW, minBox, Math.min(maxW, Math.max(640, Math.ceil(measured + 120))));
    }
    newW = Math.max(minBox, Math.min(maxW, Math.round(newW)));
    if (align === 'center' && oldW > 0) node.x(oldX + (oldW - newW) / 2);
    else if (align === 'right' && oldW > 0) node.x(oldX + (oldW - newW));
    node.width(newW);
    if (typeof node.wrap === 'function') node.wrap('word');
    node.setAttr('textFit', 'wrap');
    node.setAttr('wrapWidth', newW);
    this.layer?.batchDraw?.();
    this.onChange?.();
    this._pushHistory?.();
    return true;
  },

  /**
   * Fit all Text nodes marked textFit=fit (or short reference-like roles).
   * @param {{ silent?: boolean }} opts silent skips history/onChange spam (load paths)
   */
  fitAllTextBoxes(opts = {}) {
    const silent = !!opts.silent;
    // Títulos longos usam wrap; só papéis curtos forçam fit automático
    const FIT_ROLES = new Set(['reference', 'badge', 'author', 'ref', 'churchName', 'years']);
    const nodes = (this.getContentNodes?.() || []).filter((n) => n.getClassName?.() === 'Text');
    let n = 0;
    for (const node of nodes) {
      const fit = node.getAttr?.('textFit') || node.attrs?.textFit;
      const role = node.getAttr?.('role') || node.attrs?.role || '';
      const textLen = String(node.text?.() || '').length;
      // Título → caixa larga com wrap (nunca cortar no canvas)
      if (role === 'title' && textLen > 6) {
        if (this.healTextLayout(node)) n += 1;
        continue;
      }
      if (fit === 'fit' || (fit !== 'wrap' && FIT_ROLES.has(role))) {
        if (this.fitTextBox(node, { silent: true })) n += 1;
      } else if (fit === 'wrap' || !fit || role === 'title' || role === 'body') {
        const healed = this.healTextLayout(node);
        if (healed) n += 1;
      }
    }
    if (n > 0) {
      this.layer?.batchDraw?.();
      if (!silent) {
        this.onChange?.();
        this._pushHistory?.();
      }
    }
    return n;
  },

  /**
   * Schedule fit after fonts are ready (preset/slide load).
   */
  scheduleFitTextBoxes() {
    const run = () => {
      try {
        this.fitAllTextBoxes?.({ silent: true });
        // Segunda passagem após layout estabilizar (font metrics)
        requestAnimationFrame(() => {
          try {
            this.fitAllTextBoxes?.({ silent: true });
            this.layer?.batchDraw?.();
          } catch { /* ignore */ }
        });
        this.layer?.batchDraw?.();
      } catch { /* ignore */ }
    };
    if (typeof document !== 'undefined' && document.fonts?.ready) {
      document.fonts.ready.then(run).catch(run);
    } else {
      requestAnimationFrame(run);
    }
    // Refit tardio — fontes custom demoram mais que document.fonts.ready
    setTimeout(run, 350);
    setTimeout(run, 900);
  },

  addLayersFromData(layers = []) {
    if (!this.layer || !layers.length) return;
    importLayersToKonva(this.layer, layers);
    this._restackSystemNodes();
    this.rebindFrameInteractions?.();
    this.layer.batchDraw();
    this.onChange?.();
    this._pushHistory();
    this.refreshLayers?.();
  },

  getLayerList() {
    return this.getContentNodes()
      .map((n) => ({
        id: n.id(),
        kind: n.getClassName(),
        name: n.name() || n.getClassName(),
        label: this._layerLabel(n),
        visible: n.visible(),
        locked: n.draggable() === false,
      }))
      .reverse();
  },

  _layerLabel(n) {
    if (n.attrs?.displayName) return String(n.attrs.displayName).slice(0, 32);
    const cls = n.getClassName?.();
    if (cls === 'Text') {
      const t = (n.text() || '').slice(0, 28);
      return t || 'Texto';
    }
    if (cls === 'Image') return n.name() === 'logo' ? 'Logo' : 'Imagem';
    if (cls === 'Circle') return 'Círculo';
    if (cls === 'Line') return 'Linha';
    if (cls === 'Rect') return 'Retângulo';
    if (cls === 'Group' && n.name?.() === 'frame') {
      const shape = n.attrs.clipShape || 'rect';
      const labels = {
        rect: 'Moldura ret.',
        rounded: 'Moldura arred.',
        circle: 'Moldura circ.',
        ellipse: 'Moldura elipse',
        star: 'Moldura estrela',
        hexagon: 'Moldura hex.',
        diamond: 'Moldura losango',
      };
      return labels[shape] || 'Moldura';
    }
    if (cls === 'Group' && n.name?.() === 'photo-card') {
      const t = n.attrs.cardTitle || n.findOne('.card-title')?.text?.() || 'Card foto';
      return `Card: ${String(t).slice(0, 24)}`;
    }
    if (cls === 'Group' && n.name?.() === 'designer-group') return 'Grupo';
    return n.name() || cls;
  },

};
