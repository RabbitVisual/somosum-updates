/** Utilitários compartilhados — molduras/máscaras (editor Konva + projeção CSS). */

export const FRAME_CLIP_SHAPES = [
  'rect',
  'rounded',
  'circle',
  'ellipse',
  'star',
  'hexagon',
  'diamond',
];

/**
 * Konva.getClientRect une filhos SEM respeitar clipFunc.
 * Com fill "cover" a imagem passa da moldura → Transformer fica "fantasma".
 * Força o AABB lógico = attrs.width × attrs.height.
 */
export function bindLogicalClientRect(node, getSize) {
  if (!node || node.attrs?._logicalClientRect) return node;
  const sizeFn = typeof getSize === 'function'
    ? getSize
    : () => ({
      w: Number(node.attrs?.width) || Number(node.width?.()) || 0,
      h: Number(node.attrs?.height) || Number(node.height?.()) || 0,
    });
  node.attrs._logicalClientRect = true;
  node.getClientRect = function logicalClientRect(config = {}) {
    const { w, h } = sizeFn.call(this) || { w: 0, h: 0 };
    const selfRect = {
      x: 0,
      y: 0,
      width: Math.max(0, w),
      height: Math.max(0, h),
    };
    if (config.skipTransform) return { ...selfRect };
    return this._transformedRect(selfRect, config.relativeTo);
  };
  return node;
}

/** Atalho para molduras (Group name=frame). */
export function bindFrameLogicalBounds(group) {
  if (!group || group.name?.() !== 'frame') return group;
  return bindLogicalClientRect(group, function () {
    return {
      w: Number(this.attrs.width) || 400,
      h: Number(this.attrs.height) || 400,
    };
  });
}

export function applyKonvaFrameClip(group, w, h, shape, opts = {}) {
  if (!group?.clipFunc) return;
  const cornerRadius = Math.min(opts.cornerRadius || 24, w / 2, h / 2);
  const cx = w / 2;
  const cy = h / 2;

  if (shape === 'circle') {
    group.clipFunc((ctx) => {
      ctx.beginPath();
      ctx.arc(cx, cy, Math.min(w, h) / 2, 0, Math.PI * 2);
      ctx.closePath();
    });
    return;
  }

  if (shape === 'ellipse') {
    group.clipFunc((ctx) => {
      ctx.beginPath();
      ctx.ellipse(cx, cy, w / 2, h / 2, 0, 0, Math.PI * 2);
      ctx.closePath();
    });
    return;
  }

  if (shape === 'rounded') {
    group.clipFunc((ctx) => {
      if (typeof ctx.roundRect === 'function') {
        ctx.beginPath();
        ctx.roundRect(0, 0, w, h, cornerRadius);
        ctx.closePath();
        return;
      }
      ctx.beginPath();
      ctx.moveTo(cornerRadius, 0);
      ctx.lineTo(w - cornerRadius, 0);
      ctx.quadraticCurveTo(w, 0, w, cornerRadius);
      ctx.lineTo(w, h - cornerRadius);
      ctx.quadraticCurveTo(w, h, w - cornerRadius, h);
      ctx.lineTo(cornerRadius, h);
      ctx.quadraticCurveTo(0, h, 0, h - cornerRadius);
      ctx.lineTo(0, cornerRadius);
      ctx.quadraticCurveTo(0, 0, cornerRadius, 0);
      ctx.closePath();
    });
    return;
  }

  if (shape === 'star') {
    group.clipFunc((ctx) => {
      drawPolygonPath(ctx, cx, cy, Math.min(w, h) / 2, Math.min(w, h) / 4, 5, -Math.PI / 2);
    });
    return;
  }

  if (shape === 'hexagon') {
    group.clipFunc((ctx) => {
      drawRegularPolygon(ctx, cx, cy, Math.min(w, h) / 2, 6, -Math.PI / 2);
    });
    return;
  }

  if (shape === 'diamond') {
    group.clipFunc((ctx) => {
      drawRegularPolygon(ctx, cx, cy, Math.min(w, h) / 2, 4, -Math.PI / 4);
    });
    return;
  }

  group.clipFunc((ctx) => {
    ctx.beginPath();
    ctx.rect(0, 0, w, h);
    ctx.closePath();
  });
}

function drawRegularPolygon(ctx, cx, cy, r, sides, startAngle = 0) {
  ctx.beginPath();
  for (let i = 0; i < sides; i++) {
    const a = startAngle + (i * 2 * Math.PI) / sides;
    const x = cx + r * Math.cos(a);
    const y = cy + r * Math.sin(a);
    if (i === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  }
  ctx.closePath();
}

function drawPolygonPath(ctx, cx, cy, outerR, innerR, points, startAngle = 0) {
  ctx.beginPath();
  const step = Math.PI / points;
  for (let i = 0; i < points * 2; i++) {
    const r = i % 2 === 0 ? outerR : innerR;
    const a = startAngle + i * step;
    const x = cx + r * Math.cos(a);
    const y = cy + r * Math.sin(a);
    if (i === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  }
  ctx.closePath();
}

export function computeFrameFillLayout(w, h, imgW, imgH, fit = 'cover', scale = 1, offsetX = 0, offsetY = 0) {
  if (!imgW || !imgH) {
    return { x: offsetX, y: offsetY, width: w, height: h };
  }
  let s = fit === 'contain'
    ? Math.min(w / imgW, h / imgH)
    : Math.max(w / imgW, h / imgH);
  s *= scale || 1;
  const drawW = imgW * s;
  const drawH = imgH * s;
  return {
    x: (w - drawW) / 2 + (offsetX || 0),
    y: (h - drawH) / 2 + (offsetY || 0),
    width: drawW,
    height: drawH,
  };
}

export function cssClipPathForFrame(layer) {
  const shape = layer.clipShape || 'rect';
  const r = layer.cornerRadius || 24;
  if (shape === 'circle') return 'circle(50% at 50% 50%)';
  if (shape === 'ellipse') return 'ellipse(50% 50% at 50% 50%)';
  if (shape === 'rounded') return `inset(0 round ${r}px)`;
  if (shape === 'star') {
    return 'polygon(50% 0%, 61% 35%, 98% 35%, 68% 57%, 79% 91%, 50% 70%, 21% 91%, 32% 57%, 2% 35%, 39% 35%)';
  }
  if (shape === 'hexagon') {
    return 'polygon(25% 0%, 75% 0%, 100% 50%, 75% 100%, 25% 100%, 0% 50%)';
  }
  if (shape === 'diamond') {
    return 'polygon(50% 0%, 100% 50%, 50% 100%, 0% 50%)';
  }
  return 'inset(0 round 0)';
}

/** Molduras vetoriais prontas (SVG inline como data URL). */
export const BUILTIN_FRAME_MASKS = [
  { id: 'arch', label: 'Arco', clipShape: 'rounded', cornerRadius: 80 },
  { id: 'circle-frame', label: 'Círculo', clipShape: 'circle' },
  { id: 'star-frame', label: 'Estrela', clipShape: 'star' },
  { id: 'hex-frame', label: 'Hexágono', clipShape: 'hexagon' },
  { id: 'diamond-frame', label: 'Losango', clipShape: 'diamond' },
  { id: 'wide-rect', label: 'Retângulo', clipShape: 'rect', width: 560, height: 360 },
  { id: 'portrait', label: 'Retrato', clipShape: 'rounded', cornerRadius: 16, width: 360, height: 520 },
];

/**
 * Permite arrastar a moldura pela área de hit.
 * onPointerDown: seleciona no mousedown (o drag engole o click do stage).
 */
export function bindFrameDrag(group, { onPointerDown } = {}) {
  if (!group || group.attrs._bindingFrameDrag) return;
  group.attrs._bindingFrameDrag = true;
  try {
    if (typeof onPointerDown === 'function') {
      group.attrs._onFramePointerDown = onPointerDown;
    }

    const hit = group.findOne('.frame-hit');
    if (!hit) return;

    hit.listening(true);
    hit.moveToTop();

    // Remove handlers anteriores (evita acumular / loop)
    if (hit.attrs._frameHitHandler) {
      hit.off('mousedown', hit.attrs._frameHitHandler);
      hit.off('touchstart', hit.attrs._frameHitHandler);
    }
    if (group.attrs._frameDragHandler) {
      group.off('mousedown', group.attrs._frameDragHandler);
      group.off('touchstart', group.attrs._frameDragHandler);
      group.attrs._frameDragHandler = null;
    }

    const handler = (e) => {
      if (group.attrs._fillEdit) return;
      if (e.target?.getClassName?.() === 'Transformer') return;
      e.cancelBubble = true;
      if (group.draggable() === false) return;
      // Arrasta primeiro — anexar Transformer no mesmo mousedown cancela o drag
      if (!group.isDragging?.()) {
        try {
          group.startDrag(e);
        } catch { /* ignore */ }
      }
      // Seleciona depois (microtask) para não interromper o gesture
      queueMicrotask(() => {
        try {
          group.attrs._onFramePointerDown?.(group, e);
        } catch { /* ignore */ }
      });
    };

    hit.attrs._frameHitHandler = handler;
    hit.attrs._dragBound = true;
    hit.on('mousedown touchstart', handler);
  } finally {
    group.attrs._bindingFrameDrag = false;
  }
}

/**
 * Hit area confiável — fill quase transparente / opacity 0 falham no hit-canvas do Konva.
 * sceneFunc vazio (invisível) + hitFunc sólido (fill precisa existir p/ fillStrokeShape).
 */
export function makeFrameHitRect(K, w, h) {
  const hit = new K.Rect({
    x: 0,
    y: 0,
    width: w,
    height: h,
    fill: '#ffffff',
    name: 'frame-hit',
    listening: true,
    perfectDrawEnabled: false,
    shadowForStrokeEnabled: false,
    sceneFunc() {
      /* invisível no canvas visual */
    },
    hitFunc(context) {
      context.beginPath();
      context.rect(0, 0, this.width(), this.height());
      context.closePath();
      context.fillStrokeShape(this);
    },
  });
  // Hit não deve inflar o AABB da moldura (já usamos bounds lógicos no group)
  hit.getClientRect = function hitClientRect(config = {}) {
    const selfRect = { x: 0, y: 0, width: this.width(), height: this.height() };
    if (config.skipTransform) return { ...selfRect };
    return this._transformedRect(selfRect, config.relativeTo);
  };
  return hit;
}

/** Redimensiona filhos da moldura após bake de scale. */
export function resizeFrameChildren(group, w, h) {
  if (!group) return;
  for (const child of group.getChildren?.() || []) {
    const nm = child.name?.() || '';
    if (nm === 'frame-hit' || nm === 'frame-mask') {
      child.width?.(w);
      child.height?.(h);
      child.position?.({ x: 0, y: 0 });
    }
    if (nm === 'frame-fill' && child.getClassName?.() === 'Rect') {
      child.width?.(w);
      child.height?.(h);
      child.position?.({ x: 0, y: 0 });
    }
  }
}

function frameDashAttr(opts = {}) {
  if (opts.strokeDashed === false) return undefined;
  if (Array.isArray(opts.strokeDash)) return opts.strokeDash;
  if (opts.strokeDash === false || opts.strokeDash === 0) return undefined;
  return [8, 4];
}

/**
 * Borda Konva que segue a forma do recorte (não só Retângulo).
 */
export function createFrameBorderNode(K, w, h, shape = 'rect', opts = {}) {
  const stroke = opts.stroke || '#d4c68d';
  const strokeWidth = opts.strokeWidth ?? 2;
  const dash = frameDashAttr(opts);
  const cornerRadius = Math.min(opts.cornerRadius || 24, w / 2, h / 2);
  const common = {
    listening: false,
    name: 'frame-border',
    stroke,
    strokeWidth,
    dash,
    fillEnabled: false,
    perfectDrawEnabled: false,
  };
  const cx = w / 2;
  const cy = h / 2;
  const r = Math.min(w, h) / 2;

  if (shape === 'circle') {
    return new K.Circle({ ...common, x: cx, y: cy, radius: r });
  }
  if (shape === 'ellipse') {
    return new K.Ellipse({ ...common, x: cx, y: cy, radiusX: w / 2, radiusY: h / 2 });
  }
  if (shape === 'star') {
    return new K.Star({
      ...common,
      x: cx,
      y: cy,
      numPoints: 5,
      innerRadius: r / 2,
      outerRadius: r,
    });
  }
  if (shape === 'hexagon') {
    return new K.RegularPolygon({ ...common, x: cx, y: cy, sides: 6, radius: r });
  }
  if (shape === 'diamond') {
    return new K.RegularPolygon({ ...common, x: cx, y: cy, sides: 4, radius: r, rotation: 45 });
  }
  if (shape === 'rounded') {
    return new K.Rect({
      ...common,
      x: 0,
      y: 0,
      width: w,
      height: h,
      cornerRadius,
    });
  }
  return new K.Rect({ ...common, x: 0, y: 0, width: w, height: h });
}

/** SVG overlay de traçado para projeção HTML (segue clipShape). */
export function frameStrokeSvgHtml(layer) {
  const sw = Number(layer.strokeWidth);
  if (!sw || sw <= 0 || !layer.stroke) return '';
  const w = Math.max(1, layer.width || 400);
  const h = Math.max(1, layer.height || 400);
  const shape = layer.clipShape || 'rect';
  const stroke = String(layer.stroke).replace(/"/g, '');
  const dash = layer.strokeDashed === false ? '' : ' stroke-dasharray="8 4"';
  const r = Math.min(w, h) / 2;
  const cx = w / 2;
  const cy = h / 2;
  const cr = Math.min(layer.cornerRadius || 24, w / 2, h / 2);
  let body = '';

  if (shape === 'circle') {
    body = `<circle cx="${cx}" cy="${cy}" r="${r - sw / 2}" fill="none" stroke="${stroke}" stroke-width="${sw}"${dash}/>`;
  } else if (shape === 'ellipse') {
    body = `<ellipse cx="${cx}" cy="${cy}" rx="${w / 2 - sw / 2}" ry="${h / 2 - sw / 2}" fill="none" stroke="${stroke}" stroke-width="${sw}"${dash}/>`;
  } else if (shape === 'star') {
    const pts = starPoints(cx, cy, r - sw / 2, r / 2 - sw / 4, 5);
    body = `<polygon points="${pts}" fill="none" stroke="${stroke}" stroke-width="${sw}"${dash}/>`;
  } else if (shape === 'hexagon') {
    body = `<polygon points="${regularPolygonPoints(cx, cy, r - sw / 2, 6)}" fill="none" stroke="${stroke}" stroke-width="${sw}"${dash}/>`;
  } else if (shape === 'diamond') {
    body = `<polygon points="${regularPolygonPoints(cx, cy, r - sw / 2, 4, Math.PI / 4)}" fill="none" stroke="${stroke}" stroke-width="${sw}"${dash}/>`;
  } else if (shape === 'rounded') {
    const x = sw / 2;
    const y = sw / 2;
    const rw = w - sw;
    const rh = h - sw;
    body = `<rect x="${x}" y="${y}" width="${rw}" height="${rh}" rx="${cr}" ry="${cr}" fill="none" stroke="${stroke}" stroke-width="${sw}"${dash}/>`;
  } else {
    body = `<rect x="${sw / 2}" y="${sw / 2}" width="${w - sw}" height="${h - sw}" fill="none" stroke="${stroke}" stroke-width="${sw}"${dash}/>`;
  }

  return `<svg class="custom-layer-frame-stroke" viewBox="0 0 ${w} ${h}" preserveAspectRatio="none" aria-hidden="true">${body}</svg>`;
}

function regularPolygonPoints(cx, cy, radius, sides, startAngle = -Math.PI / 2) {
  const pts = [];
  for (let i = 0; i < sides; i++) {
    const a = startAngle + (i * 2 * Math.PI) / sides;
    pts.push(`${cx + radius * Math.cos(a)},${cy + radius * Math.sin(a)}`);
  }
  return pts.join(' ');
}

function starPoints(cx, cy, outerR, innerR, points) {
  const pts = [];
  const step = Math.PI / points;
  const start = -Math.PI / 2;
  for (let i = 0; i < points * 2; i++) {
    const r = i % 2 === 0 ? outerR : innerR;
    const a = start + i * step;
    pts.push(`${cx + r * Math.cos(a)},${cy + r * Math.sin(a)}`);
  }
  return pts.join(' ');
}
