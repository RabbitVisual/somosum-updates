import {
  applyKonvaFrameClip,
  computeFrameFillLayout,
  bindFrameDrag,
  bindFrameLogicalBounds,
  bindLogicalClientRect,
  makeFrameHitRect,
  createFrameBorderNode,
} from './frame-utils.js';
import { buildPhotoCardNodes, exportPhotoCardGroup, layoutPhotoCardFill, bindPhotoCardDrag } from './photo-card.js';
import { applyShadowState, getShadowState } from './konva-shadow.js';



const DESIGN_W = 1920;

const DESIGN_H = 1080;



function readShadow(node) {
  const sh = getShadowState(node);
  if (!sh.blur || sh.blur <= 0) return {};
  return {
    shadowBlur: sh.blur,
    shadowColor: sh.color || 'rgba(0,0,0,0.55)',
    shadowOpacity: 1,
    shadowOffsetX: sh.offsetX ?? 0,
    shadowOffsetY: sh.offsetY ?? 0,
  };
}

function applyShadowAttrs(node, spec) {
  const blur = spec.shadowBlur || 0;
  if (!(blur > 0)) return;
  applyShadowState(node, {
    blur,
    color: spec.shadowColor || 'rgba(0,0,0,0.55)',
    offsetX: spec.shadowOffsetX ?? 0,
    offsetY: spec.shadowOffsetY ?? 0,
    opacity: spec.shadowOpacity ?? 1,
  });
}

export function exportSlideFromStage(stage, meta = {}) {

  if (!stage) return { type: 'custom', title: 'Slide', text: '', layers: [] };

  const layers = [];

  const nodes = stage.getChildren?.()[0]?.getChildren?.() || [];



  for (const node of nodes) {

    const name = node.name?.() || '';

    if (name === 'grid' || name === 'safe-zone' || name === 'design-bg' || name === 'design-bg-image') continue;

    if (node.getClassName?.() === 'Transformer') continue;

    const layer = nodeToLayer(node);

    if (layer) layers.push(layer);

  }



  const bgImage = stage.findOne?.('.design-bg-image');

  let background;

  if (bgImage) {

    background = {
      type: 'image',
      src: bgImage.attrs?.src || bgImage.image?.()?.src || '',
      fit: bgImage.attrs?.fit || 'cover',
      dim: bgImage.attrs?.dim || 0,
      offsetX: bgImage.attrs?.offsetX || 0,
      offsetY: bgImage.attrs?.offsetY || 0,
    };

  } else {

    const bg = stage.findOne?.('.design-bg');

    const bgType = bg?.getAttr?.('bgType') || 'color';

    if (bgType === 'gradient') {

      background = {
        type: 'gradient',
        preset: bg.getAttr('bgPreset') || 'dark',
        colors: bg.getAttr('bgColors') || null,
        angle: bg.getAttr('bgAngle') || 180,
        dim: bg.getAttr('bgDim') || 0,
      };

    } else {

      background = bg

        ? { type: 'color', value: bg.getAttr('bgValue') || bg.fill() || '#0a0a0a', dim: bg.getAttr('bgDim') || 0 }

        : { type: 'gradient', preset: 'dark' };

    }

  }



  const titleLayer = layers.find((l) => l.role === 'title');

  const bodyLayer = layers.find((l) => l.role === 'body');



  let previewDataUrl = '';

  if (meta.includePreview) {
    try {
      const hide = [];
      for (const n of nodes) {
        const nm = n.name?.() || '';
        if (nm === 'grid' || nm === 'safe-zone' || n.getClassName?.() === 'Transformer') {
          if (n.visible()) {
            n.visible(false);
            hide.push(n);
          }
        }
      }
      stage.draw();
      previewDataUrl = stage.toDataURL({ pixelRatio: 0.45, mimeType: 'image/jpeg', quality: 0.82 });
      hide.forEach((n) => n.visible(true));
      stage.draw();
    } catch { /* preview opcional */ }
  }



  return {

    type: 'custom',

    title: meta.title || titleLayer?.text || 'Slide personalizado',

    text: meta.text || bodyLayer?.text || '',

    layers,

    background,

    previewDataUrl: previewDataUrl || meta.existingPreview || undefined,

    templateId: meta.templateId || null,

    style: meta.style || {},


    designer: { version: 3, width: DESIGN_W, height: DESIGN_H },

  };

}



function nodeToLayer(node) {

  const cls = node.getClassName?.();

  const sx = node.scaleX?.() || 1;
  const sy = node.scaleY?.() || 1;
  const flipped = sx < 0 || sy < 0;

  let x = node.x();
  let y = node.y();
  let width = Math.abs((node.width?.() || 0) * sx);
  let height = Math.abs((node.height?.() || 0) * sy);
  let outSx = sx;
  let outSy = sy;

  if (flipped) {
    try {
      const box = node.getClientRect({
        relativeTo: node.getLayer?.(),
        skipShadow: true,
      });
      if (box) {
        x = box.x;
        y = box.y;
        width = Math.abs(box.width);
        height = Math.abs(box.height);
      }
    } catch { /* keep math fallback */ }
    // Persist flip as ±1; magnitude already in AABB size
    outSx = sx < 0 ? -1 : 1;
    outSy = sy < 0 ? -1 : 1;
  }

  const base = {

    id: node.id() || node._id,

    x,

    y,

    width,

    height,

    rotation: node.rotation?.() || 0,

    opacity: node.opacity?.() ?? 1,

    visible: node.visible?.() !== false,

    locked: node.draggable?.() === false,

    name: node.name() || '',

    scaleX: outSx,

    scaleY: outSy,

  };



  if (cls === 'Group' && node.name?.() === 'designer-group') {
    const children = node.getChildren?.()
      .map((child) => nodeToLayer(child))
      .filter(Boolean);
    return {
      ...base,
      kind: 'group',
      children,
      ...readShadow(node),
    };
  }

  if (cls === 'Text') {

    // Layout width + signed scale (Transformer resize preserved when not flipped)
    const layoutW = Math.abs(node.width?.() || 0);
    const textW = flipped ? width : layoutW;
    const textH = flipped ? height : Math.abs(node.height?.() || 0);

    return {

      ...base,

      kind: 'text',

      width: textW,

      height: textH,

      text: node.text(),

      fontSize: node.fontSize(),

      fontFamily: node.fontFamily(),

      fontStyle: node.fontStyle?.() || 'normal',

      letterSpacing: node.letterSpacing?.() || 0,

      lineHeight: node.lineHeight?.() || 1,

      fill: node.fill(),

      stroke: node.stroke?.() || '',

      strokeWidth: node.strokeWidth?.() || 0,

      align: node.align(),

      role: node.attrs.role || '',

      textFit: node.getAttr?.('textFit') || node.attrs?.textFit || 'wrap',

      wrapWidth: Number(node.getAttr?.('wrapWidth') || node.attrs?.wrapWidth) || undefined,

      scaleX: outSx,

      scaleY: outSy,

      ...readShadow(node),

    };

  }

  if (cls === 'Image') {

    return {

      ...base,

      kind: 'image',

      src: node.attrs?.src || node.image()?.src || '',

      ...readShadow(node),

    };

  }

  if (cls === 'Rect') {

    return {

      ...base,

      kind: 'shape',

      shape: 'rect',

      fill: node.fill(),

      stroke: node.stroke(),

      strokeWidth: node.strokeWidth?.() || 0,

      cornerRadius: node.cornerRadius?.() || 0,

      ...readShadow(node),

    };

  }

  if (cls === 'Circle') {

    const r = node.radius?.() * (node.scaleX?.() || 1);

    return {

      ...base,

      kind: 'shape',

      shape: 'circle',

      x: node.x() - r,

      y: node.y() - r,

      width: r * 2,

      height: r * 2,

      radius: r,

      fill: node.fill(),

      stroke: node.stroke(),

      strokeWidth: node.strokeWidth?.() || 0,

      ...readShadow(node),

    };

  }

  if (cls === 'Line') {

    return {

      ...base,

      kind: 'shape',

      shape: 'line',

      points: node.points(),

      stroke: node.stroke(),

      strokeWidth: node.strokeWidth?.() || 2,

      width: Math.abs((node.points()[2] || 0) - (node.points()[0] || 0)),

      ...readShadow(node),

    };

  }

  if (cls === 'Group' && node.name?.() === 'photo-card') {
    return exportPhotoCardGroup(node);
  }

  if (cls === 'Group' && node.name?.() === 'frame') {
    const fillNode = node.findOne('.frame-fill');
    const fw = node.attrs.width || base.width || 400;
    const fh = node.attrs.height || base.height || 400;
    return {
      ...base,
      x: node.x(),
      y: node.y(),
      width: fw,
      height: fh,
      kind: 'frame',
      clipShape: node.attrs.clipShape || 'rect',
      cornerRadius: node.attrs.cornerRadius || 24,
      maskSrc: node.attrs.maskSrc || '',
      fillSrc: node.attrs.fillSrc
        || fillNode?.attrs?.src
        || fillNode?.image?.()?.src
        || '',
      fillMediaId: node.attrs.fillMediaId || '',
      fillKind: node.attrs.fillKind || (/\.(mp4|webm|mov|m4v)(\?|$)/i.test(String(node.attrs.fillSrc || '')) ? 'video' : 'image'),
      fillOffsetX: node.attrs.fillOffsetX || 0,
      fillOffsetY: node.attrs.fillOffsetY || 0,
      fillFit: node.attrs.fillFit || 'cover',
      fillScale: node.attrs.fillScale || 1,
      fillNaturalW: node.attrs.fillNaturalW || 0,
      fillNaturalH: node.attrs.fillNaturalH || 0,
      stroke: node.attrs.stroke || '#d4c68d',
      strokeWidth: node.attrs.strokeWidth ?? 2,
      strokeDashed: node.attrs.strokeDashed !== false,
      role: node.attrs.role || '',
      displayName: node.attrs.displayName || '',
    };
  }

  return null;

}



export function importLayersToKonva(layer, layers = []) {

  if (!layer || !window.Konva) return;

  for (const spec of layers) {

    const node = layerFromSpec(spec);

    if (node) layer.add(node);

  }

  layer.batchDraw();

}



function layerFromSpec(spec) {

  const K = window.Konva;

  if (!K || !spec) return null;



  if (spec.kind === 'group' && Array.isArray(spec.children)) {
    const group = new K.Group({
      id: spec.id,
      x: spec.x || 0,
      y: spec.y || 0,
      rotation: spec.rotation || 0,
      opacity: spec.opacity ?? 1,
      visible: spec.visible !== false,
      draggable: !spec.locked,
      name: 'designer-group',
    });
    for (const childSpec of spec.children) {
      const child = layerFromSpec(childSpec);
      if (child) group.add(child);
    }
    applyShadowAttrs(group, spec);
    return group;
  }

  if (spec.kind === 'text') {

    const fs = spec.fontSize || 48;
    const textStr = spec.text || '';
    const textFit = spec.textFit || 'wrap';
    let w = Math.abs(spec.width || 800);
    // Evita importar caixas corrompidas (~1 letra de largura → texto empilhado)
    const minImportW = Math.max(Math.ceil(fs * 1.5), 48);
    if (w < minImportW && textStr.length > 1) {
      w = Math.min(
        DESIGN_W - 80,
        Math.max(minImportW, Math.ceil(textStr.length * fs * 0.62 + 32)),
      );
    }
    // Título: nunca importar caixa mais estreita que o texto estimado
    const role = spec.role || '';
    if (role === 'title' && textStr.length > 6) {
      const est = Math.ceil(textStr.length * fs * 0.62 + 40);
      if (w < est) {
        w = Math.min(DESIGN_W - 80, Math.max(est, 800));
      }
    }
    const sx = spec.scaleX || 1;
    const sy = spec.scaleY || 1;
    // AABB export when flipped → Konva top-left + negative scale
    let x = spec.x || 0;
    let y = spec.y || 0;
    if (sx < 0) x += w;
    if (sy < 0) y += Math.abs(spec.height || fs);

    const textNode = new K.Text({

      id: spec.id,

      x,

      y,

      text: textStr,

      fontSize: fs,

      fontFamily: spec.fontFamily || 'Segoe UI',

      fontStyle: spec.fontStyle || 'normal',

      letterSpacing: spec.letterSpacing || 0,

      lineHeight: spec.lineHeight || 1.2,

      fill: spec.fill || '#ffffff',

      align: spec.align || 'center',

      width: w,

      wrap: textFit === 'fit' ? 'none' : 'word',

      opacity: spec.opacity ?? 1,

      visible: spec.visible !== false,

      draggable: !spec.locked,

      role: spec.role || '',

      name: spec.name || 'text',

      scaleX: sx,

      scaleY: sy,

      textFit,

      wrapWidth: Number(spec.wrapWidth) || undefined,

      stroke: spec.strokeWidth > 0 ? (spec.stroke || '#000000') : undefined,

      strokeWidth: spec.strokeWidth || 0,

      listening: true,

    });

    applyShadowAttrs(textNode, spec);

    return textNode;

  }

  if (spec.kind === 'image' && spec.src) {

    const img = new Image();

    const kImg = new K.Image({

      id: spec.id,

      x: spec.x || 0,

      y: spec.y || 0,

      width: spec.width || 400,

      height: spec.height || 300,

      opacity: spec.opacity ?? 1,

      visible: spec.visible !== false,

      draggable: !spec.locked,

      name: spec.name || 'image',

      src: spec.src,

    });

    img.onload = () => {

      kImg.image(img);

      kImg.getLayer()?.batchDraw();

    };

    img.src = spec.src;

    applyShadowAttrs(kImg, spec);

    return kImg;

  }

  if (spec.kind === 'shape' && spec.shape === 'rect') {

    const rectNode = new K.Rect({

      id: spec.id,

      x: spec.x || 0,

      y: spec.y || 0,

      width: spec.width || 200,

      height: spec.height || 100,

      fill: spec.fill || '#d4c68d',

      stroke: spec.stroke || '',

      strokeWidth: spec.strokeWidth || 0,

      cornerRadius: spec.cornerRadius || 0,

      opacity: spec.opacity ?? 1,

      visible: spec.visible !== false,

      draggable: !spec.locked,

      name: spec.name || 'shape',

    });

    applyShadowAttrs(rectNode, spec);

    return rectNode;

  }

  if (spec.kind === 'shape' && spec.shape === 'circle') {

    const r = spec.radius || (spec.width ? spec.width / 2 : 80);

    const circleNode = new K.Circle({

      id: spec.id,

      x: (spec.x || 0) + r,

      y: (spec.y || 0) + r,

      radius: r,

      fill: spec.fill || 'rgba(212,198,141,0.25)',

      stroke: spec.stroke || '#d4c68d',

      strokeWidth: spec.strokeWidth || 2,

      opacity: spec.opacity ?? 1,

      visible: spec.visible !== false,

      draggable: !spec.locked,

      name: spec.name || 'shape',

    });

    applyShadowAttrs(circleNode, spec);

    return circleNode;

  }

  if (spec.kind === 'shape' && spec.shape === 'line') {

    const lineNode = new K.Line({

      id: spec.id,

      x: spec.x || 0,

      y: spec.y || 0,

      points: spec.points || [0, 0, 400, 0],

      stroke: spec.stroke || '#d4c68d',

      strokeWidth: spec.strokeWidth || 3,

      opacity: spec.opacity ?? 1,

      visible: spec.visible !== false,

      draggable: !spec.locked,

      name: spec.name || 'line',

    });

    applyShadowAttrs(lineNode, spec);

    return lineNode;

  }

  if (spec.kind === 'photo-card') {
    const { group } = buildPhotoCardNodes(K, spec);
    bindPhotoCardDrag(group);
    if (spec.fillSrc) {
      const img = new Image();
      img.onload = () => {
        const photoWrap = group.findOne('.card-photo-wrap');
        photoWrap?.findOne('.card-photo-fill')?.destroy();
        const kImg = new K.Image({
          image: img,
          name: 'card-photo-fill',
          listening: false,
          src: spec.fillSrc,
        });
        photoWrap?.add(kImg);
        kImg.moveToBottom();
        layoutPhotoCardFill(group, kImg);
        group.findOne('.card-hit')?.moveToTop();
        group.getLayer()?.batchDraw();
      };
      img.src = spec.fillSrc;
    }
    return group;
  }

  if (spec.kind === 'frame') {
    const w = spec.width || 400;
    const h = spec.height || 400;
    const clipShape = spec.clipShape || 'rect';
    const group = new K.Group({
      id: spec.id,
      x: spec.x || 0,
      y: spec.y || 0,
      width: w,
      height: h,
      rotation: spec.rotation || 0,
      opacity: spec.opacity ?? 1,
      visible: spec.visible !== false,
      draggable: !spec.locked,
      name: 'frame',
      clipShape,
      cornerRadius: spec.cornerRadius || 24,
      maskSrc: spec.maskSrc || '',
      fillSrc: spec.fillSrc || '',
      fillMediaId: spec.fillMediaId || '',
      fillKind: spec.fillKind || 'image',
      fillOffsetX: spec.fillOffsetX || 0,
      fillOffsetY: spec.fillOffsetY || 0,
      fillFit: spec.fillFit || 'cover',
      fillScale: spec.fillScale || 1,
      fillNaturalW: spec.fillNaturalW || 0,
      fillNaturalH: spec.fillNaturalH || 0,
      stroke: spec.stroke || '#d4c68d',
      strokeWidth: spec.strokeWidth ?? 2,
      strokeDashed: spec.strokeDashed !== false,
      role: spec.role || '',
      displayName: spec.displayName || '',
    });
    applyKonvaFrameClip(group, w, h, clipShape, { cornerRadius: spec.cornerRadius || 24 });
    bindFrameLogicalBounds(group);

    const addFillImage = (imgEl, naturalW, naturalH) => {
      const nw = naturalW || imgEl.naturalWidth || imgEl.videoWidth || 0;
      const nh = naturalH || imgEl.naturalHeight || imgEl.videoHeight || 0;
      const layout = computeFrameFillLayout(
        w,
        h,
        nw,
        nh,
        spec.fillFit || 'cover',
        spec.fillScale || 1,
        spec.fillOffsetX || 0,
        spec.fillOffsetY || 0,
      );
      group.attrs.fillNaturalW = nw || spec.fillNaturalW || 0;
      group.attrs.fillNaturalH = nh || spec.fillNaturalH || 0;
      group.add(new K.Image({
        x: layout.x,
        y: layout.y,
        width: layout.width,
        height: layout.height,
        image: imgEl,
        name: 'frame-fill',
        draggable: false,
        listening: false,
        src: spec.fillSrc,
      }));
    };

    if (spec.fillSrc) {
      const isVideo = spec.fillKind === 'video' || /\.(mp4|webm|mov|m4v)(\?|$)/i.test(String(spec.fillSrc));
      if (isVideo) {
        group.attrs.fillKind = 'video';
        const video = document.createElement('video');
        video.muted = true;
        video.loop = true;
        video.playsInline = true;
        video.preload = 'auto';
        group.attrs._fillVideoEl = video;
        video.onloadeddata = () => {
          addFillImage(video, video.videoWidth, video.videoHeight);
          group.findOne('.frame-hit')?.moveToTop();
          group.getLayer()?.batchDraw();
          video.play().catch(() => {});
          if (window.Konva && group.getLayer() && !group.getLayer()._frameVideoAnim) {
            group.getLayer()._frameVideoAnim = new window.Konva.Animation(() => {}, group.getLayer());
            group.getLayer()._frameVideoAnim.start();
          }
        };
        video.src = spec.fillSrc;
      } else {
        const img = new Image();
        img.onload = () => {
          addFillImage(img);
          group.findOne('.frame-hit')?.moveToTop();
          group.getLayer()?.batchDraw();
        };
        img.src = spec.fillSrc;
      }
    } else {
      group.add(new K.Rect({
        x: 0, y: 0, width: w, height: h,
        fill: 'rgba(60,60,60,0.55)',
        name: 'frame-fill',
        listening: false,
      }));
    }

    if (spec.maskSrc) {
      const maskImg = new Image();
      maskImg.onload = () => {
        group.add(new K.Image({
          x: 0,
          y: 0,
          width: w,
          height: h,
          image: maskImg,
          listening: false,
          name: 'frame-mask',
          globalCompositeOperation: 'destination-in',
        }));
        group.findOne('.frame-border')?.destroy();
        group.findOne('.frame-fill')?.moveToBottom?.();
        group.findOne('.frame-mask')?.moveToTop?.();
        group.findOne('.frame-hit')?.moveToTop();
        group.getLayer()?.batchDraw();
      };
      maskImg.src = spec.maskSrc;
    } else {
      group.add(createFrameBorderNode(K, w, h, clipShape, {
        stroke: spec.stroke || '#d4c68d',
        strokeWidth: spec.strokeWidth ?? 2,
        strokeDashed: spec.strokeDashed !== false,
        cornerRadius: spec.cornerRadius || 24,
      }));
    }
    group.add(makeFrameHitRect(K, w, h));
    bindFrameDrag(group);
    return group;
  }

}



export { DESIGN_W, DESIGN_H };

