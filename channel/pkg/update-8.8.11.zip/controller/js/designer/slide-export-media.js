/**
 * Export PNG/PDF do stage Konva (U2-G) — 1920×1080 offline.
 */
import { DESIGN_W, DESIGN_H } from './slide-exporter.js';

function hideChrome(stage) {
  const hide = [];
  const nodes = stage.getChildren?.()[0]?.getChildren?.() || [];
  for (const n of nodes) {
    const nm = n.name?.() || '';
    if (nm === 'grid' || nm === 'safe-zone' || n.getClassName?.() === 'Transformer') {
      if (n.visible()) {
        n.visible(false);
        hide.push(n);
      }
    }
  }
  stage.draw?.();
  return () => {
    hide.forEach((n) => n.visible(true));
    stage.draw?.();
  };
}

/**
 * @returns {string|null} data URL PNG
 */
export function stageToPngDataUrl(stage, { width = DESIGN_W, height = DESIGN_H } = {}) {
  if (!stage) return null;
  const restore = hideChrome(stage);
  try {
    const pixelRatio = width / (stage.width?.() || DESIGN_W);
    return stage.toDataURL({
      mimeType: 'image/png',
      pixelRatio: Math.max(pixelRatio, 1),
      width,
      height,
    });
  } catch {
    return null;
  } finally {
    restore();
  }
}

export function downloadStagePng(stage, filename = 'slide-1920x1080.png') {
  const url = stageToPngDataUrl(stage);
  if (!url) return false;
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  return true;
}

/**
 * Abre janela de impressão com a imagem do slide (PDF via diálogo do SO).
 */
export function exportStagePdfViaPrint(stage, title = 'SOMOSUM Slide') {
  const url = stageToPngDataUrl(stage);
  if (!url) return false;
  const w = window.open('', '_blank', 'noopener,noreferrer,width=1100,height=700');
  if (!w) return false;
  w.document.write(`<!DOCTYPE html><html><head><title>${title}</title>
    <style>
      @page { size: landscape; margin: 0; }
      html, body { margin: 0; background: #111; }
      img { width: 100vw; height: 100vh; object-fit: contain; display: block; }
    </style></head><body>
    <img src="${url}" alt="slide" onload="setTimeout(function(){print();},200)" />
    </body></html>`);
  w.document.close();
  return true;
}

export { DESIGN_W, DESIGN_H };
