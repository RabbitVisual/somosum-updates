import { DESIGN_W, DESIGN_H, exportSlideFromStage, importLayersToKonva } from './slide-exporter.js';
import { canvasShapeMethods } from './canvas-shapes.js';
import { canvasToolMethods } from './canvas-tools.js';
import { canvasBackgroundMethods } from './canvas-background.js';
import { canvasLayerMethods } from './canvas-layer-ops.js';
import { SAFE_PAD, getSafeZoneViolations } from './safe-zone.js';

export const CANVAS_ENGINE_VERSION = '3.17.0';



export class CanvasEngine {

  constructor(container, { onSelect, onChange } = {}) {

    this.container = container;

    this.onSelect = onSelect;

    this.onChange = onChange;

    this.stage = null;

    this.layer = null;

    this.transformer = null;

    this.selectedNode = null;

    this.selectedNodes = [];

    this.smartGuidesEnabled = true;

    this._guideGroup = null;

    this.snapGrid = 20;

    this._history = [];

    this._historyIdx = -1;

    this._bgImageNode = null;

    this._bootstrapping = false;

    this._zoomFactor = 1;

  }



  _computeScale() {

    const wrapW = Math.max(

      this.container?.clientWidth || 0,

      this.container?.parentElement?.clientWidth || 0,

      this.container?.offsetWidth || 0,

      720

    );

    const wrapH = Math.max(

      this.container?.clientHeight || 0,

      this.container?.parentElement?.clientHeight || 0,

      400

    );

    return Math.min(wrapW / DESIGN_W, wrapH / DESIGN_H, 0.92) * (this._zoomFactor || 1);

  }



  setZoom(delta) {

    const next = Math.min(1.35, Math.max(0.65, (this._zoomFactor || 1) + delta));

    this._zoomFactor = next;

    this.resize();

    return next;

  }

  resetZoom() {

    this._zoomFactor = 1;

    this.resize();

    return 1;

  }



  init() {

    if (!window.Konva) {

      this.container.innerHTML = '<div class="designer-error">Konva não carregado — verifique vendor/konva.min.js</div>';

      return false;

    }

    const wrapW = Math.max(

      this.container.clientWidth,

      this.container.parentElement?.clientWidth || 0,

      this.container.offsetWidth || 0,

      720

    );

    if (wrapW < 80) {
      this.container.innerHTML = '<div class="designer-loading">Preparando canvas…</div>';
      if (typeof ResizeObserver !== 'undefined') {
        const ro = new ResizeObserver(() => {
          const w = this.container.clientWidth || this.container.parentElement?.clientWidth || 0;
          if (w >= 80) {
            ro.disconnect();
            this.init();
          }
        });
        ro.observe(this.container);
        if (this.container.parentElement) ro.observe(this.container.parentElement);
      }
      return false;
    }

    const scale = this._computeScale();



    this.container.innerHTML = '';

    this.stage = new Konva.Stage({

      container: this.container,

      width: DESIGN_W * scale,

      height: DESIGN_H * scale,

      scale: { x: scale, y: scale },

    });



    this.layer = new Konva.Layer();

    this.stage.add(this.layer);



    const bg = new Konva.Rect({

      x: 0,

      y: 0,

      width: DESIGN_W,

      height: DESIGN_H,

      fill: '#0a0a0a',

      name: 'design-bg',

      listening: false,

    });

    this.layer.add(bg);



    this._drawGrid();

    this._drawSafeZone();



    this._createTransformer();

    this._bindStageEvents();



    this._bootstrapping = true;

    this.selectNode(null);

    this._bootstrapping = false;

    this._pushHistory();

    requestAnimationFrame(() => this.resize());

    return true;

  }



  _isUnderTransformer(node) {
    let n = node;
    while (n && n !== this.layer && n !== this.stage) {
      if (n === this.transformer || n.getClassName?.() === 'Transformer') return true;
      n = n.getParent?.();
    }
    return false;
  }

  _isSystemNode(node) {

    if (!node) return true;

    const name = node.name?.() || '';

    if (['grid', 'safe-zone', 'design-bg', 'design-bg-image', 'design-bg-dim', 'smart-guides', 'safe-warn'].includes(name)) return true;

    if (node.getClassName?.() === 'Transformer') return true;

    // Handles / área do Transformer — anexá-los a si mesmos = Maximum call stack
    if (name === 'back' || String(name).includes('_anchor')) return true;
    if (this._isUnderTransformer(node)) return true;

    return false;

  }



  _createTransformer() {

    this.transformer = new Konva.Transformer({

      rotateEnabled: true,

      ignoreStroke: true,

      enabledAnchors: ['top-left', 'top-right', 'bottom-left', 'bottom-right', 'middle-left', 'middle-right', 'top-center', 'bottom-center'],

      boundBoxFunc: (oldBox, newBox) => {
        // Texto: não permitir caixa ~1 letra (vira C/B/A/V)
        const sel = this.selectedNode;
        const isText = sel?.getClassName?.() === 'Text';
        const minW = isText ? Math.max(48, (sel.fontSize?.() || 48) * 1.2) : 16;
        const minH = isText ? Math.max(24, (sel.fontSize?.() || 48) * 0.6) : 16;
        if (newBox.width < minW || newBox.height < minH) return oldBox;
        return newBox;
      },

    });

    this.layer.add(this.transformer);

  }



  _ensureTransformer() {

    if (this.transformer?.getStage()) return;

    this.transformer = this.stage?.findOne?.('Transformer')

      || this.layer?.getChildren?.().find((n) => n.getClassName?.() === 'Transformer');

    if (!this.transformer?.getStage()) {

      this._createTransformer();

    }

  }



  _findContentRoot(node) {
    let n = node;
    while (n && n !== this.layer && n !== this.stage) {
      const nm = n.name?.();
      if (nm === 'frame' || nm === 'photo-card' || nm === 'designer-group') return n;
      n = n.getParent();
    }
    return node;
  }

  _bindStageEvents() {

    if (!this.stage || !this.layer) return;

    this.stage.off('click tap');
    this.stage.off('mousedown touchstart');

    this.layer.off('dragend transformend');

    this.layer.off('dragmove');

    this._ignoreNextStageClick = false;

    const pickFromEvent = (e) => {
      if (this._ignoreNextStageClick && e.type !== 'mousedown' && e.type !== 'touchstart') {
        this._ignoreNextStageClick = false;
        return;
      }

      // Clique no Transformer / handles: NÃO re-selecionar nem limpar (evita stack overflow + perda de seleção)
      if (e.target?.getClassName?.() === 'Transformer' || this._isUnderTransformer?.(e.target)) {
        return;
      }

      const tName = e.target?.name?.() || '';
      if (e.target === this.stage
        || tName === 'design-bg'
        || tName === 'design-bg-image'
        || tName === 'design-bg-dim'
        || tName === 'grid'
        || tName === 'safe-zone'
        || tName === 'safe-warn') {
        if (e.type === 'mousedown' || e.type === 'touchstart' || e.type === 'click' || e.type === 'tap') {
          this.selectNode(null);
        }
        return;
      }

      const multi = !!(e.evt?.shiftKey || e.evt?.ctrlKey || e.evt?.metaKey);
      const root = this._findContentRoot(e.target);
      if (root && !this._isSystemNode(root)) {
        // Já selecionado: não reanexa Transformer no mousedown (libera o arraste)
        if (!multi
          && (e.type === 'mousedown' || e.type === 'touchstart')
          && this.selectedNode === root
          && this.selectedNodes?.length === 1) {
          return;
        }
        this.selectNode(root, { multi });
      }
    };

    // pointerdown seleciona de imediato (mais confiável que só click no WebView2)
    this.stage.on('mousedown touchstart', (e) => {
      if (e.evt?.button != null && e.evt.button !== 0) return;
      // Moldura / photo-card: bindFrameDrag / card-hit já selecionam + startDrag.
      // Se o stage também chamar selectNode, o Transformer interrompe o arraste.
      const root = this._findContentRoot?.(e.target);
      const nm = root?.name?.() || '';
      if (nm === 'frame' || nm === 'photo-card') return;
      pickFromEvent(e);
    });

    this.stage.on('click tap', (e) => {
      pickFromEvent(e);
    });

    this.stage.on('dblclick dbltap', (e) => {
      if (window.__SOMOSUM_LIVE_ACTIVE) return;
      const root = this._findContentRoot?.(e.target) || e.target;
      if (!root || this._isSystemNode(root)) return;
      this.selectNode(root);
      if (root.getClassName?.() === 'Text') {
        this.startInlineTextEdit?.(root);
      }
    });

    this.layer.on('dragmove', (e) => {
      if (window.__SOMOSUM_LIVE_ACTIVE) return;
      const node = e.target;
      if (this._isSystemNode(node)) return;
      if (this.smartGuidesEnabled !== false) this._updateSmartGuides(node);
    });

    this.layer.on('dragend transformend', (e) => {
      if (window.__SOMOSUM_LIVE_ACTIVE) return;

      const node = e.target;
      if (this._isSystemNode(node)) return;

      this._clearSmartGuides();

      const root = this._findContentRoot?.(node) || node;

      if (root?.name?.() === 'frame') {
        this.normalizeFrameTransform?.(root);
        this._snapNode(root);
        try { this.transformer?.forceUpdate?.(); } catch { /* ignore */ }
      } else {
        const target = root || node;
        this.normalizeNodeTransform?.(target);
        this._snapNode(target);
        try { this.transformer?.forceUpdate?.(); } catch { /* ignore */ }
      }

      if (root?.getClassName?.() === 'Text' || node?.getClassName?.() === 'Text') {
        this.healTextLayout?.(root?.getClassName?.() === 'Text' ? root : node);
      }

      this._flagSafeZoneWarn?.(root || node);
      this._ignoreNextStageClick = true;
      this.onChange?.();
      this._pushHistory();
    });

  }

  _flagSafeZoneWarn(node) {
    try {
      const hits = getSafeZoneViolations(this);
      const bad = hits.some((v) => v.node === node || v.id === node.id?.());
      node.setAttr?.('_safeWarn', !!bad);
      this._drawSafeWarnOverlay?.(bad ? node : null);
    } catch { /* optional */ }
  }

  _drawSafeWarnOverlay(node) {
    this._safeWarnRect?.destroy?.();
    this._safeWarnRect = null;
    if (!node || !this.layer) return;
    let box;
    try {
      box = node.getClientRect({ relativeTo: this.layer, skipShadow: true });
    } catch {
      return;
    }
    this._safeWarnRect = new Konva.Rect({
      x: box.x - 2,
      y: box.y - 2,
      width: box.width + 4,
      height: box.height + 4,
      stroke: 'rgba(220,60,60,0.95)',
      strokeWidth: 2,
      dash: [8, 6],
      listening: false,
      name: 'safe-warn',
    });
    this.layer.add(this._safeWarnRect);
    this._safeWarnRect.moveToTop();
    this.transformer?.moveToTop();
    this.layer.batchDraw();
  }

  /**
   * Inline textarea over Konva.Text — Enter/blur commit, Esc cancel.
   */
  startInlineTextEdit(node) {
    if (!node || node.getClassName?.() !== 'Text' || !this.stage) return;
    this.endInlineTextEdit?.(false);
    this.onSelect?.(node);

    const stage = this.stage;
    const container = stage.container();
    const scale = stage.scaleX() || 1;
    const box = node.getClientRect({ relativeTo: this.layer, skipShadow: true });
    const stageBox = container.getBoundingClientRect();

    const ta = document.createElement('textarea');
    ta.className = 'designer-inline-edit';
    ta.value = node.text() || '';
    ta.style.cssText = [
      'position:fixed',
      `left:${stageBox.left + box.x * scale}px`,
      `top:${stageBox.top + box.y * scale}px`,
      `width:${Math.max(80, box.width * scale)}px`,
      `min-height:${Math.max(28, box.height * scale)}px`,
      `font-size:${(node.fontSize() || 48) * scale}px`,
      `font-family:${node.fontFamily() || 'Segoe UI'}`,
      `color:${node.fill() || '#fff'}`,
      `text-align:${node.align() || 'center'}`,
      'line-height:1.2',
      'background:rgba(10,10,10,0.92)',
      'border:2px solid #d4c68d',
      'border-radius:4px',
      'padding:4px 8px',
      'z-index:600',
      'resize:both',
      'outline:none',
      'box-shadow:0 8px 24px rgba(0,0,0,0.45)',
    ].join(';');

    const commit = () => {
      if (this._inlineEditClosing) return;
      this._inlineEditClosing = true;
      const next = ta.value;
      const target = node;
      this.endInlineTextEdit(true);
      this._inlineEditClosing = false;
      if (next !== target.text()) {
        target.text(next);
        if ((target.getAttr?.('textFit') || target.attrs?.textFit) === 'fit') {
          this.fitTextBox?.(target, { silent: false });
        } else {
          this.layer.batchDraw();
          this.onChange?.();
          this._pushHistory?.();
        }
      }
    };
    const cancel = () => {
      if (this._inlineEditClosing) return;
      this._inlineEditClosing = true;
      this.endInlineTextEdit(false);
      this._inlineEditClosing = false;
    };

    ta.addEventListener('keydown', (ev) => {
      if (ev.key === 'Escape') {
        ev.preventDefault();
        cancel();
      } else if (ev.key === 'Enter' && !ev.shiftKey) {
        ev.preventDefault();
        commit();
      }
    });
    ta.addEventListener('blur', () => {
      if (this._inlineEditClosing) return;
      commit();
    });

    document.body.appendChild(ta);
    this._inlineEditEl = ta;
    this._inlineEditNode = node;
    node.visible(false);
    this.layer.batchDraw();
    queueMicrotask(() => {
      try {
        ta.focus();
        ta.select();
      } catch { /* ignore */ }
    });
  }

  endInlineTextEdit(committed) {
    if (this._inlineEditNode) {
      try { this._inlineEditNode.visible(true); } catch { /* ignore */ }
      this._inlineEditNode = null;
    }
    const el = this._inlineEditEl;
    this._inlineEditEl = null;
    if (el) {
      try {
        el.onblur = null;
        if (el.isConnected) el.remove();
        else el.parentNode?.removeChild?.(el);
      } catch { /* já removido no blur */ }
    }
    this.layer?.batchDraw?.();
    void committed;
  }



  _restackSystemNodes() {
    if (!this.layer) return;

    const bg = this.layer.findOne('.design-bg');
    const dim = this.layer.findOne('.design-bg-dim');
    const grid = this.layer.findOne('.grid');
    const safe = this.layer.findOne('.safe-zone');

    bg?.listening(false);
    this._bgImageNode?.listening?.(false);
    dim?.listening(false);
    grid?.listening(false);
    safe?.listening(false);

    // Empurra só o fundo para baixo (sem reindexar todo o conteúdo — evita loops no Konva)
    // Ordem final (baixo→cima): bg → image → dim → grid → [conteúdo] → safe → transformer
    grid?.moveToBottom();
    dim?.moveToBottom();
    this._bgImageNode?.moveToBottom();
    bg?.moveToBottom();

    safe?.moveToTop();
    this.transformer?.moveToTop();
  }



  findNode(id) {

    if (!this.layer || !id) return null;

    const sid = String(id);
    try {
      const bySelector = this.stage?.findOne?.(`#${CSS.escape ? CSS.escape(sid) : sid}`);
      if (bySelector) return bySelector;
    } catch { /* ignore selector errors */ }

    for (const n of this.layer.getChildren()) {
      if (n.id && n.id() === sid) return n;
      if (typeof n.findOne === 'function') {
        const nested = n.findOne?.((node) => node.id?.() === sid);
        if (nested) return nested;
      }
    }

    return null;

  }



  getContentNodes() {

    return (this.layer?.getChildren() || []).filter((n) => !this._isSystemNode(n));

  }



  _drawGrid() {

    const g = new Konva.Group({ name: 'grid', listening: false });

    for (let x = 0; x <= DESIGN_W; x += this.snapGrid) {

      g.add(new Konva.Line({

        points: [x, 0, x, DESIGN_H],

        stroke: 'rgba(255,255,255,0.04)',

        strokeWidth: 1,

      }));

    }

    for (let y = 0; y <= DESIGN_H; y += this.snapGrid) {

      g.add(new Konva.Line({

        points: [0, y, DESIGN_W, y],

        stroke: 'rgba(255,255,255,0.04)',

        strokeWidth: 1,

      }));

    }

    this.layer.add(g);

    g.moveToBottom();

    this.layer.findOne('.design-bg')?.moveToBottom();

  }



  _drawSafeZone() {

    const pad = SAFE_PAD;

    const rect = new Konva.Rect({

      x: pad,

      y: pad,

      width: DESIGN_W - pad * 2,

      height: DESIGN_H - pad * 2,

      stroke: 'rgba(212,198,141,0.25)',

      dash: [12, 8],

      name: 'safe-zone',

      listening: false,

    });

    this.layer.add(rect);

  }



  _snapNode(node) {

    if (!node || !node.draggable?.()) return;

    const g = this.snapGrid;

    node.x(Math.round(node.x() / g) * g);

    node.y(Math.round(node.y() / g) * g);

    this.layer.batchDraw();

  }

  _clearSmartGuides() {
    if (this._guideGroup) {
      this._guideGroup.destroy();
      this._guideGroup = null;
      this.layer?.batchDraw();
    }
  }

  _updateSmartGuides(node) {
    if (!this.layer || !node) return;
    this._clearSmartGuides();
    const { w, h } = this._nodeSize(node);
    let x = node.x();
    let y = node.y();
    const cx = x + w / 2;
    const cy = y + h / 2;
    const thr = window.__SOMOSUM_LOW_SPEC ? 8 : 6;
    const guides = [];
    const snapX = [];
    const snapY = [];

    const targets = [
      { v: DESIGN_W / 2, axis: 'x', kind: 'center' },
      { v: DESIGN_H / 2, axis: 'y', kind: 'center' },
      { v: SAFE_PAD, axis: 'x', kind: 'safe' },
      { v: DESIGN_W - SAFE_PAD, axis: 'x', kind: 'safe' },
      { v: SAFE_PAD, axis: 'y', kind: 'safe' },
      { v: DESIGN_H - SAFE_PAD, axis: 'y', kind: 'safe' },
    ];

    for (const other of this.getContentNodes()) {
      if (other === node) continue;
      const ow = this._nodeSize(other);
      const ox = other.x();
      const oy = other.y();
      targets.push(
        { v: ox, axis: 'x', kind: 'edge' },
        { v: ox + ow.w / 2, axis: 'x', kind: 'mid' },
        { v: ox + ow.w, axis: 'x', kind: 'edge' },
        { v: oy, axis: 'y', kind: 'edge' },
        { v: oy + ow.h / 2, axis: 'y', kind: 'mid' },
        { v: oy + ow.h, axis: 'y', kind: 'edge' },
      );
    }

    for (const t of targets) {
      if (t.axis === 'x') {
        const candidates = [
          { delta: Math.abs(cx - t.v), apply: () => { x = t.v - w / 2; } },
          { delta: Math.abs(x - t.v), apply: () => { x = t.v; } },
          { delta: Math.abs(x + w - t.v), apply: () => { x = t.v - w; } },
        ];
        const best = candidates.sort((a, b) => a.delta - b.delta)[0];
        if (best.delta <= thr) {
          best.apply();
          snapX.push(t.v);
          guides.push({ axis: 'x', v: t.v });
        }
      } else {
        const candidates = [
          { delta: Math.abs(cy - t.v), apply: () => { y = t.v - h / 2; } },
          { delta: Math.abs(y - t.v), apply: () => { y = t.v; } },
          { delta: Math.abs(y + h - t.v), apply: () => { y = t.v - h; } },
        ];
        const best = candidates.sort((a, b) => a.delta - b.delta)[0];
        if (best.delta <= thr) {
          best.apply();
          snapY.push(t.v);
          guides.push({ axis: 'y', v: t.v });
        }
      }
    }

    if (snapX.length || snapY.length) {
      node.x(x);
      node.y(y);
    }

    if (!guides.length) return;
    this._guideGroup = new Konva.Group({ name: 'smart-guides', listening: false });
    for (const g of guides) {
      if (g.axis === 'x') {
        this._guideGroup.add(new Konva.Line({
          points: [g.v, 0, g.v, DESIGN_H],
          stroke: 'rgba(212,175,55,0.85)',
          strokeWidth: 1,
          dash: [8, 6],
        }));
      } else {
        this._guideGroup.add(new Konva.Line({
          points: [0, g.v, DESIGN_W, g.v],
          stroke: 'rgba(212,175,55,0.85)',
          strokeWidth: 1,
          dash: [8, 6],
        }));
      }
    }
    this.layer.add(this._guideGroup);
    this._guideGroup.moveToTop();
    this.transformer?.moveToTop();
    this.layer.batchDraw();
  }



  selectNode(node, { multi = false } = {}) {

    this._ensureTransformer();

    if (!this.selectedNodes) this.selectedNodes = [];

    // Evita reentrada (selectNode → Transformer.nodes → getClientRect → stack overflow)
    if (this._selectingNode) return;
    this._selectingNode = true;
    try {

    if (!node) {

      this.selectedNode = null;

      this.selectedNodes = [];

      try {
        this.transformer.nodes([]);
      } catch { /* ignore */ }

      this.layer.batchDraw();

      if (!this._bootstrapping) this.onSelect?.(null);

      return;

    }

    // Nó de sistema / handle do Transformer: ignora (NÃO limpa a seleção atual)
    if (this._isSystemNode(node)) {
      return;
    }

    // Já selecionado sozinho — NÃO chamar transformer.nodes() (getter recurse no Konva 10)
    // Ainda assim notifica o painel (pode ter ficado dessincronizado: "Nenhum elemento selecionado")
    if (!multi && this.selectedNode === node && this.selectedNodes?.length === 1) {
      try {
        this.transformer?.moveToTop();
        this.layer.batchDraw();
      } catch { /* ignore */ }
      if (!this._bootstrapping) this.onSelect?.(this.selectedNode);
      return;
    }

    if (multi) {

      const idx = this.selectedNodes.indexOf(node);

      if (idx >= 0) this.selectedNodes.splice(idx, 1);

      else this.selectedNodes.push(node);

    } else {

      this.selectedNodes = [node];

    }

    this.selectedNode = this.selectedNodes[this.selectedNodes.length - 1] || null;

    // Nunca anexar Transformer a si mesmo / nós de sistema / handles
    const nodes = this.selectedNodes.filter((n) => n
      && n.getStage?.()
      && n !== this.transformer
      && n.getClassName?.() !== 'Transformer'
      && !this._isSystemNode(n)
      && !this._isUnderTransformer?.(n));

    if (nodes.length) {

      const isCard = nodes.length === 1 && nodes[0].name?.() === 'photo-card';

      try {
        // Detach primeiro — evita estado sujo no __getNodeRect
        this.transformer.nodes([]);
        this.transformer.resizeEnabled(!isCard && nodes.length === 1);
        this.transformer.enabledAnchors(isCard || nodes.length > 1 ? [] : [
          'top-left', 'top-right', 'bottom-left', 'bottom-right',
          'middle-left', 'middle-right', 'top-center', 'bottom-center',
        ]);
        this.transformer.rotateEnabled(nodes.length === 1);
        this.transformer.nodes(nodes);
        this.transformer.moveToTop();
      } catch { /* ignore Konva transform cache glitches */ }

    } else {

      try { this.transformer.nodes([]); } catch { /* ignore */ }

    }

    this.layer.batchDraw();

    if (!this._bootstrapping) {

      this.onSelect?.(this.selectedNode);

    }

    } finally {
      this._selectingNode = false;
    }

  }



  exportSlide(meta) {

    return exportSlideFromStage(this.stage, meta);

  }



  loadPreset(preset) {

    if (!preset) return;

    this.clearContent();

    if (preset.background) this.setBackground(preset.background);

    if (preset.layers?.length) importLayersToKonva(this.layer, preset.layers);

    this._restackSystemNodes();

    this.rebindFrameInteractions?.();

    this._ensureTransformer();

    this.selectNode(null);

    this.scheduleFitTextBoxes?.();

    this._pushHistory();

    this.onChange?.();

  }



  loadSlide(slide) {

    if (!slide?.layers?.length) {

      this.clearContent();

      if (slide?.background) this.setBackground(slide.background);

      if (slide?.title) this.addText(slide.title, { role: 'title', fontSize: 76 });

      if (slide?.text) this.addText(slide.text, { role: 'body', fontSize: 40, y: DESIGN_H / 2 });

      this.scheduleFitTextBoxes?.();

      return;

    }

    this.clearContent();

    if (slide.background) this.setBackground(slide.background);

    importLayersToKonva(this.layer, slide.layers);

    this._restackSystemNodes();

    this.rebindFrameInteractions?.();

    this._ensureTransformer();

    this.selectNode(null);

    this.scheduleFitTextBoxes?.();

    this._pushHistory();

  }



  clearContent() {

    this.selectNode(null);

    this._removeBgImage();
    this._clearBgVideo?.();

    const remove = this.getContentNodes();

    remove.forEach((n) => n.destroy());

    const designBg = this.layer.findOne('.design-bg');

    if (designBg) {

      designBg.visible(true);

      designBg.fill('#0a0a0a');

    }

    this._ensureTransformer();

    this.layer.batchDraw();

  }



  resize() {

    if (!this.container || !this.stage) return;

    const wrapW = Math.max(

      this.container.clientWidth,

      this.container.parentElement?.clientWidth || 0,

      720

    );

    const scale = this._computeScale();

    this.stage.width(DESIGN_W * scale);

    this.stage.height(DESIGN_H * scale);

    this.stage.scale({ x: scale, y: scale });

    this.stage.batchDraw();

  }



  destroy() {

    this.endInlineTextEdit?.(false);
    this._safeWarnRect?.destroy?.();
    this._clearBgVideo?.();
    this.stage?.destroy();

    this.stage = null;

  }

}

Object.assign(CanvasEngine.prototype, canvasShapeMethods, canvasToolMethods, canvasBackgroundMethods, canvasLayerMethods);


