/**
 * Sombra Konva só existe em Shape (não em Group).
 * Helpers seguros para ler/aplicar em nó ou filhos de Group (moldura/card).
 */

function isShadowShape(node) {
  return !!(node && typeof node.shadowBlur === 'function');
}

/** Alvos que aceitam sombra: o próprio Shape, ou shapes dentro de um Group. */
export function shadowTargets(node) {
  if (!node) return [];
  if (isShadowShape(node)) return [node];
  const out = [];
  const walk = (n) => {
    if (!n || n.getClassName?.() === 'Transformer') return;
    if (isShadowShape(n)) {
      out.push(n);
      return;
    }
    if (typeof n.getChildren === 'function') {
      for (const child of n.getChildren()) walk(child);
    }
  };
  walk(node);
  // Preferir mídia/texto visível (evita sombra só no hit-rect invisível)
  const preferred = out.filter((n) => {
    const nm = n.name?.() || '';
    const cls = n.getClassName?.() || '';
    if (nm.includes('hit') || nm.includes('border-guide')) return false;
    if (cls === 'Text' || cls === 'Image' || cls === 'Rect' || cls === 'Circle') return true;
    return !nm;
  });
  return preferred.length ? preferred : out;
}

export function getShadowState(node) {
  const targets = shadowTargets(node);
  const src = targets[0] || node;
  const blur = isShadowShape(src)
    ? (src.shadowBlur() || 0)
    : (typeof src?.getAttr === 'function' ? (src.getAttr('shadowBlur') || 0) : 0);
  let ox = 0;
  let oy = 0;
  if (isShadowShape(src)) {
    if (typeof src.shadowOffset === 'function') {
      const off = src.shadowOffset() || {};
      ox = off.x || 0;
      oy = off.y || 0;
    } else {
      ox = src.shadowOffsetX?.() ?? 0;
      oy = src.shadowOffsetY?.() ?? 0;
    }
  }
  const color = isShadowShape(src)
    ? (src.shadowColor?.() || 'rgba(0,0,0,0.55)')
    : 'rgba(0,0,0,0.55)';
  return { blur: Number(blur) || 0, offsetX: ox, offsetY: oy, color };
}

export function applyShadowState(node, patch = {}) {
  const targets = shadowTargets(node);
  if (!targets.length) return false;
  for (const t of targets) {
    if (patch.blur != null && typeof t.shadowBlur === 'function') {
      t.shadowBlur(Number(patch.blur) || 0);
    }
    if (patch.color != null && typeof t.shadowColor === 'function') {
      t.shadowColor(patch.color);
    }
    if (patch.offsetX != null && typeof t.shadowOffsetX === 'function') {
      t.shadowOffsetX(Number(patch.offsetX) || 0);
    }
    if (patch.offsetY != null && typeof t.shadowOffsetY === 'function') {
      t.shadowOffsetY(Number(patch.offsetY) || 0);
    }
    if (patch.offset && typeof t.shadowOffset === 'function') {
      t.shadowOffset({
        x: Number(patch.offset.x) || 0,
        y: Number(patch.offset.y) || 0,
      });
    } else if (patch.offset) {
      if (typeof t.shadowOffsetX === 'function') t.shadowOffsetX(Number(patch.offset.x) || 0);
      if (typeof t.shadowOffsetY === 'function') t.shadowOffsetY(Number(patch.offset.y) || 0);
    }
    if (typeof t.shadowEnabled === 'function') {
      const blur = typeof t.shadowBlur === 'function' ? (t.shadowBlur() || 0) : 0;
      t.shadowEnabled(blur > 0);
    }
    if (patch.opacity != null && typeof t.shadowOpacity === 'function') {
      t.shadowOpacity(patch.opacity);
    }
  }
  return true;
}
