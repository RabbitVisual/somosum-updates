import { DESIGN_W, DESIGN_H } from './slide-exporter.js';
import { resolveWelcomePreset, WELCOME_PRESETS } from '../slides/welcome-config.js';
import { SAFE_PAD } from './safe-zone.js';
import { PRODUCT_LOGO_REL } from '../core/brand-assets.js';

const W = DESIGN_W;
const H = DESIGN_H;
const SAFE_INNER_W = W - SAFE_PAD * 2;

const WRAP_ROLES = new Set(['verse', 'body', 'quote', 'subtitle', 'theme', 'title']);

function estimateTextWidth(text, fontSize, opts = {}) {
  const pad = opts.pad ?? Math.max(32, Math.round(fontSize * 0.4));
  // 0.62 cobre serif/bold melhor que 0.56 (evitava "Título do slide" cortado)
  const approx = Math.ceil(String(text || '').length * fontSize * 0.62) + pad;
  const max = opts.max ?? SAFE_INNER_W;
  const min = opts.min ?? Math.max(120, Math.round(fontSize * 2));
  return Math.min(max, Math.max(min, approx));
}

function txt(id, text, opts = {}) {
  const fontSize = opts.fontSize ?? 64;
  const role = opts.role || '';
  // Títulos/corpo: caixa larga com wrap por padrão (não cortar no canvas)
  const wrap = opts.wrap != null
    ? opts.wrap === true
    : (WRAP_ROLES.has(role) || role === 'title' || (String(text || '').length > 10 && role !== 'reference'));
  const width = opts.width != null
    ? opts.width
    : (wrap ? SAFE_INNER_W : estimateTextWidth(text, fontSize));
  const x = opts.x != null
    ? opts.x
    : Math.round((W - width) / 2);
  return {
    id,
    kind: 'text',
    name: opts.name || 'text',
    role,
    text,
    x,
    y: opts.y ?? 400,
    width,
    fontSize,
    fontFamily: opts.fontFamily || 'Segoe UI',
    fill: opts.fill || '#ffffff',
    align: opts.align || 'center',
    fontStyle: opts.fontStyle || 'normal',
    textFit: opts.textFit || (wrap ? 'wrap' : 'fit'),
  };
}

function img(id, src, opts = {}) {
  return {
    id,
    kind: 'image',
    name: opts.name || 'image',
    role: opts.role || '',
    src,
    x: opts.x ?? 0,
    y: opts.y ?? 0,
    width: opts.width ?? 400,
    height: opts.height ?? 300,
    locked: opts.locked ?? false,
  };
}

function rect(id, opts = {}) {
  return {
    id,
    kind: 'shape',
    shape: 'rect',
    name: opts.name || 'shape',
    x: opts.x ?? W / 2 - 200,
    y: opts.y ?? H / 2 - 60,
    width: opts.width ?? 400,
    height: opts.height ?? 120,
    fill: opts.fill ?? 'rgba(212,198,141,0.35)',
    stroke: opts.stroke || '',
    strokeWidth: opts.strokeWidth || 0,
    cornerRadius: opts.cornerRadius ?? 8,
    locked: opts.locked ?? false,
  };
}

function circle(id, opts = {}) {
  return {
    id,
    kind: 'shape',
    shape: 'circle',
    name: opts.name || 'shape',
    x: opts.x ?? W / 2 - 80,
    y: opts.y ?? H / 2 - 80,
    width: opts.radius ? opts.radius * 2 : 160,
    height: opts.radius ? opts.radius * 2 : 160,
    radius: opts.radius ?? 80,
    fill: opts.fill ?? 'rgba(212,198,141,0.25)',
    stroke: opts.stroke || '#d4c68d',
    strokeWidth: opts.strokeWidth ?? 2,
    locked: opts.locked ?? false,
  };
}

function line(id, opts = {}) {
  return {
    id,
    kind: 'shape',
    shape: 'line',
    name: opts.name || 'line',
    x: opts.x ?? 200,
    y: opts.y ?? 540,
    width: opts.width ?? W - 400,
    points: opts.points || [0, 0, W - 400, 0],
    stroke: opts.stroke || '#d4c68d',
    strokeWidth: opts.strokeWidth ?? 3,
    locked: opts.locked ?? false,
  };
}

export const DESIGNER_PRESET_CATALOG = [
  { id: 'blank', label: 'Em branco', icon: 'square-dashed', group: 'base' },
  { id: 'welcome', label: 'Boas-Vindas (padrão)', icon: 'hand-wave', group: 'boas-vindas' },
  { id: 'welcome-quarta', label: 'Boas-Vindas — Oração', icon: 'hands-praying', group: 'boas-vindas' },
  { id: 'welcome-missoes', label: 'Boas-Vindas — Missões', icon: 'earth-americas', group: 'boas-vindas' },
  { id: 'welcome-mulheres', label: 'Boas-Vindas — Mulheres', icon: 'flower-tulip', group: 'boas-vindas' },
  { id: 'welcome-homens', label: 'Boas-Vindas — Homens', icon: 'cross', group: 'boas-vindas' },
  { id: 'welcome-jovens', label: 'Boas-Vindas — Jovens', icon: 'sparkles', group: 'boas-vindas' },
  { id: 'welcome-criancas', label: 'Boas-Vindas — Crianças', icon: 'sun', group: 'boas-vindas' },
  { id: 'welcome-especial', label: 'Boas-Vindas — Especial', icon: 'star', group: 'boas-vindas' },
  { id: 'welcome-aniversario', label: 'Boas-Vindas — Aniversário', icon: 'cake-candles', group: 'boas-vindas' },
  { id: 'bible-intro', label: 'Introito', icon: 'book-open', group: 'culto' },
  { id: 'section', label: 'Seção / Momento', icon: 'bookmark', group: 'culto' },
  { id: 'prayer', label: 'Oração', icon: 'hands-praying', group: 'culto' },
  { id: 'lyrics-title', label: 'Louvor', icon: 'music', group: 'culto' },
  { id: 'bible', label: 'Leitura bíblica', icon: 'book-bible', group: 'culto' },
  { id: 'message', label: 'Mensagem', icon: 'bullhorn', group: 'culto' },
  { id: 'preacher-card', label: 'Card pregador', icon: 'user-tie', group: 'culto' },
  { id: 'foto-card', label: 'Card foto+texto', icon: 'image-portrait', group: 'culto' },
  { id: 'theme', label: 'Tema / Divisa', icon: 'sparkles', group: 'culto' },
  { id: 'announcements', label: 'Comunicados', icon: 'bullhorn', group: 'culto' },
  { id: 'communion', label: 'Ceia do Senhor', icon: 'wine-glass', group: 'culto' },
  { id: 'ordem', label: 'Ordem de culto', icon: 'list-ol', group: 'culto' },
  { id: 'quote-spurgeon', label: 'Citação — Spurgeon', icon: 'quote-left', group: 'exegese' },
  { id: 'quote-hdl', label: 'Citação — H. Dias Lopes', icon: 'quote-left', group: 'exegese' },
  { id: 'quote-authority', label: 'Citação — Autoridade', icon: 'quote-left', group: 'exegese' },
];

const WELCOME_DESIGNER_BG = {
  domingo: { type: 'gradient', preset: 'gold', colors: ['#1a1610', '#0a0908', '#12100c'], angle: 165 },
  quarta: { type: 'gradient', preset: 'bible', colors: ['#101820', '#0a0e14', '#0c1016'], angle: 165 },
  missoes: { type: 'gradient', preset: 'communion', colors: ['#1c140c', '#0e0a08', '#1a120a'], angle: 145 },
  mulheres: { type: 'gradient', preset: 'theme', colors: ['#2a121c', '#140810', '#1e1018'], angle: 155 },
  homens: { type: 'gradient', preset: 'bible', colors: ['#0e1624', '#080c14', '#101828'], angle: 160 },
  jovens: { type: 'gradient', preset: 'gold', colors: ['#1a1408', '#0c0a06', '#221808'], angle: 140 },
  criancas: { type: 'gradient', preset: 'bible', colors: ['#0c1a22', '#081218', '#102028'], angle: 150 },
  ceia: { type: 'gradient', preset: 'communion', colors: ['#1a140e', '#0c0908', '#181210'], angle: 155 },
  noite: { type: 'gradient', preset: 'gold', colors: ['#14100a', '#080604', '#1a140c'], angle: 170 },
  familia: { type: 'gradient', preset: 'gold', colors: ['#18140e', '#0c0a08', '#16120e'], angle: 160 },
  especial: { type: 'gradient', preset: 'gold', colors: ['#1a1610', '#0a0908'], angle: 165 },
  aniversario: { type: 'gradient', preset: 'gold', colors: ['#221808', '#0e0a06', '#1c1408'], angle: 160 },
};

function buildWelcomeDesignerPreset(presetKey, assets, church) {
  const welcomeBg = assets.welcomeBg || 'IMG/FRENTE_DA_IGREJA.png';
  const logo = assets.logo || PRODUCT_LOGO_REL;
  const churchName = church.name || 'Nome da Igreja';
  const map = {
    welcome: 'domingo',
    'welcome-quarta': 'quarta',
    'welcome-missoes': 'missoes',
    'welcome-mulheres': 'mulheres',
    'welcome-homens': 'homens',
    'welcome-jovens': 'jovens',
    'welcome-criancas': 'criancas',
    'welcome-especial': 'especial',
    'welcome-aniversario': 'aniversario',
  };
  const id = map[presetKey] || 'domingo';
  const w = resolveWelcomePreset(id, church);
  const accent = w.accent || '#d4c68d';
  const themedBg = WELCOME_DESIGNER_BG[id] || { type: 'image', src: welcomeBg };
  const showLogo = w.showLogo !== false;
  return {
    templateId: presetKey,
    title: 'Boas-Vindas',
    text: w.theme || w.extraLine || '',
    background: themedBg || { type: 'image', src: welcomeBg },
    layers: [
      rect('w-overlay', { x: 0, y: 0, width: W, height: H, fill: 'rgba(0,0,0,0.42)', cornerRadius: 0, locked: true }),
      ...(showLogo ? [img('w-logo', logo, { x: W / 2 - 120, y: 90, width: 240, height: 160, role: 'logo' })] : []),
      ...(w.showBadge !== false && w.badge ? [txt('w-badge', w.badge, { role: 'badge', y: showLogo ? 280 : 220, fontSize: 26, fill: accent, fontStyle: 'bold', fontFamily: 'Open Sans' })] : []),
      ...(w.showChurchName !== false ? [txt('w-church', churchName, { role: 'churchName', y: showLogo ? 330 : 270, fontSize: 28, fill: accent, fontFamily: 'Open Sans' })] : []),
      txt('w-title', w.years || 'Bem-vindos', { role: 'years', y: 400, fontSize: 88, fontFamily: 'Montserrat', fontStyle: 'bold' }),
      ...(w.showTheme !== false && w.theme ? [txt('w-theme', w.theme, { role: 'theme', y: 520, fontSize: 40, fill: accent, fontFamily: 'Open Sans' })] : []),
      ...(w.showExtra !== false && w.extraLine ? [txt('w-extra', w.extraLine, { role: 'subtitle', y: 610, fontSize: 28, fill: '#d8d0c4', fontFamily: 'Open Sans' })] : []),
    ],
  };
}

export function buildDesignerPreset(presetId, assets = {}, church = {}) {
  const logo = assets.logo || PRODUCT_LOGO_REL;
  const welcomeBg = assets.welcomeBg || 'IMG/FRENTE_DA_IGREJA.png';
  const churchName = church.name || 'Nome da Igreja';

  const presets = {
    blank: {
      templateId: 'blank',
      title: 'Slide personalizado',
      text: '',
      background: { type: 'color', value: '#0a0a0a' },
      layers: [
        txt('t-blank', 'Título do slide', { role: 'title', y: 380, fontSize: 76, wrap: true, textFit: 'wrap', fontFamily: 'Montserrat', fontStyle: 'bold' }),
        txt('b-blank', 'Texto ou subtítulo', { role: 'body', y: 500, fontSize: 40, fill: '#d4c68d', wrap: true, textFit: 'wrap', fontFamily: 'Open Sans' }),
      ],
    },

    welcome: buildWelcomeDesignerPreset('welcome', assets, church),
    'welcome-quarta': buildWelcomeDesignerPreset('welcome-quarta', assets, church),
    'welcome-missoes': buildWelcomeDesignerPreset('welcome-missoes', assets, church),
    'welcome-mulheres': buildWelcomeDesignerPreset('welcome-mulheres', assets, church),
    'welcome-homens': buildWelcomeDesignerPreset('welcome-homens', assets, church),
    'welcome-jovens': buildWelcomeDesignerPreset('welcome-jovens', assets, church),
    'welcome-criancas': buildWelcomeDesignerPreset('welcome-criancas', assets, church),
    'welcome-especial': buildWelcomeDesignerPreset('welcome-especial', assets, church),
    'welcome-aniversario': buildWelcomeDesignerPreset('welcome-aniversario', assets, church),

    'bible-intro': {
      templateId: 'bible-intro',
      title: 'Introito Bíblico',
      text: '...para que sejam um, assim como somos um.',
      background: { type: 'color', value: '#0a0a0a' },
      layers: [
        rect('bi-bar', { x: W / 2 - 120, y: 200, width: 240, height: 4, fill: '#d4c68d', cornerRadius: 2 }),
        txt('bi-label', 'INTROITO', { y: 230, fontSize: 28, fill: '#d4c68d', fontStyle: 'bold' }),
        txt('bi-ref', 'João 17:11 (NAA)', { role: 'reference', y: 300, fontSize: 52 }),
        txt('bi-text', '...para que sejam um, assim como somos um.', {
          role: 'verse', y: 420, fontSize: 40, fill: '#e8e8e8',
        }),
        line('bi-line', { x: 360, y: 620, points: [0, 0, W - 720, 0] }),
      ],
    },

    section: {
      templateId: 'section',
      title: 'Momento do Culto',
      text: '',
      background: { type: 'color', value: '#12101a' },
      layers: [
        circle('sec-ring', { x: W / 2 - 100, y: 280, radius: 100, fill: 'rgba(212,198,141,0.12)', stroke: '#d4c68d', strokeWidth: 2 }),
        txt('sec-title', 'LOUVOR', { role: 'title', y: 400, fontSize: 96, fontStyle: 'bold' }),
        line('sec-line', { x: 480, y: 540, strokeWidth: 4 }),
      ],
    },

    prayer: {
      templateId: 'prayer',
      title: 'Oração',
      text: '',
      background: { type: 'color', value: '#0a0a0a' },
      layers: [
        txt('pr-emoji', '🙏', { y: 320, fontSize: 72 }),
        txt('pr-title', 'ORAÇÃO', { role: 'title', y: 440, fontSize: 88 }),
        txt('pr-sub', 'Momento de comunhão com Deus', { role: 'body', y: 560, fontSize: 32, fill: '#888888' }),
      ],
    },

    'lyrics-title': {
      templateId: 'lyrics-title',
      title: 'Nome do Louvor',
      text: '',
      background: { type: 'color', value: '#141414' },
      layers: [
        rect('ly-bg', { x: 80, y: 80, width: W - 160, height: H - 160, fill: 'rgba(212,198,141,0.08)', cornerRadius: 16, stroke: 'rgba(212,198,141,0.3)', strokeWidth: 2 }),
        txt('ly-label', 'LOUVOR', { y: 340, fontSize: 32, fill: '#d4c68d' }),
        txt('ly-title', 'Nome da Música', { role: 'title', y: 420, fontSize: 80 }),
      ],
    },

    bible: {
      templateId: 'bible',
      title: 'Leitura Bíblica',
      text: '',
      background: { type: 'color', value: '#0a0a0a' },
      layers: [
        txt('rd-label', 'LEITURA BÍBLICA', { y: 280, fontSize: 30, fill: '#d4c68d' }),
        txt('rd-ref', 'Salmos 23:1-6 (NAA)', { role: 'reference', y: 380, fontSize: 64 }),
        txt('rd-hint', 'Texto do versículo na projeção', { role: 'verse', y: 500, fontSize: 36, fill: '#e8e8e8' }),
      ],
    },

    message: {
      templateId: 'message',
      title: 'Mensagem Bíblica',
      text: 'Pregador',
      background: { type: 'color', value: '#12101a' },
      layers: [
        txt('msg-label', 'MENSAGEM', { y: 240, fontSize: 28, fill: '#d4c68d' }),
        txt('msg-theme', 'TÍTULO DA MENSAGEM', { role: 'title', y: 320, fontSize: 72, fontStyle: 'bold', x: 120, width: W - 520, align: 'left' }),
        txt('msg-ref', 'João 3:16 (NAA)', { y: 460, fontSize: 36, fill: '#e8c97a', x: 120, width: W - 520, align: 'left' }),
        line('msg-line', { x: 120, y: 540, points: [0, 0, W - 640, 0] }),
        {
          kind: 'photo-card',
          id: 'msg-preacher-card',
          x: W - 420,
          y: 280,
          width: 380,
          height: 460,
          cardLabel: 'Pregador',
          cardName: 'Rev. Nome do Pregador',
          cardFrom: 'Igreja / cidade',
          photoSize: 200,
        },
      ],
    },

    'preacher-card': {
      templateId: 'preacher-card',
      title: 'Card pregador',
      text: '',
      background: { type: 'color', value: '#12101a' },
      layers: [
        {
          kind: 'photo-card',
          id: 'pc-preacher',
          x: W / 2 - 190,
          y: H / 2 - 230,
          width: 380,
          height: 460,
          cardLabel: 'Pregador',
          cardName: 'Rev. João Silva',
          cardFrom: 'IB Batista — Feira de Santana',
          photoSize: 200,
        },
      ],
    },

    'foto-card': {
      templateId: 'foto-card',
      title: 'Card foto + texto',
      text: '',
      background: { type: 'color', value: '#12101a' },
      layers: [
        {
          kind: 'photo-card',
          id: 'pc-main',
          x: W / 2 - 190,
          y: H / 2 - 230,
          width: 380,
          height: 460,
          cardLabel: 'Pregador',
          cardName: 'Título ou nome',
          cardFrom: 'Texto abaixo (opcional)',
          photoSize: 200,
        },
      ],
    },

    theme: {
      templateId: 'theme',
      title: 'SOMOS UM',
      text: '...para que sejam um, assim como somos um.',
      background: { type: 'color', value: '#1a1510' },
      layers: [
        txt('th-label', 'DIVISA', { y: 260, fontSize: 28, fill: '#d4c68d' }),
        txt('th-motto', 'João 17:11 (NAA)', { y: 330, fontSize: 40, fill: '#e8c97a' }),
        txt('th-verse', '...para que sejam um, assim como somos um.', { role: 'body', y: 400, fontSize: 32, fill: '#cccccc' }),
        txt('th-title', 'SOMOS UM', { role: 'title', y: 520, fontSize: 96, fontStyle: 'bold' }),
      ],
    },

    announcements: {
      templateId: 'announcements',
      title: 'Comunicados',
      text: '• Aviso 1\n• Aviso 2\n• Aviso 3',
      background: { type: 'color', value: '#12101a' },
      layers: [
        rect('an-panel', { x: 120, y: 140, width: W - 240, height: H - 280, fill: 'rgba(0,0,0,0.4)', cornerRadius: 12, stroke: 'rgba(212,198,141,0.25)', strokeWidth: 2 }),
        txt('an-title', 'COMUNICADOS', { role: 'title', y: 200, fontSize: 64 }),
        txt('an-list', '• Reunião de obreiros — sábado 19h\n• Escola bíblica — domingo 9h\n• Campanha de oração', {
          role: 'body', y: 340, fontSize: 36, align: 'left', x: 200, width: W - 400,
        }),
      ],
    },

    communion: {
      templateId: 'communion',
      title: 'Ceia do Senhor',
      text: '1 Coríntios 11:23-24',
      background: { type: 'color', value: '#0d0a08' },
      layers: [
        txt('cm-cross', '✝', { y: 260, fontSize: 64, fill: '#d4c68d' }),
        txt('cm-title', 'CEIA DO SENHOR', { role: 'title', y: 380, fontSize: 72 }),
        txt('cm-sub', 'O Pão', { y: 480, fontSize: 40, fill: '#e8c97a' }),
        txt('cm-ref', '1 Coríntios 11:23-24 (NAA)', { role: 'body', y: 580, fontSize: 32, fill: '#aaaaaa' }),
      ],
    },

    ordem: {
      templateId: 'ordem',
      title: 'Ordem do Culto',
      text: '1. Boas-Vindas\n2. Louvor\n3. Oração\n4. Mensagem',
      background: { type: 'color', value: '#0a0a0a' },
      layers: [
        rect('ord-header', { x: 0, y: 0, width: W, height: 140, fill: 'rgba(212,198,141,0.15)', cornerRadius: 0 }),
        txt('ord-title', 'ORDEM DO CULTO', { role: 'title', y: 40, fontSize: 48 }),
        txt('ord-list', '1. Boas-Vindas\n2. Louvor de adoração\n3. Oração\n4. Leitura bíblica\n5. Mensagem\n6. Comunicados', {
          role: 'body', y: 200, fontSize: 38, align: 'left', x: 200, width: W - 400, fill: '#eeeeee',
        }),
        img('ord-logo', logo, { x: W - 200, y: 20, width: 100, height: 80 }),
      ],
    },

    'quote-spurgeon': {
      templateId: 'quote-spurgeon',
      title: 'Citação teológica',
      text: '',
      background: { type: 'color', value: '#121018' },
      layers: [
        rect('qs-frame', { x: 140, y: 160, width: W - 280, height: H - 320, fill: 'rgba(0,0,0,0.35)', cornerRadius: 12, stroke: 'rgba(212,198,141,0.35)', strokeWidth: 2 }),
        txt('qs-mark', '“', { y: 200, fontSize: 120, fill: 'rgba(212,198,141,0.35)', x: 180, width: 120, align: 'left' }),
        txt('qs-quote', 'A graça de Deus é suficiente para todo o caminho do crente.', {
          role: 'quote', y: 320, fontSize: 52, fontFamily: 'Georgia', align: 'left', x: 220, width: W - 440, fill: '#f5f0e6',
        }),
        line('qs-sep', { x: 220, y: 620, points: [0, 0, 280, 0], stroke: '#d4c68d', strokeWidth: 3 }),
        txt('qs-author', 'Charles H. Spurgeon', { role: 'author', y: 660, fontSize: 34, fontFamily: 'Georgia', align: 'left', x: 220, width: W - 440, fill: '#d4c68d' }),
        txt('qs-ref', 'Sermões escolhidos', { role: 'ref', y: 710, fontSize: 26, align: 'left', x: 220, width: W - 440, fill: '#888888' }),
      ],
    },

    'quote-hdl': {
      templateId: 'quote-hdl',
      title: 'Citação teológica',
      text: '',
      background: { type: 'color', value: '#101820' },
      layers: [
        rect('qh-frame', { x: 120, y: 140, width: W - 240, height: H - 280, fill: 'rgba(212,198,141,0.06)', cornerRadius: 16 }),
        txt('qh-quote', 'A Palavra de Deus é a regra suprema de nossa fé e prática.', {
          role: 'quote', y: 300, fontSize: 50, fontFamily: 'Times New Roman', align: 'center', x: SAFE_PAD, width: SAFE_INNER_W, fill: '#ffffff',
        }),
        line('qh-sep', { x: W / 2 - 160, y: 580, points: [0, 0, 320, 0], stroke: '#c9b896', strokeWidth: 2 }),
        txt('qh-author', 'Hernandes Dias Lopes', { role: 'author', y: 640, fontSize: 36, fontFamily: 'Georgia', fill: '#e8c97a' }),
        txt('qh-ref', 'Comentário bíblico', { role: 'ref', y: 690, fontSize: 26, fill: '#999999' }),
      ],
    },

    'quote-authority': {
      templateId: 'quote-authority',
      title: 'Citação de autoridade',
      text: '',
      background: { type: 'color', value: '#0a0a0a' },
      layers: [
        txt('qa-label', 'CITAÇÃO', { y: 220, fontSize: 28, fill: '#d4c68d', letterSpacing: 4 }),
        txt('qa-quote', 'Insira aqui a citação do autor ou da confissão de fé.', {
          role: 'quote', y: 340, fontSize: 46, fontFamily: 'Georgia', align: 'left', x: 180, width: W - 360, fill: '#f0f0f0',
        }),
        rect('qa-bar', { x: 180, y: 600, width: 6, height: 120, fill: '#d4c68d', cornerRadius: 3 }),
        txt('qa-author', 'Nome do autor', { role: 'author', y: 620, fontSize: 32, align: 'left', x: 220, width: W - 400, fill: '#d4c68d' }),
        txt('qa-ref', 'Obra ou referência (opcional)', { role: 'ref', y: 670, fontSize: 24, align: 'left', x: 220, width: W - 400, fill: '#777777' }),
      ],
    },
  };

  return presets[presetId] || presets.blank;
}

export function listDesignerPresets() {
  return DESIGNER_PRESET_CATALOG;
}
