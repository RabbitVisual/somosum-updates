/** Designer Pro — master slides e undo persistente */
import { dataPublicUrl } from '../core/data-public-url.js';

const HISTORY_PREFIX = 'somosum-designer-history-';

export class DesignerHistory {
  constructor(itemId) {
    this.itemId = itemId;
    this.stack = [];
    this.pointer = -1;
    this.load();
  }

  load() {
    try {
      const raw = localStorage.getItem(HISTORY_PREFIX + this.itemId);
      if (raw) {
        const data = JSON.parse(raw);
        this.stack = data.stack || [];
        this.pointer = data.pointer ?? this.stack.length - 1;
      }
    } catch { /* */ }
  }

  persist() {
    localStorage.setItem(HISTORY_PREFIX + this.itemId, JSON.stringify({
      stack: this.stack.slice(-100),
      pointer: this.pointer,
    }));
  }

  push(state) {
    this.stack = this.stack.slice(0, this.pointer + 1);
    this.stack.push(state);
    this.pointer = this.stack.length - 1;
    this.persist();
  }

  undo() {
    if (this.pointer <= 0) return null;
    this.pointer--;
    this.persist();
    return this.stack[this.pointer];
  }

  redo() {
    if (this.pointer >= this.stack.length - 1) return null;
    this.pointer++;
    this.persist();
    return this.stack[this.pointer];
  }
}

export const MasterSlides = {
  async list() {
    const res = await fetch(dataPublicUrl('templates/index.json'), { cache: 'no-store' });
    if (!res.ok) return [];
    const data = await res.json();
    return data.masters || [];
  },

  /**
   * Aplica fundo + defaults de texto do master ao canvas atual (U2-F).
   * @param {*} canvasEngine CanvasEngine instance
   * @param {object|string} masterOrId
   */
  async apply(canvasEngine, masterOrId) {
    if (!canvasEngine) return false;
    let master = masterOrId;
    if (typeof masterOrId === 'string') {
      const list = await this.list();
      master = list.find((m) => m.id === masterOrId);
    }
    if (!master) return false;

    if (master.background) {
      if (typeof canvasEngine.setBackground === 'function') {
        canvasEngine.setBackground(master.background);
      } else if (typeof canvasEngine.applyBackground === 'function') {
        canvasEngine.applyBackground(master.background);
      } else if (master.background.type === 'color' && typeof canvasEngine.setBgColor === 'function') {
        canvasEngine.setBgColor(master.background.value);
      }
    }

    const defaults = master.textDefaults || {};
    const stage = canvasEngine.stage;
    if (stage && defaults) {
      const layer = stage.getChildren?.()?.[0];
      const nodes = layer?.getChildren?.() || [];
      for (const node of nodes) {
        const role = node.getAttr?.('role') || node.name?.();
        const style = role === 'title' ? defaults.title : (role === 'body' || role === 'text' ? defaults.body : null);
        if (!style || typeof node.fill !== 'function') continue;
        if (style.fill) node.fill(style.fill);
        if (style.fontSize && typeof node.fontSize === 'function') node.fontSize(style.fontSize);
        if (style.fontFamily && typeof node.fontFamily === 'function') node.fontFamily(style.fontFamily);
        if (style.align && typeof node.align === 'function') node.align(style.align);
      }
      stage.draw?.();
    }

    // Stash for new text tools
    canvasEngine._masterTextDefaults = defaults;
    return true;
  },
};
