/** Paleta SOMOSUM + presets de cor para o designer */

export const CHURCH_PALETTE = [
  { id: 'white', value: '#ffffff', label: 'Branco' },
  { id: 'gold', value: '#d4c68d', label: 'Dourado' },
  { id: 'gold-dim', value: '#b8862e', label: 'Ouro escuro' },
  { id: 'gold-light', value: '#e8c97a', label: 'Dourado claro' },
  { id: 'black', value: '#0a0a0a', label: 'Preto' },
  { id: 'charcoal', value: '#1a1a1a', label: 'Carvão' },
  { id: 'wine', value: '#4a1020', label: 'Vinho' },
  { id: 'brown', value: '#2a1810', label: 'Marrom' },
  { id: 'gold-alpha', value: 'rgba(212,198,141,0.35)', label: 'Dourado translúcido' },
  { id: 'overlay', value: 'rgba(0,0,0,0.55)', label: 'Overlay escuro' },
];

export const BG_PRESETS = [
  { id: 'dark', label: 'Escuro', type: 'color', value: '#0a0a0a' },
  { id: 'charcoal', label: 'Carvão', type: 'color', value: '#141414' },
  { id: 'gold-tint', label: 'Dourado suave', type: 'color', value: '#1a1510' },
  { id: 'theme', label: 'Tema', type: 'color', value: '#12101a' },
  { id: 'communion', label: 'Ceia', type: 'color', value: '#0d0a08' },
];

export const GRADIENT_BG_PRESETS = [
  { id: 'dark', label: 'Escuro' },
  { id: 'gold', label: 'Ouro' },
  { id: 'theme', label: 'Tema' },
  { id: 'charcoal', label: 'Carvão' },
  { id: 'communion', label: 'Ceia' },
  { id: 'bible', label: 'Bíblia' },
];

export const FONT_STACKS = [
  'Segoe UI',
  'Georgia',
  'Times New Roman',
  'Arial',
  'Verdana',
  'Trebuchet MS',
  'Impact',
];

export function colorSwatchesHtml(selected, prefix = 'dp') {
  return `<div class="designer-swatches" id="${prefix}-swatches">
    ${CHURCH_PALETTE.map((c) =>
      `<button type="button" class="designer-swatch${selected === c.value ? ' is-active' : ''}"
        data-color="${c.value}" title="${c.label}"
        style="background:${c.value}"></button>`
    ).join('')}
  </div>`;
}
