/**
 * Content bindings — slots Designer ↔ Ordem (design once, edit content later).
 * Layers keep x/y/font/estilo; only .text / .src are filled from bible/welcome/media.
 */

import { randomId } from '../core/uuid.js';
import { DESIGN_W, DESIGN_H } from './slide-exporter.js';

/** Semantic roles a layer can declare (Papel no Designer). */
export const SLOT_ROLES = {
  none: { label: 'Nenhum (fixo)', group: 'geral' },
  title: { label: 'Título genérico', group: 'geral' },
  body: { label: 'Corpo / subtítulo', group: 'geral' },
  reference: { label: 'Referência bíblica', group: 'biblia' },
  verse: { label: 'Texto bíblico', group: 'biblia' },
  photo: { label: 'Foto (moldura)', group: 'midia' },
  logo: { label: 'Logo', group: 'midia' },
  years: { label: 'Anos / título boas-vindas', group: 'welcome' },
  theme: { label: 'Tema do culto', group: 'welcome' },
  subtitle: { label: 'Linha extra / subtítulo', group: 'welcome' },
  badge: { label: 'Badge', group: 'welcome' },
  churchName: { label: 'Nome da igreja', group: 'welcome' },
  quote: { label: 'Citação', group: 'geral' },
  author: { label: 'Autor', group: 'geral' },
  ref: { label: 'Referência (citação)', group: 'geral' },
  caption: { label: 'Legenda', group: 'geral' },
};

/** templateId → content kind for typed program items */
const TEMPLATE_KIND = {
  'bible-intro': 'introito',
  bible: 'bible',
  welcome: 'welcome',
  'welcome-quarta': 'welcome',
  'welcome-missoes': 'welcome',
  'welcome-mulheres': 'welcome',
  'welcome-homens': 'welcome',
  'welcome-jovens': 'welcome',
  'welcome-criancas': 'welcome',
  'welcome-especial': 'welcome',
  'welcome-aniversario': 'welcome',
};

/** Legacy Designer roles → semantic slots (per content kind) */
const ROLE_ALIASES = {
  introito: { title: 'reference', body: 'verse' },
  bible: { title: 'reference', body: 'verse' },
  welcome: { title: 'years', body: 'theme' },
};

export function contentKindFromTemplateId(templateId) {
  const id = String(templateId || '').trim();
  if (TEMPLATE_KIND[id]) return TEMPLATE_KIND[id];
  if (id.startsWith('welcome')) return 'welcome';
  return null;
}

/** Resolve templateId padrão a partir do item da Ordem. */
export function templateIdForProgramItem(item) {
  if (!item) return 'blank';
  const skin = getDesignerSkin(item);
  if (skin?.templateId) return skin.templateId;
  if (item.data?.templateId) return item.data.templateId;
  if (item.data?.role === 'introito') return 'bible-intro';
  if (item.slideType === 'bible') return 'bible';
  if (item.slideType === 'welcome') {
    const p = item.data?.welcomePreset || 'domingo';
    if (p === 'domingo') return 'welcome';
    return `welcome-${p}`;
  }
  if (item.slideType === 'message') return 'message';
  if (item.slideType === 'custom') return 'blank';
  return 'blank';
}

/** Contexto de injeção (Bíblia / welcome / foto) a partir do item do programa. */
export function buildContentCtxFromItem(item) {
  if (!item) return {};
  const templateId = templateIdForProgramItem(item);
  const contentKind = contentKindFromTemplateId(templateId)
    || (item.slideType === 'bible' ? 'bible' : null)
    || (item.slideType === 'welcome' ? 'welcome' : null)
    || (item.data?.role === 'introito' ? 'introito' : null);
  const bible = item.bible || {};
  const data = item.data || {};
  const reference = bible.referenceOverride
    || [bible.book, bible.chapter && `${bible.chapter}:${bible.verseStart || 1}${bible.verseEnd && bible.verseEnd !== bible.verseStart ? `-${bible.verseEnd}` : ''}`]
      .filter(Boolean).join(' ')
    || '';
  return {
    contentKind,
    bible,
    welcome: contentKind === 'welcome' ? data : {},
    media: {
      photo: data.photoSrc || data.mediaSrc || data.photo || '',
      logo: data.logoSrc || '',
      src: data.photoSrc || data.mediaSrc || '',
    },
    reference,
    verseText: bible.excerptText || '',
    referenceFormatted: reference,
  };
}

/** Fundo do item (inclui vídeo de boas-vindas / mídia). */
export function backgroundFromProgramItem(item, fallback = null) {
  const skin = getDesignerSkin(item);
  if (skin?.background) return { ...skin.background };
  if (item?.data?.background) return { ...item.data.background };
  const d = item?.data || {};
  if (d.bgKind === 'video' && (d.bgSrc || d.bgMediaId)) {
    return {
      type: 'video',
      src: d.bgSrc || '',
      mediaId: d.bgMediaId || '',
      fit: d.bgFit || 'cover',
      dim: Number(d.bgDim ?? d.dim ?? 0.35) || 0,
    };
  }
  if (d.bgKind === 'image' && d.bgSrc) {
    return { type: 'image', src: d.bgSrc, fit: d.bgFit || 'cover', dim: Number(d.bgDim || 0) || 0 };
  }
  return fallback ? { ...fallback } : null;
}

export function normalizeLayerRole(role, contentKind) {
  const r = String(role || '').trim();
  if (!r) return '';
  if (SLOT_ROLES[r]) return r;
  const aliases = ROLE_ALIASES[contentKind] || {};
  return aliases[r] || r;
}

export function findLayerByRole(layers, role, contentKind) {
  const list = Array.isArray(layers) ? layers : [];
  const want = normalizeLayerRole(role, contentKind);
  return list.find((l) => normalizeLayerRole(l?.role, contentKind) === want) || null;
}

export function textFromRole(layers, role, contentKind) {
  const layer = findLayerByRole(layers, role, contentKind);
  return String(layer?.text || '').trim();
}

/**
 * Build designer skin blob stored on program item.data.designer
 * Also keeps top-level layers/background for older custom path compat.
 */
export function buildDesignerSkin(slide = {}) {
  const layers = Array.isArray(slide.layers) ? slide.layers : [];
  const background = slide.background || null;
  const templateId = slide.templateId || null;
  return {
    version: 3,
    width: Number(slide.designer?.width) || DESIGN_W,
    height: Number(slide.designer?.height) || DESIGN_H,
    templateId,
    layers,
    background,
    previewDataUrl: slide.previewDataUrl || null,
  };
}

export function getDesignerSkin(itemOrData) {
  const data = itemOrData?.data || itemOrData || {};
  const skin = data.designer;
  if (skin?.layers?.length) {
    return {
      version: skin.version || 3,
      width: Number(skin.width) || DESIGN_W,
      height: Number(skin.height) || DESIGN_H,
      templateId: skin.templateId || data.templateId || null,
      layers: skin.layers,
      background: skin.background || data.background || null,
      previewDataUrl: skin.previewDataUrl || data.previewDataUrl || null,
    };
  }
  if (data.layers?.length) {
    return {
      version: 3,
      width: DESIGN_W,
      height: DESIGN_H,
      templateId: data.templateId || null,
      layers: data.layers,
      background: data.background || null,
      previewDataUrl: data.previewDataUrl || null,
    };
  }
  return null;
}

export function hasDesignerSkin(item) {
  return !!getDesignerSkin(item)?.layers?.length;
}

/**
 * Aplica título/subtítulo/texto do inspetor da Ordem às camadas por papel.
 * Não altera geometria — só texto de roles conhecidos.
 */
export function applyCustomOrdemProps(layers, data = {}) {
  if (!Array.isArray(layers) || !layers.length) return layers || [];
  const title = String(data.title || '').trim();
  const subtitle = String(data.subtitle || '').trim();
  const body = String(data.text || '').trim();
  if (!title && !subtitle && !body) return layers.map((l) => (l ? { ...l } : l));

  return layers.map((layer) => {
    if (!layer || typeof layer !== 'object') return layer;
    if (layer.kind !== 'text' && layer.text == null) return { ...layer };
    const role = normalizeLayerRole(layer.role, 'custom') || String(layer.role || '').toLowerCase();
    if (title && (role === 'title' || role === 'years' || role === 'badge')) {
      return { ...layer, text: title };
    }
    if (subtitle && (role === 'caption' || role === 'subtitle' || role === 'theme')) {
      return { ...layer, text: subtitle };
    }
    if (body && (role === 'body' || role === 'verse' || role === 'reference')) {
      return { ...layer, text: body };
    }
    return { ...layer };
  });
}

/** Fundo do slide personalizado: inspetor (preset) ou pele do Designer. */
export function resolveCustomBackground(data = {}, skin = null) {
  const preset = data.backgroundPreset || data.background?.preset || skin?.background?.preset;
  const skinBg = skin?.background || data.background || null;
  // Inspetor alterou preset → aplica gradiente (não apaga vídeo/imagem do Designer sem intenção)
  if (data.textEdited && preset && (!skinBg || skinBg.type === 'gradient' || skinBg.type === 'color')) {
    return { type: 'gradient', preset };
  }
  if (skinBg) return skinBg;
  if (preset) return { type: 'gradient', preset };
  return { type: 'gradient', preset: 'dark' };
}

/**
 * Compacta slide custom para sync Control→Screen.
 * - Com preview JPEG válido + mídia embutida → bitmap (fiel ao Designer).
 * - Sem preview bom → mantém layers COM fillSrc data: (nunca deixar moldura vazia).
 * - blob: sempre removido (não atravessa WebView2).
 */
export function prepareCustomSlideForSync(slide) {
  if (!slide || slide.type !== 'custom') return slide;
  const layers = Array.isArray(slide.layers) ? slide.layers : [];
  const stripBlob = (src) => {
    const s = String(src || '');
    if (/^blob:/i.test(s)) return '';
    return s;
  };
  const hasHeavy = layers.some((l) => {
    const a = String(l?.src || l?.imageSrc || '');
    const b = String(l?.fillSrc || '');
    return /^data:/i.test(a) || /^data:/i.test(b) || /^blob:/i.test(a) || /^blob:/i.test(b);
  });
  const hasFrameFill = layers.some((l) => l?.kind === 'frame' && String(l.fillSrc || '').length > 32);
  const preview = slide.previewDataUrl || slide.designer?.previewDataUrl || null;
  // Preview curto demais = captura antes da imagem carregar (círculo vazio)
  const previewOk = typeof preview === 'string' && preview.length > 12000;

  if (previewOk && (hasHeavy || slide.designer?.preferBitmap)) {
    return {
      type: 'custom',
      title: slide.title,
      subtitle: slide.subtitle,
      text: slide.text,
      background: slide.background,
      style: slide.style,
      layers: [],
      previewDataUrl: preview,
      designer: {
        version: slide.designer?.version || 3,
        width: Number(slide.designer?.width) || DESIGN_W,
        height: Number(slide.designer?.height) || DESIGN_H,
        preferBitmap: true,
      },
    };
  }

  // Caminho camadas: preservar data: das molduras (logo/foto)
  const nextLayers = layers.map((l) => {
    if (!l || typeof l !== 'object') return l;
    return {
      ...l,
      src: stripBlob(l.src),
      imageSrc: stripBlob(l.imageSrc),
      fillSrc: stripBlob(l.fillSrc),
      maskSrc: stripBlob(l.maskSrc),
    };
  });

  return {
    ...slide,
    layers: nextLayers,
    previewDataUrl: previewOk ? preview : (hasFrameFill ? undefined : preview || undefined),
    designer: {
      version: slide.designer?.version || 3,
      width: Number(slide.designer?.width) || DESIGN_W,
      height: Number(slide.designer?.height) || DESIGN_H,
      preferBitmap: false,
    },
  };
}

/**
 * Inject content into layers by role. Does not mutate geometry/style.
 * @param {object[]} layers
 * @param {{ contentKind?: string, bible?: object, welcome?: object, media?: object, reference?: string, verseText?: string, versesHtmlText?: string }} ctx
 */
export function applyContentToLayers(layers, ctx = {}) {
  if (!Array.isArray(layers) || !layers.length) return layers || [];
  const kind = ctx.contentKind || null;
  const reference = String(ctx.reference || ctx.bible?.referenceOverride || '').trim()
    || String(ctx.referenceFormatted || '').trim();
  const verseText = String(
    ctx.verseText
    || ctx.bible?.excerptText
    || ctx.versesHtmlText
    || ''
  ).trim();
  const welcome = ctx.welcome || {};
  const media = ctx.media || {};
  const photoSrc = media.photo || media.src || welcome.photoSrc || '';
  const logoSrc = media.logo || welcome.logoSrc || '';

  const fillByRole = {
    reference,
    verse: verseText,
    title: kind === 'welcome' ? (welcome.years || '') : (kind === 'introito' || kind === 'bible' ? reference : ''),
    body: kind === 'welcome' ? (welcome.theme || welcome.extraLine || '') : (kind === 'introito' || kind === 'bible' ? verseText : ''),
    years: welcome.years || '',
    theme: welcome.theme || '',
    subtitle: welcome.extraLine || welcome.subtitle || '',
    badge: welcome.badge || '',
    churchName: welcome.churchName || '',
  };

  return layers.map((layer) => {
    if (!layer || typeof layer !== 'object') return layer;
    const role = normalizeLayerRole(layer.role, kind);
    if (!role) return { ...layer };

    if (role === 'photo' && photoSrc && (layer.kind === 'image' || layer.kind === 'photo-card' || layer.kind === 'frame' || layer.src != null)) {
      if (layer.kind === 'frame') {
        return { ...layer, fillSrc: photoSrc, src: photoSrc };
      }
      return { ...layer, src: photoSrc, imageSrc: photoSrc };
    }
    if (role === 'logo' && logoSrc && (layer.kind === 'image' || layer.src != null)) {
      return { ...layer, src: logoSrc };
    }

    const text = fillByRole[role];
    if (text != null && text !== '' && (layer.kind === 'text' || layer.text != null)) {
      // Keep textFit so Designer re-fits box after content injection
      return { ...layer, text, textFit: layer.textFit || (role === 'reference' || role === 'badge' ? 'fit' : layer.textFit) };
    }
    // Clear empty optional welcome slots? Keep placeholder if no content — leave as-is when empty
    if ((role === 'theme' || role === 'subtitle' || role === 'badge') && text === '' && layer.kind === 'text') {
      return { ...layer, text: layer.text || '' };
    }
    return { ...layer };
  });
}

/** Seed bible fields from current layer texts (when saving Designer → Ordem). */
export function seedBibleFromLayers(layers, contentKind, existing = {}) {
  const reference = textFromRole(layers, 'reference', contentKind)
    || textFromRole(layers, 'title', contentKind);
  const verse = textFromRole(layers, 'verse', contentKind)
    || textFromRole(layers, 'body', contentKind);
  const base = { ...(existing || {}) };
  if (contentKind === 'introito') {
    return {
      version: base.version || 'naa',
      book: base.book || 'Jo',
      chapter: base.chapter || 17,
      verseStart: base.verseStart || 11,
      verseEnd: base.verseEnd || 11,
      displayMode: 'excerpt',
      referenceOverride: reference || base.referenceOverride || 'João 17:11 (NAA)',
      excerptText: verse || base.excerptText || '',
      showText: true,
    };
  }
  return {
    version: base.version || 'naa',
    book: base.book || 'Sl',
    chapter: base.chapter || 23,
    verseStart: base.verseStart || 1,
    verseEnd: base.verseEnd || 6,
    displayMode: base.displayMode || 'verses',
    referenceOverride: reference || base.referenceOverride || '',
    showText: true,
    showVersion: true,
    refStyle: 'colon',
    // Keep verse text in override fields when seeded from designer body (optional)
    _designerSeedVerse: verse || '',
  };
}

export function seedWelcomeFromLayers(layers, contentKind, existing = {}, church = {}) {
  const w = { ...(existing || {}) };
  const years = textFromRole(layers, 'years', contentKind) || textFromRole(layers, 'title', contentKind);
  const theme = textFromRole(layers, 'theme', contentKind) || textFromRole(layers, 'body', contentKind);
  const badge = textFromRole(layers, 'badge', contentKind);
  const extra = textFromRole(layers, 'subtitle', contentKind);
  const churchName = textFromRole(layers, 'churchName', contentKind);
  return {
    ...w,
    years: years || w.years || 'Bem-vindos',
    theme: theme || w.theme || '',
    badge: badge || w.badge || '',
    extraLine: extra || w.extraLine || '',
    churchName: churchName || church.name || w.churchName || '',
    showYears: w.showYears !== false,
    showTheme: w.showTheme !== false,
    showBadge: w.showBadge !== false,
    showExtra: w.showExtra !== false,
    showLogo: w.showLogo !== false,
    showChurchName: w.showChurchName !== false,
  };
}

/**
 * Infer typed program item from a Designer slide export.
 * @returns {{ slideType: string, title: string, data: object, bible?: object }}
 */
export function inferProgramItemFromDesigner(slide = {}, meta = {}) {
  const templateId = slide.templateId || 'blank';
  const kind = contentKindFromTemplateId(templateId);
  const skin = buildDesignerSkin(slide);
  const title = slide.title || meta.title || 'Slide Designer';
  const layers = skin.layers || [];

  if (kind === 'introito') {
    const bible = seedBibleFromLayers(layers, 'introito', meta.bible);
    return {
      id: meta.id || randomId(),
      slideType: 'bible',
      type: 'bible',
      title: title || 'Introito',
      data: {
        role: 'introito',
        templateId,
        designer: skin,
        // mirror for older loaders
        layers: skin.layers,
        background: skin.background,
        previewDataUrl: skin.previewDataUrl,
      },
      bible,
    };
  }

  if (kind === 'bible') {
    const bible = seedBibleFromLayers(layers, 'bible', meta.bible);
    return {
      id: meta.id || randomId(),
      slideType: 'bible',
      type: 'bible',
      title: title || 'Leitura Bíblica',
      data: {
        templateId,
        designer: skin,
        layers: skin.layers,
        background: skin.background,
        previewDataUrl: skin.previewDataUrl,
      },
      bible,
    };
  }

  if (kind === 'welcome') {
    const welcomePreset = String(templateId).replace(/^welcome-?/, '') || 'domingo';
    const presetId = templateId === 'welcome' ? 'domingo' : (welcomePreset || 'domingo');
    const welcomeData = seedWelcomeFromLayers(layers, 'welcome', meta.welcome || meta.data, meta.church);
    return {
      id: meta.id || randomId(),
      slideType: 'welcome',
      type: 'welcome',
      title: title || 'Boas-Vindas',
      data: {
        ...welcomeData,
        welcomePreset: presetId === 'welcome' ? 'domingo' : presetId,
        templateId,
        designer: skin,
        layers: skin.layers,
        background: skin.background,
        previewDataUrl: skin.previewDataUrl,
      },
    };
  }

  // Generic custom
  return {
    id: meta.id || randomId(),
    slideType: 'custom',
    type: 'custom',
    title,
    data: {
      title,
      text: slide.text || '',
      templateId,
      designer: skin,
      layers: skin.layers,
      background: skin.background,
      previewDataUrl: skin.previewDataUrl,
    },
  };
}

/**
 * Build a projection slide payload that uses Designer skin + live content.
 * Returns null if no skin (caller uses HTML template).
 */
export function buildSkinnedProjectionSlide({
  contentKind,
  skin,
  style,
  reference,
  verseText,
  welcome,
  media,
  type = 'custom',
}) {
  if (!skin?.layers?.length) return null;
  const layers = applyContentToLayers(skin.layers, {
    contentKind,
    reference,
    verseText,
    welcome,
    media,
  });
  return {
    type: 'custom',
    layers,
    background: skin.background || undefined,
    designer: {
      version: skin.version || 3,
      width: skin.width || DESIGN_W,
      height: skin.height || DESIGN_H,
      preferBitmap: false,
    },
    previewDataUrl: skin.previewDataUrl || undefined,
    style: style || {},
    _contentKind: contentKind,
    _skinnedFrom: type,
  };
}

export function listRoleOptionsForSelect() {
  return Object.entries(SLOT_ROLES).map(([id, def]) => ({
    id,
    label: def.label,
    group: def.group,
  }));
}
