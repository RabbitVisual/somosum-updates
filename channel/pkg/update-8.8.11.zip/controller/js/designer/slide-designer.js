export { SlideDesigner } from './slide-designer/index.js';
