/** Shape builders for CanvasEngine — text, rects, images. */

import { DESIGN_W, DESIGN_H } from './slide-exporter.js';

export const canvasShapeMethods = {

  addText(text = 'Novo texto', opts = {}) {
    const id = `ly-${Date.now()}`;
    const textFit = opts.textFit || 'wrap';
    const node = new Konva.Text({
      id,
      x: opts.x ?? (DESIGN_W / 2 - 400),
      y: opts.y ?? (DESIGN_H / 2 - 40),
      width: opts.width ?? 800,
      text,
      fontSize: opts.fontSize || 64,
      fontFamily: opts.fontFamily || 'Segoe UI',
      fontStyle: opts.fontStyle || 'normal',
      fill: opts.fill || '#ffffff',
      align: opts.align || 'center',
      letterSpacing: opts.letterSpacing ?? 0,
      lineHeight: opts.lineHeight ?? 1.2,
      wrap: textFit === 'fit' ? 'none' : 'word',
      draggable: opts.locked !== true,
      name: opts.name || 'text',
      role: opts.role || '',
      textFit,
      listening: true,
    });
    this.layer.add(node);
    this._restackSystemNodes();
    this.selectNode(node);
    this.onChange?.();
    this._pushHistory();
    return node;
  },

  addRect(opts = {}) {
    const node = new Konva.Rect({
      id: opts.id || `sh-${Date.now()}`,
      x: opts.x ?? DESIGN_W / 2 - 150,
      y: opts.y ?? DESIGN_H / 2 - 80,
      width: opts.width ?? 300,
      height: opts.height ?? 160,
      fill: opts.fill ?? 'rgba(212,198,141,0.35)',
      stroke: opts.stroke || '',
      strokeWidth: opts.strokeWidth || 0,
      cornerRadius: opts.cornerRadius ?? 8,
      draggable: opts.locked !== true,
      name: opts.name || 'shape',
    });
    this.layer.add(node);
    this._restackSystemNodes();
    this.selectNode(node);
    this.onChange?.();
    this._pushHistory();
    return node;
  },

  addCircle(opts = {}) {
    const r = opts.radius ?? 80;
    const node = new Konva.Circle({
      id: opts.id || `ci-${Date.now()}`,
      x: (opts.x ?? DESIGN_W / 2 - r) + r,
      y: (opts.y ?? DESIGN_H / 2 - r) + r,
      radius: r,
      fill: opts.fill ?? 'rgba(212,198,141,0.25)',
      stroke: opts.stroke || '#d4c68d',
      strokeWidth: opts.strokeWidth ?? 2,
      draggable: opts.locked !== true,
      name: opts.name || 'shape',
    });
    this.layer.add(node);
    this._restackSystemNodes();
    this.selectNode(node);
    this.onChange?.();
    this._pushHistory();
    return node;
  },

  addLine(opts = {}) {
    const points = opts.points || [0, 0, 400, 0];
    const node = new Konva.Line({
      id: opts.id || `ln-${Date.now()}`,
      x: opts.x ?? 360,
      y: opts.y ?? 540,
      points,
      stroke: opts.stroke || '#d4c68d',
      strokeWidth: opts.strokeWidth ?? 3,
      draggable: opts.locked !== true,
      name: opts.name || 'line',
    });
    this.layer.add(node);
    this._restackSystemNodes();
    this.selectNode(node);
    this.onChange?.();
    this._pushHistory();
    return node;
  },

  addImageFromUrl(src, opts = {}) {
    return new Promise((resolve) => {
      const img = new Image();
      img.onload = () => {
        const maxW = opts.maxWidth ?? DESIGN_W * 0.6;
        const scale = opts.width ? opts.width / img.width : Math.min(1, maxW / img.width);
        const w = opts.width ?? img.width * scale;
        const h = opts.height ?? img.height * scale;
        const node = new Konva.Image({
          id: opts.id || `img-${Date.now()}`,
          x: opts.x ?? DESIGN_W / 2 - w / 2,
          y: opts.y ?? DESIGN_H / 2 - h / 2,
          image: img,
          width: w,
          height: h,
          draggable: opts.locked !== true,
          name: opts.name || 'image',
          src,
        });
        this.layer.add(node);
        this._restackSystemNodes();
        this.selectNode(node);
        this.onChange?.();
        this._pushHistory();
        resolve(node);
      };
      img.onerror = () => resolve(null);
      img.src = src;
    });
  },

  addImageFromFile(file) {
    return new Promise((resolve) => {
      const reader = new FileReader();
      reader.onload = () => {
        this.addImageFromUrl(reader.result).then(resolve);
      };
      reader.readAsDataURL(file);
    });
  },

  addLogo(logoUrl) {
    return this.addImageFromUrl(logoUrl, {
      x: DESIGN_W - 360,
      y: 60,
      width: 280,
      name: 'logo',
    });
  },

};
