/** Frame and photo-card tool handlers for CanvasEngine. */

import { DESIGN_W, DESIGN_H } from './slide-exporter.js';
import {
  applyKonvaFrameClip,
  computeFrameFillLayout,
  bindFrameDrag,
  bindFrameLogicalBounds,
  makeFrameHitRect,
  resizeFrameChildren,
  createFrameBorderNode,
} from './frame-utils.js';
import {
  buildPhotoCardNodes,
  layoutPhotoCardFill,
  relayoutPhotoCardGroup,
  bindPhotoCardDrag,
} from './photo-card.js';

export const canvasToolMethods = {

  _applyFrameClip(group, w, h, shape, opts = {}) {
    applyKonvaFrameClip(group, w, h, shape, {
      cornerRadius: opts.cornerRadius ?? group.attrs.cornerRadius ?? 24,
    });
  },

  /** Ordem visual: fill → máscara (destination-in) → borda → hit */
  _restackFrameLayers(group) {
    if (!group || group.name?.() !== 'frame') return;
    const fill = group.findOne('.frame-fill');
    const mask = group.findOne('.frame-mask');
    const border = group.findOne('.frame-border');
    const hit = group.findOne('.frame-hit');
    fill?.moveToBottom?.();
    if (mask) {
      mask.globalCompositeOperation?.('destination-in');
      mask.moveToTop?.();
    }
    border?.moveToTop?.();
    hit?.moveToTop?.();
  },

  _attachFrameMaskImage(group, maskSrc) {
    if (!group || !maskSrc) return;
    const K = window.Konva;
    if (!K) return;
    group.findOne('.frame-mask')?.destroy();
    const w = group.attrs.width || 400;
    const h = group.attrs.height || 400;
    group.attrs.maskSrc = maskSrc;
    const img = new Image();
    img.onload = () => {
      const mask = new K.Image({
        x: 0,
        y: 0,
        width: w,
        height: h,
        image: img,
        listening: false,
        name: 'frame-mask',
        globalCompositeOperation: 'destination-in',
      });
      group.add(mask);
      this._restackFrameLayers(group);
      this.layer?.batchDraw?.();
    };
    img.onerror = () => { /* ignore */ };
    img.src = maskSrc;
  },

  _layoutFrameFill(group) {
    const fillNode = group.findOne('.frame-fill');
    if (!fillNode || fillNode.getClassName?.() !== 'Image') return;
    const w = group.attrs.width || 400;
    const h = group.attrs.height || 400;
    const img = fillNode.image?.();
    const nw = img?.videoWidth || img?.naturalWidth || group.attrs.fillNaturalW || fillNode.width();
    const nh = img?.videoHeight || img?.naturalHeight || group.attrs.fillNaturalH || fillNode.height();
    const layout = computeFrameFillLayout(
      w,
      h,
      nw,
      nh,
      group.attrs.fillFit || 'cover',
      group.attrs.fillScale || 1,
      group.attrs.fillOffsetX || 0,
      group.attrs.fillOffsetY || 0,
    );
    fillNode.position({ x: layout.x, y: layout.y });
    fillNode.size({ width: layout.width, height: layout.height });
    this.layer?.batchDraw();
  },

  _bindFrameFillDrag(group, fillNode) {
    if (!fillNode || fillNode._frameDragBound) return;
    fillNode._frameDragBound = true;
    fillNode.on('dragend', () => {
      const w = group.attrs.width || 400;
      const h = group.attrs.height || 400;
      const img = fillNode.image?.();
      const nw = img?.videoWidth || img?.naturalWidth || fillNode.width();
      const nh = img?.videoHeight || img?.naturalHeight || fillNode.height();
      const base = computeFrameFillLayout(
        w,
        h,
        nw,
        nh,
        group.attrs.fillFit || 'cover',
        group.attrs.fillScale || 1,
        0,
        0,
      );
      group.attrs.fillOffsetX = Math.round(fillNode.x() - base.x);
      group.attrs.fillOffsetY = Math.round(fillNode.y() - base.y);
      this.onChange?.();
    });
  },

  _rebuildFrameBorder(group) {
    if (!group || group.name?.() !== 'frame') return;
    group.findOne('.frame-border')?.destroy();
    if (group.attrs.maskSrc) {
      this._restackFrameLayers(group);
      return;
    }
    const w = group.attrs.width || 400;
    const h = group.attrs.height || 400;
    const border = createFrameBorderNode(Konva, w, h, group.attrs.clipShape || 'rect', {
      stroke: group.attrs.stroke || '#d4c68d',
      strokeWidth: group.attrs.strokeWidth ?? 2,
      strokeDashed: group.attrs.strokeDashed !== false,
      cornerRadius: group.attrs.cornerRadius ?? 24,
    });
    group.add(border);
    this._restackFrameLayers(group);
  },

  resizeFrame(group, w, h) {
    if (!group || group.name?.() !== 'frame') return;
    const nw = Math.max(40, Math.round(w));
    const nh = Math.max(40, Math.round(h));
    group.attrs.width = nw;
    group.attrs.height = nh;
    group.width?.(nw);
    group.height?.(nh);
    resizeFrameChildren(group, nw, nh);
    this._applyFrameClip(group, nw, nh, group.attrs.clipShape || 'rect', group.attrs);
    this._rebuildFrameBorder(group);
    this._layoutFrameFill(group);
    group.findOne('.frame-hit')?.moveToTop();
    this.layer?.batchDraw();
    this.onChange?.();
  },

  /**
   * Aguarda imagens/vídeos de molduras e cards carregarem no Konva.
   * Evita projetar círculo vazio quando o preview/export roda cedo demais.
   */
  async waitForMediaReady(timeoutMs = 6000) {
    const deadline = Date.now() + Math.max(500, timeoutMs);
    const isPending = () => {
      const kids = this.layer?.getChildren?.() || [];
      for (const n of kids) {
        const nm = n.name?.();
        if (nm !== 'frame' && nm !== 'photo-card') continue;
        const fillSrc = String(n.attrs?.fillSrc || '');
        if (!fillSrc) continue;
        const fill = nm === 'frame'
          ? n.findOne?.('.frame-fill')
          : n.findOne?.('.card-photo-fill');
        if (!fill) return true;
        if (fill.getClassName?.() === 'Rect') return true;
        if (fill.getClassName?.() === 'Image') {
          const img = fill.image?.();
          if (!img) return true;
          if (img instanceof HTMLVideoElement) {
            if (img.readyState < 2) return true;
          } else if (!img.complete || !(img.naturalWidth > 0)) {
            return true;
          }
        }
      }
      return false;
    };
    while (isPending() && Date.now() < deadline) {
      await new Promise((r) => setTimeout(r, 40));
    }
    try { this.layer?.batchDraw?.(); } catch { /* ignore */ }
    return !isPending();
  },

  setFrameFillEditMode(group, enabled) {
    if (!group || group.name?.() !== 'frame') return;
    const fill = group.findOne('.frame-fill');
    const hit = group.findOne('.frame-hit');
    if (!fill || fill.getClassName?.() !== 'Image') return;
    group.attrs._fillEdit = !!enabled;
    if (enabled) {
      fill.listening(true);
      fill.draggable(true);
      hit?.listening(false);
      this._bindFrameFillDrag(group, fill);
      this.selectNode(group);
    } else {
      fill.draggable(false);
      fill.listening(false);
      hit?.listening(true);
      hit?.moveToTop();
    }
    this.layer?.batchDraw();
  },

  addFrame(opts = {}) {
    const w = opts.width ?? 400;
    const h = opts.height ?? 400;
    const clipShape = opts.clipShape || 'rect';
    const group = new Konva.Group({
      id: opts.id || `fr-${Date.now()}`,
      x: opts.x ?? DESIGN_W / 2 - w / 2,
      y: opts.y ?? DESIGN_H / 2 - h / 2,
      width: w,
      height: h,
      draggable: opts.locked !== true,
      name: 'frame',
      clipShape,
      cornerRadius: opts.cornerRadius ?? 24,
      maskSrc: opts.maskSrc || '',
      fillSrc: opts.fillSrc || '',
      fillMediaId: opts.fillMediaId || '',
      fillKind: opts.fillKind || 'image',
      fillOffsetX: opts.fillOffsetX || 0,
      fillOffsetY: opts.fillOffsetY || 0,
      fillFit: opts.fillFit || 'cover',
      fillScale: opts.fillScale || 1,
      stroke: opts.stroke || '#d4c68d',
      strokeWidth: opts.strokeWidth ?? 2,
      strokeDashed: opts.strokeDashed !== false,
      role: opts.role || '',
      displayName: opts.displayName || '',
    });
    this._applyFrameClip(group, w, h, clipShape, opts);
    bindFrameLogicalBounds(group);

    const placeholder = new Konva.Rect({
      x: 0,
      y: 0,
      width: w,
      height: h,
      fill: 'rgba(60,60,60,0.55)',
      name: 'frame-fill',
      listening: false,
    });
    group.add(placeholder);

    if (!opts.maskSrc) this._rebuildFrameBorder(group);

    if (opts.maskSrc) {
      this._attachFrameMaskImage(group, opts.maskSrc);
    }

    group.add(makeFrameHitRect(Konva, w, h));
    bindFrameDrag(group, {
      onPointerDown: (g) => {
        if (this.selectedNode !== g) this.selectNode(g);
      },
    });

    this.layer.add(group);
    this._restackSystemNodes();
    if (opts.fillSrc) this.setFrameFill(group, opts.fillSrc, { mediaId: opts.fillMediaId, kind: opts.fillKind });
    this.selectNode(group);
    this.onChange?.();
    this._pushHistory();
    return group;
  },

  _isVideoFillSrc(src, kind) {
    if (kind === 'video') return true;
    return /\.(mp4|webm|mov|m4v)(\?|$)/i.test(String(src || ''));
  },

  _ensureFrameVideoAnim() {
    if (this._frameVideoAnim || !window.Konva || !this.layer) return;
    this._frameVideoAnim = new window.Konva.Animation(() => {}, this.layer);
    this._frameVideoAnim.start();
  },

  setFrameFill(group, src, { mediaId = '', kind = '' } = {}) {
    if (!group || group.name?.() !== 'frame' || !src) return Promise.resolve(null);
    group.findOne('.frame-fill')?.destroy();
    const prevVideo = group.attrs._fillVideoEl;
    if (prevVideo) {
      try { prevVideo.pause(); prevVideo.removeAttribute('src'); prevVideo.load?.(); } catch { /* */ }
      group.attrs._fillVideoEl = null;
    }

    const isVideo = this._isVideoFillSrc(src, kind);
    group.attrs.fillKind = isVideo ? 'video' : 'image';

    return new Promise((resolve) => {
      const attach = (mediaEl, naturalW, naturalH) => {
        const kImg = new Konva.Image({
          image: mediaEl,
          name: 'frame-fill',
          draggable: false,
          listening: false,
          src,
        });
        group.add(kImg);
        group.attrs.fillSrc = src;
        group.attrs.fillNaturalW = naturalW || 0;
        group.attrs.fillNaturalH = naturalH || 0;
        if (mediaId) group.attrs.fillMediaId = mediaId;
        this._layoutFrameFill(group);
        this._rebuildFrameBorder(group);
        // Reaplica máscara PNG (destination-in) após o fill — senão a foto ignora a moldura
        if (group.attrs.maskSrc) {
          const existing = group.findOne('.frame-mask');
          if (existing) {
            existing.globalCompositeOperation('destination-in');
            this._restackFrameLayers(group);
          } else {
            this._attachFrameMaskImage(group, group.attrs.maskSrc);
          }
        } else {
          this._restackFrameLayers(group);
        }
        group.findOne('.frame-hit')?.listening(true);
        this.selectNode(group);
        this.onChange?.();
        resolve(kImg);
      };

      if (isVideo) {
        const video = document.createElement('video');
        video.muted = true;
        video.loop = true;
        video.playsInline = true;
        video.preload = 'auto';
        video.setAttribute('playsinline', '');
        group.attrs._fillVideoEl = video;
        video.onloadeddata = () => {
          attach(video, video.videoWidth || 1920, video.videoHeight || 1080);
          this._ensureFrameVideoAnim();
          video.play().catch(() => {});
        };
        video.onerror = () => resolve(null);
        video.src = src;
        return;
      }

      const img = new Image();
      img.onload = () => attach(img, img.naturalWidth || 0, img.naturalHeight || 0);
      img.onerror = () => resolve(null);
      img.src = src;
    });
  },

  clearFrameFill(group) {
    if (!group || group.name?.() !== 'frame') return;
    const prevVideo = group.attrs._fillVideoEl;
    if (prevVideo) {
      try { prevVideo.pause(); prevVideo.removeAttribute('src'); prevVideo.load?.(); } catch { /* */ }
      group.attrs._fillVideoEl = null;
    }
    group.findOne('.frame-fill')?.destroy();
    const w = group.attrs.width || 400;
    const h = group.attrs.height || 400;
    group.add(new Konva.Rect({
      x: 0,
      y: 0,
      width: w,
      height: h,
      fill: 'rgba(60,60,60,0.55)',
      name: 'frame-fill',
      listening: false,
    }));
    group.attrs.fillSrc = '';
    group.attrs.fillKind = 'image';
    group.attrs.fillMediaId = '';
    group.attrs.fillNaturalW = 0;
    group.attrs.fillNaturalH = 0;
    group.attrs.fillOffsetX = 0;
    group.attrs.fillOffsetY = 0;
    group.attrs._fillEdit = false;
    this._rebuildFrameBorder(group);
    group.findOne('.frame-hit')?.listening(true);
    group.findOne('.frame-hit')?.moveToTop();
    this.layer.batchDraw();
    this.selectNode(group);
    this.onChange?.();
  },

  updateFrameProps(group, patch = {}, opts = {}) {
    if (!group || group.name?.() !== 'frame') return;
    let w = group.attrs.width || 400;
    let h = group.attrs.height || 400;
    Object.assign(group.attrs, patch);
    if (patch.width != null || patch.height != null) {
      w = Math.max(40, Math.round(patch.width ?? w));
      h = Math.max(40, Math.round(patch.height ?? h));
      group.attrs.width = w;
      group.attrs.height = h;
      group.width?.(w);
      group.height?.(h);
      resizeFrameChildren(group, w, h);
    }
    if (patch.clipShape != null || patch.cornerRadius != null || patch.width != null || patch.height != null) {
      this._applyFrameClip(group, w, h, group.attrs.clipShape || 'rect', group.attrs);
    }
    if (patch.fillFit != null || patch.fillScale != null || patch.fillOffsetX != null || patch.fillOffsetY != null) {
      this._layoutFrameFill(group);
    }

    // cornerRadius sozinho: atualiza borda in-place (evita destroy/recreate a cada tick do slider)
    const onlyRadius = patch.cornerRadius != null
      && patch.clipShape == null
      && patch.stroke == null
      && patch.strokeWidth == null
      && patch.strokeDashed == null
      && patch.width == null
      && patch.height == null
      && patch.maskSrc == null;

    if (onlyRadius) {
      const border = group.findOne('.frame-border');
      const shape = group.attrs.clipShape || 'rect';
      const cr = group.attrs.cornerRadius ?? 24;
      if (border && (shape === 'rounded' || shape === 'rect') && typeof border.cornerRadius === 'function') {
        if (shape === 'rect' && cr > 0) {
          group.attrs.clipShape = 'rounded';
          this._applyFrameClip(group, w, h, 'rounded', group.attrs);
          this._rebuildFrameBorder(group);
        } else {
          border.cornerRadius(Math.min(cr, w / 2, h / 2));
        }
      } else if (!border && !group.attrs.maskSrc) {
        this._rebuildFrameBorder(group);
      }
    } else if (
      patch.stroke != null
      || patch.strokeWidth != null
      || patch.strokeDashed != null
      || patch.clipShape != null
      || patch.width != null
      || patch.height != null
      || patch.maskSrc != null
    ) {
      if (patch.maskSrc) {
        group.findOne('.frame-border')?.destroy();
        this._attachFrameMaskImage(group, patch.maskSrc);
      } else {
        this._rebuildFrameBorder(group);
      }
    }

    this.layer.batchDraw();
    // silent: painel já agenda persist — evita export+refreshLayers a cada tick do slider
    if (!opts.silent) this.onChange?.();
    // Só garante hit no topo — NÃO rebind a cada tick (causava stack overflow)
    if (!group.attrs._fillEdit) {
      const hit = group.findOne('.frame-hit');
      if (hit) {
        hit.listening(true);
        hit.moveToTop();
      }
    }
  },

  /**
   * Após Transformer: bake scale → width/height e reaplicar clip (evita moldura “desorientada”).
   */
  normalizeFrameTransform(group) {
    if (!group || group.name?.() !== 'frame') return false;
    bindFrameLogicalBounds(group);
    const rawSx = group.scaleX?.() ?? 1;
    const rawSy = group.scaleY?.() ?? 1;
    const sx = Math.abs(rawSx);
    const sy = Math.abs(rawSy);
    if (Math.abs(sx - 1) < 0.001 && Math.abs(sy - 1) < 0.001) return false;
    const w = Math.max(40, Math.round((group.attrs.width || 400) * sx));
    const h = Math.max(40, Math.round((group.attrs.height || 400) * sy));
    group.scale({ x: rawSx < 0 ? -1 : 1, y: rawSy < 0 ? -1 : 1 });
    group.attrs.width = w;
    group.attrs.height = h;
    group.width?.(w);
    group.height?.(h);
    resizeFrameChildren(group, w, h);
    this._applyFrameClip(group, w, h, group.attrs.clipShape || 'rect', group.attrs);
    this._rebuildFrameBorder(group);
    this._layoutFrameFill(group);
    group.findOne('.frame-hit')?.moveToTop();
    this.layer?.batchDraw();
    return true;
  },

  /**
   * Bake scaleX/Y → geometria (linha/imagem/forma/texto).
   * Sem isso o Transformer deixa scale residual = “tamanho fantasma” ao redimensionar de novo.
   */
  normalizeNodeTransform(node) {
    if (!node || this._isSystemNode?.(node)) return false;
    if (node.name?.() === 'frame') return this.normalizeFrameTransform(node);
    if (node.name?.() === 'photo-card') return false;

    const cls = node.getClassName?.();
    const rawSx = node.scaleX?.() ?? 1;
    const rawSy = node.scaleY?.() ?? 1;
    const sx = Math.abs(rawSx);
    const sy = Math.abs(rawSy);
    if (Math.abs(sx - 1) < 0.001 && Math.abs(sy - 1) < 0.001) return false;

    const flipX = rawSx < 0 ? -1 : 1;
    const flipY = rawSy < 0 ? -1 : 1;

    if (cls === 'Line') {
      const pts = (node.points?.() || []).slice();
      for (let i = 0; i < pts.length; i += 2) {
        pts[i] *= rawSx;
        pts[i + 1] *= rawSy;
      }
      node.points(pts);
      node.scale({ x: 1, y: 1 });
      this.layer?.batchDraw();
      return true;
    }

    if (cls === 'Image' || cls === 'Rect') {
      const w = Math.max(8, Math.round(Math.abs((node.width?.() || 0) * sx)));
      const h = Math.max(8, Math.round(Math.abs((node.height?.() || 0) * sy)));
      node.width?.(w);
      node.height?.(h);
      node.scale({ x: flipX, y: flipY });
      this.layer?.batchDraw();
      return true;
    }

    if (cls === 'Circle') {
      const r = Math.max(4, Math.round(Math.abs((node.radius?.() || 0) * Math.max(sx, sy))));
      node.radius?.(r);
      node.scale({ x: flipX, y: flipY });
      this.layer?.batchDraw();
      return true;
    }

    if (cls === 'Ellipse') {
      node.radiusX?.(Math.max(4, Math.round(Math.abs((node.radiusX?.() || 0) * sx))));
      node.radiusY?.(Math.max(4, Math.round(Math.abs((node.radiusY?.() || 0) * sy))));
      node.scale({ x: flipX, y: flipY });
      this.layer?.batchDraw();
      return true;
    }

    if (cls === 'Text') {
      const w = Math.max(24, Math.round(Math.abs((node.width?.() || 0) * sx)));
      const fs = Math.max(8, Math.round(Math.abs((node.fontSize?.() || 48) * sy)));
      node.width?.(w);
      node.fontSize?.(fs);
      node.scale({ x: flipX, y: flipY });
      this.healTextLayout?.(node);
      this.layer?.batchDraw();
      return true;
    }

    // Genérico: zera scale residual quando possível
    if (typeof node.width === 'function' && typeof node.height === 'function') {
      const w = Math.max(8, Math.round(Math.abs((node.width() || 0) * sx)));
      const h = Math.max(8, Math.round(Math.abs((node.height() || 0) * sy)));
      node.width(w);
      node.height(h);
      node.scale({ x: flipX, y: flipY });
      this.layer?.batchDraw();
      return true;
    }

    return false;
  },

  /** Reconecta seleção/drag em molduras após import/load. */
  rebindFrameInteractions() {
    for (const n of this.layer?.getChildren?.() || []) {
      if (n.name?.() === 'frame') {
        bindFrameLogicalBounds(n);
        const w = n.attrs.width || 400;
        const h = n.attrs.height || 400;
        n.attrs._frameDragHandler = null;
        n.findOne('.frame-hit')?.destroy?.();
        n.add(makeFrameHitRect(Konva, w, h));
        this._rebuildFrameBorder(n);
        n.attrs._fillEdit = false;
        bindFrameDrag(n, {
          onPointerDown: (g) => {
            if (this.selectedNode !== g) this.selectNode(g);
          },
        });
        // Garante máscara com destination-in após reload
        const mask = n.findOne('.frame-mask');
        if (mask) {
          mask.globalCompositeOperation('destination-in');
        } else if (n.attrs.maskSrc) {
          this._attachFrameMaskImage(n, n.attrs.maskSrc);
        }
        this._restackFrameLayers(n);
        continue;
      }
      if (n.name?.() === 'photo-card') {
        const hit = n.findOne('.card-hit');
        if (hit?.attrs) hit.attrs._dragBound = false;
        bindPhotoCardDrag(n, {
          onPointerDown: (g) => {
            if (this.selectedNode !== g) this.selectNode(g);
          },
        });
        n.findOne('.card-hit')?.moveToTop();
      }
    }
    this.layer?.batchDraw?.();
  },

  addPhotoCard(opts = {}) {
    const { group } = buildPhotoCardNodes(Konva, opts);
    this.layer.add(group);
    this._restackSystemNodes();
    // Seleção no mousedown (stage ignora photo-card para não cancelar o drag)
    bindPhotoCardDrag(group, {
      onPointerDown: (g) => {
        if (this.selectedNode !== g) this.selectNode(g);
      },
    });
    if (opts.fillSrc) this.setPhotoCardFill(group, opts.fillSrc, { mediaId: opts.fillMediaId });
    this.selectNode(group);
    this.onChange?.();
    this._pushHistory();
    return group;
  },

  setPhotoCardFill(group, src, { mediaId = '' } = {}) {
    if (!group || group.name?.() !== 'photo-card' || !src) return Promise.resolve(null);
    const photoWrap = group.findOne('.card-photo-wrap');
    if (!photoWrap) return Promise.resolve(null);
    photoWrap.findOne('.card-photo-fill')?.destroy();
    return new Promise((resolve) => {
      const img = new Image();
      img.onload = () => {
        const kImg = new Konva.Image({
          image: img,
          name: 'card-photo-fill',
          listening: false,
          draggable: false,
          src,
        });
        photoWrap.add(kImg);
        kImg.moveToBottom();
        photoWrap.findOne('.card-photo-ring')?.moveToTop();
        group.attrs.fillSrc = src;
        if (mediaId) group.attrs.fillMediaId = mediaId;
        layoutPhotoCardFill(group, kImg);
        group.findOne('.card-hit')?.moveToTop();
        this.layer.batchDraw();
        this.onChange?.();
        resolve(kImg);
      };
      img.onerror = () => resolve(null);
      img.src = src;
    });
  },

  updatePhotoCardProps(group, patch = {}, opts = {}) {
    if (!group || group.name?.() !== 'photo-card') return;
    if (patch.cardTitle != null && patch.cardName == null) patch.cardName = patch.cardTitle;
    if (patch.cardSubtitle != null && patch.cardFrom == null) patch.cardFrom = patch.cardSubtitle;
    Object.assign(group.attrs, patch);
    if (patch.cardName != null) group.attrs.cardTitle = patch.cardName;
    if (patch.cardFrom != null) group.attrs.cardSubtitle = patch.cardFrom;
    if (patch.photoSize != null || patch.width != null || patch.height != null
      || patch.titleSize != null || patch.subtitleSize != null || patch.labelSize != null) {
      relayoutPhotoCardGroup(group);
    }
    const labelNode = group.findOne('.card-label');
    const nameNode = group.findOne('.card-name') || group.findOne('.card-title');
    const fromNode = group.findOne('.card-from') || group.findOne('.card-subtitle');
    if (patch.cardLabel != null && labelNode) labelNode.text(patch.cardLabel);
    if (patch.cardName != null && nameNode) nameNode.text(patch.cardName);
    if (patch.cardFrom != null && fromNode) fromNode.text(patch.cardFrom);
    if (patch.labelSize != null && labelNode) labelNode.fontSize(patch.labelSize);
    if (patch.titleSize != null && nameNode) nameNode.fontSize(patch.titleSize);
    if (patch.subtitleSize != null && fromNode) fromNode.fontSize(patch.subtitleSize);
    if (patch.labelColor != null && labelNode) labelNode.fill(patch.labelColor);
    if (patch.titleColor != null && nameNode) nameNode.fill(patch.titleColor);
    if (patch.subtitleColor != null && fromNode) fromNode.fill(patch.subtitleColor);
    if (patch.cornerRadius != null) {
      group.findOne('.card-bg')?.cornerRadius(patch.cornerRadius);
    }
    if (patch.fillFit != null || patch.fillScale != null || patch.fillOffsetX != null || patch.fillOffsetY != null) {
      const fillNode = group.findOne('.card-photo-fill');
      if (fillNode?.getClassName?.() === 'Image') layoutPhotoCardFill(group, fillNode);
    }
    group.findOne('.card-hit')?.moveToTop();
    this.layer.batchDraw();
    if (!opts.silent) this.onChange?.();
  },

};
