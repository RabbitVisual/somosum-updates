/** Slide layer panel operations for SlideDesigner. */

export const designerLayerOpsMethods = {

  persistCurrentSlide(opts = {}) {
    const existingPreview = this.slides[this.slideIndex]?.previewDataUrl;
    const exported = this.canvas.exportSlide({
      title: this.slides[this.slideIndex]?.title,
      templateId: this.slides[this.slideIndex]?.templateId,
      includePreview: !!opts.includePreview,
      existingPreview: opts.includePreview ? undefined : existingPreview,
    });
    this.slides[this.slideIndex] = {
      ...exported,
      templateId: this.slides[this.slideIndex]?.templateId || exported.templateId,
    };
    if (!opts.skipLayers) this.refreshLayers();
    if (opts.markDirty) this._markDirty?.();
  },

  /** Debounce persist durante sliders (evita piscada / perda de foco no painel). */
  _scheduleDesignerPersist() {
    clearTimeout(this._designerPersistTimer);
    this._designerPersistTimer = setTimeout(() => {
      this.persistCurrentSlide({ markDirty: true, skipLayers: false });
      this._markDirty?.();
    }, 280);
  },

  _getContentNodes() {
    const eng = this._getEngine();
    return typeof eng?.getContentNodes === 'function' ? eng.getContentNodes() : [];
  },

  refreshLayers() {
    const eng = this._getEngine();
    const list = typeof eng?.getLayerList === 'function' ? eng.getLayerList() : [];
    this.layerPanel?.setLayers(list, eng?.selectedNode?.id());
  },

  reorderLayer(from, to) {
    const eng = this._getEngine();
    const children = this._getContentNodes();
    const node = children[children.length - 1 - from];
    if (!node) return;
    if (to > from) node.moveDown();
    else node.moveUp();
    eng._restackSystemNodes?.();
    eng.layer?.batchDraw();
    this.refreshLayers();
    this.persistCurrentSlide();
  },

  layerActionById(id, action) {
    const node = this.canvas.findNode(id);
    if (!node) return;
    this.canvas.selectNode(node);
    this.canvas.layerOrder(action);
    this.refreshLayers();
    this.persistCurrentSlide();
  },

  toggleLayer(id, prop) {
    const node = this.canvas.findNode(id);
    if (!node) return;
    if (prop === 'visible') node.visible(!node.visible());
    if (prop === 'locked') node.draggable(!node.draggable());
    this.canvas.layer.batchDraw();
    this.refreshLayers();
    this.persistCurrentSlide();
  },

};
