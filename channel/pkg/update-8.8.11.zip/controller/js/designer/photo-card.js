/** Card foto + texto (estilo mensagem bíblica / pregador) — editor + projeção. */

import { computeFrameFillLayout, bindLogicalClientRect } from './frame-utils.js';

export const PHOTO_CARD_DEFAULTS = {
  width: 380,
  height: 460,
  photoSize: 200,
  padding: 28,
  gap: 18,
  cornerRadius: 18,
  panelFill: 'rgba(0,0,0,0.42)',
  panelStroke: 'rgba(212,175,55,0.4)',
  photoStroke: '#d4af37',
  labelSize: 22,
  titleSize: 32,
  subtitleSize: 22,
  labelColor: '#d4c68d',
  titleColor: '#ffffff',
  subtitleColor: '#aaaaaa',
  cardLabel: 'Pregador',
  cardName: 'Rev. João Silva',
  cardFrom: 'IB Batista — Feira de Santana',
  title: 'Rev. João Silva',
  subtitle: 'IB Batista — Feira de Santana',
};

export const PHOTO_CARD_PREACHER_PRESET = {
  cardLabel: 'Pregador',
  cardName: 'Rev. João Silva',
  cardFrom: 'IB Batista — Feira de Santana',
  photoSize: 200,
};

/** Migra cardTitle/cardSubtitle legados para cardName/cardFrom. */
export function normalizePhotoCardFields(spec = {}) {
  const d = { ...PHOTO_CARD_DEFAULTS, ...spec };
  if (d.cardName == null && d.cardTitle != null) d.cardName = d.cardTitle;
  if (d.cardFrom == null && d.cardSubtitle != null) d.cardFrom = d.cardSubtitle;
  if (d.cardName == null && d.title != null) d.cardName = d.title;
  if (d.cardFrom == null && d.subtitle != null) d.cardFrom = d.subtitle;
  if (d.cardLabel == null || d.cardLabel === '') d.cardLabel = 'Pregador';
  d.cardTitle = d.cardName ?? d.cardTitle ?? '';
  d.cardSubtitle = d.cardFrom ?? d.cardSubtitle ?? '';
  return d;
}

export function photoCardLayout(spec = {}) {
  const d = normalizePhotoCardFields(spec);
  const w = d.width;
  const photo = d.photoSize;
  const pad = d.padding;
  const photoX = (w - photo) / 2;
  const photoY = pad;
  const labelY = photoY + photo + d.gap;
  const nameY = labelY + d.labelSize + 4;
  const fromY = nameY + d.titleSize + 8;
  return {
    width: w,
    height: d.height,
    photoX,
    photoY,
    photoSize: photo,
    labelY,
    nameY,
    fromY,
    titleY: nameY,
    subtitleY: fromY,
    titleWidth: w - pad * 2,
    titleX: pad,
  };
}

function escHtml(t) {
  return String(t ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

export function renderPhotoCardHtml(layer) {
  const d = normalizePhotoCardFields(layer);
  const layout = photoCardLayout(d);
  const left = `${((layer.x || 0) / 1920) * 100}%`;
  const top = `${((layer.y || 0) / 1080) * 100}%`;
  const width = `${(layout.width / 1920) * 100}%`;
  const rot = layer.rotation ? `transform:rotate(${layer.rotation}deg);` : '';
  const opacity = layer.opacity != null ? layer.opacity : 1;
  const hidden = layer.visible === false ? 'visibility:hidden;' : '';
  const photoPx = `${layout.photoSize}px`;

  let photoInner = '<div class="designer-photo-card-img designer-photo-card-img--empty"></div>';
  if (layer.fillSrc) {
    const fl = computeFrameFillLayout(
      layout.photoSize,
      layout.photoSize,
      layout.photoSize,
      layout.photoSize,
      layer.fillFit || 'cover',
      layer.fillScale || 1,
      layer.fillOffsetX || 0,
      layer.fillOffsetY || 0,
    );
    photoInner = `<img class="designer-photo-card-img" src="${layer.fillSrc}" alt="" style="left:${(fl.x / layout.photoSize) * 100}%;top:${(fl.y / layout.photoSize) * 100}%;width:${(fl.width / layout.photoSize) * 100}%;height:${(fl.height / layout.photoSize) * 100}%;" />`;
  }

  const label = layer.cardLabel !== undefined ? layer.cardLabel : d.cardLabel;
  const name = layer.cardName !== undefined ? layer.cardName : (layer.cardTitle ?? d.cardName);
  const from = layer.cardFrom !== undefined ? layer.cardFrom : (layer.cardSubtitle ?? d.cardFrom);

  return `<div class="custom-layer custom-layer-photo-card" style="left:${left};top:${top};width:${width};opacity:${opacity};${hidden}${rot}">
    <div class="designer-photo-card-panel message-preacher-card" style="border-radius:${d.cornerRadius}px">
      <div class="designer-photo-card-photo-wrap msg-preacher-photo-wrap" style="width:${photoPx};height:${photoPx}">
        ${photoInner}
      </div>
      <div class="designer-photo-card-info msg-preacher-info">
        ${label ? `<span class="designer-photo-card-label msg-label">${escHtml(label)}</span>` : ''}
        <p class="designer-photo-card-name msg-preacher-name" style="font-size:${d.titleSize}px">${escHtml(name)}</p>
        ${from ? `<p class="designer-photo-card-from msg-preacher-from" style="font-size:${d.subtitleSize}px">${escHtml(from)}</p>` : ''}
      </div>
    </div>
  </div>`;
}

export function exportPhotoCardGroup(group) {
  const layout = photoCardLayout({
    width: group.attrs.width,
    height: group.attrs.height,
    photoSize: group.attrs.photoSize,
  });
  const fillNode = group.findOne('.card-photo-fill');
  const labelNode = group.findOne('.card-label');
  const nameNode = group.findOne('.card-name') || group.findOne('.card-title');
  const fromNode = group.findOne('.card-from') || group.findOne('.card-subtitle');
  const cardName = nameNode?.text?.() || group.attrs.cardName || group.attrs.cardTitle || '';
  const cardFrom = fromNode?.text?.() || group.attrs.cardFrom || group.attrs.cardSubtitle || '';
  return {
    kind: 'photo-card',
    id: group.id(),
    x: group.x(),
    y: group.y(),
    width: group.attrs.width || layout.width,
    height: group.attrs.height || layout.height,
    rotation: group.rotation?.() || 0,
    opacity: group.opacity?.() ?? 1,
    visible: group.visible?.() !== false,
    locked: group.draggable?.() === false,
    photoSize: group.attrs.photoSize || PHOTO_CARD_DEFAULTS.photoSize,
    cornerRadius: group.attrs.cornerRadius ?? PHOTO_CARD_DEFAULTS.cornerRadius,
    fillSrc: fillNode?.attrs?.src || fillNode?.image?.()?.src || group.attrs.fillSrc || '',
    fillMediaId: group.attrs.fillMediaId || '',
    fillOffsetX: group.attrs.fillOffsetX || 0,
    fillOffsetY: group.attrs.fillOffsetY || 0,
    fillFit: group.attrs.fillFit || 'cover',
    fillScale: group.attrs.fillScale || 1,
    cardLabel: labelNode?.text?.() || group.attrs.cardLabel || 'Pregador',
    cardName,
    cardFrom,
    cardTitle: cardName,
    cardSubtitle: cardFrom,
    labelSize: labelNode?.fontSize?.() || group.attrs.labelSize || PHOTO_CARD_DEFAULTS.labelSize,
    titleSize: nameNode?.fontSize?.() || group.attrs.titleSize || PHOTO_CARD_DEFAULTS.titleSize,
    subtitleSize: fromNode?.fontSize?.() || group.attrs.subtitleSize || PHOTO_CARD_DEFAULTS.subtitleSize,
    labelColor: labelNode?.fill?.() || group.attrs.labelColor || PHOTO_CARD_DEFAULTS.labelColor,
    titleColor: nameNode?.fill?.() || group.attrs.titleColor || PHOTO_CARD_DEFAULTS.titleColor,
    subtitleColor: fromNode?.fill?.() || group.attrs.subtitleColor || PHOTO_CARD_DEFAULTS.subtitleColor,
  };
}

export function bindPhotoCardDrag(group, { onPointerDown } = {}) {
  const hit = group.findOne('.card-hit');
  if (!hit) return;
  if (typeof onPointerDown === 'function') {
    group.attrs._onPhotoCardPointerDown = onPointerDown;
  }
  // Rebind seguro (clone / reload)
  if (hit.attrs._dragBound && hit.attrs._photoHitHandler) {
    hit.off('mousedown', hit.attrs._photoHitHandler);
    hit.off('touchstart', hit.attrs._photoHitHandler);
    hit.attrs._dragBound = false;
  }
  if (hit.attrs._dragBound) return;
  hit.attrs._dragBound = true;
  const handler = (e) => {
    if (e.target?.getClassName?.() === 'Transformer') return;
    e.cancelBubble = true;
    if (group.draggable() === false) return;
    if (!group.isDragging?.()) {
      try {
        group.startDrag(e);
      } catch { /* ignore */ }
    }
    // Seleciona depois — sem isso o painel de propriedades não abre (stage ignora photo-card)
    queueMicrotask(() => {
      try {
        group.attrs._onPhotoCardPointerDown?.(group, e);
      } catch { /* ignore */ }
    });
  };
  hit.attrs._photoHitHandler = handler;
  hit.on('mousedown touchstart', handler);
}

export function relayoutPhotoCardGroup(group) {
  if (!group || group.name?.() !== 'photo-card') return;
  const layout = photoCardLayout({
    width: group.attrs.width,
    height: group.attrs.height,
    photoSize: group.attrs.photoSize,
    padding: group.attrs.padding,
    gap: group.attrs.gap,
    labelSize: group.attrs.labelSize,
    titleSize: group.attrs.titleSize,
    subtitleSize: group.attrs.subtitleSize,
  });
  const radius = group.attrs.cornerRadius ?? PHOTO_CARD_DEFAULTS.cornerRadius;
  group.findOne('.card-bg')?.setAttrs({
    width: layout.width,
    height: layout.height,
    cornerRadius: radius,
  });
  const photoWrap = group.findOne('.card-photo-wrap');
  if (photoWrap) {
    photoWrap.position({ x: layout.photoX, y: layout.photoY });
    photoWrap.size({ width: layout.photoSize, height: layout.photoSize });
    photoWrap.clipFunc((ctx) => {
      ctx.beginPath();
      ctx.arc(layout.photoSize / 2, layout.photoSize / 2, layout.photoSize / 2, 0, Math.PI * 2);
      ctx.closePath();
    });
    const ring = photoWrap.findOne('.card-photo-ring');
    ring?.position({ x: layout.photoSize / 2, y: layout.photoSize / 2 });
    ring?.radius(layout.photoSize / 2);
    const placeholder = photoWrap.findOne('.card-photo-fill');
    if (placeholder?.getClassName?.() === 'Rect') {
      placeholder.size({ width: layout.photoSize, height: layout.photoSize });
    }
  }
  const labelNode = group.findOne('.card-label');
  labelNode?.position({ x: layout.titleX, y: layout.labelY });
  labelNode?.width(layout.titleWidth);
  const nameNode = group.findOne('.card-name') || group.findOne('.card-title');
  nameNode?.position({ x: layout.titleX, y: layout.nameY });
  nameNode?.width(layout.titleWidth);
  const fromNode = group.findOne('.card-from') || group.findOne('.card-subtitle');
  fromNode?.position({ x: layout.titleX, y: layout.fromY });
  fromNode?.width(layout.titleWidth);
  group.findOne('.card-hit')?.size({ width: layout.width, height: layout.height });
  group.findOne('.card-hit')?.moveToTop();
  const fillNode = group.findOne('.card-photo-fill');
  if (fillNode?.getClassName?.() === 'Image') layoutPhotoCardFill(group, fillNode);
}

export function buildPhotoCardNodes(K, spec = {}) {
  const d = normalizePhotoCardFields(spec);
  const layout = photoCardLayout(d);
  const group = new K.Group({
    id: spec.id || `pc-${Date.now()}`,
    x: spec.x ?? 1920 / 2 - layout.width / 2,
    y: spec.y ?? 1080 / 2 - layout.height / 2,
    width: layout.width,
    height: layout.height,
    draggable: spec.locked !== true,
    name: 'photo-card',
    photoSize: d.photoSize,
    cornerRadius: d.cornerRadius,
    fillSrc: spec.fillSrc || '',
    fillMediaId: spec.fillMediaId || '',
    fillOffsetX: spec.fillOffsetX || 0,
    fillOffsetY: spec.fillOffsetY || 0,
    fillFit: spec.fillFit || 'cover',
    fillScale: spec.fillScale || 1,
    cardLabel: d.cardLabel,
    cardName: d.cardName,
    cardFrom: d.cardFrom,
    cardTitle: d.cardName,
    cardSubtitle: d.cardFrom,
    labelSize: spec.labelSize || d.labelSize,
    titleSize: spec.titleSize || d.titleSize,
    subtitleSize: spec.subtitleSize || d.subtitleSize,
    labelColor: spec.labelColor || d.labelColor,
    titleColor: spec.titleColor || d.titleColor,
    subtitleColor: spec.subtitleColor || d.subtitleColor,
    rotation: spec.rotation || 0,
    opacity: spec.opacity ?? 1,
    visible: spec.visible !== false,
  });

  bindLogicalClientRect(group, function () {
    return {
      w: Number(this.attrs.width) || layout.width,
      h: Number(this.attrs.height) || layout.height,
    };
  });

  group.add(new K.Rect({
    x: 0,
    y: 0,
    width: layout.width,
    height: layout.height,
    fill: d.panelFill,
    stroke: d.panelStroke,
    strokeWidth: 1,
    cornerRadius: d.cornerRadius,
    listening: false,
    name: 'card-bg',
  }));

  const photoGroup = new K.Group({
    x: layout.photoX,
    y: layout.photoY,
    width: layout.photoSize,
    height: layout.photoSize,
    name: 'card-photo-wrap',
    listening: false,
  });
  photoGroup.clipFunc((ctx) => {
    ctx.beginPath();
    ctx.arc(layout.photoSize / 2, layout.photoSize / 2, layout.photoSize / 2, 0, Math.PI * 2);
    ctx.closePath();
  });

  photoGroup.add(new K.Rect({
    x: 0,
    y: 0,
    width: layout.photoSize,
    height: layout.photoSize,
    fill: 'rgba(60,60,60,0.55)',
    name: 'card-photo-fill',
    listening: false,
  }));

  photoGroup.add(new K.Circle({
    x: layout.photoSize / 2,
    y: layout.photoSize / 2,
    radius: layout.photoSize / 2,
    stroke: d.photoStroke,
    strokeWidth: 3,
    listening: false,
    name: 'card-photo-ring',
  }));
  group.add(photoGroup);

  group.add(new K.Text({
    x: layout.titleX,
    y: layout.labelY,
    width: layout.titleWidth,
    text: d.cardLabel,
    fontSize: spec.labelSize || d.labelSize,
    fontFamily: 'Segoe UI',
    fill: spec.labelColor || d.labelColor,
    align: 'center',
    name: 'card-label',
    listening: false,
  }));

  group.add(new K.Text({
    x: layout.titleX,
    y: layout.nameY,
    width: layout.titleWidth,
    text: d.cardName,
    fontSize: spec.titleSize || d.titleSize,
    fontFamily: 'Segoe UI',
    fill: spec.titleColor || d.titleColor,
    align: 'center',
    fontStyle: 'bold',
    name: 'card-name',
    listening: false,
  }));

  group.add(new K.Text({
    x: layout.titleX,
    y: layout.fromY,
    width: layout.titleWidth,
    text: d.cardFrom,
    fontSize: spec.subtitleSize || d.subtitleSize,
    fontFamily: 'Segoe UI',
    fill: spec.subtitleColor || d.subtitleColor,
    align: 'center',
    name: 'card-from',
    listening: false,
  }));

  group.add(new K.Rect({
    x: 0,
    y: 0,
    width: layout.width,
    height: layout.height,
    fill: 'rgba(0,0,0,0.001)',
    name: 'card-hit',
    listening: true,
  }));

  bindPhotoCardDrag(group);
  return { group, layout };
}

export function layoutPhotoCardFill(group, fillNode) {
  if (!fillNode || fillNode.getClassName?.() !== 'Image') return;
  const photoWrap = group.findOne('.card-photo-wrap');
  const size = photoWrap?.width?.() || group.attrs.photoSize || PHOTO_CARD_DEFAULTS.photoSize;
  const img = fillNode.image?.();
  const layout = computeFrameFillLayout(
    size,
    size,
    img?.naturalWidth || fillNode.width(),
    img?.naturalHeight || fillNode.height(),
    group.attrs.fillFit || 'cover',
    group.attrs.fillScale || 1,
    group.attrs.fillOffsetX || 0,
    group.attrs.fillOffsetY || 0,
  );
  fillNode.position({ x: layout.x, y: layout.y });
  fillNode.size({ width: layout.width, height: layout.height });
}
