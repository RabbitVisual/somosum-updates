/** Painel de camadas — ordem, visibilidade, bloqueio + FA Duotone */

import { faBtnIcon, DS_ICONS as I } from './fa-icon.js';

export class LayerPanel {

  constructor(container, { onSelect, onReorder, onToggle, onLayerAction, onRename }) {

    this.container = container;

    this.onSelect = onSelect;

    this.onReorder = onReorder;

    this.onToggle = onToggle;

    this.onLayerAction = onLayerAction;

    this.onRename = onRename;

    this.layers = [];

    this.selectedId = null;

  }



  setLayers(layers, selectedId) {

    this.layers = layers || [];

    this.selectedId = selectedId;

    this.render();

  }



  render() {

    if (!this.container) return;

    if (!this.layers.length) {

      this.container.innerHTML = `<div class="designer-empty">${faBtnIcon(I.layers)} Nenhuma camada — use Ferramentas</div>`;

      return;

    }

    this.container.innerHTML = this.layers

      .map((l, i) => {

        const active = l.id === this.selectedId ? ' is-active' : '';

        const hidden = l.visible === false ? ' is-hidden' : '';

        const locked = l.locked ? ' is-locked' : '';

        const visIco = l.visible === false ? I.hidden : I.visible;

        const lockIco = l.locked ? I.lock : I.unlock;

        return `<div class="designer-layer${active}${hidden}${locked}" data-id="${l.id}" data-idx="${i}">

          <button type="button" class="layer-vis" data-act="vis" title="Mostrar/ocultar">${faBtnIcon(visIco)}</button>

          <button type="button" class="layer-lock" data-act="lock" title="Bloquear">${faBtnIcon(lockIco)}</button>

          <span class="layer-kind">${kindIcon(l.kind)}</span>

          <span class="layer-name" title="Duplo-clique para renomear" data-rename="${l.id}">${esc(l.label || l.name || l.kind)}</span>

          <div class="layer-actions">

            <button type="button" data-act="front" title="Trazer frente">${faBtnIcon(I.layerFront)}</button>

            <button type="button" data-act="up" title="Acima">${faBtnIcon(I.layerForward)}</button>

            <button type="button" data-act="down" title="Abaixo">${faBtnIcon(I.layerBackward)}</button>

            <button type="button" data-act="back" title="Enviar fundo">${faBtnIcon(I.layerBack)}</button>

          </div>

        </div>`;

      })

      .join('');



    this.container.querySelectorAll('.designer-layer').forEach((row) => {

      row.addEventListener('click', (e) => {

        const act = e.target.closest('[data-act]')?.dataset.act;

        const id = row.dataset.id;

        const idx = Number(row.dataset.idx);

        if (act === 'vis') {

          e.stopPropagation();

          this.onToggle?.(id, 'visible');

          return;

        }

        if (act === 'lock') {

          e.stopPropagation();

          this.onToggle?.(id, 'locked');

          return;

        }

        if (act === 'front' || act === 'back') {

          e.stopPropagation();

          this.onLayerAction?.(id, act === 'front' ? 'front' : 'back');

          return;

        }

        if (act === 'up') {

          e.stopPropagation();

          this.onReorder?.(idx, idx - 1);

          return;

        }

        if (act === 'down') {

          e.stopPropagation();

          this.onReorder?.(idx, idx + 1);

          return;

        }

        this.onSelect?.(id);

      });

      row.querySelector('[data-rename]')?.addEventListener('dblclick', (e) => {
        e.stopPropagation();
        const id = row.dataset.id;
        const span = e.currentTarget;
        const current = span.textContent || '';
        const input = document.createElement('input');
        input.type = 'text';
        input.className = 'layer-rename-input';
        input.value = current;
        input.style.cssText = 'width:100%;min-width:4rem;background:#1a1a1a;border:1px solid #d4c68d;color:#fff;font-size:0.75rem;padding:0.1rem 0.25rem;border-radius:3px';
        const finish = (ok) => {
          const next = input.value.trim();
          span.textContent = ok && next ? next : current;
          input.replaceWith(span);
          if (ok && next && next !== current) this.onRename?.(id, next);
        };
        input.addEventListener('keydown', (ev) => {
          if (ev.key === 'Enter') { ev.preventDefault(); finish(true); }
          if (ev.key === 'Escape') { ev.preventDefault(); finish(false); }
        });
        input.addEventListener('blur', () => finish(true));
        span.replaceWith(input);
        input.focus();
        input.select();
      });

    });

  }

}



function kindIcon(kind) {

  const map = {
    Text: I.text,
    Image: I.image,
    Rect: I.rect,
    Circle: I.circle,
    Line: I.line,
    Group: I.group,
  };

  return faBtnIcon(map[kind] || 'shapes');
}



function esc(t) {

  const d = document.createElement('div');

  d.textContent = t ?? '';

  return d.innerHTML;

}
