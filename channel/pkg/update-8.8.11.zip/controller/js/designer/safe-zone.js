/** Safe-zone SSOT — margins, violation detection, clamp for Designer canvas. */

import { DESIGN_W, DESIGN_H } from './slide-exporter.js';

export const SAFE_PAD = DESIGN_W * 0.05; // 96px on 1920

export function getSafeRect() {
  return {
    x: SAFE_PAD,
    y: SAFE_PAD,
    width: DESIGN_W - SAFE_PAD * 2,
    height: DESIGN_H - SAFE_PAD * 2,
  };
}

const FULL_BLEED_ROLES = new Set(['overlay', 'full-bleed', 'background']);

/**
 * Layers that intentionally cover the full frame (welcome dim overlay, etc.).
 */
export function isSafeZoneExempt(node) {
  if (!node) return true;
  const name = node.name?.() || '';
  if (name === 'grid' || name === 'safe-zone' || name === 'design-bg'
    || name === 'design-bg-image' || name === 'design-bg-dim') return true;
  if (node.getClassName?.() === 'Transformer') return true;
  if (node.getAttr?.('safeExempt') === true) return true;
  const role = node.getAttr?.('role') || node.attrs?.role || '';
  if (FULL_BLEED_ROLES.has(role)) return true;
  // Full-frame locked rects (welcome overlay)
  if (node.draggable?.() === false) {
    const w = Math.abs((node.width?.() || 0) * (node.scaleX?.() || 1));
    const h = Math.abs((node.height?.() || 0) * (node.scaleY?.() || 1));
    if (w >= DESIGN_W * 0.95 && h >= DESIGN_H * 0.95) return true;
  }
  return false;
}

function nodeLabel(node) {
  const role = node.getAttr?.('role') || '';
  const text = node.text?.()?.slice?.(0, 40);
  const name = node.name?.() || node.getClassName?.() || 'elemento';
  if (text) return text;
  if (role) return role;
  return name;
}

/**
 * @param {object} engine CanvasEngine-like ({ getContentNodes, layer })
 * @returns {{ id: string, label: string, reason: string, node: object }[]}
 */
export function getSafeZoneViolations(engine) {
  const nodes = typeof engine?.getContentNodes === 'function'
    ? engine.getContentNodes()
    : (engine?.layer?.getChildren?.() || []).filter((n) => !isSafeZoneExempt(n));

  const safe = getSafeRect();
  const layer = engine?.layer;
  const violations = [];

  for (const node of nodes) {
    if (isSafeZoneExempt(node)) continue;
    if (node.visible?.() === false) continue;

    let box;
    try {
      box = node.getClientRect?.({
        relativeTo: layer || undefined,
        skipShadow: true,
        skipStroke: false,
      });
    } catch {
      box = null;
    }
    if (!box) {
      const sx = Math.abs(node.scaleX?.() || 1);
      const sy = Math.abs(node.scaleY?.() || 1);
      box = {
        x: node.x?.() || 0,
        y: node.y?.() || 0,
        width: Math.abs((node.width?.() || 0) * sx),
        height: Math.abs((node.height?.() || 0) * sy),
      };
    }

    const right = box.x + box.width;
    const bottom = box.y + box.height;
    const outs = [];
    if (box.x < safe.x - 0.5) outs.push('esquerda');
    if (box.y < safe.y - 0.5) outs.push('topo');
    if (right > safe.x + safe.width + 0.5) outs.push('direita');
    if (bottom > safe.y + safe.height + 0.5) outs.push('baixo');
    if (!outs.length) continue;

    violations.push({
      id: node.id?.() || String(node._id || ''),
      label: nodeLabel(node),
      reason: `fora da área segura (${outs.join(', ')})`,
      node,
    });
  }

  return violations;
}

/**
 * Clamp node AABB into safe rect by translating (and mild uniform scale if needed).
 */
export function clampNodeToSafeZone(node, layer) {
  if (!node || isSafeZoneExempt(node)) return false;
  const safe = getSafeRect();
  let box = node.getClientRect?.({ relativeTo: layer, skipShadow: true }) || {
    x: node.x(),
    y: node.y(),
    width: Math.abs((node.width?.() || 0) * (node.scaleX?.() || 1)),
    height: Math.abs((node.height?.() || 0) * (node.scaleY?.() || 1)),
  };

  let changed = false;

  // Scale down if larger than safe area
  if (box.width > safe.width || box.height > safe.height) {
    const factor = Math.min(safe.width / Math.max(1, box.width), safe.height / Math.max(1, box.height)) * 0.98;
    if (factor > 0 && factor < 1) {
      const sx = (node.scaleX?.() || 1) * factor;
      const sy = (node.scaleY?.() || 1) * factor;
      if (node.scaleX) node.scaleX(sx);
      if (node.scaleY) node.scaleY(sy);
      // Prefer shrinking text layout width when possible
      if (node.getClassName?.() === 'Text' && node.width) {
        node.width(Math.max(24, node.width() * factor));
        node.scaleX(Math.sign(node.scaleX?.() || 1) || 1);
        node.scaleY(Math.sign(node.scaleY?.() || 1) || 1);
      }
      changed = true;
      box = node.getClientRect?.({ relativeTo: layer, skipShadow: true }) || box;
    }
  }

  let dx = 0;
  let dy = 0;
  if (box.x < safe.x) dx = safe.x - box.x;
  if (box.y < safe.y) dy = safe.y - box.y;
  if (box.x + box.width + dx > safe.x + safe.width) {
    dx = safe.x + safe.width - (box.x + box.width);
  }
  if (box.y + box.height + dy > safe.y + safe.height) {
    dy = safe.y + safe.height - (box.y + box.height);
  }
  if (dx !== 0 || dy !== 0) {
    node.x(node.x() + dx);
    node.y(node.y() + dy);
    changed = true;
  }
  return changed;
}

export function clampAllToSafeZone(engine) {
  const violations = getSafeZoneViolations(engine);
  let n = 0;
  for (const v of violations) {
    if (clampNodeToSafeZone(v.node, engine.layer)) n += 1;
  }
  engine.layer?.batchDraw?.();
  return n;
}

export function formatSafeZoneAlert(violations) {
  const lines = violations.slice(0, 8).map((v) => `• ${v.label}: ${v.reason}`);
  const extra = violations.length > 8 ? `\n…e mais ${violations.length - 8}` : '';
  return `Há ${violations.length} elemento(s) fora da margem de segurança.\n`
    + 'Corrija antes de salvar ou projetar para não vazar na projeção.\n\n'
    + lines.join('\n') + extra
    + '\n\nOK = encaixar automaticamente na área segura\nCancelar = voltar e corrigir manualmente';
}
