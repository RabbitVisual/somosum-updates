/** Re-export — ícones globais SOMOSUM (Designer usa o mesmo pack). */
export {
  faIcon,
  faBtnIcon,
  faIconRaw,
  faClass,
  DS_ICONS,
  SU_SLIDE,
  SU_ACTION,
  slideTypeIcon,
} from '../core/fa-icons.js';
