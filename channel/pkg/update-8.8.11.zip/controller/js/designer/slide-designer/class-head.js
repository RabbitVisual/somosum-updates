import { LayerPanel } from '.././layer-panel.js';

import { PropertiesPanel } from '.././properties-panel.js';

import { bindToolbox } from '.././toolbox.js';

import { faBtnIcon, DS_ICONS as I } from '.././fa-icon.js';

import { PHOTO_CARD_PREACHER_PRESET } from '.././photo-card.js';
import { designerTemplatesUIMethods } from '.././designer-templates-ui.js';
import { designerLayerOpsMethods } from '.././designer-layer-ops.js';
import { designerCanvasBridgeMethods } from '.././designer-canvas-bridge.js';
import { designerProgramMethods } from '.././designer-program-actions.js';
import {
  getSafeZoneViolations,
  clampAllToSafeZone,
  formatSafeZoneAlert,
} from '.././safe-zone.js';
import { bindContextMenu } from '../../ui/kit/context-menu.js';

import { loadCustomFonts } from '../../core/fonts.js';
import { dataPublicUrl } from '../../core/data-public-url.js';
import { importModule } from '../../core/asset-registry.js';
import { rawHtml, setHtml } from '../../core/render-engine/index.js';

export class SlideDesigner {

  constructor(root, app) {

    this.root = root;

    this.app = app;

    this.canvas = null;

    this._engine = null;

    this.layerPanel = null;

    this.propsPanel = null;

    this.slides = [{ title: 'Slide 1', layers: [], templateId: 'blank' }];

    this.slideIndex = 0;

    this._fileInput = null;

    this._fonts = [];

    this._engine = null;

    this._CanvasEngine = null;

    this._sourceItemIndex = null;

    this._editingTemplateId = null;

    this._tplSearch = '';

    this._dirty = false;

    this._autosaveTimer = null;

  }



  setSourceItemIndex(idx) {
    this._sourceItemIndex = typeof idx === 'number' ? idx : null;
    this._syncSaveButtons();
  }

  _updateSaveItemButton() {
    this._syncSaveButtons();
  }

  _syncSaveButtons() {
    const saveItem = this.root?.querySelector('#ds-save-item');
    const saveTpl = this.root?.querySelector('#ds-save-tpl');
    const savePrimary = this.root?.querySelector('#ds-save-primary');
    const refreshContent = this.root?.querySelector('#ds-refresh-content');
    const hasItem = this._sourceItemIndex != null;

    if (refreshContent) {
      refreshContent.style.display = hasItem ? '' : 'none';
      refreshContent.disabled = !hasItem;
    }

    if (saveItem) {
      saveItem.style.display = '';
      saveItem.disabled = !hasItem;
      saveItem.title = hasItem
        ? 'Salvar alterações neste item da Ordem do culto'
        : 'Abra o Designer a partir de um item da Ordem para salvar nele';
      saveItem.textContent = hasItem ? 'Salvar na Ordem' : 'Item';
    }
    if (saveTpl) {
      saveTpl.textContent = this._editingTemplateId ? 'Atualizar modelo' : 'Salvar modelo';
      saveTpl.title = this._editingTemplateId
        ? 'Atualizar o modelo salvo na biblioteca'
        : 'Salvar como novo modelo (presets embutidos viram cópia)';
    }
    if (savePrimary) {
      if (hasItem) {
        savePrimary.textContent = 'Salvar na Ordem';
        savePrimary.title = 'Salvar no item da Ordem (Ctrl+S)';
        savePrimary.disabled = false;
      } else if (this._editingTemplateId) {
        savePrimary.textContent = 'Salvar';
        savePrimary.title = 'Atualizar modelo na biblioteca';
        savePrimary.disabled = false;
      } else {
        savePrimary.textContent = 'Salvar';
        savePrimary.title = 'Salvar como novo modelo na biblioteca';
        savePrimary.disabled = false;
      }
    }
  }

  async savePrimaryAction() {
    if (this._sourceItemIndex != null) {
      await this.saveToSourceItem();
      return;
    }
    await this.saveTemplate();
    this._clearDirty();
  }

  /**
   * Hard gate: block save/project when content leaves the safe margin.
   * @returns {Promise<boolean>}
   */
  async _ensureSafeZoneClear() {
    const eng = this._getEngine?.() || this.canvas;
    if (!eng) return true;
    const violations = getSafeZoneViolations(eng);
    if (!violations.length) return true;

    if (violations[0]?.node) eng.selectNode?.(violations[0].node);

    const fix = confirm(formatSafeZoneAlert(violations));
    if (!fix) {
      this.app.toast?.('Corrija a margem de segurança antes de salvar ou projetar', 'warn');
      return false;
    }

    clampAllToSafeZone(eng);
    eng.layer?.batchDraw?.();
    this.persistCurrentSlide?.({ markDirty: true });
    this.propsPanel?.setNode(eng.selectedNode);

    const still = getSafeZoneViolations(eng);
    if (still.length) {
      if (still[0]?.node) eng.selectNode?.(still[0].node);
      this.app.toast?.('Ainda há elementos fora da área segura — ajuste manualmente', 'error');
      return false;
    }
    this.app.toast?.('Elementos encaixados na área segura');
    return true;
  }

  _bindDesignerContextMenu() {
    const host = this.root?.querySelector('#designer-canvas') || this.root?.querySelector('#designer-canvas-wrap');
    if (!host || this._ctxMenuUnbind) return;
    this._ctxMenuUnbind = bindContextMenu(host, (e) => {
      const eng = this.canvas;
      if (!eng) return [];
      // Hit-test Konva under cursor
      const stage = eng.stage;
      if (stage) {
        const rect = stage.container().getBoundingClientRect();
        const scale = stage.scaleX() || 1;
        const pos = {
          x: (e.clientX - rect.left) / scale,
          y: (e.clientY - rect.top) / scale,
        };
        const shape = stage.getIntersection?.(pos);
        if (shape && !eng._isSystemNode?.(shape)) {
          let node = shape;
          while (node?.getParent?.() && node.getParent() !== eng.layer) {
            if (node.name?.() === 'designer-group' || node.name?.() === 'frame' || node.name?.() === 'photo-card') break;
            const p = node.getParent();
            if (p === eng.layer) break;
            node = p;
          }
          if (!eng.selectedNodes?.includes(node) && eng.selectedNode !== node) {
            eng.selectNode?.(node);
          }
        }
      }

      const hasSel = !!(eng.selectedNode || eng.selectedNodes?.length);
      const isText = eng.selectedNode?.getClassName?.() === 'Text';
      const locked = eng.selectedNode?.draggable?.() === false;

      if (!hasSel) {
        return [
          { label: 'Colar (clipboard)', action: () => this._pasteFromOsClipboard?.() },
          { label: 'Colar elemento', action: () => {
            if (eng.pasteClipboardNode?.()) this.app.toast?.('Elemento colado');
            else this.app.toast?.('Nada para colar', 'warn');
          } },
          { sep: true },
          { label: 'Selecionar tudo', action: () => {
            const nodes = eng.getContentNodes?.() || [];
            if (!nodes.length) return;
            eng.selectNode?.(nodes[0]);
            for (let i = 1; i < nodes.length; i++) eng.selectNode?.(nodes[i], { multi: true });
          } },
          { label: 'Mostrar / ocultar área segura', action: () => {
            const cb = this.root?.querySelector('#ds-toggle-safe');
            if (cb) {
              cb.checked = !cb.checked;
              cb.dispatchEvent(new Event('change'));
            }
          } },
          { sep: true },
          { label: 'Adicionar texto', action: () => eng.addText?.('Novo texto') },
        ];
      }

      return [
        { label: 'Duplicar', action: () => eng.duplicateSelected?.() },
        { label: 'Copiar', action: () => {
          eng.copySelectedToClipboard?.();
          this.app.toast?.('Elemento copiado');
        } },
        { label: 'Colar elemento', action: () => eng.pasteClipboardNode?.() },
        { label: 'Excluir', danger: true, action: () => eng.deleteSelected?.() },
        { sep: true },
        { label: 'Copiar estilo', action: () => {
          eng.copyStyleSelected?.();
          this.app.toast?.('Estilo copiado');
        } },
        { label: 'Colar estilo', action: () => {
          if (eng.pasteStyleSelected?.()) {
            this.propsPanel?.setNode(eng.selectedNode);
            this.app.toast?.('Estilo aplicado');
          } else this.app.toast?.('Nenhum estilo na área de transferência', 'warn');
        } },
        { sep: true },
        { label: locked ? 'Desbloquear' : 'Bloquear', action: () => eng.toggleLockSelected?.() },
        { label: 'Trazer à frente', action: () => eng.layerOrder?.('front') },
        { label: 'Enviar ao fundo', action: () => eng.layerOrder?.('back') },
        { label: 'Um nível acima', action: () => eng.layerOrder?.('forward') },
        { label: 'Um nível abaixo', action: () => eng.layerOrder?.('backward') },
        { sep: true },
        { label: 'Espelhar horizontal', action: () => eng.flipSelected?.('h') },
        { label: 'Espelhar vertical', action: () => eng.flipSelected?.('v') },
        { label: 'Inverter', action: () => eng.flipSelected?.('h') },
        { label: 'Rodar +90°', action: () => eng.rotateSelected?.(90) },
        { label: 'Rodar −90°', action: () => eng.rotateSelected?.(-90) },
        ...(isText ? [
          { sep: true },
          { label: 'Ajustar caixa ao texto', action: () => {
            eng.fitTextBox?.(eng.selectedNode);
            this.propsPanel?.setNode(eng.selectedNode);
          } },
          { label: 'Editar texto', action: () => eng.startInlineTextEdit?.(eng.selectedNode) },
        ] : []),
        { sep: true },
        { label: 'Alinhar ao centro', action: () => eng.alignSelected?.('center') },
        { label: 'Alinhar à área segura (esq.)', action: () => eng.alignSelected?.('left') },
        { label: 'Agrupar', action: () => eng.groupSelected?.() },
        { label: 'Desagrupar', action: () => eng.ungroupSelected?.() },
      ];
    });
  }

  async _pasteFromOsClipboard() {
    try {
      const items = await navigator.clipboard?.read?.();
      if (items?.length) {
        for (const item of items) {
          const imgType = item.types.find((t) => t.startsWith('image/'));
          if (imgType) {
            const blob = await item.getType(imgType);
            const reader = new FileReader();
            const dataUrl = await new Promise((resolve, reject) => {
              reader.onload = () => resolve(reader.result);
              reader.onerror = reject;
              reader.readAsDataURL(blob);
            });
            this.canvas?.addImage?.(dataUrl);
            this.app.toast?.('Imagem colada');
            return;
          }
        }
      }
      const text = await navigator.clipboard?.readText?.();
      if (text?.trim()) {
        const node = this.canvas?.addText?.(text.trim());
        if (node) this.canvas?.fitTextBox?.(node);
        this.app.toast?.('Texto colado');
        return;
      }
      if (this.canvas?.pasteClipboardNode?.()) {
        this.app.toast?.('Elemento colado');
        return;
      }
      this.app.toast?.('Clipboard vazio', 'warn');
    } catch {
      if (this.canvas?.pasteClipboardNode?.()) this.app.toast?.('Elemento colado');
      else this.app.toast?.('Não foi possível ler o clipboard', 'warn');
    }
  }



  async _loadCanvasEngine() {

    if (this._CanvasEngine) return this._CanvasEngine;

    const mod = await importModule('/js/designer/canvas-engine.js');

    this._CanvasEngine = mod.CanvasEngine;

    return this._CanvasEngine;

  }



  _getEngine() {

    return this._engine || this.canvas;

  }

}
