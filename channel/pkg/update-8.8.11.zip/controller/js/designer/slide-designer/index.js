export { SlideDesigner } from './class-head.js';
import { SlideDesigner } from './class-head.js';
import { slideDesignerMount } from './mount.js';
import { slideDesignerTail } from './class-tail.js';
import { designerTemplatesUIMethods } from '../designer-templates-ui.js';
import { designerLayerOpsMethods } from '../designer-layer-ops.js';
import { designerCanvasBridgeMethods } from '../designer-canvas-bridge.js';
import { designerProgramMethods } from '../designer-program-actions.js';

Object.assign(
  SlideDesigner.prototype,
  designerTemplatesUIMethods,
  designerLayerOpsMethods,
  designerCanvasBridgeMethods,
  designerProgramMethods,
  slideDesignerMount,
  slideDesignerTail,
);
