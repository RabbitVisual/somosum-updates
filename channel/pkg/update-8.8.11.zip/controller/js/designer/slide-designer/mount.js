import { loadCustomFonts } from '../../core/fonts.js';
import { rawHtml, setHtml } from '../../core/render-engine/index.js';
import { faBtnIcon, DS_ICONS as I } from '../fa-icon.js';
import { LayerPanel } from '../layer-panel.js';
import { PropertiesPanel } from '../properties-panel.js';
import { bindToolbox } from '../toolbox.js';
import { PHOTO_CARD_PREACHER_PRESET } from '../photo-card.js';

export const slideDesignerMount = {
  async mount() {

    if (!this._fonts?.length) {
      this._fonts = await loadCustomFonts({ injectFaces: true });
    } else {
      await loadCustomFonts({ injectFaces: true });
    }

    const CanvasEngine = await this._loadCanvasEngine();



    setHtml(this.root, rawHtml(`
      <div class="designer-shell designer-shell--pro">
        <header class="designer-topbar">
          <div class="designer-topbar-brand">
            <span class="designer-topbar-kicker">Designer</span>
            <input type="text" id="ds-slide-title" class="designer-slide-title-input" placeholder="Nome do slide (ex.: Boas-vindas)" maxlength="80" />
            <span class="designer-dirty-badge is-clean" id="ds-dirty-badge">Salvo</span>
          </div>
          <div class="designer-topbar-context" id="ds-context" aria-live="polite">
            <span class="designer-ctx-pill is-bg" data-ctx="bg">${faBtnIcon(I.background)} Fundo</span>
            <span class="designer-ctx-pill is-el" data-ctx="el">${faBtnIcon(I.tools)} Elemento</span>
            <span class="designer-ctx-pill is-slide is-active" data-ctx="slide">${faBtnIcon(I.models)} Slide</span>
          </div>
          <div class="designer-toolbar-actions">
            <button type="button" class="btn btn-secondary btn-sm designer-icon-btn" id="ds-undo" title="Desfazer (Ctrl+Z)">${faBtnIcon(I.undo)}</button>
            <button type="button" class="btn btn-secondary btn-sm designer-icon-btn" id="ds-redo" title="Refazer (Ctrl+Y)">${faBtnIcon(I.redo)}</button>
            <button type="button" class="btn btn-secondary btn-sm designer-icon-btn" id="ds-zoom-out" title="Zoom −">${faBtnIcon(I.zoomOut)}</button>
            <span class="designer-zoom-label" id="ds-zoom-label">100%</span>
            <button type="button" class="btn btn-secondary btn-sm designer-icon-btn" id="ds-zoom-in" title="Zoom +">${faBtnIcon(I.zoomIn)}</button>
            <button type="button" class="btn btn-secondary btn-sm designer-icon-btn" id="ds-zoom-fit" title="Ajustar ao quadro">${faBtnIcon(I.zoomFit)}</button>
            <button type="button" class="btn btn-secondary btn-sm" id="ds-export-png" title="Exportar PNG 1080p">PNG</button>
            <button type="button" class="btn btn-secondary btn-sm" id="ds-export-pdf" title="Exportar PDF">PDF</button>
            <button type="button" class="btn btn-primary btn-sm" id="ds-save-primary" title="Salvar (Ctrl+S)">${faBtnIcon(I.save)} Salvar</button>
            <button type="button" class="btn btn-secondary btn-sm" id="ds-refresh-content" title="Re-injetar Bíblia/welcome/foto da Ordem" style="display:none">Atualizar conteúdo</button>
            <button type="button" class="btn btn-secondary btn-sm" id="ds-save-tpl" title="Salvar slide na biblioteca">Salvar slide</button>
            <button type="button" class="btn btn-secondary btn-sm" id="ds-save-item" title="Salvar no item da ordem">Na ordem</button>
            <button type="button" class="btn btn-secondary btn-sm" id="ds-add-program">+ Ordem</button>
            <button type="button" class="btn btn-live btn-sm" id="ds-live">${faBtnIcon(I.project)} Projetar</button>
          </div>
        </header>

        <div class="designer-workspace">
          <nav class="designer-rail" aria-label="Painéis do designer">
            <button type="button" class="designer-rail-btn is-active" data-left-tab="tools" title="Elementos">
              <span class="designer-rail-ico">${faBtnIcon(I.tools)}</span><span>Elementos</span>
            </button>
            <button type="button" class="designer-rail-btn" data-left-tab="layers" title="Camadas">
              <span class="designer-rail-ico">${faBtnIcon(I.layers)}</span><span>Camadas</span>
            </button>
            <button type="button" class="designer-rail-btn" data-left-tab="media" title="Mídia e fontes">
              <span class="designer-rail-ico">${faBtnIcon(I.media)}</span><span>Mídia</span>
            </button>
            <button type="button" class="designer-rail-btn" data-left-tab="saved" title="Slides salvos">
              <span class="designer-rail-ico">${faBtnIcon(I.models)}</span><span>Salvos</span>
            </button>
            <button type="button" class="designer-rail-btn" data-left-tab="background" title="Fundo do slide">
              <span class="designer-rail-ico">${faBtnIcon(I.background)}</span><span>Fundo</span>
            </button>
            <button type="button" class="designer-rail-btn" data-left-tab="presets" title="Modelos de culto">
              <span class="designer-rail-ico">${faBtnIcon(I.models)}</span><span>Modelos</span>
            </button>
          </nav>

          <aside class="designer-side designer-side-left" id="designer-side-left">
            <div class="designer-left-panel is-active" data-left-panel="tools">
              <div class="designer-panel-head">Elementos</div>
              <p class="designer-panel-lead">Clique para adicionar. Shift+clique no canvas = multi-seleção · Ctrl+G agrupa.</p>
              <div class="designer-toolbox designer-toolbox--panel" id="designer-toolbox"></div>
            </div>
            <div class="designer-left-panel" data-left-panel="layers">
              <div class="designer-panel-head">Camadas</div>
              <div id="designer-layers" class="designer-panel-body designer-layers-panel"></div>
            </div>
            <div class="designer-left-panel" data-left-panel="media">
              <div class="designer-panel-head designer-panel-head-row">
                <span>Fontes (pasta fonts/)</span>
                <button type="button" class="designer-panel-refresh designer-icon-btn" id="ds-refresh-fonts" title="Recarregar fontes">${faBtnIcon(I.refresh)}</button>
              </div>
              <p class="designer-panel-lead">Clique numa fonte com um texto selecionado no canvas. As mesmas famílias valem na Ordem e na tela.</p>
              <div id="designer-fonts" class="designer-panel-body designer-fonts-list"></div>
              <div class="designer-panel-head">Biblioteca / Imagens e vídeos</div>
              <div id="designer-library" class="designer-panel-body designer-library"></div>
            </div>
            <div class="designer-left-panel" data-left-panel="saved">
              <div class="designer-panel-head">Slides salvos</div>
              <div id="designer-saved" class="designer-panel-body designer-saved-panel"></div>
            </div>
            <div class="designer-left-panel" data-left-panel="background">
              <div class="designer-panel-head">Fundo &amp; atmosfera</div>
              <p class="designer-panel-lead">O fundo fica atrás de tudo. Use Escurecer para legibilidade do texto.</p>
              <div id="designer-bg-quick" class="designer-bg-quick"></div>
              <div class="designer-panel-note">Ajuste fino também aparece em <strong>Propriedades</strong> à direita quando nada está selecionado.</div>
            </div>
            <div class="designer-left-panel" data-left-panel="presets">
              <div class="designer-panel-head">Modelos de culto</div>
              <p class="designer-panel-lead">Pontos de partida (Bem-vindo, Ceia…). Seus slides salvos ficam na aba <strong>Salvos</strong>.</p>
              <div id="designer-presets" class="designer-panel-body designer-presets"></div>
            </div>
          </aside>

          <main class="designer-stage">
            <div class="designer-stage-chrome">
              <div class="designer-stage-meta" id="ds-stage-meta">1920×1080 · Área segura ativa</div>
              <div class="designer-stage-controls">
                <label class="designer-toggle" title="Mostrar grade">
                  <input type="checkbox" id="ds-toggle-grid" checked /> Grade
                </label>
                <label class="designer-toggle" title="Guias inteligentes ao arrastar">
                  <input type="checkbox" id="ds-toggle-guides" checked /> Guias
                </label>
                <label class="designer-toggle" title="Área segura do projetor">
                  <input type="checkbox" id="ds-toggle-safe" checked /> Safe
                </label>
              </div>
            </div>
            <div class="designer-canvas-wrap" id="designer-canvas-wrap">
              <div class="designer-stage-stack" id="designer-stage-stack">
                <video id="designer-bg-video" class="designer-bg-video" muted loop playsinline preload="metadata" hidden aria-hidden="true"></video>
                <div id="designer-canvas" class="designer-canvas"></div>
              </div>
            </div>
            <div class="designer-quickbar" id="designer-quickbar" aria-label="Ações rápidas">
              <button type="button" class="designer-quick-btn" data-quick="text" title="Texto">${faBtnIcon(I.text)}</button>
              <button type="button" class="designer-quick-btn" data-quick="rect" title="Retângulo">${faBtnIcon(I.rect)}</button>
              <button type="button" class="designer-quick-btn" data-quick="image" title="Imagem">${faBtnIcon(I.image)}</button>
              <button type="button" class="designer-quick-btn" data-quick="logo" title="Logo">${faBtnIcon(I.logo)}</button>
              <span class="designer-quick-sep"></span>
              <button type="button" class="designer-quick-btn" data-quick="group" title="Agrupar (Ctrl+G)">${faBtnIcon(I.group)}</button>
              <button type="button" class="designer-quick-btn" data-quick="ungroup" title="Desagrupar">${faBtnIcon(I.ungroup)}</button>
              <button type="button" class="designer-quick-btn" data-quick="align-center" title="Centralizar">${faBtnIcon(I.alignCenter)}</button>
              <button type="button" class="designer-quick-btn" data-quick="flip-h" title="Espelhar H">⇋</button>
              <button type="button" class="designer-quick-btn" data-quick="rot-p90" title="Rodar +90°">⟳</button>
              <button type="button" class="designer-quick-btn" data-quick="rot-m90" title="Rodar −90°">⟲</button>
              <button type="button" class="designer-quick-btn" data-quick="duplicate" title="Duplicar">${faBtnIcon(I.duplicate)}</button>
              <button type="button" class="designer-quick-btn is-danger" data-quick="delete" title="Excluir">${faBtnIcon(I.delete)}</button>
            </div>
          </main>

          <aside class="designer-side designer-side-right">
            <div class="designer-props-tabs" id="ds-props-tabs">
              <button type="button" class="designer-props-tab is-active" data-props-tab="design">Design</button>
              <button type="button" class="designer-props-tab" data-props-tab="position">Posição</button>
              <button type="button" class="designer-props-tab" data-props-tab="effects">Efeitos</button>
            </div>
            <div class="designer-panel-head" id="ds-props-head">Propriedades</div>
            <p class="designer-panel-lead" id="ds-props-lead">Sem seleção: edite o fundo do slide. Com seleção: tipografia, posição e estilo.</p>
            <div id="designer-props" class="designer-panel-body"></div>
          </aside>
        </div>

        <footer class="designer-footer">
          <div class="designer-slides" id="designer-slides"></div>
          <p class="designer-hint" id="designer-hint">Salvos → editar · Mídia → arrastar para moldura · Ctrl+S salva · Del exclui</p>
        </footer>

        <div class="designer-modal" id="ds-master-modal" hidden>
          <div class="designer-modal-card" role="dialog" aria-labelledby="ds-master-title">
            <h3 id="ds-master-title">Aplicar master slide</h3>
            <p class="designer-panel-lead">Escolha um master para aplicar fundo e camadas base.</p>
            <div id="ds-master-list" class="designer-master-list"></div>
            <div class="designer-modal-actions">
              <button type="button" class="btn btn-secondary btn-sm" id="ds-master-cancel">Cancelar</button>
            </div>
          </div>
        </div>
      </div>`));


    const canvasEl = this.root.querySelector('#designer-canvas');

    const engine = new CanvasEngine(canvasEl, {

      onSelect: (node) => {

        // soft se for o mesmo nó — evita remount do painel (sliders perdem o clique)
        const same = node && this.propsPanel?.node === node;
        this.propsPanel?.setNode(node, { soft: !!same });

        this.propsPanel?.setBackground(this._getBackground());

        this.refreshLayers();

        this._updateDesignerContext(node);

      },

      onChange: () => {
        this.persistCurrentSlide({ markDirty: false });
        this._markDirty();
      },

    });

    engine.refreshLayers = () => this.refreshLayers();

    this._engine = engine;

    this.canvas = engine;



    if (!engine.init()) {

      setHtml(canvasEl, rawHtml('<div class="designer-error">Konva nao carregou. Feche o controle, reinicie o SOMOSUM.exe e abra de novo (Ctrl+F5).</div>'));

      return;

    }

    this._bindDesignerContextMenu();



    this.propsPanel = new PropertiesPanel(this.root.querySelector('#designer-props'), {

      fonts: this._fonts,

      onChange: (payload) => {
        let needsPropsRerender = false;

        if (payload?.type === 'frameFill') {
          const node = this.canvas.selectedNode;
          if (node?.name?.() === 'frame') {
            this.canvas.setFrameFill(node, payload.src, { kind: payload.kind || '' }).then?.(() => {
              this.propsPanel?.setNode(this.canvas.selectedNode);
              this.refreshLayers();
              this._markDirty?.();
            });
          }
          return;
        }
        if (payload?.type === 'frameClear') {
          const node = this.canvas.selectedNode;
          if (node?.name?.() === 'frame') {
            this.canvas.clearFrameFill(node);
            needsPropsRerender = true;
          }
        }
        if (payload?.type === 'frameFillEdit') {
          const node = this.canvas.selectedNode;
          if (node?.name?.() === 'frame') {
            this.canvas.setFrameFillEditMode(node, !!payload.enabled);
            needsPropsRerender = true;
          }
        }
        if (payload?.type === 'frameProps') {
          const node = this.canvas.selectedNode;
          if (node?.name?.() === 'frame') {
            this.canvas.updateFrameProps(node, payload.patch || {}, { silent: true });
            if (payload.patch?.maskSrc) this._applyFrameMaskOverlay(node, payload.patch.maskSrc);
            needsPropsRerender = !!payload.rerender
              || payload.patch?.maskSrc != null
              || (payload.patch?.clipShape != null && payload.patch?.cornerRadius == null);
          }
        }
        if (payload?.type === 'imageReplace') {
          const node = this.canvas.selectedNode;
          if (node?.getClassName?.() === 'Image' && payload.src) {
            const img = new Image();
            img.onload = () => {
              node.image(img);
              node.attrs.src = payload.src;
              this.canvas.layer?.batchDraw();
              this.canvas.onChange?.();
              this.propsPanel?.setNode(node);
            };
            img.src = payload.src;
          }
        }
        if (payload?.type === 'photoCardFill') {
          const node = this.canvas.selectedNode;
          if (node?.name?.() === 'photo-card') {
            this.canvas.setPhotoCardFill(node, payload.src).then?.(() => {
              this.propsPanel?.setNode(this.canvas.selectedNode);
            });
          }
        }
        if (payload?.type === 'photoCardProps') {
          const node = this.canvas.selectedNode;
          if (node?.name?.() === 'photo-card') {
            this.canvas.updatePhotoCardProps(node, payload.patch || {}, { silent: true });
          }
        }
        if (payload?.type === 'fitText') {
          this.canvas.fitTextBox?.(this.canvas.selectedNode);
          // Não remount — só ajusta caixa no canvas
        }
        if (payload?.type === 'textFit') {
          this.canvas.setTextFitMode?.(payload.mode, this.canvas.selectedNode);
          needsPropsRerender = true;
        }
        if (payload?.type === 'flip') {
          this.canvas.flipSelected?.(payload.axis || 'h');
          needsPropsRerender = true;
        }
        if (payload?.type === 'rotateBy') {
          this.canvas.rotateSelected?.(payload.delta || 0);
          needsPropsRerender = true;
        }
        if (payload?.type === 'rotateReset') {
          this.canvas.resetRotationSelected?.();
          needsPropsRerender = true;
        }

        this.canvas.layer?.batchDraw();

        if (needsPropsRerender) {
          this.propsPanel?.setNode(this.canvas.selectedNode);
        } else if (this.canvas.selectedNode) {
          this.propsPanel?.setNode(this.canvas.selectedNode, { soft: true });
        }

        const continuous = payload?.type === 'frameProps'
          || payload?.type === 'photoCardProps'
          || payload?.type === 'fitText'

          || (payload && typeof payload === 'object' && !payload.type && typeof payload.getClassName === 'function');

        if (continuous) {
          this._scheduleDesignerPersist();
        } else {
          this.persistCurrentSlide();
          this.refreshLayers();
        }
      },

      onBackground: (bg) => {

        if (bg?.type === 'pick-image') {

          this.pickBackgroundImage({ dim: bg.dim, fit: bg.fit });

          return;

        }

        if (bg?.type === 'pick-video') {

          void this.pickBackgroundVideo({ dim: bg.dim, fit: bg.fit });

          return;

        }

        // Evita onChange do canvas a cada tick do slider (remount / perda de arraste)
        this.canvas.setBackground(bg, { silent: true });

        this.propsPanel.setBackground(this.canvas.getBackground?.() || bg, { soft: true });

        this._scheduleDesignerPersist();

        this._markDirty?.();

      },

    });



    this.layerPanel = new LayerPanel(this.root.querySelector('#designer-layers'), {
      onSelect: (id) => {
        const node = this.canvas.findNode?.(id);
        if (node) this.canvas.selectNode(node);
      },
      onReorder: (from, to) => this.reorderLayer(from, to),
      onToggle: (id, prop) => this.toggleLayer(id, prop),
      onLayerAction: (id, action) => this.layerActionById(id, action),
      onRename: (id, name) => {
        const node = this.canvas.findNode?.(id);
        if (!node) return;
        node.setAttr?.('displayName', name);
        node.attrs.displayName = name;
        this.persistCurrentSlide();
        this._markDirty?.();
        this.refreshLayers();
      },
    });



    bindToolbox(this.root.querySelector('#designer-toolbox'), {

      text: () => this.canvas.addText('Novo texto'),

      rect: () => this.canvas.addRect(),

      circle: () => this.canvas.addCircle(),

      line: () => this.canvas.addLine(),

      'frame-rect': () => this.canvas.addFrame({ clipShape: 'rect' }),

      'frame-rounded': () => this.canvas.addFrame({ clipShape: 'rounded', cornerRadius: 32 }),

      'frame-circle': () => this.canvas.addFrame({ clipShape: 'circle' }),

      'frame-ellipse': () => this.canvas.addFrame({ clipShape: 'ellipse', width: 480, height: 360 }),

      'frame-star': () => this.canvas.addFrame({ clipShape: 'star', width: 420, height: 420 }),

      'frame-hex': () => this.canvas.addFrame({ clipShape: 'hexagon', width: 420, height: 420 }),

      'frame-diamond': () => this.canvas.addFrame({ clipShape: 'diamond', width: 380, height: 380 }),

      'preacher-card': () => {
        this.canvas.addPhotoCard({ ...PHOTO_CARD_PREACHER_PRESET });
        this.propsPanel?.setActiveTab?.('design');
        this.root?.querySelectorAll('.designer-props-tab').forEach((t) => {
          t.classList.toggle('is-active', t.dataset.propsTab === 'design');
        });
      },

      'frame-mask': () => this.pickFrameMask(),

      image: () => this.pickImage(),

      logo: () => this.canvas.addLogo(this.app.getAssetUrls().logo),

      'media-library': () => this.pickFromMediaLibrary(),

      'bg-dark': () => this.canvas.setBackground({ type: 'gradient', preset: 'dark' }),

      'bg-gold': () => this.canvas.setBackground({ type: 'gradient', preset: 'gold' }),

      'bg-theme': () => this.canvas.setBackground({ type: 'gradient', preset: 'theme' }),

      'bg-bible': () => this.canvas.setBackground({ type: 'gradient', preset: 'bible' }),

      'bg-image': () => this.pickBackgroundImage({}),

      'align-left': () => this.canvas.alignSelected('left'),

      'align-center-h': () => this.canvas.alignSelected('center-h'),

      'align-right': () => this.canvas.alignSelected('right'),

      'align-top': () => this.canvas.alignSelected('top'),

      'align-middle': () => this.canvas.alignSelected('center-v'),

      'align-bottom': () => this.canvas.alignSelected('bottom'),

      'align-center': () => this.canvas.alignSelected('center'),

      'distribute-h': () => this.canvas.distributeSelected?.('h'),

      'distribute-v': () => this.canvas.distributeSelected?.('v'),

      'layer-front': () => this.canvas.layerOrder('front'),

      'layer-forward': () => this.canvas.layerOrder('forward'),

      'layer-backward': () => this.canvas.layerOrder('backward'),

      'layer-back': () => this.canvas.layerOrder('back'),

      duplicate: () => this.canvas.duplicateSelected(),

      delete: () => this.canvas.deleteSelected(),

      group: () => this.canvas.groupSelected?.(),

      ungroup: () => this.canvas.ungroupSelected?.(),

      'flip-h': () => this.canvas.flipSelected?.('h'),

      'rot-p90': () => this.canvas.rotateSelected?.(90),

      'rot-m90': () => this.canvas.rotateSelected?.(-90),

      'block-title': () => this._insertBlock('title'),

      'block-verse': () => this._insertBlock('verse'),

      'block-logo': () => this._insertBlock('logo'),

      'master-apply': () => this._applyMasterSlide(),

    });



    this.root.querySelector('#ds-undo').onclick = () => this.canvas.undo();

    this.root.querySelector('#ds-redo').onclick = () => this.canvas.redo();

    this.root.querySelector('#ds-export-png')?.addEventListener('click', async () => {
      const { downloadStagePng } = await import('../slide-export-media.js');
      const ok = downloadStagePng(this.canvas?.stage, 'slide-1920x1080.png');
      this.app.toast?.(ok ? 'PNG exportado' : 'Falha ao exportar PNG', ok ? 'success' : 'warn');
    });

    this.root.querySelector('#ds-export-pdf')?.addEventListener('click', async () => {
      const { exportStagePdfViaPrint } = await import('../slide-export-media.js');
      const ok = exportStagePdfViaPrint(this.canvas?.stage, 'SOMOSUM Slide');
      if (!ok) this.app.toast?.('Falha ao abrir PDF', 'warn');
    });

    this.root.querySelector('#ds-zoom-in')?.addEventListener('click', () => {
      this.canvas.setZoom?.(0.08);
      this._syncZoomLabel();
    });

    this.root.querySelector('#ds-zoom-out')?.addEventListener('click', () => {
      this.canvas.setZoom?.(-0.08);
      this._syncZoomLabel();
    });

    this.root.querySelector('#ds-zoom-fit')?.addEventListener('click', () => {
      this.canvas.resetZoom?.();
      this._syncZoomLabel();
    });

    this.root.querySelector('#designer-canvas-wrap')?.addEventListener('wheel', (e) => {
      if (!e.ctrlKey && !e.metaKey) return;
      e.preventDefault();
      this.canvas.setZoom?.(e.deltaY < 0 ? 0.06 : -0.06);
      this._syncZoomLabel();
    }, { passive: false });

    this.root.querySelector('#ds-save-tpl').onclick = () => this.saveTemplate();

    this.root.querySelector('#ds-save-item').onclick = () => this.saveToSourceItem();

    this.root.querySelector('#ds-refresh-content')?.addEventListener('click', () => {
      this.refreshContentFromSourceItem?.();
    });

    this.root.querySelector('#ds-save-primary')?.addEventListener('click', () => {
      void this.savePrimaryAction();
    });

    this._syncSaveButtons();

    this.root.querySelector('#ds-add-program').onclick = () => this.addToProgram();

    this.root.querySelector('#ds-live').onclick = () => this.projectCurrent();

    this.root.querySelector('#ds-refresh-fonts')?.addEventListener('click', () => this.reloadFonts());

    this.root.querySelectorAll('.designer-rail-btn, .designer-left-tab').forEach((tab) => {
      tab.addEventListener('click', () => this._setLeftPanel(tab.dataset.leftTab));
    });

    this.root.querySelectorAll('[data-quick]').forEach((btn) => {
      btn.addEventListener('click', () => {
        const q = btn.dataset.quick;
        const map = {
          text: () => this.canvas.addText('Novo texto'),
          rect: () => this.canvas.addRect(),
          image: () => this.pickImage(),
          logo: () => this.canvas.addLogo(this.app.getAssetUrls().logo),
          group: () => this.canvas.groupSelected?.(),
          ungroup: () => this.canvas.ungroupSelected?.(),
          'align-center': () => this.canvas.alignSelected('center'),
          'flip-h': () => this.canvas.flipSelected?.('h'),
          'rot-p90': () => this.canvas.rotateSelected?.(90),
          'rot-m90': () => this.canvas.rotateSelected?.(-90),
          duplicate: () => this.canvas.duplicateSelected(),
          delete: () => this.canvas.deleteSelected(),
        };
        map[q]?.();
      });
    });

    this.root.querySelector('#ds-toggle-grid')?.addEventListener('change', (e) => {
      const g = this.canvas.layer?.findOne?.('.grid');
      if (g) { g.visible(!!e.target.checked); this.canvas.layer.batchDraw(); }
    });
    this.root.querySelector('#ds-toggle-safe')?.addEventListener('change', (e) => {
      const s = this.canvas.layer?.findOne?.('.safe-zone');
      if (s) { s.visible(!!e.target.checked); this.canvas.layer.batchDraw(); }
      this._syncStageMeta();
    });
    this.root.querySelector('#ds-toggle-guides')?.addEventListener('change', (e) => {
      this.canvas.smartGuidesEnabled = !!e.target.checked;
    });

    this.root.querySelectorAll('.designer-props-tab').forEach((tab) => {
      tab.addEventListener('click', () => {
        this.root.querySelectorAll('.designer-props-tab').forEach((t) => t.classList.toggle('is-active', t === tab));
        this.propsPanel?.setActiveTab?.(tab.dataset.propsTab);
      });
    });

    this.root.querySelector('#ds-master-cancel')?.addEventListener('click', () => {
      this.root.querySelector('#ds-master-modal')?.setAttribute('hidden', '');
    });

    this._renderBgQuickPanel();
    this._updateDesignerContext(null);
    this._syncZoomLabel();
    this._syncStageMeta();

    this._onVisChange = () => {
      this.canvas?.setVideoPreviewActive?.(!document.hidden);
    };
    document.addEventListener('visibilitychange', this._onVisChange);



    this._keyHandler = (e) => {

      if (!this.root.isConnected) return;

      if (e.target.matches('input, textarea, select')) return;

      if (e.key === 'Delete' || e.key === 'Backspace') {

        e.preventDefault();

        this.canvas.deleteSelected();

      }

      if ((e.ctrlKey || e.metaKey) && e.key === 'd') {

        e.preventDefault();

        this.canvas.duplicateSelected();

      }

      if ((e.ctrlKey || e.metaKey) && e.key === 'c' && !e.shiftKey) {
        e.preventDefault();
        this.canvas.copySelectedToClipboard?.();
        this.app.toast?.('Elemento copiado');
      }

      if ((e.ctrlKey || e.metaKey) && e.key === 'v' && !e.shiftKey) {
        e.preventDefault();
        if (this.canvas.selectedNode) {
          this.canvas.pasteClipboardNode?.() || void this._pasteFromOsClipboard?.();
        } else {
          void this._pasteFromOsClipboard?.();
        }
      }

      if ((e.ctrlKey || e.metaKey) && e.shiftKey && (e.key === 'C' || e.key === 'c')) {
        e.preventDefault();
        this.canvas.copyStyleSelected?.();
        this.app.toast?.('Estilo copiado');
      }

      if ((e.ctrlKey || e.metaKey) && e.shiftKey && (e.key === 'V' || e.key === 'v')) {
        e.preventDefault();
        if (this.canvas.pasteStyleSelected?.()) {
          this.propsPanel?.setNode(this.canvas.selectedNode);
          this.app.toast?.('Estilo aplicado');
        }
      }

      if ((e.ctrlKey || e.metaKey) && e.key === 's') {

        e.preventDefault();

        void this.savePrimaryAction();

      }

      if ((e.ctrlKey || e.metaKey) && e.key === 'g' && !e.shiftKey) {

        e.preventDefault();

        this.canvas.groupSelected?.();

      }

      if ((e.ctrlKey || e.metaKey) && e.key === 'g' && e.shiftKey) {

        e.preventDefault();

        this.canvas.ungroupSelected?.();

      }

      if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.key) && this.canvas.selectedNode) {

        e.preventDefault();

        const step = e.shiftKey ? 10 : 1;

        const node = this.canvas.selectedNode;

        if (e.key === 'ArrowUp') node.y(node.y() - step);

        if (e.key === 'ArrowDown') node.y(node.y() + step);

        if (e.key === 'ArrowLeft') node.x(node.x() - step);

        if (e.key === 'ArrowRight') node.x(node.x() + step);

        this.canvas.layer.batchDraw();

        this.persistCurrentSlide({ markDirty: false });

        this._markDirty();

      }

      if ((e.ctrlKey || e.metaKey) && e.key === 'z' && !e.shiftKey) {

        e.preventDefault();

        this.canvas.undo();

      }

      if ((e.ctrlKey || e.metaKey) && (e.key === 'y' || (e.key === 'z' && e.shiftKey))) {

        e.preventDefault();

        this.canvas.redo();

      }

    };

    document.addEventListener('keydown', this._keyHandler);

    this.root.querySelector('#ds-slide-title')?.addEventListener('input', (e) => {
      const title = e.target.value.trim();
      this.slides[this.slideIndex].title = title || `Slide ${this.slideIndex + 1}`;
      this.renderSlideTabs();
      this.persistCurrentSlide();
    });

    this.renderPresets();

    this.renderFontsPanel();

    this.applyPreset('blank', false);

    this.renderSlideTabs();

    this.syncSlideTitleInput();

    this.loadLibrary();
    this.renderSavedSlides?.();
    this._bindMediaCanvasDrop?.();

    const hint = this.root.querySelector('#designer-hint');

    if (hint && this._fonts.length) {

      hint.textContent += ` · ${this._fonts.length} fonte(s) em fonts/`;

    }

    engine._pushHistory();

    this._updateDirtyBadge();



    let resizeTimer = 0;
    this._resizeObs = new ResizeObserver(() => {
      if (resizeTimer) clearTimeout(resizeTimer);
      resizeTimer = setTimeout(() => {
        resizeTimer = 0;
        this.canvas?.resize?.();
      }, 120);
    });
    this._resizeObs.observe(canvasEl.parentElement);

  }
};
