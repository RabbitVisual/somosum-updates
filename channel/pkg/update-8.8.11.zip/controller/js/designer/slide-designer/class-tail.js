import { faBtnIcon, DS_ICONS as I } from '../fa-icon.js';
import { rawHtml, setHtml } from '../../core/render-engine/index.js';
import { dataPublicUrl } from '../../core/data-public-url.js';

export const slideDesignerTail = {
  _getBackground() {

    const eng = this._getEngine();

    return typeof eng?.getBackground === 'function' ? eng.getBackground() : null;

  },

  async reloadFonts() {
    const { resetFontsCache, loadCustomFonts, getCustomFontList } = await import('../../core/fonts.js');
    resetFontsCache();
    await loadCustomFonts({ injectFaces: true });
    this._fonts = getCustomFontList();
    this.propsPanel?.setFonts(this._fonts);
    this.renderFontsPanel();
    const hint = this.root.querySelector('#designer-hint');
    if (hint) {
      const base = 'Escolha um modelo · Fundos/gradientes no topo · Shift+clique multi-seleção · Del excluir · Ctrl+D duplicar';
      hint.textContent = this._fonts.length ? `${base} · ${this._fonts.length} fonte(s) em fonts/` : base;
    }
    this.app.toast?.(
      this._fonts.length ? `${this._fonts.length} fonte(s) carregada(s)` : 'Nenhuma fonte em fonts/ — adicione .ttf ou .otf',
      this._fonts.length ? 'success' : 'warn'
    );
  },

  pickImage() {

    if (!this._fileInput) {

      this._fileInput = document.createElement('input');

      this._fileInput.type = 'file';

      this._fileInput.accept = 'image/*';

      this._fileInput.hidden = true;

      this._fileInput.onchange = (e) => {

        const f = e.target.files?.[0];

        if (f) this.canvas.addImageFromFile(f);

        e.target.value = '';

      };

      document.body.appendChild(this._fileInput);

    }

    this._fileInput.click();

  },

  pickBackgroundImage(opts = {}) {
    if (!this._bgInput) {
      this._bgInput = document.createElement('input');
      this._bgInput.type = 'file';
      this._bgInput.accept = 'image/*';
      this._bgInput.hidden = true;
      document.body.appendChild(this._bgInput);
    }
    this._bgInput.onchange = (e) => {
      const f = e.target.files?.[0];
      if (!f) return;
      const reader = new FileReader();
      reader.onload = () => {
        this.canvas.setBackground({
          type: 'image',
          src: reader.result,
          fit: opts.fit || 'cover',
          dim: opts.dim || 0,
        });
        this.persistCurrentSlide();
        this.propsPanel?.setBackground(this.canvas.getBackground?.());
      };
      reader.readAsDataURL(f);
      e.target.value = '';
    };
    this._bgInput.click();
  },

  async pickBackgroundVideo(opts = {}) {
    try {
      const { resolveMediaSrc } = await import('../../core/media-url.js');
      const { dataPublicUrl } = await import('../../core/data-public-url.js');
      const res = await fetch('/api/data/media/index.json', { cache: 'no-store' });
      if (!res.ok) throw new Error('media');
      const data = await res.json();
      const list = data.media || data.items || [];
      const videos = list.filter((m) => {
        const cat = m.category || '';
        const isVideo = m.kind === 'video' || (m.mime || '').startsWith('video/');
        const isAnim = cat === 'fundo-animado' || cat === 'loop' || !!m.system;
        return isVideo && (isAnim || cat !== 'frame');
      }).slice(0, 48);
      if (!videos.length) {
        this.app.toast?.('Nenhum fundo animado na biblioteca — adicione vídeos em Mídia (Fundos animados).', 'warn');
        return;
      }
      const labels = videos.map((m, i) => `${i + 1}. ${m.name || m.fileName || m.id}`).join('\n');
      const pick = prompt(`Fundo animado — digite o número (1–${videos.length}):\n\n${labels}`, '1');
      if (pick == null) return;
      const idx = Math.max(1, Math.min(videos.length, Number(pick) || 1)) - 1;
      const choice = videos[idx];
      let src = resolveMediaSrc?.(choice) || choice.path || choice.src || '';
      if (src && !src.startsWith('http') && !src.startsWith('data:') && !src.startsWith('/')) {
        src = dataPublicUrl(String(src).replace(/^\/?data\//, ''));
      }
      if (!src) {
        this.app.toast?.('Não foi possível resolver o vídeo', 'warn');
        return;
      }
      this.canvas.setBackground({
        type: 'video',
        src,
        mediaId: choice.id || '',
        fit: opts.fit || 'cover',
        dim: opts.dim != null ? opts.dim : 0.35,
      });
      this.persistCurrentSlide();
      this.propsPanel?.setBackground(this.canvas.getBackground?.());
      this.app.toast?.(`Fundo animado: ${choice.name || choice.id}`, 'success');
    } catch {
      this.app.toast?.('Não foi possível abrir a biblioteca de vídeos', 'warn');
    }
  },

  async pickFromMediaLibrary() {
    try {
      const res = await fetch('/api/data/media/index.json', { cache: 'no-store' });
      if (!res.ok) throw new Error('media');
      const data = await res.json();
      const images = (data.media || data.items || []).filter((m) =>
        (m.kind === 'image' || (m.mime || '').startsWith('image/')) && (m.path || m.src)
      ).slice(0, 40);
      if (!images.length) {
        this.app.toast?.('Nenhuma imagem na biblioteca de mídia — use Imagem ou adicione em Mídia.', 'warn');
        this.pickImage();
        return;
      }
      const choice = images[0];
      const src = choice.path?.startsWith('http') || choice.path?.startsWith('data:')
        ? choice.path
        : dataPublicUrl(String(choice.path || '').replace(/^\/?data\//, ''));
      await this.canvas.addImageFromUrl(src);
      this.app.toast?.(`Imagem: ${choice.name || 'mídia'}`, 'success');
    } catch {
      this.app.toast?.('Não foi possível abrir a biblioteca — escolhendo arquivo…', 'warn');
      this.pickImage();
    }
  },

  pickFrameMask() {
    if (!this._frameInput) {
      this._frameInput = document.createElement('input');
      this._frameInput.type = 'file';
      this._frameInput.accept = 'image/png,image/webp,image/jpeg';
      this._frameInput.hidden = true;
      this._frameInput.onchange = (e) => {
        const f = e.target.files?.[0];
        if (!f) return;
        const reader = new FileReader();
        reader.onload = () => {
          this.canvas.addFrame({ clipShape: 'rect', maskSrc: reader.result });
        };
        reader.readAsDataURL(f);
        e.target.value = '';
      };
      document.body.appendChild(this._frameInput);
    }
    this._frameInput.click();
  },

  _applyFrameMaskOverlay(group, maskSrc) {
    if (!group || !maskSrc) return;
    group.findOne('.frame-border')?.destroy();
    if (this.canvas?._attachFrameMaskImage) {
      this.canvas._attachFrameMaskImage(group, maskSrc);
      return;
    }
    group.findOne('.frame-mask')?.destroy();
    const w = group.attrs.width || 400;
    const h = group.attrs.height || 400;
    group.attrs.maskSrc = maskSrc;
    const img = new Image();
    img.onload = () => {
      const K = window.Konva;
      if (!K) return;
      const mask = new K.Image({
        x: 0,
        y: 0,
        width: w,
        height: h,
        image: img,
        listening: false,
        name: 'frame-mask',
        globalCompositeOperation: 'destination-in',
      });
      group.add(mask);
      this.canvas?._restackFrameLayers?.(group);
      this.canvas?.layer?.batchDraw();
    };
    img.src = maskSrc;
  },

  _bindMediaCanvasDrop() {
    const wrap = this.root?.querySelector('#designer-canvas-wrap');
    if (!wrap || wrap.dataset.mediaDropBound) return;
    wrap.dataset.mediaDropBound = '1';
    wrap.addEventListener('dragover', (e) => {
      if (![...e.dataTransfer.types].includes('application/x-somosum-media')) return;
      e.preventDefault();
      e.dataTransfer.dropEffect = 'copy';
      wrap.classList.add('is-media-drop');
    });
    wrap.addEventListener('dragleave', () => wrap.classList.remove('is-media-drop'));
    wrap.addEventListener('drop', (e) => {
      wrap.classList.remove('is-media-drop');
      const raw = e.dataTransfer.getData('application/x-somosum-media');
      if (!raw) return;
      e.preventDefault();
      let payload;
      try { payload = JSON.parse(raw); } catch { return; }
      const { src, mediaId, kind } = payload || {};
      if (!src) return;

      // Hit-test Konva: soltar sobre moldura / card existente
      const stage = this.canvas?.stage;
      if (stage) {
        try { stage.setPointersPositions(e); } catch { /* ignore */ }
        const pos = stage.getPointerPosition();
        let shape = pos ? stage.getIntersection(pos) : null;
        if (!shape) {
          const rect = stage.container().getBoundingClientRect();
          const scale = stage.scaleX() || 1;
          const x = (e.clientX - rect.left) / scale;
          const y = (e.clientY - rect.top) / scale;
          shape = stage.getIntersection({ x, y });
        }
        let node = shape;
        while (node && node !== stage) {
          if (node.name?.() === 'frame' || node.name?.() === 'photo-card') {
            this.canvas.selectNode(node);
            this.fillSelectedFrameFromMedia(src, mediaId || '', kind || '');
            this.propsPanel?.setNode(node);
            return;
          }
          node = node.getParent?.();
        }
      }
      this.applyMediaToCanvas(src, mediaId || '', kind || '');
    });
  },

  syncSlideTitleInput() {
    const input = this.root?.querySelector('#ds-slide-title');
    if (!input) return;
    const slide = this.slides[this.slideIndex];
    input.value = slide?.title && !slide.title.startsWith('Slide ') ? slide.title : (slide?.title || '');
  },

  _setLeftPanel(id) {
    if (!id || !this.root) return;
    this.root.querySelectorAll('.designer-rail-btn').forEach((t) => {
      t.classList.toggle('is-active', t.dataset.leftTab === id);
    });
    this.root.querySelectorAll('.designer-left-panel').forEach((p) => {
      p.classList.toggle('is-active', p.dataset.leftPanel === id);
    });
    if (id === 'background') {
      this.canvas?.selectNode?.(null);
      this._updateDesignerContext(null);
      this.propsPanel?.setBackground(this._getBackground());
      this.propsPanel?.setNode(null);
    }
    if (id === 'saved') this.renderSavedSlides?.();
    if (id === 'media') this.loadLibrary?.();
  },

  _updateDesignerContext(node) {
    const ctx = this.root?.querySelector('#ds-context');
    const head = this.root?.querySelector('#ds-props-head');
    const lead = this.root?.querySelector('#ds-props-lead');
    const mode = node ? 'el' : 'bg';
    ctx?.querySelectorAll('.designer-ctx-pill').forEach((p) => {
      const on = p.dataset.ctx === mode || (mode === 'bg' && p.dataset.ctx === 'slide');
      p.classList.toggle('is-active', on);
    });
    if (head) head.textContent = node ? 'Propriedades do elemento' : 'Fundo & slide';
    if (lead) {
      lead.textContent = node
        ? (node.name?.() === 'photo-card'
          ? 'Card pregador: edite nome, foto e tamanhos aqui. Arraste a foto da Mídia sobre o círculo.'
          : node.name?.() === 'frame'
            ? 'Moldura: solte a foto da Mídia sobre a máscara. Ajuste zoom/posição em Foto.'
            : 'Posição, tipografia, sombra e opacidade. Use Alinhar para encaixar no quadro 16:9.')
        : 'Sem seleção: edite o fundo. Clique no texto/forma no canvas (ou na lista Camadas) para abrir Design / Posição / Efeitos.';
    }
    this.root?.querySelectorAll('.designer-props-tab').forEach((tab) => {
      const needsNode = tab.dataset.propsTab === 'position' || tab.dataset.propsTab === 'effects';
      tab.disabled = !!(needsNode && !node);
      tab.classList.toggle('is-disabled', !!(needsNode && !node));
      if (!node && tab.dataset.propsTab !== 'design') {
        tab.classList.remove('is-active');
      }
      if (!node && tab.dataset.propsTab === 'design') {
        tab.classList.add('is-active');
      }
    });
    const n = (this.canvas?.selectedNodes?.length || (node ? 1 : 0));
    const meta = this.root?.querySelector('#ds-stage-meta');
    if (meta && n > 0) {
      meta.textContent = n > 1 ? `${n} elementos selecionados · Shift+clique para ajustar` : '1 elemento · Arraste com guias inteligentes';
    } else {
      this._syncStageMeta();
    }
  },

  _syncZoomLabel() {
    const el = this.root?.querySelector('#ds-zoom-label');
    if (!el || !this.canvas) return;
    const z = Math.round((this.canvas._zoomFactor || 1) * 100);
    el.textContent = `${z}%`;
  },

  _syncStageMeta() {
    const meta = this.root?.querySelector('#ds-stage-meta');
    if (!meta) return;
    const safeOn = this.root.querySelector('#ds-toggle-safe')?.checked !== false;
    meta.textContent = safeOn
      ? '1920×1080 · Área segura · Fundo atrás · Elementos na frente'
      : '1920×1080 · Área segura oculta';
  },

  _renderBgQuickPanel() {
    const host = this.root?.querySelector('#designer-bg-quick');
    if (!host) return;
    const presets = [
      { id: 'dark', label: 'Escuro', css: 'linear-gradient(180deg,#0a0a0a,#1a1a1a)' },
      { id: 'gold', label: 'Ouro', css: 'linear-gradient(160deg,#1a1510,#3d2e18)' },
      { id: 'theme', label: 'Tema', css: 'linear-gradient(200deg,#0c0a14,#1a1530)' },
      { id: 'bible', label: 'Bíblia', css: 'linear-gradient(190deg,#0a1018,#142030)' },
      { id: 'communion', label: 'Ceia', css: 'linear-gradient(150deg,#080604,#2a1810)' },
    ];
    setHtml(host, rawHtml(`
      <div class="designer-bg-quick-grid">
        ${presets.map((p) => `
          <button type="button" class="designer-bg-card" data-bg-preset="${p.id}" title="${p.label}">
            <span class="designer-bg-card-swatch" style="background:${p.css}"></span>
            <span>${p.label}</span>
          </button>`).join('')}
      </div>
      <div class="designer-bg-quick-actions">
        <button type="button" class="btn btn-secondary btn-sm" data-bg-act="image">Imagem de fundo</button>
        <button type="button" class="btn btn-secondary btn-sm" data-bg-act="video">Fundo animado</button>
        <button type="button" class="btn btn-secondary btn-sm" data-bg-act="dim">+ Dim 35%</button>
        <button type="button" class="btn btn-secondary btn-sm" data-bg-act="clear-dim">Sem dim</button>
      </div>`));
    host.querySelectorAll('[data-bg-preset]').forEach((btn) => {
      btn.addEventListener('click', () => {
        this.canvas.setBackground({ type: 'gradient', preset: btn.dataset.bgPreset });
        this.persistCurrentSlide();
        this.propsPanel?.setBackground(this.canvas.getBackground?.());
        this._setLeftPanel('background');
        this.root.classList.add('designer-flash-bg');
        setTimeout(() => this.root.classList.remove('designer-flash-bg'), 450);
      });
    });
    host.querySelector('[data-bg-act="image"]')?.addEventListener('click', () => this.pickBackgroundImage({}));
    host.querySelector('[data-bg-act="video"]')?.addEventListener('click', () => {
      void this.pickBackgroundVideo({ dim: 0.35 });
    });
    host.querySelector('[data-bg-act="dim"]')?.addEventListener('click', () => {
      const bg = this.canvas.getBackground?.() || { type: 'gradient', preset: 'dark' };
      this.canvas.setBackground({ ...bg, dim: 0.35 });
      this.persistCurrentSlide();
      this.propsPanel?.setBackground(this.canvas.getBackground?.());
    });
    host.querySelector('[data-bg-act="clear-dim"]')?.addEventListener('click', () => {
      const bg = this.canvas.getBackground?.() || { type: 'gradient', preset: 'dark' };
      this.canvas.setBackground({ ...bg, dim: 0 });
      this.persistCurrentSlide();
      this.propsPanel?.setBackground(this.canvas.getBackground?.());
    });
  },

  async _insertBlock(blockId) {
    try {
      const { insertComponentBlock } = await import('../component-blocks.js');
      const ok = insertComponentBlock(this.canvas, blockId);
      if (ok) this.persistCurrentSlide?.();
      this.app.toast?.(ok ? 'Bloco inserido' : 'Não foi possível inserir o bloco', ok ? 'success' : 'warn');
    } catch (err) {
      this.app.toast?.(`Bloco: ${err.message || err}`, 'warn');
    }
  },

  async _applyMasterSlide() {
    try {
      const { MasterSlides } = await import('../master-slides.js');
      const list = await MasterSlides.list();
      if (!list.length) {
        this.app.toast?.('Nenhum master em data/templates/index.json', 'warn');
        return;
      }
      const modal = this.root.querySelector('#ds-master-modal');
      const host = this.root.querySelector('#ds-master-list');
      if (!modal || !host) return;
      setHtml(host, rawHtml(list.map((m, i) => `
        <button type="button" class="designer-master-pick" data-master-idx="${i}">
          ${faBtnIcon(I.master)} <span>${m.name || `Master ${i + 1}`}</span>
        </button>`).join('')));
      modal.removeAttribute('hidden');
      host.querySelectorAll('[data-master-idx]').forEach((btn) => {
        btn.onclick = async () => {
          const master = list[Number(btn.dataset.masterIdx) || 0];
          const ok = await MasterSlides.apply(this.canvas, master);
          modal.setAttribute('hidden', '');
          if (ok) {
            this.persistCurrentSlide({ markDirty: false });
            this._markDirty();
          }
          this.app.toast?.(ok ? `Master “${master.name}” aplicado` : 'Falha ao aplicar master', ok ? 'success' : 'warn');
        };
      });
    } catch (err) {
      this.app.toast?.(`Master: ${err.message || err}`, 'warn');
    }
  },

  destroy() {
    clearTimeout(this._autosaveTimer);
    this._autosaveTimer = null;
    try { this._resizeObs?.disconnect?.(); } catch { /* ignore */ }
    this._resizeObs = null;
    try { this._ctxMenuUnbind?.(); } catch { /* ignore */ }
    this._ctxMenuUnbind = null;
    try { this.canvas?.destroy?.(); } catch { /* ignore */ }
    this.canvas = null;
    this._engine = null;
    this.layerPanel = null;
    this.propsPanel = null;
    this._fileInput?.remove?.();
    this._bgInput?.remove?.();
    this._frameInput?.remove?.();
    this._fileInput = null;
    this._bgInput = null;
    this._frameInput = null;
    if (this.root) {
      try { this.root.replaceChildren(); } catch { this.root.innerHTML = ''; }
    }
  },
};
