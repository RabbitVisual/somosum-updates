/** Template gallery, preset picker, and related designer panel UI. */

import { listDesignerTemplates, saveDesignerTemplate, loadDesignerTemplate, deleteDesignerTemplate } from './template-library.js';
import { BUILTIN_FRAME_MASKS } from './frame-utils.js';
import { buildDesignerPreset, listDesignerPresets } from './designer-presets.js';
import { preloadFontsForCanvas, SYSTEM_FONT_STACKS, getCustomFontList } from '../core/fonts.js';
import { faIconRaw, faBtnIcon, faIcon } from './fa-icon.js';

function esc(t) {
  const d = document.createElement('div');
  d.textContent = t ?? '';
  return d.innerHTML;
}

function escAttr(t) {
  return esc(t).replace(/"/g, '&quot;');
}

const PRESET_GROUP_LABELS = {
  base: 'Base',
  'boas-vindas': 'Boas-vindas',
  culto: 'Culto',
  exegese: 'Exegese / Citações',
};

export const designerTemplatesUIMethods = {

  renderPresets() {
    const el = this.root.querySelector('#designer-presets');
    if (!el) return;

    const current = this.slides[this.slideIndex]?.templateId || 'blank';
    const presets = listDesignerPresets();
    const groups = [...new Set(presets.map((p) => p.group || 'base'))];

    el.innerHTML = groups.map((group) => {
      const items = presets.filter((p) => (p.group || 'base') === group);
      const label = PRESET_GROUP_LABELS[group] || group;
      return `
        <div class="designer-preset-group designer-preset-group--${group}">
          <div class="designer-preset-group-label">${label}</div>
          <div class="designer-preset-group-row">
            ${items.map((p) => `<button type="button" class="designer-preset-btn${p.id === current ? ' is-active' : ''}" data-preset="${p.id}" title="${p.label}">
              <span class="designer-preset-icon">${faIconRaw(p.icon, 'su-fa')}</span>
              <span class="designer-preset-label">${p.label}</span>
            </button>`).join('')}
          </div>
        </div>`;
    }).join('');

    el.querySelectorAll('.designer-preset-btn').forEach((btn) => {
      btn.onclick = () => {
        if (btn.dataset.preset === current && this.slides[this.slideIndex]?.layers?.length) {
          if (!confirm('Substituir o slide atual pelo modelo? As alterações serão perdidas.')) return;
        }
        this.applyPreset(btn.dataset.preset);
      };
    });
  },

  applyPreset(presetId, confirmEmpty = true) {
    const eng = this._getEngine();
    if (!eng?.layer) {
      this.app?.toast?.('Canvas nao iniciado — abra o Designer novamente', 'error');
      return;
    }

    const assets = this.app.getAssetUrls?.() || {};
    const church = this.app.prefs?.church || {};
    const preset = buildDesignerPreset(presetId, assets, church);

    if (confirmEmpty && this.slides[this.slideIndex]?.layers?.length > 2) {
      if (!confirm(`Carregar modelo "${preset.title}"? O conteúdo atual será substituído.`)) return;
    }

    if (!this._loadPresetOntoCanvas(preset)) {
      this.app?.toast?.('Falha ao carregar modelo — pressione Ctrl+F5', 'error');
      return;
    }

    const families = (preset.layers || []).map((l) => l.fontFamily).filter(Boolean);
    void preloadFontsForCanvas(families).then(() => {
      const engAfter = this._getEngine();
      engAfter?.scheduleFitTextBoxes?.();
      engAfter?.layer?.batchDraw?.();
    });

    this.slides[this.slideIndex] = {
      ...preset,
      title: preset.title,
      text: preset.text || '',
      templateId: presetId,
      designer: { version: 3, width: 1920, height: 1080 },
    };

    // Garantir frame 16:9 após carregar modelo (evita Bem-vindo “comprimido”)
    try {
      const eng = this._getEngine();
      eng?.fitToContainer?.();
      eng?.scheduleFitTextBoxes?.();
      eng?.stage?.batchDraw?.();
    } catch { /* ignore */ }

    // Modelo embutido != template salvo em disco — nunca sobrescrever ds-* por engano
    this._editingTemplateId = null;
    this._syncSaveButtons?.();

    this.propsPanel.setBackground(preset.background);
    this.propsPanel.setNode(null);
    this.renderPresets();
    this.renderSlideTabs();
    this.refreshLayers();
    this.app.toast?.(`Modelo: ${preset.title}`);
  },

  renderFontsPanel() {
    const el = this.root.querySelector('#designer-fonts');
    if (!el) return;

    const custom = this._fonts?.length ? this._fonts : getCustomFontList();
    const system = SYSTEM_FONT_STACKS.filter((f) => !custom.includes(f));

    if (!custom.length && !system.length) {
      el.innerHTML = '<p class="designer-empty">Nenhuma fonte. Coloque .ttf/.otf/.woff2 em <code>fonts/</code> e clique Recarregar.</p>';
      return;
    }

    const pickBtn = (f, isCustom) =>
      `<button type="button" class="designer-font-pick${isCustom ? ' is-custom' : ''}" data-font="${escAttr(f)}" style="font-family:'${escAttr(f)}',sans-serif" title="Aplicar no texto selecionado">
        <span class="designer-font-pick__name">${esc(f)}</span>
        <span class="designer-font-pick__sample">Aa Bb 123</span>
      </button>`;

    el.innerHTML = `
      <div class="designer-fonts-head">
        <p class="designer-fonts-lead"><strong>${custom.length}</strong> família(s) da pasta <code>fonts/</code>${custom.length ? '' : ' — pasta vazia ou não carregada'}.</p>
        <button type="button" class="btn btn-secondary btn-sm" id="ds-fonts-reload">Recarregar fontes</button>
      </div>
      ${custom.length ? `<div class="designer-fonts-section"><h4>Pasta fonts/</h4><div class="designer-fonts-grid">${custom.map((f) => pickBtn(f, true)).join('')}</div></div>` : ''}
      <div class="designer-fonts-section"><h4>Sistema Windows</h4><div class="designer-fonts-grid">${system.map((f) => pickBtn(f, false)).join('')}</div></div>
    `;

    el.querySelector('#ds-fonts-reload')?.addEventListener('click', async () => {
      const { resetFontsCache, loadCustomFonts, getCustomFontList: list } = await import('../core/fonts.js');
      resetFontsCache();
      this._fonts = await loadCustomFonts({ injectFaces: true, force: true });
      this.renderFontsPanel();
      this.app?.toast?.(`${list().length} fontes da pasta carregadas`, 'ok');
    });

    el.querySelectorAll('.designer-font-pick').forEach((btn) => {
      btn.onclick = async () => {
        const node = this.canvas?.selectedNode;
        if (!node || node.getClassName?.() !== 'Text') {
          this.app.toast?.('Selecione um texto no canvas primeiro', 'warn');
          return;
        }
        const fam = btn.dataset.font;
        await preloadFontsForCanvas([fam]);
        node.fontFamily(fam);
        this.canvas.layer.batchDraw();
        this.propsPanel?.setNode(node);
        this.persistCurrentSlide();
        this.app.toast?.(`Fonte: ${fam}`);
      };
    });
  },

  fillSelectedFrameFromMedia(src, mediaId = '', kind = '') {
    const node = this.canvas.selectedNode;
    if (!node || !src) {
      this.app.toast?.('Selecione uma moldura no canvas ou arraste a mídia para cima dela', 'warn');
      return;
    }
    if (node.name?.() === 'photo-card') {
      this.canvas.setPhotoCardFill(node, src, { mediaId }).then?.(() => {
        this.propsPanel?.setNode(node);
      });
      this.app.toast('Foto aplicada no card do pregador');
      return;
    }
    if (node.name?.() === 'frame') {
      const isVideo = kind === 'video' || /\.(mp4|webm|mov|m4v)(\?|$)/i.test(String(src));
      this.canvas.setFrameFill(node, src, { mediaId, kind: isVideo ? 'video' : 'image' }).then?.(() => {
        this.propsPanel?.setNode(node);
      });
      this.app.toast(isVideo ? 'Vídeo aplicado na moldura' : 'Imagem aplicada na moldura');
    }
  },

  mediaSrcOf(m) {
    return m?.src || m?.dataUrl || m?.path || '';
  },

  applyMediaToCanvas(src, mediaId = '', kind = '') {
    if (!src) {
      this.app.toast?.('Arquivo de mídia sem caminho — reimporte na Biblioteca de mídia', 'warn');
      return;
    }
    const sel = this.canvas?.selectedNode;
    const overFrame = sel?.name?.() === 'frame' || sel?.name?.() === 'photo-card';
    if (overFrame) {
      this.fillSelectedFrameFromMedia(src, mediaId, kind);
      return;
    }
    if (kind === 'video' || /\.(mp4|webm|mov|m4v)(\?|$)/i.test(src)) {
      // Sem moldura selecionada: adiciona moldura e preenche com o vídeo
      const frame = this.canvas.addFrame({
        width: 720,
        height: 405,
        clipShape: 'rounded',
        cornerRadius: 16,
      });
      this.canvas.setFrameFill(frame, src, { mediaId, kind: 'video' });
      this.app.toast('Moldura com vídeo adicionada — ajuste zoom/posição nas propriedades');
      return;
    }
    this.canvas.addImageFromUrl(src);
  },

  async renderSavedSlides() {
    const el = this.root.querySelector('#designer-saved');
    if (!el) return;
    const templates = await listDesignerTemplates();
    const q = (this._savedSearch || '').trim().toLowerCase();
    const list = q
      ? templates.filter((t) => (t.name || '').toLowerCase().includes(q))
      : templates;

    el.innerHTML = `
      <div class="designer-saved-toolbar">
        <input type="search" class="designer-tpl-search" id="ds-saved-search"
          placeholder="Buscar slide salvo…" value="${escAttr(this._savedSearch || '')}" />
        <p class="designer-panel-lead">Slides salvos com <strong>Salvar</strong> / <strong>Salvar slide</strong>. Abra, edite, projete ou coloque na ordem.</p>
      </div>
      ${list.length ? `<div class="designer-saved-gallery">${list.map((t) => {
        const initial = esc((t.name || 'S').charAt(0).toUpperCase());
        const date = t.updatedAt ? new Date(t.updatedAt).toLocaleDateString('pt-BR') : '';
        const active = this._editingTemplateId === t.id ? ' is-active' : '';
        return `<article class="designer-tpl-card designer-saved-card${active}" data-tpl-id="${escAttr(t.id)}">
          <div class="designer-tpl-thumb" aria-hidden="true">${initial}</div>
          <div class="designer-tpl-meta">
            <strong class="designer-tpl-name">${esc(t.name || 'Sem nome')}</strong>
            <span class="designer-tpl-date">${esc(date)}</span>
          </div>
          <div class="designer-tpl-actions">
            <button type="button" class="btn btn-secondary btn-sm" data-tpl-action="open">Editar</button>
            <button type="button" class="btn btn-live btn-sm" data-tpl-action="project">Projetar</button>
            <button type="button" class="btn btn-primary btn-sm" data-tpl-action="program">+ Ordem</button>
            <button type="button" class="btn btn-secondary btn-sm designer-tpl-del" data-tpl-action="delete" title="Excluir">Excluir</button>
          </div>
        </article>`;
      }).join('')}</div>` : `<div class="designer-empty">Nenhum slide salvo ainda.<br/>Crie no canvas e clique em <strong>Salvar slide</strong>.</div>`}`;

    el.querySelector('#ds-saved-search')?.addEventListener('input', (e) => {
      this._savedSearch = e.target.value;
      this.renderSavedSlides();
    });

    el.querySelectorAll('.designer-saved-card').forEach((card) => {
      const id = card.dataset.tplId;
      card.querySelector('[data-tpl-action="open"]')?.addEventListener('click', async () => {
        await this.loadTemplate(id);
        this._setLeftPanel?.('saved');
      });
      card.querySelector('[data-tpl-action="project"]')?.addEventListener('click', async () => {
        await this.loadTemplate(id);
        await this.canvas?.waitForMediaReady?.(8000);
        await this.projectCurrent?.();
      });
      card.querySelector('[data-tpl-action="program"]')?.addEventListener('click', async () => {
        await this.loadTemplate(id);
        await this.canvas?.waitForMediaReady?.(8000);
        await this.addToProgram?.();
      });
      card.querySelector('[data-tpl-action="delete"]')?.addEventListener('click', async () => {
        if (!confirm(`Excluir o slide «${card.querySelector('.designer-tpl-name')?.textContent || id}»?`)) return;
        await deleteDesignerTemplate(id);
        if (this._editingTemplateId === id) this._editingTemplateId = null;
        this.app.toast('Slide excluído');
        this.renderSavedSlides();
      });
    });
  },

  async loadLibrary() {
    const lib = this.root.querySelector('#designer-library');
    if (!lib) return;

    try {
      const { getAllMedia } = await import('../core/store.js');
      this.app.mediaList = await getAllMedia();
    } catch {
      /* mantém lista atual */
    }

    const assets = this.app.getAssetUrls?.() || {};
    const stockImages = [
      { label: 'Logo da igreja', src: assets.logo },
      { label: 'Frente da igreja', src: assets.welcomeBg },
    ].filter((i) => i.src);

    const myMedia = (this.app.mediaList || []).filter((m) => {
      const kind = m.kind || '';
      const isImg = kind === 'image' || (m.mime || '').startsWith('image/');
      const isVid = kind === 'video' || (m.mime || '').startsWith('video/');
      return (isImg || isVid) && m.category !== 'frame' && this.mediaSrcOf(m);
    });
    const frames = (this.app.mediaList || []).filter((m) => m.category === 'frame' && this.mediaSrcOf(m));

    let html = `
      <p class="designer-panel-lead">Clique ou <strong>arraste</strong> para o canvas / moldura. Vídeos entram na moldura e dão para reposicionar.</p>
      <div class="designer-lib-section"><div class="designer-lib-sub">Imagens do SOMOSUM</div>`;
    html += stockImages.map((i) =>
      `<button type="button" class="designer-lib-item designer-lib-img" draggable="true" data-src="${escAttr(i.src)}" data-kind="image">${faIcon('image', 'su-fa su-fa--sm')} ${esc(i.label)}</button>`
    ).join('');
    html += '</div>';

    html += '<div class="designer-lib-section"><div class="designer-lib-sub">Molduras prontas</div>';
    html += BUILTIN_FRAME_MASKS.map((f) =>
      `<button type="button" class="designer-lib-item designer-lib-builtin-frame" data-shape="${escAttr(f.clipShape)}" data-radius="${f.cornerRadius || 24}" data-w="${f.width || 400}" data-h="${f.height || 400}">${faIcon('frame', 'su-fa su-fa--sm')} ${esc(f.label)}</button>`
    ).join('');
    html += '</div>';

    if (myMedia.length) {
      html += `<div class="designer-lib-section"><div class="designer-lib-sub">Minha mídia (${myMedia.length})</div>`;
      html += myMedia.slice(0, 64).map((m) => {
        const src = this.mediaSrcOf(m);
        const isVid = m.kind === 'video' || (m.mime || '').startsWith('video/') || /\.(mp4|webm|mov|m4v)(\?|$)/i.test(src);
        return `<button type="button" class="designer-lib-item designer-lib-media" draggable="true"
          data-src="${escAttr(src)}" data-media-id="${escAttr(m.id)}" data-kind="${isVid ? 'video' : 'image'}"
          title="${escAttr(isVid ? 'Vídeo — arraste para moldura' : 'Imagem — clique ou arraste')}">
          ${faIcon(isVid ? 'photo-film' : 'image', 'su-fa su-fa--sm')} ${esc(m.name || m.fileName || 'Mídia')}
          ${isVid ? '<span class="designer-lib-badge">Vídeo</span>' : ''}
        </button>`;
      }).join('');
      html += '</div>';
    } else {
      html += '<div class="designer-lib-section"><div class="designer-empty">Nenhuma mídia em system/media. Importe pela aba Mídia do Controle.</div></div>';
    }

    if (frames.length) {
      html += `<div class="designer-lib-section"><div class="designer-lib-sub">Molduras PNG (${frames.length})</div>`;
      html += frames.map((m) =>
        `<button type="button" class="designer-lib-item designer-lib-frame" data-src="${escAttr(this.mediaSrcOf(m))}">${faIcon('frame', 'su-fa su-fa--sm')} ${esc(m.name)}</button>`
      ).join('');
      html += '</div>';
    }

    html += `<p class="designer-panel-note">Slides salvos ficam na aba <strong>Slides salvos</strong> (não em Modelos).</p>`;
    lib.innerHTML = html;

    const bindDrag = (btn) => {
      btn.addEventListener('dragstart', (e) => {
        e.dataTransfer.setData('application/x-somosum-media', JSON.stringify({
          src: btn.dataset.src,
          mediaId: btn.dataset.mediaId || '',
          kind: btn.dataset.kind || 'image',
        }));
        e.dataTransfer.effectAllowed = 'copy';
        btn.classList.add('is-dragging');
      });
      btn.addEventListener('dragend', () => btn.classList.remove('is-dragging'));
    };

    lib.querySelectorAll('.designer-lib-img').forEach((btn) => {
      bindDrag(btn);
      btn.onclick = () => this.applyMediaToCanvas(btn.dataset.src, '', 'image');
    });

    lib.querySelectorAll('.designer-lib-media').forEach((btn) => {
      bindDrag(btn);
      btn.onclick = () => this.applyMediaToCanvas(btn.dataset.src, btn.dataset.mediaId, btn.dataset.kind);
    });

    lib.querySelectorAll('.designer-lib-frame').forEach((btn) => {
      btn.onclick = () => this.canvas.addFrame({ clipShape: 'rect', maskSrc: btn.dataset.src });
    });

    lib.querySelectorAll('.designer-lib-builtin-frame').forEach((btn) => {
      btn.onclick = () => this.canvas.addFrame({
        clipShape: btn.dataset.shape,
        cornerRadius: Number(btn.dataset.radius) || 24,
        width: Number(btn.dataset.w) || 400,
        height: Number(btn.dataset.h) || 400,
      });
    });
  },

  async loadTemplate(id) {
    const slide = await loadDesignerTemplate(id);
    if (!slide) {
      this.app.toast('Template nao encontrado — verifique se o servidor esta ativo', 'warn');
      return;
    }

    this.slides[this.slideIndex] = { ...slide, templateId: slide.templateId || id };
    this._editingTemplateId = id;
    this._loadSlideOntoCanvas(this.slides[this.slideIndex]);
    this.propsPanel.setBackground(slide.background || this._getBackground());
    this.renderPresets();
    this.renderSlideTabs();
    this.syncSlideTitleInput();
    this._syncSaveButtons?.();
    this.app.toast('Template carregado para edicao');
    this._setLeftPanel?.('saved');
    this.renderSavedSlides?.();
  },

  async saveTemplate() {
    if (!(await this._gateSafeZone?.())) return;
    await this.canvas?.waitForMediaReady?.(8000);
    this.persistCurrentSlide({ includePreview: true });

    const current = this.slides[this.slideIndex];
    const defaultName = current?.title || 'Meu slide';
    // Presets embutidos (welcome, blank, etc.) nunca atualizam um ds-* existente
    const canUpdate = !!this._editingTemplateId;

    const name = prompt(
      canUpdate ? 'Atualizar nome do slide salvo:' : 'Salvar slide (nome):',
      defaultName,
    );

    if (!name) return;

    try {
      const wasUpdate = canUpdate;
      const id = await saveDesignerTemplate(name, current, canUpdate ? this._editingTemplateId : null);
      this._editingTemplateId = id;
      this.slides[this.slideIndex].title = name;
      this.syncSlideTitleInput();
      this.renderSlideTabs();
      this._syncSaveButtons?.();
      this.app.toast(wasUpdate ? `Slide «${name}» atualizado` : `Slide «${name}» salvo — veja em Slides salvos`);
      this._setLeftPanel?.('saved');
      await this.renderSavedSlides?.();
      await this.loadLibrary();
    } catch (err) {
      console.error(err);
      this.app.toast('Falha ao salvar slide', 'error');
    }
  },

  renderSlideTabs() {
    const el = this.root.querySelector('#designer-slides');
    if (!el) return;

    el.innerHTML = this.slides
      .map((s, i) => {
        const label = esc(s.title || `Slide ${i + 1}`);
        const canDelete = this.slides.length > 1;
        return `<div class="designer-slide-tab-wrap${i === this.slideIndex ? ' is-active' : ''}" draggable="true" data-idx="${i}">
          <button type="button" class="designer-slide-tab" data-idx="${i}" title="${label}">
            <span class="ds-tab-num">${i + 1}</span>
            <span class="ds-tab-label">${label}</span>
          </button>
          <span class="designer-slide-tab-actions">
            <button type="button" class="ds-tab-move btn-icon" data-move="${i}" data-dir="-1" title="Mover para esquerda" ${i === 0 ? 'disabled' : ''}>${faIcon('prev')}</button>
            <button type="button" class="ds-tab-move btn-icon" data-move="${i}" data-dir="1" title="Mover para direita" ${i === this.slides.length - 1 ? 'disabled' : ''}>${faIcon('next')}</button>
            <button type="button" class="ds-tab-dup btn-icon" data-dup="${i}" title="Duplicar slide">⧉</button>
            ${canDelete ? `<button type="button" class="ds-tab-del" data-del="${i}" title="Excluir slide">×</button>` : ''}
          </span>
        </div>`;
      })
      .join('') + '<button type="button" class="designer-slide-tab designer-slide-add" id="ds-slide-add" title="Novo slide">+</button>';

    el.querySelectorAll('.designer-slide-tab[data-idx]').forEach((btn) => {
      btn.onclick = () => {
        this.persistCurrentSlide();
        this.slideIndex = Number(btn.dataset.idx);
        this._loadSlideOntoCanvas(this.slides[this.slideIndex]);
        this.propsPanel.setBackground(this.slides[this.slideIndex].background || this._getBackground());
        this.renderPresets();
        this.renderSlideTabs();
        this.syncSlideTitleInput();
        this.refreshLayers();
      };
    });

    el.querySelectorAll('.ds-tab-del').forEach((btn) => {
      btn.onclick = (e) => {
        e.stopPropagation();
        const idx = Number(btn.dataset.del);
        if (this.slides.length <= 1) return;
        if (!confirm(`Excluir "${this.slides[idx]?.title || `Slide ${idx + 1}`}"?`)) return;
        this.slides.splice(idx, 1);
        if (this.slideIndex >= this.slides.length) this.slideIndex = this.slides.length - 1;
        if (this.slideIndex === idx || this.slideIndex > idx) {
          this._loadSlideOntoCanvas(this.slides[this.slideIndex]);
        }
        this.renderSlideTabs();
        this.syncSlideTitleInput();
        this.refreshLayers();
      };
    });

    el.querySelectorAll('.ds-tab-dup').forEach((btn) => {
      btn.onclick = (e) => {
        e.stopPropagation();
        const idx = Number(btn.dataset.dup);
        this.persistCurrentSlide();
        const src = this.slides[idx];
        if (!src) return;
        const copy = JSON.parse(JSON.stringify(src));
        copy.title = `${src.title || `Slide ${idx + 1}`} (cópia)`;
        delete copy.previewDataUrl;
        this.slides.splice(idx + 1, 0, copy);
        this.slideIndex = idx + 1;
        this._loadSlideOntoCanvas(this.slides[this.slideIndex]);
        this.propsPanel?.setBackground(this.slides[this.slideIndex].background || this._getBackground());
        this.renderSlideTabs();
        this.syncSlideTitleInput();
        this.refreshLayers();
        this.app.toast?.('Slide duplicado');
      };
    });

    el.querySelectorAll('.ds-tab-move').forEach((btn) => {
      btn.onclick = (e) => {
        e.stopPropagation();
        const idx = Number(btn.dataset.move);
        const dir = Number(btn.dataset.dir);
        const next = idx + dir;
        if (next < 0 || next >= this.slides.length) return;
        this.persistCurrentSlide();
        const tmp = this.slides[idx];
        this.slides[idx] = this.slides[next];
        this.slides[next] = tmp;
        if (this.slideIndex === idx) this.slideIndex = next;
        else if (this.slideIndex === next) this.slideIndex = idx;
        this.renderSlideTabs();
      };
    });

    el.querySelectorAll('.designer-slide-tab-wrap').forEach((wrap) => {
      wrap.addEventListener('dragstart', (e) => {
        e.dataTransfer.setData('text/plain', wrap.dataset.idx);
        wrap.classList.add('is-dragging');
      });
      wrap.addEventListener('dragend', () => wrap.classList.remove('is-dragging'));
      wrap.addEventListener('dragover', (e) => {
        e.preventDefault();
        wrap.classList.add('is-drag-over');
      });
      wrap.addEventListener('dragleave', () => wrap.classList.remove('is-drag-over'));
      wrap.addEventListener('drop', (e) => {
        e.preventDefault();
        wrap.classList.remove('is-drag-over');
        const from = Number(e.dataTransfer.getData('text/plain'));
        const to = Number(wrap.dataset.idx);
        if (Number.isNaN(from) || Number.isNaN(to) || from === to) return;
        this.persistCurrentSlide();
        const [moved] = this.slides.splice(from, 1);
        this.slides.splice(to, 0, moved);
        if (this.slideIndex === from) this.slideIndex = to;
        else if (from < this.slideIndex && to >= this.slideIndex) this.slideIndex -= 1;
        else if (from > this.slideIndex && to <= this.slideIndex) this.slideIndex += 1;
        this.renderSlideTabs();
      });
    });

    el.querySelector('#ds-slide-add').onclick = () => {
      this.persistCurrentSlide();
      this.slides.push({ title: `Slide ${this.slides.length + 1}`, layers: [], templateId: 'blank' });
      this.slideIndex = this.slides.length - 1;
      this.applyPreset('blank', false);
      this.renderSlideTabs();
      this.syncSlideTitleInput();
    };
  },

};
