/** Canvas load helpers for SlideDesigner. */

import { importLayersToKonva } from './slide-exporter.js';

export const designerCanvasBridgeMethods = {

  _loadPresetOntoCanvas(preset) {
    const eng = this._getEngine();
    if (!eng?.layer) return false;
    if (typeof eng.loadPreset === 'function') {
      eng.loadPreset(preset);
      return true;
    }
    if (typeof eng.clearContent === 'function') eng.clearContent();
    if (preset?.background && typeof eng.setBackground === 'function') eng.setBackground(preset.background);
    if (preset?.layers?.length) importLayersToKonva(eng.layer, preset.layers);
    eng._restackSystemNodes?.();
    eng.rebindFrameInteractions?.();
    eng._ensureTransformer?.();
    eng.selectNode?.(null);
    eng._pushHistory?.();
    eng.onChange?.();
    return true;
  },

  _loadSlideOntoCanvas(slide) {
    const eng = this._getEngine();
    if (!eng?.layer) return false;
    if (typeof eng.loadSlide === 'function') {
      eng.loadSlide(slide);
      return true;
    }
    if (!slide?.layers?.length) {
      eng.clearContent?.();
      if (slide?.background) eng.setBackground?.(slide.background);
      if (slide?.title) eng.addText?.(slide.title, { role: 'title', fontSize: 76 });
      if (slide?.text) eng.addText?.(slide.text, { role: 'body', fontSize: 40, y: 540 });
      return true;
    }
    eng.clearContent?.();
    if (slide.background) eng.setBackground?.(slide.background);
    importLayersToKonva(eng.layer, slide.layers);
    eng._restackSystemNodes?.();
    eng.rebindFrameInteractions?.();
    eng._ensureTransformer?.();
    eng.selectNode?.(null);
    eng._pushHistory?.();
    return true;
  },

};
