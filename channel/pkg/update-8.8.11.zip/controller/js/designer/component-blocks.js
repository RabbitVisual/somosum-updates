/**
 * Blocos reutilizáveis do Designer (U2-F).
 */
import { DESIGN_W, DESIGN_H, importLayersToKonva } from './slide-exporter.js';
import { PRODUCT_LOGO_REL } from '../core/brand-assets.js';

export const COMPONENT_BLOCKS = [
  {
    id: 'title',
    label: 'Título',
    layers: [
      {
        kind: 'text',
        role: 'title',
        text: 'Título do slide',
        x: DESIGN_W * 0.1,
        y: DESIGN_H * 0.35,
        width: DESIGN_W * 0.8,
        fontSize: 72,
        fontFamily: 'Georgia, serif',
        fill: '#ffffff',
        align: 'center',
        textFit: 'wrap',
      },
    ],
  },
  {
    id: 'verse',
    label: 'Versículo',
    layers: [
      {
        kind: 'text',
        role: 'body',
        text: '“Porque Deus amou o mundo…”',
        x: DESIGN_W * 0.12,
        y: DESIGN_H * 0.32,
        width: DESIGN_W * 0.76,
        fontSize: 44,
        fontFamily: 'Georgia, serif',
        fill: '#f5f0e8',
        align: 'center',
        textFit: 'wrap',
      },
      {
        kind: 'text',
        role: 'caption',
        text: 'João 3:16',
        x: DESIGN_W * 0.12,
        y: DESIGN_H * 0.62,
        width: DESIGN_W * 0.76,
        fontSize: 28,
        fontFamily: 'Segoe UI, sans-serif',
        fill: '#c9b896',
        align: 'center',
        textFit: 'wrap',
      },
    ],
  },
  {
    id: 'logo',
    label: 'Logo',
    layers: [
      {
        kind: 'image',
        role: 'logo',
        name: 'logo',
        src: PRODUCT_LOGO_REL,
        x: DESIGN_W * 0.5 - 120,
        y: DESIGN_H * 0.5 - 120,
        width: 240,
        height: 240,
      },
    ],
  },
];

export function listComponentBlocks() {
  return COMPONENT_BLOCKS.map(({ id, label }) => ({ id, label }));
}

export function getComponentBlock(id) {
  return COMPONENT_BLOCKS.find((b) => b.id === id) || null;
}

function normalizeLayerSpec(spec) {
  if (!spec) return spec;
  const out = { ...spec };
  if (!out.kind && out.type) out.kind = out.type;
  delete out.type;
  return out;
}

/**
 * Insere camadas do bloco no canvas.
 */
export function insertComponentBlock(canvasEngine, blockId) {
  const block = getComponentBlock(blockId);
  if (!block || !canvasEngine) return false;
  const layers = (block.layers || []).map(normalizeLayerSpec);
  if (typeof canvasEngine.addLayersFromData === 'function') {
    canvasEngine.addLayersFromData(layers);
    return true;
  }
  if (canvasEngine.layer && typeof importLayersToKonva === 'function') {
    importLayersToKonva(canvasEngine.layer, layers);
    canvasEngine.onChange?.();
    canvasEngine._pushHistory?.();
    canvasEngine.refreshLayers?.();
    return true;
  }
  return false;
}
