function esc(text) {
  return String(text ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function renderLyricsSlide(slide) {
  const lines = (slide.lines || []).map((l) =>
    `<p class="lyrics-line">${esc(l)}</p>`
  ).join('');
  return `<div class="slide slide-lyrics"><div class="lyrics-body"><div class="lyrics-lines">${lines}</div></div></div>`;
}

function renderBlankSlide() {
  return '<div class="slide slide-blank"></div>';
}

function renderThemeGradient(slide) {
  const c1 = slide.color1 || '#1a1a2e';
  const c2 = slide.color2 || '#16213e';
  return `<div class="slide slide-theme" style="background:linear-gradient(135deg,${c1},${c2})"></div>`;
}

self.onmessage = async (e) => {
  const { id, slide } = e.data || {};
  try {
    let html = '';
    if (slide?.type === 'lyrics') html = renderLyricsSlide(slide);
    else if (slide?.type === 'blank') html = renderBlankSlide();
    else if (slide?.type === 'theme') html = renderThemeGradient(slide);
    else {
      self.postMessage({ id, ok: true, result: { html: null } });
      return;
    }

    if (typeof OffscreenCanvas !== 'undefined' && (slide?.type === 'blank' || slide?.type === 'theme')) {
      const canvas = new OffscreenCanvas(1920, 1080);
      const ctx = canvas.getContext('2d');
      if (slide?.type === 'theme') {
        const g = ctx.createLinearGradient(0, 0, 1920, 1080);
        g.addColorStop(0, slide.color1 || '#1a1a2e');
        g.addColorStop(1, slide.color2 || '#16213e');
        ctx.fillStyle = g;
      } else {
        ctx.fillStyle = '#000';
      }
      ctx.fillRect(0, 0, 1920, 1080);
      const bitmap = canvas.transferToImageBitmap();
      self.postMessage({ id, ok: true, result: { html, bitmap } }, [bitmap]);
      return;
    }
    self.postMessage({ id, ok: true, result: { html } });
  } catch (err) {
    self.postMessage({ id, ok: false, error: err?.message || String(err) });
  }
};
