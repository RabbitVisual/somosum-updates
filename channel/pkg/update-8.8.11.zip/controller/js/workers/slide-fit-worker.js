/**
 * Worker: tipografia fit sem getComputedStyle (OffscreenCanvas + measureText).
 * API: { id, lines, fontFamily, fontSize, maxW, maxH, lineHeight? }
 * → { fontSize, lineHeights, scale }
 */

function measureBlock(ctx, lines, fontSize, fontFamily, lineHeight) {
  ctx.font = `${fontSize}px ${fontFamily}`;
  const lh = lineHeight || fontSize * 1.25;
  let maxLineW = 0;
  for (const line of lines) {
    const m = ctx.measureText(String(line || ''));
    maxLineW = Math.max(maxLineW, m.width);
  }
  return { width: maxLineW, height: lines.length * lh };
}

self.onmessage = (e) => {
  const { id, lines = [], fontFamily = 'Segoe UI, sans-serif', fontSize = 64, maxW = 1600, maxH = 900, lineHeight } = e.data || {};
  try {
    const canvas = typeof OffscreenCanvas !== 'undefined'
      ? new OffscreenCanvas(8, 8)
      : null;
    if (!canvas?.getContext) {
      self.postMessage({ id, ok: true, result: { fontSize, scale: 1, lineHeights: lines.map(() => fontSize * 1.25) } });
      return;
    }
    const ctx = canvas.getContext('2d');
    let size = Math.max(12, Number(fontSize) || 64);
    let scale = 1;
    let guard = 0;
    const minScale = 0.55;
    let metrics = measureBlock(ctx, lines, size, fontFamily, lineHeight);
    while ((metrics.width > maxW || metrics.height > maxH) && scale > minScale && guard < 24) {
      scale -= 0.04;
      size = Math.max(12, (Number(fontSize) || 64) * scale);
      metrics = measureBlock(ctx, lines, size, fontFamily, lineHeight ? lineHeight * scale : undefined);
      guard += 1;
    }
    const lh = (lineHeight || size * 1.25);
    self.postMessage({
      id,
      ok: true,
      result: {
        fontSize: size,
        scale,
        lineHeights: lines.map(() => lh),
        width: metrics.width,
        height: metrics.height,
      },
    });
  } catch (err) {
    self.postMessage({ id, ok: false, error: err?.message || String(err) });
  }
};
