self.onmessage = (e) => {
  const { id, verses } = e.data || {};
  try {
    const html = (verses || []).map((v) =>
      `<p class="bible-verse"><span class="verse-num">${v.num || ''}</span>${String(v.text || '')}</p>`
    ).join('');
    self.postMessage({ id, ok: true, result: { html } });
  } catch (err) {
    self.postMessage({ id, ok: false, error: err?.message || String(err) });
  }
};
