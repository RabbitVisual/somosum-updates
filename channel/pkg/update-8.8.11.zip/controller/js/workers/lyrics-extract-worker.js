/** Worker — extração e normalização de letras off-thread. */
import { extractLyricsFromHtmlSync } from '../worship/lyrics-engine/lyrics-extractor.js';
import { normalizeLyricsPipeline } from '../worship/lyrics-engine/lyrics-normalizer.js';

self.onmessage = (e) => {
  const { id, html, url, matchScore = 0.5 } = e.data || {};
  try {
    const { plainText, chordSource } = extractLyricsFromHtmlSync(html, url);
    const normalized = normalizeLyricsPipeline(plainText, { matchScore });
    self.postMessage({
      id,
      ok: true,
      result: { ...normalized, chordSource },
    });
  } catch (err) {
    self.postMessage({ id, ok: false, error: err?.message || String(err) });
  }
};
