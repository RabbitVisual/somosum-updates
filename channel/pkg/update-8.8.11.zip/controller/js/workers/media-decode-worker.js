self.onmessage = async (e) => {
  const { id, url } = e.data || {};
  try {
    const res = await fetch(url);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const blob = await res.blob();
    self.postMessage({ id, ok: true, result: { blob, type: blob.type, size: blob.size } });
  } catch (err) {
    self.postMessage({ id, ok: false, error: err?.message || String(err) });
  }
};
