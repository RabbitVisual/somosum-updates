/**
 * Worker leve: filtro/busca em arrays (worship/media) fora da main thread.
 * payload: { id, op: 'filter', items, query, fields? }
 */
function normalize(s) {
  return String(s || '')
    .toLowerCase()
    .normalize('NFD')
    .replace(/\p{M}/gu, '');
}

self.onmessage = (e) => {
  const { id, op, items = [], query = '', fields = ['title', 'name', 'author'] } = e.data || {};
  try {
    if (op !== 'filter') {
      self.postMessage({ id, ok: true, result: { items } });
      return;
    }
    const q = normalize(query).trim();
    if (!q) {
      self.postMessage({ id, ok: true, result: { items, indices: items.map((_, i) => i) } });
      return;
    }
    const indices = [];
    const out = [];
    for (let i = 0; i < items.length; i += 1) {
      const it = items[i];
      if (!it) continue;
      const hay = fields.map((f) => normalize(it[f])).join(' ');
      if (hay.includes(q)) {
        indices.push(i);
        out.push(it);
      }
    }
    self.postMessage({ id, ok: true, result: { items: out, indices } });
  } catch (err) {
    self.postMessage({ id, ok: false, error: err?.message || String(err) });
  }
};
