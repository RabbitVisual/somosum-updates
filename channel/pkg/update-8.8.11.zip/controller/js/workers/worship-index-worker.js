/** Rebuild worship inverted index off main thread. */

self.onmessage = (ev) => {
  const { songs, chunkSize = 80 } = ev.data || {};
  if (!Array.isArray(songs)) {
    self.postMessage({ type: 'error', error: 'invalid' });
    return;
  }
  const index = new Map();
  const tokenize = (text) => String(text || '').toLowerCase()
    .normalize('NFD').replace(/\p{M}/gu, '')
    .split(/[^a-z0-9]+/).filter((t) => t.length >= 2);

  let i = 0;
  const pump = () => {
    const end = Math.min(i + chunkSize, songs.length);
    for (; i < end; i++) {
      const s = songs[i];
      if (!s?.id) continue;
      const bag = new Set([
        ...tokenize(s.title),
        ...tokenize(s.artist),
        ...tokenize(s.ministry),
        ...(s.tags || []).flatMap(tokenize),
      ]);
      for (const tok of bag) {
        if (!index.has(tok)) index.set(tok, new Set());
        index.get(tok).add(s.id);
      }
    }
    self.postMessage({ type: 'progress', done: i, total: songs.length });
    if (i < songs.length) setTimeout(pump, 0);
    else {
      const serial = {};
      for (const [k, set] of index.entries()) serial[k] = [...set];
      self.postMessage({ type: 'done', index: serial });
    }
  };
  pump();
};
