/** SOMOSUM text.json consumer — poll 100ms + refresh lock. */

let refreshIsRunning = false;
const fields = {
  type: 'empty',
  color: '#FAFAFA',
  background: '#000000',
  text: '',
  alert: '',
};

const textEl = document.getElementById('stream-text');
const alertEl = document.getElementById('stream-alert');
const rootEl = document.getElementById('stream-root');

async function refresh() {
  if (refreshIsRunning) return;
  refreshIsRunning = true;
  try {
    const res = await fetch('/api/stream/text.json', { cache: 'no-store' });
    if (!res.ok) return;
    const data = await res.json();
    applyPayload(data);
  } catch { /* retry next tick */ }
  finally {
    refreshIsRunning = false;
  }
}

function applyPayload(data) {
  Object.assign(fields, data);
  if (textEl && fields.text !== textEl.textContent) {
    textEl.textContent = fields.text || '';
    textEl.style.color = fields.color || '#FAFAFA';
    textEl.style.fontWeight = fields.bold ? '700' : '400';
    textEl.style.textAlign = fields.halign || 'center';
  }
  if (rootEl) rootEl.style.background = fields.background || '#000';
  if (alertEl) {
    const alert = fields.alert || '';
    alertEl.style.display = alert ? 'block' : 'none';
    alertEl.textContent = alert;
  }
}

setInterval(refresh, 100);
refresh();
