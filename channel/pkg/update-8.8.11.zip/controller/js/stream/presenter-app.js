import { ProjectionBus, MessageTypes } from '../core/bus.js';

const bus = new ProjectionBus('presenter');
const elCurrent = document.getElementById('presenter-current');
const elNext = document.getElementById('presenter-next');
const elNotes = document.getElementById('presenter-notes');
const elMeta = document.getElementById('presenter-meta');
const elClock = document.getElementById('presenter-clock');

function tickClock() {
  const d = new Date();
  elClock.textContent = d.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
}
setInterval(tickClock, 1000);
tickClock();

bus.on((msg) => {
  if (msg.type === MessageTypes.SLIDE || msg.type === MessageTypes.FULL_STATE) {
    const slide = msg.payload?.slide;
    const nav = msg.payload?.stageNav;
    if (slide) {
      const lines = slide.lines?.join('\n') || slide.title || slide.reference || slide.type || '';
      elCurrent.textContent = lines;
    }
    if (nav) {
      elMeta.textContent = `${nav.itemTitle || ''} · slide ${(nav.slideIndex ?? 0) + 1}/${nav.itemSlideCount || '?'}`;
    }
  }
  if (msg.type === MessageTypes.STAGE_STATE) {
    elNext.textContent = msg.payload?.nextLabel || '—';
    elNotes.textContent = msg.payload?.notes || '';
  }
});

bus.send(MessageTypes.HEARTBEAT, { ready: true, needState: true, role: 'presenter' });
