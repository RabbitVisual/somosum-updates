/**
 * Painel de rede — status, PIN dinâmico, dispositivos.
 * QR fica só em Ajustes → URLs e QR (evita seção duplicada / QR piscando).
 */
import {
  getNetworkStatus,
  runNetworkDiagnostics,
  networkBuildQr,
  networkRegisterPorts,
  networkPairList,
  networkPairRevoke,
  networkDiscover,
  networkRepairFirewall,
  getCurrentPin,
} from '../runtime/facades/network-runtime.js';
import { rotateRemoteToken } from '../core/security/token-manager.js';
import { getPrefs, savePrefs } from '../core/store.js';

function esc(t) {
  const d = document.createElement('div');
  d.textContent = t ?? '';
  return d.innerHTML;
}

function withTimeout(promise, ms, fallback) {
  return Promise.race([
    promise.catch(() => fallback),
    new Promise((resolve) => setTimeout(() => resolve(fallback), ms)),
  ]);
}

function formatMmSs(totalSec) {
  const s = Math.max(0, Math.floor(Number(totalSec) || 0));
  const m = Math.floor(s / 60);
  const r = s % 60;
  return `${m}:${String(r).padStart(2, '0')}`;
}

const _pinTimers = new WeakMap();

export function stopPinTimer(container) {
  const t = _pinTimers.get(container);
  if (t) {
    clearInterval(t);
    _pinTimers.delete(container);
  }
}

export async function mountLivePin(pinHost, { toast, forceRotate = false, onPinChanged } = {}) {
  if (!pinHost) return;
  const pin = await withTimeout(getCurrentPin({ rotate: forceRotate }), 4000, null);
  if (!pin?.pin) {
    pinHost.innerHTML = '<p class="panel-hint panel-hint-warn">PIN indisponível — confira o Modo LAN.</p>';
    return;
  }

  let remaining = Number(pin.remainingSeconds);
  if (!Number.isFinite(remaining) || remaining < 0) {
    const exp = Date.parse(pin.expiresUtc || '');
    remaining = Number.isFinite(exp) ? Math.max(0, Math.ceil((exp - Date.now()) / 1000)) : 300;
  }

  const code = String(pin.pin);
  const paintMeta = () => {
    const urgent = remaining <= 60;
    const card = pinHost.querySelector('.network-pin-card');
    const ttlEl = pinHost.querySelector('[data-pin-ttl]');
    const codeEl = pinHost.querySelector('[data-pin-code]');
    if (card) card.classList.toggle('is-urgent', urgent);
    if (ttlEl) ttlEl.innerHTML = `Renova em <strong>${esc(formatMmSs(remaining))}</strong>`;
    if (codeEl) codeEl.textContent = code;
  };

  if (!pinHost.querySelector('.network-pin-card') || forceRotate) {
    pinHost.innerHTML = `
      <div class="network-pin-card${remaining <= 60 ? ' is-urgent' : ''}">
        <div class="network-pin-card__main">
          <span class="network-pin-card__label">PIN do Remote</span>
          <strong class="network-pin-card__code" data-pin-code>${esc(code)}</strong>
        </div>
        <div class="network-pin-card__meta">
          <span data-pin-ttl>Renova em <strong>${esc(formatMmSs(remaining))}</strong></span>
          <button type="button" class="btn btn-sm" data-pin-rotate>Renovar PIN</button>
        </div>
        <p class="panel-hint">PIN de <strong>1 uso</strong>: cada aparelho novo digita o código; depois o sistema gera outro. QR só abre o link.</p>
      </div>`;
    pinHost.querySelector('[data-pin-rotate]')?.addEventListener('click', async () => {
      toast?.('Gerando novo PIN…', 'info');
      await mountLivePin(pinHost, { toast, forceRotate: true, onPinChanged });
      toast?.('PIN renovado', 'ok');
      onPinChanged?.({ reason: 'rotate' });
    });
  } else {
    paintMeta();
  }

  const root = pinHost.closest('.network-panel') || pinHost;
  stopPinTimer(root);
  const timer = setInterval(async () => {
    remaining -= 1;
    paintMeta();
    if (remaining <= 0) {
      stopPinTimer(root);
      await mountLivePin(pinHost, { toast, forceRotate: false, onPinChanged });
      onPinChanged?.({ reason: 'expired' });
    }
  }, 1000);
  _pinTimers.set(root, timer);
}

/** @deprecated Use mountNetworkHub — UI paralela removida; mantido para compat interna do wizard legado. */
export async function renderNetworkPanel(container, { toast, onRefresh } = {}) {
  if (!container) return;
  stopPinTimer(container);
  container.innerHTML = '<p class="panel-hint">Carregando rede...</p>';

  let status = null;
  let devices = { devices: [] };
  let discover = null;
  try {
    [status, devices, discover] = await Promise.all([
      withTimeout(getNetworkStatus(), 7000, null),
      withTimeout(networkPairList(), 3000, { devices: [] }),
      withTimeout(networkDiscover(), 5000, null),
    ]);
  } catch {
    status = null;
  }

  if (!status) {
    try {
      const lan = await fetch('/api/lan-info', { cache: 'no-store' }).then((r) => (r.ok ? r.json() : null));
      if (lan) {
        status = {
          lanBindOk: !!lan.lanBindOk,
          port: lan.port,
          recommendedIp: lan.lanIp,
          lanIp: lan.lanIp,
          remoteUrl: lan.remoteUrl,
        };
      }
    } catch { /* ignore */ }
  }

  const lanOk = !!status?.lanBindOk;
  const ip = status?.recommendedIp || status?.lanIp || discover?.recommendedIp || '—';
  const list = devices?.devices || [];

  container.innerHTML = `
    <section class="network-panel">
      <header class="network-panel-head">
        <h3>Rede local</h3>
        <span class="network-badge ${lanOk ? 'ok' : 'warn'}">${lanOk ? 'Pronta' : 'Atenção'}</span>
      </header>
      <dl class="network-panel-stats">
        <div><dt>IP recomendado</dt><dd>${esc(ip)}</dd></div>
        <div><dt>Porta</dt><dd>${esc(String(status?.port || '—'))}</dd></div>
        <div><dt>mDNS</dt><dd>${status?.mdnsRunning ? esc('_somosum._tcp.local') : 'Inativo'}</dd></div>
        <div><dt>Dispositivos</dt><dd>${list.filter((d) => d.authorized).length}</dd></div>
      </dl>
      <div class="network-panel-actions">
        <button type="button" class="btn" data-act="test">Testar conexão</button>
        <button type="button" class="btn" data-act="diag">Diagnóstico</button>
        <button type="button" class="btn" data-act="fix">Preparar rede</button>
        <button type="button" class="btn" data-act="firewall">Reparar firewall</button>
        <button type="button" class="btn" data-act="qr">Atualizar QR acima</button>
        <button type="button" class="btn" data-act="copy">Copiar endereço</button>
      </div>
      <article class="network-tls-card panel-tile panel-tile--tip">
        <header class="panel-tile__head">
          <div>
            <h4>Rede segura (opcional)</h4>
            <p>HTTPS na LAN criptografa Remote/Stage. Celulares verão aviso de certificado self-signed — aceite uma vez por aparelho.</p>
          </div>
        </header>
        <div class="settings-btn-row">
          <label class="settings-toggle">
            <input type="checkbox" id="network-lan-tls" />
            <span>Ativar HTTPS na rede local (TLS)</span>
          </label>
          <button type="button" class="btn btn-sm" data-act="rotate-token">Revogar token Remote</button>
        </div>
        <p class="panel-hint">Revogue o token após o culto se compartilhou QR fora da igreja.</p>
      </article>
      <div id="network-panel-pin" class="network-panel-pin"></div>
      <p class="panel-hint" id="network-panel-hint"></p>
      <div id="network-panel-devices"></div>
      <details class="network-panel-diag"><summary>Diagnóstico NCM 2.0</summary><pre id="network-panel-diag-pre"></pre></details>
    </section>`;

  const pinHost = container.querySelector('#network-panel-pin');
  const hintEl = container.querySelector('#network-panel-hint');
  const tlsEl = container.querySelector('#network-lan-tls');
  if (tlsEl) {
    const prefs = getPrefs();
    tlsEl.checked = !!prefs.lanTls;
    tlsEl.addEventListener('change', async () => {
      await savePrefs({ lanTls: tlsEl.checked });
      toast?.(tlsEl.checked
        ? 'HTTPS ativado — reinicie o servidor na bandeja para aplicar'
        : 'HTTPS desativado — reinicie o servidor para voltar ao HTTP', 'info');
    });
  }

  container.querySelector('[data-act="rotate-token"]')?.addEventListener('click', async () => {
    const ok = await rotateRemoteToken();
    toast?.(ok ? 'Token Remote rotacionado — pareamentos antigos invalidados' : 'Só disponível no PC local (loopback)', ok ? 'ok' : 'warn');
  });

  if (lanOk) {
    await mountLivePin(pinHost, { toast });
    if (hintEl) {
      hintEl.innerHTML = `Tablet e PC na <strong>mesma Wi‑Fi</strong> (sem dados móveis). Se der “não é possível acessar”, use <strong>Reparar firewall</strong> e escaneie o QR de novo.`;
    }
  } else {
    if (hintEl) {
      hintEl.className = 'panel-hint panel-hint-warn';
      hintEl.textContent = 'Ative o Modo LAN e prepare a rede antes de escanear o QR.';
    }
  }

  const devEl = container.querySelector('#network-panel-devices');
  if (list.length === 0) {
    devEl.innerHTML = '<p class="panel-hint">Nenhum celular pareado ainda.</p>';
  } else {
    devEl.innerHTML = `<h4>Celulares autorizados</h4><ul class="network-device-list">${list.map((d) => `
      <li>
        <span>${esc(d.name || 'Celular')} ${d.pending ? '(aguardando)' : ''}</span>
        <button type="button" class="btn btn-sm" data-revoke="${esc(d.id)}">Remover</button>
      </li>`).join('')}</ul>`;
  }

  container.querySelector('[data-act="test"]')?.addEventListener('click', async () => {
    try {
      const t0 = performance.now();
      const res = await fetch('/api/ping', { cache: 'no-store' });
      toast?.(res.ok ? `Conexão OK (~${Math.round(performance.now() - t0)} ms)` : 'Sem resposta', res.ok ? 'ok' : 'warn');
    } catch {
      toast?.('Falha no teste', 'warn');
    }
  });

  container.querySelector('[data-act="diag"]')?.addEventListener('click', async () => {
    const diag = await runNetworkDiagnostics();
    container.querySelector('#network-panel-diag-pre').textContent = JSON.stringify(diag, null, 2);
    container.querySelector('.network-panel-diag').open = true;
  });

  container.querySelector('[data-act="fix"]')?.addEventListener('click', async () => {
    toast?.('Se o Windows pedir, confirme a permissão.', 'info');
    const reg = await networkRegisterPorts(false);
    if (reg?.pending || reg?.needsElevation) {
      toast?.('Confirme o UAC. A rede atualiza em alguns segundos.', 'info');
    } else if (reg?.ok || reg?.Success) {
      toast?.('Rede preparada.', 'ok');
    } else {
      toast?.('Use o ícone da bandeja → Rede → Preparar rede local.', 'warn');
    }
    onRefresh?.();
    setTimeout(() => renderNetworkPanel(container, { toast, onRefresh }), 2500);
  });

  container.querySelector('[data-act="firewall"]')?.addEventListener('click', async () => {
    toast?.('Reparando regras do firewall...', 'info');
    const result = await networkRepairFirewall();
    if (result?.requiresElevation) {
      toast?.('Permissão de administrador necessária.', 'warn');
    } else if (result?.ok) {
      toast?.('Firewall reparado.', 'ok');
    } else {
      toast?.('Não foi possível reparar: ' + (result?.message || 'erro'), 'warn');
    }
    onRefresh?.();
  });

  container.querySelector('[data-act="qr"]')?.addEventListener('click', async () => {
    onRefresh?.();
    toast?.('QR atualizado na seção URLs e QR', 'ok');
  });

  container.querySelector('[data-act="copy"]')?.addEventListener('click', async () => {
    const qr = await networkBuildQr(15);
    const url = qr?.url || (ip && status?.port ? `http://${ip}:${status.port}/remote.html` : '');
    if (url) {
      await navigator.clipboard?.writeText(url);
      toast?.('Endereço copiado', 'ok');
    }
  });

  container.querySelectorAll('[data-revoke]').forEach((btn) => {
    btn.addEventListener('click', async () => {
      await networkPairRevoke(btn.dataset.revoke);
      toast?.('Dispositivo removido', 'ok');
      renderNetworkPanel(container, { toast, onRefresh });
    });
  });
}
