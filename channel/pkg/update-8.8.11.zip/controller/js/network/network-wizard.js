/**
 * Assistente de rede — usa HTTP do servidor (confiável).
 * Evita bridge nativa que trava/erra COM e gera QR a partir de /api/lan-info.
 */
import { drawQrToCanvas } from '../ui/qr-lite.js';

const STEPS = [
  { id: 'wifi', title: 'Wi-Fi', question: 'Verificando conexão de rede…' },
  { id: 'lan', title: 'Modo LAN', question: 'Garantindo acesso do celular na mesma Wi‑Fi…' },
  { id: 'qr', title: 'QR Code', question: 'Aponte a câmera do celular para o código.' },
];

async function fetchJson(url, opts = {}) {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), opts.timeoutMs || 8000);
  try {
    const res = await fetch(url, { cache: 'no-store', signal: ctrl.signal, ...opts });
    if (!res.ok) return null;
    return await res.json();
  } catch {
    return null;
  } finally {
    clearTimeout(t);
  }
}

async function getLanSnapshot() {
  const [status, lan, health] = await Promise.all([
    fetchJson('/api/network/status'),
    fetchJson('/api/lan-info'),
    fetchJson('/api/health'),
  ]);
  const stage = String(lan?.guarantee?.stage || lan?.guaranteeStage || '').toLowerCase();
  const proven = !!(lan?.lanBindOk
    && (lan?.listeningPublic === true || lan?.guarantee?.ready === true
      || lan?.guarantee?.probeOk === true || stage === 'ready'));
  const lanBindOk = proven;
  const lanMode = !!(status?.lanMode || lan?.lanMode || health?.lanMode);
  const ip = status?.recommendedIp || lan?.lanIp || health?.lanIp || '';
  const port = status?.port || lan?.port || health?.port || Number(location.port) || 8765;
  // Sem bind LAN: só localhost. Inventar http://IP:... quebrava o tablet.
  let remoteUrl = '';
  if (lanBindOk && lan?.remoteUrl && !String(lan.remoteUrl).includes('127.0.0.1')) {
    remoteUrl = lan.remoteUrl;
  } else if (lan?.localRemoteUrl) {
    remoteUrl = lan.localRemoteUrl;
  } else {
    remoteUrl = `http://127.0.0.1:${port}/remote.html`;
  }
  return {
    lanBindOk,
    lanMode,
    ip,
    port,
    remoteUrl,
    qrReady: !!(lanBindOk && (lan?.qrReady || lan?.listeningPublic)),
    guaranteeStage: stage,
    raw: { status, lan, health },
  };
}

async function fetchQrUrl(fallbackRemoteUrl, lanBindOk) {
  const qr = await fetchJson('/api/network/qr');
  if (qr?.ok && qr.url && !String(qr.url).includes('127.0.0.1')) {
    return { ok: true, url: qr.url, source: 'api' };
  }
  if (lanBindOk && fallbackRemoteUrl && !String(fallbackRemoteUrl).includes('127.0.0.1')) {
    return { ok: true, url: fallbackRemoteUrl, source: 'lan-info' };
  }
  return {
    ok: false,
    error: qr?.error || 'lan_bind_not_ready',
    blockers: qr?.blockers || ['lan_bind_not_ready'],
    localUrl: fallbackRemoteUrl,
  };
}

function delay(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

export class NetworkWizard {
  constructor(rootEl, { onComplete, toast, ensureLanMode } = {}) {
    this.root = rootEl;
    this.onComplete = onComplete;
    this.toast = toast;
    this.ensureLanMode = ensureLanMode;
    this.stepIndex = 0;
    this._busy = false;
    this._generation = 0;
  }

  async run() {
    const gen = ++this._generation;
    this.stepIndex = 0;
    this.render();
    this.setStatus('Lendo estado da rede…', 'info');

    let snap = await getLanSnapshot();
    if (gen !== this._generation) return;

    if (!snap.ip) {
      this.setStatus('Nenhum IP de rede detectado. Conecte o PC ao Wi‑Fi e clique em Tentar de novo.', 'fail');
      this.showActions({ retry: true });
      return;
    }

    this.setStatus(`Wi‑Fi OK — IP ${snap.ip}`, 'ok');
    await delay(400);
    if (gen !== this._generation) return;

    this.stepIndex = 1;
    this.render();

    if (!snap.lanMode || !snap.lanBindOk) {
      this.setStatus('Ativando Modo LAN (sem reiniciar o app)…', 'info');
      await this.prepareLanLight();
      snap = await getLanSnapshot();
    }

    if (gen !== this._generation) return;

    if (!snap.lanBindOk) {
      this.setStatus(
        'LAN ainda não abriu na rede. Clique em Corrigir e confirme o UAC se o Windows pedir.',
        'warn'
      );
      this.showActions({ fix: true, retry: true });
      return;
    }

    this.setStatus('Rede pronta. Gerando QR…', 'ok');
    await delay(250);
    if (gen !== this._generation) return;

    await this.showQrStep(snap, gen);
  }

  async showQrStep(snap, gen = this._generation) {
    this.stepIndex = 2;
    this.render();
    this.setStatus('Gerando QR…', 'info');
    this.showActions({});

    const qr = await fetchQrUrl(snap.remoteUrl, snap.lanBindOk);
    if (gen !== this._generation) return;

    if (!qr.ok || !qr.url) {
      const blockers = Array.isArray(qr.blockers) && qr.blockers.length
        ? ` (${qr.blockers.join(', ')})`
        : '';
      this.setStatus(`Não foi possível gerar o QR${blockers}. Clique em Corrigir.`, 'fail');
      this.showActions({ fix: true, retry: true });
      return;
    }

    const qrEl = this.root.querySelector('#nw-qr');
    const urlEl = this.root.querySelector('#nw-url');
    if (urlEl) urlEl.value = qr.url;

    try {
      if (qrEl) {
        qrEl.width = 200;
        qrEl.height = 200;
        await drawQrToCanvas(qrEl, qr.url, { size: 200 });
      }
      this.setStatus('Pronto! Escaneie no celular (mesma Wi‑Fi do PC).', 'ok');
      this.showActions({ copy: true });
      this.onComplete?.({ ok: true, url: qr.url });
    } catch (err) {
      console.error('[SOMOSUM] qr draw', err);
      this.setStatus('QR gerado — use Copiar URL se a imagem não aparecer.', 'warn');
      this.showActions({ copy: true, retry: true });
      if (urlEl) urlEl.value = qr.url;
    }
  }

  /** Ativa LAN + porta sem soft-restart (reinício trava o assistente). */
  async prepareLanLight() {
    try {
      if (typeof this.ensureLanMode === 'function') {
        // ensureLanMode ja registra + rebind (sem segundo UAC aqui)
        await this.ensureLanMode({ softRestart: false });
      } else {
        await fetchJson('/api/prefs', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ lanMode: true }),
          timeoutMs: 5000,
        });
        const { networkRegisterPorts, networkRebind, waitForLanBind } = await import('../runtime/facades/network-runtime.js');
        await networkRegisterPorts(false);
        await networkRebind();
        await waitForLanBind(20000);
      }
    } catch { /* ignore */ }

    try {
      await fetchJson('/api/network/rebind', { method: 'POST', timeoutMs: 8000 });
    } catch { /* optional */ }

    await delay(600);
  }

  async fixCurrent() {
    if (this._busy) return;
    this._busy = true;
    const gen = this._generation;
    try {
      this.showActions({});
      this.setStatus('Preparando rede… (sem reiniciar o Controle)', 'info');
      await this.prepareLanLight();
      if (gen !== this._generation) return;

      let snap = await getLanSnapshot();
      if (snap.lanBindOk) {
        this.toast?.('Rede OK — gerando QR', 'success');
        await this.showQrStep(snap, gen);
        return;
      }

      // Último recurso: restart curto (timeout 15s, não 90s)
      this.setStatus('Reiniciando só o servidor de rede…', 'info');
      try {
        const { requestSoftRestart } = await import('../core/server-restart.js');
        const ok = await Promise.race([
          requestSoftRestart(20000),
          delay(20000).then(() => false),
        ]);
        this.toast?.(ok ? 'Servidor de volta' : 'Reinício demorou — tentando mesmo assim', ok ? 'success' : 'warn');
      } catch { /* ignore */ }

      await delay(1000);
      snap = await getLanSnapshot();
      if (gen !== this._generation) return;

      if (snap.lanBindOk || snap.remoteUrl) {
        await this.showQrStep(snap, gen);
        return;
      }

      this.setStatus(
        'Ainda sem LAN. Feche o SOMOSUM, abra de novo como administrador, marque Modo LAN e use Preparar rede.',
        'fail'
      );
      this.showActions({ fix: true, retry: true });
    } finally {
      this._busy = false;
    }
  }

  render() {
    const step = STEPS[this.stepIndex] || STEPS[STEPS.length - 1];
    this.root.innerHTML = `
      <div class="network-wizard">
        <div class="network-wizard-progress">${this.stepIndex + 1} / ${STEPS.length}</div>
        <h3>${step.title}</h3>
        <p>${step.question}</p>
        <div class="network-wizard-status" id="nw-status" data-kind="info">…</div>
        <div class="network-wizard-actions">
          <button type="button" class="btn btn-secondary" id="nw-fix" hidden>Corrigir</button>
          <button type="button" class="btn btn-secondary" id="nw-retry" hidden>Tentar de novo</button>
          <button type="button" class="btn btn-primary" id="nw-copy" hidden>Copiar URL Remote</button>
        </div>
        <canvas id="nw-qr" class="network-wizard-qr" width="200" height="200" hidden></canvas>
        <input type="text" id="nw-url" class="network-wizard-url" readonly value="" hidden />
      </div>`;
    this.root.querySelector('#nw-fix')?.addEventListener('click', () => { void this.fixCurrent(); });
    this.root.querySelector('#nw-retry')?.addEventListener('click', () => { void this.run(); });
    this.root.querySelector('#nw-copy')?.addEventListener('click', () => {
      const url = this.root.querySelector('#nw-url')?.value;
      if (!url) return;
      navigator.clipboard?.writeText(url)
        .then(() => this.toast?.('URL Remote copiada', 'success'))
        .catch(() => this.toast?.('Não foi possível copiar', 'warn'));
    });
  }

  setStatus(text, kind = 'info') {
    const el = this.root.querySelector('#nw-status');
    if (!el) return;
    el.textContent = text;
    el.dataset.kind = kind;
  }

  showActions({ fix = false, retry = false, copy = false } = {}) {
    const fixBtn = this.root.querySelector('#nw-fix');
    const retryBtn = this.root.querySelector('#nw-retry');
    const copyBtn = this.root.querySelector('#nw-copy');
    const qr = this.root.querySelector('#nw-qr');
    const url = this.root.querySelector('#nw-url');
    if (fixBtn) fixBtn.hidden = !fix;
    if (retryBtn) retryBtn.hidden = !retry;
    if (copyBtn) copyBtn.hidden = !copy;
    if (qr) qr.hidden = !copy;
    if (url) url.hidden = !copy;
  }
}

export function mountNetworkWizard(container, opts) {
  if (!container) return null;
  container.innerHTML = '';
  const wizard = new NetworkWizard(container, opts);
  void wizard.run().catch((err) => {
    console.error('[SOMOSUM] network wizard', err);
    opts?.toast?.('Falha no assistente de rede', 'error');
    container.innerHTML = `<p class="panel-hint panel-hint-warn">Falha no assistente. Use Preparar rede abaixo ou recarregue (Ctrl+F5).</p>`;
  });
  return wizard;
}
