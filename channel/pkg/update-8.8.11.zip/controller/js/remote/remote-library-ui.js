/**
 * Aba Biblioteca do Remote — atalhos de ordem + painéis Pré-culto / Bíblia.
 */
import { faBtnIcon, faIcon } from '../core/fa-icons.js';
import { renderPrecultoPanel, renderBiblePanel } from './remote-studio-ui.js';

export function renderLibraryTabHtml({
  countdownActive = false,
  hasActiveAlert = false,
  timerLabel = '00:00',
  durationMinutes = 10,
  ambient = {},
  bibleReaderLive = false,
  readerProgress = null,
  bibleRef = {},
} = {}) {
  return `
    ${renderPrecultoPanel({ countdownActive, durationMinutes, ambient })}
    ${renderBiblePanel({ bibleReaderLive, readerProgress, bibleRef })}
    <section class="remote-section-card">
      <h2>${faIcon('layers', 'su-fa su-fa--inline-btn')} Ir na ordem</h2>
      <p class="remote-hint">Abre o primeiro item correspondente no culto.</p>
      <div class="remote-quick remote-quick-grid">
        <button type="button" class="su-btn remote-btn remote-btn-action" data-cmd="openBible">${faBtnIcon('bible')} Item Bíblia</button>
        <button type="button" class="su-btn remote-btn remote-btn-action" data-cmd="openSongs">${faBtnIcon('lyrics')} Louvores</button>
        <button type="button" class="su-btn remote-btn remote-btn-action" data-cmd="openMessage">${faBtnIcon('message')} Mensagem</button>
        <button type="button" class="su-btn remote-btn remote-btn-action" data-cmd="openOffering">${faBtnIcon('offering')} Oferta</button>
      </div>
    </section>
    <section class="remote-section-card">
      <h2>${faIcon('layers', 'su-fa su-fa--inline-btn')} Overlays</h2>
      <div class="remote-quick remote-quick-grid">
        <button type="button" class="su-btn remote-btn remote-btn-action" data-cmd="blank">${faBtnIcon('blank')} Tela preta</button>
        <button type="button" class="su-btn remote-btn remote-btn-action" data-cmd="logo">${faBtnIcon('logo')} Logo</button>
        <button type="button" class="su-btn remote-btn remote-btn-action" data-cmd="clearOverlay">${faBtnIcon('close')} Limpar</button>
      </div>
      ${hasActiveAlert ? `
        <button type="button" class="su-btn su-btn--warn remote-btn remote-btn-action" data-cmd="dismissAlert" style="margin-top:.65rem;width:100%">
          ${faIcon('close', 'su-fa su-fa--inline-btn')} Parar aviso
        </button>` : ''}
    </section>
    <section class="remote-section-card remote-times-block" aria-label="Cronômetro local">
      <h2>${faIcon('countdown', 'su-fa su-fa--inline-btn')} Cronômetro local</h2>
      <p class="remote-times-hint">Só neste aparelho — não comanda o pré-culto da projeção.</p>
      <div class="remote-local-timer" aria-live="polite">
        <strong class="remote-local-timer-value" data-local-timer>${timerLabel || '00:00'}</strong>
        <div class="remote-local-timer-actions">
          <button type="button" class="su-btn su-btn--sm remote-btn" data-local-timer-toggle>${faIcon('play', 'su-fa su-fa--inline-btn')} Iniciar</button>
          <button type="button" class="su-btn su-btn--sm remote-btn" data-local-timer-reset>${faIcon('reset', 'su-fa su-fa--inline-btn')} Zerar</button>
        </div>
      </div>
    </section>`;
}
