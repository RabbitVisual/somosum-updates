import '../runtime/engine-boot.js';
import { initAppMetaRuntime } from '../core/app-meta-boot.js';
import { bootstrapRenderEngine } from '../core/render-engine/index.js';
import { bootstrapSecurity } from '../core/security/index.js';
import { bootstrapPerformance } from '../core/performance/index.js';
import { bootstrapDesignSystem } from '../ui/index.js';
import { initStoragePlatform } from '../core/bootstrap-storage.js';
import { bootstrapWorshipEngine } from '../worship/engine/worship-engine.js';
import { installServerBootGuard, markAppReady } from '../core/server-boot.js';
import { bootstrapLogging } from '../core/bootstrap-logging.js';

bootstrapLogging({ module: 'remote' });
void initAppMetaRuntime();
bootstrapRenderEngine();
bootstrapSecurity();
bootstrapPerformance('remote');
bootstrapDesignSystem('remote');
void initStoragePlatform();
bootstrapWorshipEngine('remote');
installServerBootGuard({ maxWaitMs: 120000 });
window.__somosumMarkReady = markAppReady;

function showRemoteBootFatal(err) {
  const msg = err?.message || String(err || 'Erro desconhecido');
  try { document.getElementById('boot-loading')?.remove(); } catch { /* ignore */ }
  try {
    window.__somosumBootSplashReady?.();
    window.__somosumDismissBootSplash?.(() => {});
  } catch { /* ignore */ }
  const root = document.getElementById('remote-root');
  if (!root) return;
  root.innerHTML = `
    <div class="remote-error">
      <div>
        <h1>Falha ao abrir o Remote</h1>
        <p>${String(msg).replace(/[<>&]/g, '')}</p>
        <button type="button" class="su-btn su-btn--primary remote-btn remote-btn-primary" onclick="location.reload()">Recarregar</button>
      </div>
    </div>`;
}

function forceDismissSplash() {
  try {
    window.__somosumBootSplashReady?.();
    window.__somosumDismissBootSplash?.(() => {});
  } catch { /* ignore */ }
}

window.__somosumBootTimeout = setTimeout(function () {
  if (document.getElementById('boot-loading')) {
    forceDismissSplash();
    import('../core/server-boot.js').then(function (m) {
      m.showReconnectOverlay('Carregamento demorado - reconectando...');
      m.waitAndReload();
    });
  }
}, 20000);

window.addEventListener('somosum-app-ready', function () {
  clearTimeout(window.__somosumBootTimeout);
});

import('./remote-app.js').catch((err) => {
  console.error('[SOMOSUM] Falha ao carregar remote-app', err);
  showRemoteBootFatal(err);
});
