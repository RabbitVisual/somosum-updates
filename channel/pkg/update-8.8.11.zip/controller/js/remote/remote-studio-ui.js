/**
 * Painéis profissionais do Remote — Pré-culto e Bíblia (ponta a ponta).
 */
import { faBtnIcon, faIcon } from '../core/fa-icons.js';
import { BOOKS } from '../bible/books-map.js';
import { esc, escAttr } from '../core/render-engine/index.js';

const DURATION_PRESETS = [5, 10, 15, 20, 30];

export function renderPrecultoPanel({
  countdownActive = false,
  durationMinutes = 10,
  ambient = {},
} = {}) {
  const mins = Number(durationMinutes) || 10;
  const ambientPlaying = !!ambient.playing;
  const hasTrack = !!ambient.hasTrack;
  return `
    <section class="remote-section-card remote-studio-card" data-studio="preculto">
      <h2>${faIcon('countdown', 'su-fa su-fa--inline-btn')} Pré-culto</h2>
      <p class="remote-hint">Defina o tempo e inicie. A contagem roda no Controle/projeção até o fim ou até você encerrar.</p>
      <div class="remote-duration-strip" role="group" aria-label="Duração do pré-culto">
        ${DURATION_PRESETS.map((m) => `
          <button type="button" class="remote-duration-chip ${m === mins ? 'is-active' : ''}" data-cd-mins="${m}" ${countdownActive ? 'disabled' : ''}>${m} min</button>
        `).join('')}
      </div>
      <div class="remote-studio-actions">
        ${countdownActive
    ? `<button type="button" class="su-btn su-btn--warn su-btn--lg remote-btn remote-btn-lg is-live" data-cmd="countdownStop">${faBtnIcon('countdown')} Encerrar pré-culto</button>`
    : `<button type="button" class="su-btn su-btn--primary su-btn--lg remote-btn remote-btn-lg remote-btn-primary" data-cmd="countdownStart" data-duration="${mins}">${faBtnIcon('countdown')} Iniciar ${mins} min</button>`}
      </div>
      <div class="remote-ambient-row">
        <span class="remote-ambient-label">${faIcon('music', 'su-fa su-fa--inline-btn')} Música de fundo</span>
        <div class="remote-ambient-actions">
          <button type="button" class="su-btn su-btn--sm remote-btn" data-cmd="ambientPlay" ${!hasTrack || ambientPlaying ? 'disabled' : ''}>${faIcon('play', 'su-fa su-fa--inline-btn')} Tocar</button>
          <button type="button" class="su-btn su-btn--sm remote-btn" data-cmd="ambientPause" ${!ambientPlaying ? 'disabled' : ''}>${faIcon('pause', 'su-fa su-fa--inline-btn')} Pausar</button>
        </div>
        <p class="remote-times-hint">${hasTrack
    ? (ambientPlaying ? 'Tocando no PC do Controle' : 'Pronta — toque para iniciar')
    : 'Configure a faixa em Controle → Pré-culto / Fundo'}</p>
      </div>
    </section>`;
}

export function renderBiblePanel({
  bibleReaderLive = false,
  readerProgress = null,
  bibleRef = {},
} = {}) {
  const book = bibleRef.book || readerProgress?.book || 'Lc';
  const chapter = Number(bibleRef.chapter || readerProgress?.chapter) || 1;
  const version = bibleRef.version || readerProgress?.version || 'naa';
  const bookOpts = BOOKS.map((b) =>
    `<option value="${escAttr(b.abbrev)}" ${b.abbrev === book ? 'selected' : ''}>${esc(b.name)}</option>`
  ).join('');

  if (bibleReaderLive && readerProgress) {
    return `
      <section class="remote-section-card remote-studio-card remote-bible-live" data-studio="bible">
        <h2>${faIcon('bible', 'su-fa su-fa--inline-btn')} Leitura bíblica</h2>
        <div class="remote-progress">
          <span class="remote-progress-label">No ar</span>
          <strong>${esc(readerProgress.chapterTitle || `${book} ${chapter}`)}</strong>
          <span class="remote-overlay-pill">${esc(readerProgress.slideRange || '')} · ${(readerProgress.index ?? 0) + 1}/${readerProgress.total || '?'}</span>
        </div>
        <div class="remote-transport">
          <button type="button" class="su-btn su-btn--lg remote-btn remote-btn-lg btn-icon" data-cmd="prev">${faIcon('prev')} Versículo</button>
          <button type="button" class="su-btn su-btn--primary su-btn--lg remote-btn remote-btn-lg remote-btn-primary btn-icon" data-cmd="next">${faIcon('next')} Próximo</button>
        </div>
        <div class="remote-studio-actions remote-studio-actions--row">
          <button type="button" class="su-btn remote-btn" data-cmd="readerChapterPrev">${faIcon('prev', 'su-fa su-fa--inline-btn')} Cap. −</button>
          <button type="button" class="su-btn remote-btn" data-cmd="readerChapterNext">${faIcon('next', 'su-fa su-fa--inline-btn')} Cap. +</button>
          <button type="button" class="su-btn su-btn--warn remote-btn" data-cmd="readerStop">Parar leitura</button>
        </div>
      </section>`;
  }

  return `
    <section class="remote-section-card remote-studio-card" data-studio="bible">
      <h2>${faIcon('bible', 'su-fa su-fa--inline-btn')} Bíblia ao vivo</h2>
      <p class="remote-hint">Escolha livro e capítulo e projete a leitura. Também pode abrir o item Bíblia da ordem.</p>
      <div class="remote-bible-form">
        <label class="remote-field">
          <span>Livro</span>
          <select data-bible-book>${bookOpts}</select>
        </label>
        <label class="remote-field remote-field--narrow">
          <span>Capítulo</span>
          <input type="number" min="1" max="150" inputmode="numeric" data-bible-chapter value="${chapter}" />
        </label>
        <label class="remote-field remote-field--narrow">
          <span>Versão</span>
          <select data-bible-version>
            <option value="naa" ${version === 'naa' ? 'selected' : ''}>NAA</option>
            <option value="nvi" ${version === 'nvi' ? 'selected' : ''}>NVI</option>
            <option value="nvt" ${version === 'nvt' ? 'selected' : ''}>NVT</option>
            <option value="acf" ${version === 'acf' ? 'selected' : ''}>ACF</option>
            <option value="ara" ${version === 'ara' ? 'selected' : ''}>ARA</option>
            <option value="arc" ${version === 'arc' ? 'selected' : ''}>ARC</option>
          </select>
        </label>
      </div>
      <div class="remote-studio-actions remote-studio-actions--row">
        <button type="button" class="su-btn su-btn--primary remote-btn remote-btn-primary" data-bible-start>${faBtnIcon('bible')} Projetar leitura</button>
        <button type="button" class="su-btn remote-btn" data-cmd="openBible">Ir ao item Bíblia</button>
      </div>
    </section>`;
}

export function bindStudioPanel(root, { sendCmd, getDuration, setDuration } = {}) {
  root.querySelectorAll('[data-cd-mins]').forEach((btn) => {
    btn.onclick = () => {
      const mins = parseInt(btn.dataset.cdMins, 10);
      if (!Number.isFinite(mins)) return;
      setDuration?.(mins);
      root.querySelectorAll('[data-cd-mins]').forEach((b) => {
        b.classList.toggle('is-active', parseInt(b.dataset.cdMins, 10) === mins);
      });
      const start = root.querySelector('[data-cmd="countdownStart"]');
      if (start) {
        start.dataset.duration = String(mins);
        start.innerHTML = `${faBtnIcon('countdown')} Iniciar ${mins} min`;
      }
    };
  });

  const startBtn = root.querySelector('[data-cmd="countdownStart"]');
  if (startBtn) {
    startBtn.onclick = () => {
      const mins = parseInt(startBtn.dataset.duration, 10) || getDuration?.() || 10;
      void sendCmd('countdownStart', { durationMinutes: mins });
    };
  }

  root.querySelector('[data-bible-start]')?.addEventListener('click', () => {
    const book = root.querySelector('[data-bible-book]')?.value || 'Lc';
    const chapter = parseInt(root.querySelector('[data-bible-chapter]')?.value, 10) || 1;
    const version = root.querySelector('[data-bible-version]')?.value || 'naa';
    void sendCmd('readerStart', {
      book,
      chapter,
      version,
      verseStart: 1,
      verseEnd: 999,
    });
  });
}
