/**
 * WebSocket sync client — Remote 2.0 (fallback para HTTP poll).
 *
 * Owns its own reconnect loop. Callers must NOT also call reconnect() on every
 * ws_close — that races with CONNECTING sockets and floods the console with
 * "WebSocket is closed before the connection is established".
 */

const WS_PATH = '/ws/sync';
const RECONNECT_MIN = 1000;
const RECONNECT_MIN_LIVE = 1200;
const RECONNECT_MAX = 20000;

function roleReconnectMin(role) {
  return (role === 'screen' || role === 'control' || role === 'stage')
    ? RECONNECT_MIN_LIVE
    : RECONNECT_MIN;
}

function withJitter(ms) {
  const base = Math.max(0, Number(ms) || 0);
  const jitter = Math.floor(base * 0.25 * Math.random());
  return base + jitter;
}

export class SyncSocket {
  constructor(role = 'remote', getToken = () => '', getDeviceContext = () => ({})) {
    this.role = role;
    this.getToken = getToken;
    this.getDeviceContext = getDeviceContext;
    this.listeners = new Set();
    this.socket = null;
    this.connected = false;
    this.lastSeq = 0;
    this._reconnectDelay = roleReconnectMin(role);
    this._reconnectTimer = null;
    this._shouldRun = true;
    this._pingTimer = null;
    /** Bumps on intentional teardown so stale onclose/onerror cannot clear a newer socket. */
    this._generation = 0;
    this._intentionalClose = false;
  }

  on(handler) {
    this.listeners.add(handler);
    return () => this.listeners.delete(handler);
  }

  _dispatch(msg) {
    if (!msg) return;
    for (const h of this.listeners) h(msg);
  }

  _wsUrl() {
    const proto = location.protocol === 'https:' ? 'wss:' : 'ws:';
    const token = this.getToken();
    const ctx = typeof this.getDeviceContext === 'function' ? this.getDeviceContext() : {};
    const q = new URLSearchParams({ role: this.role });
    if (token) q.set('token', token);
    if (ctx.deviceFingerprint) q.set('deviceFingerprint', ctx.deviceFingerprint);
    if (ctx.deviceId) q.set('deviceId', ctx.deviceId);
    if (ctx.deviceLabel) q.set('deviceLabel', ctx.deviceLabel);
    return `${proto}//${location.host}${WS_PATH}?${q}`;
  }

  _isLiveSocket(ws = this.socket) {
    if (!ws) return false;
    const rs = ws.readyState;
    return rs === WebSocket.CONNECTING || rs === WebSocket.OPEN;
  }

  connect() {
    if (!this._shouldRun) return;
    if (this._isLiveSocket()) return;

    const gen = ++this._generation;
    this._intentionalClose = false;

    let ws;
    try {
      ws = new WebSocket(this._wsUrl());
    } catch {
      this._scheduleReconnect();
      return;
    }

    this.socket = ws;

    ws.onopen = () => {
      if (gen !== this._generation || this.socket !== ws) return;
      this.connected = true;
      this._reconnectDelay = roleReconnectMin(this.role);
      this._dispatch({ type: 'ws_open' });
      this._startPing();
    };

    ws.onmessage = (ev) => {
      if (gen !== this._generation || this.socket !== ws) return;
      try {
        const data = JSON.parse(ev.data);
        if (data.type === 'ping') {
          this._send({ type: 'pong', ts: data.ts });
          return;
        }
        if (data.type === 'sync_push' && data.body) {
          const body = typeof data.body === 'string' ? JSON.parse(data.body) : data.body;
          this._dispatch(body);
          return;
        }
        if (data.type === 'sync_messages') {
          if (data.seq) this.lastSeq = Math.max(this.lastSeq, data.seq);
          for (const entry of data.messages || []) {
            if (entry.seq) this.lastSeq = Math.max(this.lastSeq, entry.seq);
            if (entry.message) this._dispatch(entry.message);
          }
          return;
        }
        if (data.type === 'network:rebind') {
          this._dispatch({ type: 'network:rebind' });
          this.reconnect();
          return;
        }
        if (data.type === 'ws_connected' && data.seq != null) {
          // Não avançar lastSeq aqui: HTTP poll é a fonte de verdade.
          this._send({ type: 'sync_poll', since: this.lastSeq || 0 });
        }
      } catch { /* ignore */ }
    };

    ws.onclose = () => {
      if (gen !== this._generation) return;
      this.connected = false;
      if (this.socket === ws) this.socket = null;
      this._stopPing();
      this._dispatch({ type: 'ws_close' });
      if (!this._intentionalClose) this._scheduleReconnect();
    };

    ws.onerror = () => {
      if (gen !== this._generation || this.socket !== ws) return;
      this.connected = false;
    };
  }

  reconnect() {
    const hadLive = this.connected || this._isLiveSocket();
    this._teardownSocket({ intentional: true, stop: false });
    // Let SyncHub resume HTTP poll during the reconnect gap.
    if (hadLive) this._dispatch({ type: 'ws_close' });
    this._shouldRun = true;
    this.connect();
  }

  disconnect(stop = true) {
    this._teardownSocket({ intentional: true, stop });
  }

  _teardownSocket({ intentional = false, stop = false } = {}) {
    if (stop) this._shouldRun = false;
    this._intentionalClose = intentional;
    clearTimeout(this._reconnectTimer);
    this._reconnectTimer = null;
    this._stopPing();
    this._generation += 1;
    const old = this.socket;
    this.socket = null;
    this.connected = false;
    if (!old) return;
    try {
      old.onmessage = null;
      old.onerror = null;
      if (old.readyState === WebSocket.OPEN) {
        old.onopen = null;
        old.onclose = null;
        old.close();
      } else if (old.readyState === WebSocket.CONNECTING) {
        // Avoid Chrome's "closed before the connection is established" spam:
        // detach and close only after open (or let it fail silently).
        old.onclose = null;
        old.onopen = () => {
          try { old.close(); } catch { /* ignore */ }
        };
      } else {
        old.onopen = null;
        old.onclose = null;
      }
    } catch { /* ignore */ }
  }

  push(message) {
    if (!this.connected || this.socket?.readyState !== WebSocket.OPEN) {
      this.connected = this.socket?.readyState === WebSocket.OPEN;
      return false;
    }
    try {
      this.socket.send(JSON.stringify({ type: 'sync_push', body: JSON.stringify(message) }));
      return true;
    } catch {
      this.connected = false;
      return false;
    }
  }

  poll(since = 0) {
    if (!this.connected) return;
    this._send({ type: 'sync_poll', since: since || this.lastSeq });
  }

  _send(obj) {
    if (this.socket?.readyState !== WebSocket.OPEN) return;
    try {
      this.socket.send(JSON.stringify(obj));
    } catch { /* ignore */ }
  }

  _startPing() {
    this._stopPing();
    this._pingTimer = setInterval(() => {
      if (this.connected) this._send({ type: 'ping', ts: Date.now() });
    }, 15000);
  }

  _stopPing() {
    if (this._pingTimer) clearInterval(this._pingTimer);
    this._pingTimer = null;
  }

  _scheduleReconnect() {
    if (!this._shouldRun) return;
    if (this._reconnectTimer) return;
    if (this._isLiveSocket()) return;
    const delay = withJitter(this._reconnectDelay);
    this._reconnectTimer = setTimeout(() => {
      this._reconnectTimer = null;
      this._reconnectDelay = Math.min(this._reconnectDelay * 2, RECONNECT_MAX);
      this.connect();
    }, delay);
  }
}

export function isWebSocketSupported() {
  return typeof WebSocket !== 'undefined';
}
