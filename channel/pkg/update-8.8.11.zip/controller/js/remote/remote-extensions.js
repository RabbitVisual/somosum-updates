/** Remote Pro — layouts, macros, fila */
import { DiskAdapter } from '../core/storage/adapters/disk-adapter.js';

const MACROS_PATH = 'remote-macros.json';

export function wireRemotePro(app) {
  const state = {
    layout: localStorage.getItem('somosum-remote-layout') || 'compact',
    queue: [],
    macros: {},
    _macrosLoaded: false,
  };

  const loadMacros = async () => {
    try {
      const disk = await DiskAdapter.load(MACROS_PATH);
      if (disk && typeof disk === 'object') {
        state.macros = disk;
        state._macrosLoaded = true;
        return state.macros;
      }
    } catch { /* ignore */ }
    try {
      state.macros = JSON.parse(localStorage.getItem('somosum-remote-macros') || '{}');
    } catch {
      state.macros = {};
    }
    state._macrosLoaded = true;
    return state.macros;
  };

  app.setRemoteLayout = (layout) => {
    state.layout = layout;
    localStorage.setItem('somosum-remote-layout', layout);
    document.body.dataset.remoteLayout = layout;
  };

  app.enqueueRemoteAction = (action) => {
    state.queue.push({ action, ts: Date.now() });
    if (state.queue.length > 32) state.queue.shift();
  };

  app.saveMacro = (name, steps) => {
    state.macros[name] = steps;
    DiskAdapter.saveDebounced(MACROS_PATH, state.macros);
    try { localStorage.setItem('somosum-remote-macros', JSON.stringify(state.macros)); } catch { /* */ }
  };

  app.runMacro = async (name, exec) => {
    if (!state._macrosLoaded) await loadMacros();
    const steps = state.macros[name];
    if (!steps?.length) return;
    for (const step of steps) {
      await exec(step);
    }
  };

  app.loadRemoteMacros = loadMacros;

  document.body.dataset.remoteLayout = state.layout;
  void loadMacros();
  return state;
}
