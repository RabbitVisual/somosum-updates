/**
 * Aba Avisos do Remote — compose nativo (não abre painel no PC).
 */
import { esc, escAttr } from '../core/render-engine/index.js';
import { faIcon } from '../core/fa-icons.js';

export const REMOTE_ALERT_PRESETS = [
  { id: 'music', text: 'Louvor pronto — pode começar', priority: 'normal', label: 'Música pronta' },
  { id: 'wait', text: 'Aguarde um momento, por favor', priority: 'urgent', label: 'Aguarde' },
  { id: 'preacher', text: 'Chamar o pregador / púlpito', priority: 'urgent', label: 'Chamar pregador' },
  { id: 'sound', text: 'Verificar microfone / retorno', priority: 'urgent', label: 'Áudio' },
  { id: 'offer', text: 'Momento da oferta — equipe atenta', priority: 'normal', label: 'Oferta' },
  { id: 'ok', text: 'OK — mensagem recebida', priority: 'normal', label: 'OK / recebido' },
];

export function renderAlertsTabHtml({ hasActiveAlert = false } = {}) {
  return `
    <section class="remote-section-card remote-alerts-tab">
      <h2>${faIcon('macros', 'su-fa su-fa--inline-btn')} Avisos à equipe</h2>
      <p class="remote-hint">Vai para Púlpito e outros Remotes — <strong>não</strong> aparece no projetor da congregação.</p>
      ${hasActiveAlert ? `
        <button type="button" class="su-btn su-btn--warn remote-btn remote-btn-action remote-btn-block" data-cmd="dismissAlert">
          ${faIcon('close', 'su-fa su-fa--inline-btn')} Parar aviso ativo
        </button>` : ''}
      <div class="remote-alert-presets">
        ${REMOTE_ALERT_PRESETS.map((p) => `
          <button type="button" class="su-btn remote-btn remote-alert-preset ${p.priority === 'urgent' ? 'is-urgent' : ''}"
            data-alert-send data-text="${escAttr(p.text)}" data-priority="${escAttr(p.priority)}">
            ${esc(p.label)}
          </button>`).join('')}
      </div>
      <label class="remote-alert-compose-label">Mensagem personalizada</label>
      <textarea id="remote-alert-text" class="remote-alert-textarea" rows="3" maxlength="180"
        placeholder="Ex.: Subir volume do retorno"></textarea>
      <label class="remote-pin-trust remote-alert-urgent">
        <input type="checkbox" id="remote-alert-urgent" checked /> Urgente
      </label>
      <button type="button" class="su-btn su-btn--primary remote-btn remote-btn-primary remote-btn-lg remote-btn-block" id="remote-alert-send">
        ${faIcon('project', 'su-fa su-fa--inline-btn')} Enviar aviso
      </button>
    </section>`;
}

export function bindAlertsTab(root, { sendCmd, toast } = {}) {
  root.querySelectorAll('[data-alert-send]').forEach((btn) => {
    btn.onclick = async () => {
      btn.disabled = true;
      try {
        await sendCmd?.('alertSend', {
          text: btn.dataset.text || '',
          priority: btn.dataset.priority || 'normal',
          target: 'all',
          source: 'remote',
        });
        toast?.('Aviso enviado', 'info');
      } catch {
        toast?.('Falha ao enviar aviso', 'warn');
      } finally {
        btn.disabled = false;
      }
    };
  });
  root.querySelector('#remote-alert-send')?.addEventListener('click', async () => {
    const text = root.querySelector('#remote-alert-text')?.value?.trim();
    if (!text) {
      toast?.('Digite a mensagem', 'warn');
      return;
    }
    const urgent = !!root.querySelector('#remote-alert-urgent')?.checked;
    const btn = root.querySelector('#remote-alert-send');
    if (btn) btn.disabled = true;
    try {
      await sendCmd?.('alertSend', {
        text,
        priority: urgent ? 'urgent' : 'normal',
        target: 'all',
        source: 'remote',
      });
      const ta = root.querySelector('#remote-alert-text');
      if (ta) ta.value = '';
      toast?.('Aviso enviado', 'info');
    } catch {
      toast?.('Falha ao enviar aviso', 'warn');
    } finally {
      if (btn) btn.disabled = false;
    }
  });
}
