/**
 * Media Preview — prévia 16:9 com overlay e letra de exemplo (estilo projetor).
 */
export function renderMediaPreviewHtml({
  src = '',
  kind = 'image',
  mode = 'lyrics', // media | lyrics | safe
  sampleLines = ['Jesus Cristo', 'é o Senhor'],
  title = '',
} = {}) {
  const lines = (sampleLines || []).filter(Boolean);
  const media = kind === 'video'
    ? `<video class="mp-media" src="${escAttr(src)}" autoplay muted loop playsinline preload="metadata"></video>`
    : `<div class="mp-media mp-media--image" style="background-image:url('${escAttr(src)}')"></div>`;

  const overlay = mode === 'media' ? '' : `<div class="mp-overlay" aria-hidden="true"></div>`;
  const lyrics = mode === 'media' ? '' : `
    <div class="mp-lyrics ${mode === 'safe' ? 'mp-lyrics--safe' : ''}">
      ${lines.map((l) => `<div class="mp-line">${esc(l)}</div>`).join('')}
    </div>`;

  return `
    <div class="media-preview" data-mode="${escAttr(mode)}">
      <div class="media-preview-stage">
        ${media}
        ${overlay}
        ${lyrics}
      </div>
      ${title ? `<div class="media-preview-caption">${esc(title)}</div>` : ''}
    </div>`;
}

function esc(t) {
  const d = document.createElement('div');
  d.textContent = t ?? '';
  return d.innerHTML;
}

function escAttr(t) {
  return esc(t).replace(/"/g, '&quot;');
}
