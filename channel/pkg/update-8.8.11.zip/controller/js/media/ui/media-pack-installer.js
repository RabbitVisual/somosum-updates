/**
 * Modal — instalar / atualizar / desinstalar packs de fundos (system/media).
 * Catálogo local + CDN (RabbitVisual/somosum-catalog).
 */
import {
  fetchMediaPackManifest,
  formatPackSize,
  isMediaPackInstalled,
  getMediaPackInstallState,
  summarizeMediaPackNews,
  formatMediaPackError,
  installMediaPack,
  uninstallMediaPack,
  invalidateMediaPackManifest,
} from '../media-pack-service.js';
import { DiskAdapter } from '../../core/storage/adapters/disk-adapter.js';
import { hydrateMediaFromDisk } from '../../core/store.js';

function esc(t) {
  const d = document.createElement('div');
  d.textContent = t ?? '';
  return d.innerHTML;
}

export async function openMediaPackInstaller(opts = {}) {
  const { onInstalled, toast } = opts;
  invalidateMediaPackManifest();
  let manifest;
  try {
    manifest = await fetchMediaPackManifest({ force: true });
  } catch (err) {
    toast?.(formatMediaPackError(err), 'warn');
    return;
  }
  if (!manifest.packs.length) {
    toast?.('Nenhum pack de fundos disponível.', 'warn');
    return;
  }

  let cfg = await DiskAdapter.load('config.json').catch(() => ({}));
  const hasCdn = !!manifest.cdnBaseUrl;
  const news = summarizeMediaPackNews(manifest, cfg);

  const overlay = document.createElement('div');
  overlay.className = 'hinario-pack-overlay';

  const renderList = () => {
    cfg = cfg || {};
    return manifest.packs.map((p) => {
      const st = getMediaPackInstallState(cfg, p);
      const remote = p.remoteOnly ? ' · online' : '';
      let badges = '';
      if (st.updateAvailable) badges += '<span class="hinario-pack-badge hinario-pack-badge--update">Atualização</span>';
      else if (st.isNew) badges += '<span class="hinario-pack-badge hinario-pack-badge--new">Novo</span>';
      if (st.installed && !st.updateAvailable) badges += '<span class="hinario-pack-badge">Instalado</span>';

      let action = '';
      if (st.updateAvailable) {
        action = `<button type="button" class="btn btn-primary btn-sm hinario-pack-update">Atualizar</button>
                  <button type="button" class="btn btn-ghost btn-sm hinario-pack-uninstall">Remover</button>`;
      } else if (st.installed) {
        action = `<button type="button" class="btn btn-ghost btn-sm hinario-pack-uninstall">Remover</button>`;
      } else {
        action = `<button type="button" class="btn btn-primary btn-sm hinario-pack-install">Instalar</button>`;
      }

      return `
        <li class="hinario-pack-row ${st.installed ? 'is-installed' : ''} ${st.updateAvailable || st.isNew ? 'is-news' : ''}" data-pack-id="${esc(p.id)}">
          <div class="hinario-pack-row-main">
            <span class="hinario-pack-sigla">${esc(p.sigla)}</span>
            <div>
              <strong>${esc(p.name)}</strong>
              <span class="hinario-pack-meta">${p.count} itens · ${formatPackSize(p.bytes)} · v${esc(p.version)}${remote}${p.description ? ` · ${esc(p.description)}` : ''}</span>
            </div>
          </div>
          <div class="hinario-pack-row-action">
            ${action}
            ${badges}
          </div>
          <div class="hinario-pack-progress" hidden>
            <div class="hinario-pack-progress-bar"><span></span></div>
            <span class="hinario-pack-progress-label"></span>
          </div>
        </li>`;
    }).join('');
  };

  const newsBanner = news.hasNews
    ? `<p class="hinario-pack-news">${news.updates ? `${news.updates} atualizaç${news.updates === 1 ? 'ão' : 'ões'} disponível${news.updates === 1 ? '' : 'eis'}` : ''}${news.updates && news.available ? ' · ' : ''}${news.available && [...manifest.packs].some((p) => getMediaPackInstallState(cfg, p).isNew) ? 'Novo pack de fundos online' : (!news.updates ? `${news.available} pack(s) para instalar` : '')}</p>`
    : '';

  overlay.innerHTML = `
    <div class="hinario-pack-dialog" role="dialog" aria-labelledby="media-pack-title">
      <header class="hinario-pack-dialog-head">
        <h2 id="media-pack-title">Fundos padrão do sistema</h2>
        <p class="hinario-pack-dialog-sub">Instale, atualize ou remova packs de vídeos e imagens. Packs inclusos no SOMOSUM funcionam offline; packs novos e atualizações vêm do catálogo online${hasCdn ? ' (GitHub)' : ''}.</p>
        ${newsBanner}
        <button type="button" class="hinario-pack-close" aria-label="Fechar">×</button>
      </header>
      <ul class="hinario-pack-list">${renderList()}</ul>
      <footer class="hinario-pack-dialog-foot">
        <button type="button" class="btn btn-ghost btn-sm" id="media-pack-install-all">Instalar todos</button>
        <button type="button" class="btn btn-ghost hinario-pack-close-foot">Fechar</button>
      </footer>
    </div>`;

  document.body.appendChild(overlay);
  const close = () => overlay.remove();
  overlay.querySelector('.hinario-pack-close')?.addEventListener('click', close);
  overlay.querySelector('.hinario-pack-close-foot')?.addEventListener('click', close);
  overlay.addEventListener('click', (e) => { if (e.target === overlay) close(); });

  const setProgress = (row, label, pct) => {
    const prog = row.querySelector('.hinario-pack-progress');
    const bar = row.querySelector('.hinario-pack-progress-bar span');
    const lbl = row.querySelector('.hinario-pack-progress-label');
    if (!prog) return;
    prog.hidden = false;
    if (lbl) lbl.textContent = label;
    if (bar) bar.style.width = `${pct}%`;
  };

  const afterChange = async () => {
    cfg = await DiskAdapter.load('config.json').catch(() => ({}));
    await hydrateMediaFromDisk();
    overlay.querySelector('.hinario-pack-list').innerHTML = renderList();
    bindActions();
    onInstalled?.();
  };

  async function runInstall(row, packId, { force = false } = {}) {
    if (row.classList.contains('is-busy')) return;
    row.classList.add('is-busy');
    try {
      setProgress(row, force ? 'Atualizando…' : 'Baixando / descompactando…', 20);
      const result = await installMediaPack(packId, {
        force,
        onProgress: (phase, pct) => {
          if (phase === 'download') setProgress(row, `Baixando… ${pct}%`, 10 + pct * 0.4);
          if (phase === 'extract' || phase === 'install') setProgress(row, 'Instalando pack…', 55 + (pct || 0) * 0.2);
          if (phase === 'import') setProgress(row, 'Atualizando biblioteca…', 85);
          if (phase === 'done') setProgress(row, 'Concluído', 100);
        },
      });
      row.classList.remove('is-busy');
      if (result.alreadyInstalled) {
        toast?.(`${result.pack?.name} já instalado.`, 'info');
      } else if (result.updated) {
        toast?.(`${result.pack?.name} atualizado (${result.added} fundos).`, 'success');
      } else {
        toast?.(`${result.added} fundos instalados (${result.pack?.name}).`, 'success');
      }
      await afterChange();
    } catch (err) {
      row.classList.remove('is-busy');
      row.querySelector('.hinario-pack-progress')?.setAttribute('hidden', '');
      toast?.(formatMediaPackError(err), 'warn');
    }
  }

  async function runUninstall(row, packId) {
    const name = manifest.packs.find((p) => p.id === packId)?.name || packId;
    if (!confirm(`Remover "${name}"?\n\nOs fundos deste pack serão excluídos de system/media.`)) return;
    row.classList.add('is-busy');
    try {
      setProgress(row, 'Removendo…', 40);
      const result = await uninstallMediaPack(packId);
      row.classList.remove('is-busy');
      if (result.notInstalled) toast?.('Pack não estava instalado.', 'info');
      else if (result.clearedOrphan) toast?.('Registro do pack limpo.', 'info');
      else toast?.('Fundos removidos.', 'success');
      await afterChange();
    } catch (err) {
      row.classList.remove('is-busy');
      row.querySelector('.hinario-pack-progress')?.setAttribute('hidden', '');
      toast?.(formatMediaPackError(err), 'warn');
    }
  }

  function bindActions() {
    const rebind = (sel, handler) => {
      overlay.querySelectorAll(sel).forEach((btn) => {
        const next = btn.cloneNode(true);
        btn.replaceWith(next);
        next.addEventListener('click', () => {
          const row = next.closest('.hinario-pack-row');
          void handler(row, row?.dataset.packId);
        });
      });
    };
    rebind('.hinario-pack-install', (row, id) => runInstall(row, id));
    rebind('.hinario-pack-update', (row, id) => runInstall(row, id, { force: true }));
    rebind('.hinario-pack-uninstall', (row, id) => runUninstall(row, id));
  }

  overlay.querySelector('#media-pack-install-all')?.addEventListener('click', async () => {
    const pending = manifest.packs.filter((p) => !isMediaPackInstalled(cfg, p.id));
    if (!pending.length) {
      toast?.('Todos os packs já estão instalados. Use Remover para desinstalar individualmente.', 'info');
      return;
    }
    for (const pack of pending) {
      const row = overlay.querySelector(`.hinario-pack-row[data-pack-id="${pack.id}"]`);
      if (row) await runInstall(row, pack.id);
    }
  });

  bindActions();
}
