/**
 * Pacotes opcionais de fundos system/media (ZIP offline + GitHub CDN).
 */
import { DiskAdapter } from '../core/storage/adapters/disk-adapter.js';
import { formatHinarioPackError } from '../worship/hinario-pack-errors.js';
import { isOnline } from '../plugins/plugin-pack-errors.js';
import { installPackWithRemoteFallback } from '../core/pack-remote-fetch.js';
import { fetchCatalog } from '../core/catalog-proxy-fetch.js';
import { compareVersions } from '../plugins/plugin-pack-service.js';

const MANIFEST_URL = '/content/packs/media/manifest.json';
const MANIFEST_API = '/api/content/packs/media/manifest';

let _manifestPromise = null;

function normalizeMediaPack(p) {
  return {
    id: String(p.id || '').toLowerCase(),
    sigla: String(p.sigla || '').toUpperCase(),
    name: String(p.name || ''),
    description: String(p.description || ''),
    file: String(p.file || ''),
    format: String(p.format || 'zip'),
    version: String(p.version ?? '1'),
    count: Number(p.count) || 0,
    bytes: Number(p.bytes) || 0,
    sha256: String(p.sha256 || '').trim().toLowerCase(),
    remotePath: String(p.remotePath || '').trim(),
    remoteOnly: !!p.remoteOnly,
  };
}

function mergeManifests(local, remote) {
  if (!remote?.packs?.length) return local;
  const byId = new Map((local.packs || []).map((p) => [p.id, p]));
  for (const rp of remote.packs) {
    const pack = normalizeMediaPack(rp);
    if (!pack.id) continue;
    const existing = byId.get(pack.id);
    if (existing) {
      const remoteNewer = compareVersions(pack.version, existing.version) > 0;
      byId.set(pack.id, {
        ...existing,
        ...pack,
        remoteOnly: false,
        version: remoteNewer ? pack.version : (existing.version || pack.version),
        sha256: remoteNewer ? (pack.sha256 || existing.sha256) : (existing.sha256 || pack.sha256),
        remotePath: pack.remotePath || existing.remotePath,
        file: existing.file || pack.file,
        bytes: pack.bytes || existing.bytes,
        count: pack.count || existing.count,
      });
    } else {
      byId.set(pack.id, { ...pack, remoteOnly: true });
    }
  }
  return {
    ...local,
    cdnBaseUrl: remote.cdnBaseUrl || local.cdnBaseUrl,
    remoteCatalogUrl: remote.remoteCatalogUrl || local.remoteCatalogUrl,
    packs: [...byId.values()],
  };
}

async function loadConfigRaw() {
  return DiskAdapter.load('config.json').catch(() => ({}));
}

async function saveConfigPartial(patch) {
  const cfg = await loadConfigRaw();
  const next = { ...cfg, ...patch, updatedAt: Date.now() };
  await DiskAdapter.save('config.json', next, { silent: true });
  return next;
}

export function getInstalledMediaPacks(cfg = {}) {
  const raw = cfg?.installedMediaPacks;
  return raw && typeof raw === 'object' ? { ...raw } : {};
}

export function isMediaPackInstalled(cfg, packId) {
  return !!getInstalledMediaPacks(cfg)[String(packId || '').toLowerCase()]?.installedAt;
}

/** Estado de um pack vs catálogo (instalado / novo / atualização). */
export function getMediaPackInstallState(cfg, pack) {
  const id = String(pack?.id || '').toLowerCase();
  const state = getInstalledMediaPacks(cfg)[id];
  const installed = !!state?.installedAt;
  const installedVersion = String(state?.version || '');
  const catalogVersion = String(pack?.version || '1');
  const updateAvailable = installed
    && catalogVersion
    && compareVersions(catalogVersion, installedVersion) > 0;
  const isNew = !installed && !!pack?.remoteOnly;
  return {
    id,
    installed,
    installedVersion,
    catalogVersion,
    updateAvailable,
    isNew,
    installedAt: state?.installedAt || null,
  };
}

/** Resumo para badge/toast na aba Mídia. */
export function summarizeMediaPackNews(manifest, cfg = {}) {
  const packs = manifest?.packs || [];
  let installed = 0;
  let available = 0;
  let updates = 0;
  let news = 0;
  for (const p of packs) {
    const st = getMediaPackInstallState(cfg, p);
    if (st.installed) installed += 1;
    else available += 1;
    if (st.updateAvailable) updates += 1;
    if (st.isNew || st.updateAvailable) news += 1;
  }
  return {
    total: packs.length,
    installed,
    available,
    updates,
    news,
    hasNews: news > 0,
  };
}

export async function fetchMediaPackManifest({ force = false } = {}) {
  if (force) _manifestPromise = null;
  if (!_manifestPromise) {
    _manifestPromise = (async () => {
      let res = await fetch(MANIFEST_URL, { cache: 'no-store' });
      if (!res.ok) res = await fetch(MANIFEST_API, { cache: 'no-store' });
      if (!res.ok) throw new Error(`manifest_fetch_${res.status}`);
      const data = await res.json();
      let manifest = {
        version: Number(data?.version) || 1,
        totalItems: Number(data?.totalItems) || 0,
        cdnBaseUrl: String(data?.cdnBaseUrl || '').trim().replace(/\/+$/, ''),
        remoteCatalogUrl: String(data?.remoteCatalogUrl || '').trim(),
        packs: (Array.isArray(data?.packs) ? data.packs : [])
          .map(normalizeMediaPack)
          .filter((p) => p.id && p.file),
      };

      if (manifest.remoteCatalogUrl && isOnline()) {
        try {
          const remoteRes = await fetchCatalog(`${manifest.remoteCatalogUrl}${manifest.remoteCatalogUrl.includes('?') ? '&' : '?'}_=${Date.now()}`);
          if (remoteRes.ok) {
            manifest = mergeManifests(manifest, await remoteRes.json());
          }
        } catch { /* CDN opcional */ }
      }
      return manifest;
    })();
  }
  return _manifestPromise;
}

export function invalidateMediaPackManifest() {
  _manifestPromise = null;
}

export function formatPackSize(bytes) {
  const n = Number(bytes) || 0;
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(0)} KB`;
  return `${(n / (1024 * 1024)).toFixed(1)} MB`;
}

export async function installMediaPack(packId, { onProgress, force = false } = {}) {
  const id = String(packId || '').toLowerCase();
  const manifest = await fetchMediaPackManifest();
  const pack = manifest.packs.find((p) => p.id === id);
  if (!pack) throw new Error('pack_not_found:' + id);

  const cfg = await loadConfigRaw();
  if (!force && isMediaPackInstalled(cfg, id)) {
    return { alreadyInstalled: true, pack };
  }

  onProgress?.('install', 10);
  const localUrl = `/content/packs/media/${encodeURIComponent(pack.file)}`;
  const data = await installPackWithRemoteFallback({
    manifest,
    pack,
    localUrl,
    installUrl: '/api/content/packs/media/install',
    installBytesUrl: '/api/content/packs/media/install-bytes',
    onProgress,
  });

  if (!data?.ok) {
    throw new Error(formatHinarioPackError(new Error(data?.error || 'install_failed')));
  }

  onProgress?.('import', 70);
  const installed = getInstalledMediaPacks(cfg);
  installed[id] = {
    version: pack.version,
    name: pack.name,
    file: pack.file,
    count: data.count || pack.count,
    installedAt: Date.now(),
    files: Array.isArray(data.files) ? data.files : [],
    mediaIds: Array.isArray(data.mediaIds) ? data.mediaIds : [],
  };
  await saveConfigPartial({ installedMediaPacks: installed });

  onProgress?.('done', 100);
  return {
    pack,
    added: data.count || pack.count,
    filesWritten: data.filesWritten || 0,
    updated: force,
  };
}

export async function uninstallMediaPack(packId, { onProgress } = {}) {
  const id = String(packId || '').toLowerCase();
  const cfg = await loadConfigRaw();
  const state = getInstalledMediaPacks(cfg)[id];
  if (!state?.installedAt) {
    return { notInstalled: true };
  }

  const manifest = await fetchMediaPackManifest().catch(() => ({ packs: [] }));
  const pack = manifest.packs?.find((p) => p.id === id);

  onProgress?.('remove', 20);
  const res = await fetch('/api/content/packs/media/uninstall', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      packId: id,
      file: state.file || pack?.file || `${id}.zip`,
      files: Array.isArray(state.files) ? state.files : [],
      mediaIds: Array.isArray(state.mediaIds) ? state.mediaIds : [],
    }),
  });
  const data = await res.json().catch(() => ({}));

  // Limpa registro local mesmo se o servidor já não achou arquivos (estado órfão)
  const installed = getInstalledMediaPacks(cfg);
  delete installed[id];
  await saveConfigPartial({ installedMediaPacks: installed });

  if (!res.ok || !data.ok) {
    if (data.error === 'nothing_to_remove') {
      onProgress?.('done', 100);
      return { removed: 0, packId: id, clearedOrphan: true };
    }
    throw new Error(formatHinarioPackError(new Error(data.error || `uninstall_${res.status}`)));
  }

  onProgress?.('done', 100);
  return { removed: data.filesRemoved || 0, packId: id };
}

export function formatMediaPackError(err) {
  const raw = String(err?.message || err || '').trim();
  const mediaMessages = {
    nothing_to_remove: 'Nada para remover — o registro do pack foi limpo. Se ainda vir fundos, use Remover de novo ou reinstale o pack.',
    manifest_fetch_404: 'Catálogo de fundos não encontrado. Verifique model/content/packs/media/.',
    network_offline: 'Sem internet e o pack não está no disco. Conecte-se para baixar do catálogo online.',
  };
  for (const [code, msg] of Object.entries(mediaMessages)) {
    if (raw === code || raw.includes(code)) return msg;
  }
  return formatHinarioPackError(err);
}

export { compareVersions };
