/**
 * MediaLibrary — biblioteca de mídia profissional (shell v2).
 * Abas Imagem / Vídeo / Áudio / Molduras + prévia, favoritos e dropzone.
 */
import { generateId, getAllMedia, saveMedia, saveMediaFile, deleteMedia } from '../core/store.js';
import { filterMedia } from '../assets/asset-manager.js';
import { loadAmbientTracks } from '../core/ambient-audio.js';
import { uploadAudioFile } from '../core/storage/adapters/server-adapter.js';
import { renderMediaPreviewHtml } from './media-preview.js';
import { getConverterInfo } from '../core/media-convert.js';
import { openMediaPackInstaller } from './ui/media-pack-installer.js';
import {
  fetchMediaPackManifest,
  summarizeMediaPackNews,
  getInstalledMediaPacks,
  getMediaPackInstallState,
} from './media-pack-service.js';
import { DiskAdapter } from '../core/storage/adapters/disk-adapter.js';
import { faIcon } from '../core/fa-icons.js';
import { mountVirtualGrid, mountVirtualListHost } from '../core/performance/virtual-renderer.js';

const VIRTUAL_THRESHOLD = 20;

function esc(t) {
  const d = document.createElement('div');
  d.textContent = t ?? '';
  return d.innerHTML;
}

function escAttr(t) {
  return esc(t).replace(/"/g, '&quot;');
}

function formatBytes(n) {
  if (!n || n < 0) return '';
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(0)} KB`;
  return `${(n / (1024 * 1024)).toFixed(1)} MB`;
}

const TABS = [
  { id: 'sys-anim', label: 'Fundos animados', hint: 'Vídeo loop padrão' },
  { id: 'sys-still', label: 'Fundos estáticos', hint: 'Imagens padrão' },
  { id: 'image', label: 'Minhas imagens', hint: 'Biblioteca' },
  { id: 'video', label: 'Meus vídeos', hint: 'Clipes / loops' },
  { id: 'audio', label: 'Áudio', hint: 'Pasta audio/' },
  { id: 'frame', label: 'Molduras', hint: 'Designer' },
];

export class MediaLibrary {
  constructor(app) {
    this.app = app;
    this.tab = 'sys-anim';
    this.search = '';
    this.favoritesOnly = false;
    this.sort = 'name';
    this.selectedId = null;
    this.selectedAudioPath = null;
    this.audioTracks = [];
    this._previewAudio = null;
    this._previewMode = 'lyrics';
    this._convertJobs = [];
    this._virtualGrid = null;
    this._virtualAudio = null;
    this._gridDelegated = false;
  }

  mount(container) {
    this.root = container;
    this.renderShell();
    this.refresh();
    void this.refreshPackButton();
  }

  openPackInstaller() {
    void openMediaPackInstaller({
      toast: (msg, type) => this.app.toast?.(msg, type),
      onInstalled: () => {
        this.refresh();
        void this.refreshPackButton();
      },
    });
  }

  async refreshPackButton() {
    const btn = this.root?.querySelector('#ml-install-sys-packs');
    if (!btn) return;
    try {
      const [manifest, cfg] = await Promise.all([
        fetchMediaPackManifest({ force: true }),
        DiskAdapter.load('config.json').catch(() => ({})),
      ]);
      const summary = summarizeMediaPackNews(manifest, cfg);
      const installedMap = getInstalledMediaPacks(cfg);
      const anyInstalled = Object.keys(installedMap).length > 0 || summary.installed > 0;
      btn.textContent = anyInstalled ? 'Gerenciar fundos…' : 'Escolher fundos…';
      btn.title = anyInstalled
        ? `${summary.installed}/${summary.total} packs instalados — instalar, atualizar ou remover`
        : 'Instalar packs de fundos (offline + catálogo online)';
      btn.classList.toggle('has-pack-news', summary.hasNews);
      let badge = btn.querySelector('.media-pack-news-dot');
      if (summary.hasNews) {
        if (!badge) {
          badge = document.createElement('span');
          badge.className = 'media-pack-news-dot';
          badge.setAttribute('aria-hidden', 'true');
          btn.appendChild(badge);
        }
        if (!this._packNewsToasted) {
          this._packNewsToasted = true;
          const parts = [];
          if (summary.updates) parts.push(`${summary.updates} atualização(ões) de pack`);
          const newPacks = (manifest.packs || []).filter((p) => getMediaPackInstallState(cfg, p).isNew).length;
          if (newPacks) parts.push(`${newPacks} pack(s) novo(s) online`);
          if (parts.length) {
            this.app.toast?.(`Fundos: ${parts.join(' · ')} — abra Gerenciar fundos`, 'info');
          }
        }
      } else if (badge) {
        badge.remove();
      }
    } catch {
      btn.textContent = 'Fundos padrão…';
    }
  }

  counts() {
    const list = this.app.mediaList || [];
    const sysAnim = list.filter((m) => m.system && (m.category === 'fundo-animado' || (m.kind === 'video' && m.system))).length;
    const sysStill = list.filter((m) => m.system && (m.category === 'fundo-estatico' || (m.kind === 'image' && m.system && m.category !== 'frame'))).length;
    const images = list.filter((m) => !m.system && m.kind === 'image' && (m.category || 'image') !== 'frame').length;
    const videos = list.filter((m) => !m.system && m.kind === 'video' && (m.category || '') !== 'frame').length;
    const frames = list.filter((m) => (m.category || '') === 'frame').length;
    return {
      'sys-anim': sysAnim,
      'sys-still': sysStill,
      image: images,
      video: videos,
      audio: this.audioTracks.length,
      frame: frames,
      total: sysAnim + sysStill + images + videos + frames + this.audioTracks.length,
      favorites: list.filter((m) => m.favorite).length,
    };
  }

  renderShell() {
    this.root.innerHTML = `
      <div class="view-panel is-active media-library-view media-shell-root">
        <div class="media-shell">
          <header class="media-shell-header">
            <div class="media-shell-titles">
              <h2>Mídia</h2>
              <p class="media-shell-lead">Fundos padrão do sistema (animados e estáticos) + sua biblioteca. Envie qualquer formato — o conversor gera MP4/WebP.</p>
            </div>
            <div class="media-shell-meta">
              <span class="media-stat-chip" id="ml-stat-total">0 itens</span>
              <span class="media-stat-chip media-stat-chip--muted" id="ml-stat-fav">0 favoritos</span>
              <div class="media-lib-uploads" id="ml-uploads">
                <button type="button" class="btn btn-ghost btn-sm" id="ml-install-sys-packs" title="Instalar ou gerenciar packs de fundos">Escolher fundos…</button>
                <label class="btn btn-primary media-upload-btn" title="Qualquer imagem/vídeo — convertido automaticamente">
                  Enviar
                  <input type="file" id="ml-upload-av" accept="image/*,video/*,.gif,.mov,.mkv,.avi,.webp" multiple hidden />
                </label>
                <label class="btn btn-secondary media-upload-btn" title="Áudio para pasta audio/">
                  + Áudio
                  <input type="file" id="ml-upload-audio" accept="audio/mpeg,audio/wav,audio/ogg,audio/mp4,audio/flac,.mp3,.wav,.ogg,.m4a,.flac" multiple hidden />
                </label>
                <label class="btn btn-secondary media-upload-btn" title="Moldura PNG/WebP">
                  + Moldura
                  <input type="file" id="ml-upload-frame" accept="image/png,image/webp,image/jpeg" multiple hidden />
                </label>
              </div>
            </div>
          </header>

          <div class="media-shell-body">
            <nav class="media-rail" id="ml-tabs" aria-label="Tipos de mídia"></nav>

            <div class="media-workspace">
              <div class="media-toolbar">
                <div class="media-toolbar-search">
                  <input type="search" id="ml-search" class="media-lib-search" placeholder="Buscar por nome ou tag…" autocomplete="off" />
                </div>
                <div class="media-toolbar-filters">
                  <button type="button" class="media-filter-btn" id="ml-fav-toggle" title="Só favoritos" aria-pressed="false">Favoritos</button>
                  <select id="ml-sort" class="media-sort-select" title="Ordenar">
                    <option value="name">Nome A–Z</option>
                    <option value="recent">Mais recentes</option>
                  </select>
                </div>
              </div>

              <div class="media-dropzone" id="ml-dropzone" tabindex="0">
                <div class="media-dropzone-inner">
                  <strong>Arraste arquivos aqui</strong>
                  <span>Qualquer formato — convertemos para MP4 H.264 muted ou WebP (leve e estável)</span>
                </div>
                <div class="media-convert-queue" id="ml-convert-queue" hidden></div>
              </div>

              <div class="media-split">
                <div class="media-grid-host" id="ml-grid-host">
                  <div class="media-grid" id="ml-grid"></div>
                </div>
                <aside class="media-inspector" id="ml-inspector" aria-live="polite">
                  <div class="media-inspector-empty">
                    <p class="media-inspector-empty-title">Seleção</p>
                    <p class="muted">Clique em um item para detalhar. Use <strong>Projetar</strong> — o resultado aparece no painel <em>Projetor</em> à direita, em tempo real.</p>
                  </div>
                </aside>
              </div>
            </div>
          </div>
        </div>
      </div>`;

    this.bindShellEvents();
    this.renderRail();
    this.bindGridDelegation();
  }

  bindShellEvents() {
    this.root.querySelector('#ml-search')?.addEventListener('input', (e) => {
      this.search = e.target.value.trim().toLowerCase();
      this.renderGrid();
    });

    this.root.querySelector('#ml-fav-toggle')?.addEventListener('click', (btnEv) => {
      this.favoritesOnly = !this.favoritesOnly;
      const btn = btnEv.currentTarget;
      btn.classList.toggle('is-active', this.favoritesOnly);
      btn.setAttribute('aria-pressed', this.favoritesOnly ? 'true' : 'false');
      this.renderGrid();
    });

    this.root.querySelector('#ml-sort')?.addEventListener('change', (e) => {
      this.sort = e.target.value || 'name';
      this.renderGrid();
    });

    this.root.querySelector('#ml-upload-av')?.addEventListener('change', (e) => this.handleAvUpload(e));
    this.root.querySelector('#ml-upload-frame')?.addEventListener('change', (e) => this.handleFrameUpload(e));
    this.root.querySelector('#ml-upload-audio')?.addEventListener('change', (e) => this.handleAudioUpload(e));

    this.root.querySelector('#ml-install-sys-packs')?.addEventListener('click', () => {
      this.openPackInstaller();
    });

    const dz = this.root.querySelector('#ml-dropzone');
    if (dz) {
      dz.addEventListener('dragover', (e) => {
        e.preventDefault();
        e.stopPropagation();
        dz.classList.add('is-dragover');
      });
      dz.addEventListener('dragleave', (e) => {
        e.preventDefault();
        if (!dz.contains(e.relatedTarget)) dz.classList.remove('is-dragover');
      });
      dz.addEventListener('drop', (e) => {
        e.preventDefault();
        dz.classList.remove('is-dragover');
        this.handleDrop(e.dataTransfer?.files);
      });
    }
  }

  renderRail() {
    const rail = this.root?.querySelector('#ml-tabs');
    if (!rail) return;
    const c = this.counts();
    rail.innerHTML = TABS.map((t) => `
      <button type="button" class="media-rail-item ${this.tab === t.id ? 'is-active' : ''}" data-tab="${t.id}">
        <span class="media-rail-label">${t.label}</span>
        <span class="media-rail-hint">${t.hint}</span>
        <span class="media-rail-count">${c[t.id] ?? 0}</span>
      </button>`).join('');

    rail.querySelectorAll('.media-rail-item').forEach((btn) => {
      btn.onclick = () => {
        this.tab = btn.dataset.tab;
        this.selectedId = null;
        this.selectedAudioPath = null;
        this.stopPreviewAudio();
        this.renderRail();
        this.renderGrid();
        this.renderInspector();
      };
    });
  }

  updateStats() {
    const c = this.counts();
    const total = this.root?.querySelector('#ml-stat-total');
    const fav = this.root?.querySelector('#ml-stat-fav');
    if (total) total.textContent = `${c.total} ${c.total === 1 ? 'item' : 'itens'}`;
    if (fav) fav.textContent = `${c.favorites} favorito${c.favorites === 1 ? '' : 's'}`;
  }

  async refresh() {
    this.app.mediaList = await getAllMedia();
    this.audioTracks = await loadAmbientTracks();
    this.updateStats();
    this.renderRail();
    this.renderGrid();
    this.renderInspector();
  }

  filterItems() {
    const q = this.search;
    if (this.tab === 'audio') {
      let items = this.audioTracks.filter((t) =>
        !q || (t.name || t.fileName || '').toLowerCase().includes(q)
      );
      if (this.sort === 'name') {
        items = [...items].sort((a, b) =>
          String(a.name || a.fileName || '').localeCompare(String(b.name || b.fileName || ''), 'pt')
        );
      }
      return items;
    }

    let items = filterMedia(this.app.mediaList, {
      kind: this.tab === 'video' ? 'video' : this.tab === 'image' ? 'image' : null,
      query: this.search,
      favoritesOnly: this.favoritesOnly,
    }).filter((m) => {
      const cat = m.category || (m.kind === 'video' ? 'video' : 'image');
      if (this.tab === 'sys-anim') {
        return !!m.system && (cat === 'fundo-animado' || cat === 'loop' || (m.kind === 'video' && cat !== 'frame'));
      }
      if (this.tab === 'sys-still') {
        return !!m.system && (cat === 'fundo-estatico' || cat === 'background' || (m.kind === 'image' && cat !== 'frame'));
      }
      if (m.system) return false;
      if (this.tab === 'frame') return cat === 'frame';
      if (this.tab === 'video') return m.kind === 'video' && cat !== 'frame';
      if (this.tab === 'image') return m.kind === 'image' && cat !== 'frame';
      return false;
    });

    if (this.sort === 'recent') {
      items = [...items].sort((a, b) => (b.updatedAt || b.createdAt || 0) - (a.updatedAt || a.createdAt || 0));
    } else {
      items = [...items].sort((a, b) => String(a.name || '').localeCompare(String(b.name || ''), 'pt'));
    }
    return items;
  }

  stopPreviewAudio() {
    if (this._previewAudio) {
      try { this._previewAudio.pause(); } catch { /* ignore */ }
      this._previewAudio = null;
    }
  }

  /** Delegação de eventos — estável com virtualização. */
  bindGridDelegation() {
    if (this._gridDelegated) return;
    this._gridDelegated = true;
    const host = this.root?.querySelector('#ml-grid-host');
    if (!host) return;
    host.addEventListener('click', (e) => {
      const card = e.target.closest('.media-card');
      if (!card || !host.contains(card)) return;
      if (e.target.closest('button, input')) {
        const btn = e.target.closest('button');
        if (!btn) return;
        if (btn.classList.contains('ml-audio-play')) {
          e.stopPropagation();
          const path = card.dataset.path;
          this.stopPreviewAudio();
          this._previewAudio = new Audio(`/${path}`);
          this._previewAudio.play().catch(() => this.app.toast?.('Erro ao tocar áudio', 'warn'));
          return;
        }
        if (btn.classList.contains('ml-audio-add')) {
          e.stopPropagation();
          const path = card.dataset.path;
          const name = card.querySelector('.media-card-name')?.textContent || 'Áudio';
          void this.addAudioToProgram(path, name);
          return;
        }
        if (btn.classList.contains('ml-project')) {
          e.stopPropagation();
          void this.projectMedia(card.dataset.id);
          return;
        }
        if (btn.classList.contains('ml-bg')) {
          e.stopPropagation();
          void this.applyAsLyricsBackground(card.dataset.id);
          return;
        }
        if (btn.classList.contains('ml-add')) {
          e.stopPropagation();
          void this.addMediaToProgram(card.dataset.id);
          return;
        }
        if (btn.classList.contains('ml-fav')) {
          e.stopPropagation();
          void this.toggleFavorite(card.dataset.id);
          return;
        }
        if (btn.classList.contains('ml-del')) {
          e.stopPropagation();
          void this.deleteMediaCard(card.dataset.id);
          return;
        }
        return;
      }
      if (card.classList.contains('media-card-audio')) this.selectAudioCard(card.dataset.path);
      else this.selectMediaCard(card.dataset.id);
    });
    host.addEventListener('keydown', (e) => {
      const card = e.target.closest('.media-card');
      if (!card || (e.key !== 'Enter' && e.key !== ' ')) return;
      e.preventDefault();
      if (card.classList.contains('media-card-audio')) this.selectAudioCard(card.dataset.path);
      else this.selectMediaCard(card.dataset.id);
    });
    host.addEventListener('change', (e) => {
      const input = e.target.closest('.media-card-rename');
      if (!input) return;
      void this.renameMediaCard(input);
    });
  }

  async deleteMediaCard(id) {
    const item = this.app.mediaList.find((x) => x.id === id);
    if (item?.system || item?.readonly) {
      this.app.toast?.('Mídia do sistema não pode ser excluída', 'warn');
      return;
    }
    if (!confirm('Excluir esta mídia?')) return;
    try {
      await deleteMedia(id);
      if (this.selectedId === id) this.selectedId = null;
      await this.refresh();
      this.app.toast?.('Mídia excluída');
    } catch (err) {
      this.app.toast?.(err?.message || 'Não foi possível excluir', 'warn');
    }
  }

  async renameMediaCard(input) {
    const id = input.closest('.media-card')?.dataset.id;
    const m = this.app.mediaList.find((x) => x.id === id);
    if (!m || m.system || m.readonly) return;
    m.name = input.value.trim() || m.name;
    m.updatedAt = Date.now();
    await saveMedia(m);
    this.app.toast?.('Nome atualizado');
    this.renderInspector();
    this.updateStats();
  }

  disposeVirtualGrid() {
    this._virtualGrid?.dispose?.();
    this._virtualGrid = null;
    this._virtualAudio?.dispose?.();
    this._virtualAudio = null;
  }

  renderMediaCardHtml(m) {
    const src = m.src || m.dataUrl || '';
    const selected = this.selectedId === m.id ? 'is-selected' : '';
    let badge = '';
    if (m.system && m.kind === 'video') badge = '<span class="media-badge media-badge-system">ANIMADO</span>';
    else if (m.system && m.kind === 'image') badge = '<span class="media-badge media-badge-system">ESTÁTICO</span>';
    else if (m.category === 'frame') badge = '<span class="media-badge media-badge-frame">MOLDURA</span>';
    else if (m.kind === 'video') badge = '<span class="media-badge">VÍDEO</span>';
    return `
      <article class="media-card ${selected}" data-id="${m.id}" tabindex="0" role="button">
        <div class="media-thumb">
          ${m.kind === 'video'
            ? `<video src="${escAttr(src)}" muted preload="metadata" loop playsinline></video>`
            : `<img src="${escAttr(src)}" alt="" loading="lazy" decoding="async" onerror="this.style.opacity='0'" />`}
          ${badge}
          ${m.favorite ? '<span class="media-fav-mark" title="Favorito">★</span>' : ''}
          <div class="media-card-overlay">
            <button type="button" class="btn btn-secondary btn-sm ml-bg" title="Usar como fundo da letra">Fundo</button>
            <button type="button" class="btn btn-secondary btn-sm ml-project" title="Projetar agora">Projetar</button>
            <button type="button" class="btn btn-primary btn-sm ml-add" title="Adicionar ao programa">+ Programa</button>
          </div>
        </div>
        <div class="media-card-info">
          <input class="media-card-rename" value="${escAttr(m.name)}" title="Renomear" ${m.system || m.readonly ? 'readonly' : ''} />
          <div class="media-card-actions">
            <button type="button" class="btn btn-secondary btn-icon ml-fav ${m.favorite ? 'is-on' : ''}" title="Favorito">${m.favorite ? '★' : '☆'}</button>
            ${m.system || m.readonly ? '' : '<button type="button" class="btn btn-danger btn-icon ml-del" title="Excluir">×</button>'}
          </div>
        </div>
      </article>`;
  }

  renderAudioCardHtml(t) {
    const path = t.path || '';
    const selected = this.selectedAudioPath === path ? 'is-selected' : '';
    return `
      <article class="media-card media-card-audio ${selected}" data-path="${escAttr(path)}" tabindex="0" role="button">
        <div class="media-thumb media-thumb-audio">
          <span class="media-audio-glyph" aria-hidden="true"></span>
          <span class="media-badge">ÁUDIO</span>
        </div>
        <div class="media-card-info">
          <div class="media-card-name" title="${escAttr(t.name || t.fileName)}">${esc(t.name || t.fileName)}</div>
          <div class="media-card-actions">
            <button type="button" class="btn btn-secondary btn-icon ml-audio-play" title="Ouvir">${faIcon('play')}</button>
            <button type="button" class="btn btn-secondary btn-icon ml-audio-add" title="Add programa">+</button>
          </div>
        </div>
      </article>`;
  }

  /** Atualiza só a classe de seleção — sem recriar thumbs/vídeos. */
  syncGridSelection() {
    const host = this.root?.querySelector('#ml-grid-host');
    if (!host) return;
    host.querySelectorAll('.media-card.is-selected').forEach((c) => c.classList.remove('is-selected'));
    if (this.tab === 'audio' && this.selectedAudioPath) {
      const card = [...host.querySelectorAll('.media-card-audio')].find(
        (c) => c.dataset.path === this.selectedAudioPath
      );
      card?.classList.add('is-selected');
      return;
    }
    if (this.selectedId) {
      host.querySelector(`.media-card[data-id="${CSS.escape(this.selectedId)}"]`)?.classList.add('is-selected');
    }
  }

  selectMediaCard(id) {
    this.selectedId = id;
    this.selectedAudioPath = null;
    this.syncGridSelection();
    this.renderInspector();
  }

  selectAudioCard(path) {
    this.selectedAudioPath = path;
    this.selectedId = null;
    this.syncGridSelection();
    this.renderInspector();
  }

  renderGrid() {
    const host = this.root?.querySelector('#ml-grid-host');
    const grid = this.root?.querySelector('#ml-grid');
    if (!host || !grid) return;

    this.disposeVirtualGrid();
    const items = this.filterItems();

    if (this.tab === 'audio') {
      if (!items.length) {
        host.innerHTML = '';
        grid.style.display = '';
        grid.innerHTML = `
          <div class="media-empty">
            <p class="media-empty-title">Nenhum áudio</p>
            <p class="muted">Envie MP3, WAV, OGG ou FLAC — arquivos vão para a pasta <code>audio/</code>.</p>
            <label class="btn btn-primary media-upload-btn">Enviar áudio
              <input type="file" accept="audio/mpeg,audio/wav,audio/ogg,audio/mp4,audio/flac,.mp3,.wav,.ogg,.m4a,.flac" multiple hidden data-ml-empty-audio />
            </label>
          </div>`;
        host.appendChild(grid);
        grid.querySelector('[data-ml-empty-audio]')?.addEventListener('change', (e) => this.handleAudioUpload(e));
        return;
      }
      if (items.length >= VIRTUAL_THRESHOLD) {
        host.innerHTML = '';
        grid.style.display = 'none';
        this._virtualAudio = mountVirtualListHost(host, {
          items,
          rowHeight: 112,
          renderRow: (t) => this.renderAudioCardHtml(t),
        });
        return;
      }
      host.innerHTML = '';
      grid.style.display = '';
      grid.innerHTML = items.map((t) => this.renderAudioCardHtml(t)).join('');
      host.appendChild(grid);
      return;
    }

    if (!items.length) {
      const labels = {
        'sys-anim': 'fundo animado',
        'sys-still': 'fundo estático',
        image: 'imagem',
        video: 'vídeo',
        frame: 'moldura',
      };
      host.innerHTML = '';
      grid.style.display = '';
      grid.innerHTML = `
        <div class="media-empty">
          <p class="media-empty-title">Nenhuma ${labels[this.tab] || 'mídia'}</p>
          <p class="muted">${(this.tab === 'sys-anim' || this.tab === 'sys-still')
            ? 'Os fundos padrão ainda não foram instalados. Use Escolher fundos… no topo (offline ou catálogo online).'
            : this.favoritesOnly
              ? 'Nenhum favorito nesta aba. Desative o filtro Favoritos.'
              : 'Arraste arquivos para a área acima ou use Enviar — o conversor gera MP4/WebP automaticamente.'}</p>
          ${(this.tab === 'sys-anim' || this.tab === 'sys-still')
            ? '<button type="button" class="btn btn-primary btn-sm" id="ml-empty-install-packs">Escolher fundos…</button>'
            : ''}
        </div>`;
      grid.querySelector('#ml-empty-install-packs')?.addEventListener('click', () => {
        this.openPackInstaller();
      });
      host.appendChild(grid);
      return;
    }

    if (items.length >= VIRTUAL_THRESHOLD) {
      host.innerHTML = '';
      grid.style.display = 'none';
      this._virtualGrid = mountVirtualGrid(host, {
        items,
        rowHeight: 210,
        minColWidth: 168,
        gap: 14,
        renderCell: (m) => this.renderMediaCardHtml(m),
      });
      return;
    }

    host.innerHTML = '';
    grid.style.display = '';
    grid.innerHTML = items.map((m) => this.renderMediaCardHtml(m)).join('');
    host.appendChild(grid);
  }

  renderInspector() {
    const el = this.root?.querySelector('#ml-inspector');
    if (!el) return;

    if (this.tab === 'audio' && this.selectedAudioPath) {
      const t = this.audioTracks.find((x) => x.path === this.selectedAudioPath);
      if (!t) {
        el.innerHTML = this._inspectorEmpty();
        return;
      }
      const name = t.name || t.fileName || 'Áudio';
      el.innerHTML = `
        <div class="media-inspector-body">
          <div class="media-inspector-preview media-inspector-preview--audio">
            <span class="media-audio-glyph media-audio-glyph--lg" aria-hidden="true"></span>
          </div>
          <div class="media-inspector-meta">
            <h3 class="media-inspector-title">${esc(name)}</h3>
            <p class="media-inspector-sub">Áudio · <code>${esc(t.path || '')}</code></p>
          </div>
          <div class="media-inspector-actions">
            <button type="button" class="btn btn-secondary" id="ml-insp-play">Ouvir</button>
            <button type="button" class="btn btn-primary" id="ml-insp-add">+ Programa</button>
          </div>
        </div>`;
      el.querySelector('#ml-insp-play')?.addEventListener('click', () => {
        this.stopPreviewAudio();
        this._previewAudio = new Audio(`/${t.path}`);
        this._previewAudio.play().catch(() => this.app.toast?.('Erro ao tocar áudio', 'warn'));
      });
      el.querySelector('#ml-insp-add')?.addEventListener('click', () => this.addAudioToProgram(t.path, name));
      return;
    }

    const m = this.app.mediaList?.find((x) => x.id === this.selectedId);
    if (!m) {
      el.innerHTML = this._inspectorEmpty();
      return;
    }

    const src = m.src || m.dataUrl || '';
    const kindLabel = m.system
      ? 'Sistema'
      : m.category === 'frame' ? 'Moldura' : m.kind === 'video' ? 'Vídeo' : 'Imagem';
    const onAir = this.app._mediaOnAir?.mediaId === m.id;
    const sizeLabel = m.sizeBytes
      ? formatBytes(m.sizeBytes)
      : (m.inputBytes ? `${formatBytes(m.inputBytes)} → canônico` : '');
    el.innerHTML = `
      <div class="media-inspector-body">
        ${renderMediaPreviewHtml({
          src,
          kind: m.kind,
          mode: this._previewMode,
          title: m.name,
        })}
        <div class="media-preview-modes" role="group" aria-label="Modo de prévia">
          <button type="button" class="media-mode-btn ${this._previewMode === 'media' ? 'is-active' : ''}" data-mode="media">Só mídia</button>
          <button type="button" class="media-mode-btn ${this._previewMode === 'lyrics' ? 'is-active' : ''}" data-mode="lyrics">+ Letra</button>
          <button type="button" class="media-mode-btn ${this._previewMode === 'safe' ? 'is-active' : ''}" data-mode="safe">+ Safe area</button>
        </div>
        <div class="media-inspector-meta">
          <h3 class="media-inspector-title">${esc(m.name || 'Sem nome')}</h3>
          <p class="media-inspector-sub">${kindLabel}${m.mimeType ? ` · ${esc(m.mimeType)}` : ''}${sizeLabel ? ` · ${sizeLabel}` : ''}</p>
          ${onAir ? '<p class="media-on-air-chip">No projetor agora</p>' : ''}
          ${(m.tags || []).length ? `<div class="media-tag-row">${m.tags.map((t) => `<span class="media-tag">${esc(t)}</span>`).join('')}</div>` : ''}
        </div>
        <div class="media-inspector-actions">
          <button type="button" class="btn btn-secondary" id="ml-insp-bg">Usar como fundo</button>
          <button type="button" class="btn ${onAir ? 'btn-live' : 'btn-secondary'}" id="ml-insp-project">${onAir ? '● No ar' : 'Projetar'}</button>
          <button type="button" class="btn btn-primary" id="ml-insp-add">+ Programa</button>
          <button type="button" class="btn btn-secondary ${m.favorite ? 'is-on' : ''}" id="ml-insp-fav">${m.favorite ? '★ Favorito' : '☆ Favoritar'}</button>
          ${m.system || m.readonly ? '' : '<button type="button" class="btn btn-danger btn-sm" id="ml-insp-del">Excluir</button>'}
        </div>
        <p class="form-hint media-inspector-hint">Prévia com letra simula o projetor. O resultado ao vivo fica no painel <strong>Projetor</strong>.</p>
      </div>`;

    el.querySelectorAll('.media-mode-btn').forEach((btn) => {
      btn.addEventListener('click', () => {
        this._previewMode = btn.dataset.mode || 'lyrics';
        this.renderInspector();
      });
    });
    el.querySelector('#ml-insp-bg')?.addEventListener('click', () => this.applyAsLyricsBackground(m.id));
    el.querySelector('#ml-insp-project')?.addEventListener('click', () => this.projectMedia(m.id));
    el.querySelector('#ml-insp-add')?.addEventListener('click', () => this.addMediaToProgram(m.id));
    el.querySelector('#ml-insp-fav')?.addEventListener('click', () => this.toggleFavorite(m.id));
    el.querySelector('#ml-insp-del')?.addEventListener('click', async () => {
      if (!confirm('Excluir esta mídia?')) return;
      try {
        await deleteMedia(m.id);
        this.selectedId = null;
        await this.refresh();
      } catch (err) {
        this.app.toast?.(err?.message || 'Não foi possível excluir', 'warn');
      }
    });
  }

  applyAsLyricsBackground(id) {
    const m = this.app.mediaList.find((x) => x.id === id);
    if (!m) return;
    const song = this.app.selectedSong || this.app.currentSong;
    if (song?.style) {
      song.style.backgroundMediaId = id;
      song.style.backgroundPreset = null;
      this.app.saveSong?.(song);
      this.app.toast?.(`Fundo da letra: ${m.name}`);
      this.app.refreshInspector?.();
      return;
    }
    // Sem música selecionada — guarda preferência de sessão e avisa
    this.app._pendingLyricsBgMediaId = id;
    this.app.toast?.('Selecione uma música para aplicar o fundo, ou use no editor de letra', 'info');
  }

  _inspectorEmpty() {
    return `
      <div class="media-inspector-empty">
        <p class="media-inspector-empty-title">Seleção</p>
        <p class="muted">Clique em um item para detalhar. <strong>Projetar</strong> envia ao painel Projetor (direita).</p>
      </div>`;
  }

  projectMedia(id) {
    const m = this.app.mediaList.find((x) => x.id === id);
    if (!m) return;
    if (this.app.bibleReader?.isLive) {
      this.app.bibleReader.stopSession?.();
    }
    const slide = {
      type: 'media',
      kind: m.kind,
      src: m.src || m.dataUrl,
      title: m.name,
      loop: true,
      mediaId: m.id,
    };
    this.app.setMediaOnAir?.(slide);
    this.app.sendSlideToProjector(slide, true);
    this.app.refreshStage?.({ skipInspector: true });
    this.app.toast?.('Mídia no projetor');
    this.renderInspector();
    this.renderGrid();
  }

  async addMediaToProgram(id) {
    const m = this.app.mediaList.find((x) => x.id === id);
    if (!m) return;
    this.app.program.items.push({
      id: generateId(),
      type: 'media',
      slideType: 'media',
      title: m.name,
      mediaId: m.id,
      data: { loop: true },
    });
    await this.app.persistProgram();
    this.app.toast?.('Adicionado ao programa');
  }

  async addAudioToProgram(path, name) {
    this.app.program.items.push({
      id: generateId(),
      type: 'media-audio',
      slideType: 'media-audio',
      title: name,
      data: { audioPath: path, loop: false },
    });
    await this.app.persistProgram();
    this.app.toast?.('Áudio adicionado ao programa');
  }

  async toggleFavorite(id) {
    const m = this.app.mediaList.find((x) => x.id === id);
    if (!m) return;
    m.favorite = !m.favorite;
    m.updatedAt = Date.now();
    await saveMedia(m);
    this.updateStats();
    this.renderRail();
    this.renderGrid();
    this.renderInspector();
  }

  async handleDrop(fileList) {
    const files = [...(fileList || [])];
    if (!files.length) return;
    const imagesVideos = files.filter((f) =>
      f.type.startsWith('image/') || f.type.startsWith('video/') || /\.(gif|mov|mkv|avi|webm|mp4|webp|png|jpe?g|bmp|tiff?)$/i.test(f.name)
    );
    const audios = files.filter((f) => f.type.startsWith('audio/'));
    if (this.tab === 'frame') {
      await this._saveFrames(imagesVideos.filter((f) => f.type.startsWith('image/') || /\.(png|webp|jpe?g)$/i.test(f.name)));
    } else if (imagesVideos.length) {
      await this._convertUploadBatch(imagesVideos);
    }
    if (audios.length) {
      let ok = 0;
      for (const f of audios) {
        if (await uploadAudioFile(f)) ok += 1;
      }
      this.app.toast?.(`${ok} áudio(s) enviado(s)`);
    }
    await this.refresh();
  }

  async handleAvUpload(e) {
    const files = [...e.target.files];
    await this._convertUploadBatch(files);
    await this.refresh();
    e.target.value = '';
  }

  _renderConvertQueue() {
    const el = this.root?.querySelector('#ml-convert-queue');
    if (!el) return;
    if (!this._convertJobs.length) {
      el.hidden = true;
      el.innerHTML = '';
      return;
    }
    el.hidden = false;
    el.innerHTML = this._convertJobs.map((j) => `
      <div class="media-convert-job">
        <span class="media-convert-name">${esc(j.name)}</span>
        <span class="media-convert-status">${esc(j.status)} ${j.progress || 0}%</span>
        <div class="media-convert-bar"><i style="width:${Math.max(4, j.progress || 0)}%"></i></div>
      </div>`).join('');
  }

  async _convertUploadBatch(files) {
    if (!files?.length) return;
    const info = await getConverterInfo();
    if (!info?.available) {
      this.app.toast?.('Conversor indisponível — coloque ffmpeg em app/tools/ffmpeg', 'error');
      return;
    }
    let ok = 0;
    for (const f of files) {
      const jobUi = { name: f.name, status: 'queued', progress: 0 };
      this._convertJobs.push(jobUi);
      this._renderConvertQueue();
      try {
        await saveMediaFile(f, {
          onProgress: (p) => {
            jobUi.status = p.status || 'running';
            jobUi.progress = p.progress || 0;
            this._renderConvertQueue();
          },
        });
        ok += 1;
        jobUi.status = 'done';
        jobUi.progress = 100;
      } catch (err) {
        jobUi.status = 'error';
        this.app.toast?.(err?.message || `Falha: ${f.name}`, 'error');
      }
      this._renderConvertQueue();
    }
    if (ok) this.app.toast?.(`${ok} arquivo(s) convertido(s) para o formato SOMOSUM`);
    setTimeout(() => {
      this._convertJobs = [];
      this._renderConvertQueue();
    }, 2500);
  }

  async _saveFrames(files) {
    for (const f of files) {
      try {
        await saveMediaFile(f, { category: 'frame' });
      } catch (err) {
        this.app.toast?.(err?.message || `Falha na moldura ${f.name}`, 'error');
      }
    }
    if (files.length) this.app.toast?.(`${files.length} moldura(s) processada(s)`);
  }

  async handleFrameUpload(e) {
    await this._saveFrames([...e.target.files]);
    await this.refresh();
    e.target.value = '';
  }

  async handleAudioUpload(e) {
    const files = [...e.target.files];
    let ok = 0;
    for (const f of files) {
      if (await uploadAudioFile(f)) ok += 1;
    }
    this.audioTracks = await loadAmbientTracks();
    this.updateStats();
    this.renderRail();
    this.renderGrid();
    this.app.toast?.(`${ok} áudio(s) enviado(s) para pasta audio/`);
    e.target.value = '';
  }
}
