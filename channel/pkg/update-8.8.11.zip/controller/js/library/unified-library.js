/**
 * Biblioteca unificada — fachada com abas sobre worship / bible / media.
 */
import { mountTabs } from '../ui/kit/tabs.js';
import { WorshipLibrary } from '../worship/worship-library.js';
import { renderBibleView } from '../bible/bible-reader.js';

const TABS = [
  { id: 'songs', label: 'Músicas' },
  { id: 'bible', label: 'Bíblias' },
  { id: 'images', label: 'Imagens' },
  { id: 'videos', label: 'Vídeos' },
  { id: 'audio', label: 'Áudio' },
  { id: 'templates', label: 'Templates' },
  { id: 'playlists', label: 'Playlists' },
];

const RECENT_KEY = 'somosum.library.recent';
const FAV_KEY = 'somosum.library.favorites';

function readJson(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch {
    return fallback;
  }
}

function writeJson(key, value) {
  try { localStorage.setItem(key, JSON.stringify(value)); } catch { /* ignore */ }
}

export function getLibraryRecents() {
  return readJson(RECENT_KEY, []);
}

export function pushLibraryRecent(entry) {
  const list = getLibraryRecents().filter((x) => x.id !== entry.id);
  list.unshift({ ...entry, ts: Date.now() });
  writeJson(RECENT_KEY, list.slice(0, 24));
}

export function getLibraryFavorites() {
  return readJson(FAV_KEY, []);
}

export function toggleLibraryFavorite(entry) {
  const list = getLibraryFavorites();
  const idx = list.findIndex((x) => x.id === entry.id);
  if (idx >= 0) list.splice(idx, 1);
  else list.unshift(entry);
  writeJson(FAV_KEY, list.slice(0, 48));
  return list;
}

export class UnifiedLibrary {
  constructor(root, app, opts = {}) {
    this.root = root;
    this.app = app;
    this.opts = opts;
    this.tab = opts.initialTab || 'songs';
    this._child = null;
    this.mount();
  }

  mount() {
    this.root.className = 'unified-library su-panel';
    this.root.innerHTML = `
      <header class="unified-library__head">
        <div>
          <p class="somosum-kicker">Biblioteca</p>
          <h2 class="somosum-display" style="margin:0;font-size:var(--text-xl)">Conteúdo do culto</h2>
        </div>
        <div class="su-search unified-library__search">
          <span aria-hidden="true">⌕</span>
          <input type="search" id="ul-search" placeholder="Filtrar nesta aba…" autocomplete="off" />
        </div>
      </header>
      <div class="unified-library__chips" id="ul-chips"></div>
      <div id="ul-tabs"></div>
      <div class="unified-library__body" id="ul-body"></div>`;

    this._syncShellClass();

    this._tabs = mountTabs(this.root.querySelector('#ul-tabs'), {
      tabs: TABS,
      active: TABS.findIndex((t) => t.id === this.tab),
      onChange: (id) => {
        this.tab = id;
        this._syncShellClass();
        this.renderBody();
      },
    });

    this.renderChips();
    this.renderBody();

    this.root.querySelector('#ul-search')?.addEventListener('input', (e) => {
      const q = e.target.value.trim().toLowerCase();
      this.root.querySelector('#ul-body')?.dispatchEvent(new CustomEvent('ul-filter', { detail: { q }, bubbles: true }));
    });
  }

  renderChips() {
    if (this.tab === 'songs') return;
    const host = this.root.querySelector('#ul-chips');
    if (!host) return;
    const recents = getLibraryRecents().slice(0, 6);
    const favs = getLibraryFavorites().slice(0, 4);
    host.innerHTML = [
      ...favs.map((f) => `<button type="button" class="su-chip" data-fav="${f.id}">★ ${f.label || f.id}</button>`),
      ...recents.map((r) => `<button type="button" class="su-chip" data-recent="${r.id}">${r.label || r.id}</button>`),
    ].join('') || `<span class="su-badge">Favoritos e recentes aparecem aqui</span>`;
  }

  _syncShellClass() {
    this.root.classList.toggle('is-songs-tab', this.tab === 'songs' || this.tab === 'playlists');
  }

  async renderBody() {
    this.destroyChild();
    const body = this.root.querySelector('#ul-body');
    if (!body) return;
    body.innerHTML = '';

    if (this.tab === 'songs' || this.tab === 'playlists') {
      const mount = document.createElement('div');
      mount.className = 'unified-library__mount';
      body.appendChild(mount);
      this._child = new WorshipLibrary(mount, this.app, {
        onSave: this.opts.onSave,
        onDelete: this.opts.onDelete,
      });
      this._child.init?.();
      return;
    }

    if (this.tab === 'bible') {
      renderBibleView(this.app, body);
      return;
    }

    // images / videos / audio / templates → media library
    const mount = document.createElement('div');
    mount.className = 'unified-library__mount';
    body.appendChild(mount);
    try {
      const { MediaLibrary } = await import('../media/media-library.js');
      const lib = new MediaLibrary(this.app);
      const initial = this.tab === 'videos' ? 'video' : this.tab === 'audio' ? 'audio' : this.tab === 'templates' ? 'frame' : 'image';
      lib.tab = initial;
      lib.mount(mount);
      this._child = lib;
    } catch (err) {
      mount.innerHTML = `<div class="su-alert su-alert--error">Não foi possível abrir mídia: ${err?.message || err}</div>`;
    }
  }

  destroyChild() {
    this._child?.destroy?.();
    this._child = null;
  }

  destroy() {
    this.destroyChild();
    this.root.innerHTML = '';
  }
}

export function renderUnifiedLibraryView(app, main) {
  main.innerHTML = `<div class="view-panel is-active full-panel su-motion-view" id="library-root"></div>`;
  if (app._unifiedLibrary) app._unifiedLibrary.destroy?.();
  app._unifiedLibrary = new UnifiedLibrary(document.getElementById('library-root'), app, {
    onSave: async () => {
      app.program?.clearSongCache?.();
      await app.program?.rebuild?.();
      app.syncProjectorState?.(false);
    },
  });
}
