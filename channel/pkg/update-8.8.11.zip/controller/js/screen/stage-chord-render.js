/**
 * Renderização rica de cifra ChordPro + tablatura para o Stage (Músico).
 */
import { parseChordPro } from '../worship/chordpro-parser.js';

const TAB_LINE = /^([EeBbGgDdAa])\s*[|│]/;

export function normalizeLyricLine(text) {
  return String(text || '')
    .trim()
    .toLowerCase()
    .replace(/[.,;:!?…'"]/g, '')
    .replace(/\s+/g, ' ');
}

function esc(s) {
  return String(s || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

function stripInlineChords(line) {
  return String(line || '').replace(/\[[^\]]+\]/g, '').trim();
}

/** Nome de acorde (inclui F#m, C#m, B7…) — não é título de seção. */
export function isChordTokenName(name) {
  return /^[A-G][#b]?(?:maj|min|m|dim|aug|sus|add|maj7|m7|M7|7|9|11|13|6|º|°|\d)*(?:\/[A-G][#b]?)?$/i
    .test(String(name || '').trim());
}

function isSectionName(name) {
  const n = String(name || '').trim();
  if (!n) return false;
  if (isChordTokenName(n)) return false;
  if (/^tab\s/i.test(n) || /tab\s-/i.test(n)) return true;
  if (/parte|intro|refr|solo|verso|ponte|final|outro|coro/i.test(n)) return true;
  if (n.includes(' ')) return true;
  return n.length > 2;
}

function chordRowFromParsed(row) {
  const lyric = row?.lyric || '';
  const chords = row?.chords || [];
  let chordLine = '';
  for (let i = 0; i < Math.max(chords.length, lyric.length); i += 1) {
    const ch = chords[i] || '';
    if (ch) {
      while (chordLine.length < i) chordLine += ' ';
      chordLine += ch;
    }
  }
  return { chordLine: chordLine.trimEnd(), lyric };
}

/**
 * Detecta linha de tablatura mesmo com acordes embutidos:
 * `[F#m]E|--------/2---|[B][E]` → corda E + conteúdo limpo.
 */
export function parseTabLine(line) {
  const raw = String(line || '').trim();
  if (!raw) return null;

  const leadingChords = [];
  let rest = raw;
  let lead;
  while ((lead = rest.match(/^\[([^\]]+)\]\s*/))) {
    leadingChords.push(lead[1].trim());
    rest = rest.slice(lead[0].length);
  }

  const m = rest.match(/^([EeBbGgDdAa])\s*[|│]\s*(.*)$/);
  if (!m) return null;

  const trailingChords = [];
  let content = m[2] || '';
  content = content.replace(/(?:\s*\[[^\]]+\])+\s*$/g, (chunk) => {
    const re = /\[([^\]]+)\]/g;
    let mm;
    while ((mm = re.exec(chunk)) !== null) trailingChords.push(mm[1].trim());
    return '';
  });
  content = content.replace(/\[[^\]]+\]/g, '');

  return {
    string: m[1].toUpperCase(),
    content,
    leadingChords,
    trailingChords,
  };
}

const TAB_PART = /^parte\s+\d+/i;

/** Parse fonte bruta em blocos semânticos. */
export function parseStageChordBlocks(source) {
  const raw = String(source || '').replace(/\r\n/g, '\n');
  const lines = raw.split('\n');
  const blocks = [];
  let cur = { type: 'section', title: '', items: [] };
  let tabGroup = null;

  const flushSection = () => {
    if (cur.items.length || cur.title) blocks.push({ ...cur });
    cur = { type: 'section', title: '', items: [] };
    tabGroup = null;
  };

  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed) {
      tabGroup = null;
      cur.items.push({ type: 'blank' });
      continue;
    }

    if (TAB_PART.test(trimmed)) {
      tabGroup = { type: 'tab', label: trimmed, rows: [], annotations: [] };
      cur.items.push(tabGroup);
      continue;
    }

    // Tab ANTES de seção: `[F#m]E|---` não pode virar título "F#m"
    const tabRow = parseTabLine(trimmed);
    if (tabRow) {
      if (!tabGroup) {
        tabGroup = { type: 'tab', label: '', rows: [], annotations: [] };
        cur.items.push(tabGroup);
      }
      const notes = [...(tabRow.leadingChords || []), ...(tabRow.trailingChords || [])];
      for (const ch of notes) {
        if (ch && !tabGroup.annotations.includes(ch)) tabGroup.annotations.push(ch);
      }
      tabGroup.rows.push(tabRow);
      continue;
    }

    const bracket = trimmed.match(/^\[([^\]]+)\]\s*(.*)$/);
    if (bracket) {
      const name = bracket[1].trim();
      const rest = bracket[2].trim();
      if (isSectionName(name)) {
        flushSection();
        cur.title = name;
        if (rest) cur.items.push({ type: 'chord', rows: [{ chordLine: rest, lyric: '' }] });
        tabGroup = null;
        continue;
      }
    }

    tabGroup = null;

    if (/\[[A-Ga-g][#b]?[^\]]*\]/.test(trimmed)) {
      const parsed = parseChordPro(`${trimmed}\n`);
      const rows = (parsed.lines || [])
        .filter((r) => (r.lyric || '').trim() || (r.chords || []).some(Boolean))
        .map(chordRowFromParsed);
      if (rows.length) cur.items.push({ type: 'chord', rows });
      continue;
    }

    if (/^\{[^}]+\}/.test(trimmed)) continue;

    cur.items.push({ type: 'text', text: trimmed });
  }
  flushSection();
  return blocks.filter((b) => b.title || b.items.length);
}

export function resolveHighlightBlockIndices(slide, blocks) {
  const out = new Set();
  const targets = (slide?.lines || []).map(normalizeLyricLine).filter(Boolean);
  if (!targets.length) {
    if (Number.isFinite(slide?.slideIndex) && slide.slideIndex >= 0) out.add(slide.slideIndex);
    return out;
  }

  blocks.forEach((block, bi) => {
    const haystack = [];
    for (const item of block.items || []) {
      if (item.type === 'chord') {
        for (const row of item.rows || []) {
          if (row.lyric) haystack.push(row.lyric);
        }
      }
      if (item.type === 'text') haystack.push(item.text);
    }
    const normalized = haystack.map(normalizeLyricLine).filter(Boolean);
    const hit = targets.some((t) => normalized.some((n) => n.includes(t) || t.includes(n)));
    if (hit) out.add(bi);
  });

  if (!out.size && Number.isFinite(slide?.slideIndex) && slide.slideIndex >= 0) {
    out.add(Math.min(slide.slideIndex, Math.max(0, blocks.length - 1)));
  }
  return out;
}

function stringClass(name) {
  const c = String(name || 'e').toLowerCase();
  return `stage-tab-string stage-tab-string--${c}`;
}

/**
 * Quebra tablatura longa em blocos de compassos legíveis (não quebra no meio da corda).
 * @param {{ string: string, content: string }[]} rows
 * @param {number} maxCols
 */
export function chunkTabMeasures(rows, maxCols = 36) {
  if (!rows?.length) return [];
  const splitRows = rows.map((r) => {
    let parts = String(r.content || '').split('|');
    if (parts.length && parts[parts.length - 1] === '') parts = parts.slice(0, -1);
    if (!parts.length) parts = [''];
    return { string: r.string, parts };
  });
  const numMeasures = Math.max(...splitRows.map((r) => r.parts.length), 1);
  const chunks = [];
  let start = 0;
  while (start < numMeasures) {
    let end = start;
    let width = 0;
    while (end < numMeasures) {
      const measureW = Math.max(...splitRows.map((r) => String(r.parts[end] ?? '').length), 0) + 1;
      if (end > start && width + measureW > maxCols) break;
      width += measureW;
      end += 1;
    }
    if (end === start) end = start + 1;
    chunks.push(splitRows.map((r) => ({
      string: r.string,
      content: r.parts.slice(start, end).map((p) => `${p}|`).join(''),
    })));
    start = end;
  }
  return chunks;
}

function renderTabChunk(rows, isLive) {
  const lineRows = (rows || []).map((row) => `
    <div class="stage-tab-row">
      <span class="${stringClass(row.string)}" title="Corda ${esc(row.string)}">${esc(row.string)}</span>
      <span class="stage-tab-bar">│</span>
      <span class="stage-tab-fret">${esc(row.content)}</span>
    </div>`).join('');
  return `<div class="stage-tab-chunk ${isLive ? 'is-current' : ''}"><div class="stage-tab-lines">${lineRows}</div></div>`;
}

function renderTabDiagram(tab, isLive) {
  const label = tab.label
    ? `<div class="stage-tab-label">${esc(tab.label)}</div>`
    : '<div class="stage-tab-label">Tablatura</div>';
  const annotations = (tab.annotations || []).filter(Boolean);
  const chordHint = annotations.length
    ? `<div class="stage-tab-chords">${annotations.map((c) => `<span class="stage-tab-chord">${esc(c)}</span>`).join(' ')}</div>`
    : '';
  const chunks = chunkTabMeasures(tab.rows || [], 36);
  if (!chunks.length) return '';
  const body = chunks.map((chunk, i) => {
    const partLabel = chunks.length > 1
      ? `<div class="stage-tab-chunk-label">parte ${i + 1}/${chunks.length}</div>`
      : '';
    return `${partLabel}${renderTabChunk(chunk, isLive)}`;
  }).join('');
  return `
    <div class="stage-tab-diagram ${isLive ? 'is-current' : ''}" role="group" aria-label="Tablatura de violão">
      ${label}
      ${chordHint}
      <div class="stage-tab-scroll">${body}</div>
    </div>`;
}

function renderChordRows(rows, isLive) {
  return `
    <div class="stage-chord-lyric-block ${isLive ? 'is-current' : ''}">
      ${(rows || []).map((row) => {
        const chordHtml = row.chordLine
          ? `<div class="stage-chord-chord${isLive ? ' stage-chord-line--current' : ''}">${esc(row.chordLine)}</div>`
          : '';
        const lyricHtml = row.lyric
          ? `<div class="stage-chord-lyric${isLive ? ' stage-chord-line--current' : ''}">${esc(row.lyric)}</div>`
          : '';
        return `${chordHtml}${lyricHtml}`;
      }).join('')}
    </div>`;
}

export function renderStageChordDocument(source, { highlightBlocks = new Set() } = {}) {
  const blocks = parseStageChordBlocks(source);
  if (!blocks.length) {
    return { html: '<p class="stage-live-status">Cifra vazia</p>', blockCount: 0 };
  }

  const html = blocks.map((block, bi) => {
    const isLive = highlightBlocks.has(bi);
    const title = block.title
      ? `<div class="stage-chord-section ${isLive ? 'is-current' : ''}">${esc(block.title)}</div>`
      : '';
    const body = (block.items || []).map((item) => {
      if (item.type === 'tab') return renderTabDiagram(item, isLive);
      if (item.type === 'chord') return renderChordRows(item.rows, isLive);
      if (item.type === 'text') {
        return `<p class="stage-chord-text ${isLive ? 'is-current' : ''}">${esc(item.text)}</p>`;
      }
      if (item.type === 'blank') return '<div class="stage-chord-spacer"></div>';
      return '';
    }).join('');
    return `<section class="stage-chord-block ${isLive ? 'is-current' : ''}" data-block="${bi}">${title}${body}</section>`;
  }).join('');

  return { html, blockCount: blocks.length };
}

export function globalHighlightIndices(fullLines, slide) {
  const indices = new Set();
  if (!fullLines?.length || !slide?.lines?.length) return indices;
  const used = new Set();
  for (const slideLine of slide.lines) {
    const t = normalizeLyricLine(slideLine);
    if (!t) continue;
    for (let idx = 0; idx < fullLines.length; idx += 1) {
      if (used.has(idx)) continue;
      const n = normalizeLyricLine(fullLines[idx]);
      if (!n) continue;
      if (n === t || n.includes(t) || t.includes(n)) {
        indices.add(idx);
        used.add(idx);
        break;
      }
    }
  }
  return indices;
}

export function stanzaIsLive(stanza, fullLines, hiSet) {
  let cursor = 0;
  return stanza.some((line) => {
    const t = normalizeLyricLine(line);
    for (let i = cursor; i < fullLines.length; i += 1) {
      if (hiSet.has(i)) {
        const n = normalizeLyricLine(fullLines[i]);
        if (n === t || n.includes(t) || t.includes(n)) {
          cursor = i + 1;
          return true;
        }
      }
    }
    return false;
  });
}
