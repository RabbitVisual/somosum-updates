/** Efeitos visuais para louvor no projetor — seguro, tela cheia, compatível com designer. */

const AMBIENT_CLASS = 'lyrics-ambient-layer';

export const LYRICS_FX_AMBIENTS = [
  { id: 'none', label: 'Sem animacao' },
  { id: 'aurora', label: 'Aurora suave' },
  { id: 'embers', label: 'Brasas douradas' },
  { id: 'soft-rays', label: 'Raios suaves' },
  { id: 'gold-glow', label: 'Brilho dourado' },
  { id: 'shimmer', label: 'Shimmer leve' },
  { id: 'vignette', label: 'Vignette suave' },
];

export function getLyricsFxPrefs(prefs = {}) {
  const fx = prefs.lyricsFx || {};
  return {
    ambient: fx.ambient ?? 'none',
    lineEntrance: fx.lineEntrance ?? 'none',
    highlightPulse: fx.highlightPulse !== false,
  };
}

function findLyricsSlide(stageEl) {
  return stageEl?.querySelector('.slide-lyrics, .slide-lyrics-title') || null;
}

function isLyricsSlideType(slide) {
  return slide?.type === 'lyrics' || slide?.type === 'lyrics-title';
}

function upsertAmbientLayer(parent, ambientId, beforeSelector = '.lyrics-bg-overlay') {
  if (!parent) return;
  const existing = parent.querySelector('.' + AMBIENT_CLASS);
  const same = existing?.classList.contains(`lyrics-ambient-${ambientId}`);
  if (same) return;
  parent.querySelectorAll('.' + AMBIENT_CLASS).forEach((n) => n.remove());
  if (!ambientId) return;
  const layer = document.createElement('div');
  layer.className = `${AMBIENT_CLASS} lyrics-ambient-${ambientId}`;
  layer.setAttribute('aria-hidden', 'true');
  const before = parent.querySelector(beforeSelector);
  if (before) parent.insertBefore(layer, before);
  else parent.appendChild(layer);
}

export function applyLyricsFxPatch(stageEl, slide, prefs = {}, persistEl = null) {
  const slideEl = findLyricsSlide(stageEl);
  if (!slideEl || !isLyricsSlideType(slide)) return;
  const fx = getLyricsFxPrefs(prefs);
  const ambientId = fx.ambient && fx.ambient !== 'none' ? fx.ambient : '';

  if (persistEl && slideEl.classList.contains('slide-lyrics--bg-persist')) {
    upsertAmbientLayer(persistEl, ambientId);
    slideEl.querySelectorAll('.' + AMBIENT_CLASS).forEach((n) => n.remove());
  }

  slideEl.classList.toggle('has-lyrics-fx', !!(ambientId || fx.lineEntrance === 'stagger' || fx.highlightPulse));

  slideEl.querySelectorAll('.lyrics-line').forEach((line, i) => {
    const isHi = slide.highlightIndex === i;
    line.classList.toggle('is-highlight', isHi);
    line.classList.toggle('lyrics-line-pulse', isHi && fx.highlightPulse);
  });
}

export function applyLyricsFx(stageEl, slide, prefs = {}, persistEl = null) {
  const slideEl = findLyricsSlide(stageEl);
  if (!slideEl) return;

  const fx = getLyricsFxPrefs(prefs);
  const ambientId = fx.ambient && fx.ambient !== 'none' ? fx.ambient : '';

  if (persistEl && slideEl.classList.contains('slide-lyrics--bg-persist')) {
    upsertAmbientLayer(persistEl, ambientId);
    slideEl.querySelectorAll('.' + AMBIENT_CLASS).forEach((n) => n.remove());
  } else {
    upsertAmbientLayer(slideEl, ambientId);
  }

  slideEl.classList.toggle('has-lyrics-fx', !!(ambientId || fx.lineEntrance === 'stagger' || fx.highlightPulse));

  if (fx.lineEntrance === 'stagger' && !slideEl.dataset.fxStagger) {
    slideEl.dataset.fxStagger = '1';
    slideEl.querySelectorAll('.anim-fade-up').forEach((el) => el.classList.remove('anim-fade-up'));
    slideEl.querySelectorAll('.lyrics-line').forEach((line, i) => {
      if (!line.classList.contains('lyrics-line-enter')) {
        line.classList.add('lyrics-line-enter');
        line.style.animationDelay = `${Math.min(i * 0.05, 0.3)}s`;
      }
    });
    const titleBlock = slideEl.querySelector('.lyrics-title-content');
    if (titleBlock && !titleBlock.classList.contains('lyrics-title-enter')) {
      titleBlock.classList.add('lyrics-title-enter');
    }
  }

  slideEl.querySelectorAll('.lyrics-line').forEach((line, i) => {
    const isHi = slide?.highlightIndex === i;
    line.classList.toggle('is-highlight', isHi);
    line.classList.toggle('lyrics-line-pulse', isHi && fx.highlightPulse);
  });
}

export function refreshLyricsFxOnStage(stageEl, slide, prefs, persistEl = null) {
  applyLyricsFx(stageEl, slide || { type: stageEl?.querySelector('[data-type]')?.dataset?.type }, prefs, persistEl);
}
