/** Metrônomo offline via Web Audio API — click + mute/volume. */
import { TaskScheduler } from '../core/task-scheduler.js';
import { TaskIds } from '../core/task-registry.js';

export class StageMetronome {
  constructor() {
    this.ctx = null;
    this.bpm = 120;
    this.volume = 0.7;
    this.muted = false;
    this._beat = 0;
    this._dispose = null;
    this._onBeat = null;
  }

  ensureCtx() {
    if (!this.ctx) this.ctx = new (window.AudioContext || window.webkitAudioContext)();
    return this.ctx;
  }

  async resume() {
    const ctx = this.ensureCtx();
    if (ctx.state === 'suspended') {
      try { await ctx.resume(); } catch { /* gesture required */ }
    }
    return ctx;
  }

  setVolume(v) {
    const n = Number(v);
    this.volume = Number.isFinite(n) ? Math.min(1, Math.max(0, n)) : 0.7;
  }

  setMuted(m) {
    this.muted = !!m;
  }

  onBeat(fn) {
    this._onBeat = typeof fn === 'function' ? fn : null;
  }

  tick() {
    const accent = this._beat === 0;
    this._onBeat?.(this._beat, accent);
    this._beat = (this._beat + 1) % 4;

    if (this.muted || this.volume <= 0) return;
    const ctx = this.ensureCtx();
    if (ctx.state === 'suspended') return;

    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.frequency.value = accent ? 1100 : 880;
    const peak = (accent ? 0.12 : 0.08) * this.volume;
    const t = ctx.currentTime;
    gain.gain.setValueAtTime(0.0001, t);
    gain.gain.exponentialRampToValueAtTime(peak, t + 0.005);
    gain.gain.exponentialRampToValueAtTime(0.0001, t + 0.05);
    osc.start(t);
    osc.stop(t + 0.055);
  }

  start(bpm = 120) {
    this.stop();
    const n = Number(bpm);
    this.bpm = Number.isFinite(n) ? Math.max(40, Math.min(220, n)) : 120;
    this._beat = 0;
    void this.resume();
    this.tick();
    const interval = (60 / this.bpm) * 1000;
    this._dispose = TaskScheduler.register({
      id: TaskIds.STAGE_PRO_METRONOME,
      kind: 'interval',
      intervalMs: interval,
      priority: 7,
      fn: () => this.tick(),
    });
  }

  isRunning() {
    return !!this._dispose;
  }

  stop() {
    this._dispose?.();
    this._dispose = null;
    this._beat = 0;
    TaskScheduler.unregister(TaskIds.STAGE_PRO_METRONOME);
  }
}
