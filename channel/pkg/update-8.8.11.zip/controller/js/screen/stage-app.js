import './stage-app/utils.js';
import { bootstrapMain } from './stage-app/boot.js';
import { rawHtml, setHtml } from '../core/render-engine/index.js';

async function main() {
  const ctx = {};
  await bootstrapMain(ctx);
}

main().catch(async (err) => {
  console.error('[SOMOSUM stage boot]', err);
  const root = document.getElementById('stage-root');
  if (root) {
    setHtml(root, rawHtml(`
      <div class="stage-boot stage-boot--error">
        <div class="stage-boot-inner">
          <p class="stage-boot-title">Erro ao iniciar</p>
          <p class="stage-boot-msg">Recarregue a página ou reinicie o SOMOSUM.exe.</p>
          <button type="button" class="stage-boot-retry" onclick="location.reload()">Tentar novamente</button>
        </div>
      </div>`));
  }
  try {
    const { markAppReady } = await import('../core/server-boot.js');
    markAppReady();
  } catch { /* ignore */ }
});
