﻿import '../../runtime/runtime-client.js';
import { esc, escAttr, rawHtml, setHtml } from '../../core/render-engine/index.js';
import { ProjectionBus, MessageTypes } from '../../core/bus.js';
import { getPrefs, initializeFromDisk } from '../../core/store.js';
import { applyTheme } from '../../core/themes.js';
import { resolvePrefsAtmosphereId } from '../../ui/theme/atmospheres.js';
import { loadCustomFonts } from '../../core/fonts.js';
import { renderLyricsLinesBlock, renderMessage } from '../../slides/templates.js';
import { renderInterlinearSlideHtml } from '../../bible/interlinear-render.js';
import { formatCountdownDigits } from '../../core/countdown.js';
import {
  getStageClientId,
  getStageDeviceLabel,
  setStageDeviceLabel,
  startPresenceHeartbeat,
} from '../../core/client-presence.js';
import { getRecoveryEngine } from '../../runtime/facades/recovery-runtime.js';
import { TaskScheduler } from '../../core/task-scheduler.js';
import { TaskIds } from '../../core/task-registry.js';
import { initUiScale } from '../../core/ui-scale.js';
import { RenderScheduler } from '../../core/render-scheduler.js';
import { getDesignDimensions } from '../../runtime/facades/display-runtime.js';
import {
  getChordViewState,
  renderChordChartHtml,
  wireStageChordControls,
} from '../stage-chords-view.js';

const SLIDE_TYPE_LABELS = {
  welcome: 'Boas-vindas',
  lyrics: 'Louvor',
  'lyrics-title': 'Louvor',
  bible: 'Leitura bíblica',
  'bible-reader': 'Leitura bíblica',
  message: 'Mensagem',
  prayer: 'Oração',
  section: 'Seção',
  announcements: 'Comunicados',
  communion: 'Ceia do Senhor',
  theme: 'Tema / Divisa',
  participation: 'Participação',
  custom: 'Personalizado',
  media: 'Mídia',
  blank: 'Em branco',
  logo: 'Logo',
  countdown: 'Pré-culto',
};

const FULL_LYRICS_KEY = 'somosum-stage-full-lyrics';
const TELEPROMPTER_KEY = 'somosum-stage-teleprompter';

function slideTypeLabel(type) {
  return SLIDE_TYPE_LABELS[type] || type || 'Slide';
}

function lyricsKey(slide) {
  if (!slide?.lines?.length) return '';
  return `${slide.highlightIndex ?? -1}:${slide.lines.join('\n')}`;
}

function scaledLyricsStyle(slide = {}, prefs = {}) {
  const style = slide.style || {};
  const base = style.fontSize || 54;
  const body = typeof document !== 'undefined' ? document.getElementById('stage-live-body') : null;
  const dims = getDesignDimensions(body);
  const aspect43 = dims.w / dims.h < 1.45;
  const maxLeg = prefs?.displayEngine?.maxLegibility || aspect43;
  // Tablet/celular: letras legíveis sem estourar a tela (antes floor 64px era excessivo)
  let floor = maxLeg && aspect43 ? 28 : 20;
  const vw = Math.max(2.2, Math.min(3.8, base * 0.05));
  const max = Math.max(floor, Math.round(base * (maxLeg ? 0.48 : 0.42)));
  return `
    --lyrics-font-size: clamp(${floor / 16}rem, ${vw}vw, ${max}px);
    --lyrics-line-height: ${style.lineHeight || 1.4};
    --lyrics-align: ${style.align || 'center'};
    --lyrics-text-transform: ${style.textTransform || 'none'};`;
}

function formatProgress(state) {
  const total = state.totalSlides || 0;
  const flat = (state.flatIndex ?? 0) + 1;
  if (!total) return '—';
  const part = (state.itemSlideIndex ?? 0) + 1;
  const parts = state.itemSlideCount > 1 ? ` · ${part}/${state.itemSlideCount}` : '';
  return `${flat}/${total}${parts}`;
}

function countdownRemainingMs(expiresAt) {
  if (!expiresAt) return null;
  return Math.max(0, expiresAt - Date.now());
}

function globalHighlightIndex(fullLines, slide) {
  if (!fullLines?.length || !slide?.lines?.length) return -1;
  const hi = slide.highlightIndex ?? 0;
  const target = slide.lines[hi] ?? slide.lines[0];
  let idx = fullLines.indexOf(target);
  if (idx >= 0) return idx;
  for (let i = 0; i < fullLines.length; i++) {
    if (fullLines[i].trim() === String(target).trim()) return i;
  }
  return -1;
}

function alertTargetsMe(target, clientId) {
  if (!target || target === 'all') return true;
  if (Array.isArray(target)) return target.includes(clientId);
  return target === clientId;
}
