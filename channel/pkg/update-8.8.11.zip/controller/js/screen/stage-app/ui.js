/** Stage UI continues inside bootstrapMain (shared scope). */
export async function runMainUi() {
  /* no-op: logic merged into boot.js */
}
