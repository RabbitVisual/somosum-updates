/** Stage Pro UI — perfil, metrônomo, auto-scroll e cronômetro (contextual por perfil) */
import { TaskScheduler } from '../core/task-scheduler.js';
import { TaskIds } from '../core/task-registry.js';
import { StageMetronome } from './stage-metronome.js';
import { faIcon } from '../core/fa-icons.js';
import { STAGE_CORE_LAYOUTS, normalizeStageLayout } from './stage-layouts.js';
import {
  getAutoScrollState,
  setAutoScrollMode,
  setAutoScrollSpeed,
  setAutoScrollPaused,
  toggleAutoScrollPaused,
  onStageSlideChange,
  resolveStageScrollContainer,
} from './stage-auto-scroll.js';

const PREFS_KEY = 'somosum-stage-pro';

function normalizeLayout(id) {
  return normalizeStageLayout(id);
}

function loadMetroPrefs() {
  try {
    const raw = localStorage.getItem(`${PREFS_KEY}-metro`);
    if (!raw) return { muted: false, volume: 0.7 };
    const p = JSON.parse(raw);
    return {
      muted: !!p.muted,
      volume: Number.isFinite(Number(p.volume)) ? Math.min(1, Math.max(0, Number(p.volume))) : 0.7,
    };
  } catch {
    return { muted: false, volume: 0.7 };
  }
}

function saveMetroPrefs(prefs) {
  try {
    localStorage.setItem(`${PREFS_KEY}-metro`, JSON.stringify(prefs));
  } catch { /* ignore */ }
}

function loadAutoScrollPrefs() {
  try {
    const raw = localStorage.getItem(`${PREFS_KEY}-autoscroll`);
    if (!raw) return { mode: 'follow', speed: 1, paused: false };
    const p = JSON.parse(raw);
    const mode = ['off', 'follow', 'manual', 'bpm'].includes(p.mode) ? p.mode : 'follow';
    const speed = Number.isFinite(Number(p.speed)) ? Math.min(4, Math.max(0.25, Number(p.speed))) : 1;
    return { mode, speed, paused: !!p.paused };
  } catch {
    return { mode: 'follow', speed: 1, paused: false };
  }
}

function saveAutoScrollPrefs(prefs) {
  try {
    localStorage.setItem(`${PREFS_KEY}-autoscroll`, JSON.stringify(prefs));
  } catch { /* ignore */ }
}

function stageScrollContainer(root) {
  return root.querySelector('#stage-live-body, .stage-full-scroll, .stage-chord-pre, .stage-live-scroll, .stage-live-panel--scroll')
    || document.getElementById('stage-live-body');
}

export function mountStageProUi(root, stagePro, { onLayoutChange } = {}) {
  if (!root || !stagePro) return () => {};

  if (typeof onLayoutChange === 'function') {
    stagePro.onStageLayoutChange?.(onLayoutChange);
  }

  const metro = new StageMetronome();
  const metroPrefs = loadMetroPrefs();
  metro.setMuted(metroPrefs.muted);
  metro.setVolume(metroPrefs.volume);

  const autoScrollPrefs = loadAutoScrollPrefs();
  setAutoScrollMode(autoScrollPrefs.mode);
  setAutoScrollSpeed(autoScrollPrefs.speed);
  setAutoScrollPaused(autoScrollPrefs.paused);

  let tickDispose = null;

  const applyAutoScroll = () => {
    const container = resolveStageScrollContainer(root) || stageScrollContainer(root);
    const bpm = stagePro.getMetronomeBpm?.() || null;
    onStageSlideChange({
      mode: getAutoScrollState().mode,
      bpm,
      container,
    });
  };

  const formatTimer = (sec) => {
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  };

  const flashDot = (accent) => {
    const dot = root.querySelector('#stage-pro-metro-dot');
    if (!dot) return;
    dot.classList.add('is-beat');
    dot.classList.toggle('is-accent', !!accent);
    setTimeout(() => {
      dot.classList.remove('is-beat');
      dot.classList.remove('is-accent');
    }, 80);
    try { navigator.vibrate?.(accent ? 18 : 8); } catch { /* ignore */ }
  };

  metro.onBeat((_beat, accent) => flashDot(accent));

  const stopMetronome = () => {
    metro.stop();
    const dot = root.querySelector('#stage-pro-metro-dot');
    if (dot) {
      dot.classList.remove('is-beat');
      dot.classList.remove('is-accent');
    }
    const toggle = root.querySelector('#stage-pro-metro-toggle');
    if (toggle) toggle.classList.remove('is-active');
  };

  const startMetronome = async (bpm) => {
    if (!bpm || bpm < 40 || bpm > 220) return false;
    await metro.resume();
    metro.start(bpm);
    const toggle = root.querySelector('#stage-pro-metro-toggle');
    if (toggle) toggle.classList.add('is-active');
    const hint = root.querySelector('#stage-pro-metro-hint');
    if (hint) hint.hidden = true;
    return true;
  };

  const mergePluginLayouts = async () => {
    renderBar();
  };

  const renderBar = () => {
    const bar = root.querySelector('#stage-pro-bar');
    if (!bar) return;
    const layout = normalizeLayout(stagePro.getStageProLayout?.());
    const bpm = stagePro.getMetronomeBpm?.();
    const timerSec = stagePro.getStageTimerSec?.();
    const volPct = Math.round(metro.volume * 100);
    const scroll = getAutoScrollState();
    const layoutOpts = STAGE_CORE_LAYOUTS
      .map((l) => `<option value="${l.id}" ${layout === l.id ? 'selected' : ''}>${l.label}</option>`)
      .join('');

    const showMetro = layout === 'musician';
    const showScroll = layout === 'musician' || layout === 'singer';
    const showTimer = true;
    const scrollPlayTitle = scroll.mode === 'follow'
      ? (scroll.paused ? 'Retomar seguir destaque' : 'Pausar seguir destaque')
      : (scroll.paused ? 'Retomar rolagem' : 'Pausar rolagem');
    const scrollPlayDisabled = scroll.mode === 'off';

    bar.innerHTML = `
      <div class="stage-pro-bar" role="toolbar" aria-label="Ferramentas do púlpito">
        <div class="stage-pro-group stage-pro-group-layout">
          <label class="stage-pro-label">Perfil</label>
          <select id="stage-pro-layout" class="su-select stage-pro-select" title="Perfil do púlpito">
            ${layoutOpts}
          </select>
        </div>
        ${showMetro ? `
        <div class="stage-pro-group stage-pro-group-metro" data-profile="musician">
          <label class="stage-pro-label">Metrônomo</label>
          <input type="number" id="stage-pro-bpm" class="su-input stage-pro-bpm" min="40" max="220" step="1"
            value="${bpm || ''}" placeholder="BPM" title="Batidas por minuto" />
          <button type="button" class="su-btn su-btn--sm stage-pro-btn btn-icon" id="stage-pro-metro-toggle" title="Ligar/desligar metrônomo">${faIcon('lyrics')}</button>
          <button type="button" class="su-btn su-btn--sm su-btn--ghost stage-pro-btn btn-icon ${metro.muted ? 'is-active' : ''}" id="stage-pro-metro-mute" title="Mute">${faIcon(metro.muted ? 'volumeMute' : 'volume')}</button>
          <input type="range" id="stage-pro-metro-vol" class="stage-pro-vol" min="0" max="100" step="1" value="${volPct}" title="Volume" aria-label="Volume do metrônomo" />
          <span class="stage-pro-metro-dot" id="stage-pro-metro-dot" aria-hidden="true"></span>
          <span class="stage-pro-hint" id="stage-pro-metro-hint" hidden>Informe o BPM (40–220)</span>
        </div>` : ''}
        ${showScroll ? `
        <div class="stage-pro-group stage-pro-group-scroll" data-profile="scroll">
          <label class="stage-pro-label">Auto-scroll</label>
          <select id="stage-pro-autoscroll-mode" class="su-select stage-pro-select" title="Modo de rolagem">
            <option value="off" ${scroll.mode === 'off' ? 'selected' : ''}>Off</option>
            <option value="follow" ${scroll.mode === 'follow' ? 'selected' : ''}>Seguir destaque</option>
            <option value="manual" ${scroll.mode === 'manual' ? 'selected' : ''}>Velocidade</option>
            ${layout === 'musician' ? `<option value="bpm" ${scroll.mode === 'bpm' ? 'selected' : ''}>Sync BPM</option>` : ''}
          </select>
          <button type="button" class="su-btn su-btn--sm stage-pro-btn btn-icon ${scroll.paused ? '' : 'is-active'}" id="stage-pro-autoscroll-play" title="${scrollPlayTitle}" ${scrollPlayDisabled ? 'disabled' : ''}>${faIcon(scroll.paused ? 'play' : 'pause')}</button>
          <input type="range" id="stage-pro-autoscroll-speed" class="stage-pro-vol" min="25" max="400" step="25"
            value="${Math.round(scroll.speed * 100)}" title="Velocidade" aria-label="Velocidade do auto-scroll"
            ${scroll.mode === 'off' || scroll.mode === 'follow' ? 'disabled' : ''} />
        </div>` : ''}
        ${showTimer ? `
        <div class="stage-pro-group stage-pro-group-timer">
          <label class="stage-pro-label">Cronômetro</label>
          <span class="stage-pro-timer" id="stage-pro-timer">${formatTimer(timerSec || 0)}</span>
          <button type="button" class="su-btn su-btn--sm stage-pro-btn btn-icon" id="stage-pro-timer-start" title="Iniciar">${faIcon('play')}</button>
          <button type="button" class="su-btn su-btn--sm stage-pro-btn btn-icon" id="stage-pro-timer-reset" title="Zerar">${faIcon('reset')}</button>
        </div>` : ''}
      </div>`;

    bar.querySelector('#stage-pro-layout')?.addEventListener('change', (e) => {
      const id = normalizeLayout(e.target.value);
      stagePro.setStageProLayout?.(id);
    });
    bar.querySelector('#stage-pro-bpm')?.addEventListener('change', (e) => {
      const v = parseInt(e.target.value, 10);
      stagePro.setMetronomeBpm?.(Number.isFinite(v) ? v : null);
      if (metro.isRunning()) void startMetronome(v);
    });
    bar.querySelector('#stage-pro-metro-toggle')?.addEventListener('click', () => {
      if (metro.isRunning()) {
        stopMetronome();
        return;
      }
      const v = parseInt(bar.querySelector('#stage-pro-bpm')?.value, 10);
      if (!Number.isFinite(v) || v < 40 || v > 220) {
        const hint = bar.querySelector('#stage-pro-metro-hint');
        if (hint) hint.hidden = false;
        return;
      }
      stagePro.setMetronomeBpm?.(v);
      void startMetronome(v);
    });
    bar.querySelector('#stage-pro-metro-mute')?.addEventListener('click', () => {
      metro.setMuted(!metro.muted);
      saveMetroPrefs({ muted: metro.muted, volume: metro.volume });
      const btn = bar.querySelector('#stage-pro-metro-mute');
      if (btn) {
        btn.innerHTML = faIcon(metro.muted ? 'volumeMute' : 'volume');
        btn.classList.toggle('is-active', metro.muted);
      }
    });
    bar.querySelector('#stage-pro-metro-vol')?.addEventListener('input', (e) => {
      const pct = parseInt(e.target.value, 10);
      metro.setVolume((Number.isFinite(pct) ? pct : 70) / 100);
      saveMetroPrefs({ muted: metro.muted, volume: metro.volume });
    });
    bar.querySelector('#stage-pro-timer-start')?.addEventListener('click', () => {
      stagePro.startStageTimer?.();
    });
    bar.querySelector('#stage-pro-timer-reset')?.addEventListener('click', () => {
      stagePro.resetStageTimer?.();
      const el = bar.querySelector('#stage-pro-timer');
      if (el) el.textContent = '00:00';
    });
    const refreshScrollPlayBtn = () => {
      const st = getAutoScrollState();
      const playBtn = bar.querySelector('#stage-pro-autoscroll-play');
      if (!playBtn) return;
      playBtn.disabled = st.mode === 'off';
      playBtn.innerHTML = faIcon(st.paused ? 'play' : 'pause');
      playBtn.classList.toggle('is-active', st.mode !== 'off' && !st.paused);
      playBtn.title = st.mode === 'follow'
        ? (st.paused ? 'Retomar seguir destaque' : 'Pausar seguir destaque')
        : (st.paused ? 'Retomar rolagem' : 'Pausar rolagem');
    };

    bar.querySelector('#stage-pro-autoscroll-mode')?.addEventListener('change', (e) => {
      const mode = e.target.value || 'off';
      setAutoScrollMode(mode);
      if (mode === 'off') setAutoScrollPaused(false);
      const speedEl = bar.querySelector('#stage-pro-autoscroll-speed');
      if (speedEl) speedEl.disabled = mode === 'off' || mode === 'follow';
      refreshScrollPlayBtn();
      saveAutoScrollPrefs({
        mode,
        speed: getAutoScrollState().speed,
        paused: getAutoScrollState().paused,
      });
      applyAutoScroll();
    });
    bar.querySelector('#stage-pro-autoscroll-play')?.addEventListener('click', () => {
      toggleAutoScrollPaused();
      refreshScrollPlayBtn();
      saveAutoScrollPrefs({
        mode: getAutoScrollState().mode,
        speed: getAutoScrollState().speed,
        paused: getAutoScrollState().paused,
      });
      applyAutoScroll();
    });
    bar.querySelector('#stage-pro-autoscroll-speed')?.addEventListener('input', (e) => {
      const pct = parseInt(e.target.value, 10);
      const speed = (Number.isFinite(pct) ? pct : 100) / 100;
      setAutoScrollSpeed(speed);
      saveAutoScrollPrefs({ mode: getAutoScrollState().mode, speed, paused: getAutoScrollState().paused });
      applyAutoScroll();
    });
  };

  tickDispose = TaskScheduler.register({
    id: TaskIds.STAGE_PRO_TIMER,
    kind: 'interval',
    intervalMs: 1000,
    priority: 6,
    fn: () => {
      const el = root.querySelector('#stage-pro-timer');
      if (el && stagePro.getStageTimerSec) {
        el.textContent = formatTimer(stagePro.getStageTimerSec());
      }
    },
  });

  renderBar();
  void mergePluginLayouts();
  applyAutoScroll();

  return () => {
    stopMetronome();
    tickDispose?.();
    TaskScheduler.unregister(TaskIds.STAGE_PRO_TIMER);
  };
}

export { onStageSlideChange, scrollHighlightIntoView, resolveStageScrollContainer } from './stage-auto-scroll.js';
