/**
 * Stage — visualização de cifra ChordPro (U1-A).
 * Transpose/capo locais; não afeta projeção.
 */
import { parseChordPro } from '../worship/chordpro-parser.js';
import { transposeChordProSource, transposeKeyLabel } from '../worship/chord-transpose.js';
import {
  renderStageChordDocument,
  resolveHighlightBlockIndices,
  parseStageChordBlocks,
} from './stage-chord-render.js';
import { renderMusicianLivePillHtml } from './stage-musician-session.js';

const LS_TRANSPOSE = 'somosum-stage-chord-transpose';
const LS_CAPO = 'somosum-stage-chord-capo';
const LS_MODE = 'somosum-stage-chord-mode';

function loadNum(key, fallback = 0) {
  try {
    const n = Number(localStorage.getItem(key));
    return Number.isFinite(n) ? n : fallback;
  } catch {
    return fallback;
  }
}

export function getChordViewState() {
  return {
    mode: localStorage.getItem(LS_MODE) === '1',
    transpose: loadNum(LS_TRANSPOSE, 0),
    capo: Math.max(0, Math.min(11, loadNum(LS_CAPO, 0))),
  };
}

export function setChordMode(on) {
  localStorage.setItem(LS_MODE, on ? '1' : '0');
}

export function setChordTranspose(n) {
  const v = Math.max(-11, Math.min(11, Number(n) || 0));
  localStorage.setItem(LS_TRANSPOSE, String(v));
  return v;
}

export function setChordCapo(n) {
  const v = Math.max(0, Math.min(11, Number(n) || 0));
  localStorage.setItem(LS_CAPO, String(v));
  return v;
}

function esc(s) {
  return String(s || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

/**
 * @param {{ source:string, title?:string, key?:string, bpm?:number, capo?:number }|null} chart
 * @param {{ transpose?:number, capo?:number, highlightBlock?:number, slide?:object, stableView?:boolean, repeating?:boolean }} opts
 */
export function renderChordChartHtml(chart, opts = {}) {
  if (!chart?.source?.trim()) {
    return `<div class="stage-live-panel stage-live-panel--muted"><p class="stage-live-status">Sem cifra ChordPro nesta música</p></div>`;
  }
  const transpose = Number(opts.transpose) || 0;
  const capo = opts.capo != null ? Number(opts.capo) : (Number(chart.capo) || 0);
  let source = chart.source;
  if (transpose) source = transposeChordProSource(source, transpose);
  const parsed = parseChordPro(source);
  const blocks = parseStageChordBlocks(source);
  const slide = opts.slide || null;
  const stableView = opts.stableView === true;
  const highlightBlocks = stableView
    ? new Set()
    : (slide
      ? resolveHighlightBlockIndices(slide, blocks)
      : new Set(Number.isFinite(opts.highlightBlock) && opts.highlightBlock >= 0 ? [opts.highlightBlock] : []));

  const { html: bodyHtml } = renderStageChordDocument(source, { highlightBlocks });

  const writtenKey = chart.key || parsed.key || '';
  const sounding = writtenKey
    ? transposeKeyLabel(writtenKey, (transpose || 0) + (capo || 0))
    : '';
  const meta = [
    writtenKey ? `Tom ${writtenKey}` : '',
    capo ? `Capo ${capo}` : '',
    sounding && capo ? `Soa ${sounding}` : '',
    transpose ? `Transp ${transpose > 0 ? '+' : ''}${transpose}` : '',
    chart.bpm ? `${chart.bpm} BPM` : '',
  ].filter(Boolean).join(' · ');

  const liveHint = stableView
    ? renderMusicianLivePillHtml(slide, { repeating: !!opts.repeating })
    : (slide?.lines?.length
      ? `<p class="stage-full-live-hint">Ao vivo · ${slide.lines.length} linha(s) no projetor</p>`
      : '');

  return `
    <div class="stage-live-panel stage-chord-chart stage-live-panel--align-start${stableView ? ' stage-chord-chart--stable' : ''}">
      <p class="stage-live-kicker">Cifra · ${esc(chart.title || '')}</p>
      ${meta ? `<p class="stage-chord-meta">${esc(meta)}</p>` : ''}
      ${liveHint}
      <div class="stage-chord-pre stage-chord-pre--rich">${bodyHtml}</div>
    </div>`;
}

/** @deprecated use parseStageChordBlocks */
export function splitChordProBlocks(lines) {
  const blocks = [];
  let cur = [];
  for (const line of lines || []) {
    if (!String(line).trim()) {
      if (cur.length) { blocks.push(cur); cur = []; }
    } else cur.push(line);
  }
  if (cur.length) blocks.push(cur);
  return blocks;
}

export function wireStageChordControls(root, { hasChart, onChange, layout = 'musician' } = {}) {
  const bar = root.querySelector('#stage-chord-bar');
  if (!bar) return;
  const st = getChordViewState();
  const showBar = layout === 'musician' && (hasChart || stateHasLyricsSlide(root));
  bar.hidden = !showBar;
  if (!showBar) {
    bar.innerHTML = '';
    return;
  }
  bar.innerHTML = `
    <div class="stage-chord-controls">
      <button type="button" class="su-btn su-btn--sm ${st.mode ? 'su-btn--primary is-active' : ''}" id="stage-chord-toggle" title="Alternar cifra">Cifra</button>
      <button type="button" class="su-btn su-btn--sm su-btn--ghost" id="stage-chord-down" title="Transpose −1">−</button>
      <span class="stage-chord-transp" id="stage-chord-transp">${st.transpose > 0 ? '+' : ''}${st.transpose}</span>
      <button type="button" class="su-btn su-btn--sm su-btn--ghost" id="stage-chord-up" title="Transpose +1">+</button>
      <label class="stage-chord-capo-label">Capo
        <input type="number" class="su-input stage-chord-capo" id="stage-chord-capo" min="0" max="11" value="${st.capo}" />
      </label>
    </div>`;

  const refreshUi = () => {
    const cur = getChordViewState();
    bar.querySelector('#stage-chord-toggle')?.classList.toggle('is-active', cur.mode);
    bar.querySelector('#stage-chord-toggle')?.classList.toggle('su-btn--primary', cur.mode);
    const transpEl = bar.querySelector('#stage-chord-transp');
    if (transpEl) transpEl.textContent = `${cur.transpose > 0 ? '+' : ''}${cur.transpose}`;
    const capoEl = bar.querySelector('#stage-chord-capo');
    if (capoEl && document.activeElement !== capoEl) capoEl.value = String(cur.capo);
    onChange?.();
  };

  bar.querySelector('#stage-chord-toggle')?.addEventListener('click', () => {
    setChordMode(!getChordViewState().mode);
    refreshUi();
  });
  bar.querySelector('#stage-chord-down')?.addEventListener('click', () => {
    setChordTranspose(getChordViewState().transpose - 1);
    refreshUi();
  });
  bar.querySelector('#stage-chord-up')?.addEventListener('click', () => {
    setChordTranspose(getChordViewState().transpose + 1);
    refreshUi();
  });
  bar.querySelector('#stage-chord-capo')?.addEventListener('change', (e) => {
    setChordCapo(e.target.value);
    refreshUi();
  });
}

function stateHasLyricsSlide(root) {
  return root.querySelector?.('#stage-live-body .stage-live-lyrics, #stage-live-body .stage-chord-chart') != null;
}
