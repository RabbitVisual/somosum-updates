import { getPassage, preloadVersion } from '../bible/bible-service.js';
import { COUNTDOWN_VERSE_POOL } from '../data/countdown-verses.js';
import {
  formatCountdownDigits,
  pickRandomVerseRef,
  verseKey,
  computeAnnounceDurationSec,
  normalizeCountdownBgMode,
  normalizeCountdownLayout,
} from '../core/countdown.js';
import { TaskScheduler } from '../core/task-scheduler.js';
import { faNoticeIcon } from '../core/fa-icons.js';
import { TaskIds } from '../core/task-registry.js';
import { fontFamilyCss, loadCustomFonts } from '../core/fonts.js';
import { PRODUCT_LOGO_REL } from '../core/brand-assets.js';

function esc(text) {
  const d = document.createElement('div');
  d.textContent = text ?? '';
  return d.innerHTML;
}

function assetUrl(assets, key, fallback) {
  return assets?.[key] || fallback;
}

export class CountdownPlayer {
  constructor(options = {}) {
    this.root = options.root || document.body;
    this.defaults = options.defaults || {};
    this.assets = options.assets || {};
    this.prefs = options.prefs || {};
    this.onComplete = options.onComplete;
    this.onPhaseChange = options.onPhaseChange;
    this.ambientPlayer = options.ambientPlayer || null;
    this.onAmbientFade = options.onAmbientFade || null;
    this.onBellPlay = options.onBellPlay || null;
    this.layer = null;
    this.state = null;
    this.tickTimer = null;
    this.verseTimer = null;
    this.phaseTimer = null;
    this._spotlightTimer = null;
    this._phaseDispose = null;
    this._spotlightDispose = null;
    this._announceDisposers = [];
    this.active = false;
    this.currentVerseKey = null;
    this.bibleVersion = this.prefs.bibleVersion || 'naa';
    this._bellPlayed = false;
    this._ambientFadeStarted = false;
    this._lastVerse = { reference: '', text: '' };
    this._announceTimers = [];
    this._verseGen = 0;
  }

  apply(payload = {}) {
    if (payload.action === 'stop') {
      this.stop(false);
      return;
    }
    if (payload.action === 'complete') return;
    if (payload.action === 'start' || payload.action === 'sync') {
      const state = payload.state;
      this.assets = state?.assets || this.assets;
      this.prefs = state?.prefs || this.prefs;
      this.bibleVersion = state?.bibleVersion || this.prefs.bibleVersion || 'naa';

      if (this.canSoftSync(state)) {
        this.softSync(state);
        return;
      }
      this.start(state);
    }
  }

  canSoftSync(state) {
    if (!this.active || !state?.active || !state.targetMs || !this.state?.targetMs) {
      return false;
    }
    return Math.abs(Number(state.targetMs) - Number(this.state.targetMs)) < 5;
  }

  softSync(state) {
    if (!state?.active || !state.targetMs) {
      this.stop(false);
      return;
    }

    const PHASE_ORDER = ['running', 'announce', 'transition'];
    const localPhase = this.state?.phase;
    const remotePhase = state.phase;
    let nextPhase = localPhase || remotePhase;

    if (remotePhase && localPhase && remotePhase !== localPhase) {
      const remoteIdx = PHASE_ORDER.indexOf(remotePhase);
      const localIdx = PHASE_ORDER.indexOf(localPhase);
      if (remoteIdx > localIdx) nextPhase = remotePhase;
    }

    const prevMode = this.state?.backgroundMode;
    const prevDim = this.state?.backgroundDim;
    const prevLayout = this.state?.layoutStyle;
    const prevFont = this.state?.clockFontFamily;
    const prevMedia = this.state?.customMediaSrc;
    const prevMediaKind = this.state?.customMediaKind;
    this.state = { ...this.state, ...state, phase: nextPhase };
    const mode = normalizeCountdownBgMode(this.state.backgroundMode);
    this.state.backgroundMode = mode;
    this.state.layoutStyle = normalizeCountdownLayout(this.state.layoutStyle);
    const dim = Number.isFinite(this.state.backgroundDim) ? this.state.backgroundDim : 0.45;
    const mediaChanged = mode === 'media' && (
      prevMedia !== this.state.customMediaSrc || prevMediaKind !== this.state.customMediaKind
    );
    if (mode !== prevMode || mediaChanged || Math.abs(Number(prevDim ?? 0.45) - dim) > 0.008) {
      this.applyBackground();
    }
    if (prevLayout !== this.state.layoutStyle || prevFont !== this.state.clockFontFamily) {
      this.applyLayoutAndFont();
    }

    if (nextPhase !== localPhase) {
      this.resumePhase();
    }

    if (state.showRandomVerses && this.state.phase === 'running') {
      if (!this._verseDispose) this.startVerseRotation();
    } else {
      this.stopVerseRotation();
      this.clearVerse();
    }
  }

  resolveMediaBackground() {
    const mode = normalizeCountdownBgMode(this.state?.backgroundMode);
    if (mode === 'media') {
      const rawCustom = String(this.state?.customMediaSrc || '').trim();
      const custom = /^blob:|^data:/i.test(rawCustom) ? '' : rawCustom;
      const fallback = assetUrl(this.assets, 'welcomeBg', this.prefs?.church?.welcomeBgPath || 'IMG/FRENTE_DA_IGREJA.png');
      const bg = custom || fallback;
      const kind = this.state?.customMediaKind === 'video'
        || /\.(mp4|webm|mov)(\?|$)/i.test(bg)
        ? 'video'
        : 'image';
      return { bg, kind, mode: 'media' };
    }
    const bg = assetUrl(this.assets, 'welcomeBg', this.prefs?.church?.welcomeBgPath || 'IMG/FRENTE_DA_IGREJA.png');
    const kind = this.assets?.welcomeBgKind
      || this.prefs?.church?.welcomeBgKind
      || (/\.(mp4|webm|mov)(\?|$)/i.test(String(bg)) ? 'video' : 'image');
    return { bg, kind, mode: 'welcome' };
  }

  buildBackgroundHtml() {
    const mode = normalizeCountdownBgMode(this.state?.backgroundMode);
    const dim = Number.isFinite(this.state?.backgroundDim) ? this.state.backgroundDim : 0.45;
    const overlayOpacity = Math.min(1, Math.max(0, dim));

    if (mode === 'welcome' || mode === 'media') {
      const { bg, kind } = this.resolveMediaBackground();
      const bgClass = mode === 'media' ? 'countdown-bg--media' : 'countdown-bg--welcome';
      if (kind === 'video') {
        return `
        <div class="countdown-bg ${bgClass}" data-bg="${mode}" aria-hidden="true">
          <video class="cd-bg-video" src="${esc(bg)}" autoplay muted loop playsinline></video>
          <div class="cd-bg-layer cd-bg-sheen"></div>
          <div class="cd-bg-layer cd-bg-drift"></div>
        </div>
        <div class="countdown-bg-overlay" style="opacity:${overlayOpacity}"></div>
        <div class="countdown-particles countdown-particles--gold" aria-hidden="true"></div>
        <div class="countdown-atmosphere countdown-atmosphere--welcome" aria-hidden="true"></div>`;
      }
      return `
        <div class="countdown-bg ${bgClass}" data-bg="${mode}" aria-hidden="true">
          <div class="cd-bg-photo ken-burns" style="background-image:url('${esc(bg)}')"></div>
          <div class="cd-bg-layer cd-bg-sheen"></div>
          <div class="cd-bg-layer cd-bg-drift"></div>
        </div>
        <div class="countdown-bg-overlay" style="opacity:${overlayOpacity}"></div>
        <div class="countdown-particles countdown-particles--gold" aria-hidden="true"></div>
        <div class="countdown-atmosphere countdown-atmosphere--welcome" aria-hidden="true"></div>`;
    }

    if (mode === 'none') {
      return `
        <div class="countdown-bg countdown-bg--none" data-bg="none" aria-hidden="true">
          <div class="cd-bg-layer cd-bg-base"></div>
        </div>
        <div class="countdown-bg-overlay countdown-bg-overlay--minimal" style="opacity:${Math.min(0.55, overlayOpacity)}"></div>
        <div class="countdown-particles countdown-particles--sparse" aria-hidden="true"></div>
        <div class="countdown-atmosphere" aria-hidden="true"></div>`;
    }

    return `
      <div class="countdown-bg countdown-bg--${mode}" data-bg="${mode}" aria-hidden="true">
        <div class="cd-bg-layer cd-bg-base"></div>
        <div class="cd-bg-layer cd-bg-motion-a"></div>
        <div class="cd-bg-layer cd-bg-motion-b"></div>
        <div class="cd-bg-layer cd-bg-accent"></div>
        <div class="cd-bg-layer cd-bg-vignette"></div>
      </div>
      <div class="countdown-bg-overlay" style="opacity:${overlayOpacity}"></div>
      <div class="countdown-particles countdown-particles--${mode}" aria-hidden="true"></div>
      <div class="countdown-atmosphere countdown-atmosphere--${mode}" aria-hidden="true"></div>`;
  }

  applyBackground() {
    if (!this.layer) return;
    const tmp = document.createElement('div');
    tmp.innerHTML = this.buildBackgroundHtml();
    [...this.layer.children].forEach((child) => {
      if (child.classList.contains('countdown-bg')
        || child.classList.contains('countdown-bg-overlay')
        || child.classList.contains('countdown-particles')
        || child.classList.contains('countdown-atmosphere')) {
        child.remove();
      }
    });
    const insertBefore = this.layer.querySelector('.countdown-spotlight-scrim')
      || this.layer.querySelector('.countdown-inner')
      || this.layer.firstChild;
    [...tmp.children].reverse().forEach((node) => {
      this.layer.insertBefore(node, insertBefore);
    });
    this.layer.setAttribute('data-bg', normalizeCountdownBgMode(this.state?.backgroundMode));
    this.applyLayoutAndFont();
  }

  applyLayoutAndFont() {
    if (!this.layer || !this.state) return;
    const layout = normalizeCountdownLayout(this.state.layoutStyle);
    this.state.layoutStyle = layout;
    this.layer.setAttribute('data-layout', layout);
    const font = String(this.state.clockFontFamily || '').trim();
    this.layer.style.setProperty('--cd-clock-font', fontFamilyCss(font));
    if (font) loadCustomFonts({ injectFaces: true }).catch(() => {});
  }

  async ensureBibleReady() {
    try {
      await Promise.race([
        preloadVersion(this.bibleVersion),
        new Promise((_, reject) => setTimeout(() => reject(new Error('timeout')), 6000)),
      ]);
      return true;
    } catch {
      return false;
    }
  }

  start(state) {
    if (!state?.active || !state.targetMs) {
      this.stop(false);
      return;
    }

    this._verseGen = (this._verseGen || 0) + 1;
    this.stopTick();
    this.stopVerseRotation();
    this.clearPhaseTimers();
    this.clearAnnounceSequence();
    this.clearSpotlightTimer();

    this.state = state;
    this.active = true;
    this._bellPlayed = false;
    this._ambientFadeStarted = false;
    document.documentElement.classList.add('countdown-active');
    this.ensureLayer();
    this.renderShell();
    this.resumePhase();
    this.startTick();
    if (state.showRandomVerses && this.state.phase === 'running') {
      this.ensureBibleReady().finally(() => {
        if (this.active && this.state?.phase === 'running') {
          this.startVerseRotation();
        }
      });
    } else {
      this.clearVerse();
    }
    preloadVersion(this.bibleVersion).catch(() => {});
  }

  resumePhase() {
    const remaining = this.state.targetMs - Date.now();
    if (remaining <= 0 && this.state.phase === 'running') {
      this.enterAnnouncePhase();
    } else if (this.state.phase === 'announce') {
      this.startAmbientFadeIfNeeded();
      this.hideVerseSpotlight();
      this.renderAnnounce();
      this.startAnnounceSequence();
      this.scheduleAnnounceEnd();
    } else if (this.state.phase === 'transition') {
      if (!this._bellPlayed) this.playBellIfEnabled();
      if (this.state.ambientFadeStart === 'transition') {
        this.startTransitionAmbientFade();
      }
      this.hideVerseSpotlight();
      this.renderTransition();
      this.scheduleTransitionEnd();
    } else {
      this.state.phase = 'running';
      this.setPhase('running');
      this.renderRunning();
    }
  }

  ensureLayer() {
    if (this.layer?.isConnected) return;
    this.layer = document.createElement('div');
    this.layer.id = 'countdown-layer';
    this.layer.className = 'countdown-layer';
    this.root.appendChild(this.layer);
  }

  renderShell() {
    const ev = this.defaults.event || {};
    const logo = assetUrl(this.assets, 'logo', PRODUCT_LOGO_REL);
    const churchName = this.prefs?.church?.name || this.defaults?.church?.name || '';
    const showBrand = this.state.showBranding !== false;
    const mode = normalizeCountdownBgMode(this.state.backgroundMode);
    const layout = normalizeCountdownLayout(this.state.layoutStyle);
    this.state.backgroundMode = mode;
    this.state.layoutStyle = layout;

    this.layer.innerHTML = `
      ${this.buildBackgroundHtml()}
      <div class="countdown-spotlight-scrim" aria-hidden="true"></div>
      <div class="countdown-transition-backdrop" aria-hidden="true"></div>
      <div class="countdown-verse-spotlight" id="countdown-verse-spotlight" aria-hidden="true">
        <div class="spotlight-inner">
          <p class="spotlight-ref" id="spotlight-ref"></p>
          <blockquote class="spotlight-text" id="spotlight-text"></blockquote>
        </div>
      </div>
      <div class="announce-spotlight" id="announce-spotlight" aria-hidden="true">
        <div class="announce-spotlight-scrim" aria-hidden="true"></div>
        <div class="announce-spotlight-card">
          <span class="announce-spotlight-icon" id="announce-spotlight-icon"></span>
          <p class="announce-spotlight-text" id="announce-spotlight-text"></p>
          <span class="announce-spotlight-hint">Leia com atenção</span>
        </div>
      </div>
      <div class="countdown-inner">
        ${showBrand ? `
          <header class="countdown-brand anim-fade-up">
            <img class="countdown-logo" src="${logo}" alt="" />
            <div class="countdown-brand-text">
              ${churchName ? `<p class="countdown-church">${esc(churchName)}</p>` : ''}
              <p class="countdown-theme">${esc(ev.theme || '')}</p>
            </div>
          </header>` : ''}
        <section class="countdown-main" id="countdown-main"></section>
      </div>`;
    this.layer.setAttribute('data-bg', mode);
    this.applyLayoutAndFont();
  }

  setPhase(phase) {
    this.state.phase = phase;
    this.layer?.setAttribute('data-phase', phase);
    this.onPhaseChange?.(phase);
  }

  startTick() {
    this.stopTick();
    this._tickDispose = TaskScheduler.register({
      id: TaskIds.COUNTDOWN_TICK,
      kind: 'interval',
      intervalMs: 250,
      priority: 1,
      coalesce: true,
      fn: () => this.tick(),
    });
    this.tick();
  }

  stopTick() {
    if (this._tickDispose) {
      this._tickDispose();
      this._tickDispose = null;
    }
    clearInterval(this.tickTimer);
    this.tickTimer = null;
  }

  tick() {
    if (!this.active || !this.state) return;
    if (this.state.phase !== 'running') return;

    const remaining = this.state.targetMs - Date.now();
    this.updateDigits(remaining);

    if (remaining <= 0) {
      this.enterAnnouncePhase();
    }
  }

  updateDigits(remainingMs) {
    const ms = remainingMs ?? Math.max(0, this.state.targetMs - Date.now());
    const { h, m, s } = formatCountdownDigits(ms);
    const main = this.layer?.querySelector('#countdown-main');
    if (!main || this.state.phase !== 'running') return;

    const hEl = main.querySelector('[data-part="h"]');
    const mEl = main.querySelector('[data-part="m"]');
    const sEl = main.querySelector('[data-part="s"]');
    const hWrap = main.querySelector('.cd-seg-hours');
    const nextH = String(h).padStart(2, '0');
    const nextM = String(m).padStart(2, '0');
    const nextS = String(s).padStart(2, '0');
    const tickPart = (el, next) => {
      if (!el) return;
      if (el.textContent === next) return;
      el.textContent = next;
      el.classList.remove('cd-tick');
      void el.offsetWidth;
      el.classList.add('cd-tick');
    };
    tickPart(hEl, nextH);
    tickPart(mEl, nextM);
    tickPart(sEl, nextS);
    if (hWrap) hWrap.classList.toggle('is-visible', h > 0);
    const hSep = main.querySelector('.cd-sep-h');
    if (hSep) hSep.classList.toggle('is-visible', h > 0);
    main.classList.toggle('is-final-minute', ms > 0 && ms <= 60000);
    main.classList.toggle('is-final-ten', ms > 0 && ms <= 10000);
    this.layer?.classList.toggle('is-urgency-minute', ms > 0 && ms <= 60000);
    this.layer?.classList.toggle('is-urgency-ten', ms > 0 && ms <= 10000);
  }

  renderRunning() {
    const main = this.layer?.querySelector('#countdown-main');
    if (!main) return;
    main.className = 'countdown-main countdown-running anim-fade-up';
    main.innerHTML = `
      <p class="countdown-label">${esc(this.state.label)}</p>
      <div class="countdown-clock-wrap">
        <div class="countdown-clock-aura" aria-hidden="true"></div>
        <div class="countdown-clock-ring" aria-hidden="true"></div>
        <div class="countdown-clock" aria-live="polite">
          <div class="cd-seg cd-seg-hours">
            <span class="cd-num" data-part="h">00</span>
            <span class="cd-unit">horas</span>
          </div>
          <span class="cd-sep cd-sep-h">:</span>
          <div class="cd-seg">
            <span class="cd-num" data-part="m">00</span>
            <span class="cd-unit">min</span>
          </div>
          <span class="cd-sep">:</span>
          <div class="cd-seg">
            <span class="cd-num" data-part="s">00</span>
            <span class="cd-unit">seg</span>
          </div>
        </div>
      </div>
      <article class="countdown-verse-card" id="countdown-verse-card" aria-live="polite">
        <p class="countdown-verse-ref" id="verse-card-ref"></p>
        <blockquote class="countdown-verse-text" id="verse-card-text"></blockquote>
      </article>`;
    if (this._lastVerse.reference) {
      this.showVerseCompact(this._lastVerse.reference, this._lastVerse.text);
    }
    this.updateDigits();
  }

  startVerseRotation() {
    TaskScheduler.unregister(TaskIds.COUNTDOWN_VERSE);
    this.loadNextVerse();
    const interval = Math.max(
      (this.state.verseIntervalSec || 22),
      (this.state.verseSpotlightSec || 8) + 6
    );
    this._verseDispose = TaskScheduler.register({
      id: TaskIds.COUNTDOWN_VERSE,
      kind: 'interval',
      intervalMs: interval * 1000,
      priority: 6,
      fn: () => this.loadNextVerse(),
    });
  }

  stopVerseRotation() {
    this._verseDispose?.();
    this._verseDispose = null;
    TaskScheduler.unregister(TaskIds.COUNTDOWN_VERSE);
  }

  clearPhaseTimers() {
    this._phaseDispose?.();
    this._phaseDispose = null;
    TaskScheduler.unregister(TaskIds.COUNTDOWN_PHASE);
    clearTimeout(this.phaseTimer);
    this.phaseTimer = null;
  }

  clearSpotlightTimer() {
    this._spotlightDispose?.();
    this._spotlightDispose = null;
    TaskScheduler.unregister(TaskIds.COUNTDOWN_SPOTLIGHT);
    clearTimeout(this._spotlightTimer);
    this._spotlightTimer = null;
  }

  clearVerse() {
    this.hideVerseSpotlight({ persistCompact: false });
    this.hideVerseCompact();
  }

  hideVerseCompact() {
    const card = this.layer?.querySelector('#countdown-verse-card');
    if (card) card.classList.remove('is-visible');
  }

  showVerseCompact(reference, text) {
    const card = this.layer?.querySelector('#countdown-verse-card');
    const refEl = this.layer?.querySelector('#verse-card-ref');
    const textEl = this.layer?.querySelector('#verse-card-text');
    if (!card || !refEl || !textEl) return;
    if (!reference && !text) {
      card.classList.remove('is-visible');
      refEl.textContent = '';
      textEl.textContent = '';
      return;
    }
    refEl.textContent = reference;
    textEl.textContent = text;
    card.classList.remove('is-visible');
    requestAnimationFrame(() => {
      card.classList.add('is-visible');
    });
  }

  presentVerse(reference, text) {
    if (!reference && !text) return;
    this._lastVerse = { reference, text };
    this.showVerseSpotlight(reference, text);
  }

  hideVerseSpotlight({ persistCompact = false } = {}) {
    this.clearSpotlightTimer();
    this.layer?.classList.remove('is-verse-spotlight');
    const spotlight = this.layer?.querySelector('#countdown-verse-spotlight');
    if (spotlight) spotlight.setAttribute('aria-hidden', 'true');
    if (persistCompact && this._lastVerse.reference) {
      this.showVerseCompact(this._lastVerse.reference, this._lastVerse.text);
    }
  }

  showVerseSpotlight(reference, text) {
    const spotlight = this.layer?.querySelector('#countdown-verse-spotlight');
    const refEl = this.layer?.querySelector('#spotlight-ref');
    const textEl = this.layer?.querySelector('#spotlight-text');
    if (!spotlight || !refEl || !textEl) {
      this.showVerseCompact(reference, text);
      return;
    }

    this._lastVerse = { reference, text };
    refEl.textContent = reference;
    textEl.textContent = text;

    this.clearSpotlightTimer();
    this.layer.classList.add('is-verse-spotlight');
    spotlight.setAttribute('aria-hidden', 'false');

    const sec = this.state.verseSpotlightSec || 8;
    this._spotlightDispose = TaskScheduler.scheduleDelayed(
      TaskIds.COUNTDOWN_SPOTLIGHT,
      sec * 1000,
      () => this.hideVerseSpotlight({ persistCompact: true }),
      4
    );
  }

  getFallbackVerse() {
    const ev = this.defaults.event || {};
    if (ev.mottoText) {
      return {
        reference: ev.motto || 'João 17:11',
        text: `"${ev.mottoText.replace(/^["']|["']$/g, '').trim()}"`,
      };
    }
    return {
      reference: 'Salmos 46:10',
      text: '"Aquietai-vos e sabei que eu sou Deus."',
    };
  }

  async loadNextVerse() {
    if (!this.active || this.state.phase !== 'running') return;
    if (this.state.showRandomVerses === false) return;
    const gen = this._verseGen;

    try {
      let reference = '';
      let text = '';

      if (this.state.includeEventMotto && Math.random() < 0.22) {
        const ev = this.defaults.event || {};
        reference = ev.motto || '';
        text = ev.mottoText ? `"${ev.mottoText.replace(/^["']|["']$/g, '').trim()}"` : '';
      } else {
        const ref = pickRandomVerseRef(COUNTDOWN_VERSE_POOL, this.currentVerseKey);
        this.currentVerseKey = verseKey(ref);
        const passage = await Promise.race([
          getPassage(
            this.bibleVersion,
            ref.book,
            ref.chapter,
            ref.verseStart,
            ref.verseEnd || ref.verseStart
          ),
          new Promise((_, reject) => setTimeout(() => reject(new Error('timeout')), 5000)),
        ]);
        if (gen !== this._verseGen) return;
        reference = passage.reference;
        text = passage.verses.map((v) => v.text).join(' ');
      }

      if (gen !== this._verseGen || this.state.phase !== 'running') return;

      const cleanText = text.replace(/^["']|["']$/g, '').trim();
      const displayText = cleanText ? (cleanText.startsWith('"') ? cleanText : `"${cleanText}"`) : '';
      if (displayText) {
        this.presentVerse(reference, displayText);
        return;
      }
      throw new Error('empty verse');
    } catch {
      if (gen !== this._verseGen || this.state.phase !== 'running') return;
      const fallback = this.getFallbackVerse();
      this.presentVerse(fallback.reference, fallback.text);
    }
  }

  enterAnnouncePhase() {
    if (this.state.phase !== 'running') return;
    clearInterval(this.tickTimer);
    clearInterval(this.verseTimer);
    this.hideVerseSpotlight({ persistCompact: false });
    this.hideVerseCompact();
    this.setPhase('announce');
    this.startAmbientFadeIfNeeded();
    this.renderAnnounce();
    this.startAnnounceSequence();
    this.scheduleAnnounceEnd();
  }

  playBellIfEnabled() {
    if (this._bellPlayed || this.state.playBell === false) return;
    this._bellPlayed = true;
    this.layer?.classList.add('is-bell-ring');
    TaskScheduler.scheduleDelayed(TaskIds.COUNTDOWN_BELL, 1400, () => {
      this.layer?.classList.remove('is-bell-ring');
    }, 8);
    const opts = {
      bellPath: this.state.bellPath || null,
      volume: this.state.bellVolume ?? 0.7,
    };
    if (this.onBellPlay) {
      this.onBellPlay(opts);
    }
  }

  startAmbientFadeIfNeeded() {
    if (this._ambientFadeStarted || this.state.fadeAmbientOnEnd === false) return;
    if (this.state.ambientFadeStart !== 'announce') return;
    this._ambientFadeStarted = true;
    const ms = (this.state.ambientFadeSec || 4) * 1000;
    this.triggerAmbientFade(ms);
  }

  startTransitionAmbientFade() {
    if (this._ambientFadeStarted || this.state.fadeAmbientOnEnd === false) return;
    this._ambientFadeStarted = true;
    const ms = (this.state.ambientFadeSec || 4) * 1000;
    this.triggerAmbientFade(ms);
  }

  triggerAmbientFade(durationMs) {
    if (this.ambientPlayer?.fadeOut) {
      if (!this.ambientPlayer.isPlaying?.()) return;
      this.ambientPlayer.fadeOut(durationMs);
      return;
    }
    this.onAmbientFade?.(durationMs);
  }

  renderAnnounce() {
    const main = this.layer?.querySelector('#countdown-main');
    if (!main) return;
    const notices = Array.isArray(this.state.notices) ? this.state.notices : [];
    main.className = 'countdown-main countdown-announce';
    main.innerHTML = `
      <div class="announce-scene">
        <div class="announce-header">
          <h1 class="announce-title anim-glow">${esc(this.state.announcementTitle)}</h1>
          <p class="announce-sub anim-fade-up delay-1">Prepare-se para um momento especial na presença de Deus</p>
        </div>
        <ul class="announce-list" aria-live="polite">
          ${notices.map((n, i) => `
            <li class="announce-item" data-index="${i}">
              <span class="announce-icon-wrap"><span class="announce-icon">${faNoticeIcon(n.icon, 'su-fa su-fa--lg')}</span></span>
              <span class="announce-text">${esc(n.text)}</span>
            </li>`).join('')}
        </ul>
      </div>`;
  }

  clearAnnounceSequence() {
    this._announceDisposers.forEach((d) => d?.());
    this._announceDisposers = [];
    this._announceTimers = [];
    this.layer?.classList.remove('is-announce-spotlight');
    const spotlight = this.layer?.querySelector('#announce-spotlight');
    spotlight?.classList.remove('is-settling');
    spotlight?.setAttribute('aria-hidden', 'true');
  }

  startAnnounceSequence() {
    this.clearAnnounceSequence();
    const notices = Array.isArray(this.state.notices) ? this.state.notices : [];
    if (!notices.length) return;

    const spotlightMs = (this.state.noticeSpotlightSec ?? 5) * 1000;
    const settleMs = 850;
    const gapMs = 750;
    const headerMs = 2000;

    let announceSeq = 0;
    const queue = (fn, delay) => {
      announceSeq += 1;
      const id = `countdown-announce-${announceSeq}`;
      const dispose = TaskScheduler.scheduleDelayed(id, delay, fn, 3);
      this._announceDisposers.push(dispose);
      this._announceTimers.push(id);
    };

    const runNotice = (index) => {
      if (!this.active || this.state.phase !== 'announce') return;

      if (index >= notices.length) {
        this.clearAnnounceSequence();
        this.layer?.querySelector('.announce-header')?.classList.remove('is-dimmed');
        return;
      }

      const notice = notices[index];
      const spotlight = this.layer?.querySelector('#announce-spotlight');
      const iconEl = this.layer?.querySelector('#announce-spotlight-icon');
      const textEl = this.layer?.querySelector('#announce-spotlight-text');
      const header = this.layer?.querySelector('.announce-header');

      if (iconEl) iconEl.innerHTML = faNoticeIcon(notice.icon, 'su-fa su-fa--lg');
      if (textEl) textEl.textContent = notice.text || '';
      if (spotlight) {
        spotlight.classList.remove('is-settling');
        spotlight.setAttribute('aria-hidden', 'false');
      }
      this.layer?.classList.add('is-announce-spotlight');
      header?.classList.add('is-dimmed');

      queue(() => {
        if (!this.active || this.state.phase !== 'announce') return;
        spotlight?.classList.add('is-settling');

        queue(() => {
          if (!this.active || this.state.phase !== 'announce') return;
          this.layer?.classList.remove('is-announce-spotlight');
          spotlight?.classList.remove('is-settling');
          spotlight?.setAttribute('aria-hidden', 'true');
          header?.classList.remove('is-dimmed');

          const item = this.layer?.querySelector(`.announce-item[data-index="${index}"]`);
          item?.classList.add('is-revealed');

          queue(() => runNotice(index + 1), gapMs);
        }, settleMs);
      }, spotlightMs);
    };

    queue(() => runNotice(0), headerMs);
  }

  scheduleAnnounceEnd() {
    this.clearPhaseTimers();
    const sec = computeAnnounceDurationSec(this.state);
    this._phaseDispose = TaskScheduler.scheduleDelayed(
      TaskIds.COUNTDOWN_PHASE,
      sec * 1000,
      () => this.enterTransitionPhase(),
      2
    );
  }

  enterTransitionPhase() {
    this.setPhase('transition');
    this.playBellIfEnabled();
    if (this.state.ambientFadeStart === 'transition') {
      this.startTransitionAmbientFade();
    }
    this.hideVerseSpotlight();
    this.renderTransition();
    this.scheduleTransitionEnd();
  }

  renderTransition() {
    const main = this.layer?.querySelector('#countdown-main');
    if (!main) return;
    const brand = this.layer?.querySelector('.countdown-brand');
    if (brand) brand.style.display = 'none';

    const logo = this.layer?.querySelector('.countdown-logo')?.src
      || assetUrl(this.assets, 'logo', PRODUCT_LOGO_REL);
    const themeRaw = this.defaults.event?.theme || 'SOMOS UM';
    const themeParts = themeRaw.trim().split(/\s+/).filter(Boolean);
    const themeHtml = themeParts.length > 1
      ? themeParts.map((word, i) =>
          `<span class="transition-word-part" style="--tw-i:${i}">${esc(word)}</span>`
        ).join('<span class="transition-word-gap" aria-hidden="true"> </span>')
      : `<span class="transition-word-part">${esc(themeRaw)}</span>`;

    main.className = 'countdown-main countdown-transition-scene';
    main.innerHTML = `
      <div class="transition-stage">
        <div class="transition-burst" aria-hidden="true"></div>
        <div class="transition-rays" aria-hidden="true"></div>
        <div class="transition-ring ring-outer" aria-hidden="true"></div>
        <div class="transition-ring ring-inner" aria-hidden="true"></div>
        <div class="transition-content">
          <span class="transition-shimmer" aria-hidden="true"></span>
          <img class="transition-logo" src="${logo}" alt="" />
          <h1 class="transition-word">${themeHtml}</h1>
          <div class="transition-divider" aria-hidden="true"></div>
          <p class="transition-sub">Entrando no culto...</p>
        </div>
      </div>`;
    this.layer.classList.add('is-transitioning');
    this.layer?.querySelector('.countdown-transition-backdrop')?.setAttribute('aria-hidden', 'false');
  }

  scheduleTransitionEnd() {
    this.clearPhaseTimers();
    const sec = this.state.transitionDurationSec || 4;
    this._phaseDispose = TaskScheduler.scheduleDelayed(
      TaskIds.COUNTDOWN_PHASE,
      sec * 1000,
      () => this.complete(),
      2
    );
  }

  complete() {
    const welcomeSlide = this.state?.welcomeSlide || null;
    const autoWelcome = this.state?.autoGoToWelcome !== false;
    this.stop(true);
    this.onComplete?.({ welcomeSlide, autoWelcome });
  }

  stop(completed = false) {
    this.active = false;
    this.stopTick();
    this.stopVerseRotation();
    this.clearPhaseTimers();
    this.clearSpotlightTimer();
    this.hideVerseSpotlight({ persistCompact: false });
    this.clearAnnounceSequence();
    TaskScheduler.unregister(TaskIds.COUNTDOWN_BELL);
    document.documentElement.classList.remove('countdown-active');
    this.layer?.classList.remove('is-transitioning');
    this.layer?.querySelector('.countdown-transition-backdrop')?.setAttribute('aria-hidden', 'true');
    this.layer?.remove();
    this.layer = null;
    this.state = null;
    this._bellPlayed = false;
    this._ambientFadeStarted = false;
    this._lastVerse = { reference: '', text: '' };
    if (!completed) {
      this.onPhaseChange?.('idle');
    }
  }

  isActive() {
    return this.active;
  }

}
