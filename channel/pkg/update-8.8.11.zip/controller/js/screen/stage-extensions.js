/** Stage Pro — extensões do retorno ao ministério */
import { normalizeStageLayout } from './stage-layouts.js';

function normalizeLayout(layout) {
  return normalizeStageLayout(layout);
}

export function wireStagePro(app, { prefsKey = 'somosum-stage-pro' } = {}) {
  let urlLayout = '';
  try {
    const params = new URLSearchParams(window.location.search || '');
    urlLayout = normalizeLayout(params.get('layout') || '');
  } catch { /* ignore */ }
  let openHint = '';
  try {
    openHint = normalizeLayout(localStorage.getItem('somosum-stage-open-layout') || '');
    if (openHint) localStorage.removeItem('somosum-stage-open-layout');
  } catch { /* ignore */ }

  const stored = localStorage.getItem(`${prefsKey}-layout`) || 'musician';
  const initial = urlLayout || openHint || normalizeLayout(stored);
  const state = {
    layout: initial,
    fullLyrics: localStorage.getItem(`${prefsKey}-full-lyrics`) === '1',
    metronomeBpm: null,
    timerStartedAt: null,
  };

  if (stored !== state.layout) {
    localStorage.setItem(`${prefsKey}-layout`, state.layout);
  }

  let onLayoutChange = null;

  app.getStageProLayout = () => state.layout;

  app.setStageProLayout = (layout) => {
    const next = normalizeLayout(layout);
    if (!next || next === state.layout) {
      document.body.dataset.stageLayout = state.layout;
      return state.layout;
    }
    state.layout = next;
    localStorage.setItem(`${prefsKey}-layout`, next);
    document.body.dataset.stageLayout = next;
    try {
      onLayoutChange?.(next);
      window.dispatchEvent(new CustomEvent('somosum-stage-layout-change', { detail: next }));
    } catch (err) {
      console.warn('[stage] falha ao aplicar perfil', next, err);
    }
    return next;
  };

  app.onStageLayoutChange = (cb) => { onLayoutChange = cb; };

  app.startStageTimer = () => { state.timerStartedAt = Date.now(); };

  app.resetStageTimer = () => { state.timerStartedAt = null; };

  app.getStageTimerSec = () => (state.timerStartedAt ? Math.floor((Date.now() - state.timerStartedAt) / 1000) : 0);

  app.setMetronomeBpm = (bpm) => { state.metronomeBpm = bpm; };

  app.getMetronomeBpm = () => state.metronomeBpm;

  document.body.dataset.stageLayout = state.layout;

  return app;
}
