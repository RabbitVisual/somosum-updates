/**
 * Cache local do último slide projetado (failover offline na screen).
 * Autoridade continua no Controle via FULL_STATE quando reconectar.
 */
const STORAGE_KEY = 'somosum-screen-last-slide-v1';
const IDB_NAME = 'somosum-screen-failover';
const IDB_STORE = 'snapshots';
const IDB_KEY = 'last';

function openDb() {
  return new Promise((resolve, reject) => {
    if (!window.indexedDB) {
      reject(new Error('no-idb'));
      return;
    }
    const req = indexedDB.open(IDB_NAME, 1);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(IDB_STORE)) db.createObjectStore(IDB_STORE);
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error || new Error('idb-open'));
  });
}

export async function saveLastSlideSnapshot(snapshot) {
  if (!snapshot?.slide) return;
  const payload = {
    slide: snapshot.slide,
    prefs: snapshot.prefs || null,
    theme: snapshot.theme || null,
    seq: Number(snapshot.seq) || 0,
    ts: Date.now(),
  };
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(payload));
  } catch { /* quota */ }
  try {
    const db = await openDb();
    await new Promise((resolve, reject) => {
      const tx = db.transaction(IDB_STORE, 'readwrite');
      tx.objectStore(IDB_STORE).put(payload, IDB_KEY);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
    db.close();
  } catch { /* ignore */ }
}

export async function loadLastSlideSnapshot() {
  try {
    const db = await openDb();
    const row = await new Promise((resolve, reject) => {
      const tx = db.transaction(IDB_STORE, 'readonly');
      const req = tx.objectStore(IDB_STORE).get(IDB_KEY);
      req.onsuccess = () => resolve(req.result || null);
      req.onerror = () => reject(req.error);
    });
    db.close();
    if (row?.slide) return row;
  } catch { /* fall through */ }
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    return parsed?.slide ? parsed : null;
  } catch {
    return null;
  }
}

export const SCREEN_FAILOVER_STORAGE_KEY = STORAGE_KEY;
