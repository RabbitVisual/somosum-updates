/**
 * Sessão do Músico — cifra estável; o operador pode repetir estrofes sem puxar a leitura.
 */
import { normalizeStageLayout } from './stage-layouts.js';

export function musicianSongKey(state = {}) {
  return String(
    state.itemTitle
    || state.chordChart?.title
    || state.fullSongLyrics?.title
    || '',
  ).trim();
}

export function musicianLivePillText(slide) {
  const lines = (slide?.lines || []).filter(Boolean);
  if (!lines.length) return 'Aguardando louvor no projetor';
  const preview = lines.slice(0, 2).join(' · ');
  const extra = lines.length > 2 ? ` (+${lines.length - 2})` : '';
  return `${preview}${extra}`;
}

export function renderMusicianLivePillHtml(slide, { repeating = false } = {}) {
  const text = musicianLivePillText(slide);
  const repeatHint = repeating
    ? '<span class="stage-musician-live-pill__repeat">Repetição no projetor</span>'
    : '';
  return `
    <div class="stage-musician-live-pill" id="stage-musician-live-pill" role="status" aria-live="polite">
      <span class="stage-musician-live-pill__kicker">No projetor agora</span>
      <span class="stage-musician-live-pill__text">${escapeHtml(text)}</span>
      ${repeatHint}
    </div>`;
}

function escapeHtml(s) {
  return String(s || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

export function createMusicianSession() {
  return {
    songKey: '',
    maxSlideIndex: -1,
    lastSlideIndex: -1,
  };
}

export function updateMusicianSession(session, state, slide) {
  const key = musicianSongKey(state);
  const idx = Number.isFinite(slide?.slideIndex) ? slide.slideIndex : -1;
  if (key !== session.songKey) {
    session.songKey = key;
    session.maxSlideIndex = idx;
    session.lastSlideIndex = idx;
    return { reset: true, repeating: false };
  }
  const repeating = idx >= 0 && idx < session.maxSlideIndex;
  if (idx > session.maxSlideIndex) session.maxSlideIndex = idx;
  session.lastSlideIndex = idx;
  return { reset: false, repeating };
}

export function shouldStabilizeMusicianView({ layout, chordMode, slide, chartSource }) {
  if (normalizeStageLayout(layout) !== 'musician') return false;
  if (!chordMode || !chartSource?.trim()) return false;
  return slide?.type === 'lyrics' && (!!(slide.lines?.length) || slide.slideIndex != null);
}

export function patchMusicianLivePill(root, slide, { repeating = false } = {}) {
  const host = root?.querySelector?.('#stage-musician-live-pill');
  if (!host) return false;
  const textEl = host.querySelector('.stage-musician-live-pill__text');
  if (textEl) textEl.textContent = musicianLivePillText(slide);
  let repeatEl = host.querySelector('.stage-musician-live-pill__repeat');
  if (repeating) {
    if (!repeatEl) {
      repeatEl = document.createElement('span');
      repeatEl.className = 'stage-musician-live-pill__repeat';
      repeatEl.textContent = 'Repetição no projetor';
      host.appendChild(repeatEl);
    }
  } else if (repeatEl) {
    repeatEl.remove();
  }
  return true;
}
