/** Stage aux panel — lista de momentos + alertas para o palco. */

export function mountStageAuxPanel(root, bus, MessageTypes) {
  if (!root || root.querySelector('.stage-aux-panel')) return;
  const panel = document.createElement('aside');
  panel.className = 'stage-aux-panel';
  panel.innerHTML = `
    <header class="stage-aux-head">Auxiliar</header>
    <ul class="stage-aux-list" id="stage-aux-list"></ul>
    <div class="stage-aux-alert" id="stage-aux-alert" hidden></div>`;
  root.appendChild(panel);
  const listEl = panel.querySelector('#stage-aux-list');
  const alertEl = panel.querySelector('#stage-aux-alert');

  bus.on((msg) => {
    if (msg.type === MessageTypes.STAGE_STATE || msg.type === MessageTypes.FULL_STATE) {
      const moments = msg.payload?.moments || msg.payload?.programState?.moments || [];
      if (Array.isArray(moments) && moments.length) {
        listEl.innerHTML = moments.map((m) =>
          `<li class="stage-aux-item${m.live ? ' is-live' : ''}">${m.title || m.label || ''}</li>`
        ).join('');
      }
      const alert = msg.payload?.alert || '';
      if (alert) {
        alertEl.hidden = false;
        alertEl.textContent = alert;
      } else {
        alertEl.hidden = true;
      }
    }
  });
}
