import { normalizeAmbientState, encodeAudioPath } from '../core/ambient-audio.js';

export class AmbientAudioPlayer {
  constructor(rootEl, options = {}) {
    this.root = rootEl || document.body;
    this.role = options.role || 'screen';
    this.audio = document.createElement('audio');
    this.audio.id = this.role === 'control' ? 'ambient-audio-control' : 'ambient-audio';
    this.audio.preload = 'auto';
    this.audio.setAttribute('playsinline', '');
    this.root.appendChild(this.audio);
    this.state = normalizeAmbientState();
    this._fadeRaf = null;
    this._targetVolume = null;
    this.needsUnlock = false;
    this._unlockBound = false;
    this._lastError = null;
    this._preloadPath = null;
    this._readyPromise = null;
    this._progressTimer = null;

    this.audio.addEventListener('error', () => {
      this._lastError = this.audio.error?.code === 4 ? 'Arquivo não encontrado' : 'Erro ao carregar áudio';
      this.state = { ...this.state, playing: false };
      this.onError?.(this._lastError);
      this.onPlaybackError?.(this._lastError);
    });

    this.audio.addEventListener('timeupdate', () => {
      if (!this.state.playing) return;
      this.onProgress?.({
        current: this.audio.currentTime,
        duration: this.audio.duration || 0,
        pct: this.audio.duration ? (this.audio.currentTime / this.audio.duration) * 100 : 0,
      });
    });

    if (this.role === 'screen') {
      this.bindScreenUnlock();
    }
  }

  bindScreenUnlock() {
    if (this._unlockBound) return;
    this._unlockBound = true;
    const tryUnlock = () => {
      if (this.needsUnlock && this.state.playing) {
        this.unlockAndPlay();
      }
    };
    document.addEventListener('pointerdown', tryUnlock, { passive: true });
    document.addEventListener('keydown', tryUnlock);
  }

  cancelFade() {
    if (this._fadeRaf) {
      cancelAnimationFrame(this._fadeRaf);
      this._fadeRaf = null;
    }
  }

  isPlaying() {
    return this.state.playing && !this.audio.paused;
  }

  ensureSource(trackPath) {
    if (!trackPath) return false;
    if (this.audio.getAttribute('data-track') !== trackPath) {
      this.cancelFade();
      this.audio.setAttribute('data-track', trackPath);
      this.audio.src = encodeAudioPath(trackPath);
      this._lastError = null;
      this._readyPromise = null;
      this.audio.load();
    }
    return true;
  }

  preloadTrack(trackPath) {
    if (!trackPath) return Promise.resolve(false);
    this._preloadPath = trackPath;
    this.ensureSource(trackPath);
    return this.waitReady(6000);
  }

  waitReady(timeoutMs = 4000) {
    if (!this.audio.src) return Promise.resolve(false);
    if (this.audio.readyState >= 2) return Promise.resolve(true);
    if (this._readyPromise) return this._readyPromise;

    this._readyPromise = new Promise((resolve) => {
      let done = false;
      const finish = (ok) => {
        if (done) return;
        done = true;
        cleanup();
        resolve(ok);
      };
      const cleanup = () => {
        this.audio.removeEventListener('canplaythrough', onReady);
        this.audio.removeEventListener('canplay', onReady);
        this.audio.removeEventListener('error', onError);
        clearTimeout(timer);
        this._readyPromise = null;
      };
      const onReady = () => finish(true);
      const onError = () => finish(false);
      const timer = setTimeout(() => finish(this.audio.readyState >= 2), timeoutMs);
      this.audio.addEventListener('canplaythrough', onReady, { once: true });
      this.audio.addEventListener('canplay', onReady, { once: true });
      this.audio.addEventListener('error', onError, { once: true });
      if (this.audio.readyState < 1) this.audio.load();
    });
    return this._readyPromise;
  }

  async warmStart() {
    if (!this.state.trackPath) return false;
    this.ensureSource(this.state.trackPath);
    await this.waitReady(5000);
    return this.audio.readyState >= 2;
  }

  fadeTo(targetVolume, durationMs = 3000, { pauseAtZero = false } = {}) {
    this.cancelFade();
    const target = Math.min(1, Math.max(0, targetVolume));
    const startVol = this.audio.volume;
    const start = performance.now();

    if (!this.state.playing && target > 0) return;

    const step = (now) => {
      const t = Math.min(1, (now - start) / durationMs);
      const eased = 1 - (1 - t) ** 2;
      this.audio.volume = startVol + (target - startVol) * eased;

      if (t < 1) {
        this._fadeRaf = requestAnimationFrame(step);
      } else {
        this._fadeRaf = null;
        this.audio.volume = target;
        this._targetVolume = target;
        if (pauseAtZero && target <= 0.001) {
          this.audio.pause();
          this.onFadeOutComplete?.();
        }
      }
    };

    this._fadeRaf = requestAnimationFrame(step);
  }

  fadeOut(durationMs = 4000) {
    if (!this.state.playing) return;
    this.fadeTo(0, durationMs, { pauseAtZero: true });
  }

  restoreVolume() {
    this.cancelFade();
    const vol = this.state.volume ?? 0.3;
    this.audio.volume = vol;
    this._targetVolume = null;
  }

  async unlockAndPlay() {
    if (!this.state.trackPath) return false;
    this.ensureSource(this.state.trackPath);
    await this.waitReady(3000);
    this.audio.muted = false;
    this.restoreVolume();
    try {
      await this.audio.play();
      this.needsUnlock = false;
      this.hideUnlockPrompt();
      this.onPlaybackStarted?.();
      return true;
    } catch {
      this.needsUnlock = true;
      this.showUnlockPrompt();
      this.onNeedsUnlock?.();
      return false;
    }
  }

  async startPlayback() {
    if (!this.ensureSource(this.state.trackPath)) return false;

    this.audio.loop = this.state.loop;
    this.restoreVolume();
    this.audio.muted = false;
    await this.waitReady(4000);

    try {
      await this.audio.play();
      this.needsUnlock = false;
      this.hideUnlockPrompt();
      this.onPlaybackStarted?.();
      return true;
    } catch {
      this.audio.muted = true;
      try {
        await this.audio.play();
        this.needsUnlock = true;
        this.showUnlockPrompt();
        this.onNeedsUnlock?.();
        return false;
      } catch {
        this.needsUnlock = true;
        this.showUnlockPrompt();
        this.onNeedsUnlock?.();
        return false;
      }
    }
  }

  apply(next = {}) {
    if (next.action === 'fadeOut') {
      this.fadeOut(next.durationMs || 4000);
      return;
    }
    if (next.action === 'fadeTo') {
      this.fadeTo(next.volume ?? 0, next.durationMs || 3000, { pauseAtZero: next.pauseAtZero });
      return;
    }

    const s = normalizeAmbientState({ ...this.state, ...next });
    const wasPlaying = this.state.playing;
    const trackChanged = this.state.trackPath !== s.trackPath;
    this.state = s;
    this.audio.loop = s.loop;

    if (!s.trackPath) {
      this.cancelFade();
      this.audio.pause();
      this.audio.removeAttribute('src');
      this.audio.removeAttribute('data-track');
      this.needsUnlock = false;
      this.hideUnlockPrompt();
      this._preloadPath = null;
      return;
    }

    this.ensureSource(s.trackPath);

    if (!s.playing) {
      if (trackChanged || this._preloadPath !== s.trackPath) {
        this.preloadTrack(s.trackPath);
      }
      this.cancelFade();
      this.audio.pause();
      this.audio.muted = false;
      this.audio.volume = s.volume;
      this._targetVolume = null;
      this.needsUnlock = false;
      this.hideUnlockPrompt();
      return;
    }

    if (this._targetVolume === null) {
      this.audio.volume = s.volume;
    }
    this.audio.muted = false;

    if (this.role === 'control') {
      this.startPlayback().then((ok) => {
        if (!ok && s.playing) {
          this.state = { ...this.state, playing: false };
          this.onPlaybackError?.('Reprodução bloqueada ou arquivo inválido');
          this.onError?.('Reprodução bloqueada ou arquivo inválido');
        }
      });
      return;
    }

    if (s.playing && (!wasPlaying || this.needsUnlock || this.audio.paused || trackChanged)) {
      this.startPlayback();
    } else if (s.playing && !this.audio.paused) {
      this.audio.volume = s.volume;
      this.audio.muted = false;
    }
  }

  showUnlockPrompt() {
    if (this.role !== 'screen' || this._unlockEl || !this.state.playing) return;
    this._unlockEl = document.createElement('button');
    this._unlockEl.type = 'button';
    this._unlockEl.className = 'ambient-unlock';
    this._unlockEl.innerHTML = `
      <span class="ambient-unlock-icon">♫</span>
      <span class="ambient-unlock-title">Música de fundo pronta</span>
      <span class="ambient-unlock-sub">Clique em qualquer lugar desta tela para ativar o som</span>`;
    this._unlockEl.onclick = (e) => {
      e.stopPropagation();
      this.unlockAndPlay();
    };
    document.body.appendChild(this._unlockEl);
  }

  hideUnlockPrompt() {
    this._unlockEl?.remove();
    this._unlockEl = null;
  }
}
