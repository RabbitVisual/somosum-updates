/** Perfis oficiais do Púlpito — Cantor, Músico, Pregador. */
export const STAGE_CORE_LAYOUTS = [
  { id: 'singer', label: 'Cantor' },
  { id: 'musician', label: 'Músico' },
  { id: 'preacher', label: 'Pregador' },
];

const LEGACY_MAP = {
  operator: 'musician',
  'lyrics-focus': 'singer',
  'verse-focus': 'singer',
  'moment-board': 'musician',
  'sermon-timer': 'preacher',
};

export function normalizeStageLayout(layout) {
  const id = String(layout || '').trim() || 'musician';
  if (LEGACY_MAP[id]) return LEGACY_MAP[id];
  if (STAGE_CORE_LAYOUTS.some((l) => l.id === id)) return id;
  return 'musician';
}

export function stageLayoutLabel(layout) {
  const id = normalizeStageLayout(layout);
  return STAGE_CORE_LAYOUTS.find((l) => l.id === id)?.label || id;
}
