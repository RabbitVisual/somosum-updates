/**
 * Modo Operador do Stage — navegação touch via REMOTE_CMD (mesmo canal do Remote).
 */
import { MessageTypes } from '../core/bus.js';
import { faIcon } from '../core/fa-icons.js';

const KEY = 'somosum-stage-operator';

export function isStageOperatorMode() {
  try { return localStorage.getItem(KEY) === '1'; } catch { return false; }
}

export function setStageOperatorMode(on) {
  try { localStorage.setItem(KEY, on ? '1' : '0'); } catch { /* ignore */ }
}

export function renderOperatorBarHtml(operatorOn) {
  if (!operatorOn) {
    return `
      <div class="stage-operator-bar stage-operator-bar--off">
        <button type="button" class="stage-op-toggle" id="stage-op-toggle" title="Ativar comandos touch">
          ${faIcon('sliders', 'su-fa su-fa--inline-btn')} Ativar modo Operador
        </button>
        <span class="stage-op-hint">Púlpito só leitura · toque para comandar o culto</span>
      </div>`;
  }
  return `
    <div class="stage-operator-bar is-active">
      <div class="stage-op-transport">
        <button type="button" class="stage-op-btn" data-stage-cmd="prev">${faIcon('prev')} Ant.</button>
        <button type="button" class="stage-op-btn stage-op-btn--primary" data-stage-cmd="next">${faIcon('next')} Próx.</button>
        <button type="button" class="stage-op-btn" data-stage-cmd="blank">${faIcon('blank')} Preta</button>
        <button type="button" class="stage-op-btn" data-stage-cmd="logo">${faIcon('logo')} Logo</button>
        <button type="button" class="stage-op-btn" data-stage-cmd="clearOverlay">${faIcon('close')} Limpar</button>
        <button type="button" class="stage-op-btn" data-stage-cmd="dismissAlert">${faIcon('macros')} Parar aviso</button>
      </div>
      <button type="button" class="stage-op-toggle is-on" id="stage-op-toggle" title="Voltar ao Púlpito">
        Modo Operador · desligar
      </button>
    </div>`;
}

/**
 * @param {HTMLElement} root
 * @param {{ bus: any, onToggle: (on: boolean) => void, getProgramItems?: () => any[] }} opts
 */
export function bindStageOperator(root, { bus, onToggle, getProgramItems } = {}) {
  if (!root || !bus) return () => {};

  const send = (action, extra = {}) => {
    try { navigator.vibrate?.(12); } catch { /* ignore */ }
    bus.send(MessageTypes.REMOTE_CMD, { action, ...extra, source: 'stage-operator' });
    bus.hub?.boostPolling?.();
  };

  const onClick = (e) => {
    const toggle = e.target.closest?.('#stage-op-toggle');
    if (toggle) {
      const next = !isStageOperatorMode();
      if (next) {
        const ok = window.confirm(
          'Ativar Modo Operador neste Púlpito?\n\nVocê poderá avançar slides, overlays e avisos (comandos vão ao Controle).',
        );
        if (!ok) return;
      }
      setStageOperatorMode(next);
      onToggle?.(next);
      return;
    }
    const cmdBtn = e.target.closest?.('[data-stage-cmd]');
    if (cmdBtn && isStageOperatorMode()) {
      send(cmdBtn.dataset.stageCmd);
      return;
    }
    const railItem = e.target.closest?.('.stage-rail-item[data-go]');
    if (railItem && isStageOperatorMode()) {
      const idx = parseInt(railItem.dataset.go, 10);
      if (Number.isFinite(idx)) send('goToItem', { itemIndex: idx });
    }
  };

  let touchStartX = 0;
  let touchStartY = 0;
  const onTouchStart = (e) => {
    if (!isStageOperatorMode()) return;
    const t = e.changedTouches?.[0];
    if (!t) return;
    touchStartX = t.clientX;
    touchStartY = t.clientY;
  };
  const onTouchEnd = (e) => {
    if (!isStageOperatorMode()) return;
    if (e.target?.closest?.('button, a, input, .stage-rail')) return;
    const t = e.changedTouches?.[0];
    if (!t) return;
    const dx = t.clientX - touchStartX;
    const dy = t.clientY - touchStartY;
    if (Math.abs(dx) < 56 || Math.abs(dx) < Math.abs(dy)) return;
    send(dx < 0 ? 'next' : 'prev');
  };

  root.addEventListener('click', onClick);
  root.addEventListener('touchstart', onTouchStart, { passive: true });
  root.addEventListener('touchend', onTouchEnd, { passive: true });

  // Enrich rail with data-go when operator mode (caller may re-render)
  const syncRail = () => {
    if (!isStageOperatorMode()) return;
    const items = getProgramItems?.() || [];
    root.querySelectorAll('.stage-rail-item').forEach((li, i) => {
      const idx = items[i]?.index ?? i;
      li.dataset.go = String(idx);
      li.classList.add('is-operable');
    });
  };
  syncRail();

  return () => {
    root.removeEventListener('click', onClick);
    root.removeEventListener('touchstart', onTouchStart);
    root.removeEventListener('touchend', onTouchEnd);
  };
}
