/**
 * Auto-scroll Stage — segue destaque, velocidade manual ou sync BPM.
 */
let mode = 'off'; // off | follow | manual | bpm
let speed = 1;
let paused = false;
let _timer = null;
let _scrollEl = null;

export function getAutoScrollState() {
  return { mode, speed, paused };
}

export function setAutoScrollMode(m) {
  mode = m || 'off';
  if (mode === 'off') {
    paused = false;
    stopAutoScroll();
  }
}

export function setAutoScrollSpeed(s) {
  speed = Math.max(0.25, Math.min(4, Number(s) || 1));
}

export function setAutoScrollPaused(on) {
  paused = !!on;
  if (paused) {
    if (_timer) {
      clearInterval(_timer);
      _timer = null;
    }
  } else if (mode === 'manual' || mode === 'bpm') {
    onStageSlideChange({ container: _scrollEl });
  } else if (mode === 'follow') {
    scrollHighlightIntoView(_scrollEl || document);
  }
}

export function toggleAutoScrollPaused() {
  setAutoScrollPaused(!paused);
  return paused;
}

export function bindAutoScrollContainer(el) {
  _scrollEl = el || null;
}

export function stopAutoScroll() {
  if (_timer) {
    clearInterval(_timer);
    _timer = null;
  }
}

/** Resolve o elemento que realmente rola (cifra, letra completa ou body). */
export function resolveStageScrollContainer(root = document) {
  const body = root?.querySelector?.('#stage-live-body') || document.getElementById('stage-live-body');
  if (!body) return null;
  const inner = body.querySelector('.stage-full-scroll, .stage-chord-pre');
  if (inner) return inner;
  return body;
}

const HIGHLIGHT_SELECTORS = [
  '.stage-full-stanza.is-current-stanza',
  '.stage-chord-block.is-current',
  '.lyrics-line.is-highlight',
  '.stage-full-line.is-current',
  '.stage-chord-line--current',
].join(', ');

/** Segue bloco/estrofe destacada. */
export function scrollHighlightIntoView(root = document) {
  const scope = root?.querySelector ? root : document;
  const el = scope.querySelector?.(HIGHLIGHT_SELECTORS);
  if (!el) return;
  el.scrollIntoView({ block: 'center', behavior: 'smooth' });
}

export function startManualAutoScroll(container, { pxPerTick = 2, intervalMs = 50 } = {}) {
  stopAutoScroll();
  if (paused) return;
  const el = container || _scrollEl || resolveStageScrollContainer();
  if (!el) return;
  _scrollEl = el;
  _timer = setInterval(() => {
    if (mode !== 'manual' && mode !== 'bpm') return;
    if (paused) return;
    const maxScroll = el.scrollHeight - el.clientHeight;
    if (maxScroll <= 0) return;
    const delta = pxPerTick * speed;
    el.scrollTop = Math.min(el.scrollTop + delta, maxScroll);
  }, intervalMs);
}

export function startBpmAutoScroll(container, bpm, { linesPerMinute = 4 } = {}) {
  stopAutoScroll();
  if (paused) return;
  const el = container || _scrollEl || resolveStageScrollContainer();
  if (!el || !bpm) return;
  _scrollEl = el;
  const msPerLine = (60000 / bpm) * (4 / linesPerMinute);
  _timer = setInterval(() => {
    if (mode !== 'bpm') return;
    if (paused) return;
    const maxScroll = el.scrollHeight - el.clientHeight;
    if (maxScroll <= 0) return;
    el.scrollTop = Math.min(el.scrollTop + 8 * speed, maxScroll);
  }, Math.max(200, msPerLine));
}

export function onStageSlideChange({ mode: m, bpm, container, forceFollow } = {}) {
  if (m) mode = m;
  const resolved = container || resolveStageScrollContainer();
  if (resolved) _scrollEl = resolved;
  if (mode === 'follow' || forceFollow) {
    stopAutoScroll();
    if (!paused || forceFollow) scrollHighlightIntoView(resolved || document);
  } else if (mode === 'manual' && !paused) {
    startManualAutoScroll(resolved);
  } else if (mode === 'bpm' && bpm && !paused) {
    startBpmAutoScroll(resolved, bpm);
  } else if (mode === 'off' || paused) {
    stopAutoScroll();
  }
}
