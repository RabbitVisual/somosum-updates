/** Culto report export — Holyrics played/schedule reports parity. */

import { getPrefs } from '../core/store.js';

export function buildCultoReport({ program, playedSlides = [], startedAt, endedAt } = {}) {
  const church = getPrefs()?.church?.name || '';
  return {
    church,
    startedAt: startedAt || null,
    endedAt: endedAt || new Date().toISOString(),
    itemCount: program?.items?.length || 0,
    slidesPlayed: playedSlides.length,
    items: (program?.items || []).map((it, i) => ({
      index: i,
      title: it.title,
      type: it.type,
      played: playedSlides.some((p) => p.itemIndex === i),
    })),
  };
}

export function downloadCultoReportCsv(report) {
  const rows = [
    ['#', 'Título', 'Tipo', 'Projetado'],
    ...(report.items || []).map((it) => [it.index + 1, it.title, it.type, it.played ? 'sim' : 'não']),
  ];
  const csv = rows.map((r) => r.map((c) => `"${String(c).replace(/"/g, '""')}"`).join(',')).join('\n');
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `culto-report-${Date.now()}.csv`;
  a.click();
  URL.revokeObjectURL(url);
}
