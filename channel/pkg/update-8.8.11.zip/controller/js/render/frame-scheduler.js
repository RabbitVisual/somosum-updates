import { TaskScheduler } from '../core/task-scheduler.js';

let budgetMs = 16;

/** @deprecated Use TaskScheduler.scheduleFrame — mantido para compatibilidade. */
export const FrameScheduler = {
  setBudget(ms) { budgetMs = ms; },
  schedule(fn) {
    return TaskScheduler.scheduleFrame(() => {
      const start = performance.now();
      const result = fn();
      const elapsed = performance.now() - start;
      if (elapsed > budgetMs) {
        window.dispatchEvent(new CustomEvent('somosum-frame-over-budget', { detail: { elapsed } }));
      }
      return result;
    });
  },
};

export { TaskScheduler };
