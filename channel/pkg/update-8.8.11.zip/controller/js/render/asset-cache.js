const cache = new Map();
const MAX = 80;
const objectUrls = new Map();

export const AssetCache = {
  get(key) { return cache.get(key); },
  set(key, value) {
    if (cache.size >= MAX) cache.delete(cache.keys().next().value);
    cache.set(key, value);
  },
  clear() { cache.clear(); },
};

function revokeObjectUrl(src) {
  const prev = objectUrls.get(src);
  if (prev) {
    try { URL.revokeObjectURL(prev); } catch { /* */ }
    objectUrls.delete(src);
  }
}

export const ImageCache = {
  _map: new Map(),
  _maxSize: 80,
  _metrics: { hits: 0, misses: 0, workerLoads: 0 },

  async load(src) {
    if (this._map.has(src)) {
      this._metrics.hits += 1;
      return this._map.get(src);
    }
    this._metrics.misses += 1;
    const isProjection = document.documentElement?.dataset?.productionMode === '1'
      || document.documentElement?.dataset?.screenOutput
      || document.documentElement?.dataset?.renderSurface === 'screen';
    const max = isProjection
      ? 24
      : (window.__SOMOSUM_PRODUCTION_CACHE_MAX ? (this._maxSize || 160) : (this._maxSize || 80));
    if (this._map.size >= max) {
      const oldKey = this._map.keys().next().value;
      revokeObjectUrl(oldKey);
      this._map.delete(oldKey);
    }

    const p = this._loadImage(src);
    this._map.set(src, p);
    return p;
  },

  async _loadImage(src) {
    try {
      const { runWorkerTask, isWorkerSupported } = await import('../core/worker-pool.js');
      if (isWorkerSupported() && /^https?:/.test(src)) {
        const workerUrl = new URL('../workers/media-decode-worker.js', import.meta.url);
        const data = await runWorkerTask(workerUrl, { url: src }, {
          fallback: () => Promise.reject(new Error('skip-worker')),
        });
        if (data?.blob) {
          this._metrics.workerLoads += 1;
          revokeObjectUrl(src);
          const objUrl = URL.createObjectURL(data.blob);
          objectUrls.set(src, objUrl);
          return this._imageFromUrl(objUrl, src);
        }
      }
    } catch { /* fallback main thread */ }
    return this._imageFromUrl(src, src);
  },

  _imageFromUrl(url, revokeKey) {
    return new Promise((res) => {
      const img = new Image();
      img.onload = () => res(img);
      img.onerror = () => {
        if (String(url).startsWith('blob:')) revokeObjectUrl(revokeKey);
        this._map.delete(revokeKey);
        res(null);
      };
      img.src = url;
      img.dataset.cacheKey = revokeKey;
    });
  },

  clear() {
    for (const key of objectUrls.keys()) revokeObjectUrl(key);
    this._map.clear();
  },

  trim(keep = 20) {
    while (this._map.size > keep) {
      const oldKey = this._map.keys().next().value;
      revokeObjectUrl(oldKey);
      this._map.delete(oldKey);
    }
  },

  getMetrics() {
    return { ...this._metrics, size: this._map.size, max: this._maxSize };
  },
};

function disposeVideo(el) {
  if (!el) return;
  // Nunca destruir o vídeo de fundo persistente das letras (ainda no DOM / marcado)
  if (el.dataset?.lyricsPersist === '1' || (el.isConnected && el.classList?.contains('lyrics-bg-video'))) {
    return;
  }
  try {
    el.pause();
    el.removeAttribute('src');
    el.load();
    el.remove?.();
  } catch { /* ignore */ }
}

export const VideoCache = {
  _map: new Map(),
  _maxSize: 12,

  _evictOne() {
    const key = this._map.keys().next().value;
    if (key === undefined) return;
    const el = this._map.get(key);
    if (el?.dataset?.lyricsPersist === '1' || (el?.isConnected && el?.classList?.contains('lyrics-bg-video'))) {
      // Mantém referência viva; só remove do mapa sem dispose
      this._map.delete(key);
      return;
    }
    disposeVideo(el);
    this._map.delete(key);
  },

  get(id) { return this._map.get(id); },

  set(id, el) {
    const max = document.documentElement?.dataset?.productionMode === '1'
      ? 4
      : (window.__SOMOSUM_PRODUCTION_CACHE_MAX ? (this._maxSize || 24) : 12);
    if (this._map.has(id)) {
      const prev = this._map.get(id);
      if (prev && prev !== el) disposeVideo(prev);
      this._map.delete(id);
    }
    while (this._map.size >= max) this._evictOne();
    this._map.set(id, el);
  },

  trim(keep = 2) {
    while (this._map.size > keep) this._evictOne();
  },

  clear() {
    for (const el of this._map.values()) disposeVideo(el);
    this._map.clear();
  },

  getMetrics() {
    return { size: this._map.size, max: this._maxSize };
  },
};
