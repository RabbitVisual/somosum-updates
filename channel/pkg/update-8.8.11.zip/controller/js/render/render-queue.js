const PRIORITY = { critical: 3, high: 2, normal: 1, low: 0 };



export class RenderQueue {

  constructor() {

    this.queue = [];

    this.running = false;

  }



  enqueue(task, { priority = 'normal', coalesceKey = null } = {}) {

    if (coalesceKey) {

      this.queue = this.queue.filter((item) => item.coalesceKey !== coalesceKey);

    }

    this.queue.push({ task, priority: PRIORITY[priority] ?? 1, coalesceKey });

    this.queue.sort((a, b) => b.priority - a.priority);

    this.pump();

  }



  async pump() {

    if (this.running) return;

    this.running = true;

    while (this.queue.length) {

      const { task } = this.queue.shift();

      try { await task(); } catch { /* */ }

    }

    this.running = false;

  }

}



export const renderQueue = new RenderQueue();

