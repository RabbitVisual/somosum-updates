import { renderQueue } from './render-queue.js';
import { FrameScheduler } from './frame-scheduler.js';

export class RenderPipeline {
  constructor({ renderFn }) {
    this.renderFn = renderFn;
  }

  async run(ctx, { priority = 'high' } = {}) {
    const coalesceKey = ctx?.slide ? 'slide-render' : null;
    return new Promise((resolve) => {
      renderQueue.enqueue(async () => {
        const result = await FrameScheduler.schedule(() => this.renderFn(ctx));
        resolve(result);
      }, { priority, coalesceKey });
    });
  }
}
