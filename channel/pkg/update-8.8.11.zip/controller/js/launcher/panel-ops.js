/**
 * Operação / Saúde — métricas, timeline, restart, diagnósticos embutidos.
 */
import { $, fmtSec, getPanelEvents, setText } from './panel-utils.js';

export function opsSectionHtml(active) {
  return `
    <section class="panel-section${active ? ' is-active' : ''}" data-section="operacao">
      <header class="panel-section-head">
        <p class="panel-section-kicker">Neste PC</p>
        <h2>Operação</h2>
        <p>Veja se o SOMOSUM está saudável neste computador e use ações rápidas se precisar.</p>
      </header>

      <div class="panel-section-stack">
        <article class="panel-ops-hero" id="panel-ops-hero" aria-live="polite">
          <div class="panel-ops-hero__body">
            <span class="panel-chip panel-ops-hero__chip" id="ops-status-chip">Verificando…</span>
            <h3 class="panel-ops-hero__title" id="ops-status-title">Status do programa</h3>
            <p class="panel-ops-hero__detail" id="ops-status-detail">Lendo o estado do SOMOSUM…</p>
          </div>
          <div class="panel-ops-hero__actions">
            <button type="button" class="panel-cta panel-cta--secondary" data-act="restart">Reiniciar o SOMOSUM</button>
            <button type="button" class="panel-cta panel-cta--ghost panel-cta--sm" data-act="diagnostics-toggle">Checagem rápida</button>
            <button type="button" class="panel-cta panel-cta--ghost panel-cta--sm" data-act="diagnostics">Ver detalhes</button>
            <button type="button" class="panel-cta panel-cta--ghost panel-cta--sm" data-act="folder-logs">Abrir registros</button>
            <button type="button" class="panel-cta panel-btn-danger panel-cta--sm" data-act="shutdown">Encerrar</button>
          </div>
        </article>

        <article class="panel-tile">
          <header class="panel-tile__head">
            <div>
              <h3>Números ao vivo</h3>
              <p>Tempo ligado, erros e sincronização com as telas do culto.</p>
            </div>
            <span class="panel-chip">Ao vivo</span>
          </header>
          <dl class="panel-stat-grid" id="panel-metrics">
            <div><dt>Porta</dt><dd id="m-port">—</dd></div>
            <div><dt>Tempo ligado</dt><dd id="m-uptime">—</dd></div>
            <div><dt title="Pedidos desde que o programa iniciou">Atividade</dt><dd id="m-req">0</dd></div>
            <div><dt>Erros</dt><dd id="m-err">0</dd></div>
            <div><dt>Fila de gravação</dt><dd id="m-queue">0</dd></div>
            <div><dt>Sincronização</dt><dd id="m-seq">0</dd></div>
            <div><dt>Modo</dt><dd id="m-mode">—</dd></div>
          </dl>
          <p class="panel-ops-tip muted" id="panel-ops-tip">Fila de gravação perto de 0 é normal. A sincronização sobe durante o culto.</p>
          <div id="panel-restart-progress" class="panel-restart-progress" hidden>
            <div class="panel-restart-progress__bar"></div>
            <span>Reiniciando servidor…</span>
          </div>
        </article>

        <article class="panel-tile">
          <header class="panel-tile__head">
            <div>
              <h3>Eventos recentes</h3>
              <p>Linha do tempo desta sessão do Painel.</p>
            </div>
            <span class="panel-chip panel-chip--soft">Sessão</span>
          </header>
          <ul class="su-list panel-ops-timeline" id="panel-event-timeline"><li class="su-list__item muted">Sem eventos nesta sessão</li></ul>
        </article>

        <article class="panel-tile panel-diag-embed" id="panel-diag-embed" hidden>
          <header class="panel-tile__head">
            <div>
              <h3>Diagnóstico</h3>
              <p>Ferramenta embutida — feche quando terminar.</p>
            </div>
            <button type="button" class="panel-cta panel-cta--ghost panel-cta--sm" data-act="diagnostics-toggle">Fechar</button>
          </header>
          <div class="panel-diag-frame-wrap">
            <div class="panel-diag-frame-loading" id="panel-diag-loading">Carregando diagnóstico…</div>
            <iframe id="panel-diag-frame" class="panel-diag-frame" title="Diagnóstico SOMOSUM" src="about:blank"></iframe>
          </div>
        </article>
      </div>
    </section>`;
}

export function updateOpsHero(h) {
  const chip = $('ops-status-chip');
  const title = $('ops-status-title');
  const detail = $('ops-status-detail');
  if (!chip || !title || !detail) return;

  const errors = h?.errors ?? 0;
  const queue = h?.saveQueue ?? 0;
  const ready = !!h?.readyForService;
  const online = !!(h?.ok || h?.port != null);

  if (!online) {
    chip.textContent = 'Offline';
    chip.className = 'panel-chip panel-ops-hero__chip is-fail';
    title.textContent = 'Servidor indisponível';
    detail.textContent = 'Abra SOMOSUM.exe na bandeja ou reinicie o aplicativo.';
    return;
  }

  if (!ready || errors >= 5 || queue > 3) {
    chip.textContent = errors >= 5 || queue > 3 ? 'Falha' : 'Atenção';
    chip.className = `panel-chip panel-ops-hero__chip ${errors >= 5 || queue > 3 ? 'is-fail' : 'is-warn'}`;
    title.textContent = errors >= 5 ? 'Erros HTTP elevados' : (queue > 3 ? 'Fila de gravação alta' : 'Pacote incompleto');
    detail.textContent = ready
      ? `${errors} erro(s) HTTP · fila save ${queue} · uptime ${fmtSec(h.uptimeSec || 0)}`
      : 'Konva, bíblias ou pasta data precisam de correção antes do culto.';
    return;
  }

  chip.textContent = 'OK';
  chip.className = 'panel-chip panel-ops-hero__chip is-ok';
  title.textContent = h.lanBindOk ? 'Pronto · rede da igreja ativa' : 'Pronto para culto';
  detail.textContent = `Porta ${h.port ?? '—'} · uptime ${fmtSec(h.uptimeSec || 0)} · fila ${queue} · sync ${h.syncSeq ?? 0}`;
}

function formatHttpTotal(h) {
  const req = h?.requests ?? 0;
  const up = Math.max(1, h?.uptimeSec ?? 1);
  const perMin = Math.round((req / up) * 60);
  if (up < 90) return `${req} (inclui boot)`;
  if (perMin <= 24) return String(req);
  return `${req} (~${perMin}/min)`;
}

export function updateOpsMetrics(h) {
  updateOpsHero(h);
  setText('m-port', h.port ?? '—');
  setText('m-uptime', fmtSec(h.uptimeSec || 0));
  setText('m-req', formatHttpTotal(h));
  setText('m-err', h.errors ?? 0);
  setText('m-queue', h.saveQueue ?? 0);
  setText('m-seq', h.syncSeq ?? 0);
  setText('m-mode', h.lanMode ? 'Rede da igreja' : 'Só neste PC');
}

export function renderEventTimeline() {
  const host = $('panel-event-timeline');
  if (!host) return;
  const events = getPanelEvents().slice().reverse().slice(0, 12);
  if (!events.length) {
    host.innerHTML = '<li class="su-list__item muted">Sem eventos nesta sessão</li>';
    return;
  }
  host.innerHTML = events.map((e) => {
    const t = new Date(e.ts).toLocaleTimeString('pt-BR');
    const tone = e.tone === 'error' ? ' is-error' : (e.tone === 'ok' ? ' is-ok' : '');
    return `<li class="su-list__item panel-ops-event${tone}"><time class="panel-ops-event__time">${t}</time><span>${e.message}</span></li>`;
  }).join('');
}

export function showRestartProgress(on) {
  const el = $('panel-restart-progress');
  if (!el) return;
  el.hidden = !on;
  el.setAttribute('aria-busy', on ? 'true' : 'false');
  if (on) el.removeAttribute('hidden');
  else el.setAttribute('hidden', '');
}

let embedDiagListener = null;
let embedDiagTimer = null;

function hideEmbedDiagLoading(loading) {
  if (!loading) return;
  loading.hidden = true;
  loading.setAttribute('hidden', '');
}

export function toggleEmbeddedDiagnostics() {
  const card = $('panel-diag-embed');
  const frame = $('panel-diag-frame');
  const loading = $('panel-diag-loading');
  if (!card || !frame) return;
  const open = card.hidden;
  card.hidden = !open;
  if (embedDiagListener) {
    window.removeEventListener('message', embedDiagListener);
    embedDiagListener = null;
  }
  if (embedDiagTimer) {
    clearTimeout(embedDiagTimer);
    embedDiagTimer = null;
  }
  if (open) {
    if (loading) {
      loading.textContent = 'Carregando diagnóstico…';
      loading.hidden = false;
      loading.removeAttribute('hidden');
    }
    embedDiagListener = (ev) => {
      if (ev.origin !== location.origin) return;
      const msg = ev.data;
      if (!msg || msg.type !== 'somosum-diagnostics-embed') return;
      if (msg.state === 'ready' || msg.state === 'error') {
        hideEmbedDiagLoading(loading);
      } else if (msg.state === 'analyzing' && loading) {
        loading.textContent = 'Analisando sistema…';
        loading.hidden = false;
        loading.removeAttribute('hidden');
      }
    };
    window.addEventListener('message', embedDiagListener);
    frame.onload = () => {
      if (loading) loading.textContent = 'Analisando sistema…';
    };
    frame.onerror = () => {
      if (loading) {
        loading.textContent = 'Não foi possível carregar o diagnóstico embutido.';
        loading.hidden = false;
        loading.removeAttribute('hidden');
      }
    };
    embedDiagTimer = setTimeout(() => {
      if (loading && !loading.hidden) {
        loading.textContent = 'Diagnóstico demorou — feche e abra de novo ou use Janela diagnóstico.';
      }
    }, 40000);
    frame.src = `/launcher/diagnostics.html?embed=1&v=${Date.now()}`;
  } else {
    frame.src = 'about:blank';
    if (loading) {
      loading.textContent = 'Carregando diagnóstico…';
      hideEmbedDiagLoading(loading);
    }
  }
}
