/**
 * Shell do Painel — rail agrupado, navegação, deep-link.
 */
import { showSkeletonOverlay } from '../ui/kit/skeleton-overlay.js';
import { faPanelIcon } from '../core/fa-icons.js';
import { $ } from './panel-utils.js';

export const SECTIONS = [
  { id: 'inicio', label: 'Início', hint: 'Checklist do culto', iconKey: 'inicio', group: 'comando' },
  { id: 'superficies', label: 'Telas', hint: 'Abrir Controle e projetor', iconKey: 'control', group: 'comando' },
  { id: 'loja', label: 'Loja', hint: 'Recursos extras do culto', iconKey: 'loja', group: 'comando' },
  { id: 'rede', label: 'Rede', hint: 'Wi‑Fi · celular · código', iconKey: 'rede', group: 'infra' },
  { id: 'operacao', label: 'Operação', hint: 'Status neste PC', iconKey: 'operacao', group: 'infra' },
  { id: 'monitores', label: 'Monitores', hint: 'Projetor 1 e 2', iconKey: 'monitores', group: 'infra' },
  { id: 'recursos', label: 'Desempenho', hint: 'CPU · memória', iconKey: 'recursos', group: 'infra' },
  { id: 'dados', label: 'Dados', hint: 'Cópia de segurança', iconKey: 'dados', group: 'infra' },
  { id: 'igreja', label: 'Igreja', hint: 'Nome · logo', iconKey: 'igreja', group: 'igreja' },
  { id: 'sobre', label: 'Sobre', hint: 'Versão · novidades', iconKey: 'sobre', group: 'igreja' },
];

export const GROUPS = [
  { id: 'comando', label: 'Culto' },
  { id: 'infra', label: 'Este computador' },
  { id: 'igreja', label: 'Igreja e ajuda' },
];

export const SECTION_KEY = 'somosum.panel.section';

/** @type {(id: string, prev: string) => void} */
let onSectionChange = () => {};

export function resolveInitialSection() {
  try {
    const params = new URLSearchParams(location.search || '');
    const q = params.get('section') || params.get('tab');
    if (q && SECTIONS.some((s) => s.id === q)) return q;
  } catch { /* ignore */ }
  try {
    const hash = (location.hash || '').replace(/^#/, '').split('?')[0];
    if (hash && SECTIONS.some((s) => s.id === hash)) return hash;
  } catch { /* ignore */ }
  try {
    const stored = localStorage.getItem(SECTION_KEY);
    if (SECTIONS.some((s) => s.id === stored)) return stored;
  } catch { /* ignore */ }
  return 'inicio';
}

export function storeSection(id) {
  try { localStorage.setItem(SECTION_KEY, id); } catch { /* ignore */ }
  try {
    if (history.replaceState) {
      const url = new URL(location.href);
      url.searchParams.set('section', id);
      history.replaceState(null, '', url.pathname + url.search + (url.hash || ''));
    }
  } catch { /* ignore */ }
}

export function setSectionChangeHandler(fn) {
  onSectionChange = typeof fn === 'function' ? fn : () => {};
}

export function buildRail(activeId) {
  const rail = $('panel-rail');
  if (!rail) return;

  const parts = [];
  for (const g of GROUPS) {
    const items = SECTIONS.filter((s) => s.group === g.id);
    if (!items.length) continue;
    parts.push(`<p class="panel-rail-group">${g.label}</p>`);
    for (const s of items) {
      parts.push(`
    <button type="button" class="panel-rail-item${s.id === activeId ? ' is-active' : ''}"
      data-section="${s.id}" aria-current="${s.id === activeId ? 'page' : 'false'}">
      <span class="panel-rail-ico" aria-hidden="true">${faPanelIcon(s.iconKey)}</span>
      <span class="panel-rail-copy">
        <span class="panel-rail-label">${s.label}</span>
        <span class="panel-rail-hint">${s.hint}</span>
      </span>
    </button>`);
    }
  }
  rail.innerHTML = parts.join('');

  rail.querySelectorAll('.panel-rail-item').forEach((btn) => {
    btn.addEventListener('click', () => {
      const id = btn.dataset.section;
      if (id) showSection(id);
    });
  });
}

export function showSection(id, { skipSkeleton = false } = {}) {
  if (!SECTIONS.some((s) => s.id === id)) return;
  const prev = document.querySelector('.panel-section.is-active')?.dataset?.section || '';
  if (id === prev && !skipSkeleton) {
    onSectionChange(id, prev);
    return;
  }

  const main = $('panel-main');
  const hide = (!skipSkeleton && main)
    ? showSkeletonOverlay(main, {
        variant: 'settings',
        message: `Abrindo ${SECTIONS.find((s) => s.id === id)?.label || 'seção'}…`,
        minMs: 220,
      })
    : () => {};

  storeSection(id);

  document.querySelectorAll('.panel-rail-item').forEach((btn) => {
    const on = btn.dataset.section === id;
    btn.classList.toggle('is-active', on);
    btn.setAttribute('aria-current', on ? 'page' : 'false');
  });

  document.querySelectorAll('.panel-mobile-chip').forEach((btn) => {
    btn.classList.toggle('is-active', btn.dataset.section === id);
  });

  document.querySelectorAll('.panel-section').forEach((sec) => {
    sec.classList.toggle('is-active', sec.dataset.section === id);
  });

  onSectionChange(id, prev);
  requestAnimationFrame(() => requestAnimationFrame(() => hide()));
}

export function buildMobileChips(activeId) {
  let host = document.getElementById('panel-mobile-nav');
  if (!host) {
    const shell = document.querySelector('.panel-shell');
    if (!shell) return;
    host = document.createElement('nav');
    host.id = 'panel-mobile-nav';
    host.className = 'panel-mobile-nav';
    host.setAttribute('aria-label', 'Seções (mobile)');
    shell.insertBefore(host, shell.firstChild);
  }
  host.innerHTML = SECTIONS.map((s) => `
    <button type="button" class="panel-mobile-chip${s.id === activeId ? ' is-active' : ''}"
      data-section="${s.id}">${s.label}</button>`).join('');
  host.querySelectorAll('.panel-mobile-chip').forEach((btn) => {
    btn.addEventListener('click', () => showSection(btn.dataset.section));
  });
}
