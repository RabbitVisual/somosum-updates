/**
 * Superfícies — mapa, presença, previews leves, presets de layout.
 */
import { $, escapeHtml, fetchJson, normalizePresence, shell } from './panel-utils.js';
import { faPanelIcon } from '../core/fa-icons.js';

const SURFACES = [
  { id: 'control', role: 'control', label: 'Controle', tag: 'Operador', act: 'open-control', icon: 'control', desc: 'Ordem do culto e ao vivo' },
  { id: 'screen', role: 'screen', label: 'Projeção', tag: 'Igreja', act: 'open-screen', icon: 'screen', desc: 'HDMI / projetor principal' },
  { id: 'screen2', role: 'screen2', label: 'Projeção 2', tag: 'Extra', act: 'open-screen2', icon: 'screen', desc: 'Segundo monitor / auxiliar' },
  { id: 'stage', role: 'stage', label: 'Púlpito', tag: 'Músicos', act: 'open-stage', icon: 'stage', desc: 'Cifras e próxima' },
  { id: 'remote', role: 'remote', label: 'Remote', tag: 'Celular', act: 'open-remote', icon: 'remote', desc: 'Controle na Wi‑Fi' },
];

export function surfacesSectionHtml(active) {
  return `
    <section class="panel-section${active ? ' is-active' : ''}" data-section="superficies">
      <header class="panel-section-head">
        <p class="panel-section-kicker">Janelas · presença · layout</p>
        <h2>Superfícies</h2>
        <p>Abra cada papel do culto, veja quem está online e monte o layout em um clique — iguais à bandeja do Windows.</p>
      </header>

      <div class="panel-section-stack">
        <article class="panel-tile panel-tile--tip">
          <header class="panel-tile__head">
            <div>
              <h3>Dica de layout</h3>
              <p>No culto: Controle + Projeção. No ensaio: só Controle. Presets abaixo = atalhos da bandeja.</p>
            </div>
            <span class="panel-chip panel-chip--soft">Guia</span>
          </header>
        </article>

        <article class="panel-tile">
          <header class="panel-tile__head">
            <div>
              <h3>Presets de layout</h3>
              <p>Culto completo = Controle + Projeção. Ensaio = Controle sem projetor.</p>
            </div>
            <span class="panel-chip">Bandeja</span>
          </header>
          <div class="panel-tile__actions panel-preset-row">
            <button type="button" class="panel-cta panel-cta--ghost" data-act="preset-control-only">Só Controle</button>
            <button type="button" class="panel-cta panel-cta--primary" data-act="preset-full-service">Culto completo</button>
            <button type="button" class="panel-cta panel-cta--secondary" data-act="preset-rehearsal">Ensaio</button>
          </div>
        </article>

        <div class="panel-surface-grid" id="panel-surface-grid">
          ${SURFACES.map((s) => `
            <article class="panel-surface-card" data-surface="${s.id}" data-role="${s.role}">
              <div class="panel-surface-card__head">
                <span class="panel-surface-card__ico" aria-hidden="true">${faPanelIcon(s.icon)}</span>
                <span class="panel-cta-tag">${s.tag}</span>
                <span class="panel-surface-badge" data-online>—</span>
              </div>
              <strong class="panel-surface-card__title">${s.label}</strong>
              <p class="panel-surface-card__desc">${s.desc}</p>
              <div class="panel-surface-preview" data-preview>
                <span class="panel-surface-preview__meta muted">Aguardando presença…</span>
              </div>
              <div class="panel-surface-card__actions">
                <button type="button" class="panel-cta panel-cta--primary panel-cta--sm" data-act="${s.act}">Abrir</button>
                <button type="button" class="panel-cta panel-cta--ghost panel-cta--sm" data-act="focus-${s.id}">Focar</button>
                ${s.id === 'screen' || s.id === 'screen2' ? `<button type="button" class="panel-cta panel-cta--ghost panel-cta--sm" data-act="test-${s.id}">Testar</button>` : ''}
              </div>
            </article>`).join('')}
        </div>
      </div>
    </section>`;
}

function matchRole(client, role) {
  const r = String(client.role || '').toLowerCase();
  if (role === 'screen2') return r === 'screen2' || r === 'projection2' || r.includes('screen2');
  if (role === 'screen') return r === 'screen' || r === 'projection' || r === 'projector';
  if (role === 'control') return r === 'control' || r === 'controller';
  if (role === 'stage') return r === 'stage' || r === 'pulpito';
  if (role === 'remote') return r === 'remote';
  return r === role;
}

export async function refreshSurfacesPresence() {
  const grid = $('panel-surface-grid');
  if (!grid) return;
  let clients = [];
  try {
    const raw = await fetchJson('/api/clients/presence?maxAge=90000', 5000);
    clients = normalizePresence(raw);
  } catch { /* empty */ }

  grid.querySelectorAll('.panel-surface-card').forEach((card) => {
    const role = card.dataset.role;
    const matches = clients.filter((c) => matchRole(c, role));
    const best = matches.sort((a, b) => (a.ageMs ?? 9e9) - (b.ageMs ?? 9e9))[0];
    const badge = card.querySelector('[data-online]');
    const preview = card.querySelector('[data-preview]');
    if (!best) {
      if (badge) {
        badge.textContent = 'Offline';
        badge.className = 'panel-surface-badge is-off';
      }
      if (preview) {
        preview.innerHTML = '<span class="panel-surface-preview__meta muted">Sem cliente recente</span>';
      }
      return;
    }
    const online = best.online || (best.ageMs != null && best.ageMs < 45000);
    if (badge) {
      badge.textContent = online ? 'Online' : 'Ausente';
      badge.className = `panel-surface-badge ${online ? 'is-on' : 'is-warn'}`;
    }
    const age = best.ageMs != null ? `${Math.round(best.ageMs / 1000)}s` : '—';
    const slide = best.slideType || best.title
      ? `<span class="panel-surface-preview__slide">${escapeHtml(best.title || best.slideType)}</span>`
      : '';
    if (preview) {
      preview.innerHTML = `
        <span class="panel-surface-preview__dot ${online ? 'is-on' : ''}" aria-hidden="true"></span>
        <span class="panel-surface-preview__meta">
          <strong>${escapeHtml(best.label || role)}</strong>
          · sync há ${age}
          ${slide}
        </span>`;
    }
  });
}

export function runSurfacePreset(kind) {
  const s = shell();
  if (!s?.isAvailable?.()) return false;
  if (kind === 'control-only' || kind === 'rehearsal') {
    s.openControl?.();
    return true;
  }
  if (kind === 'full-service') {
    s.openControl?.();
    s.openProjection?.(-1);
    return true;
  }
  return false;
}

export function focusSurface(id) {
  const s = shell();
  if (!s) return;
  if (id === 'control') s.openControl?.();
  else if (id === 'screen') s.openProjection?.(-1);
  else if (id === 'screen2') s.openProjection2?.(-1);
  else if (id === 'stage') s.openStage?.(-1);
  else if (id === 'remote') s.openRemote?.();
}
