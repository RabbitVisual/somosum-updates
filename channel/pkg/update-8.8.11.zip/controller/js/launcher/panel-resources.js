/**
 * Recursos — CPU/RAM e modos de projeção fluida.
 */
import {
  applyRenderMode,
  describeRenderPrefs,
  hydrateRenderPrefs,
} from '../core/performance/render-prefs.js';
import { getPrefs, savePrefs } from '../core/store.js';
import { $, setText } from './panel-utils.js';
import { toast } from '../ui/kit/toast.js';

export function resourcesSectionHtml(active) {
  return `
    <section class="panel-section${active ? ' is-active' : ''}" data-section="recursos">
      <header class="panel-section-head">
        <p class="panel-section-kicker">Desempenho</p>
        <h2>Recursos</h2>
        <p>O motor adapta o perfil sozinho (eco ↔ performance). Force só se o PC estiver sobrecarregado ou ocioso.</p>
      </header>

      <div class="panel-section-stack">
        <article class="panel-tile panel-tile--tip">
          <header class="panel-tile__head">
            <div>
              <h3>Perfis</h3>
              <p>Três modos — Automático é o padrão do culto.</p>
            </div>
            <span class="panel-chip panel-chip--soft">Guia</span>
          </header>
          <ol class="panel-steps">
            <li><strong>Eco</strong> — menos CPU/GPU; ideal em PCs modestos.</li>
            <li><strong>Performance</strong> — mais fluidez na projeção e no Designer.</li>
            <li><strong>Automático</strong> — o sistema escolhe conforme a carga.</li>
          </ol>
        </article>

        <div class="panel-home-grid">
          <article class="panel-tile">
            <header class="panel-tile__head">
              <div>
                <h3>Métricas</h3>
                <p>CPU, RAM e perfil atual do motor.</p>
              </div>
              <span class="panel-chip">Ao vivo</span>
            </header>
            <dl class="panel-stat-grid panel-resources">
              <div><dt>Perfil</dt><dd id="r-profile">—</dd></div>
              <div><dt>CPU</dt><dd id="r-cpu">—</dd></div>
              <div><dt>RAM</dt><dd id="r-ram">—</dd></div>
              <div><dt>Heap JS</dt><dd id="r-heap">—</dd></div>
              <div><dt>GPU</dt><dd id="r-gpu">—</dd></div>
              <div><dt>Cache</dt><dd id="r-cache">—</dd></div>
              <div><dt>Motivo</dt><dd id="r-reason">—</dd></div>
              <div><dt>Projeção</dt><dd id="r-render">—</dd></div>
            </dl>
            <div class="panel-tile__actions">
              <button type="button" class="panel-cta panel-cta--ghost panel-cta--sm" data-act="resources-refresh">Atualizar</button>
              <button type="button" class="panel-cta panel-cta--secondary panel-cta--sm" data-act="resources-eco">Forçar eco</button>
              <button type="button" class="panel-cta panel-cta--secondary panel-cta--sm" data-act="resources-perf">Forçar performance</button>
            </div>
          </article>

          <article class="panel-tile">
            <header class="panel-tile__head">
              <div>
                <h3>Projeção fluida</h3>
                <p>Escolha simples — o sistema configura Canvas e efeitos.</p>
              </div>
              <span class="panel-chip panel-chip--soft">Culto</span>
            </header>
            <div class="panel-render-modes su-choice-stack" id="panel-render-modes">
              <label class="su-choice"><input type="radio" name="panel-render-mode" value="auto" /> <span><strong>Automático</strong><small>Recomendado para o culto</small></span></label>
              <label class="su-choice"><input type="radio" name="panel-render-mode" value="fluid" /> <span><strong>Máxima fluidez</strong><small>Canvas nas letras quando a GPU aguentar</small></span></label>
              <label class="su-choice"><input type="radio" name="panel-render-mode" value="economy" /> <span><strong>Economia</strong><small>PC limitado / notebook 4 GB</small></span></label>
            </div>
            <p class="panel-card-lead" id="panel-render-status">—</p>
            <div class="panel-tile__actions">
              <button type="button" class="panel-cta panel-cta--primary" data-act="render-apply">Aplicar projeção fluida</button>
            </div>
          </article>
        </div>
      </div>
    </section>`;
}

export function renderResources(snap) {
  if (!snap) {
    setText('r-profile', 'Iniciando…');
    return;
  }
  const p = snap.profile || {};
  const sig = p.signals || {};
  const gpu = snap.gpu || {};
  setText('r-profile', `${p.name || '—'} (${p.adaptations ?? 0} adaptações)`);
  setText('r-cpu', sig.cpu != null ? `${Math.round(sig.cpu)}%` : '—');
  setText('r-ram', sig.ramWs != null ? `${Math.round(sig.ramWs)} MB` : '—');
  setText('r-heap', snap.heap?.usedMb != null ? `${snap.heap.usedMb} / ${snap.heap.limitMb || '?'} MB` : '—');
  setText('r-gpu', `${gpu.tier || '—'}${gpu.renderer ? ` · ${String(gpu.renderer).slice(0, 42)}` : ''}`);
  setText('r-cache', `${snap.caches?.image?.size ?? 0} / ${snap.caches?.imageMax ?? '—'} imgs`);
  setText('r-reason', p.reason || '—');
  try {
    const prefs = hydrateRenderPrefs(getPrefs());
    const d = describeRenderPrefs(prefs);
    setText('r-render', `${d.modeLabel}: ${d.statusLabel}`);
    const mode = prefs.render?.mode || 'auto';
    document.querySelectorAll('input[name="panel-render-mode"]').forEach((el) => {
      el.checked = el.value === mode;
    });
    const st = document.getElementById('panel-render-status');
    if (st) st.textContent = `${d.statusLabel} — ${d.reason}`;
  } catch {
    setText('r-render', '—');
  }
}

export async function refreshResources() {
  try {
    await window.Engine?.resources?.start?.();
    renderResources(await window.Engine?.resources?.snapshot?.());
  } catch {
    renderResources(null);
  }
}

export async function applyPanelRender() {
  const picked = document.querySelector('input[name="panel-render-mode"]:checked')?.value || 'auto';
  const next = applyRenderMode(getPrefs(), picked);
  savePrefs({ render: next.render });
  try {
    window.__SOMOSUM_RENDER = next.render;
  } catch { /* ignore */ }
  const d = describeRenderPrefs(next);
  const st = document.getElementById('panel-render-status');
  if (st) st.textContent = `${d.statusLabel} — ${d.reason}`;
  setText('r-render', `${d.modeLabel}: ${d.statusLabel}`);
  toast(`Projeção fluida: ${d.statusLabel}. Atualize a Projeção para ver o efeito.`, 'success');
}
