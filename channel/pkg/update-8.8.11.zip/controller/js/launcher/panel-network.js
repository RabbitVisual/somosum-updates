/**
 * Rede — delega ao Network Hub compartilhado.
 */
import { getPrefs, savePrefs } from '../core/store.js';
import { requestSoftRestart } from '../core/server-restart.js';
import { toast } from '../ui/kit/toast.js';
import {
  mountNetworkHub,
  refreshNetworkHub,
  startNetworkHubPoll,
  stopNetworkHubPoll,
} from '../network/network-hub.js';

let _panelHubHost = null;

function hubOptions() {
  return {
    surface: 'panel',
    toast: (m, t) => toast(m, t === 'ok' ? 'success' : t),
    getPrefs,
    savePrefs,
    requestSoftRestart,
  };
}

export function networkSectionHtml(active) {
  return `
    <section class="panel-section${active ? ' is-active' : ''}" data-section="rede">
      <header class="panel-section-head">
        <p class="panel-section-kicker">Wi‑Fi · celular · código</p>
        <h2>Rede</h2>
        <p>Ligue a rede da igreja, confirme se o Windows pedir permissão, escaneie o QR e digite o código de uso único no celular ou no Púlpito.</p>
      </header>
      <div class="panel-section-stack">
        <div id="panel-network-hub" class="network-hub-host"></div>
      </div>
    </section>`;
}

export function ensurePanelNetworkHub() {
  const host = document.getElementById('panel-network-hub');
  if (!host) return null;
  if (!host.dataset.mounted) {
    mountNetworkHub(host, hubOptions());
    host.dataset.mounted = '1';
    _panelHubHost = host;
  }
  return host;
}

export async function refreshNetworkBlock(lastHealth) {
  const host = ensurePanelNetworkHub();
  if (!host) return;
  await refreshNetworkHub(host, lastHealth || {});
}

export function startPanelNetworkPoll(getHealth) {
  const host = ensurePanelNetworkHub();
  if (host) startNetworkHubPoll(host, getHealth);
}

export function stopPanelNetworkPoll() {
  if (_panelHubHost) stopNetworkHubPoll(_panelHubHost);
}

/** @deprecated use hub — mantido para compatibilidade de imports */
export async function refreshPresence() {
  await refreshNetworkBlock({});
}

/** @deprecated use hub */
export async function refreshPairingList() {
  await refreshNetworkBlock({});
}

/** @deprecated use hub — Preparar rede via hub */
export async function repairFirewall() {
  const { networkRepairFirewall } = await import('../runtime/facades/network-runtime.js');
  toast('Reparando firewall…', 'info');
  const res = await networkRepairFirewall();
  if (res?.pending || res?.requiresElevation) {
    toast('Confirme o UAC do Windows (Sim)…', 'info');
  } else if (res?.ok) {
    toast(res.message || 'Firewall atualizado', 'success');
  } else {
    toast(res?.message || 'Não foi possível reparar', 'warn');
  }
  await refreshNetworkBlock({});
  return res;
}

/** @deprecated use hub */
export async function openNetworkWizard() {
  const host = ensurePanelNetworkHub();
  host?.querySelector('[data-hub-wizard]')?.click();
}
