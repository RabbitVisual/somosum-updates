/**
 * Identidade da igreja no Painel Gerencial — só afeta a projeção.
 */
import {
  getPrefs,
  savePrefs,
  saveAsset,
  deleteAsset,
  fileToDataUrl,
  getAllAssets,
  flushPrefsToDisk,
  assetDiskPath,
  initializeFromDisk,
  resolveChurchWelcomeBgUrl,
  resolveChurchLogoUrl,
  resolveChurchWelcomeBgKind,
  churchWelcomeBgIsCustom,
  churchLogoIsCustom,
  DEFAULT_CHURCH_WELCOME_BG,
  DEFAULT_CHURCH_LOGO,
} from '../core/store.js';
import { ProjectionBus, MessageTypes } from '../core/bus.js';
import {
  churchIdentityAssetsHtml,
  openLogoCropDialog,
  bindChurchIdentityPickers,
} from '../ui/church-identity-editor.js';
import { PRODUCT_LOGO, PRODUCT_FAVICON_ICO, ensureProductFavicons } from '../core/brand-assets.js';

let panelAssets = { logo: null, welcomeBg: null };
let panelBus = null;
let wired = false;

function esc(s) {
  return String(s ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/"/g, '&quot;');
}

export function panelChurchAssetUrls() {
  const church = getPrefs().church || {};
  const welcomeBg = resolveChurchWelcomeBgUrl({ church, assets: panelAssets });
  return {
    logo: resolveChurchLogoUrl({ church, assets: panelAssets }),
    welcomeBg,
    welcomeBgKind: resolveChurchWelcomeBgKind({ church, url: welcomeBg }),
  };
}

function syncChurchToOpenApps() {
  try {
    if (!panelBus) panelBus = new ProjectionBus('panel');
    panelBus.send(MessageTypes.ASSETS, panelChurchAssetUrls());
    panelBus.send(MessageTypes.SETTINGS, getPrefs());
  } catch (err) {
    console.warn('[panel-church] sync', err);
  }
}

export async function initPanelChurchAssets() {
  try {
    await initializeFromDisk();
  } catch (err) {
    console.warn('[panel-church] init disk', err);
  }
  try {
    const stored = await getAllAssets();
    panelAssets = {
      logo: stored.logo || null,
      welcomeBg: stored.welcomeBg || null,
    };
  } catch (err) {
    console.warn('[panel-church] assets', err);
    panelAssets = { logo: null, welcomeBg: null };
  }
}

export const FACTORY_PRODUCT_LOGO = PRODUCT_LOGO;

export function restoreFactoryProductChrome() {
  /** Mantém marca SOMOSUM no chrome do Painel — independente da logo da igreja na projeção. */
  ensureProductFavicons();
  document.querySelectorAll('.panel-brand-logo, .su-boot-splash__logo').forEach((img) => {
    if (!img) return;
    img.src = FACTORY_PRODUCT_LOGO;
    img.onerror = null;
    img.style.display = '';
  });
  document.querySelectorAll('link[rel="icon"], link[rel="shortcut icon"], link[rel="apple-touch-icon"]').forEach((link) => {
    const type = link.getAttribute('type') || '';
    const sizes = link.getAttribute('sizes') || '';
    if (type === 'image/x-icon' || sizes === 'any' || link.rel === 'shortcut icon') {
      link.href = PRODUCT_FAVICON_ICO;
    } else {
      link.href = FACTORY_PRODUCT_LOGO;
    }
  });
}

export function churchChecklistItem() {
  const church = getPrefs().church || {};
  const hasName = !!church.name?.trim();
  const customLogo = churchLogoIsCustom({ church, assets: panelAssets });
  const customBg = churchWelcomeBgIsCustom({ church, assets: panelAssets });
  const ok = hasName || customLogo || customBg;
  let detail = 'Configure na aba Igreja (só afeta o projetor)';
  if (hasName && (customLogo || customBg)) detail = `${church.name} · identidade na projeção ok`;
  else if (hasName) detail = church.name;
  else if (customLogo || customBg) detail = 'Logo ou fundo da projeção definidos';
  return {
    ok,
    label: 'Identidade da igreja',
    detail,
    solution: ok ? '' : 'Informe o nome da congregação e, se quiser, logo e fundo na aba Igreja.',
    action: ok ? '' : 'go-igreja',
    actionLabel: 'Abrir aba Igreja',
  };
}

export function churchSectionHtml(isActive = false) {
  const church = getPrefs().church || {};
  const urls = panelChurchAssetUrls();
  const logoCustom = churchLogoIsCustom({ church, assets: panelAssets });
  const bgCustom = churchWelcomeBgIsCustom({ church, assets: panelAssets });

  return `
    <section class="panel-section${isActive ? ' is-active' : ''}" data-section="igreja">
      <header class="panel-section-head">
        <p class="panel-section-kicker">Sua congregação</p>
        <h2>Igreja</h2>
        <p>Nome, logo e fundo que aparecem <strong>só no projetor</strong>. Este Painel e o Controle mantêm a marca SOMOSUM.</p>
      </header>

      <div class="panel-section-stack">
        <article class="panel-tile panel-tile--tip">
          <header class="panel-tile__head">
            <div>
              <h3>Só afeta a projeção</h3>
              <p>Campos vazios usam textos genéricos. Logo e fundo personalizados vão para as Boas-vindas e o pré-culto na tela da igreja.</p>
            </div>
            <span class="panel-chip panel-chip--soft">Projetor</span>
          </header>
        </article>

        <article class="panel-tile">
          <header class="panel-tile__head">
            <div>
              <h3>Dados da congregação</h3>
              <p>Nome e textos das Boas-vindas e do pré-culto.</p>
            </div>
            <span class="panel-chip">Identidade</span>
          </header>
          <label class="panel-field">
            <span>Nome da igreja</span>
            <input type="text" id="panel-church-name" value="${esc(church.name || '')}" placeholder="Ex.: Congregação Batista…" autocomplete="organization" />
          </label>
          <label class="panel-field">
            <span>Subtítulo / frase de boas-vindas</span>
            <input type="text" id="panel-church-sub" value="${esc(church.subtitle || '')}" placeholder="Ex.: Sejam bem-vindos" />
          </label>
          <div class="panel-row-2">
            <label class="panel-field">
              <span>Título nas Boas-vindas</span>
              <input type="text" id="panel-church-welcome-title" value="${esc(church.defaultWelcomeTitle || 'Boas-Vindas')}" />
            </label>
            <label class="panel-field">
              <span>Tema padrão do culto</span>
              <input type="text" id="panel-church-theme" value="${esc(church.defaultTheme || '')}" placeholder="Opcional" />
            </label>
          </div>
          <div class="panel-tile__actions">
            <button type="button" class="panel-cta panel-cta--primary" id="panel-church-save-text">Salvar dados</button>
          </div>
        </article>

        <article class="panel-tile panel-tile--flush">
          ${churchIdentityAssetsHtml({
            logoUrl: urls.logo,
            bgUrl: urls.welcomeBg,
            bgKind: urls.welcomeBgKind,
            logoCustom,
            bgCustom,
            idPrefix: 'panel-church',
          })}
        </article>
      </div>
    </section>`;
}

function readChurchTextFields() {
  return {
    name: document.getElementById('panel-church-name')?.value?.trim() || '',
    subtitle: document.getElementById('panel-church-sub')?.value?.trim() || '',
    defaultWelcomeTitle: document.getElementById('panel-church-welcome-title')?.value?.trim() || 'Boas-Vindas',
    defaultTheme: document.getElementById('panel-church-theme')?.value?.trim() || '',
  };
}

function persistChurchPatch(churchPatch) {
  savePrefs({
    ...getPrefs(),
    church: {
      ...(getPrefs().church || {}),
      ...churchPatch,
    },
  });
  void flushPrefsToDisk();
  syncChurchToOpenApps();
  restoreFactoryProductChrome();
}

export function refreshChurchSection() {
  const host = document.querySelector('.panel-section[data-section="igreja"]');
  if (!host) return;
  const active = host.classList.contains('is-active');
  const wrapper = document.createElement('div');
  wrapper.innerHTML = churchSectionHtml(active);
  const next = wrapper.firstElementChild;
  host.replaceWith(next);
  wired = false;
  wireChurchSection();
}

export function refreshChurchSectionActive(isActive) {
  const sec = document.querySelector('.panel-section[data-section="igreja"]');
  if (sec) sec.classList.toggle('is-active', !!isActive);
}

export function wireChurchSection() {
  if (wired) return;
  const root = document.querySelector('.panel-section[data-section="igreja"]');
  if (!root) return;
  wired = true;

  root.querySelector('#panel-church-save-text')?.addEventListener('click', () => {
    persistChurchPatch(readChurchTextFields());
    const toast = document.createElement('p');
    toast.className = 'panel-inline-toast';
    toast.textContent = 'Dados da igreja salvos.';
    root.querySelector('#panel-church-save-text')?.after(toast);
    setTimeout(() => toast.remove(), 2200);
  });

  bindChurchIdentityPickers(root, {
    idPrefix: 'panel-church',
    onLogoFile: async (file, setStatus) => {
      const cropped = await openLogoCropDialog(file);
      if (!cropped) {
        setStatus('logo', 'Recorte cancelado.', false);
        return;
      }
      setStatus('logo', 'Salvando logo…');
      await saveAsset('logo', cropped, 'image/png');
      panelAssets.logo = cropped;
      persistChurchPatch({ logoPath: assetDiskPath('logo', 'image/png') });
      setStatus('logo', 'Logo aplicada na projeção.', true);
      refreshChurchSection();
    },
    onBgFile: async (file, setStatus) => {
      const mime = file.type || 'image/png';
      const kind = mime.includes('video') ? 'video' : 'image';
      const dataUrl = await fileToDataUrl(file);
      await saveAsset('welcomeBg', dataUrl, mime);
      panelAssets.welcomeBg = dataUrl;
      persistChurchPatch({
        welcomeBgPath: assetDiskPath('welcomeBg', mime),
        welcomeBgKind: kind,
      });
      setStatus('bg', kind === 'video' ? 'Vídeo de fundo aplicado.' : 'Foto de fundo aplicada.', true);
      refreshChurchSection();
    },
    onLogoReset: async (setStatus) => {
      await deleteAsset('logo');
      panelAssets.logo = null;
      persistChurchPatch({ logoPath: DEFAULT_CHURCH_LOGO });
      setStatus('logo', 'Logo restaurada ao padrão do sistema.', true);
      refreshChurchSection();
    },
    onBgReset: async (setStatus) => {
      await deleteAsset('welcomeBg');
      panelAssets.welcomeBg = null;
      persistChurchPatch({
        welcomeBgPath: DEFAULT_CHURCH_WELCOME_BG,
        welcomeBgKind: 'image',
      });
      setStatus('bg', 'Fundo restaurado ao padrão do sistema.', true);
      refreshChurchSection();
    },
  });
}
