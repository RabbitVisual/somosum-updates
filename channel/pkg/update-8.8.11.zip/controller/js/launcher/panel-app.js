/**
 * Painel Gerencial — orquestrador (hub operacional do SOMOSUM).
 */
import { initAppMetaRuntime } from '../core/app-meta-boot.js';
import { bootstrapRenderEngine } from '../core/render-engine/index.js';
import { bootstrapSecurity } from '../core/security/index.js';
import { bootstrapPerformance } from '../core/performance/index.js';
import { ensureRenderPrefsPersisted } from '../core/performance/render-prefs.js';
import { bootstrapDesignSystem } from '../ui/index.js';
import { initStoragePlatform } from '../core/bootstrap-storage.js';
import { getAppMeta, metaSummaryLine } from '../core/app-meta.js';
import { getPrefs, savePrefs } from '../core/store.js';
import { applyUiPrefs } from '../ui/apply-ui-prefs.js';
import { bindChromeThemeToggle } from '../ui/chrome-theme.js';
import {
  initPanelChurchAssets,
  restoreFactoryProductChrome,
  churchSectionHtml,
  wireChurchSection,
  refreshChurchSection,
} from './panel-church.js';
import { requestSoftRestart } from '../core/server-restart.js';
import { TaskScheduler } from '../core/task-scheduler.js';
import { TaskIds } from '../core/task-registry.js';
import '../runtime/engine-boot.js';
import { markAppReady } from '../core/server-boot.js';
import { confirmDialog } from '../ui/kit/dialog.js';
import { toast } from '../ui/kit/toast.js';

import { $, fetchJson, pushPanelEvent, setText, shell } from './panel-utils.js';
import {
  buildMobileChips,
  buildRail,
  resolveInitialSection,
  setSectionChangeHandler,
  showSection,
  storeSection,
} from './panel-shell.js';
import {
  homeSectionHtml,
  updateChecklist,
  refreshHomeDashboard,
  updateHomePulsesFromHealth,
} from './panel-home.js';
import {
  surfacesSectionHtml,
  refreshSurfacesPresence,
  runSurfacePreset,
  focusSurface,
} from './panel-surfaces.js';
import {
  networkSectionHtml,
  refreshNetworkBlock,
  ensurePanelNetworkHub,
  startPanelNetworkPoll,
  stopPanelNetworkPoll,
} from './panel-network.js';
import {
  opsSectionHtml,
  updateOpsMetrics,
  renderEventTimeline,
  showRestartProgress,
  toggleEmbeddedDiagnostics,
} from './panel-ops.js';
import { monitorsSectionHtml, renderDisplays } from './panel-monitors.js';
import {
  resourcesSectionHtml,
  refreshResources,
  applyPanelRender,
} from './panel-resources.js';
import { dataSectionHtml, renderBackupLog } from './panel-data.js';
import { aboutSectionHtml, updateAboutMetrics, refreshIntegrity, refreshAboutWhatsNew, invalidateAboutWhatsNewCache } from './panel-about.js';
import { lojaSectionHtml, mountPanelLoja } from './panel-loja.js';

let activeSection = resolveInitialSection();
storeSection(activeSection);
let lastHealth = null;
let wired = false;
let restartProgressUntil = 0;
let lastDashboardAt = 0;
const DASHBOARD_REFRESH_MS = 45000;

setSectionChangeHandler((id) => {
  activeSection = id;
  if (id === 'inicio') {
    if (lastHealth) {
      updateHomePulsesFromHealth(lastHealth);
      lastDashboardAt = 0;
      void refreshHomeDashboard(lastHealth);
    }
  }
  if (id === 'igreja') refreshChurchSection();
  if (id === 'rede') {
    ensurePanelNetworkHub();
    startPanelNetworkPoll(() => lastHealth || {});
    void refreshNetworkBlock(lastHealth);
  } else {
    stopPanelNetworkPoll();
  }
  if (id === 'superficies') void refreshSurfacesPresence();
  if (id === 'monitores') renderDisplays();
  if (id === 'recursos') void refreshResources();
  if (id === 'operacao') renderEventTimeline();
  if (id === 'sobre') {
    void refreshIntegrity();
    void refreshAboutWhatsNew(lastHealth?.version || window.SOMOSUM_VERSION);
  }
  if (id === 'dados') renderBackupLog();
  if (id === 'loja') void mountPanelLoja({ force: true });
});

async function prepareLanFlow() {
  const btn = document.querySelector('[data-act="prepare-lan"]');
  const statusEl = $('panel-status-pill');
  if (btn) btn.disabled = true;
  try {
    const {
      networkRegisterPorts, waitForLanBind, beginRebindGrace,
    } = await import('../runtime/facades/network-runtime.js');
    if (statusEl) {
      statusEl.textContent = 'Preparando rede…';
      statusEl.className = 'panel-status-pill is-warn';
    }
    pushPanelEvent('Preparando rede da igreja');
    const reg = await networkRegisterPorts(false);
    if (reg?.pending || reg?.needsElevation || reg?.NeedsElevation) {
      if (statusEl) statusEl.textContent = 'Confirme a permissão do Windows (Sim)…';
      beginRebindGrace(25000);
      void (async () => {
        const ready = await waitForLanBind(50000);
        if (statusEl) {
          statusEl.textContent = ready?.lanBindOk ? 'Rede pronta — escaneie o QR' : 'Aguardando rede…';
          statusEl.className = ready?.lanBindOk ? 'panel-status-pill is-ok' : 'panel-status-pill is-warn';
        }
        pushPanelEvent(ready?.lanBindOk ? 'Rede pronta' : 'Rede pendente (permissão do Windows)', ready?.lanBindOk ? 'ok' : 'warn');
        await tick();
        if (activeSection === 'rede') void refreshNetworkBlock(lastHealth);
      })();
      return;
    }
    if (reg?.Success || reg?.success || reg?.ok) {
      if (reg?.rebindScheduled) {
        beginRebindGrace(18000);
        if (statusEl) statusEl.textContent = 'Abrindo Wi‑Fi (1–2s)…';
      } else if (statusEl) {
        statusEl.textContent = 'Rede pronta';
        statusEl.className = 'panel-status-pill is-ok';
      }
      pushPanelEvent('Rede preparada');
      void (async () => {
        await waitForLanBind(reg?.rebindScheduled ? 20000 : 5000);
        await tick();
        if (activeSection === 'rede') void refreshNetworkBlock(lastHealth);
      })();
      return;
    }
    if (statusEl) {
      statusEl.textContent = 'Falha — tente de novo';
      statusEl.className = 'panel-status-pill is-warn';
    }
    pushPanelEvent('Falha ao preparar rede', 'error');
    setTimeout(tick, 1500);
  } catch {
    if (statusEl) statusEl.textContent = 'Servidor ocupado — aguarde';
    pushPanelEvent('Preparar rede: servidor ocupado', 'warn');
    try {
      const { beginRebindGrace } = await import('../runtime/facades/network-runtime.js');
      beginRebindGrace(8000);
    } catch { /* ignore */ }
    setTimeout(tick, 2500);
  } finally {
    if (btn) btn.disabled = false;
  }
}

function buildShell() {
  const main = $('panel-main');
  if (!main) return;

  buildRail(activeSection);
  buildMobileChips(activeSection);

  main.innerHTML = [
    homeSectionHtml(activeSection === 'inicio'),
    surfacesSectionHtml(activeSection === 'superficies'),
    lojaSectionHtml(activeSection === 'loja'),
    networkSectionHtml(activeSection === 'rede'),
    opsSectionHtml(activeSection === 'operacao'),
    monitorsSectionHtml(activeSection === 'monitores'),
    resourcesSectionHtml(activeSection === 'recursos'),
    dataSectionHtml(activeSection === 'dados'),
    churchSectionHtml(activeSection === 'igreja'),
    aboutSectionHtml(activeSection === 'sobre'),
  ].join('');

  main.querySelectorAll('[data-go]').forEach((btn) => {
    btn.addEventListener('click', () => showSection(btn.dataset.go));
  });
  wireActions(main);
  wireChurchSection();
  document.querySelectorAll('.panel-topbar [data-act]').forEach((el) => {
    if (el.dataset.boundTop) return;
    el.dataset.boundTop = '1';
    el.addEventListener('click', () => {
      if (el.dataset.act === 'open-control') shell()?.openControl?.();
    });
  });
  wired = true;
  showSection(activeSection, { skipSkeleton: true });
}

function updateMetrics(h) {
  const ver = h.version || window.SOMOSUM_VERSION || '—';
  setText('home-ver', ver);
  setText('home-port', h.port != null ? String(h.port) : '—');
  setText('home-lan', h.lanBindOk ? `Rede ${h.lanIp || 'OK'}` : (h.lanMode ? 'Rede pendente' : 'Só neste PC'));

  const lan = document.querySelector('#panel-network-hub [data-hub-lan]');
  if (lan && document.activeElement !== lan) lan.checked = !!h.lanMode;

  updateOpsMetrics(h);
  updateAboutMetrics(h);
  updateChecklist(h, { onPrepareLan: () => { void prepareLanFlow(); } });
  // Motor/Rede: sempre no tick (não depender do throttle do dashboard).
  updateHomePulsesFromHealth(h);
  if (activeSection === 'inicio' && Date.now() - lastDashboardAt >= DASHBOARD_REFRESH_MS) {
    lastDashboardAt = Date.now();
    void refreshHomeDashboard(h);
  }
  renderEventTimeline();
}

function requireShell(actionLabel) {
  const s = shell();
  if (s?.isAvailable?.()) return s;
  toast(`Abra pelo SOMOSUM.exe — ${actionLabel}`, 'warn');
  return null;
}

function wireActions(root) {
  const on = (sel, fn) => {
    root.querySelectorAll(sel).forEach((el) => el.addEventListener('click', fn));
  };

  on('[data-act="start-service"]', () => {
    shell()?.openControl?.();
    toast('Controle aberto — conduza o culto por lá', 'success');
    pushPanelEvent('Iniciar culto');
  });
  on('[data-act="open-control"]', () => requireShell('Controle')?.openControl?.());
  on('[data-act="open-screen"]', () => requireShell('Projeção')?.openProjection?.(-1));
  on('[data-act="open-screen2"]', () => requireShell('Projeção 2')?.openProjection2?.(-1));
  on('[data-act="open-stage"]', () => requireShell('Púlpito')?.openStage?.(-1));
  on('[data-act="open-remote"]', () => requireShell('Remote')?.openRemote?.());
  on('[data-act="test-screen"]', () => requireShell('Projeção')?.openProjection?.(-1));
  on('[data-act="test-screen2"]', () => requireShell('Projeção 2')?.openProjection2?.(-1));
  on('[data-act="focus-control"]', () => focusSurface('control'));
  on('[data-act="focus-screen"]', () => focusSurface('screen'));
  on('[data-act="focus-screen2"]', () => focusSurface('screen2'));
  on('[data-act="focus-stage"]', () => focusSurface('stage'));
  on('[data-act="focus-remote"]', () => focusSurface('remote'));
  on('[data-act="preset-control-only"]', () => {
    runSurfacePreset('control-only');
    toast('Layout: só Controle', 'success');
  });
  on('[data-act="preset-full-service"]', () => {
    runSurfacePreset('full-service');
    toast('Layout: culto completo', 'success');
  });
  on('[data-act="preset-rehearsal"]', () => {
    runSurfacePreset('rehearsal');
    toast('Layout: ensaio', 'success');
  });
  on('[data-act="open-culto"]', (e) => {
    const id = e.currentTarget?.getAttribute?.('data-culto-id') || '';
    try {
      if (id) localStorage.setItem('somosum.control.openCulto', id);
    } catch { /* ignore */ }
    shell()?.openControl?.();
    toast('Abrindo culto no Controle…', 'info');
  });

  on('[data-act="restart"]', async () => {
    showRestartProgress(true);
    restartProgressUntil = Date.now() + 12000;
    pushPanelEvent('Reinício do servidor solicitado');
    try {
      if (shell()?.restartServer) {
        shell().restartServer();
      } else {
        await requestSoftRestart();
      }
      toast('Reiniciando servidor…', 'info');
    } catch {
      showRestartProgress(false);
      restartProgressUntil = 0;
      toast('Falha ao pedir reinício', 'warn');
    }
  });
  on('[data-act="diagnostics"]', () => {
    const s = shell();
    if (s?.isAvailable?.() && s.openDiagnosticsPanel) s.openDiagnosticsPanel();
    else window.open('/launcher/diagnostics.html', 'somosum-diagnostics', 'width=960,height=780');
  });
  on('[data-act="diagnostics-toggle"]', () => toggleEmbeddedDiagnostics());
  on('[data-act="shutdown"]', async () => {
    const ok = await confirmDialog({
      title: 'Encerrar SOMOSUM',
      message: 'Encerrar o SOMOSUM e liberar a porta? Telas e o servidor local serão fechados.',
      confirmLabel: 'Encerrar',
      cancelLabel: 'Cancelar',
      danger: true,
    });
    if (ok) {
      pushPanelEvent('Encerramento solicitado');
      requireShell('Encerrar')?.shutdown?.();
    }
  });
  on('[data-act="prepare-lan"]', () => {
    ensurePanelNetworkHub();
    document.querySelector('#panel-network-hub [data-hub-prepare]')?.click();
  });
  on('[data-act="folder-data"]', () => requireShell('Pasta data')?.openFolder?.('data'));
  on('[data-act="folder-logs"]', () => requireShell('Pasta logs')?.openFolder?.('logs'));
  on('[data-act="folder-fonts"]', () => requireShell('Pasta fonts')?.openFolder?.('fonts'));
  on('[data-act="desktop-shortcut"]', () => {
    if (shell()?.createDesktopShortcut) {
      shell().createDesktopShortcut();
      toast('Atalho criado', 'success');
    } else {
      toast('Abra pelo SOMOSUM.exe para criar o atalho', 'warn');
    }
  });
  on('[data-act="resources-refresh"]', () => { void refreshResources(); });
  on('[data-act="resources-eco"]', async () => {
    await window.Engine?.resources?.forceProfile?.('eco');
    void refreshResources();
  });
  on('[data-act="resources-perf"]', async () => {
    await window.Engine?.resources?.forceProfile?.('performance');
    void refreshResources();
  });
  on('[data-act="render-apply"]', () => { void applyPanelRender(); });
  document.querySelectorAll('input[name="panel-render-mode"]').forEach((el) => {
    el.addEventListener('change', () => { void applyPanelRender(); });
  });
  on('[data-act="backup-now"]', async () => {
    try {
      const { runBackupNow } = await import('./backup-scheduler.js');
      const ok = await runBackupNow('manual');
      toast(ok ? 'Backup incremental criado' : 'Não foi possível criar o backup', ok ? 'success' : 'warn');
      renderBackupLog();
      void refreshHomeDashboard(lastHealth || {});
      pushPanelEvent(ok ? 'Backup manual OK' : 'Backup manual falhou', ok ? 'ok' : 'error');
    } catch {
      toast('Não foi possível criar o backup', 'warn');
    }
  });
  on('[data-act="backup-schedule-save"]', async () => {
    const { saveBackupSchedulePrefs, startBackupScheduler } = await import('./backup-scheduler.js');
    const minutes = Number($('bak-interval')?.value) || 0;
    const pre = !!$('bak-preservice')?.checked;
    const retention = Number($('bak-retention')?.value);
    saveBackupSchedulePrefs({
      autoBackupMinutes: minutes,
      autoBackupPreService: pre,
      retentionCount: Number.isFinite(retention) ? retention : 14,
    });
    startBackupScheduler({ onRun: () => renderBackupLog() });
    toast('Agenda de backup salva', 'success');
    renderBackupLog();
  });
  on('[data-act="presence-refresh"]', () => {
    document.querySelector('#panel-network-hub [data-hub-refresh-devices]')?.click();
    void refreshSurfacesPresence();
  });
  on('[data-act="integrity-refresh"]', () => { void refreshIntegrity(); });
  on('[data-act="goto-section"]', (ev) => {
    const id = ev.currentTarget?.dataset?.section;
    if (id) showSection(id);
  });
  on('[data-act="check-updates"]', async () => {
    const status = document.getElementById('about-update-status');
    const badge = document.getElementById('about-update-badge');
    if (status) status.textContent = 'Procurando novidades…';
    if (badge) {
      badge.textContent = '…';
      badge.className = 'panel-chip panel-chip--soft';
    }
    try {
      const { checkAppUpdateManual } = await import('../ui/app-update-dialog.js');
      const r = await checkAppUpdateManual();
      if (status) status.textContent = r?.message || 'Pronto.';
      if (badge) {
        const okLatest = /versão mais nova|já está/i.test(String(r?.message || ''));
        badge.textContent = okLatest ? 'Em dia' : (r?.ok ? 'Info' : '—');
        badge.className = 'panel-chip';
      }
      if (r?.message) toast(r.message, r.ok ? 'success' : 'warn');
      invalidateAboutWhatsNewCache();
      void refreshAboutWhatsNew(lastHealth?.version || window.SOMOSUM_VERSION);
    } catch (err) {
      if (status) status.textContent = 'Não deu para procurar agora. Confira a internet e tente de novo.';
      if (badge) {
        badge.textContent = 'Erro';
        badge.className = 'panel-chip panel-chip--warn';
      }
      toast(String(err?.message || err), 'error');
    }
  });
  on('[data-act="open-control-sistema"]', () => {
    try { localStorage.setItem('somosum.settings.section', 'sistema'); } catch { /* ignore */ }
    try { sessionStorage.setItem('somosum.settings.section', 'sistema'); } catch { /* ignore */ }
    requireShell('Controle')?.openControl?.();
    toast('No Controle: Ajustes → Sistema → Procurar novidades', 'info');
  });
  on('[data-act="culto-usb-export"]', async () => {
    try {
      const { exportCultoPackage, downloadJson } = await import('../ops/culto-package.js');
      const pkg = await exportCultoPackage();
      const stamp = new Date().toISOString().slice(0, 10);
      downloadJson(`somosum-culto-${stamp}.json`, pkg);
      toast('Pacote do culto exportado', 'success');
    } catch (err) {
      toast(err?.message || 'Falha ao exportar pacote', 'warn');
    }
  });

  document.getElementById('culto-usb-import')?.addEventListener('change', async (e) => {
    const f = e.target.files?.[0];
    e.target.value = '';
    if (!f) return;
    try {
      const json = JSON.parse(await f.text());
      const { importCultoPackage } = await import('../ops/culto-package.js');
      const result = await importCultoPackage(json, {
        replaceProgram: true,
        confirmReplace: () => confirm(
          'Substituir a ordem do culto atual pelos itens deste pacote USB?'
        ),
      });
      if (result?.cancelled) return;
      toast(result?.ok
        ? `Pacote importado: ${result.itemCount} itens, ${result.songCount} músicas`
        : 'Importação concluída', 'success');
    } catch (err) {
      toast(err?.message || 'Falha ao importar pacote', 'warn');
    }
  });

  void (async () => {
    try {
      const {
        getBackupSchedulePrefs, startBackupScheduler,
      } = await import('./backup-scheduler.js');
      const prefs = getBackupSchedulePrefs();
      const iv = $('bak-interval');
      const ps = $('bak-preservice');
      const ret = $('bak-retention');
      if (iv) iv.value = String(prefs.autoBackupMinutes || 0);
      if (ps) ps.checked = !!prefs.autoBackupPreService;
      if (ret) ret.value = String(prefs.retentionCount ?? 14);
      startBackupScheduler({ onRun: () => renderBackupLog() });
      renderBackupLog();
    } catch { /* ignore */ }
    void refreshSurfacesPresence();
  })();
}

function renderStatus(h) {
  const pill = $('panel-status-pill');
  if (pill) {
    if (h.readyForService) {
      pill.textContent = h.lanBindOk ? 'Pronto · rede ativa' : 'Pronto para culto';
      pill.className = 'panel-status-pill is-ok';
    } else if (h.ok) {
      pill.textContent = 'SOMOSUM ligado';
      pill.className = 'panel-status-pill is-warn';
    } else {
      pill.textContent = 'Conferir instalação';
      pill.className = 'panel-status-pill is-warn';
    }
  }
  // Esconde “Reiniciando…” quando o health voltar (ou após timeout)
  if (restartProgressUntil) {
    const online = !!(h?.ok || h?.readyForService || h?.port);
    if (online && Date.now() > restartProgressUntil - 9000) {
      showRestartProgress(false);
      restartProgressUntil = 0;
    } else if (Date.now() > restartProgressUntil) {
      showRestartProgress(false);
      restartProgressUntil = 0;
    }
  } else {
    showRestartProgress(false);
  }
  if ($('panel-ver')) {
    const meta = getAppMeta();
    $('panel-ver').textContent = metaSummaryLine({ ...meta, version: h.version || meta.version });
  }
  if (!wired) buildShell();
  updateMetrics(h);
  if (activeSection === 'rede') void refreshNetworkBlock(h);
  if (activeSection === 'superficies') void refreshSurfacesPresence();
  if (activeSection === 'recursos') void refreshResources();
}

async function tick() {
  try {
    lastHealth = await fetchJson('/api/health', 8000);
    renderStatus(lastHealth);
  } catch {
    let grace = false;
    try {
      const { isRebindGraceActive } = await import('../runtime/facades/network-runtime.js');
      grace = !!isRebindGraceActive();
    } catch { /* ignore */ }
    const pill = $('panel-status-pill');
    if (pill) {
      if (grace) {
        pill.textContent = 'Reabrindo rede…';
        pill.className = 'panel-status-pill is-warn';
      } else {
        pill.textContent = 'SOMOSUM desligado';
        pill.className = 'panel-status-pill is-warn';
      }
    }
    if (activeSection === 'rede') void refreshNetworkBlock(lastHealth);
    if (grace) setTimeout(() => { void tick(); }, 1500);
  }
}

markAppReady();
void ensureRenderPrefsPersisted(getPrefs, savePrefs).catch(() => {});
TaskScheduler.start();
void initAppMetaRuntime();
bootstrapRenderEngine();
bootstrapSecurity();
bootstrapPerformance('panel');
bootstrapDesignSystem('panel');
void initStoragePlatform();
void initPanelChurchAssets().then(() => {
  restoreFactoryProductChrome();
  applyUiPrefs(getPrefs());
  bindChromeThemeToggle(document.getElementById('panel-app'));
  buildShell();
  tick();
  import('../ui/whats-new-modal.js').then(({ maybeShowWhatsNew }) => maybeShowWhatsNew()).catch(() => {});
  setTimeout(() => {
    import('../ui/app-update-dialog.js').then(({ maybeCheckAppUpdate }) => maybeCheckAppUpdate()).catch(() => {});
  }, 3500);
});
requestAnimationFrame(() => {
  requestAnimationFrame(() => {
    try {
      if (typeof window.__somosumFinishBootSplash === 'function') {
        void window.__somosumFinishBootSplash();
      } else {
        document.getElementById('boot-loading')?.remove();
      }
    } catch { /* ignore */ }
  });
});
TaskScheduler.register({
  id: TaskIds.PANEL_STATUS || 'panel-status',
  kind: 'interval',
  intervalMs: 12000,
  priority: 6,
  runWhenHidden: false,
  coalesce: true,
  fn: () => tick(),
});
