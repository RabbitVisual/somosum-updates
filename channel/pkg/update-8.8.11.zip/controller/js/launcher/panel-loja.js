/**
 * Loja de Plugins — seção do Painel Gerencial.
 */
import { toast } from '../ui/kit/toast.js';
import { shell } from './panel-utils.js';

export function lojaSectionHtml(active) {
  return `
    <section class="panel-section panel-section--loja${active ? ' is-active' : ''}" data-section="loja">
      <div id="panel-loja-mount" class="panel-loja-mount"></div>
    </section>`;
}

/** App mínimo para a Loja (sem ControlApp). */
export function createPanelLojaApp() {
  return {
    toast,
    openControl() {
      const s = shell();
      if (s?.isAvailable?.()) s.openControl?.();
      else toast('Abra pelo SOMOSUM.exe para o Controle', 'warn');
    },
  };
}

let _mounted = false;

export async function mountPanelLoja({ force = false } = {}) {
  const mount = document.getElementById('panel-loja-mount');
  if (!mount) return;
  if (_mounted && !force && mount.querySelector('#plugin-store-root')) return;

  mount.innerHTML = '<div class="plugin-store-loading" style="padding:2rem">Carregando Loja…</div>';
  try {
    const { mountPluginStore } = await import('../plugins/ui/plugin-store.js');
    const { invalidatePluginPackManifest } = await import('../plugins/plugin-pack-service.js');
    if (force) invalidatePluginPackManifest();
    mount.innerHTML = '';
    await mountPluginStore(mount, createPanelLojaApp());
    _mounted = true;
  } catch (err) {
    console.error('[SOMOSUM] panel loja', err);
    mount.innerHTML = `<div class="panel-tile" style="margin:1.5rem">
      <h3>Não foi possível abrir a Loja</h3>
      <p class="muted">${String(err?.message || err)}</p>
      <button type="button" class="panel-cta panel-cta--primary" id="panel-loja-retry">Tentar novamente</button>
    </div>`;
    mount.querySelector('#panel-loja-retry')?.addEventListener('click', () => {
      _mounted = false;
      void mountPanelLoja({ force: true });
    });
  }
}

export function resetPanelLojaMount() {
  _mounted = false;
}
