/**
 * Monitores — projetor 1/2 + Púlpito (Stage), teste, salvar.
 */
import { $, escapeHtml, shell } from './panel-utils.js';
import { toast } from '../ui/kit/toast.js';

export function monitorsSectionHtml(active) {
  return `
    <section class="panel-section${active ? ' is-active' : ''}" data-section="monitores">
      <header class="panel-section-head">
        <p class="panel-section-kicker">Telas físicas</p>
        <h2>Monitores</h2>
        <p>Projeção no HDMI da igreja · Púlpito no monitor do teto (só o pregador vê). Só no SOMOSUM.exe.</p>
      </header>

      <div class="panel-section-stack">
        <article class="panel-tile panel-tile--tip">
          <header class="panel-tile__head">
            <div>
              <h3>Dica de layout</h3>
              <p>Projeção = público. Púlpito = confidence monitor (relógio, ordem, avisos) — não misture com o projetor.</p>
            </div>
            <span class="panel-chip panel-chip--soft">Guia</span>
          </header>
        </article>

        <article class="panel-tile">
          <header class="panel-tile__head">
            <div>
              <h3>Projetor 1 e 2</h3>
              <p>Selecione o monitor, teste a imagem e salve.</p>
            </div>
            <span class="panel-chip">Projeção</span>
          </header>
          <div class="panel-displays" id="panel-displays">Carregando…</div>
        </article>

        <article class="panel-tile">
          <header class="panel-tile__head">
            <div>
              <h3>Púlpito (Stage)</h3>
              <p>Monitor do teto / retorno do pregador — perfil Pregador, tela limpa.</p>
            </div>
            <span class="panel-chip">Stage</span>
          </header>
          <div class="panel-displays" id="panel-stage-displays">Carregando…</div>
        </article>
      </div>
    </section>`;
}

function displayLabel(d, i) {
  const w = d?.width ?? d?.bounds?.w ?? d?.currentMode?.w ?? d?.WorkingArea?.w;
  const h = d?.height ?? d?.bounds?.h ?? d?.currentMode?.h ?? d?.WorkingArea?.h;
  const size = (Number.isFinite(Number(w)) && Number.isFinite(Number(h)))
    ? `${w}×${h}`
    : 'resolução desconhecida';
  const name = d?.friendlyName || d?.deviceName || `Monitor ${i + 1}`;
  const primary = d?.primary ? ' (primário)' : '';
  return `${name} — ${size}${primary}`;
}

function listDisplays(s) {
  return (s.getDisplays() || []).map((d, i) => ({
    ...d,
    width: d.width ?? d.bounds?.w ?? d.currentMode?.w,
    height: d.height ?? d.bounds?.h ?? d.currentMode?.h,
    index: d.index ?? i,
  }));
}

function openStagePulpit(s, idx) {
  const displayIndex = Number.isFinite(idx) ? idx : -1;
  try {
    if (typeof s.setStageDisplay === 'function' && displayIndex >= 0) {
      s.setStageDisplay(displayIndex);
    }
    s.openStage?.(displayIndex);
  } catch {
    toast('Não foi possível abrir o Púlpito neste monitor', 'warn');
    return;
  }
  // Marca layout Pregador para a próxima carga do Stage (URL + localStorage)
  try {
    localStorage.setItem('somosum-stage-pro-layout', 'preacher');
    localStorage.setItem('somosum-stage-open-layout', 'preacher');
  } catch { /* ignore */ }
  toast('Púlpito aberto · perfil Pregador', 'success');
}

export function renderDisplays() {
  const el = $('panel-displays');
  const stageEl = $('panel-stage-displays');
  const s = shell();
  if (!s?.isAvailable?.()) {
    const msg = `<p class="panel-hint panel-hint-warn">Abra pelo <strong>SOMOSUM.exe</strong> para listar monitores. No navegador esta seção fica limitada.</p>`;
    if (el) el.innerHTML = msg;
    if (stageEl) stageEl.innerHTML = msg;
    return;
  }
  try {
    const list = listDisplays(s);
    if (!list.length) {
      if (el) el.textContent = 'Nenhum monitor detectado.';
      if (stageEl) stageEl.textContent = 'Nenhum monitor detectado.';
      return;
    }
    const current = typeof s.getProjectorDisplayIndex === 'function' ? s.getProjectorDisplayIndex() : 0;
    const current2 = typeof s.getProjector2DisplayIndex === 'function' ? s.getProjector2DisplayIndex() : -1;
    const stageIdx = typeof s.getStageDisplayIndex === 'function' ? s.getStageDisplayIndex() : 0;
    const stageFs = typeof s.getStageFullscreen === 'function' ? !!s.getStageFullscreen() : true;
    const idx2Default = current2 >= 0
      ? current2
      : Math.min(list.length - 1, Math.max(0, current === 0 ? 1 : 0));

    if (el) {
      el.innerHTML = `
        <div class="panel-home-grid">
          <div>
            <label class="panel-display-select panel-field">Monitor do projetor
              <select id="panel-projector-select" class="panel-select su-select">
                ${list.map((d, i) => `<option value="${i}" ${i === current ? 'selected' : ''}>${escapeHtml(displayLabel(d, i))}</option>`).join('')}
              </select>
            </label>
            <label class="panel-display-select panel-field" style="margin-top:.75rem">Monitor da projeção 2
              <select id="panel-projector2-select" class="panel-select su-select">
                ${list.map((d, i) => `<option value="${i}" ${i === idx2Default ? 'selected' : ''}>${escapeHtml(displayLabel(d, i))}</option>`).join('')}
              </select>
            </label>
          </div>
          <div class="panel-tile__actions" style="margin-top:0;padding-top:0;align-content:start">
            <button type="button" class="panel-cta panel-cta--primary" id="panel-test-projection">Testar projeção</button>
            <button type="button" class="panel-cta panel-cta--secondary" id="panel-test-projection2">Testar projeção 2</button>
            <button type="button" class="panel-cta panel-cta--ghost panel-cta--sm" id="panel-set-projector">Salvar projetor</button>
            <button type="button" class="panel-cta panel-cta--ghost panel-cta--sm" id="panel-apply-native-res">Aplicar resolução recomendada</button>
          </div>
        </div>`;
    }

    if (stageEl) {
      stageEl.innerHTML = `
        <div class="panel-home-grid">
          <div>
            <label class="panel-display-select panel-field">Monitor do Púlpito
              <select id="panel-stage-select" class="panel-select su-select">
                ${list.map((d, i) => `<option value="${i}" ${i === stageIdx ? 'selected' : ''}>${escapeHtml(displayLabel(d, i))}</option>`).join('')}
              </select>
            </label>
            <label class="panel-check panel-field" style="margin-top:.75rem;display:flex;align-items:center;gap:.5rem">
              <input type="checkbox" id="panel-stage-fullscreen" ${stageFs ? 'checked' : ''} />
              Tela cheia no monitor (recomendado no teto)
            </label>
            <p class="panel-hint" style="margin-top:.5rem">Este monitor não é o projetor — só o pregador / equipe vê.</p>
          </div>
          <div class="panel-tile__actions" style="margin-top:0;padding-top:0;align-content:start">
            <button type="button" class="panel-cta panel-cta--primary" id="panel-open-stage">Abrir Púlpito (Pregador)</button>
            <button type="button" class="panel-cta panel-cta--ghost panel-cta--sm" id="panel-set-stage">Salvar Púlpito</button>
          </div>
        </div>`;
    }

    $('panel-projector-select')?.addEventListener('change', (e) => {
      const idx = parseInt(e.target.value, 10);
      if (Number.isFinite(idx)) s.setProjectorDisplay?.(idx);
    });
    $('panel-projector2-select')?.addEventListener('change', (e) => {
      const idx = parseInt(e.target.value, 10);
      if (Number.isFinite(idx)) s.setProjector2Display?.(idx);
    });
    $('panel-test-projection')?.addEventListener('click', () => {
      const idx = parseInt($('panel-projector-select')?.value, 10);
      s.openProjection?.(Number.isFinite(idx) ? idx : -1);
    });
    $('panel-test-projection2')?.addEventListener('click', () => {
      const idx = parseInt($('panel-projector2-select')?.value, 10);
      s.openProjection2?.(Number.isFinite(idx) ? idx : -1);
    });
    $('panel-set-projector')?.addEventListener('click', () => {
      const idx = parseInt($('panel-projector-select')?.value, 10);
      const idx2 = parseInt($('panel-projector2-select')?.value, 10);
      if (Number.isFinite(idx)) s.setProjectorDisplay?.(idx);
      if (Number.isFinite(idx2)) s.setProjector2Display?.(idx2);
      toast('Monitores de projeção salvos', 'success');
    });
    $('panel-apply-native-res')?.addEventListener('click', () => {
      const idx = parseInt($('panel-projector-select')?.value, 10);
      try {
        s.applyProjectorNativeResolution?.(Number.isFinite(idx) ? idx : -1);
        toast('Resolução recomendada aplicada no projetor', 'success');
        setTimeout(() => renderDisplays(), 1500);
      } catch {
        toast('Não foi possível aplicar — confira o monitor selecionado', 'warn');
      }
    });

    $('panel-stage-select')?.addEventListener('change', (e) => {
      const idx = parseInt(e.target.value, 10);
      if (Number.isFinite(idx)) s.setStageDisplay?.(idx);
    });
    $('panel-stage-fullscreen')?.addEventListener('change', (e) => {
      s.setStageFullscreen?.(!!e.target.checked);
    });
    $('panel-set-stage')?.addEventListener('click', () => {
      const idx = parseInt($('panel-stage-select')?.value, 10);
      const fs = !!$('panel-stage-fullscreen')?.checked;
      if (Number.isFinite(idx)) s.setStageDisplay?.(idx);
      s.setStageFullscreen?.(fs);
      toast('Monitor do Púlpito salvo', 'success');
    });
    $('panel-open-stage')?.addEventListener('click', () => {
      const idx = parseInt($('panel-stage-select')?.value, 10);
      const fs = !!$('panel-stage-fullscreen')?.checked;
      if (Number.isFinite(idx)) s.setStageDisplay?.(idx);
      s.setStageFullscreen?.(fs);
      openStagePulpit(s, Number.isFinite(idx) ? idx : -1);
    });
  } catch {
    if (el) el.textContent = 'Não foi possível ler monitores.';
    if (stageEl) stageEl.textContent = 'Não foi possível ler monitores.';
  }
}
