/**
 * Dados — backup, pastas, USB, retenção.
 */
import { $ } from './panel-utils.js';

export function dataSectionHtml(active) {
  return `
    <section class="panel-section${active ? ' is-active' : ''}" data-section="dados">
      <header class="panel-section-head">
        <p class="panel-section-kicker">Arquivos · backup · USB</p>
        <h2>Dados</h2>
        <p>Pastas do projeto, cópia de segurança e pacote do culto para pendrive — tudo neste PC.</p>
      </header>

      <div class="panel-section-stack">
        <article class="panel-tile panel-tile--tip">
          <header class="panel-tile__head">
            <div>
              <h3>Onde fica o quê</h3>
              <p>A cópia automática roda enquanto o Painel estiver aberto.</p>
            </div>
            <span class="panel-chip panel-chip--soft">Guia</span>
          </header>
          <ol class="panel-steps">
            <li><strong>Dados do culto</strong> — cultos, músicas, config e preferências.</li>
            <li><strong>Registros</strong> — histórico para suporte, se precisar.</li>
            <li><strong>Fontes</strong> — tipografias usadas na projeção.</li>
          </ol>
        </article>

        <div class="panel-home-grid">
          <article class="panel-tile">
            <header class="panel-tile__head">
              <div>
                <h3>Pastas e atalho</h3>
                <p>Abra pastas ou baixe uma cópia completa.</p>
              </div>
              <span class="panel-chip">Disco</span>
            </header>
            <div class="panel-tile__actions">
              <button type="button" class="panel-cta panel-cta--ghost panel-cta--sm" data-act="folder-data">Pasta de dados</button>
              <button type="button" class="panel-cta panel-cta--ghost panel-cta--sm" data-act="folder-logs">Pasta de registros</button>
              <button type="button" class="panel-cta panel-cta--ghost panel-cta--sm" data-act="folder-fonts">Pasta de fontes</button>
              <a class="panel-cta panel-cta--ghost panel-cta--sm" href="/api/backup.zip" download>Baixar cópia completa</a>
              <button type="button" class="panel-cta panel-cta--primary panel-cta--sm" data-act="desktop-shortcut">Atalho na Área de Trabalho</button>
            </div>
          </article>

          <article class="panel-tile">
            <header class="panel-tile__head">
              <div>
                <h3>Backup automático</h3>
                <p>Incremental enquanto o Painel estiver aberto. Intervalo 0 = off.</p>
              </div>
              <span class="panel-chip">Agenda</span>
            </header>
            <label class="panel-field">
              <span>Intervalo (minutos, 0 = off)</span>
              <input type="number" id="bak-interval" min="0" max="180" step="5" value="0" />
            </label>
            <label class="panel-switch-row">
              <input type="checkbox" id="bak-preservice" class="su-switch" />
              <span>Backup pré-culto ao abrir o Painel</span>
            </label>
            <label class="panel-field">
              <span>Retenção (máx. backups locais, 0 = sem limite)</span>
              <input type="number" id="bak-retention" min="0" max="90" step="1" value="14" />
            </label>
            <div class="panel-tile__actions">
              <button type="button" class="panel-cta panel-cta--secondary panel-cta--sm" data-act="backup-schedule-save">Salvar agenda</button>
              <button type="button" class="panel-cta panel-cta--primary panel-cta--sm" data-act="backup-now">Backup agora</button>
            </div>
            <ul class="su-list" id="bak-log"><li class="su-list__item muted">—</li></ul>
          </article>

          <article class="panel-tile panel-tile--wide">
            <header class="panel-tile__head">
              <div>
                <h3>Pacote culto USB</h3>
                <p>Exporta/importa culto completo em JSON — ideal sem rede entre PCs.</p>
              </div>
              <span class="panel-chip panel-chip--soft">Pendrive</span>
            </header>
            <div class="panel-tile__actions">
              <button type="button" class="panel-cta panel-cta--secondary" data-act="culto-usb-export">Exportar culto USB</button>
              <label class="panel-cta panel-cta--ghost">Importar culto USB<input type="file" id="culto-usb-import" accept=".json,application/json" hidden /></label>
            </div>
            <p class="panel-card-lead">Restore JSON completo do sistema permanece no Controle → Ajustes → Dados.</p>
          </article>
        </div>
      </div>
    </section>`;
}

export function renderBackupLog() {
  const host = $('bak-log');
  if (!host) return;
  import('./backup-scheduler.js').then(({ getBackupLog, getLastBackupRun, getBackupSchedulePrefs }) => {
    const log = getBackupLog();
    const last = getLastBackupRun();
    const prefs = getBackupSchedulePrefs();
    const ret = prefs.retentionCount != null ? ` · retenção ${prefs.retentionCount || '∞'}` : '';
    if (!log.length) {
      host.innerHTML = `<li class="su-list__item muted">Sem registros${last ? ` · último ${new Date(last).toLocaleString('pt-BR')}` : ''}${ret}</li>`;
      return;
    }
    host.innerHTML = log.slice(-8).reverse().map((e) =>
      `<li class="su-list__item">${e.ok === false ? '✗' : '✓'} ${e.message || e.reason} <span class="muted">${new Date(e.ts).toLocaleTimeString('pt-BR')}</span></li>`
    ).join('');
  }).catch(() => {});
}
