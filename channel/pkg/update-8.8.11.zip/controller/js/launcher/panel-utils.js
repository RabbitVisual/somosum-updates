/** Utilitários compartilhados do Painel Gerencial. */

export function shell() {
  return window.Engine?.shell;
}

export const $ = (id) => document.getElementById(id);

export function escapeHtml(s) {
  return String(s || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

export function setText(id, v) {
  const el = $(id);
  if (el) el.textContent = v;
}

export function fmtSec(s) {
  const m = Math.floor(s / 60);
  const sec = s % 60;
  return m > 0 ? `${m}m ${sec}s` : `${sec}s`;
}

export async function fetchJson(url, ms = 8000) {
  const ctrl = typeof AbortController !== 'undefined' ? new AbortController() : null;
  const timer = ctrl ? setTimeout(() => ctrl.abort(), ms) : null;
  try {
    const r = await fetch(url, { cache: 'no-store', signal: ctrl?.signal });
    if (timer) clearTimeout(timer);
    if (!r.ok) throw new Error(String(r.status));
    return r.json();
  } catch (err) {
    if (timer) clearTimeout(timer);
    throw err;
  }
}

export function normalizePresence(raw) {
  const clients = Array.isArray(raw?.clients) ? raw.clients : (Array.isArray(raw) ? raw : []);
  return clients.map((c) => {
    const clientId = c.clientId || c.id || '';
    const lastSeen = Number(c.lastSeen ?? c.ts ?? 0);
    return {
      clientId,
      id: clientId,
      role: c.role || c.meta?.role || 'client',
      label: c.label || c.meta?.label || c.role || clientId,
      lastSeen,
      ts: lastSeen,
      ageMs: lastSeen ? Math.max(0, Date.now() - lastSeen) : null,
      online: lastSeen ? (Date.now() - lastSeen) < 45000 : false,
      meta: c.meta || null,
      slideType: c.meta?.slideType || c.slideType || null,
      title: c.meta?.title || c.title || null,
      deviceFingerprint: c.deviceFingerprint || c.meta?.deviceFingerprint || '',
      remoteIp: c.remoteIp || c.meta?.remoteIp || '',
    };
  });
}

const ROLE_LABELS = {
  remote: 'Remote',
  stage: 'Púlpito',
  screen: 'Projetor',
  control: 'Controle',
};

/** Unifica presença HTTP, WebSocket e pareamento para o Painel Gerencial. */
export function normalizeDeviceRegistry(raw) {
  if (!raw || typeof raw !== 'object') return [];
  const now = Date.now();
  const byKey = new Map();

  const upsert = (entry) => {
    const fp = entry.deviceFingerprint || '';
    const id = entry.clientId || entry.id || '';
    const key = fp || id || `${entry.role}:${entry.label}`;
    const prev = byKey.get(key) || {};
    byKey.set(key, {
      ...prev,
      ...entry,
      label: entry.label || prev.label || ROLE_LABELS[entry.role] || entry.role,
      role: entry.role || prev.role || 'client',
      online: !!(entry.online || prev.online),
      wsConnected: !!(entry.wsConnected || prev.wsConnected),
      authorized: entry.authorized ?? prev.authorized ?? null,
      remoteIp: entry.remoteIp || prev.remoteIp || '',
      lastSeen: Math.max(Number(entry.lastSeen || 0), Number(prev.lastSeen || 0)),
    });
  };

  for (const c of raw.presence || []) {
    const lastSeen = Number(c.lastSeen ?? c.ts ?? 0);
    upsert({
      clientId: c.clientId || c.id,
      role: c.role,
      label: c.label,
      deviceFingerprint: c.deviceFingerprint,
      deviceId: c.deviceId,
      remoteIp: c.remoteIp,
      lastSeen,
      online: lastSeen && (now - lastSeen) < 45000,
      meta: c.meta,
    });
  }

  for (const c of raw.websocket || []) {
    const connectedAt = Date.parse(c.connectedAt || '') || now;
    upsert({
      clientId: c.id,
      role: c.role,
      label: c.label,
      deviceFingerprint: c.deviceFingerprint,
      deviceId: c.deviceId,
      remoteIp: c.remoteIp,
      lastSeen: now,
      online: true,
      wsConnected: true,
    });
  }

  for (const d of raw.paired || []) {
    const fp = d.fingerprint || d.Fingerprint || '';
    const id = d.id || d.Id || '';
    if (!fp && !id) continue;
    const lastSeen = Date.parse(d.lastSeen || d.LastSeen || '') || 0;
    upsert({
      deviceId: id,
      deviceFingerprint: fp,
      label: d.name || d.Name || 'Dispositivo',
      role: 'remote',
      authorized: !!(d.authorized || d.Authorized),
      lastSeen,
      online: lastSeen && (now - lastSeen) < 120000,
    });
  }

  return [...byKey.values()]
    .map((c) => ({
      ...c,
      ageMs: c.lastSeen ? Math.max(0, now - c.lastSeen) : null,
      online: c.online || (c.lastSeen && (now - c.lastSeen) < 45000),
    }))
    .sort((a, b) => {
      if (a.online !== b.online) return a.online ? -1 : 1;
      return (b.lastSeen || 0) - (a.lastSeen || 0);
    });
}

const EVENT_KEY = 'somosum.panel.events';
const MAX_EVENTS = 24;

export function pushPanelEvent(message, kind = 'info') {
  try {
    const list = JSON.parse(sessionStorage.getItem(EVENT_KEY) || '[]');
    list.push({ ts: Date.now(), message: String(message || ''), kind });
    while (list.length > MAX_EVENTS) list.shift();
    sessionStorage.setItem(EVENT_KEY, JSON.stringify(list));
  } catch { /* ignore */ }
}

export function getPanelEvents() {
  try {
    return JSON.parse(sessionStorage.getItem(EVENT_KEY) || '[]');
  } catch {
    return [];
  }
}

/** Abre o Painel numa seção (deep-link a partir do Controle). */
export function openPanelSection(sectionId) {
  try {
    if (sectionId) localStorage.setItem('somosum.panel.section', sectionId);
  } catch { /* ignore */ }
  const s = shell();
  if (s?.openManagementPanel) {
    s.openManagementPanel();
    return true;
  }
  const url = `/launcher/panel.html?section=${encodeURIComponent(sectionId || 'inicio')}`;
  window.open(url, 'somosum-panel');
  return false;
}
