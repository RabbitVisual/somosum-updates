import { markAppReady } from '../core/server-boot.js';
import { initAppMetaRuntime } from '../core/app-meta-boot.js';
import { bootstrapRenderEngine } from '../core/render-engine/index.js';
import { bootstrapSecurity } from '../core/security/index.js';
import { bootstrapPerformance, buildSnapshot, PerformanceProfiler } from '../core/performance/index.js';
import { bootstrapDesignSystem, buildSnapshot as buildDsSnapshot } from '../ui/index.js';
import { initStoragePlatform } from '../core/bootstrap-storage.js';
import { runSecurityAudit, auditReportHtml } from '../core/security/security-audit.js';
import { RenderProfiler } from '../core/render-engine/render-profiler.js';
import { getAppMeta, metaSummaryLine } from '../core/app-meta.js';
import { TaskScheduler } from '../core/task-scheduler.js';
import { TaskIds } from '../core/task-registry.js';
import {
  runServerDiagnostics,
  renderDiagnosticsHtml,
  exportDiagnosticsReport,
  handleDiagnosticAction,
} from '../core/system-diagnostics.js';
import { requestSoftRestart } from '../core/server-restart.js';
import { engineReady } from '../runtime/engine-boot.js';
import { mountEngineDiagnosticsPanel } from '../runtime/engine-diagnostics-panel.js';

function shell() {
  return window.Engine?.shell;
}
let lastResult = null;
let running = false;

const isEmbed = typeof location !== 'undefined'
  && new URLSearchParams(location.search).get('embed') === '1';

function notifyEmbed(state) {
  if (!isEmbed) return;
  try {
    window.parent?.postMessage({ type: 'somosum-diagnostics-embed', state }, location.origin);
  } catch { /* ignore */ }
}

function $(sel) { return document.querySelector(sel); }

function shellAvailable() {
  try {
    return !!window.Engine?.shell?.isAvailable?.();
  } catch {
    return false;
  }
}

function requireShell(actionLabel) {
  if (shellAvailable()) return true;
  flashStatus(`Abra pelo SOMOSUM.exe — ${actionLabel} indisponível no navegador`);
  return false;
}

function wireToolbar() {
  $('#diag-run')?.addEventListener('click', () => runAnalysis());
  $('#diag-validate-culto')?.addEventListener('click', () => runCultoValidation());
  $('#diag-export')?.addEventListener('click', async () => {
    if (!lastResult) {
      flashStatus('Execute a análise antes de exportar');
      return;
    }
    const text = await exportDiagnosticsReport(lastResult);
    try {
      await navigator.clipboard.writeText(text);
      flashStatus('Relatório copiado para a área de transferência');
    } catch {
      const blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = `somosum-diagnostico-${Date.now()}.txt`;
      a.click();
      URL.revokeObjectURL(a.href);
      flashStatus('Relatório baixado');
    }
  });
  $('#diag-restart')?.addEventListener('click', async () => {
    if (!confirm('Reiniciar o servidor local? A página recarrega em alguns segundos.')) return;
    await requestSoftRestart();
    flashStatus('Reiniciando servidor…');
    setTimeout(() => location.reload(), 3500);
  });
  $('#diag-open-panel')?.addEventListener('click', () => {
    if (!requireShell('Painel gestão')) return;
    shell()?.openManagementPanel?.();
  });
  $('#diag-open-control')?.addEventListener('click', () => {
    if (!requireShell('Controle')) return;
    shell()?.openControl?.();
  });
  $('#diag-open-projection')?.addEventListener('click', () => {
    if (!requireShell('Projeção')) return;
    shell()?.openProjection?.(-1);
  });
}

function wireActions(root) {
  root.querySelectorAll('[data-diag-action]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const action = btn.getAttribute('data-diag-action');
      if (action === 'restartServer') {
        requestSoftRestart().then(() => flashStatus('Reiniciando…'));
        return;
      }
      const ok = handleDiagnosticAction(action);
      if (ok) {
        flashStatus('Ação enviada — verifique o resultado em alguns segundos');
      } else {
        flashStatus('Abra pelo SOMOSUM.exe para executar esta ação');
      }
      if (action === 'openProjection') setTimeout(runAnalysis, 8000);
    });
  });
}

function flashStatus(msg) {
  const el = $('#diag-status');
  if (el) {
    el.textContent = msg;
    setTimeout(() => { if (el.textContent === msg) el.textContent = ''; }, 3200);
  }
}

function appendRenderProfilerBlock(main) {
  if (!main || main.querySelector('.render-profiler-diag')) return;
  RenderProfiler.enable(true);
  const block = document.createElement('section');
  block.className = 'diag-group render-profiler-diag';
  block.innerHTML = `<h2>Motor de renderização</h2>${RenderProfiler.toReportHtml()}`;
  main.appendChild(block);
}

async function appendPerformanceBlock(main) {
  if (!main || main.querySelector('.performance-diag')) return;
  let serverSnap = null;
  try {
    const res = await fetch('/api/performance', { cache: 'no-store' });
    if (res.ok) serverSnap = await res.json();
  } catch { /* offline */ }
  const jsSnap = buildSnapshot();
  const block = document.createElement('section');
  block.className = 'diag-group performance-diag';
  block.innerHTML = `
    <h2>Desempenho</h2>
    ${PerformanceProfiler.toReportHtml(jsSnap.profiler)}
    <p class="muted" style="font-size:.82rem;margin-top:.75rem">
      Modo leve: ${jsSnap.lowSpec ? 'ligado' : 'desligado'} · Proteção ao vivo: ${jsSnap.isLive ? 'ativa' : 'inativa'}
      · Quadros atrasados: ${jsSnap.frame?.overruns ?? 0}
      · Assets carregados: ${jsSnap.assets?.loads ?? 0} (cache ${jsSnap.assets?.hits ?? 0})
    </p>
    ${serverSnap ? `<pre class="diag-perf-server" style="white-space:pre-wrap;background:#111;padding:.75rem;border-radius:8px;font-size:.78rem;color:#9dcea0;margin-top:.5rem">${JSON.stringify(serverSnap, null, 2).replace(/</g, '&lt;')}</pre>` : ''}`;
  main.appendChild(block);
}

async function appendDesignSystemBlock(main) {
  if (!main || main.querySelector('.design-system-diag')) return;
  const snap = buildDsSnapshot();
  const block = document.createElement('section');
  block.className = 'diag-group design-system-diag';
  block.innerHTML = `
    <h2>Design System</h2>
    <p class="muted" style="font-size:.82rem;line-height:1.5">
      Tema: <strong>${snap.theme || '—'}</strong> · Contraste: ${snap.a11yContrast ? 'alto' : 'normal'}
      · Reduzir movimento: ${snap.reducedMotion ? 'sim' : 'não'} · Modo leve: ${snap.lowSpec ? 'sim' : 'não'}
    </p>`;
  main.appendChild(block);
}

async function appendWorshipEngineBlock(main) {
  if (!main || main.querySelector('.worship-engine-diag')) return;
  try {
    const { fetchWorshipMetrics, buildWorshipDiagnosticsHtml } = await import('../worship/engine/worship-diagnostics.js');
    const metrics = await fetchWorshipMetrics();
    const block = document.createElement('section');
    block.className = 'diag-group worship-engine-diag';
    block.innerHTML = buildWorshipDiagnosticsHtml(metrics);
    main.appendChild(block);
  } catch (err) {
    console.warn('[SOMOSUM] worship diag', err);
  }
}

async function appendStoragePlatformBlock(main) {
  if (!main || main.querySelector('.storage-platform-diag')) return;
  try {
    const { StorageManager } = await import('../core/storage/index.js');
    await StorageManager.init();
    const snap = await StorageManager.snapshot();
    const block = document.createElement('section');
    block.className = 'diag-group storage-platform-diag';
    const server = snap.server || {};
    block.innerHTML = `
      <h2>Plataforma de armazenamento</h2>
      <ul class="diag-list">
        <li>Disco: <strong>${server.dataDirMb ?? '—'} MB</strong></li>
        <li>Acerto de cache: <strong>${Math.round((snap.cache?.hitRate || 0) * 100)}%</strong></li>
        <li>Fila de gravação: <strong>${snap.saveQueue ?? 0}</strong></li>
        <li>Consulta p95: <strong>${snap.timings?.queryP95Ms ?? 0} ms</strong></li>
        <li>Gravação p95: <strong>${snap.timings?.writeP95Ms ?? 0} ms</strong></li>
      </ul>
      <pre class="diag-storage-counts" style="white-space:pre-wrap;background:#111;padding:.75rem;border-radius:8px;color:#aaa;font-size:.78rem">${JSON.stringify(snap.counts || {}, null, 2).replace(/</g, '&lt;')}</pre>`;
    main.appendChild(block);
  } catch (err) {
    console.warn('[SOMOSUM] storage diag', err);
  }
}

async function appendSecurityAuditBlock(main) {
  if (!main || main.querySelector('.security-audit-diag')) return;
  const report = await runSecurityAudit();
  const block = document.createElement('section');
  block.className = 'diag-group security-audit-diag';
  block.innerHTML = `<h2>Auditoria de segurança</h2>${auditReportHtml(report)}`;
  main.appendChild(block);
}

async function runCultoValidation() {
  const main = $('#diag-main');
  flashStatus('Validando culto…');
  try {
    const { validateCultoPackage, formatCultoValidationReport } = await import('../ops/culto-validate.js');
    const result = await validateCultoPackage();
    const report = formatCultoValidationReport(result);
    if (main) {
      const block = document.createElement('section');
      block.className = 'diag-group';
      block.innerHTML = `
        <h2>Validar Culto</h2>
        <pre class="diag-culto-report" style="white-space:pre-wrap;background:#111;padding:1rem;border-radius:8px;color:${result.ready ? '#9dcea0' : '#e8b4a0'}">${report.replace(/</g, '&lt;')}</pre>`;
      const existing = main.querySelector('.diag-culto-report')?.closest('.diag-group');
      if (existing) existing.replaceWith(block);
      else main.prepend(block);
    }
    flashStatus(result.ready ? 'Culto pronto' : 'Pendências encontradas');
  } catch (err) {
    flashStatus('Falha ao validar culto');
    console.warn('[SOMOSUM] validate culto', err);
  }
}

function buildShell() {
  const app = $('#diag-app');
  if (!app) return;
  const meta = getAppMeta();
  const nativeHint = shellAvailable()
    ? ''
    : '<span class="diag-shell-hint">Abra pelo SOMOSUM.exe para Controle e Projeção</span>';
  app.innerHTML = `
    <div class="diag-toolbar${isEmbed ? ' diag-toolbar--embed' : ''}">
      <div class="diag-toolbar-brand">
        <strong class="diag-brand">Diagnóstico SOMOSUM</strong>
        <span class="diag-meta-line">${metaSummaryLine(meta)}</span>
        ${nativeHint}
        <span id="diag-status" class="diag-status" aria-live="polite"></span>
      </div>
      <div class="diag-toolbar-actions">
        <button type="button" class="diag-btn diag-btn--primary" id="diag-run">Analisar novamente</button>
        <button type="button" class="diag-btn diag-btn--secondary" id="diag-validate-culto">Validar Culto</button>
        <button type="button" class="diag-btn diag-btn--ghost" id="diag-export">Exportar relatório</button>
        <button type="button" class="diag-btn diag-btn--ghost" id="diag-restart">Reiniciar servidor</button>
        <button type="button" class="diag-btn diag-btn--ghost" id="diag-open-control">Controle</button>
        <button type="button" class="diag-btn diag-btn--ghost" id="diag-open-projection">Projeção</button>
        <button type="button" class="diag-btn diag-btn--ghost diag-embed-only" id="diag-open-panel">Painel gestão</button>
      </div>
    </div>
    <div class="diag-progress" id="diag-progress" hidden><div class="diag-progress-bar"></div></div>
    <aside class="diag-ecm-host" id="diag-ecm-host" aria-label="Engine Connectivity"></aside>
    <main class="diag-main" id="diag-main">
      <div class="diag-loading">Executando verificações…</div>
    </main>`;
  wireToolbar();
  const ecmHost = document.getElementById('diag-ecm-host');
  if (ecmHost) {
    try {
      mountEngineDiagnosticsPanel(ecmHost);
    } catch (err) {
      console.warn('[SOMOSUM diagnostics] ECM panel mount failed', err);
      ecmHost.innerHTML = '<p class="diag-ecm-fallback">Motor nativo indisponível neste contexto.</p>';
    }
  }
}

function showFatalError(msg) {
  const app = $('#diag-app');
  if (!app) return;
  app.innerHTML = `
    <div class="diag-loading" style="padding:2rem">
      <h2 style="color:#d4c68d;margin:0 0 .75rem">Diagnóstico interrompido</h2>
      <p style="color:#888;line-height:1.55;max-width:480px;margin:0 auto 1rem">${msg}</p>
      <button type="button" class="diag-btn diag-btn--primary" onclick="location.reload()">Tentar novamente</button>
    </div>`;
}

function withTimeout(promise, ms, label) {
  return Promise.race([
    promise,
    new Promise((_, reject) => {
      setTimeout(() => reject(new Error(`${label} — tempo esgotado (${Math.round(ms / 1000)}s)`)), ms);
    }),
  ]);
}

async function runAnalysis() {
  if (running) return;
  running = true;
  notifyEmbed('analyzing');
  const progress = $('#diag-progress');
  const main = $('#diag-main');
  if (progress) progress.hidden = false;
  if (main) main.innerHTML = '<div class="diag-loading">Verificando servidor, arquivos, rede e monitores…</div>';

  try {
    lastResult = await withTimeout(
      runServerDiagnostics({ includeClient: true, screenConnected: null }),
      isEmbed ? 20000 : 25000,
      'Análise'
    );
    if (main) {
      main.innerHTML = renderDiagnosticsHtml(lastResult);
      wireActions(main);
      if (!isEmbed) {
        appendRenderProfilerBlock(main);
        void appendPerformanceBlock(main);
        void appendDesignSystemBlock(main);
        void appendStoragePlatformBlock(main);
        void appendWorshipEngineBlock(main);
        void appendSecurityAuditBlock(main);
      }
    }
    markAppReady();
    document.getElementById('diag-loading')?.remove();
    notifyEmbed('ready');
  } catch (err) {
    const msg = err?.message || String(err);
    if (main) {
      main.innerHTML = `<div class="diag-loading">Erro ao analisar: ${msg}. Clique <strong>Analisar novamente</strong>.</div>`;
    } else {
      showFatalError(msg);
    }
    markAppReady();
    notifyEmbed('error');
  } finally {
    running = false;
    if (progress) progress.hidden = true;
  }
}

async function main() {
  if (isEmbed) {
    document.documentElement.dataset.diagEmbed = '1';
    notifyEmbed('loading');
  }
  try {
    await engineReady;
    await initAppMetaRuntime();
    bootstrapRenderEngine();
    bootstrapSecurity();
    if (!isEmbed) bootstrapPerformance('diagnostics');
    bootstrapDesignSystem('diagnostics');
    if (!isEmbed) void initStoragePlatform();
    buildShell();
    document.getElementById('diag-loading')?.remove();
    await runAnalysis();
  } catch (err) {
    console.error('[SOMOSUM diagnostics]', err);
    showFatalError(err?.message || String(err));
    markAppReady();
    notifyEmbed('error');
  }
  if (!isEmbed) {
    TaskScheduler.register({
      id: TaskIds.DIAGNOSTICS_REANALYZE,
      kind: 'interval',
      intervalMs: 45000,
      priority: 10,
      runWhenHidden: false,
      fn: () => {
        if (!running && document.visibilityState === 'visible') runAnalysis();
      },
    });
  }
}

main();
