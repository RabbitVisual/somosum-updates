/**
 * Comando Central — Início do Painel Gerencial (UI 8.7.9).
 */
import { churchChecklistItem } from './panel-church.js';
import { $, escapeHtml, fetchJson, setText } from './panel-utils.js';
import { faBtnIcon, faPanelIcon } from '../core/fa-icons.js';
import { showSection } from './panel-shell.js';
import { PRODUCT_COVER } from '../core/brand-assets.js';

export function homeSectionHtml(active) {
  return `
    <section class="panel-section panel-section--home${active ? ' is-active' : ''}" data-section="inicio">
      <div class="panel-hero-cover" aria-hidden="false">
        <img
          class="panel-hero-cover__img"
          src="${PRODUCT_COVER}"
          alt="SOMOS UM — Sistema de projeção para cultos"
          loading="eager"
          decoding="async"
          width="1200"
          height="630"
        />
      </div>

      <div class="panel-welcome">
        <div class="panel-welcome__copy">
          <p class="panel-welcome__eyebrow" id="panel-home-church">SOMOS UM · Projeção para igrejas</p>
          <p class="panel-welcome__lead">Um caminho: abra o Controle para o culto. Use Rede só se for celular; Telas para projetor e púlpito.</p>
          <div class="panel-welcome__cta">
            <button type="button" class="panel-cta panel-cta--primary" data-act="start-service">${faBtnIcon('control')} Abrir Controle</button>
            <button type="button" class="panel-cta panel-cta--ghost" data-go="rede">${faPanelIcon('rede')} Preparar Rede</button>
          </div>
        </div>
        <aside class="panel-welcome__pulse" aria-label="Estado do sistema">
          <p class="panel-welcome__pulse-label">Estado agora</p>
          <ul class="panel-pulse-list">
            <li><span class="panel-pulse-dot" id="home-dot-engine"></span><span>Motor</span><strong id="home-pill-engine">…</strong></li>
            <li><span class="panel-pulse-dot" id="home-dot-lan"></span><span>Rede</span><strong id="home-pill-lan">…</strong></li>
            <li><span class="panel-pulse-dot" id="home-dot-surf"></span><span>Telas</span><strong id="home-pill-surfaces">…</strong></li>
          </ul>
          <div class="panel-welcome__meta">
            <span>v<strong id="home-ver">—</strong></span>
            <span>porta <strong id="home-port">—</strong></span>
            <span id="home-lan">—</span>
          </div>
        </aside>
      </div>

      <div class="panel-launch-grid" aria-label="Outras superfícies">
        <button type="button" class="panel-launch" data-act="open-screen">
          <span class="panel-launch__ico">${faPanelIcon('screen')}</span>
          <span class="panel-launch__label">Projeção</span>
          <span class="panel-launch__hint">Tela da congregação</span>
        </button>
        <button type="button" class="panel-launch" data-act="open-stage">
          <span class="panel-launch__ico">${faPanelIcon('stage')}</span>
          <span class="panel-launch__label">Púlpito</span>
          <span class="panel-launch__hint">Cifras e próxima</span>
        </button>
        <button type="button" class="panel-launch" data-act="open-remote">
          <span class="panel-launch__ico">${faPanelIcon('remote')}</span>
          <span class="panel-launch__label">Remote</span>
          <span class="panel-launch__hint">Celular na Wi‑Fi</span>
        </button>
        <button type="button" class="panel-launch" data-go="monitores">
          <span class="panel-launch__ico">${faPanelIcon('monitores')}</span>
          <span class="panel-launch__label">Monitores</span>
          <span class="panel-launch__hint">Projetor 1 e 2</span>
        </button>
      </div>

      <div class="panel-home-grid">
        <article class="panel-tile panel-tile--wide">
          <header class="panel-tile__head">
            <div>
              <h3>Pré-culto</h3>
              <p>Checklist do pacote — corrija o que estiver em vermelho.</p>
            </div>
            <span class="panel-chip">Checklist</span>
          </header>
          <ul class="panel-checklist" id="panel-checklist"></ul>
        </article>

        <article class="panel-tile">
          <header class="panel-tile__head">
            <div>
              <h3>Como começar</h3>
              <p>Quatro passos para o culto.</p>
            </div>
          </header>
          <ol class="panel-steps">
            <li><strong>Controle</strong> — monte a ordem e ligue Ao vivo.</li>
            <li><strong>Loja</strong> — neste Painel: Comando → Loja (plugins).</li>
            <li><strong>Projeção</strong> — abra em Superfícies quando for o culto.</li>
            <li><strong>Rede</strong> — só se usar celular na Wi‑Fi.</li>
          </ol>
          <div class="panel-tile__actions">
            <button type="button" class="panel-cta panel-cta--ghost panel-cta--sm" data-go="rede">Rede</button>
            <button type="button" class="panel-cta panel-cta--ghost panel-cta--sm" data-go="superficies">Superfícies</button>
            <a class="panel-cta panel-cta--ghost panel-cta--sm" href="/docs/" target="_blank" rel="noopener">Docs</a>
          </div>
        </article>

        <article class="panel-tile">
          <header class="panel-tile__head">
            <div>
              <h3>Saúde</h3>
              <p>Resumo — detalhes em Operação.</p>
            </div>
            <span class="panel-chip panel-chip--soft">Ao vivo</span>
          </header>
          <dl class="panel-stat-grid">
            <div><dt>LAN</dt><dd id="home-st-lan">—</dd></div>
            <div><dt>Backup</dt><dd id="home-st-bak">—</dd></div>
            <div><dt>Integridade</dt><dd id="home-st-int">—</dd></div>
            <div><dt>Superfícies</dt><dd id="home-st-surf">—</dd></div>
          </dl>
          <div class="panel-tile__actions">
            <button type="button" class="panel-cta panel-cta--secondary panel-cta--sm" data-act="backup-now">Backup agora</button>
            <button type="button" class="panel-cta panel-cta--ghost panel-cta--sm" data-go="operacao">Operação</button>
          </div>
        </article>

        <article class="panel-tile">
          <header class="panel-tile__head">
            <div>
              <h3>Últimos cultos</h3>
              <p>Abre no Controle.</p>
            </div>
          </header>
          <ul class="panel-simple-list" id="home-cultos"><li>Carregando…</li></ul>
        </article>

        <article class="panel-tile">
          <header class="panel-tile__head">
            <div>
              <h3>Recentes</h3>
              <p>Do Controle neste PC.</p>
            </div>
          </header>
          <div class="panel-chips" id="home-recents"></div>
        </article>
      </div>
    </section>`;
}

export function updateChecklist(h, { onPrepareLan } = {}) {
  const items = [
    churchChecklistItem(),
    {
      ok: !!h.konva,
      label: 'Konva (Designer)',
      detail: h.konva ? 'vendor/konva.min.js OK' : 'Arquivo ausente ou incompleto',
      solution: h.konva ? '' : 'Reinstale o pacote SOMOSUM completo (pasta vendor/).',
    },
    {
      ok: (h.bibles || 0) >= 1,
      label: `Bíblias (${h.bibles || 0})`,
      detail: (h.bibles || 0) >= 1
        ? `${h.bibles} versão(ões) disponíveis`
        : 'Nenhuma *.bible.js encontrada',
      solution: (h.bibles || 0) >= 1 ? '' : 'Extraia o pacote completo — pasta storage/private/biblias/offline/.',
    },
    {
      ok: (h.fonts || 0) >= 1,
      label: `Fontes (${h.fonts || 0})`,
      detail: (h.fonts || 0) >= 1 ? 'Fontes tipográficas OK' : 'Pasta fonts/ vazia',
      solution: (h.fonts || 0) >= 1 ? '' : 'Copie as fontes oficiais para fonts/ ou reinstale o pacote.',
      action: (h.fonts || 0) >= 1 ? '' : 'folder-fonts',
      actionLabel: 'Abrir fonts/',
    },
    {
      ok: !!h.dataWritable,
      label: 'Pasta data gravável',
      detail: h.dataWritable ? 'Gravação OK' : 'Sem permissão de escrita em data/',
      solution: h.dataWritable
        ? ''
        : 'Libere escrita em data/ (UAC se necessário).',
      action: h.dataWritable ? '' : 'fix-data-acl',
      actionLabel: 'Corrigir com admin',
    },
    {
      ok: !!h.somosumExe,
      label: 'SOMOSUM.exe',
      detail: h.somosumExe ? 'Executável encontrado' : 'EXE não encontrado',
      solution: h.somosumExe ? '' : 'Compile o launcher ou reinstale pelo Setup.',
    },
  ];
  if (h.lanMode || h.lanModeRequested) {
    items.push({
      ok: !!h.lanBindOk,
      label: h.lanBindOk ? `LAN ativo (${h.lanIp || '?'})` : 'LAN ainda não liberada',
      detail: h.lanBindOk ? 'Portas e firewall OK' : 'Modo LAN ligado, bind pendente',
      solution: h.lanBindOk ? '' : 'Clique em Preparar rede e confirme o UAC.',
      action: h.lanBindOk ? '' : 'prepare-lan',
      actionLabel: 'Preparar rede',
    });
  }

  const list = $('panel-checklist');
  if (!list) return;
  list.innerHTML = items.map((it) => {
    const cls = it.ok ? 'is-ok' : 'is-fail';
    const mark = it.ok ? '✓' : '!';
    const sol = !it.ok && it.solution
      ? `<p class="panel-check-sol">${escapeHtml(it.solution)}</p>`
      : '';
    const act = !it.ok && it.action
      ? `<button type="button" class="panel-check-act" data-act="${escapeHtml(it.action)}">${escapeHtml(it.actionLabel || 'Corrigir')}</button>`
      : '';
    const detail = it.detail ? `<span class="panel-check-detail">${escapeHtml(it.detail)}</span>` : '';
    return `<li class="${cls}"><div class="panel-check-row"><span class="panel-check-mark">${mark}</span><div><strong>${escapeHtml(it.label)}</strong>${detail}</div></div>${sol}${act}</li>`;
  }).join('');

  list.querySelectorAll('[data-act]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const act = btn.getAttribute('data-act');
      if (act === 'prepare-lan' || act === 'fix-data-acl') {
        onPrepareLan?.();
      } else if (act === 'folder-fonts') {
        window.Engine?.shell?.openFolder?.('fonts');
      } else if (act === 'go-igreja') {
        showSection('igreja');
      }
    });
  });
}

function setPulse(id, text, ok) {
  const el = $(id);
  if (el) {
    el.textContent = text;
    el.className = ok === true ? 'is-ok' : (ok === false ? 'is-warn' : '');
  }
  const map = {
    'home-pill-engine': 'home-dot-engine',
    'home-pill-lan': 'home-dot-lan',
    'home-pill-surfaces': 'home-dot-surf',
  };
  const dotEl = $(map[id]);
  if (dotEl) {
    dotEl.className = `panel-pulse-dot${ok === true ? ' is-ok' : (ok === false ? ' is-warn' : '')}`;
  }
}

/** Atualiza Motor/Rede a partir do /api/health (leve — a cada tick). */
export function updateHomePulsesFromHealth(h) {
  if (!h || typeof h !== 'object') return;
  if (typeof h.ok !== 'boolean' && h.port == null) return;
  setPulse('home-pill-engine', h.ok ? 'Online' : 'Offline', !!h.ok);
  setPulse(
    'home-pill-lan',
    h.lanBindOk ? (h.lanIp || 'LAN OK') : (h.lanMode ? 'Pendente' : 'Local'),
    h.lanBindOk ? true : (h.lanMode ? false : null),
  );
}

export async function refreshHomeDashboard(h) {
  setText('home-st-lan', h?.lanBindOk ? `OK ${h.lanIp || ''}` : (h?.lanMode ? 'Pendente' : 'Local'));

  updateHomePulsesFromHealth(h || {});

  try {
    const bak = await fetchJson('/api/backup/status', 5000);
    setText('home-st-bak', bak?.lastBackup || bak?.ok ? 'Disponível' : '—');
  } catch {
    setText('home-st-bak', '—');
  }
  try {
    const integ = await fetchJson('/api/storage/integrity', 8000);
    setText('home-st-int', integ?.ok ? `${integ.total ?? integ.checked ?? 0} OK` : `${integ?.fail || '?'} falha(s)`);
  } catch {
    setText('home-st-int', '—');
  }

  try {
    const raw = await fetchJson('/api/clients/presence?maxAge=60000', 5000);
    const n = Array.isArray(raw?.clients) ? raw.clients.length : (Array.isArray(raw) ? raw.length : 0);
    setText('home-st-surf', n > 0 ? `${n} online` : 'Nenhuma');
    setPulse('home-pill-surfaces', n > 0 ? `${n} online` : 'Nenhuma', n > 0);
  } catch {
    setText('home-st-surf', '—');
    setPulse('home-pill-surfaces', '—', null);
  }

  try {
    const prefs = await fetchJson('/api/data/config.json', 4000).catch(() => null);
    const church = prefs?.church?.name?.trim();
    const el = $('panel-home-church');
    if (el && church) el.textContent = church;
  } catch { /* ignore */ }

  const cultosEl = $('home-cultos');
  if (cultosEl) {
    try {
      const idx = await fetchJson('/api/data/cultos/index.json', 5000).catch(() => null);
      const list = idx?.cultos || idx?.items || [];
      const recent = [...list].sort((a, b) => String(b.date || '').localeCompare(String(a.date || ''))).slice(0, 5);
      cultosEl.innerHTML = recent.length
        ? recent.map((c) => {
          const id = escapeHtml(c.id || c.cultoId || '');
          const title = escapeHtml(c.title || c.name || 'Culto');
          const date = escapeHtml(c.date || '');
          return `<li>
            <button type="button" class="panel-culto-link" data-act="open-culto" data-culto-id="${id}">
              <strong>${title}</strong>
              <span>${date}</span>
            </button>
          </li>`;
        }).join('')
        : '<li class="is-empty">Nenhum culto listado ainda</li>';
    } catch {
      cultosEl.innerHTML = '<li class="is-empty">Abra o Controle → Cultos para criar</li>';
    }
  }

  const recentsEl = $('home-recents');
  if (recentsEl) {
    try {
      const raw = localStorage.getItem('somosum.library.recent');
      const recents = raw ? JSON.parse(raw) : [];
      const bible = localStorage.getItem('somosum-bible-recent');
      const bibleItems = bible ? JSON.parse(bible) : [];
      const chips = [
        ...recents.slice(0, 4).map((r) => `<span class="panel-chip">${escapeHtml(r.label || r.id)}</span>`),
        ...bibleItems.slice(0, 3).map((b) => `<span class="panel-chip">${escapeHtml(b.ref || b.label || 'Versículo')}</span>`),
      ];
      recentsEl.innerHTML = chips.join('') || '<span class="panel-chip panel-chip--soft">Use o Controle para gerar recentes</span>';
    } catch {
      recentsEl.innerHTML = '<span class="panel-chip panel-chip--soft">—</span>';
    }
  }
}
