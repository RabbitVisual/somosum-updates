/**
 * Agendamento de backup automático pré-culto (U2-H).
 */
const PREFS_KEY = 'somosum-backup-schedule';
const LOG_KEY = 'somosum-backup-log';
const LAST_KEY = 'somosum-backup-last';
const MAX_LOG = 40;

let intervalId = null;

export function getBackupSchedulePrefs() {
  try {
    return {
      autoBackupMinutes: 0,
      autoBackupPreService: false,
      retentionCount: 14,
      ...JSON.parse(localStorage.getItem(PREFS_KEY) || '{}'),
    };
  } catch {
    return { autoBackupMinutes: 0, autoBackupPreService: false, retentionCount: 14 };
  }
}

export function saveBackupSchedulePrefs(patch) {
  const next = { ...getBackupSchedulePrefs(), ...patch };
  try { localStorage.setItem(PREFS_KEY, JSON.stringify(next)); } catch { /* */ }
  return next;
}

export function getBackupLog() {
  try {
    return JSON.parse(localStorage.getItem(LOG_KEY) || '[]');
  } catch {
    return [];
  }
}

function appendLog(entry) {
  const log = getBackupLog();
  log.push({ ...entry, ts: Date.now() });
  while (log.length > MAX_LOG) log.shift();
  try { localStorage.setItem(LOG_KEY, JSON.stringify(log)); } catch { /* */ }
  try {
    fetch('/api/log', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ level: 'info', message: entry.message || 'backup', detail: entry }),
    }).catch(() => {});
  } catch { /* */ }
  return log;
}

export function getLastBackupRun() {
  try {
    return Number(localStorage.getItem(LAST_KEY) || 0) || 0;
  } catch {
    return 0;
  }
}

export async function runBackupNow(reason = 'manual') {
  console.info('[SOMOSUM] backup', reason);
  try {
    const res = await fetch('/api/backup/incremental', { method: 'POST' });
    const ok = res.ok;
    localStorage.setItem(LAST_KEY, String(Date.now()));
    appendLog({ ok, reason, message: ok ? `Backup OK (${reason})` : `Backup falhou (${reason})` });
    return ok;
  } catch (err) {
    appendLog({ ok: false, reason, message: `Backup erro: ${err.message || err}` });
    return false;
  }
}

export function stopBackupScheduler() {
  if (intervalId) {
    clearInterval(intervalId);
    intervalId = null;
  }
}

/**
 * Inicia intervalo quando o painel está aberto.
 * @param {{ onRun?: (ok: boolean) => void }} [opts]
 */
export function startBackupScheduler(opts = {}) {
  stopBackupScheduler();
  const prefs = getBackupSchedulePrefs();
  const minutes = Number(prefs.autoBackupMinutes) || 0;
  if (minutes > 0) {
    intervalId = setInterval(() => {
      void runBackupNow('interval').then((ok) => opts.onRun?.(ok));
    }, minutes * 60 * 1000);
  }
  if (prefs.autoBackupPreService) {
    // Pré-culto: se nunca rodou nas últimas 12h, dispara uma vez ao abrir o painel
    const last = getLastBackupRun();
    if (!last || Date.now() - last > 12 * 60 * 60 * 1000) {
      void runBackupNow('pre-service').then((ok) => opts.onRun?.(ok));
    }
  }
  return () => stopBackupScheduler();
}
