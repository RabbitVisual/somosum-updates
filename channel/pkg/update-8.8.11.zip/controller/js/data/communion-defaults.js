import { generateId } from '../core/store.js';

export const DEFAULT_COMMUNION_PHASES = [
  { id: 'intro', title: 'Ceia do Senhor', subtitle: 'Em memória de Cristo', reference: '', text: '' },
  {
    id: 'bread',
    title: 'O Pão',
    subtitle: 'Corpo de Cristo, partido por nós',
    reference: '1 Coríntios 11:23-24 (NAA)',
    text: 'Porque eu recebi do Senhor o que também vos entreguei: que o Senhor Jesus, na noite em que foi traído, tomou pão; e, tendo dado graças, partiu-o e disse: Isto é o meu corpo, que é partido por vós; fazei isto em memória de mim.',
  },
  {
    id: 'cup',
    title: 'O Cálice',
    subtitle: 'Sangue da nova aliança',
    reference: '1 Coríntios 11:25 (NAA)',
    text: 'Semelhantemente, depois de cear, tomou o cálice, dizendo: Este cálice é a nova aliança no meu sangue; fazei isto, sempre que o beberdes, em memória de mim.',
  },
  {
    id: 'meditation',
    title: 'Meditação',
    subtitle: 'Com reverência e gratidão',
    reference: '',
    text: '',
  },
];

export function createCommunionItem(title = 'Ceia do Senhor') {
  return {
    id: generateId(),
    type: 'communion',
    title,
    slideType: 'communion',
    data: {
      mode: 'sequence',
      phases: structuredClone(DEFAULT_COMMUNION_PHASES),
      showCross: false,
      showElements: true,
      useCommunionTheme: true,
      style: { fontSize: 64, animation: 'reverent' },
    },
  };
}

export function insertDefaultCommunionTexts(phases) {
  const defaults = DEFAULT_COMMUNION_PHASES;
  return phases.map((p, i) => {
    const d = defaults.find((x) => x.id === p.id) || defaults[i];
    if (!d) return p;
    return {
      ...p,
      reference: p.reference || d.reference,
      text: p.text || d.text,
      subtitle: p.subtitle ?? d.subtitle,
    };
  });
}
