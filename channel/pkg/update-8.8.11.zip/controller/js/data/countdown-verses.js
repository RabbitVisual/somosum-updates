/** Referências para rotação aleatória durante o pré-culto */
export const COUNTDOWN_VERSE_POOL = [
  { book: 'Jo', chapter: 17, verseStart: 11, verseEnd: 11 },
  { book: 'Sl', chapter: 46, verseStart: 10, verseEnd: 10 },
  { book: 'Rm', chapter: 12, verseStart: 5, verseEnd: 5 },
  { book: 'Fp', chapter: 4, verseStart: 13, verseEnd: 13 },
  { book: 'Mt', chapter: 18, verseStart: 20, verseEnd: 20 },
  { book: 'Sl', chapter: 133, verseStart: 1, verseEnd: 1 },
  { book: 'Hb', chapter: 10, verseStart: 25, verseEnd: 25 },
  { book: 'Is', chapter: 40, verseStart: 31, verseEnd: 31 },
  { book: 'Pv', chapter: 3, verseStart: 5, verseEnd: 6 },
  { book: '1Co', chapter: 13, verseStart: 13, verseEnd: 13 },
  { book: 'Sl', chapter: 27, verseStart: 4, verseEnd: 4 },
  { book: 'Mt', chapter: 6, verseStart: 33, verseEnd: 33 },
  { book: 'Js', chapter: 1, verseStart: 5, verseEnd: 5 },
  { book: 'Sl', chapter: 100, verseStart: 4, verseEnd: 4 },
  { book: 'Cl', chapter: 3, verseStart: 16, verseEnd: 16 },
];

export const DEFAULT_COUNTDOWN_NOTICES = [
  { icon: 'mobile-signal', text: 'Desligue ou silencie o celular' },
  { icon: 'earth-americas', text: 'Desconecte-se do mundo externo por um momento' },
  { icon: 'hands-praying', text: 'Prepare o coração para adorar a Deus' },
  { icon: 'sparkles', text: 'Foque na presença do Senhor' },
  { icon: 'handshake', text: 'Receba com alegria quem está ao seu lado' },
  { icon: 'volume-xmark', text: 'Evite conversas — este é um tempo de preparação' },
];
