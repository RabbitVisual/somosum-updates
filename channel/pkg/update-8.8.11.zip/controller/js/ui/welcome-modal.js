/**

 * Modal de boas-vindas na primeira execução.

 */

import { PRODUCT_LOGO_REL } from '../core/brand-assets.js';



const STORAGE_KEY = 'somosum.welcome.v2.done';



export function maybeShowWelcome(app) {
  if (localStorage.getItem(STORAGE_KEY)) return;
  setTimeout(async () => {
    if (document.getElementById('somosum-whats-new')) return;
    try {
      const { fetchWhatsNew } = await import('../core/app-update-service.js');
      if (await fetchWhatsNew()) return;
    } catch { /* ignore */ }
    showWelcome(app);
  }, 1800);
}



export function showWelcome(app) {

  if (document.getElementById('somosum-welcome')) return;



  const ver = window.SOMOSUM_VERSION || '4.0.0';

  const author = window.SOMOSUM_AUTHOR || 'Reinan Rodrigues';



  const overlay = document.createElement('div');

  overlay.id = 'somosum-welcome';

  overlay.className = 'welcome-overlay';

  overlay.innerHTML = `

    <div class="welcome-card">

      <img src="${PRODUCT_LOGO_REL}" alt="" class="welcome-logo" onerror="this.style.display='none'" />

      <p class="welcome-kicker">SOMOSUM v${ver}</p>

      <h2>Bem-vindo ao SOMOSUM</h2>

      <p class="welcome-lead">Sistema de projeção <strong>profissional</strong> para cultos — 100% local, sem internet.</p>

      <ul class="welcome-steps">

        <li><span>1</span> Servidor em segundo plano — ícone dourado na bandeja</li>

        <li><span>2</span> Monte o programa e projete com um clique</li>

        <li><span>3</span> <strong>Designer</strong> para slides personalizados</li>

        <li><span>4</span> Mensagem com foto do pregador e Bíblia configurável</li>

      </ul>

      <p class="welcome-credits">Desenvolvido por <strong>${author}</strong></p>

      <div class="welcome-actions">

        <button type="button" class="btn btn-secondary" data-act="install-hint">Como instalar</button>

        <button type="button" class="btn btn-secondary" data-act="tour">Tour guiado</button>

        <button type="button" class="btn btn-primary" data-act="ok">Começar</button>

      </div>

    </div>`;



  document.body.appendChild(overlay);

  requestAnimationFrame(() => overlay.classList.add('is-visible'));



  const close = () => {

    localStorage.setItem(STORAGE_KEY, '1');

    overlay.classList.remove('is-visible');

    setTimeout(() => overlay.remove(), 250);

  };



  overlay.querySelector('[data-act="ok"]')?.addEventListener('click', () => {

    close();

    if (!localStorage.getItem('somosum.tour.v11.done')) {
      setTimeout(() => {
        import('./onboarding-tour.js').then(({ startTour }) => startTour(app));
      }, 600);
    }

  });

  overlay.querySelector('[data-act="tour"]')?.addEventListener('click', () => {

    close();

    import('./onboarding-tour.js').then(({ startTour }) => startTour(app));

  });

  overlay.querySelector('[data-act="install-hint"]')?.addEventListener('click', () => {

    app?.toast?.('No Painel Gerencial: Dados → Criar atalho na Área de Trabalho', 'warn');

  });

  overlay.addEventListener('click', (e) => {

    if (e.target === overlay) close();

  });

}


