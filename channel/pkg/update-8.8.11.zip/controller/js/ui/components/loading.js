import { createElement, text } from '../../core/render-engine/safe-dom.js';

export function createLoading(label = 'Carregando…', { className = '' } = {}) {
  const el = createElement('div', {
    class: ['su-loading', className].filter(Boolean).join(' '),
    role: 'status',
    'aria-live': 'polite',
  });
  el.appendChild(createElement('span', { class: 'su-loading__spinner', 'aria-hidden': 'true' }));
  el.appendChild(text(label));
  return el;
}
