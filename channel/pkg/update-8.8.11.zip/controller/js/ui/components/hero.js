import { createElement, text } from '../../core/render-engine/safe-dom.js';

export function renderHero(host, { brand = 'SOMOSUM', lead = '', actions = [] } = {}) {
  if (!host) return;
  host.innerHTML = '';
  const el = createElement('header', { class: 'su-hero' });
  el.appendChild(createElement('h1', { class: 'su-hero__brand' }, text(brand)));
  if (lead) el.appendChild(createElement('p', { class: 'su-hero__lead' }, text(lead)));
  if (actions.length) {
    const row = createElement('div', { class: 'su-toolbar', style: 'margin-top:var(--space-4)' });
    actions.forEach((node) => row.appendChild(node));
    el.appendChild(row);
  }
  host.appendChild(el);
  return el;
}

export function createKpiCard(label, value) {
  const el = createElement('article', { class: 'su-kpi' });
  el.appendChild(createElement('div', { class: 'su-kpi__value' }, text(String(value))));
  el.appendChild(createElement('div', { class: 'su-kpi__label' }, text(label)));
  return el;
}
