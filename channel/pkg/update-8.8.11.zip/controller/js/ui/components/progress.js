import { createElement } from '../../core/render-engine/safe-dom.js';

export function createProgress(value = 0, { max = 100, className = '' } = {}) {
  const pct = Math.max(0, Math.min(100, (value / max) * 100));
  const root = createElement('div', {
    class: ['su-progress', className].filter(Boolean).join(' '),
    role: 'progressbar',
    'aria-valuenow': String(Math.round(pct)),
    'aria-valuemin': '0',
    'aria-valuemax': '100',
  });
  const fill = createElement('div', { class: 'su-progress__fill', style: `width:${pct}%` });
  root.appendChild(fill);
  return {
    el: root,
    setValue(v) {
      const p = Math.max(0, Math.min(100, (v / max) * 100));
      fill.style.width = `${p}%`;
      root.setAttribute('aria-valuenow', String(Math.round(p)));
    },
  };
}

export function createSwitch(label, { checked = false, onChange = null, id = null } = {}) {
  const inputId = id || `su-switch-${Math.random().toString(36).slice(2, 8)}`;
  const wrap = createElement('label', { class: 'su-switch', for: inputId });
  const input = createElement('input', { type: 'checkbox', id: inputId, ...(checked ? { checked: true } : {}) });
  const track = createElement('span', { class: 'su-switch__track', 'aria-hidden': 'true' });
  const textEl = createElement('span', {}, document.createTextNode(label));
  wrap.appendChild(input);
  wrap.appendChild(track);
  wrap.appendChild(textEl);
  if (onChange) input.addEventListener('change', () => onChange(input.checked, input));
  return { el: wrap, input };
}
