import { createElement, text, append } from '../../core/render-engine/safe-dom.js';

/**
 * @typedef {{ id?: string, title: string, content: HTMLElement|string, open?: boolean }} AccordionItem
 */

export function mountAccordion(host, {
  items = [],
  multiple = false,
  className = '',
} = {}) {
  if (!host) return { dispose() {} };

  host.innerHTML = '';
  host.className = ['su-accordion', className].filter(Boolean).join(' ');

  const details = items.map((item, i) => {
    const det = createElement('details', {
      ...(item.id ? { id: item.id } : {}),
      ...(item.open ? { open: '' } : {}),
    });
    const summary = createElement('summary', {}, text(item.title));
    append(det, summary);
    if (typeof item.content === 'string') {
      const body = createElement('div', { class: 'su-accordion__body' });
      body.innerHTML = item.content;
      append(det, body);
    } else if (item.content) {
      const body = createElement('div', { class: 'su-accordion__body' });
      body.appendChild(item.content);
      append(det, body);
    }
    host.appendChild(det);
    return det;
  });

  if (!multiple) {
    host.addEventListener('toggle', (e) => {
      const target = e.target;
      if (!target.matches('details') || !target.open) return;
      details.forEach((d) => { if (d !== target) d.open = false; });
    });
  }

  return {
    openAt(index) {
      const d = details[index];
      if (d) d.open = true;
    },
    closeAll() {
      details.forEach((d) => { d.open = false; });
    },
    dispose() { host.innerHTML = ''; },
  };
}

export function createAccordionItem(title, content, { open = false, id = null } = {}) {
  return { title, content, open, id };
}
