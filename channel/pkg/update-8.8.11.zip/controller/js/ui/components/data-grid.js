import { createElement, text, append } from '../../core/render-engine/safe-dom.js';

/**
 * @typedef {{ key: string, label: string, sortable?: boolean, width?: string, render?: (row: object) => string|HTMLElement }} GridColumn
 */

export function createDataGrid(host, {
  columns = [],
  rows = [],
  rowKey = 'id',
  emptyLabel = 'Nenhum registro',
  onRowClick = null,
  onSort = null,
  className = '',
} = {}) {
  if (!host) return { dispose() {} };

  let sortKey = null;
  let sortDir = 'asc';
  let data = [...rows];

  host.innerHTML = '';
  host.className = ['su-data-grid', className].filter(Boolean).join(' ');

  const table = createElement('table', { class: 'su-data-grid__table' });
  const thead = createElement('thead');
  const headRow = createElement('tr');
  const colMap = new Map(columns.map((c) => [c.key, c]));

  columns.forEach((col) => {
    const th = createElement('th', {
      scope: 'col',
      ...(col.width ? { style: `width:${col.width}` } : {}),
      ...(col.sortable ? { 'data-sort-key': col.key, tabindex: '0', role: 'button' } : {}),
    }, text(col.label));
    if (col.sortable) th.classList.add('su-data-grid__sortable');
    headRow.appendChild(th);
  });
  append(thead, headRow);

  const tbody = createElement('tbody', { class: 'su-data-grid__body' });
  append(table, thead, tbody);
  host.appendChild(table);

  const empty = createElement('div', { class: 'su-empty su-data-grid__empty', hidden: '' });
  append(empty, createElement('p', { class: 'su-empty__title' }, text(emptyLabel)));
  host.appendChild(empty);

  function sortedRows() {
    if (!sortKey || !colMap.get(sortKey)?.sortable) return data;
    const dir = sortDir === 'desc' ? -1 : 1;
    return [...data].sort((a, b) => {
      const av = a[sortKey];
      const bv = b[sortKey];
      if (av == null && bv == null) return 0;
      if (av == null) return 1;
      if (bv == null) return -1;
      if (typeof av === 'number' && typeof bv === 'number') return (av - bv) * dir;
      return String(av).localeCompare(String(bv), 'pt-BR') * dir;
    });
  }

  function renderBody() {
    tbody.innerHTML = '';
    const list = sortedRows();
    empty.hidden = list.length > 0;

    list.forEach((row) => {
      const tr = createElement('tr', {
        'data-row-key': String(row[rowKey] ?? ''),
        tabindex: onRowClick ? '0' : undefined,
      });
      columns.forEach((col) => {
        const td = createElement('td');
        if (col.render) {
          const out = col.render(row);
          if (typeof out === 'string') td.innerHTML = out;
          else if (out) td.appendChild(out);
        } else {
          td.textContent = row[col.key] ?? '';
        }
        tr.appendChild(td);
      });
      if (onRowClick) {
        tr.addEventListener('click', () => onRowClick(row, tr));
        tr.addEventListener('keydown', (e) => {
          if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            onRowClick(row, tr);
          }
        });
      }
      tbody.appendChild(tr);
    });

    headRow.querySelectorAll('[data-sort-key]').forEach((th) => {
      const key = th.dataset.sortKey;
      th.classList.toggle('is-sorted', key === sortKey);
      th.classList.toggle('is-desc', key === sortKey && sortDir === 'desc');
      th.setAttribute('aria-sort', key === sortKey ? (sortDir === 'desc' ? 'descending' : 'ascending') : 'none');
    });
  }

  headRow.addEventListener('click', (e) => {
    const th = e.target.closest('[data-sort-key]');
    if (!th) return;
    const key = th.dataset.sortKey;
    if (sortKey === key) sortDir = sortDir === 'asc' ? 'desc' : 'asc';
    else { sortKey = key; sortDir = 'asc'; }
    onSort?.({ key: sortKey, dir: sortDir });
    renderBody();
  });

  headRow.addEventListener('keydown', (e) => {
    if (e.key !== 'Enter' && e.key !== ' ') return;
    const th = e.target.closest('[data-sort-key]');
    if (!th) return;
    e.preventDefault();
    th.click();
  });

  renderBody();

  return {
    setRows(next) {
      data = [...next];
      renderBody();
    },
    getRows: () => [...data],
    sort(key, dir = 'asc') {
      sortKey = key;
      sortDir = dir;
      renderBody();
    },
    refresh: renderBody,
    dispose() { host.innerHTML = ''; },
  };
}
