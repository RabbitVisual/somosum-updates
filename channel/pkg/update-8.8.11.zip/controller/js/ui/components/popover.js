import { createElement, text, append } from '../../core/render-engine/safe-dom.js';

let openPopover = null;

function placePopover(pop, anchor, placement = 'bottom') {
  const rect = anchor.getBoundingClientRect();
  const popRect = pop.getBoundingClientRect();
  const gap = 8;
  let top = rect.bottom + gap;
  let left = rect.left;

  if (placement === 'top') {
    top = rect.top - popRect.height - gap;
  } else if (placement === 'left') {
    top = rect.top;
    left = rect.left - popRect.width - gap;
  } else if (placement === 'right') {
    top = rect.top;
    left = rect.right + gap;
  }

  const maxLeft = window.innerWidth - popRect.width - 8;
  const maxTop = window.innerHeight - popRect.height - 8;
  left = Math.max(8, Math.min(left, maxLeft));
  top = Math.max(8, Math.min(top, maxTop));

  pop.style.top = `${top}px`;
  pop.style.left = `${left}px`;
}

export function mountPopover(anchor, {
  content = '',
  title = '',
  placement = 'bottom',
  className = '',
  onOpen = null,
  onClose = null,
} = {}) {
  if (!anchor) return { dispose() {} };

  const pop = createElement('div', {
    class: ['su-popover', className].filter(Boolean).join(' '),
    role: 'dialog',
    hidden: '',
  });

  if (title) {
    const head = createElement('div', { class: 'su-popover__title' }, text(title));
    append(pop, head);
  }
  const body = createElement('div', { class: 'su-popover__body' });
  if (typeof content === 'string') body.innerHTML = content;
  else if (content) body.appendChild(content);
  append(pop, body);

  document.body.appendChild(pop);

  let open = false;

  const close = () => {
    if (!open) return;
    open = false;
    pop.hidden = true;
    pop.classList.remove('is-open');
    anchor.setAttribute('aria-expanded', 'false');
    if (openPopover === api) openPopover = null;
    onClose?.();
  };

  const show = () => {
    if (openPopover && openPopover !== api) openPopover.close();
    open = true;
    openPopover = api;
    pop.hidden = false;
    pop.classList.add('is-open');
    anchor.setAttribute('aria-expanded', 'true');
    placePopover(pop, anchor, placement);
    onOpen?.();
  };

  const toggle = () => (open ? close() : show());

  const onDocClick = (e) => {
    if (!open) return;
    if (pop.contains(e.target) || anchor.contains(e.target)) return;
    close();
  };

  const onKey = (e) => {
    if (e.key === 'Escape') close();
  };

  document.addEventListener('click', onDocClick, true);
  document.addEventListener('keydown', onKey);
  window.addEventListener('resize', () => { if (open) placePopover(pop, anchor, placement); });
  window.addEventListener('scroll', () => { if (open) placePopover(pop, anchor, placement); }, true);

  anchor.setAttribute('aria-haspopup', 'dialog');
  anchor.setAttribute('aria-expanded', 'false');

  const api = { show, close, toggle, isOpen: () => open, el: pop, body };

  return {
    ...api,
    dispose() {
      close();
      document.removeEventListener('click', onDocClick, true);
      document.removeEventListener('keydown', onKey);
      pop.remove();
    },
  };
}
