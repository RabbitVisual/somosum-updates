import { createElement, text, append } from '../../core/render-engine/safe-dom.js';
import { trapFocus } from '../accessibility/a11y.js';

export function mountDrawer({
  id = 'su-drawer',
  title = '',
  side = 'right',
  content = null,
  onClose = null,
  appendTo = document.body,
} = {}) {
  let releaseFocus = () => {};
  let open = false;

  const root = createElement('aside', {
    id,
    class: `su-drawer su-drawer--${side}`,
    hidden: '',
    role: 'dialog',
    'aria-modal': 'true',
    'aria-label': title || 'Painel',
  });

  const backdrop = createElement('button', {
    type: 'button',
    class: 'su-drawer__backdrop',
    'aria-label': 'Fechar',
  });
  const panel = createElement('div', { class: 'su-drawer__panel' });
  const header = createElement('header', { class: 'su-drawer__header' });
  const titleEl = createElement('h2', { class: 'su-drawer__title' }, text(title));
  const closeBtn = createElement('button', {
    type: 'button',
    class: 'su-btn su-btn--ghost su-btn--icon su-drawer__close',
    'aria-label': 'Fechar painel',
  }, text('×'));
  append(header, titleEl, closeBtn);

  const body = createElement('div', { class: 'su-drawer__body' });
  if (typeof content === 'string') body.innerHTML = content;
  else if (content) body.appendChild(content);

  append(panel, header, body);
  append(root, backdrop, panel);
  appendTo.appendChild(root);

  const close = () => {
    if (!open) return;
    open = false;
    root.classList.remove('is-open');
    root.hidden = true;
    releaseFocus();
    releaseFocus = () => {};
    onClose?.();
  };

  const show = () => {
    if (open) return;
    open = true;
    root.hidden = false;
    requestAnimationFrame(() => {
      root.classList.add('is-open');
      releaseFocus = trapFocus(panel);
      closeBtn.focus();
    });
  };

  backdrop.addEventListener('click', close);
  closeBtn.addEventListener('click', close);
  root.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') close();
  });

  return {
    el: root,
    body,
    show,
    close,
    isOpen: () => open,
    setTitle: (t) => { titleEl.textContent = t; },
    setContent(node) {
      body.innerHTML = '';
      if (typeof node === 'string') body.innerHTML = node;
      else if (node) body.appendChild(node);
    },
    dispose() {
      close();
      root.remove();
    },
  };
}
