import { createElement, text } from '../../core/render-engine/safe-dom.js';

export function createBadge(label, { tone = 'default', className = '' } = {}) {
  const cls = ['su-badge', tone !== 'default' ? `su-badge--${tone}` : '', className].filter(Boolean).join(' ');
  return createElement('span', { class: cls }, text(label));
}
