import { createElement, text } from '../../core/render-engine/safe-dom.js';
import { createButton } from './button.js';

export function renderEmptyState(host, {
  title = 'Nada aqui ainda',
  lead = '',
  actionLabel = null,
  onAction = null,
} = {}) {
  if (!host) return;
  host.innerHTML = '';
  const root = createElement('div', { class: 'su-empty' });
  root.appendChild(createElement('p', { class: 'su-empty__title' }, text(title)));
  if (lead) root.appendChild(createElement('p', { class: 'su-empty__lead' }, text(lead)));
  if (actionLabel && onAction) {
    root.appendChild(createButton(actionLabel, { variant: 'primary', onClick: onAction }));
  }
  host.appendChild(root);
  return root;
}
