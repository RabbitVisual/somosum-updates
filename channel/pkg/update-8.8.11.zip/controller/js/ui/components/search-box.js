import { createElement, text } from '../../core/render-engine/safe-dom.js';

export function mountSearchBox(host, {
  placeholder = 'Buscar…',
  value = '',
  onInput = null,
  id = 'su-search',
} = {}) {
  if (!host) return { dispose() {} };
  host.innerHTML = '';
  host.classList.add('su-search');
  const input = createElement('input', {
    type: 'search',
    id,
    placeholder,
    value,
    autocomplete: 'off',
    'aria-label': placeholder,
  });
  host.appendChild(input);
  if (onInput) input.addEventListener('input', () => onInput(input.value, input));
  return {
    getValue: () => input.value,
    setValue: (v) => { input.value = v; },
    focus: () => input.focus(),
    dispose: () => { host.innerHTML = ''; },
  };
}
