import { createElement, text } from '../../core/render-engine/safe-dom.js';

export function createAlert(message, { tone = 'info', title = null } = {}) {
  const cls = ['su-alert', `su-alert--${tone}`].join(' ');
  const el = createElement('div', { class: cls, role: 'alert' });
  if (title) el.appendChild(createElement('strong', { class: 'su-alert__title' }, text(title)));
  el.appendChild(createElement('p', { class: 'su-alert__body' }, text(message)));
  return el;
}
