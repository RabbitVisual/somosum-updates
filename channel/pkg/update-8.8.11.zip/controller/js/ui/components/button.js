import { createElement, text, append } from '../../core/render-engine/safe-dom.js';

const VARIANTS = ['primary', 'secondary', 'danger', 'ghost'];

export function createButton(label, {
  variant = 'secondary',
  icon = null,
  type = 'button',
  className = '',
  disabled = false,
  onClick = null,
  attrs = {},
} = {}) {
  const cls = ['su-btn', VARIANTS.includes(variant) ? `su-btn--${variant}` : '', className].filter(Boolean).join(' ');
  const btn = createElement('button', { type, class: cls, disabled: disabled || undefined, ...attrs });
  if (icon) append(btn, icon);
  append(btn, text(label));
  if (onClick) btn.addEventListener('click', onClick);
  return btn;
}

export function createIconButton(label, {
  icon,
  variant = 'secondary',
  className = 'su-btn--icon',
  ...rest
} = {}) {
  const btn = createButton(label, { variant, icon, className, ...rest });
  btn.setAttribute('aria-label', label);
  return btn;
}
