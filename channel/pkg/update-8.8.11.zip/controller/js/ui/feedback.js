/**
 * Feedback API — thin wrapper over SOMOSUM UI Kit (compat).
 */
import { toast as kitToast, snackbar } from './kit/toast.js';
import { confirmDialog as kitConfirm, showModal as kitModal } from './kit/dialog.js';

let bannerEl = null;

export function toast(msg, type = 'info', durationMs = 2800) {
  return kitToast(msg, type, durationMs);
}

export { snackbar };

export function banner(msg, type = 'error') {
  if (!bannerEl) {
    bannerEl = document.createElement('div');
    bannerEl.className = 'su-alert feedback-banner';
    bannerEl.id = 'feedback-banner';
    document.body.prepend(bannerEl);
  }
  bannerEl.className = `su-alert su-alert--${type === 'error' ? 'error' : 'success'} feedback-banner feedback-banner--${type} is-visible`;
  bannerEl.textContent = msg;
  bannerEl.hidden = false;
}

export function clearBanner() {
  if (bannerEl) {
    bannerEl.hidden = true;
    bannerEl.classList.remove('is-visible');
  }
}

export function confirmDialog(opts) {
  return kitConfirm(opts);
}

export function showModal(opts) {
  return kitModal(opts);
}
