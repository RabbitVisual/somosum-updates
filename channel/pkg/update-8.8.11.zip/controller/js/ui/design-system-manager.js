/**
 * Design System Manager — bootstrap + snapshot.
 */
import { ThemeEngine } from './theme/theme-engine.js';
import { applyUiPrefs } from './apply-ui-prefs.js';
import { createLiveRegion, applyHighContrast } from './accessibility/a11y.js';
import { Motion } from './animations/motion.js';
import { loadCustomFonts } from '../core/fonts.js';
import { getPrefs } from '../core/store.js';

const SLIDE_FONT_SURFACES = new Set(['screen', 'designer', 'control', 'stage']);

let bootstrapped = false;
let liveRegion = null;

export function bootstrapDesignSystem(surface = 'default') {
  if (bootstrapped) return;
  bootstrapped = true;

  document.documentElement.dataset.surface = surface;
  document.documentElement.classList.add('somosum-ds-ready');

  try {
    applyUiPrefs(typeof getPrefs === 'function' ? getPrefs() : undefined);
  } catch { /* prefs optional early boot */ }

  liveRegion = createLiveRegion('somosum-ds-live');

  // Projeção, Designer, Controle e Púlpito injetam @font-face da pasta fonts/
  // para pickers, prévia e canvas usarem Montserrat / Open Sans / Roboto.
  if (SLIDE_FONT_SURFACES.has(surface)) {
    loadCustomFonts({ injectFaces: true }).catch(() => {});
  }

  if (typeof window !== 'undefined') {
    window.SOMOSUM_DESIGN_SYSTEM = {
      bootstrap: bootstrapDesignSystem,
      snapshot: buildSnapshot,
      ThemeEngine,
      Motion,
      announce: (msg) => liveRegion?.announce(msg),
      applyHighContrast,
    };

    window.addEventListener('somosum-sync-health', (ev) => {
      const state = ev.detail?.state;
      if (state === 'error') liveRegion?.announce('Erro de sincronização');
      else if (state === 'ok') liveRegion?.announce('Sincronizado');
    });
  }
}

export function buildSnapshot() {
  const root = document.documentElement;
  return {
    surface: root.dataset.surface || null,
    theme: ThemeEngine.getActiveId(),
    themeTokens: ThemeEngine.snapshot(),
    a11yContrast: root.classList.contains('su-a11y-contrast'),
    reducedMotion: Motion.reducedMotion(),
    lowSpec: !!window.__SOMOSUM_LOW_SPEC,
    uiScale: root.style.getPropertyValue('--ui-scale') || '1',
  };
}

export { ThemeEngine, Motion, createLiveRegion, applyHighContrast };
