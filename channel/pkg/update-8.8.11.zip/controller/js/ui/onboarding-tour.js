/**
 * Tour guiado do Controle — v11
 * Linguagem clara para o operador, poucos passos, cartão leve.
 */

const STORAGE_KEY = 'somosum.tour.v11.done';
const TOUR_MAX_LEGACY = 11;

const ICONS = {
  welcome: `<svg viewBox="0 0 64 64" aria-hidden="true"><rect x="8" y="12" width="48" height="32" rx="5" fill="none" stroke="currentColor" stroke-width="2.2"/><path d="M20 52h24M32 44v8" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/><circle cx="32" cy="28" r="7" fill="currentColor" opacity=".2"/></svg>`,
  windows: `<svg viewBox="0 0 64 64" aria-hidden="true"><rect x="6" y="10" width="24" height="36" rx="3" fill="currentColor" opacity=".18" stroke="currentColor" stroke-width="2"/><rect x="34" y="16" width="24" height="30" rx="3" fill="none" stroke="currentColor" stroke-width="2"/></svg>`,
  sidebar: `<svg viewBox="0 0 64 64" aria-hidden="true"><rect x="8" y="10" width="14" height="44" rx="3" fill="currentColor" opacity=".18" stroke="currentColor" stroke-width="2"/><rect x="28" y="10" width="28" height="44" rx="3" fill="none" stroke="currentColor" stroke-width="2"/><circle cx="15" cy="22" r="2.5" fill="currentColor"/><circle cx="15" cy="34" r="2.5" fill="currentColor" opacity=".65"/><circle cx="15" cy="46" r="2.5" fill="currentColor" opacity=".4"/></svg>`,
  live: `<svg viewBox="0 0 64 64" aria-hidden="true"><rect x="6" y="12" width="18" height="40" rx="3" fill="none" stroke="currentColor" stroke-width="2"/><rect x="28" y="12" width="30" height="22" rx="3" fill="currentColor" opacity=".14" stroke="currentColor" stroke-width="2"/><rect x="28" y="38" width="30" height="14" rx="3" fill="none" stroke="currentColor" stroke-width="2"/><circle cx="43" cy="23" r="4" fill="#c45c3e"/></svg>`,
  ordem: `<svg viewBox="0 0 64 64" aria-hidden="true"><rect x="14" y="12" width="36" height="9" rx="2" fill="currentColor" opacity=".22"/><rect x="14" y="27" width="36" height="9" rx="2" fill="currentColor" opacity=".4"/><rect x="14" y="42" width="36" height="9" rx="2" fill="currentColor" opacity=".62"/></svg>`,
  keys: `<svg viewBox="0 0 64 64" aria-hidden="true"><rect x="8" y="18" width="48" height="28" rx="4" fill="none" stroke="currentColor" stroke-width="2.2"/><rect x="14" y="26" width="8" height="6" rx="1" fill="currentColor" opacity=".45"/><rect x="28" y="26" width="8" height="6" rx="1" fill="currentColor" opacity=".45"/><rect x="42" y="26" width="8" height="6" rx="1" fill="currentColor" opacity=".45"/><rect x="20" y="36" width="24" height="5" rx="1" fill="currentColor" opacity=".3"/></svg>`,
  mirror: `<svg viewBox="0 0 64 64" aria-hidden="true"><rect x="10" y="14" width="44" height="28" rx="3" fill="none" stroke="currentColor" stroke-width="2.2"/><path d="M22 52h20M32 42v10" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/></svg>`,
  stage: `<svg viewBox="0 0 64 64" aria-hidden="true"><rect x="12" y="8" width="40" height="48" rx="4" fill="none" stroke="currentColor" stroke-width="2.2"/><path d="M20 20h24M20 28h18M20 36h20" stroke="currentColor" stroke-width="2" stroke-linecap="round" opacity=".7"/></svg>`,
  bible: `<svg viewBox="0 0 64 64" aria-hidden="true"><path d="M12 12h18c4 0 8 2 8 6v34c0-4-4-6-8-6H12V12zm40 0H34c-4 0-8 2-8 6v34c0-4 4-6 8-6h18V12z" fill="none" stroke="currentColor" stroke-width="2.2"/><path d="M32 18v34" stroke="currentColor" stroke-width="2"/></svg>`,
  music: `<svg viewBox="0 0 64 64" aria-hidden="true"><path d="M22 46V20l22-4v26" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/><circle cx="22" cy="46" r="5.5" fill="currentColor" opacity=".35"/><circle cx="44" cy="42" r="5.5" fill="currentColor" opacity=".5"/></svg>`,
  library: `<svg viewBox="0 0 64 64" aria-hidden="true"><rect x="10" y="14" width="18" height="36" rx="2" fill="currentColor" opacity=".18" stroke="currentColor" stroke-width="2"/><rect x="36" y="14" width="18" height="36" rx="2" fill="none" stroke="currentColor" stroke-width="2"/></svg>`,
  extras: `<svg viewBox="0 0 64 64" aria-hidden="true"><circle cx="32" cy="34" r="16" fill="none" stroke="currentColor" stroke-width="2.2"/><path d="M32 24v12l8 4" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>`,
  panel: `<svg viewBox="0 0 64 64" aria-hidden="true"><rect x="8" y="12" width="48" height="40" rx="4" fill="none" stroke="currentColor" stroke-width="2.2"/><rect x="8" y="12" width="14" height="40" rx="4" fill="currentColor" opacity=".16"/><rect x="28" y="24" width="22" height="5" rx="2" fill="currentColor" opacity=".35"/><rect x="28" y="36" width="16" height="5" rx="2" fill="currentColor" opacity=".22"/></svg>`,
  done: `<svg viewBox="0 0 64 64" aria-hidden="true"><circle cx="32" cy="32" r="20" fill="none" stroke="currentColor" stroke-width="2.2"/><path d="M21 33l7 7 15-16" fill="none" stroke="currentColor" stroke-width="2.8" stroke-linecap="round" stroke-linejoin="round"/></svg>`,
};

/** Passos curtos, linguagem do culto — sem jargão técnico. */
const STEPS = [
  {
    section: 'Começar',
    icon: 'welcome',
    title: 'Bem-vindo ao culto',
    body: 'Este passeio rápido mostra onde fica cada coisa no <strong>Controle</strong>. Leva poucos minutos. Depois, use a tecla <kbd>?</kbd> sempre que quiser repetir.',
    target: null,
  },
  {
    section: 'Começar',
    icon: 'windows',
    title: 'Duas janelas, duas funções',
    body: 'O <strong>Painel</strong> (ao abrir o SOMOSUM) cuida da igreja neste PC: rede, monitores e cópia de segurança. O <strong>Controle</strong> — esta tela — é onde você monta e conduz o culto.',
    target: null,
    finishCentered: true,
  },
  {
    section: 'Orientação',
    icon: 'sidebar',
    title: 'Menu da esquerda',
    body: 'Aqui você troca de área: <strong>Ao vivo</strong>, Louvores, Bíblia, Mídia, Cultos, Designer e Ajustes. Durante o culto, fique em <strong>Ao vivo</strong>.',
    target: '#sidebar',
    view: 'live',
  },
  {
    section: 'Culto',
    icon: 'live',
    title: 'Tela Ao vivo',
    body: 'É o posto de comando: à esquerda a <strong>ordem do culto</strong>, no centro o que está no projetor e a sequência de slides, à direita os botões do momento.',
    target: '#live-console-root',
    view: 'live',
  },
  {
    section: 'Culto',
    icon: 'ordem',
    title: 'Ordem do culto',
    body: 'Monte a lista do culto: louvores, bíblia, mensagem, avisos… Arraste para reordenar. Toque em um item para trabalhar nele.',
    target: '#lc-ordem-list, #rundown, .lc-ordem',
    view: 'live',
  },
  {
    section: 'Culto',
    icon: 'keys',
    title: 'Avançar slides',
    body: 'Na sequência, clique no próximo slide — ou use o teclado: <kbd>←</kbd> <kbd>→</kbd> ou <kbd>Espaço</kbd>. <kbd>B</kbd> deixa a tela preta · <kbd>L</kbd> mostra o logo.',
    target: '#lc-sequence-blocks, #live-monitor-stack',
    view: 'live',
  },
  {
    section: 'Culto',
    icon: 'mirror',
    title: 'O que a igreja está vendo',
    body: 'A prévia no centro espelha o projetor. Confira aqui antes de avançar — assim você não “surpreende” a congregação.',
    target: '#live-monitor-stack, #stage-preview',
    view: 'live',
  },
  {
    section: 'Culto',
    icon: 'stage',
    title: 'Tela do pregador (Púlpito)',
    body: 'No menu <strong>Janelas</strong> ou na Central Stage, abra o <strong>Púlpito</strong> no monitor de retorno. É a tela de confiança do pregador — não é o projetor da igreja.',
    target: null,
    view: 'live',
    finishCentered: true,
  },
  {
    section: 'Bibliotecas',
    icon: 'bible',
    title: 'Bíblia',
    body: 'Inclua um item Bíblia na ordem, escolha a passagem e avance os versículos como slides. As traduções já vêm no SOMOSUM — sem internet.',
    target: '[data-view="bible"]',
    view: 'bible',
  },
  {
    section: 'Bibliotecas',
    icon: 'music',
    title: 'Louvores e mídia',
    body: 'No menu lateral: letras de louvor e arquivos de mídia. Adicione à ordem ou projete na hora. Seus louvores ficam salvos neste computador.',
    target: '[data-view="lyrics"]',
    view: 'lyrics',
  },
  {
    section: 'Bibliotecas',
    icon: 'library',
    title: 'Cultos e Designer',
    body: 'Em <strong>Cultos</strong>, organize por data e reaproveite ordens. No <strong>Designer</strong>, monte capas e avisos personalizados para entrar na ordem.',
    target: '[data-view="cultos"]',
    view: 'cultos',
  },
  {
    section: 'Extras',
    icon: 'extras',
    title: 'Antes do culto começar',
    body: '<strong>Pré-culto</strong> mostra contagem na projeção. <strong>Fundo</strong> toca música neste PC (não no projetor). Úteis nos minutos finais antes do início.',
    target: '#btn-countdown',
    view: 'live',
  },
  {
    section: 'Extras',
    icon: 'panel',
    title: 'Plugins, Loja e Ajustes',
    body: 'Extras do culto: ative em <strong>Ajustes → Plugins</strong> ou pela <strong>Loja</strong> no Painel. Em Ajustes também ficam igreja, atalhos e preferências do operador.',
    target: '[data-view="settings"]',
    view: 'settings',
    finishCentered: true,
  },
  {
    section: 'Pronto',
    icon: 'panel',
    title: 'Volte ao Painel quando precisar',
    body: 'Rede Wi‑Fi, monitores, cópia de segurança e versão ficam no <strong>Painel</strong>. Manual completo: tecla <kbd>D</kbd>. Mapa de onde resolver cada coisa: Painel → <strong>Sobre</strong>.',
    target: null,
    finishCentered: true,
  },
  {
    section: 'Pronto',
    icon: 'done',
    title: 'Pronto — bom culto!',
    body: 'Reabra este passeio em <strong>Ajuda → Tour guiado</strong>, em Ajustes → Sistema, ou com <kbd>?</kbd>. Estamos com você no culto.',
    target: null,
    view: 'live',
    finishCentered: true,
  },
];

let _step = 0;
let _appRef = null;
let _generation = 0;
let _active = false;
let _rafIds = [];
let _keyHandler = null;

function ensureStyles() {
  if (document.getElementById('somosum-tour-styles')) return;
  const s = document.createElement('style');
  s.id = 'somosum-tour-styles';
  s.textContent = `
    .somosum-tour-backdrop {
      position: fixed; inset: 0; z-index: 999998;
      background: rgba(10, 9, 8, .48);
      pointer-events: none;
      animation: somosum-tour-fade .25s ease;
    }
    .somosum-tour-highlight {
      position: fixed; z-index: 999999;
      border-radius: 12px;
      pointer-events: none;
      box-shadow: 0 0 0 9999px rgba(10,9,8,.48), 0 0 0 1.5px rgba(212,198,141,.85);
      transition: top .25s ease, left .25s ease, width .25s ease, height .25s ease;
    }
    .somosum-tour-card {
      position: fixed; z-index: 1000000;
      width: min(400px, calc(100vw - 28px));
      background: #141210;
      border: 1px solid rgba(212,198,141,.22);
      border-radius: 18px;
      padding: 0;
      color: #f3efe6;
      font-family: "Segoe UI", system-ui, sans-serif;
      box-shadow: 0 18px 48px rgba(0,0,0,.42);
      animation: somosum-tour-pop .28s ease;
      overflow: hidden;
    }
    .somosum-tour-card-inner { padding: 1.05rem 1.15rem 1.05rem; }
    .somosum-tour-progress {
      height: 2px; background: rgba(255,255,255,.05);
    }
    .somosum-tour-progress > i {
      display: block; height: 100%;
      background: #d4c68d;
      transition: width .3s ease;
    }
    .somosum-tour-meta {
      display: flex; align-items: center; justify-content: space-between;
      gap: .5rem; margin-bottom: .7rem;
    }
    .somosum-tour-section {
      font-size: .65rem; letter-spacing: .12em; text-transform: uppercase;
      color: rgba(212,198,141,.7); font-weight: 650;
    }
    .somosum-tour-step {
      font-size: .72rem; color: rgba(243,239,230,.38); font-variant-numeric: tabular-nums;
    }
    .somosum-tour-hero {
      display: flex; gap: .85rem; align-items: flex-start; margin-bottom: .15rem;
    }
    .somosum-tour-illust {
      flex: 0 0 46px; width: 46px; height: 46px;
      border-radius: 12px;
      background: rgba(212,198,141,.08);
      border: 1px solid rgba(212,198,141,.16);
      color: #d4c68d;
      display: grid; place-items: center;
    }
    .somosum-tour-illust svg { width: 28px; height: 28px; }
    .somosum-tour-card h3 {
      margin: 0 0 .4rem; color: #f7f2e8; font-size: 1.05rem; font-weight: 650;
      line-height: 1.3; letter-spacing: -.01em;
    }
    .somosum-tour-card p {
      margin: 0; line-height: 1.55; font-size: .88rem; color: rgba(243,239,230,.7);
    }
    .somosum-tour-card p strong { color: #f7f2e8; font-weight: 650; }
    .somosum-tour-card p kbd {
      background: rgba(0,0,0,.35);
      padding: .1rem .35rem; border-radius: 5px;
      font-size: .8em; color: #d4c68d;
      font-family: "Segoe UI", system-ui, sans-serif; font-weight: 650;
      border: 1px solid rgba(212,198,141,.14);
    }
    .somosum-tour-actions {
      display: flex; gap: .4rem; justify-content: space-between;
      align-items: center; flex-wrap: wrap; margin-top: 1rem;
    }
    .somosum-tour-actions-right { display: flex; gap: .4rem; margin-left: auto; }
    .somosum-tour-actions button {
      border: none; border-radius: 10px; padding: .5rem .95rem;
      cursor: pointer; font-size: .86rem; transition: background .15s, color .15s, opacity .15s;
    }
    .somosum-tour-skip { background: transparent; color: rgba(243,239,230,.4); }
    .somosum-tour-skip:hover { color: rgba(243,239,230,.7); }
    .somosum-tour-prev {
      background: rgba(255,255,255,.05); color: rgba(243,239,230,.85);
      border: 1px solid rgba(255,255,255,.07) !important;
    }
    .somosum-tour-prev:hover { background: rgba(255,255,255,.08); }
    .somosum-tour-prev:disabled { opacity: .3; cursor: default; }
    .somosum-tour-next {
      background: #d4c68d;
      color: #1a1612; font-weight: 650;
    }
    .somosum-tour-next:hover { filter: brightness(1.04); }
    .somosum-tour-hint {
      margin-top: .55rem; font-size: .7rem; color: rgba(243,239,230,.32);
      text-align: center;
    }
    @keyframes somosum-tour-fade { from { opacity: 0 } to { opacity: 1 } }
    @keyframes somosum-tour-pop {
      from { opacity: 0; transform: translate(-50%, -48%) scale(.98) }
      to { opacity: 1; transform: translate(-50%, -50%) scale(1) }
    }
    @media (max-width: 520px) {
      .somosum-tour-hero { flex-direction: column; align-items: center; text-align: center; }
      .somosum-tour-actions { flex-direction: column; align-items: stretch; }
      .somosum-tour-actions-right { margin-left: 0; width: 100%; }
      .somosum-tour-actions-right button { flex: 1; }
    }
  `;
  document.head.appendChild(s);
}

function cancelPendingFrames() {
  for (const id of _rafIds) {
    try { cancelAnimationFrame(id); } catch { /* ignore */ }
  }
  _rafIds = [];
}

function scheduleFrame(fn) {
  const id = requestAnimationFrame(fn);
  _rafIds.push(id);
  return id;
}

function detachKeyHandler() {
  if (_keyHandler) {
    window.removeEventListener('keydown', _keyHandler, true);
    _keyHandler = null;
  }
}

function removeTourUi() {
  cancelPendingFrames();
  document.querySelectorAll('.somosum-tour-backdrop,.somosum-tour-highlight,.somosum-tour-card').forEach((el) => el.remove());
}

function finishTour({ restoreView = true } = {}) {
  _active = false;
  _generation += 1;
  cancelPendingFrames();
  detachKeyHandler();
  localStorage.setItem(STORAGE_KEY, '1');
  removeTourUi();
  if (restoreView && _appRef) {
    _appRef.view = 'live';
    _appRef.renderNav?.();
    _appRef.renderView?.();
    _appRef.toast?.('Tour concluído — bom culto!', 'success');
  }
}

function goNext(gen) {
  if (!_active || gen !== _generation) return;
  _step += 1;
  if (_step >= STEPS.length) {
    finishTour();
    return;
  }
  renderStep();
}

function goPrev(gen) {
  if (!_active || gen !== _generation) return;
  if (_step <= 0) return;
  _step -= 1;
  renderStep();
}

function positionHighlight(el, card, gen) {
  if (!_active || gen !== _generation) return;
  document.querySelectorAll('.somosum-tour-highlight').forEach((n) => n.remove());

  const hl = document.createElement('div');
  hl.className = 'somosum-tour-highlight';
  document.body.appendChild(hl);

  const pad = 8;
  const r = el.getBoundingClientRect();
  hl.style.left = `${r.left - pad}px`;
  hl.style.top = `${r.top - pad}px`;
  hl.style.width = `${Math.max(8, r.width + pad * 2)}px`;
  hl.style.height = `${Math.max(8, r.height + pad * 2)}px`;

  const cr = card.getBoundingClientRect();
  let top = r.bottom + 14;
  let left = Math.min(r.left, window.innerWidth - cr.width - 16);
  if (top + cr.height > window.innerHeight - 16) top = Math.max(16, r.top - cr.height - 14);
  if (left < 16) left = 16;
  card.style.top = `${top}px`;
  card.style.left = `${left}px`;
  card.style.transform = '';
}

function centerCard(card) {
  card.style.top = '50%';
  card.style.left = '50%';
  card.style.transform = 'translate(-50%, -50%)';
  const bd = document.createElement('div');
  bd.className = 'somosum-tour-backdrop';
  document.body.insertBefore(bd, card);
}

function attachKeyHandler(gen) {
  detachKeyHandler();
  _keyHandler = (event) => {
    if (!_active || gen !== _generation) return;
    const tag = event.target?.tagName?.toLowerCase();
    if (tag === 'input' || tag === 'textarea' || tag === 'select') return;

    if (event.key === 'Escape') {
      event.preventDefault();
      event.stopPropagation();
      finishTour();
      return;
    }
    if (event.key === 'ArrowRight' || event.key === 'Enter') {
      event.preventDefault();
      event.stopPropagation();
      goNext(gen);
      return;
    }
    if (event.key === 'ArrowLeft') {
      event.preventDefault();
      event.stopPropagation();
      goPrev(gen);
    }
  };
  window.addEventListener('keydown', _keyHandler, true);
}

function renderStep() {
  if (!_active) return;
  const gen = _generation;
  removeTourUi();
  ensureStyles();
  attachKeyHandler(gen);

  const step = STEPS[_step];
  if (!step) {
    finishTour();
    return;
  }

  if (step.view && _appRef) {
    _appRef.view = step.view;
    _appRef.renderNav?.();
    _appRef.renderView?.();
  }

  const pct = Math.round(((_step + 1) / STEPS.length) * 100);
  const iconSvg = ICONS[step.icon] || ICONS.welcome;
  const isLast = _step >= STEPS.length - 1;
  const isFirst = _step === 0;

  const card = document.createElement('div');
  card.className = 'somosum-tour-card';
  card.setAttribute('role', 'dialog');
  card.setAttribute('aria-label', `Tour: ${step.title}`);
  card.innerHTML = `
    <div class="somosum-tour-progress" aria-hidden="true"><i style="width:${pct}%"></i></div>
    <div class="somosum-tour-card-inner">
      <div class="somosum-tour-meta">
        <span class="somosum-tour-section">${step.section || 'Tour'}</span>
        <span class="somosum-tour-step">${_step + 1} de ${STEPS.length}</span>
      </div>
      <div class="somosum-tour-hero">
        <div class="somosum-tour-illust">${iconSvg}</div>
        <div>
          <h3>${step.title}</h3>
          <p>${step.body}</p>
        </div>
      </div>
      <div class="somosum-tour-actions">
        <button type="button" class="somosum-tour-skip" data-act="skip">Pular</button>
        <div class="somosum-tour-actions-right">
          <button type="button" class="somosum-tour-prev" data-act="prev"${isFirst ? ' disabled' : ''}>Voltar</button>
          <button type="button" class="somosum-tour-next" data-act="next">${isLast ? 'Concluir' : 'Continuar'}</button>
        </div>
      </div>
      <p class="somosum-tour-hint">Setas para navegar · Esc para sair · ? reabre o tour</p>
    </div>`;
  document.body.appendChild(card);

  card.querySelector('[data-act="skip"]')?.addEventListener('click', () => finishTour());
  card.querySelector('[data-act="prev"]')?.addEventListener('click', () => goPrev(gen));
  card.querySelector('[data-act="next"]')?.addEventListener('click', () => goNext(gen));

  const resolveTarget = () => {
    if (!_active || gen !== _generation) return;
    if (step.finishCentered || !step.target) {
      centerCard(card);
      return;
    }
    const target = document.querySelector(step.target);
    if (target) {
      target.scrollIntoView?.({ block: 'nearest', behavior: 'smooth' });
      scheduleFrame(() => {
        if (!_active || gen !== _generation) return;
        positionHighlight(target, card, gen);
      });
    } else {
      centerCard(card);
    }
  };

  if (step.view && _appRef) {
    scheduleFrame(() => scheduleFrame(resolveTarget));
  } else {
    resolveTarget();
  }
}

export function startTour(app) {
  if (app) _appRef = app;
  _generation += 1;
  cancelPendingFrames();
  detachKeyHandler();
  removeTourUi();
  _active = true;
  _step = 0;
  renderStep();
}

export function resetTour() {
  for (let v = 2; v <= TOUR_MAX_LEGACY; v += 1) {
    localStorage.removeItem(`somosum.tour.v${v}.done`);
  }
  localStorage.removeItem('somosum.welcome.v2.done');
}

export function maybeStartTour(app) {
  _appRef = app;
  if (localStorage.getItem(STORAGE_KEY)) return;
  if (!localStorage.getItem('somosum.welcome.v2.done')) return;
  setTimeout(() => startTour(app), 400);
}

export function bindTourButton(app) {
  document.getElementById('btn-tour')?.addEventListener('click', () => startTour(app));
}
