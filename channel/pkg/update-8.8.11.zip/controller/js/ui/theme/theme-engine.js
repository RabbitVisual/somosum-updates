/**
 * AtmosphereEngine — atmosferas litúrgicas só na projeção / prévia.
 * Controle / Painel / Stage chrome permanecem Dark Studio (sem --color-* no <html>).
 */
import {
  ATMOSPHERES,
  getAtmosphere,
  listPickerAtmospheres,
  normalizeAtmosphereId,
  resolveLiveAtmosphereId,
  resolvePrefsAtmosphereId,
} from './atmospheres.js';

const CHROME_TOKEN_KEYS = [
  '--color-bg', '--color-bg-soft', '--color-bg-panel', '--color-bg-elevated',
  '--color-gold', '--color-gold-dim', '--color-gold-glow', '--color-gold-line',
  '--color-accent', '--color-white', '--color-ink', '--color-muted',
  '--color-border', '--color-border-strong',
  '--color-hover', '--color-pressed', '--color-focus-ring',
  '--gradient-slide',
];

const PROJ_TOKEN_KEYS = [
  '--proj-accent', '--proj-bg', '--proj-bg-soft', '--proj-ink', '--proj-muted',
  '--proj-overlay', '--proj-gradient', '--proj-gold',
  '--atm-accent', '--atm-bg', '--atm-ink',
];

const listeners = new Set();
let activeId = 'somos-um';

/** Compat: THEMES espelha ATMOSPHERES (nome + vars para swatches do Settings). */
export const THEMES = Object.fromEntries(
  Object.entries(ATMOSPHERES).map(([id, atm]) => [id, {
    name: atm.name,
    canonical: atm.id,
    vars: { ...(atm.bridge || {}), ...(atm.vars || {}) },
  }]),
);
// Aliases legados apontam para a mesma definição
THEMES.communion = THEMES.ceia;
THEMES.dark = THEMES['somos-um'];
THEMES.midnight = THEMES['somos-um'];
THEMES.light = THEMES['somos-um'];
THEMES.pure = THEMES['somos-um'];
THEMES.ember = THEMES.celebracao;
THEMES.forest = THEMES.ebd;
THEMES.royal = THEMES.adolescentes;
function isProjectionSurface() {
  try {
    const path = String(typeof location !== 'undefined' ? (location.pathname || location.href || '') : '');
    if (/screen\.html/i.test(path)) return true;
  } catch { /* non-browser */ }
  if (typeof document === 'undefined') return false;
  const surface = document.body?.dataset?.surface || document.documentElement?.dataset?.surface;
  return surface === 'screen';
}

function clearInlineTokens(el, keys) {
  if (!el?.style) return;
  keys.forEach((k) => el.style.removeProperty(k));
}

/** Remove poluição legada de temas no chrome do operador. */
function scrubOperatorChrome() {
  if (typeof document === 'undefined') return;
  const root = document.documentElement;
  clearInlineTokens(root, CHROME_TOKEN_KEYS);
  clearInlineTokens(root, PROJ_TOKEN_KEYS);
  delete root.dataset.projectionTheme;
  // Dark Studio permanece via applyUiPrefs; não gravar id de atmosfera em data-theme
  if (root.dataset.theme && root.dataset.theme !== 'dark-studio' && !isProjectionSurface()) {
    root.dataset.theme = 'dark-studio';
  }
}

/**
 * Pinta atmosfera num nó de projeção (Screen root ou prévia 16:9).
 * @param {Element} el
 * @param {string} themeId
 */
export function paintAtmosphere(el, themeId) {
  if (!el) return null;
  const id = normalizeAtmosphereId(themeId);
  const atm = getAtmosphere(id);
  el.dataset.projectionTheme = id;
  Object.entries(atm.vars || {}).forEach(([key, val]) => el.style.setProperty(key, val));
  Object.entries(atm.bridge || {}).forEach(([key, val]) => el.style.setProperty(key, val));
  return atm;
}

function findPreviewRoots() {
  const roots = [];
  const scaler = document.getElementById('preview-scaler');
  if (scaler) roots.push(scaler);
  document.querySelectorAll('.lyrics-preview-scaler .screen-viewport, #stage-preview .preview-scaler').forEach((n) => {
    if (!roots.includes(n)) roots.push(n);
  });
  return roots;
}

function findScreenRoot() {
  return document.getElementById('screen-root') || document.querySelector('.screen-viewport') || document.documentElement;
}

function notify(themeId, atm) {
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new CustomEvent('somosum-theme-change', { detail: { id: themeId, theme: atm, atmosphere: atm } }));
  }
  listeners.forEach((fn) => { try { fn(themeId, atm); } catch { /* */ } });
}

export const ThemeEngine = {
  /**
   * Aplica atmosfera litúrgica.
   * - Screen: no #screen-root
   * - Controle: limpa chrome + pinta prévias; não mexe em --color-* do operador
   * - targetEl opcional: força um nó
   */
  apply(themeId, targetEl = null) {
    const id = normalizeAtmosphereId(themeId);
    const atm = getAtmosphere(id);
    activeId = id;

    if (targetEl) {
      paintAtmosphere(targetEl, id);
      notify(id, atm);
      return atm;
    }

    if (isProjectionSurface()) {
      if (typeof document === 'undefined') {
        notify(id, atm);
        return atm;
      }
      const root = findScreenRoot();
      paintAtmosphere(root, id);
      // Screen: também no documentElement para CSS global de slides que leem :root
      if (root !== document.documentElement) {
        paintAtmosphere(document.documentElement, id);
      }
      notify(id, atm);
      return atm;
    }

    // Operador (Controle / Stage chrome / Painel)
    scrubOperatorChrome();
    if (typeof document !== 'undefined') {
      findPreviewRoots().forEach((el) => paintAtmosphere(el, id));
    }
    notify(id, atm);
    return atm;
  },

  applyTo(el, themeId) {
    const id = normalizeAtmosphereId(themeId);
    const atm = paintAtmosphere(el, id);
    if (atm) activeId = id;
    return atm;
  },

  register(id, def) {
    ATMOSPHERES[id] = {
      id,
      name: def.name || id,
      picker: def.picker,
      a11y: def.a11y,
      vars: def.vars || {},
      bridge: def.bridge || def.vars || {},
      swatch: def.swatch,
    };
  },

  subscribe(fn) {
    listeners.add(fn);
    return () => listeners.delete(fn);
  },

  getActiveId() {
    return activeId;
  },

  getThemeList() {
    return listPickerAtmospheres().map((a) => ({ id: a.id, name: a.name, swatch: a.swatch, a11y: a.a11y }));
  },

  snapshot() {
    const root = getComputedStyle(document.documentElement);
    const tokens = {};
    PROJ_TOKEN_KEYS.forEach((k) => { tokens[k] = root.getPropertyValue(k).trim(); });
    return { activeId, tokens };
  },
};

export const AtmosphereEngine = ThemeEngine;

export function applyTheme(themeId, targetEl = null) {
  return ThemeEngine.apply(themeId, targetEl);
}

export function applyAtmosphere(themeId, targetEl = null) {
  return ThemeEngine.apply(themeId, targetEl);
}

export function getThemeList() {
  return ThemeEngine.getThemeList();
}

export {
  ATMOSPHERES,
  getAtmosphere,
  listPickerAtmospheres,
  normalizeAtmosphereId,
  resolveLiveAtmosphereId,
  resolvePrefsAtmosphereId,
};
