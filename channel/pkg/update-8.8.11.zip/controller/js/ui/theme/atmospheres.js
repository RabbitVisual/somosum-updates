/**
 * Atmosferas litúrgicas — SSOT para projeção (Screen + prévia).
 * Não recoloram o chrome do operador (Dark Studio).
 */

/** @typedef {{ accent: string, bg: string, bgSoft: string, ink: string, muted: string, overlay: string, gradient: string, gold?: string }} ProjPalette */

/**
 * @typedef {object} Atmosphere
 * @property {string} id
 * @property {string} name
 * @property {string} [swatch]
 * @property {boolean} [picker] — aparece no seletor de Settings (default true)
 * @property {boolean} [a11y] — opção de acessibilidade
 * @property {Record<string, string>} vars — --proj-* / --atm-*
 * @property {Record<string, string>} [bridge] — --color-* / --gradient-slide só no nó de projeção
 */

/** @param {ProjPalette} p */
function pack(p) {
  const gold = p.gold || p.accent;
  const vars = {
    '--proj-accent': p.accent,
    '--proj-bg': p.bg,
    '--proj-bg-soft': p.bgSoft,
    '--proj-ink': p.ink,
    '--proj-muted': p.muted,
    '--proj-overlay': p.overlay,
    '--proj-gradient': p.gradient,
    '--proj-gold': gold,
    '--atm-accent': p.accent,
    '--atm-bg': p.bg,
    '--atm-ink': p.ink,
  };
  const bridge = {
    '--color-bg': p.bg,
    '--color-bg-soft': p.bgSoft,
    '--color-bg-panel': p.bgSoft,
    '--color-gold': gold,
    '--color-gold-dim': gold,
    '--color-gold-glow': p.overlay,
    '--color-accent': p.accent,
    '--color-ink': p.ink,
    '--color-muted': p.muted,
    '--color-white': p.ink,
    '--gradient-slide': p.gradient,
  };
  return { vars, bridge };
}

/** @type {Record<string, Atmosphere>} */
export const ATMOSPHERES = {
  'somos-um': {
    id: 'somos-um',
    name: 'SOMOS UM (Ouro)',
    swatch: '#d4c68d',
    ...pack({
      accent: '#e8a54b',
      gold: '#d4c68d',
      bg: '#0a0a0a',
      bgSoft: '#141414',
      ink: '#f3efe6',
      muted: '#9a9a9a',
      overlay: 'rgba(212, 198, 141, 0.28)',
      gradient: 'radial-gradient(ellipse at top, rgba(212,198,141,.15) 0%, #0a0a0a 70%)',
    }),
  },
  ceia: {
    id: 'ceia',
    name: 'Ceia do Senhor',
    swatch: '#d4a853',
    ...pack({
      accent: '#6b1c2a',
      gold: '#d4a853',
      bg: '#0d0608',
      bgSoft: '#1a0c0e',
      ink: '#f5ebe0',
      muted: '#c4b5a8',
      overlay: 'rgba(212, 168, 83, 0.3)',
      gradient: 'radial-gradient(ellipse at 30% 0%, rgba(212,168,83,.15) 0%, transparent 50%), radial-gradient(ellipse at 70% 100%, rgba(107,28,42,.25) 0%, #0d0608 70%)',
    }),
  },
  celebracao: {
    id: 'celebracao',
    name: 'Culto de Celebração',
    swatch: '#d4c68d',
    ...pack({
      accent: '#d4c68d',
      gold: '#d4c68d',
      bg: '#0a0a0a',
      bgSoft: '#16140e',
      ink: '#f3efe6',
      muted: '#a89a78',
      overlay: 'rgba(212, 198, 141, 0.28)',
      gradient: 'radial-gradient(ellipse at top, rgba(212,198,141,.18) 0%, #0a0a0a 68%)',
    }),
  },
  oracao: {
    id: 'oracao',
    name: 'Culto de Oração',
    swatch: '#9db4c8',
    ...pack({
      accent: '#9db4c8',
      gold: '#9db4c8',
      bg: '#070a10',
      bgSoft: '#0e141c',
      ink: '#e8eef4',
      muted: '#8899aa',
      overlay: 'rgba(157, 180, 200, 0.25)',
      gradient: 'radial-gradient(ellipse at top, rgba(157,180,200,.12) 0%, #070a10 72%)',
    }),
  },
  missoes: {
    id: 'missoes',
    name: 'Culto de Missões',
    swatch: '#c4a574',
    ...pack({
      accent: '#c4a574',
      gold: '#c4a574',
      bg: '#0c0a06',
      bgSoft: '#18140c',
      ink: '#f5efe4',
      muted: '#a89878',
      overlay: 'rgba(196, 165, 116, 0.3)',
      gradient: 'radial-gradient(ellipse at top, rgba(196,165,116,.14) 0%, #0c0a06 70%)',
    }),
  },
  ebd: {
    id: 'ebd',
    name: 'EBD',
    swatch: '#8ecf9a',
    ...pack({
      accent: '#6dbd80',
      gold: '#8ecf9a',
      bg: '#060e0a',
      bgSoft: '#0c1812',
      ink: '#f0fff4',
      muted: '#88a898',
      overlay: 'rgba(142, 207, 154, 0.3)',
      gradient: 'radial-gradient(ellipse at top, rgba(109,189,128,.12) 0%, #060e0a 70%)',
    }),
  },
  jovens: {
    id: 'jovens',
    name: 'Jovens',
    swatch: '#f0d78c',
    ...pack({
      accent: '#f0d78c',
      gold: '#f0d78c',
      bg: '#0c0a04',
      bgSoft: '#1a1608',
      ink: '#fff8e8',
      muted: '#b8a878',
      overlay: 'rgba(240, 215, 140, 0.4)',
      gradient: 'radial-gradient(ellipse at 40% 0%, rgba(240,215,140,.22) 0%, #0c0a04 65%)',
    }),
  },
  adolescentes: {
    id: 'adolescentes',
    name: 'Adolescentes',
    swatch: '#a855f7',
    ...pack({
      accent: '#a855f7',
      gold: '#c9a0ff',
      bg: '#0a0612',
      bgSoft: '#120c1a',
      ink: '#f5f0ff',
      muted: '#9988b3',
      overlay: 'rgba(201, 160, 255, 0.35)',
      gradient: 'radial-gradient(ellipse at top, rgba(168,85,247,.14) 0%, #0a0612 70%)',
    }),
  },
  criancas: {
    id: 'criancas',
    name: 'Crianças',
    swatch: '#7ec8e3',
    ...pack({
      accent: '#7ec8e3',
      gold: '#7ec8e3',
      bg: '#061018',
      bgSoft: '#0c1c28',
      ink: '#f0faff',
      muted: '#88a8b8',
      overlay: 'rgba(126, 200, 227, 0.35)',
      gradient: 'radial-gradient(ellipse at top, rgba(126,200,227,.18) 0%, #061018 68%)',
    }),
  },
  mulheres: {
    id: 'mulheres',
    name: 'Mulheres',
    swatch: '#e8b4b8',
    ...pack({
      accent: '#e8b4b8',
      gold: '#e8b4b8',
      bg: '#12080c',
      bgSoft: '#1e1014',
      ink: '#fff5f6',
      muted: '#b8989a',
      overlay: 'rgba(232, 180, 184, 0.32)',
      gradient: 'radial-gradient(ellipse at top, rgba(232,180,184,.16) 0%, #12080c 70%)',
    }),
  },
  homens: {
    id: 'homens',
    name: 'Homens',
    swatch: '#7a9cc6',
    picker: false,
    ...pack({
      accent: '#7a9cc6',
      gold: '#7a9cc6',
      bg: '#060a12',
      bgSoft: '#0e1420',
      ink: '#eef2f8',
      muted: '#8899ad',
      overlay: 'rgba(122, 156, 198, 0.28)',
      gradient: 'radial-gradient(ellipse at top, rgba(122,156,198,.14) 0%, #060a12 70%)',
    }),
  },
  especial: {
    id: 'especial',
    name: 'Especial',
    swatch: '#d4c68d',
    picker: false,
    ...pack({
      accent: '#d4c68d',
      gold: '#d4c68d',
      bg: '#0a0a0a',
      bgSoft: '#16140e',
      ink: '#f3efe6',
      muted: '#a89a78',
      overlay: 'rgba(212, 198, 141, 0.32)',
      gradient: 'radial-gradient(ellipse at top, rgba(212,198,141,.2) 0%, #0a0a0a 68%)',
    }),
  },
  aniversario: {
    id: 'aniversario',
    name: 'Aniversário',
    swatch: '#e8c97a',
    picker: false,
    ...pack({
      accent: '#e8c97a',
      gold: '#e8c97a',
      bg: '#100c04',
      bgSoft: '#1c1608',
      ink: '#fff8e8',
      muted: '#b8a878',
      overlay: 'rgba(232, 201, 122, 0.35)',
      gradient: 'radial-gradient(ellipse at top, rgba(232,201,122,.2) 0%, #100c04 68%)',
    }),
  },
  'high-contrast': {
    id: 'high-contrast',
    name: 'Alto contraste',
    swatch: '#ffffff',
    a11y: true,
    ...pack({
      accent: '#ffffff',
      gold: '#f0e6b0',
      bg: '#000000',
      bgSoft: '#0a0a0a',
      ink: '#ffffff',
      muted: '#cccccc',
      overlay: 'rgba(255, 255, 255, 0.2)',
      gradient: 'linear-gradient(#000, #111)',
    }),
  },
};

/** Aliases legados (paletas genéricas / sync antigo) → atmosfera litúrgica */
export const ATMOSPHERE_ALIASES = {
  communion: 'ceia',
  ceia: 'ceia',
  dark: 'somos-um',
  midnight: 'somos-um',
  light: 'somos-um',
  pure: 'somos-um',
  ember: 'celebracao',
  forest: 'ebd',
  royal: 'adolescentes',
  domingo: 'celebracao',
  quarta: 'oracao',
};

export function normalizeAtmosphereId(raw) {
  const id = String(raw || 'somos-um').trim().toLowerCase();
  if (ATMOSPHERES[id]) return id;
  if (ATMOSPHERE_ALIASES[id]) return ATMOSPHERE_ALIASES[id];
  return 'somos-um';
}

export function getAtmosphere(id) {
  const nid = normalizeAtmosphereId(id);
  return ATMOSPHERES[nid] || ATMOSPHERES['somos-um'];
}

/** Lista para o picker de Settings (litúrgicos + a11y). */
export function listPickerAtmospheres() {
  return Object.values(ATMOSPHERES)
    .filter((a) => a.picker !== false)
    .map((a) => ({ id: a.id, name: a.name, swatch: a.swatch || a.vars['--proj-accent'], a11y: !!a.a11y }));
}

/** Preferência efetiva: projectionTheme → theme legado. */
export function resolvePrefsAtmosphereId(prefs) {
  return normalizeAtmosphereId(prefs?.projectionTheme || prefs?.theme || 'somos-um');
}

/** Tema enviado à Screen (Ceia no ar força ceia). */
export function resolveLiveAtmosphereId(prefs, slide) {
  if (slide?.type === 'communion' && slide.useCommunionTheme !== false) return 'ceia';
  return resolvePrefsAtmosphereId(prefs);
}
