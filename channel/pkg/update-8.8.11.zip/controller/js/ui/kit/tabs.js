/** SOMOSUM UI Kit — tabs helper */
export function mountTabs(root, { tabs = [], active = 0, onChange } = {}) {
  if (!root) return null;
  root.classList.add('su-tabs');
  root.setAttribute('role', 'tablist');
  root.innerHTML = tabs.map((t, i) =>
    `<button type="button" class="su-tabs__btn${i === active ? ' is-active' : ''}" role="tab" aria-selected="${i === active}" data-tab="${t.id || i}">${t.label}</button>`
  ).join('');

  const setActive = (id) => {
    root.querySelectorAll('.su-tabs__btn').forEach((btn) => {
      const on = btn.dataset.tab === String(id);
      btn.classList.toggle('is-active', on);
      btn.setAttribute('aria-selected', on ? 'true' : 'false');
    });
    onChange?.(id);
  };

  root.addEventListener('click', (e) => {
    const btn = e.target.closest('.su-tabs__btn');
    if (!btn) return;
    setActive(btn.dataset.tab);
  });

  return { setActive, root };
}
