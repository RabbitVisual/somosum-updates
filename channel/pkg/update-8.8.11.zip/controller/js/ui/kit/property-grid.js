/** SOMOSUM UI Kit — property grid */
export function renderPropertyGrid(host, fields = [], onChange) {
  if (!host) return;
  host.classList.add('su-property-grid');
  host.innerHTML = fields.map((f) => {
    const id = `su-pg-${f.key}`;
    if (f.type === 'checkbox') {
      return `<label for="${id}">${f.label}</label><input class="su-checkbox" type="checkbox" id="${id}" data-key="${f.key}" ${f.value ? 'checked' : ''}/>`;
    }
    if (f.type === 'select') {
      const opts = (f.options || []).map((o) =>
        `<option value="${o.value}" ${String(o.value) === String(f.value) ? 'selected' : ''}>${o.label}</option>`
      ).join('');
      return `<label for="${id}">${f.label}</label><select class="su-select" id="${id}" data-key="${f.key}">${opts}</select>`;
    }
    return `<label for="${id}">${f.label}</label><input class="su-input" type="${f.type || 'text'}" id="${id}" data-key="${f.key}" value="${f.value ?? ''}"/>`;
  }).join('');

  host.onchange = (e) => {
    const t = e.target;
    const key = t.dataset?.key;
    if (!key) return;
    const value = t.type === 'checkbox' ? t.checked : t.value;
    onChange?.(key, value, t);
  };
}
