/**
 * Lista virtual com object pool (U3-B) — reutiliza nós DOM no scroll.
 * @param {HTMLElement} host
 * @param {{
 *   items: any[],
 *   rowHeight?: number,
 *   renderRow: (item, index) => string|HTMLElement,
 *   updateRow?: (el: HTMLElement, item: any, index: number) => void,
 *   pool?: boolean
 * }} opts
 */
export function mountVirtualList(host, {
  items = [],
  rowHeight = 40,
  renderRow,
  updateRow = null,
  pool = true,
} = {}) {
  if (!host || typeof renderRow !== 'function') return { dispose() {} };

  host.classList.add('su-virtual-list');
  host.style.overflow = 'auto';
  host.style.position = 'relative';

  const spacer = document.createElement('div');
  spacer.className = 'su-virtual-list__spacer';
  const windowEl = document.createElement('div');
  windowEl.className = 'su-virtual-list__window';
  windowEl.style.position = 'absolute';
  windowEl.style.left = '0';
  windowEl.style.right = '0';
  host.innerHTML = '';
  host.appendChild(spacer);
  host.appendChild(windowEl);

  /** @type {HTMLElement[]} */
  const rowPool = [];
  let disposed = false;

  const acquireRow = () => {
    const el = rowPool.pop() || document.createElement('div');
    el.className = 'su-virtual-list__row';
    el.style.height = `${rowHeight}px`;
    el.style.display = '';
    return el;
  };

  const releaseRows = (els) => {
    for (const el of els) {
      el.remove();
      if (pool && rowPool.length < 80) {
        el.innerHTML = '';
        rowPool.push(el);
      }
    }
  };

  const paint = () => {
    if (disposed) return;
    const total = items.length;
    spacer.style.height = `${total * rowHeight}px`;
    const scrollTop = host.scrollTop;
    const viewH = host.clientHeight || 400;
    const start = Math.max(0, Math.floor(scrollTop / rowHeight) - 4);
    const end = Math.min(total, Math.ceil((scrollTop + viewH) / rowHeight) + 4);
    windowEl.style.top = `${start * rowHeight}px`;

    const prev = [...windowEl.children];
    releaseRows(prev);

    const frag = document.createDocumentFragment();
    for (let i = start; i < end; i++) {
      const rowContent = renderRow(items[i], i);
      let rowEl;
      if (typeof rowContent === 'string') {
        rowEl = acquireRow();
        if (typeof updateRow === 'function' && rowEl.dataset.poolIndex != null) {
          updateRow(rowEl, items[i], i);
        } else {
          rowEl.innerHTML = rowContent;
        }
        rowEl.dataset.index = String(i);
      } else if (rowContent instanceof HTMLElement) {
        rowEl = rowContent;
        rowEl.classList.add('su-virtual-list__row');
        rowEl.style.height = `${rowHeight}px`;
        rowEl.dataset.index = String(i);
      } else {
        continue;
      }
      frag.appendChild(rowEl);
    }
    windowEl.appendChild(frag);
  };

  host.addEventListener('scroll', paint, { passive: true });
  paint();

  return {
    refresh(nextItems) {
      if (Array.isArray(nextItems)) items = nextItems;
      paint();
    },
    repaintSelection(selectedId, itemSelector = '.worship-song-item', activeClass = 'is-active') {
      if (disposed || selectedId == null) return;
      for (const row of windowEl.children) {
        const idx = Number(row.dataset.index);
        const item = items[idx];
        const inner = row.querySelector(itemSelector);
        if (inner && item) inner.classList.toggle(activeClass, item.id === selectedId);
      }
    },
    dispose() {
      disposed = true;
      host.removeEventListener('scroll', paint);
      rowPool.length = 0;
    },
  };
}
