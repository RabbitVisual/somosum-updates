/** SOMOSUM UI Kit — context menu */
let openMenu = null;

export function closeContextMenu() {
  openMenu?.remove();
  openMenu = null;
}

/**
 * @param {number} x
 * @param {number} y
 * @param {{ label: string, action?: () => void, danger?: boolean, sep?: boolean }[]} items
 */
export function openContextMenu(x, y, items = []) {
  closeContextMenu();
  const menu = document.createElement('div');
  menu.className = 'su-context-menu';
  menu.setAttribute('role', 'menu');
  menu.style.left = `${Math.max(8, Math.min(x, window.innerWidth - 200))}px`;
  menu.style.top = `${Math.max(8, Math.min(y, window.innerHeight - 40))}px`;

  for (const item of items) {
    if (item.sep) {
      const sep = document.createElement('div');
      sep.className = 'su-context-menu__sep';
      menu.appendChild(sep);
      continue;
    }
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'su-context-menu__item';
    btn.setAttribute('role', 'menuitem');
    btn.textContent = item.label;
    if (item.danger) btn.style.color = 'var(--color-danger)';
    btn.onclick = () => {
      closeContextMenu();
      item.action?.();
    };
    menu.appendChild(btn);
  }

  document.body.appendChild(menu);
  openMenu = menu;
  const dismiss = (e) => {
    if (!menu.contains(e.target)) {
      closeContextMenu();
      document.removeEventListener('mousedown', dismiss, true);
      document.removeEventListener('keydown', onKey, true);
    }
  };
  const onKey = (e) => {
    if (e.key === 'Escape') {
      closeContextMenu();
      document.removeEventListener('mousedown', dismiss, true);
      document.removeEventListener('keydown', onKey, true);
    }
  };
  setTimeout(() => {
    document.addEventListener('mousedown', dismiss, true);
    document.addEventListener('keydown', onKey, true);
  }, 0);
  return menu;
}

export function bindContextMenu(el, getItems) {
  if (!el) return () => {};
  const handler = (e) => {
    e.preventDefault();
    const items = typeof getItems === 'function' ? getItems(e) : getItems;
    if (items?.length) openContextMenu(e.clientX, e.clientY, items);
  };
  el.addEventListener('contextmenu', handler);
  return () => el.removeEventListener('contextmenu', handler);
}
