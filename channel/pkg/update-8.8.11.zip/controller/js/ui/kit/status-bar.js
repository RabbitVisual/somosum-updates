/** SOMOSUM UI Kit — status bar */
export function mountStatusBar(host, { left = [], right = [] } = {}) {
  if (!host) return null;
  host.className = 'su-status-bar';
  host.id = host.id || 'su-status';
  const renderItem = (it) =>
    `<span class="su-status-bar__item ${it.className || ''}" data-status="${it.id || ''}">${it.html || it.label || ''}</span>`;
  host.innerHTML = [
    ...left.map(renderItem),
    '<span class="su-status-bar__spacer"></span>',
    ...right.map(renderItem),
  ].join('');

  return {
    set(id, html, className = '') {
      const el = host.querySelector(`[data-status="${id}"]`);
      if (!el) return;
      el.innerHTML = html;
      el.className = `su-status-bar__item ${className}`;
    },
    el: host,
  };
}
