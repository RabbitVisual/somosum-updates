/** SOMOSUM UI Kit — dialog / confirm */
import {
  createElement, setText, append, setHtml,
} from '../../core/render-engine/index.js';

function trapFocus(overlay, dialog) {
  const focusables = dialog.querySelectorAll('button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])');
  const first = focusables[0];
  const last = focusables[focusables.length - 1];
  first?.focus();
  const onKey = (e) => {
    if (e.key === 'Escape') {
      overlay.dispatchEvent(new CustomEvent('su-dialog-cancel', { bubbles: true }));
      return;
    }
    if (e.key !== 'Tab' || !focusables.length) return;
    if (e.shiftKey && document.activeElement === first) {
      e.preventDefault();
      last?.focus();
    } else if (!e.shiftKey && document.activeElement === last) {
      e.preventDefault();
      first?.focus();
    }
  };
  overlay.addEventListener('keydown', onKey);
  return () => overlay.removeEventListener('keydown', onKey);
}

function buildConfirmShell({ danger = false } = {}) {
  const overlay = createElement('div', { class: 'su-dialog-overlay' });
  const dialog = createElement('div', {
    class: 'su-dialog',
    role: 'dialog',
    'aria-modal': 'true',
    'aria-labelledby': 'su-dialog-title',
  });
  const titleEl = createElement('h3', { class: 'su-dialog__title', id: 'su-dialog-title' });
  const messageEl = createElement('p', { class: 'su-dialog__message' });
  const actions = createElement('div', { class: 'su-dialog__actions' });
  const cancelBtn = createElement('button', {
    type: 'button',
    class: 'su-btn su-btn--secondary',
    'data-action': 'cancel',
  });
  const confirmBtn = createElement('button', {
    type: 'button',
    class: `su-btn ${danger ? 'su-btn--danger' : 'su-btn--primary'}`,
    'data-action': 'confirm',
  });
  append(actions, cancelBtn, confirmBtn);
  append(dialog, titleEl, messageEl, actions);
  append(overlay, dialog);
  return { overlay, dialog, titleEl, messageEl, cancelBtn, confirmBtn };
}

export function confirmDialog({
  title,
  message,
  confirmLabel = 'Confirmar',
  cancelLabel = 'Cancelar',
  danger = false,
} = {}) {
  return new Promise((resolve) => {
    const {
      overlay, dialog, titleEl, messageEl, cancelBtn, confirmBtn,
    } = buildConfirmShell({ danger });
    setText(titleEl, title || '');
    setText(messageEl, message || '');
    setText(cancelBtn, cancelLabel);
    setText(confirmBtn, confirmLabel);

    let untrap = () => {};
    const close = (val) => {
      untrap();
      overlay.classList.remove('is-visible');
      setTimeout(() => overlay.remove(), 200);
      resolve(val);
    };
    overlay.addEventListener('su-dialog-cancel', () => close(false));
    cancelBtn.onclick = () => close(false);
    confirmBtn.onclick = () => close(true);
    overlay.onclick = (e) => { if (e.target === overlay) close(false); };

    document.body.appendChild(overlay);
    requestAnimationFrame(() => {
      overlay.classList.add('is-visible');
      untrap = trapFocus(overlay, dialog);
    });
  });
}

export function showModal({ title, bodyHtml = '', actions = [] } = {}) {
  return new Promise((resolve) => {
    const overlay = createElement('div', { class: 'su-dialog-overlay' });
    const dialog = createElement('div', {
      class: 'su-dialog su-dialog--wide',
      role: 'dialog',
      'aria-modal': 'true',
    });
    const titleEl = createElement('h3', { class: 'su-dialog__title' });
    setText(titleEl, title || '');
    const bodyEl = createElement('div', { class: 'su-dialog__body' });
    setHtml(bodyEl, bodyHtml, { sanitize: true });
    const actionsEl = createElement('div', { class: 'su-dialog__actions' });
    actions.forEach((a, i) => {
      const btn = createElement('button', {
        type: 'button',
        class: `su-btn ${a.primary ? 'su-btn--primary' : a.danger ? 'su-btn--danger' : 'su-btn--secondary'}`,
        'data-action-idx': String(i),
      });
      setText(btn, a.label || '');
      btn.onclick = () => {
        overlay.classList.remove('is-visible');
        setTimeout(() => overlay.remove(), 200);
        resolve(a.value ?? i);
      };
      append(actionsEl, btn);
    });
    append(dialog, titleEl, bodyEl, actionsEl);
    append(overlay, dialog);
    document.body.appendChild(overlay);
    requestAnimationFrame(() => overlay.classList.add('is-visible'));
  });
}
