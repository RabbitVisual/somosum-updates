/** SOMOSUM UI Kit — preview frame helper */
import { fitStagePreview, observeStagePreviewFit } from '../stage-preview-fit.js';

export function mountPreviewFrame(host, { variant = 'slide' } = {}) {
  if (!host) return null;
  host.className = `su-preview su-preview--${variant}`;
  if (!host.querySelector('.su-preview__stage')) {
    host.innerHTML = `<div class="su-preview__stage" data-preview-stage></div>`;
  }
  const stage = host.querySelector('[data-preview-stage]');
  const fit = () => fitStagePreview?.(stage);
  fit();
  const stop = observeStagePreviewFit?.(host, fit);
  return { stage, fit, dispose: () => stop?.() };
}
