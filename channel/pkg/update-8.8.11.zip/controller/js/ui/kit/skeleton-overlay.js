/**
 * SOMOSUM UI Kit — Skeleton Overlay
 * Anti-ansiedade ao trocar de tela / carregar painéis.
 *
 * O overlay é um portal em document.body (position:fixed sobre o host).
 * Assim main.innerHTML = … não destrói o skeleton no meio da troca.
 *
 * Uso:
 *   import { showSkeletonOverlay, withSkeleton } from './skeleton-overlay.js';
 *   const hide = showSkeletonOverlay(main, { variant: 'program', message: 'Abrindo Programa…' });
 *   // …render…
 *   hide();
 *
 *   await withSkeleton(main, () => loadStuff(), { variant: 'grid' });
 */

const HOST_ATTR = 'data-su-skel-host';
const OVERLAY_KEY = '_suSkelOverlay';
const HIDE_KEY = '_suSkelHide';

function esc(s) {
  return String(s ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/"/g, '&quot;');
}

function block(w, h, extra = '') {
  return `<div class="su-skeleton" style="width:${w};height:${h};${extra}" aria-hidden="true"></div>`;
}

function row(n = 5) {
  return Array.from({ length: n }, (_, i) => `
    <div class="su-skel-row">
      ${block('2rem', '2rem', 'border-radius:8px;flex-shrink:0')}
      <div class="su-skel-row__text">
        ${block(i % 2 ? '72%' : '88%', '0.85rem')}
        ${block('48%', '0.65rem', 'margin-top:0.35rem')}
      </div>
    </div>`).join('');
}

const TEMPLATES = {
  page: () => `
    <div class="su-skel-layout su-skel-layout--page">
      <div class="su-skel-rail">${block('100%', '2.2rem')}${block('70%', '0.7rem', 'margin-top:1rem')}${row(6)}</div>
      <div class="su-skel-main">
        ${block('40%', '1.1rem')}${block('100%', '8rem', 'margin-top:1rem;border-radius:12px')}
        ${block('100%', '1rem', 'margin-top:1rem')}${block('85%', '1rem', 'margin-top:0.5rem')}
      </div>
    </div>`,

  program: () => `
    <div class="su-skel-layout su-skel-layout--program">
      <div class="su-skel-col">
        ${block('55%', '0.9rem')}${row(8)}
      </div>
      <div class="su-skel-col su-skel-col--wide">
        ${block('100%', '56%', 'border-radius:12px;aspect-ratio:16/9;height:auto')}
        ${block('100%', '4rem', 'margin-top:0.75rem;border-radius:10px')}
      </div>
      <div class="su-skel-col">
        ${block('60%', '0.9rem')}${block('100%', '2rem', 'margin-top:0.75rem')}
        ${block('100%', '2rem', 'margin-top:0.5rem')}${block('100%', '6rem', 'margin-top:0.75rem')}
      </div>
    </div>`,

  cultos: () => `
    <div class="su-skel-layout su-skel-layout--cultos">
      <div class="su-skel-cal">
        ${block('50%', '1rem')}${block('100%', '14rem', 'margin-top:1rem;border-radius:12px')}
      </div>
      <div class="su-skel-main">${block('45%', '1rem')}${row(5)}</div>
    </div>`,

  list: () => `
    <div class="su-skel-layout su-skel-layout--list">
      ${block('36%', '1.1rem')}
      <div class="su-skel-toolbar">${block('8rem', '2rem')}${block('8rem', '2rem')}${block('30%', '2rem')}</div>
      ${row(9)}
    </div>`,

  grid: () => `
    <div class="su-skel-layout su-skel-layout--grid">
      ${block('40%', '1.1rem')}
      <div class="su-skel-toolbar">${block('9rem', '2rem')}${block('40%', '2rem')}</div>
      <div class="su-skel-grid">
        ${Array.from({ length: 8 }, () => block('100%', '0', 'aspect-ratio:16/9;height:auto;border-radius:10px')).join('')}
      </div>
    </div>`,

  settings: () => `
    <div class="su-skel-layout su-skel-layout--settings">
      <div class="su-skel-rail">${block('80%', '0.85rem')}${row(7)}</div>
      <div class="su-skel-main">
        ${block('35%', '1.1rem')}
        ${block('100%', '2.5rem', 'margin-top:1rem')}${block('100%', '2.5rem', 'margin-top:0.65rem')}
        ${block('100%', '2.5rem', 'margin-top:0.65rem')}${block('40%', '2.2rem', 'margin-top:1.25rem')}
      </div>
    </div>`,
};

TEMPLATES.media = TEMPLATES.grid;
TEMPLATES.lyrics = TEMPLATES.list;
TEMPLATES.bible = TEMPLATES.list;
TEMPLATES.library = TEMPLATES.grid;
TEMPLATES.designer = TEMPLATES.program;

export function skeletonVariantForView(view) {
  const map = {
    cultos: 'cultos',
    program: 'program',
    lyrics: 'lyrics',
    media: 'media',
    bible: 'bible',
    library: 'library',
    designer: 'designer',
    settings: 'settings',
  };
  return map[view] || 'page';
}

function syncOverlayRect(overlay, host) {
  if (!overlay || !host) return;
  const r = host.getBoundingClientRect();
  const parentH = host.parentElement?.clientHeight || 0;
  const w = Math.max(r.width, 0);
  const h = Math.max(r.height, parentH, 160);
  overlay.style.top = `${Math.max(0, r.top)}px`;
  overlay.style.left = `${Math.max(0, r.left)}px`;
  overlay.style.width = `${w}px`;
  overlay.style.height = `${h}px`;
}

/**
 * Mostra overlay de skeleton sobre o host (portal em body).
 * @returns {function} hide() — remove após minMs desde o show
 */
export function showSkeletonOverlay(host, options = {}) {
  if (!host || typeof document?.body?.appendChild !== 'function') return () => {};

  const {
    variant = 'page',
    message = 'Carregando…',
    minMs = 380,
    className = '',
  } = options;

  hideSkeletonOverlay(host, { immediate: true });

  const started = Date.now();
  host.setAttribute(HOST_ATTR, '1');

  const overlay = document.createElement('div');
  overlay.className = `su-skel-overlay su-skel-overlay--portal ${className}`.trim();
  overlay.setAttribute('role', 'status');
  overlay.setAttribute('aria-live', 'polite');
  overlay.setAttribute('aria-busy', 'true');
  const tpl = TEMPLATES[variant] || TEMPLATES.page;
  overlay.innerHTML = `
    <div class="su-skel-overlay__panel">
      <p class="su-skel-overlay__msg">${esc(message)}</p>
      ${tpl()}
    </div>`;

  syncOverlayRect(overlay, host);
  document.body.appendChild(overlay);
  host[OVERLAY_KEY] = overlay;

  const onResize = () => syncOverlayRect(overlay, host);
  window.addEventListener('resize', onResize);
  // Re-sync após o host receber conteúdo (altura muda)
  const ro = typeof ResizeObserver !== 'undefined'
    ? new ResizeObserver(onResize)
    : null;
  try { ro?.observe(host); } catch { /* ignore */ }

  requestAnimationFrame(() => {
    syncOverlayRect(overlay, host);
    overlay.classList.add('is-visible');
  });

  let hidden = false;
  const hide = () => {
    if (hidden) return;
    hidden = true;
    const left = Math.max(0, minMs - (Date.now() - started));
    const finish = () => {
      overlay.classList.remove('is-visible');
      overlay.classList.add('is-leaving');
      setTimeout(() => {
        window.removeEventListener('resize', onResize);
        try { ro?.disconnect(); } catch { /* ignore */ }
        overlay.remove();
        if (host[OVERLAY_KEY] === overlay) delete host[OVERLAY_KEY];
        host.removeAttribute(HOST_ATTR);
        if (host[HIDE_KEY] === hide) delete host[HIDE_KEY];
      }, 240);
    };
    if (left > 0) setTimeout(finish, left);
    else finish();
  };

  host[HIDE_KEY] = hide;
  return hide;
}

export function hideSkeletonOverlay(host, { immediate = false } = {}) {
  if (!host) return;
  const overlay = host[OVERLAY_KEY]
    || document.querySelector?.(`.su-skel-overlay--portal[data-for="${host.id}"]`)
    || host.querySelector?.('.su-skel-overlay');

  if (!overlay) {
    host.removeAttribute?.(HOST_ATTR);
    delete host[OVERLAY_KEY];
    delete host[HIDE_KEY];
    return;
  }

  if (immediate) {
    overlay.remove();
    host.removeAttribute(HOST_ATTR);
    delete host[OVERLAY_KEY];
    delete host[HIDE_KEY];
    return;
  }
  if (typeof host[HIDE_KEY] === 'function') host[HIDE_KEY]();
}

/** Executa async work com skeleton até concluir (+ minMs). */
export async function withSkeleton(host, work, options = {}) {
  const hide = showSkeletonOverlay(host, options);
  try {
    return await work();
  } finally {
    hide();
  }
}

/** HTML de um bloco skeleton isolado (sem overlay). */
export function skeletonBlockHtml(width = '100%', height = '1rem') {
  return `<div class="su-skeleton" style="width:${esc(width)};height:${esc(height)}" aria-hidden="true"></div>`;
}
