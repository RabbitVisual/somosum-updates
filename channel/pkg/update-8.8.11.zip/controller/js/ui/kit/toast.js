/** SOMOSUM UI Kit — toast (SafeDOM) */
import { createComponent } from '../../core/render-engine/component-registry.js';
import { enqueue } from '../../core/render-engine/render-queue.js';

function ensureHost() {
  let host = document.getElementById('su-toast-host');
  if (!host) {
    host = document.createElement('div');
    host.id = 'su-toast-host';
    host.className = 'su-toast-host';
    host.setAttribute('aria-live', 'polite');
    document.body.appendChild(host);
  }
  return host;
}

export function toast(msg, type = 'info', durationMs = 2800) {
  const host = ensureHost();
  const el = createComponent('Toast', { message: String(msg ?? ''), type });
  host.appendChild(el);
  enqueue('toast-visible', () => el.classList.add('is-visible'), { priority: 'live' });
  setTimeout(() => {
    el.classList.remove('is-visible');
    setTimeout(() => el.remove(), 220);
  }, durationMs);
  return el;
}

export function snackbar(msg, durationMs = 3200) {
  document.querySelector('.su-snackbar')?.remove();
  const el = document.createElement('div');
  el.className = 'su-snackbar';
  el.setAttribute('role', 'status');
  el.textContent = String(msg ?? '');
  document.body.appendChild(el);
  requestAnimationFrame(() => el.classList.add('is-visible'));
  setTimeout(() => {
    el.classList.remove('is-visible');
    setTimeout(() => el.remove(), 220);
  }, durationMs);
}
