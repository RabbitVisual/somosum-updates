/** SOMOSUM UI Kit — tooltip */
let tipEl = null;

export function hideTooltip() {
  tipEl?.remove();
  tipEl = null;
}

export function showTooltip(anchor, text) {
  hideTooltip();
  if (!anchor || !text) return;
  const tip = document.createElement('div');
  tip.className = 'su-tooltip';
  tip.id = 'su-tooltip';
  tip.role = 'tooltip';
  tip.textContent = text;
  document.body.appendChild(tip);
  const r = anchor.getBoundingClientRect();
  tip.style.left = `${Math.min(r.left, window.innerWidth - tip.offsetWidth - 8)}px`;
  tip.style.top = `${Math.max(8, r.top - tip.offsetHeight - 6)}px`;
  tipEl = tip;
  anchor.setAttribute('aria-describedby', 'su-tooltip');
}

export function bindTooltip(el, text) {
  if (!el) return () => {};
  const enter = () => showTooltip(el, typeof text === 'function' ? text() : text);
  const leave = () => hideTooltip();
  el.addEventListener('mouseenter', enter);
  el.addEventListener('mouseleave', leave);
  el.addEventListener('focus', enter);
  el.addEventListener('blur', leave);
  return () => {
    el.removeEventListener('mouseenter', enter);
    el.removeEventListener('mouseleave', leave);
    el.removeEventListener('focus', enter);
    el.removeEventListener('blur', leave);
  };
}

/** Tooltips elegantes no shell — botões ícone e nav colapsada. */
export function bindShellTooltips(root = document) {
  const disposers = [];
  root.querySelectorAll('.btn-icon[title], .btn-sm[title], #btn-black[title], #btn-logo-btn[title], #btn-go-live[title]').forEach((el) => {
    const text = el.getAttribute('title');
    if (!text) return;
    el.dataset.suTooltip = text;
    el.removeAttribute('title');
    disposers.push(bindTooltip(el, text));
  });
  const sidebar = root.querySelector('#sidebar');
  const refreshNavTips = () => {
    sidebar?.querySelectorAll('.nav-btn').forEach((btn) => {
      if (!sidebar.classList.contains('is-collapsed')) return;
      const text = btn.dataset.view ? btn.getAttribute('data-su-nav-tip') || btn.querySelector('.nav-label')?.textContent : '';
      if (text && !btn.dataset.suTooltipBound) {
        btn.dataset.suTooltipBound = '1';
        const tip = btn.getAttribute('title') || text;
        btn.removeAttribute('title');
        disposers.push(bindTooltip(btn, tip));
      }
    });
  };
  refreshNavTips();
  const obs = sidebar ? new MutationObserver(refreshNavTips) : null;
  if (obs && sidebar) obs.observe(sidebar, { attributes: true, attributeFilter: ['class'] });
  return () => {
    disposers.forEach((fn) => { try { fn(); } catch { /* ignore */ } });
    obs?.disconnect();
  };
}
