/**
 * SOMOSUM UI Kit — API pública
 */
export { toast, snackbar } from './toast.js';
export { confirmDialog, showModal } from './dialog.js';
export { openContextMenu, closeContextMenu, bindContextMenu } from './context-menu.js';
export { mountTabs } from './tabs.js';
export { showTooltip, hideTooltip, bindTooltip } from './tooltip.js';
export { mountStatusBar } from './status-bar.js';
export { renderPropertyGrid } from './property-grid.js';
export { mountPreviewFrame } from './preview-frame.js';
export { mountVirtualList } from './virtual-list.js';
export {
  showSkeletonOverlay,
  hideSkeletonOverlay,
  withSkeleton,
  skeletonVariantForView,
  skeletonBlockHtml,
} from './skeleton-overlay.js';

export function skeleton(width = '100%', height = '1rem') {
  const el = document.createElement('div');
  el.className = 'su-skeleton';
  el.style.width = width;
  el.style.height = height;
  el.setAttribute('aria-hidden', 'true');
  return el;
}
