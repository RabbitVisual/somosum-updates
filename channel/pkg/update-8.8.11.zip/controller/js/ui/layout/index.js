export { mountShell, mountSplitView, mountDock, mountWorkspace } from './shell.js';
