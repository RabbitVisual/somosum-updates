import { createElement } from '../../core/render-engine/safe-dom.js';

export function mountShell(host, { topbar = null, sidebar = null, main = null, dock = null } = {}) {
  if (!host) return { dispose() {} };
  host.innerHTML = '';
  host.classList.add('su-shell');
  const body = createElement('div', { class: 'su-shell__body' });
  if (topbar) {
    const bar = createElement('header', { class: 'su-shell__topbar' });
    bar.appendChild(topbar);
    host.appendChild(bar);
  }
  if (sidebar) {
    const side = createElement('aside', { class: 'su-shell__sidebar' });
    side.appendChild(sidebar);
    body.appendChild(side);
  }
  const mainEl = createElement('main', { class: 'su-shell__main' });
  if (main) mainEl.appendChild(main);
  body.appendChild(mainEl);
  if (dock) {
    const dockEl = createElement('aside', { class: 'su-shell__dock' });
    dockEl.appendChild(dock);
    body.appendChild(dockEl);
  }
  host.appendChild(body);
  return { dispose: () => { host.innerHTML = ''; host.classList.remove('su-shell'); } };
}

export function mountSplitView(host, panes = []) {
  if (!host) return { dispose() {} };
  host.innerHTML = '';
  host.classList.add('su-split');
  panes.forEach((pane) => {
    const el = createElement('div', { class: 'su-split__pane' });
    if (pane instanceof HTMLElement) el.appendChild(pane);
    host.appendChild(el);
  });
  return { dispose: () => { host.innerHTML = ''; host.classList.remove('su-split'); } };
}

export function mountDock(host, content) {
  if (!host) return { dispose() {} };
  host.classList.add('su-shell__dock');
  if (content) host.appendChild(content);
  return { dispose: () => { host.classList.remove('su-shell__dock'); } };
}

export function mountWorkspace(host, content) {
  if (!host) return { dispose() {} };
  host.innerHTML = '';
  host.classList.add('su-workspace');
  if (content) host.appendChild(content);
  return { dispose: () => { host.innerHTML = ''; host.classList.remove('su-workspace'); } };
}
