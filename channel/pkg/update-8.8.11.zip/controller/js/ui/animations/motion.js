function reducedMotion() {
  return typeof window !== 'undefined'
    && (window.matchMedia?.('(prefers-reduced-motion: reduce)')?.matches
      || document.documentElement.classList.contains('somosum-low-spec'));
}

export function motionEnter(el, className = 'su-motion-enter') {
  if (!el || reducedMotion()) return;
  el.classList.add(className);
  const done = () => el.classList.remove(className);
  el.addEventListener('animationend', done, { once: true });
}

export function motionExit(el, className = 'su-motion-exit', onDone = null) {
  if (!el) return;
  if (reducedMotion()) {
    onDone?.();
    return;
  }
  el.classList.add(className);
  el.addEventListener('animationend', () => {
    el.classList.remove(className);
    onDone?.();
  }, { once: true });
}

export function pulseFeedback(el) {
  if (!el || reducedMotion()) return;
  el.classList.add('su-motion-pulse');
  setTimeout(() => el.classList.remove('su-motion-pulse'), 320);
}

export const Motion = { enter: motionEnter, exit: motionExit, pulse: pulseFeedback, reducedMotion };
