import { DiskAdapter } from '../core/storage/adapters/disk-adapter.js';
import { PRODUCT_LOGO_REL, PRODUCT_NAME, PRODUCT_TAGLINE } from '../core/brand-assets.js';

const DEFAULTS = {
  name: PRODUCT_NAME,
  subtitle: PRODUCT_TAGLINE,
  logoPath: PRODUCT_LOGO_REL,
};

export async function applyPortalBranding() {
  let church = { ...DEFAULTS };
  try {
    const config = await DiskAdapter.load('config.json');
    if (config?.church) church = { ...church, ...config.church };
  } catch { /* offline */ }

  const name = church.name?.trim() || DEFAULTS.name;
  const subtitle = church.subtitle?.trim() || DEFAULTS.subtitle;
  const logo = church.logoPath || DEFAULTS.logoPath;

  document.title = `${name} — Projeção`;

  const h1 = document.querySelector('h1');
  if (h1 && !h1.dataset.noBrand) h1.textContent = name;

  const sub = document.querySelector('.sub, .portal-sub');
  if (sub) sub.textContent = subtitle;

  document.querySelectorAll('.hero-logo, .portal-logo').forEach((img) => {
    if (logo) img.src = logo;
  });
}

export async function applyControlTitle() {
  let church = { ...DEFAULTS };
  try {
    const config = await DiskAdapter.load('config.json');
    if (config?.church) church = { ...church, ...config.church };
  } catch { /* ignore */ }
  const name = church.name?.trim() || 'SOMOSUM';
  document.title = `${name} — Controle`;
}
