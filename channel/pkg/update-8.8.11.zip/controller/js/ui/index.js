export {
  bootstrapDesignSystem,
  buildSnapshot,
  ThemeEngine,
  Motion,
  createLiveRegion,
  applyHighContrast,
} from './design-system-manager.js';

export * from './kit/index.js';
export * from './components/index.js';
export * from './layout/index.js';
export * from './theme/index.js';
export * from './animations/index.js';
export * from './accessibility/index.js';

import { bootstrapDesignSystem } from './design-system-manager.js';

if (typeof window !== 'undefined') {
  queueMicrotask(() => {
    try { bootstrapDesignSystem(); } catch { /* offline */ }
  });
}
