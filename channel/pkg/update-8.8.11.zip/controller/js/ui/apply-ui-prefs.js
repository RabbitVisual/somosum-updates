/** Aplica preferências de UI (escala, contraste, chrome claro/escuro) no documento. */
import { lockUiScaleFromUser } from '../core/ui-scale.js';
import { applyChromeTheme, resolveChromeTheme } from './chrome-theme.js';

export function applyUiPrefs(prefs) {
  const ui = prefs?.ui || {};
  const root = document.documentElement;
  const scale = Number(ui.scale) || 1;
  const fontScale = Number(ui.fontScale) || 1;
  lockUiScaleFromUser();
  root.style.setProperty('--ui-scale', String(Math.min(1.4, Math.max(0.85, scale))));
  root.style.setProperty('--font-scale', String(Math.min(1.4, Math.max(0.85, fontScale))));
  const contrast = !!(ui.highContrast || prefs?.highContrast);
  root.classList.toggle('su-a11y-contrast', contrast);
  if (ui.reducedMotion) root.classList.add('su-reduce-motion');
  else root.classList.remove('su-reduce-motion');
  applyChromeTheme(resolveChromeTheme(prefs));
  delete root.dataset.projectionTheme;
}
