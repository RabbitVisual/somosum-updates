/**
 * Editor de identidade da igreja — logo com recorte + fundo com preview.
 * Usado no Painel Gerencial e em Ajustes → Igreja.
 */

import { PRODUCT_LOGO } from '../core/brand-assets.js';

export const LOGO_GUIDE = {
  minPx: 512,
  idealPx: 1024,
  format: 'PNG com fundo transparente',
  ratio: '1:1 (quadrada)',
  tips: [
    'Use PNG com fundo transparente para a logo ficar limpa no projetor.',
    'Tamanho ideal: 1024 × 1024 px (mínimo 512 × 512).',
    'Evite fotos com fundo branco ou texto ilegível à distância.',
    'Depois de enviar, ajuste o recorte no quadrado — o que aparece no círculo é o que a igreja vê.',
  ],
};

export const BG_GUIDE = {
  ideal: '1920 × 1080 (Full HD, 16:9)',
  formats: 'JPG, PNG ou vídeo MP4/WebM',
  tips: [
    'Foto ou vídeo horizontal 16:9 — mesma proporção do projetor.',
    'Ideal: 1920 × 1080 px. Evite imagens muito escuras ou muito claras.',
    'Aparece em Boas-vindas e no pré-culto quando você escolhe “Foto da igreja”.',
  ],
};

function esc(s) {
  return String(s ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/"/g, '&quot;');
}

function readFileAsDataUrl(file) {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(r.result);
    r.onerror = () => reject(new Error('Não foi possível ler o arquivo'));
    r.readAsDataURL(file);
  });
}

function loadImage(src) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error('Não foi possível abrir a imagem'));
    img.src = src;
  });
}

/**
 * Modal de recorte quadrado da logo.
 * @returns {Promise<string|null>} data URL PNG ou null se cancelar
 */
export async function openLogoCropDialog(fileOrDataUrl) {
  let objectUrl = null;
  let src = fileOrDataUrl;
  try {
    if (fileOrDataUrl instanceof Blob) {
      objectUrl = URL.createObjectURL(fileOrDataUrl);
      src = objectUrl;
    }
    const img = await loadImage(src);
    return await showCropUi(img);
  } catch (err) {
    console.error('[church-identity] crop', err);
    alert(err?.message || 'Não foi possível abrir a imagem para recorte.');
    return null;
  } finally {
    if (objectUrl) URL.revokeObjectURL(objectUrl);
  }
}

function showCropUi(img) {
  return new Promise((resolve) => {
    const overlay = document.createElement('div');
    overlay.className = 'church-crop-overlay';
    overlay.setAttribute('style', 'position:fixed;inset:0;z-index:10050;display:flex;align-items:center;justify-content:center;padding:1rem;background:rgba(4,3,2,.85)');
    overlay.innerHTML = `
      <div class="church-crop-dialog" role="dialog" aria-modal="true" aria-labelledby="church-crop-title"
        style="width:min(920px,100%);max-height:92vh;overflow:auto;border-radius:16px;border:1px solid rgba(212,198,141,.28);background:#14110c;padding:1.15rem 1.25rem;box-shadow:0 28px 80px rgba(0,0,0,.55)">
        <header class="church-crop-head">
          <div>
            <p class="church-crop-kicker">Logo na projeção</p>
            <h3 id="church-crop-title">Ajustar e recortar</h3>
          </div>
          <button type="button" class="church-crop-close" data-act="cancel" aria-label="Fechar">×</button>
        </header>
        <p class="church-crop-lead">Arraste a imagem e use o zoom. O quadrado é o recorte final — a prévia à direita mostra como fica no projetor.</p>
        <div class="church-crop-body">
          <div class="church-crop-stage-wrap">
            <div class="church-crop-stage" id="church-crop-stage">
              <canvas id="church-crop-canvas" width="420" height="420"></canvas>
              <div class="church-crop-frame" aria-hidden="true"></div>
            </div>
            <label class="church-crop-zoom">
              <span>Zoom</span>
              <input type="range" id="church-crop-zoom" min="100" max="300" value="100" />
            </label>
          </div>
          <aside class="church-crop-aside">
            <p class="church-crop-aside-title">Como fica na tela</p>
            <div class="church-crop-proj-preview">
              <div class="church-crop-proj-glow"></div>
              <canvas id="church-crop-mini" width="160" height="160"></canvas>
              <p class="church-crop-proj-caption">Boas-vindas · pré-culto</p>
            </div>
            <ul class="church-crop-tips">
              ${LOGO_GUIDE.tips.slice(0, 3).map((t) => `<li>${esc(t)}</li>`).join('')}
            </ul>
          </aside>
        </div>
        <footer class="church-crop-foot">
          <button type="button" class="su-btn su-btn--secondary" data-act="cancel">Cancelar</button>
          <button type="button" class="su-btn su-btn--primary" data-act="ok">Usar esta logo</button>
        </footer>
      </div>`;
    document.body.appendChild(overlay);

    const canvas = overlay.querySelector('#church-crop-canvas');
    const ctx = canvas.getContext('2d');
    const mini = overlay.querySelector('#church-crop-mini');
    const mctx = mini.getContext('2d');
    const zoomEl = overlay.querySelector('#church-crop-zoom');
    const stage = overlay.querySelector('#church-crop-stage');

    const state = { scale: 1, ox: 0, oy: 0, drag: false, lx: 0, ly: 0 };

    const fit = () => {
      const side = Math.min(img.naturalWidth || img.width, img.naturalHeight || img.height) || 1;
      state.scale = canvas.width / side;
      const w = (img.naturalWidth || img.width) * state.scale;
      const h = (img.naturalHeight || img.height) * state.scale;
      state.ox = (canvas.width - w) / 2;
      state.oy = (canvas.height - h) / 2;
      zoomEl.value = '100';
    };
    fit();

    const paint = () => {
      const z = Number(zoomEl.value) / 100;
      const s = state.scale * z;
      const iw = img.naturalWidth || img.width;
      const ih = img.naturalHeight || img.height;
      ctx.fillStyle = '#0c0a08';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.drawImage(img, state.ox, state.oy, iw * s, ih * s);

      mctx.fillStyle = '#12100c';
      mctx.fillRect(0, 0, mini.width, mini.height);
      const g = mctx.createRadialGradient(80, 80, 10, 80, 80, 90);
      g.addColorStop(0, 'rgba(212,198,141,0.25)');
      g.addColorStop(1, 'transparent');
      mctx.fillStyle = g;
      mctx.fillRect(0, 0, 160, 160);
      mctx.save();
      mctx.beginPath();
      mctx.arc(80, 80, 62, 0, Math.PI * 2);
      mctx.clip();
      mctx.drawImage(canvas, 0, 0, 160, 160);
      mctx.restore();
      mctx.strokeStyle = 'rgba(212,198,141,0.45)';
      mctx.lineWidth = 2;
      mctx.beginPath();
      mctx.arc(80, 80, 62, 0, Math.PI * 2);
      mctx.stroke();
    };
    paint();

    zoomEl.addEventListener('input', paint);

    const onDown = (e) => {
      state.drag = true;
      state.lx = e.clientX ?? e.touches?.[0]?.clientX;
      state.ly = e.clientY ?? e.touches?.[0]?.clientY;
      e.preventDefault?.();
    };
    const onMove = (e) => {
      if (!state.drag) return;
      const x = e.clientX ?? e.touches?.[0]?.clientX;
      const y = e.clientY ?? e.touches?.[0]?.clientY;
      if (x == null || y == null) return;
      state.ox += x - state.lx;
      state.oy += y - state.ly;
      state.lx = x;
      state.ly = y;
      paint();
    };
    const onUp = () => { state.drag = false; };
    stage.addEventListener('mousedown', onDown);
    stage.addEventListener('touchstart', onDown, { passive: false });
    window.addEventListener('mousemove', onMove);
    window.addEventListener('touchmove', onMove, { passive: true });
    window.addEventListener('mouseup', onUp);
    window.addEventListener('touchend', onUp);

    const cleanup = (result) => {
      window.removeEventListener('mousemove', onMove);
      window.removeEventListener('touchmove', onMove);
      window.removeEventListener('mouseup', onUp);
      window.removeEventListener('touchend', onUp);
      overlay.remove();
      resolve(result);
    };

    const exportCrop = () => {
      const out = document.createElement('canvas');
      out.width = LOGO_GUIDE.idealPx;
      out.height = LOGO_GUIDE.idealPx;
      const octx = out.getContext('2d');
      const z = Number(zoomEl.value) / 100;
      const s = state.scale * z;
      const inv = 1 / s;
      const sx = -state.ox * inv;
      const sy = -state.oy * inv;
      const sw = canvas.width * inv;
      octx.drawImage(img, sx, sy, sw, sw, 0, 0, out.width, out.height);
      return out.toDataURL('image/png');
    };

    overlay.addEventListener('click', (e) => {
      const act = e.target?.closest?.('[data-act]')?.getAttribute('data-act');
      if (act === 'cancel') cleanup(null);
      if (act === 'ok') cleanup(exportCrop());
    });
  });
}

export { readFileAsDataUrl };

/** HTML do card de identidade (logo + fundo) — ids prefixáveis. */
export function churchIdentityAssetsHtml({
  logoUrl = '',
  bgUrl = '',
  bgKind = 'image',
  logoCustom = false,
  bgCustom = false,
  idPrefix = 'church',
} = {}) {
  const logoSrc = logoUrl || PRODUCT_LOGO;
  const bgSrc = bgUrl || '/IMG/FRENTE_DA_IGREJA.png';
  const bgMedia = bgKind === 'video'
    ? `<video class="church-id-media church-id-media--video" src="${esc(bgSrc)}" muted loop playsinline autoplay></video>`
    : `<div class="church-id-media church-id-media--photo" style="background-image:url('${esc(bgSrc)}')"></div>`;

  return `
    <div class="church-id-studio" data-church-id-studio>
      <div class="church-id-hero">
        <div class="church-id-mock" aria-hidden="true">
          ${bgMedia}
          <div class="church-id-mock-veil"></div>
          <div class="church-id-mock-content">
            <img class="church-id-mock-logo" src="${esc(logoSrc)}" alt="" id="${idPrefix}-logo-live"
              onerror="this.onerror=null;this.src='${PRODUCT_LOGO}'" />
            <p class="church-id-mock-kicker">Prévia da projeção</p>
            <p class="church-id-mock-title">Boas-vindas</p>
          </div>
        </div>
        <div class="church-id-hero-copy">
          <p class="church-id-badge">${logoCustom || bgCustom ? 'Personalizado para sua igreja' : 'Usando imagens do sistema'}</p>
          <h3 class="church-id-title">Identidade na projeção</h3>
          <p class="church-id-lead">Estas imagens aparecem <strong>só no projetor</strong> (Boas-vindas e pré-culto). O Painel e o Controle do SOMOSUM não mudam.</p>
        </div>
      </div>

      <div class="church-id-grid">
        <article class="church-id-card">
          <header class="church-id-card-head">
            <h4>Logo da igreja</h4>
            <span class="church-id-pill">${logoCustom ? 'Sua logo' : 'Padrão do sistema'}</span>
          </header>
          <div class="church-id-logo-stage">
            <div class="church-id-logo-ring">
              <img src="${esc(logoSrc)}" alt="" id="${idPrefix}-logo-preview"
                onerror="this.onerror=null;this.src='${PRODUCT_LOGO}'" />
            </div>
          </div>
          <div class="church-id-specs">
            <p><strong>Recomendado:</strong> ${esc(LOGO_GUIDE.idealPx)} × ${esc(LOGO_GUIDE.idealPx)} px · ${esc(LOGO_GUIDE.ratio)}</p>
            <p><strong>Formato:</strong> ${esc(LOGO_GUIDE.format)}</p>
            <p><strong>Mínimo:</strong> ${esc(LOGO_GUIDE.minPx)} × ${esc(LOGO_GUIDE.minPx)} px</p>
          </div>
          <ul class="church-id-tips">
            ${LOGO_GUIDE.tips.map((t) => `<li>${esc(t)}</li>`).join('')}
          </ul>
          <div class="church-id-actions">
            <label class="su-btn su-btn--primary church-id-file-btn">
              Escolher e recortar logo
              <input type="file" class="church-id-file-input" id="${idPrefix}-logo-file" accept="image/png,image/jpeg,image/jpg,image/webp,image/gif,.png,.jpg,.jpeg,.webp,.gif" />
            </label>
            <button type="button" class="su-btn su-btn--secondary" id="${idPrefix}-logo-reset">Restaurar padrão do sistema</button>
          </div>
          <p class="church-id-status" id="${idPrefix}-logo-status" hidden></p>
        </article>

        <article class="church-id-card">
          <header class="church-id-card-head">
            <h4>Fundo da igreja</h4>
            <span class="church-id-pill">${bgCustom ? 'Seu fundo' : 'Padrão do sistema'}</span>
          </header>
          <div class="church-id-bg-stage" id="${idPrefix}-bg-preview">
            ${bgKind === 'video'
              ? `<video src="${esc(bgSrc)}" muted loop playsinline autoplay></video>`
              : `<div style="background-image:url('${esc(bgSrc)}')"></div>`}
            <span class="church-id-bg-ratio">16:9</span>
          </div>
          <div class="church-id-specs">
            <p><strong>Recomendado:</strong> ${esc(BG_GUIDE.ideal)}</p>
            <p><strong>Formatos:</strong> ${esc(BG_GUIDE.formats)}</p>
          </div>
          <ul class="church-id-tips">
            ${BG_GUIDE.tips.map((t) => `<li>${esc(t)}</li>`).join('')}
          </ul>
          <div class="church-id-actions">
            <label class="su-btn su-btn--primary church-id-file-btn">
              Enviar foto ou vídeo
              <input type="file" class="church-id-file-input" id="${idPrefix}-bg-file" accept="image/*,video/mp4,video/webm,.jpg,.jpeg,.png,.webp,.mp4,.webm" />
            </label>
            <button type="button" class="su-btn su-btn--secondary" id="${idPrefix}-bg-reset">Restaurar padrão do sistema</button>
          </div>
          <p class="church-id-status" id="${idPrefix}-bg-status" hidden></p>
        </article>
      </div>
    </div>`;
}

/** Liga inputs de arquivo (clique direto no input — WebView2 bloqueia input.click() em hidden). */
export function bindChurchIdentityPickers(root, {
  idPrefix,
  onLogoFile,
  onBgFile,
  onLogoReset,
  onBgReset,
} = {}) {
  if (!root || !idPrefix) return;
  /* Preferir o studio recém-montado (Ajustes reusa o mesmo <main>). */
  const scope = root.querySelector?.('[data-church-id-studio]') || root;

  const setStatus = (kind, msg, ok = true) => {
    const el = scope.querySelector(`#${idPrefix}-${kind}-status`)
      || root.querySelector(`#${idPrefix}-${kind}-status`);
    if (!el) return;
    el.hidden = !msg;
    el.textContent = msg || '';
    el.classList.toggle('is-error', !ok);
    el.classList.toggle('is-ok', !!ok && !!msg);
  };

  const logoFile = scope.querySelector(`#${idPrefix}-logo-file`)
    || root.querySelector(`#${idPrefix}-logo-file`);
  const bgFile = scope.querySelector(`#${idPrefix}-bg-file`)
    || root.querySelector(`#${idPrefix}-bg-file`);

  if (!logoFile && !bgFile) {
    console.warn('[church-identity] inputs de arquivo não encontrados', idPrefix);
    return;
  }

  logoFile?.addEventListener('change', async (e) => {
    const f = e.target.files?.[0];
    e.target.value = '';
    if (!f) return;
    setStatus('logo', 'Abrindo editor de recorte…');
    try {
      await onLogoFile?.(f, setStatus);
    } catch (err) {
      console.error(err);
      setStatus('logo', err?.message || 'Falha ao salvar a logo.', false);
      alert(err?.message || 'Falha ao salvar a logo.');
    }
  });

  bgFile?.addEventListener('change', async (e) => {
    const f = e.target.files?.[0];
    e.target.value = '';
    if (!f) return;
    setStatus('bg', 'Enviando fundo…');
    try {
      await onBgFile?.(f, setStatus);
    } catch (err) {
      console.error(err);
      setStatus('bg', err?.message || 'Falha ao salvar o fundo.', false);
      alert(err?.message || 'Falha ao salvar o fundo.');
    }
  });

  const logoReset = scope.querySelector(`#${idPrefix}-logo-reset`)
    || root.querySelector(`#${idPrefix}-logo-reset`);
  const bgReset = scope.querySelector(`#${idPrefix}-bg-reset`)
    || root.querySelector(`#${idPrefix}-bg-reset`);

  logoReset?.addEventListener('click', async () => {
    try {
      await onLogoReset?.(setStatus);
    } catch (err) {
      alert(err?.message || 'Falha ao restaurar a logo.');
    }
  });

  bgReset?.addEventListener('click', async () => {
    try {
      await onBgReset?.(setStatus);
    } catch (err) {
      alert(err?.message || 'Falha ao restaurar o fundo.');
    }
  });
}
