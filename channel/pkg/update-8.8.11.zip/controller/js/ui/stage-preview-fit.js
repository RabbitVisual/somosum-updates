/**
 * Prévia 16:9 fiel (1920×1080) — quadro centrado + conteúdo do slide centralizado.
 * Usado por Louvores, Bíblia, dock Projetor e Programa.
 * Leve: 1 RAF por ciclo + ResizeObserver só no frame.
 */

const DESIGN_W = 1920;
const DESIGN_H = 1080;

const SHELL_SEL = '.screen-viewport, .preview-inner, .screen-canvas, .screen-stage';

function lockShellBox(el) {
  el.style.position = 'absolute';
  el.style.inset = '0';
  el.style.width = `${DESIGN_W}px`;
  el.style.height = `${DESIGN_H}px`;
  el.style.minWidth = `${DESIGN_W}px`;
  el.style.minHeight = `${DESIGN_H}px`;
  el.style.maxWidth = 'none';
  el.style.maxHeight = 'none';
  el.style.margin = '0';
  el.style.flex = 'none';
  el.style.transform = 'none';
  el.style.setProperty('--dpe-design-w', `${DESIGN_W}px`);
  el.style.setProperty('--dpe-design-h', `${DESIGN_H}px`);
  el.style.setProperty('--dpe-scale', '1');
  el.style.setProperty('--projection-scale', '1');
  el.style.setProperty('--proj-comp', '1');
}

/** Força o subtree renderPreview a ocupar o stage virtual completo. */
export function lockPreviewStage(scaler) {
  if (!scaler) return;
  scaler.style.width = `${DESIGN_W}px`;
  scaler.style.height = `${DESIGN_H}px`;
  scaler.style.position = 'absolute';
  scaler.style.transformOrigin = 'top left';
  scaler.style.pointerEvents = 'none';
  scaler.style.overflow = 'hidden';
  scaler.style.right = 'auto';
  scaler.style.bottom = 'auto';
  scaler.style.margin = '0';

  scaler.querySelectorAll(SHELL_SEL).forEach((el) => {
    lockShellBox(el);
    el.style.display = 'block';
  });

  // .slide precisa permanecer flex — respeita align/vAlign do slide (não força center)
  scaler.querySelectorAll('.slide').forEach((el) => {
    lockShellBox(el);
    el.style.display = 'flex';
    el.style.flexDirection = 'column';
    el.style.alignItems = '';
    el.style.justifyContent = '';
    el.style.boxSizing = 'border-box';
  });
}

/**
 * Frame real da prévia — no Programa o chrome fica no wrap, não no #stage-preview.
 */
export function resolvePreviewFitFrame(container) {
  if (!container) return null;
  const wrap = container.closest('.live-dock-preview-wrap, .stage-preview-wrap');
  if (wrap) {
    const w = wrap.clientWidth || 0;
    const h = wrap.clientHeight || 0;
    if (w >= 40 && h >= 40) return wrap;
  }
  return container;
}

/**
 * Calcula e aplica scale para o scaler caber no frame (contain 16:9, centrado).
 * @returns {{ width: number, height: number, scale: number } | null}
 */
export function fitStagePreview(frame, scaler, { pad = 0 } = {}) {
  if (!frame || !scaler) return null;
  lockPreviewStage(scaler);

  // Medir e posicionar no mesmo elemento (#stage-preview) — evita desalinhamento no Programa.
  const availW = Math.max(0, (frame.clientWidth || 0) - pad * 2);
  const availH = Math.max(0, (frame.clientHeight || 0) - pad * 2);
  if (availW < 40 || availH < 40) return null;

  const scale = Math.min(availW / DESIGN_W, availH / DESIGN_H);
  if (!Number.isFinite(scale) || scale <= 0) return null;

  const usedW = DESIGN_W * scale;
  const usedH = DESIGN_H * scale;
  scaler.style.transform = `scale(${scale})`;
  scaler.style.left = `${Math.max(0, (availW - usedW) / 2 + pad)}px`;
  scaler.style.top = `${Math.max(0, (availH - usedH) / 2 + pad)}px`;
  return { width: usedW, height: usedH, scale };
}

/** Refit explícito após mover chrome ou redimensionar coluna. */
export function refitStagePreviewContainer(container) {
  if (!container) return null;
  const scaler = container.querySelector('#preview-scaler');
  if (!scaler) return null;
  const frame = resolvePreviewFitFrame(container) || container;
  return fitStagePreview(frame, scaler);
}

/**
 * Observa o frame e refaz o fit (1 RAF, sem observar parent). Retorna dispose().
 */
export function observeStagePreviewFit(frame, scaler, options = {}) {
  let raf = 0;
  const run = () => {
    if (raf) return;
    raf = requestAnimationFrame(() => {
      raf = 0;
      fitStagePreview(frame, scaler, options);
    });
  };
  run();
  if (typeof ResizeObserver === 'undefined') {
    window.addEventListener('resize', run);
    return () => {
      if (raf) cancelAnimationFrame(raf);
      window.removeEventListener('resize', run);
    };
  }
  const obs = new ResizeObserver(run);
  obs.observe(frame);
  return () => {
    if (raf) cancelAnimationFrame(raf);
    obs.disconnect();
  };
}

export { DESIGN_W, DESIGN_H };
