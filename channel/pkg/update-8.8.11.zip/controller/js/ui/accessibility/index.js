export { trapFocus, createLiveRegion, rovingTabindex, applyHighContrast } from './a11y.js';
