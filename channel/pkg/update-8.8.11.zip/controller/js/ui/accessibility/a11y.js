const FOCUSABLE = 'a[href],button:not([disabled]),input:not([disabled]),select:not([disabled]),textarea:not([disabled]),[tabindex]:not([tabindex="-1"])';

export function trapFocus(container) {
  if (!container) return () => {};
  const getFocusable = () => [...container.querySelectorAll(FOCUSABLE)].filter((el) => el.offsetParent !== null);
  const onKey = (e) => {
    if (e.key !== 'Tab') return;
    const nodes = getFocusable();
    if (!nodes.length) return;
    const first = nodes[0];
    const last = nodes[nodes.length - 1];
    if (e.shiftKey && document.activeElement === first) {
      e.preventDefault();
      last.focus();
    } else if (!e.shiftKey && document.activeElement === last) {
      e.preventDefault();
      first.focus();
    }
  };
  container.addEventListener('keydown', onKey);
  getFocusable()[0]?.focus();
  return () => container.removeEventListener('keydown', onKey);
}

export function createLiveRegion(id = 'su-live-region') {
  let el = document.getElementById(id);
  if (!el) {
    el = document.createElement('div');
    el.id = id;
    el.className = 'su-sr-only';
    el.setAttribute('aria-live', 'polite');
    el.setAttribute('aria-atomic', 'true');
    el.style.cssText = 'position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);border:0';
    document.body.appendChild(el);
  }
  return {
    announce(msg) {
      el.textContent = '';
      requestAnimationFrame(() => { el.textContent = msg; });
    },
  };
}

export function rovingTabindex(container, itemSelector) {
  if (!container) return () => {};
  const items = () => [...container.querySelectorAll(itemSelector)];
  const sync = (active) => {
    items().forEach((el, i) => {
      el.tabIndex = el === active ? 0 : -1;
    });
  };
  const onKey = (e) => {
    const list = items();
    const idx = list.indexOf(document.activeElement);
    if (idx < 0) return;
    if (e.key === 'ArrowDown' || e.key === 'ArrowRight') {
      e.preventDefault();
      const next = list[(idx + 1) % list.length];
      next.focus();
      sync(next);
    } else if (e.key === 'ArrowUp' || e.key === 'ArrowLeft') {
      e.preventDefault();
      const prev = list[(idx - 1 + list.length) % list.length];
      prev.focus();
      sync(prev);
    }
  };
  container.addEventListener('keydown', onKey);
  sync(items()[0]);
  return () => container.removeEventListener('keydown', onKey);
}

export function applyHighContrast(on) {
  document.documentElement.classList.toggle('su-a11y-contrast', !!on);
  if (on) document.documentElement.dataset.a11yContrast = '1';
  else delete document.documentElement.dataset.a11yContrast;
}
