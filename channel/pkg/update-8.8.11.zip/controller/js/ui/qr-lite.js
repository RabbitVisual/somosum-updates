/** QR Code para URLs LAN — usa vendor/qrcode.min.js (qrcode-generator). */

let _loadPromise = null;

function ensureQrLib() {
  if (typeof globalThis.qrcode === 'function') return Promise.resolve();
  if (_loadPromise) return _loadPromise;
  _loadPromise = new Promise((resolve, reject) => {
    const existing = document.querySelector('script[data-somosum-qrcode]');
    if (existing) {
      existing.addEventListener('load', () => resolve());
      existing.addEventListener('error', () => reject(new Error('QR lib')));
      if (typeof globalThis.qrcode === 'function') resolve();
      return;
    }
    const s = document.createElement('script');
    s.src = '/vendor/qrcode.min.js';
    s.dataset.somosumQrcode = '1';
    s.onload = () => resolve();
    s.onerror = () => reject(new Error('QR lib'));
    document.head.appendChild(s);
  });
  return _loadPromise;
}

export async function drawQrToCanvas(canvas, text, { size = 0, margin = 2 } = {}) {
  if (!canvas || typeof canvas.getContext !== 'function' || !text) return;
  const px = size || canvas.width || 160;
  canvas.width = px;
  canvas.height = px;
  const ctx = canvas.getContext('2d');

  try {
    await ensureQrLib();
    const qr = globalThis.qrcode(0, 'M');
    qr.addData(text);
    qr.make();
    const n = qr.getModuleCount();
    const cell = Math.floor((px - margin * 2) / n);
    const off = Math.floor((px - cell * n) / 2);
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, px, px);
    ctx.fillStyle = '#000000';
    for (let y = 0; y < n; y++) {
      for (let x = 0; x < n; x++) {
        if (qr.isDark(y, x)) {
          ctx.fillRect(off + x * cell, off + y * cell, cell, cell);
        }
      }
    }
  } catch {
    ctx.fillStyle = '#111';
    ctx.fillRect(0, 0, px, px);
    ctx.fillStyle = '#d4c68d';
    ctx.font = '11px Segoe UI,sans-serif';
    ctx.fillText('QR indisponivel', 12, px / 2);
  }
}

/** Desenha QR em um container (cria/reusa canvas). */
export async function renderQrLite(container, text, { size = 180, margin = 2, label = '' } = {}) {
  if (!container || !text) return null;
  let canvas = container.querySelector('canvas[data-somosum-qr]');
  if (!canvas) {
    container.innerHTML = '';
    if (label) {
      const cap = document.createElement('p');
      cap.className = 'qr-lite-label';
      cap.textContent = label;
      container.appendChild(cap);
    }
    canvas = document.createElement('canvas');
    canvas.dataset.somosumQr = '1';
    canvas.width = size;
    canvas.height = size;
    canvas.setAttribute('role', 'img');
    canvas.setAttribute('aria-label', label || 'QR Code');
    container.appendChild(canvas);
  }
  await drawQrToCanvas(canvas, text, { size, margin });
  return canvas;
}
