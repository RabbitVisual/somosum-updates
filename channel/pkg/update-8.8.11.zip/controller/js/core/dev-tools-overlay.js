/**
 * Console DEV técnico — Ctrl+Shift+D (somente fora do Modo Produção).
 * Relatório copiável para colar no chat do agente e depurar.
 */
import { LogService, LogLevel, LogCategory } from './logging/log-service.js';
import { isProductionMode } from './production-mode.js';
import { getAppMeta, APP_VERSION } from './app-meta.js';
import { detectSurfaceRole, getMemorySnapshot } from './logging/log-context.js';

const STYLE = `
.somosum-dev-badge {
  position: fixed; right: 12px; bottom: 12px; z-index: 2147483000;
  min-width: 2.1rem; height: 2.1rem; padding: 0 0.55rem; border-radius: 999px;
  border: 1px solid rgba(239,68,68,.55); background: rgba(127,29,29,.94);
  color: #fecaca; font: 700 0.75rem/1 ui-sans-serif, system-ui, sans-serif; cursor: pointer;
  box-shadow: 0 8px 24px rgba(0,0,0,.5);
}
.somosum-dev-badge[hidden] { display: none !important; }
.somosum-dev-panel {
  position: fixed; inset: 4% 4%; z-index: 2147483646;
  display: flex; flex-direction: column;
  background: #0b0c0f; color: #e8eaed; border: 1px solid rgba(212,198,141,.4);
  border-radius: 12px; box-shadow: 0 28px 80px rgba(0,0,0,.7);
  font: 400 0.82rem/1.45 ui-sans-serif, system-ui, sans-serif;
}
.somosum-dev-panel[hidden] { display: none !important; }
.somosum-dev-panel__head {
  display: flex; align-items: flex-start; justify-content: space-between; gap: 0.75rem;
  padding: 0.85rem 1rem; border-bottom: 1px solid rgba(255,255,255,.08); flex-shrink: 0;
}
.somosum-dev-panel__titles h2 { margin: 0; font-size: 1rem; color: #d4c68d; }
.somosum-dev-panel__titles p { margin: 0.25rem 0 0; font-size: 0.72rem; color: #9ca3af; }
.somosum-dev-panel__actions { display: flex; gap: 0.4rem; flex-wrap: wrap; }
.somosum-dev-panel__actions button {
  border: 1px solid rgba(212,198,141,.35); background: rgba(212,198,141,.1);
  color: #d4c68d; border-radius: 8px; padding: 0.4rem 0.7rem; cursor: pointer; font: inherit;
}
.somosum-dev-panel__actions button[data-primary] {
  background: rgba(212,198,141,.22); font-weight: 650;
}
.somosum-dev-panel__tabs {
  display: flex; gap: 0.25rem; padding: 0.45rem 0.75rem 0; border-bottom: 1px solid rgba(255,255,255,.06);
  flex-shrink: 0; flex-wrap: wrap;
}
.somosum-dev-panel__tab {
  border: none; background: transparent; color: #9ca3af; padding: 0.45rem 0.75rem;
  border-radius: 8px 8px 0 0; cursor: pointer; font: inherit; font-size: 0.78rem;
}
.somosum-dev-panel__tab.is-active {
  color: #d4c68d; background: rgba(212,198,141,.1); border-bottom: 2px solid #d4c68d;
}
.somosum-dev-panel__toolbar {
  display: flex; gap: 0.5rem; align-items: center; flex-wrap: wrap;
  padding: 0.55rem 1rem; border-bottom: 1px solid rgba(255,255,255,.06); flex-shrink: 0;
}
.somosum-dev-panel__toolbar select,
.somosum-dev-panel__toolbar input {
  background: #15171c; color: #e8eaed; border: 1px solid rgba(255,255,255,.12);
  border-radius: 6px; padding: 0.3rem 0.5rem; font: inherit; font-size: 0.78rem;
}
.somosum-dev-panel__toolbar input { flex: 1; min-width: 10rem; }
.somosum-dev-panel__meta {
  margin: 0; padding: 0.35rem 1rem; font-size: 0.7rem; color: #6b7280; flex-shrink: 0;
  font-family: ui-monospace, Consolas, monospace;
}
.somosum-dev-panel__log {
  flex: 1; margin: 0; padding: 0.75rem 1rem 1rem; overflow: auto;
  white-space: pre-wrap; word-break: break-word;
  font-family: ui-monospace, Consolas, monospace; font-size: 0.72rem; color: #f3f4f6;
  background: #08090b;
}
.somosum-dev-panel__log .lvl-ERROR,
.somosum-dev-panel__log .lvl-FATAL { color: #fca5a5; }
.somosum-dev-panel__log .lvl-WARN { color: #fcd34d; }
.somosum-dev-panel__log .lvl-INFO { color: #93c5fd; }
.somosum-dev-panel__log .lvl-DEBUG,
.somosum-dev-panel__log .lvl-TRACE { color: #9ca3af; }
.somosum-dev-panel__empty { color: #6b7280; }
.somosum-dev-panel__foot {
  display: flex; justify-content: space-between; gap: 0.75rem; flex-wrap: wrap;
  padding: 0.55rem 1rem; border-top: 1px solid rgba(255,255,255,.08);
  font-size: 0.72rem; color: #9ca3af; flex-shrink: 0;
}
`;

let panelEl = null;
let badgeEl = null;
let issueCount = 0;
let activeTab = 'errors';
let filterLevel = 'WARN';
let filterText = '';
let installedModule = 'app';

function safeJson(value, max = 2500) {
  try {
    const s = JSON.stringify(value, (_, v) => {
      if (typeof v === 'string' && v.length > 400) return `${v.slice(0, 400)}…`;
      return v;
    }, 2);
    return s.length > max ? `${s.slice(0, max)}\n…(truncado)` : s;
  } catch {
    return String(value);
  }
}

function formatBytes(n) {
  if (!Number.isFinite(n)) return '—';
  if (n < 1024) return `${n} B`;
  if (n < 1048576) return `${(n / 1024).toFixed(1)} KB`;
  return `${(n / 1048576).toFixed(1)} MB`;
}

function getFilteredEntries() {
  const all = LogService.getRingBuffer();
  const levelRank = { TRACE: 0, DEBUG: 1, INFO: 2, WARN: 3, ERROR: 4, FATAL: 5 };
  const minRank = levelRank[filterLevel] ?? 3;
  let list = all.filter((e) => (levelRank[e.level] ?? 2) >= minRank);

  if (activeTab === 'errors') {
    list = list.filter((e) => e.level === 'ERROR' || e.level === 'FATAL' || e.level === 'WARN');
  } else if (activeTab === 'lyrics') {
    list = list.filter((e) => e.context?.category === 'LYRICS' || e.context?.module === 'lyrics-engine');
  } else if (activeTab === 'boot') {
    list = list.filter((e) => e.context?.category === 'BOOT' || e.context?.category === 'DATABASE');
  }

  if (filterText.trim()) {
    const q = filterText.trim().toLowerCase();
    list = list.filter((e) => {
      const blob = `${e.level} ${e.message} ${e.context?.module || ''} ${e.context?.category || ''} ${safeJson(e.detail || {})} ${e.stack || ''}`.toLowerCase();
      return blob.includes(q);
    });
  }
  return list;
}

function formatEntryBlock(entry, index) {
  const ctx = entry.context || {};
  const lines = [
    `─── #${index + 1} [${entry.level}] ${ctx.ts || ''} ───`,
    `module: ${ctx.module || '—'}`,
    `category: ${ctx.category || '—'}`,
    `surface: ${ctx.surface || '—'}`,
    `message: ${entry.message}`,
  ];
  if (entry.detail) lines.push(`detail:\n${safeJson(entry.detail)}`);
  if (entry.stack) lines.push(`stack:\n${entry.stack}`);
  if (entry.latencyMs != null) lines.push(`latencyMs: ${entry.latencyMs}`);
  if (ctx.url) lines.push(`url: ${ctx.url}`);
  return lines.join('\n');
}

function buildSystemSnapshot() {
  const meta = getAppMeta();
  const mem = getMemorySnapshot();
  const prefs = (() => {
    try {
      return JSON.parse(localStorage.getItem('somosum-prefs') || '{}');
    } catch {
      return {};
    }
  })();
  return {
    version: meta.version || APP_VERSION,
    build: meta.build,
    protocol: meta.protocol,
    assetRevision: meta.assetRevision,
    surface: detectSurfaceRole(),
    href: location.href,
    productionMode: isProductionMode(),
    prefsProductionMode: !!prefs.productionMode,
    online: navigator.onLine,
    visibility: document.visibilityState,
    memory: mem
      ? {
        used: formatBytes(mem.usedJSHeapSize),
        total: formatBytes(mem.totalJSHeapSize),
        limit: formatBytes(mem.jsHeapSizeLimit),
      }
      : null,
    userAgent: navigator.userAgent,
    ringBufferSize: LogService.getRingBuffer().length,
    issueCount,
    time: new Date().toISOString(),
  };
}

/** Relatório otimizado para colar no chat do agente Cursor. */
export function buildAgentReport() {
  const snap = buildSystemSnapshot();
  const errors = LogService.getRingBuffer().filter(
    (e) => e.level === 'ERROR' || e.level === 'FATAL' || e.level === 'WARN'
  );
  const recent = LogService.getRingBuffer().slice(-40);

  const parts = [
    '=== SOMOSUM DEV REPORT (cole isto no chat do agente) ===',
    safeJson(snap),
    '',
    `--- WARN/ERROR/FATAL (${errors.length}) ---`,
    errors.length
      ? errors.map((e, i) => formatEntryBlock(e, i)).join('\n\n')
      : '(nenhum WARN/ERROR/FATAL no buffer — se o problema for silencioso, abra a aba Logs e filtre)',
    '',
    `--- ÚLTIMOS LOGS (${recent.length}) ---`,
    recent.map((e, i) => formatEntryBlock(e, i)).join('\n\n'),
    '',
    '=== FIM DO RELATÓRIO ===',
  ];
  return parts.join('\n');
}

function renderLogView() {
  if (!panelEl) return;
  const pre = panelEl.querySelector('.somosum-dev-panel__log');
  const meta = panelEl.querySelector('.somosum-dev-panel__meta');
  if (!pre) return;

  if (activeTab === 'system') {
    pre.textContent = safeJson(buildSystemSnapshot(), 8000);
    pre.classList.remove('somosum-dev-panel__empty');
    if (meta) meta.textContent = 'Snapshot do sistema (DEV)';
    return;
  }

  if (activeTab === 'agent') {
    pre.textContent = buildAgentReport();
    pre.classList.remove('somosum-dev-panel__empty');
    if (meta) meta.textContent = 'Use «Copiar para o agente» e cole no chat';
    return;
  }

  const entries = getFilteredEntries();
  if (!entries.length) {
    pre.textContent = activeTab === 'errors'
      ? 'Nenhum WARN/ERROR ainda.\nReproduza o problema (ex.: Importar música) e clique Atualizar.\nDepois use «Copiar para o agente».'
      : 'Nenhum log neste filtro.';
    pre.classList.add('somosum-dev-panel__empty');
  } else {
    pre.textContent = entries.map((e, i) => formatEntryBlock(e, i)).join('\n\n');
    pre.classList.remove('somosum-dev-panel__empty');
  }
  if (meta) {
    meta.textContent = `${entries.length} entrada(s) · aba=${activeTab} · nível≥${filterLevel}${filterText ? ` · q="${filterText}"` : ''}`;
  }
}

async function copyText(text) {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.style.cssText = 'position:fixed;left:-9999px';
    document.body.appendChild(ta);
    ta.select();
    try {
      document.execCommand('copy');
      return true;
    } catch {
      return false;
    } finally {
      ta.remove();
    }
  }
}

function flashButton(btn, ok) {
  if (!btn) return;
  const prev = btn.textContent;
  btn.textContent = ok ? 'Copiado!' : 'Falhou — selecione o texto';
  setTimeout(() => { btn.textContent = prev; }, 1600);
}

function isPanelOpen() {
  return panelEl && panelEl.hidden === false;
}

function togglePanel(force) {
  if (!panelEl || isProductionMode()) return;
  const open = typeof force === 'boolean' ? force : !isPanelOpen();
  panelEl.hidden = !open;
  if (open) renderLogView();
}

function bumpBadge(err) {
  if (isProductionMode()) return;
  issueCount += 1;
  if (!badgeEl) return;
  badgeEl.hidden = false;
  badgeEl.textContent = issueCount > 99 ? '99+' : String(issueCount);
  badgeEl.title = `${issueCount} alerta(s) — Ctrl+Shift+D`;
  if (isPanelOpen()) renderLogView();
  if (err && typeof console !== 'undefined') {
    console.warn('[SOMOSUM:DEV] erro capturado — Ctrl+Shift+D → Copiar para o agente', err);
  }
}

function setTab(tab) {
  activeTab = tab;
  panelEl?.querySelectorAll('.somosum-dev-panel__tab').forEach((el) => {
    el.classList.toggle('is-active', el.dataset.tab === tab);
  });
  renderLogView();
}

export function isDevConsoleAllowed() {
  if (typeof document === 'undefined') return false;
  // Pacote Setup/Portable (allowInspection=false) — sem overlay/inspeção JS
  try {
    const meta = getAppMeta();
    if (meta?.allowInspection === false) return false;
  } catch { /* meta ainda não pronta */ }
  if (document.documentElement?.dataset?.productionMode === '1') return false;
  try {
    if (isProductionMode()) return false;
  } catch { /* prefs ainda não prontas */ }
  return true;
}

export function installDevToolsOverlay({ module = 'app' } = {}) {
  if (typeof window === 'undefined' || window.__somosumDevOverlay) return;
  if (!isDevConsoleAllowed()) {
    LogService.debug('Dev overlay omitido (Modo Produção)', {
      module: 'dev-tools-overlay',
      category: LogCategory.BOOT,
    });
    return;
  }

  window.__somosumDevOverlay = true;
  installedModule = module;

  // Em DEV, buffer e console aceitam DEBUG para diagnóstico profundo
  try { LogService.setMinLevel(LogLevel.DEBUG); } catch { /* ignore */ }

  if (!document.getElementById('somosum-dev-overlay-style')) {
    const style = document.createElement('style');
    style.id = 'somosum-dev-overlay-style';
    style.textContent = STYLE;
    document.head.appendChild(style);
  }

  badgeEl = document.createElement('button');
  badgeEl.type = 'button';
  badgeEl.className = 'somosum-dev-badge';
  badgeEl.hidden = true;
  badgeEl.textContent = '!';
  badgeEl.title = 'Erros detectados — Ctrl+Shift+D';
  badgeEl.addEventListener('click', () => togglePanel(true));

  panelEl = document.createElement('div');
  panelEl.className = 'somosum-dev-panel';
  panelEl.hidden = true;
  panelEl.setAttribute('role', 'dialog');
  panelEl.setAttribute('aria-label', 'Console DEV SOMOSUM');
  panelEl.innerHTML = `
    <div class="somosum-dev-panel__head">
      <div class="somosum-dev-panel__titles">
        <h2>Console DEV — ${module}</h2>
        <p>Só em desenvolvimento. Em distribuição (Modo Produção) este painel e o F12 ficam bloqueados.</p>
      </div>
      <div class="somosum-dev-panel__actions">
        <button type="button" data-primary data-copy-agent>Copiar para o agente</button>
        <button type="button" data-copy-view>Copiar aba</button>
        <button type="button" data-refresh>Atualizar</button>
        <button type="button" data-clear>Limpar contador</button>
        <button type="button" data-close>Fechar</button>
      </div>
    </div>
    <div class="somosum-dev-panel__tabs" role="tablist">
      <button type="button" class="somosum-dev-panel__tab is-active" data-tab="errors">Erros</button>
      <button type="button" class="somosum-dev-panel__tab" data-tab="logs">Logs</button>
      <button type="button" class="somosum-dev-panel__tab" data-tab="lyrics">Lyrics</button>
      <button type="button" class="somosum-dev-panel__tab" data-tab="boot">Boot</button>
      <button type="button" class="somosum-dev-panel__tab" data-tab="system">Sistema</button>
      <button type="button" class="somosum-dev-panel__tab" data-tab="agent">Relatório agente</button>
    </div>
    <div class="somosum-dev-panel__toolbar">
      <label>Nível
        <select data-level>
          <option value="DEBUG">DEBUG+</option>
          <option value="INFO">INFO+</option>
          <option value="WARN" selected>WARN+</option>
          <option value="ERROR">ERROR+</option>
        </select>
      </label>
      <input type="search" data-filter placeholder="Filtrar texto, módulo, stack…" />
    </div>
    <p class="somosum-dev-panel__meta"></p>
    <pre class="somosum-dev-panel__log somosum-dev-panel__empty"></pre>
    <div class="somosum-dev-panel__foot">
      <span>Atalho: <strong>Ctrl+Shift+D</strong> · Esc fecha</span>
      <span>Fluxo: reproduza o erro → abra o console → «Copiar para o agente» → cole no chat</span>
    </div>`;

  panelEl.querySelectorAll('[data-tab]').forEach((btn) => {
    btn.addEventListener('click', () => setTab(btn.dataset.tab));
  });
  panelEl.querySelector('[data-level]')?.addEventListener('change', (e) => {
    filterLevel = e.target.value;
    renderLogView();
  });
  panelEl.querySelector('[data-filter]')?.addEventListener('input', (e) => {
    filterText = e.target.value || '';
    renderLogView();
  });
  panelEl.querySelector('[data-copy-agent]')?.addEventListener('click', async () => {
    const ok = await copyText(buildAgentReport());
    flashButton(panelEl.querySelector('[data-copy-agent]'), ok);
  });
  panelEl.querySelector('[data-copy-view]')?.addEventListener('click', async () => {
    const pre = panelEl.querySelector('.somosum-dev-panel__log');
    const ok = await copyText(pre?.textContent || '');
    flashButton(panelEl.querySelector('[data-copy-view]'), ok);
  });
  panelEl.querySelector('[data-refresh]')?.addEventListener('click', renderLogView);
  panelEl.querySelector('[data-clear]')?.addEventListener('click', () => {
    issueCount = 0;
    if (badgeEl) {
      badgeEl.hidden = true;
      badgeEl.textContent = '!';
    }
  });
  panelEl.querySelector('[data-close]')?.addEventListener('click', () => togglePanel(false));

  document.body.appendChild(badgeEl);
  document.body.appendChild(panelEl);

  window.addEventListener('keydown', (e) => {
    if (isProductionMode()) return;
    if (e.ctrlKey && e.shiftKey && (e.key === 'D' || e.key === 'd')) {
      e.preventDefault();
      togglePanel();
    }
    if (e.key === 'Escape' && isPanelOpen()) togglePanel(false);
  });

  // Badge sobe em qualquer WARN/ERROR do LogService (inclui error-boundary)
  LogService.onSignificant(() => bumpBadge());

  // Expõe helpers para o console F12 em DEV
  window.SOMOSUM_DEV = {
    open: () => togglePanel(true),
    report: buildAgentReport,
    copyReport: async () => copyText(buildAgentReport()),
    logs: () => LogService.getRingBuffer(),
    snapshot: buildSystemSnapshot,
  };

  LogService.debug(`Dev console instalado (${module}) — Ctrl+Shift+D`, {
    module: 'dev-tools-overlay',
    category: LogCategory.BOOT,
    detail: { surface: installedModule },
  });
}

/** Remove overlay se Modo Produção for ativado em runtime. */
export function tearDownDevToolsOverlay() {
  try {
    panelEl?.remove();
    badgeEl?.remove();
    document.getElementById('somosum-dev-overlay-style')?.remove();
  } catch { /* ignore */ }
  panelEl = null;
  badgeEl = null;
  window.__somosumDevOverlay = false;
  try { delete window.SOMOSUM_DEV; } catch { /* ignore */ }
  try { LogService.setMinLevel(LogLevel.INFO); } catch { /* ignore */ }
}
