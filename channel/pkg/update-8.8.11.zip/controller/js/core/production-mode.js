/**
 * Modo Produção — otimizações e endurecimento para culto ao vivo.
 */
import { getPrefs, savePrefs } from './store.js';
import { LogService } from './logging/log-service.js';
import { TaskScheduler } from './task-scheduler.js';
import { TaskIds } from './task-registry.js';

const PRODUCTION_DEFAULTS = {
  verboseLogs: false,
  maxCache: true,
  recoveryMax: true,
  watchdogFull: true,
  autoBackup: true,
  autoBackupIntervalHours: 4,
  integrityCheckOnBoot: true,
  integrityCheckIntervalMin: 30,
  blockDestructiveDuringLive: true,
};

let timers = { backup: null, integrity: null };

/** Propaga o Production Mode ao Somosum.Engine (componentes dev desativados no nativo). */
function syncEngineProductionMode(enabled) {
  try {
    window.Engine?.runtime?.executeJson?.(JSON.stringify({
      type: 'SetProductionModeCommand',
      source: 'production-mode',
      priority: 'High',
      payload: { enabled: !!enabled },
    }));
  } catch { /* engine indisponível — modo aplicado localmente */ }
}

export function isProductionMode() {
  return getPrefs().productionMode === true;
}

export function getProductionConfig() {
  const prefs = getPrefs();
  return { ...PRODUCTION_DEFAULTS, ...(prefs.production || {}) };
}

export function enableProductionMode(extra = {}) {
  const merged = savePrefs({
    productionMode: true,
    production: { ...PRODUCTION_DEFAULTS, ...getProductionConfig(), ...extra },
  });
  applyProductionRuntime();
  try {
    import('./dev-tools-overlay.js').then(({ tearDownDevToolsOverlay }) => {
      tearDownDevToolsOverlay();
    }).catch(() => {});
  } catch { /* ignore */ }
  return merged;
}

export async function disableProductionMode() {
  const merged = savePrefs({ productionMode: false });
  clearProductionTimers();
  syncEngineProductionMode(false);
  try {
    const { WatchdogHub } = await import('./watchdog/watchdog-hub.js');
    WatchdogHub.getInstance().stop();
  } catch { /* ignore */ }
  try {
    const { MemoryProfiler } = await import('./memory/memory-profiler.js');
    MemoryProfiler.stop?.();
  } catch { /* ignore */ }
  document.documentElement.removeAttribute('data-production-mode');
  delete window.__SOMOSUM_PRODUCTION_CACHE_MAX;
  delete window.__SOMOSUM_RECOVERY_MAX;
  LogService.setMinLevel('INFO');
  // Espelha só WARN+ no console (INFO de LYRICS/PERFORMANCE fica no ring buffer).
  LogService.setConsoleMirror(true, { minLevel: 'WARN' });
  try {
    const { ImageCache, VideoCache } = await import('../render/asset-cache.js');
    ImageCache._maxSize = 80;
    VideoCache._maxSize = 12;
  } catch { /* ignore */ }
  try {
    const { installDevToolsOverlay } = await import('./dev-tools-overlay.js');
    installDevToolsOverlay({ module: 'control' });
  } catch { /* ignore */ }
  return merged;
}

export async function applyProductionRuntime() {
  if (!isProductionMode()) return;
  const cfg = getProductionConfig();
  LogService.setMinLevel('WARN');
  LogService.setConsoleMirror(false);
  document.documentElement.dataset.productionMode = '1';
  syncEngineProductionMode(true);

  if (cfg.maxCache) {
    window.__SOMOSUM_PRODUCTION_CACHE_MAX = true;
    try {
      const { ImageCache, VideoCache } = await import('../render/asset-cache.js');
      const live = !!window.__SOMOSUM_LIVE_ACTIVE;
      ImageCache._maxSize = live ? 20 : 60;
      VideoCache._maxSize = live ? 4 : 12;
    } catch { /* ignore */ }
  }

  if (cfg.recoveryMax) {
    window.__SOMOSUM_RECOVERY_MAX = true;
    try {
      const { CheckpointRecovery } = await import('./recovery/checkpoint-recovery.js');
      CheckpointRecovery.setIntervalMs?.(2 * 60 * 1000);
    } catch { /* ignore */ }
  }

  if (cfg.watchdogFull && isProductionMode()) {
    try {
      const { WatchdogHub } = await import('./watchdog/watchdog-hub.js');
      await WatchdogHub.getInstance().start();
    } catch { /* ignore */ }
  }

  startProductionSchedulers();

  try {
    const { MemoryProfiler } = await import('./memory/memory-profiler.js');
    MemoryProfiler.start?.({ liveIntervalMs: 60000, idleIntervalMs: 30000 });
    const { LeakDetector } = await import('./memory/leak-detector.js');
    LeakDetector.start?.();
    const { AutoCleanup } = await import('./memory/auto-cleanup.js');
    AutoCleanup.start?.();
    const { AnalyzerHub } = await import('./analyzers/analyzer-hub.js');
    AnalyzerHub.start?.();
  } catch { /* optional enterprise modules */ }
}

export function canRunDestructiveOp({ live = false } = {}) {
  if (!isProductionMode()) return true;
  const cfg = getProductionConfig();
  if (cfg.blockDestructiveDuringLive && live) return false;
  return true;
}

async function runAutoBackup() {
  if (window.__SOMOSUM_LIVE_ACTIVE) return;
  try {
    const { BackupManager } = await import('./backup/backup-manager.js');
    await BackupManager.runIncremental();
  } catch { /* silent in production */ }
}

async function runIntegrityCheck() {
  if (window.__SOMOSUM_LIVE_ACTIVE) return;
  try {
    const start = await fetch('/api/storage/integrity?async=1', { cache: 'no-store' });
    if (!start.ok) return;
    const data = await start.json();
    if (!data?.jobId) return;
    const jobId = data.jobId;
    const poll = async () => {
      for (let i = 0; i < 120; i++) {
        await new Promise((r) => setTimeout(r, 500));
        const res = await fetch(`/api/storage/integrity?job=${jobId}`, { cache: 'no-store' });
        if (res.status === 200) return;
        if (res.status !== 202) break;
      }
    };
    void poll().catch(() => {});
  } catch { /* */ }
}

function clearProductionTimers() {
  TaskScheduler.unregister(TaskIds.PRODUCTION_BACKUP);
  TaskScheduler.unregister(TaskIds.PRODUCTION_INTEGRITY);
  timers = { backup: null, integrity: null };
}

function startProductionSchedulers() {
  clearProductionTimers();
  const cfg = getProductionConfig();
  if (cfg.autoBackup) {
    const ms = Math.max(1, cfg.autoBackupIntervalHours) * 3600000;
    TaskScheduler.register({
      id: TaskIds.PRODUCTION_BACKUP,
      kind: 'interval',
      intervalMs: ms,
      priority: 10,
      fn: () => runAutoBackup(),
    });
    setTimeout(runAutoBackup, 60000);
  }
  if (cfg.integrityCheckOnBoot) {
    setTimeout(runIntegrityCheck, window.__SOMOSUM_LIVE_ACTIVE ? 300000 : 0);
    if (cfg.integrityCheckIntervalMin > 0) {
      TaskScheduler.register({
        id: TaskIds.PRODUCTION_INTEGRITY,
        kind: 'interval',
        intervalMs: cfg.integrityCheckIntervalMin * 60000,
        priority: 10,
        fn: () => runIntegrityCheck(),
      });
    }
  }
}
