/** Reinicio suave do servidor HTTP (Kestrel in-process) — SOMOSUM.exe permanece ativo. */

import { resetServerCache, waitForServer } from './storage/adapters/server-adapter.js';

export async function requestSoftRestart(timeoutMs = 90000) {
  resetServerCache();
  if (window.Engine?.shell?.restartServer) {
    try {
      window.Engine.shell.restartServer();
    } catch { /* fallback abaixo */ }
  } else {
    try {
      await fetch('/api/restart-worker', { cache: 'no-store', signal: AbortSignal.timeout(5000) });
    } catch {
      try {
        await fetch('/api/shutdown', { cache: 'no-store', signal: AbortSignal.timeout(5000) });
      } catch { /* supervisor reinicia */ }
    }
  }

  const deadline = Date.now() + timeoutMs;
  let streak = 0;
  while (Date.now() < deadline) {
    await new Promise((r) => setTimeout(r, 500));
    resetServerCache();
    const ok = await waitForServer(1, 0);
    if (ok) {
      streak += 1;
      if (streak >= 2) return true;
    } else {
      streak = 0;
    }
  }
  return false;
}
