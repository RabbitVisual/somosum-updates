/**
 * TaskScheduler — loop central por superfície.
 * Substitui setInterval/requestAnimationFrame permanentes dispersos.
 */

const tasks = new Map();
let running = false;
let masterTimer = null;
let rafId = null;
let idleId = null;
let lastActivity = Date.now();
let schedulerMode = 'active';

function getRuntimeClient() {
  if (typeof window === 'undefined') return null;
  return window.__SOMOSUM_RUNTIME__ || null;
}

function proxyTaskRegistration(spec) {
  const rt = getRuntimeClient();
  if (!rt?.registerTaskMetadata) return;
  try {
    rt.registerTaskMetadata(spec);
  } catch { /* ignore */ }
}

function proxyTaskUnregistration(id) {
  const rt = getRuntimeClient();
  if (!rt?.unregisterTaskMetadata) return;
  try {
    rt.unregisterTaskMetadata(id);
  } catch { /* ignore */ }
}

function proxySchedulerMode(mode) {
  const rt = getRuntimeClient();
  if (!rt?.setBridgeMode) return;
  try {
    rt.setBridgeMode(mode);
  } catch { /* ignore */ }
}

const BACKGROUND_PAUSED_IDS = new Set([
  'health-probe',
  'watchdog-cycle',
  'stage-central-refresh',
  'production-integrity',
  'production-backup',
  'diagnostics-reanalyze',
  'panel-status',
]);

const metrics = {
  activeTasks: 0,
  lastOverrunMs: 0,
  totalRuns: 0,
  tickMs: 16,
  mode: 'active',
  rafActive: false,
};

function sortByPriority(a, b) {
  return (a.priority ?? 5) - (b.priority ?? 5);
}

function touchActivity() {
  lastActivity = Date.now();
}

function computeTickMs() {
  if (schedulerMode === 'hidden') return 1000;
  if (typeof document !== 'undefined' && document.hidden) return 1000;
  if (Date.now() - lastActivity > 30000) return 250;
  return 16;
}

function hasRafTasks() {
  return [...tasks.values()].some((t) => t.enabled && t.kind === 'raf');
}

function runTask(task) {
  if (task.coalesce !== false && task._running) return;
  task._running = true;
  const start = performance.now();
  try {
    const result = task.fn();
    if (result && typeof result.then === 'function') {
      result
        .catch((err) => {
          import('./logging/log-context.js').then(({ isBenignAbort }) => {
            if (isBenignAbort(err)) return;
            import('./logging/log-service.js').then(({ LogService, LogCategory }) => {
              LogService.debug('TaskScheduler rejeitou tarefa', {
                module: 'task-scheduler',
                category: LogCategory.PERFORMANCE,
                err,
                detail: { taskId: task.id },
              });
            }).catch(() => {});
          }).catch(() => {});
        })
        .finally(() => { task._running = false; });
    } else {
      task._running = false;
    }
  } catch {
    task._running = false;
  }
  task.lastRun = performance.now();
  task.runCount = (task.runCount || 0) + 1;
  metrics.totalRuns += 1;
  const elapsed = performance.now() - start;
  if (elapsed > 16) {
    metrics.lastOverrunMs = elapsed;
    try {
      window.dispatchEvent(new CustomEvent('somosum-frame-over-budget', { detail: { elapsed, taskId: task.id } }));
    } catch { /* ignore */ }
  }
}

function isTaskRunnable(task) {
  if (!task.enabled) return false;
  if (schedulerMode === 'background' && BACKGROUND_PAUSED_IDS.has(task.id)) return false;
  if (typeof document !== 'undefined' && document.hidden && !task.runWhenHidden) return false;
  return true;
}

function runDueIntervalTasks() {
  const now = performance.now();
  const due = [...tasks.values()]
    .filter((t) => t.kind === 'interval' && isTaskRunnable(t))
    .sort(sortByPriority);
  for (const task of due) {
    const interval = task.intervalMs ?? 1000;
    if (task.lastRun != null && now - task.lastRun < interval) continue;
    runTask(task);
    // NÃO touchActivity aqui — poll/heartbeat mantinha tick em 16ms para sempre
  }
}

function rafLoop() {
  if (!running) return;
  const rafTasks = [...tasks.values()]
    .filter((t) => isTaskRunnable(t) && t.kind === 'raf')
    .sort(sortByPriority);
  for (const task of rafTasks) {
    runTask(task);
  }
  if (hasRafTasks()) {
    rafId = requestAnimationFrame(rafLoop);
    metrics.rafActive = true;
  } else {
    rafId = null;
    metrics.rafActive = false;
  }
}

function ensureRafLoop() {
  if (!running || rafId != null) return;
  if (hasRafTasks()) rafLoop();
}

function stopRafLoop() {
  if (rafId != null) cancelAnimationFrame(rafId);
  rafId = null;
  metrics.rafActive = false;
}

function hasIdleTasks() {
  return [...tasks.values()].some((t) => t.enabled && t.kind === 'idle');
}

function scheduleIdleTasks() {
  if (!running || typeof requestIdleCallback !== 'function') return;
  if (!hasIdleTasks()) {
    idleId = null;
    return;
  }
  idleId = requestIdleCallback((deadline) => {
    const idleTasks = [...tasks.values()]
      .filter((t) => isTaskRunnable(t) && t.kind === 'idle')
      .sort(sortByPriority);
    for (const task of idleTasks) {
      if (deadline.timeRemaining() <= 2 && !deadline.didTimeout) break;
      runTask(task);
    }
    if (hasIdleTasks()) scheduleIdleTasks();
    else idleId = null;
  }, { timeout: 2000 });
}

function masterLoop() {
  if (!running) return;
  metrics.tickMs = computeTickMs();
  metrics.mode = schedulerMode;
  runDueIntervalTasks();
  ensureRafLoop();
  masterTimer = setTimeout(masterLoop, metrics.tickMs);
}

function cancelIdle() {
  if (idleId != null && typeof cancelIdleCallback === 'function') {
    cancelIdleCallback(idleId);
  }
  idleId = null;
}

export const TaskScheduler = {
  register(spec) {
    if (!spec?.id || typeof spec.fn !== 'function') return () => {};
    const task = {
      id: spec.id,
      kind: spec.kind || 'interval',
      intervalMs: spec.intervalMs ?? 1000,
      priority: spec.priority ?? 5,
      runWhenHidden: spec.runWhenHidden === true,
      coalesce: spec.coalesce !== false,
      fn: spec.fn,
      enabled: true,
      lastRun: null,
      _running: false,
      runCount: 0,
    };
    tasks.set(spec.id, task);
    metrics.activeTasks = tasks.size;
    touchActivity();
    proxyTaskRegistration(task);
    if (spec.kind === 'once') {
      runTask(task);
      tasks.delete(spec.id);
      metrics.activeTasks = tasks.size;
    } else if (spec.kind === 'raf') {
      ensureRafLoop();
    } else if (spec.kind === 'idle') {
      if (idleId == null) scheduleIdleTasks();
    }
    return () => this.unregister(spec.id);
  },

  unregister(id) {
    proxyTaskUnregistration(id);
    tasks.delete(id);
    metrics.activeTasks = tasks.size;
    if (!hasRafTasks()) stopRafLoop();
  },

  pause(id) {
    const t = tasks.get(id);
    if (t) t.enabled = false;
    if (!hasRafTasks()) stopRafLoop();
  },

  resume(id) {
    const t = tasks.get(id);
    if (t) {
      t.enabled = true;
      t.lastRun = null;
    }
    ensureRafLoop();
  },

  pauseTask(id) { this.pause(id); },
  resumeTask(id) { this.resume(id); },

  setIntervalMs(id, ms) {
    const t = tasks.get(id);
    if (t && ms > 0) t.intervalMs = ms;
  },

  setMode(mode = 'active') {
    schedulerMode = mode === 'background' || mode === 'hidden' ? mode : 'active';
    metrics.mode = schedulerMode;
    proxySchedulerMode(schedulerMode);
    if (mode === 'hidden') {
      BACKGROUND_PAUSED_IDS.forEach((id) => this.pause(id));
    } else if (mode === 'background') {
      BACKGROUND_PAUSED_IDS.forEach((id) => this.pause(id));
    } else {
      BACKGROUND_PAUSED_IDS.forEach((id) => this.resume(id));
    }
  },

  getMode() {
    return schedulerMode;
  },

  start() {
    if (running) return;
    running = true;
    schedulerMode = 'active';
    lastActivity = Date.now();
    proxySchedulerMode('active');
    masterLoop();
    scheduleIdleTasks();
    if (typeof document !== 'undefined') {
      document.addEventListener('visibilitychange', touchActivity, { passive: true });
      window.addEventListener('pointerdown', touchActivity, { passive: true, once: false });
      window.addEventListener('keydown', touchActivity, { passive: true, once: false });
    }
  },

  stop() {
    running = false;
    schedulerMode = 'active';
    proxySchedulerMode('active');
    clearTimeout(masterTimer);
    masterTimer = null;
    stopRafLoop();
    cancelIdle();
  },

  getActiveTasks() {
    return [...tasks.values()].map((t) => ({
      id: t.id,
      kind: t.kind,
      intervalMs: t.intervalMs,
      priority: t.priority,
      enabled: t.enabled,
      runCount: t.runCount,
    }));
  },

  getMetrics() {
    return { ...metrics, activeTasks: tasks.size };
  },

  waitFor(predicate, maxMs = 2000, stepMs = 16) {
    return new Promise((resolve) => {
      const start = Date.now();
      const tick = () => {
        if (predicate()) return resolve(true);
        if (Date.now() - start >= maxMs) return resolve(false);
        setTimeout(tick, stepMs);
      };
      tick();
    });
  },

  scheduleFrame(fn) {
    return new Promise((resolve) => {
      requestAnimationFrame(() => {
        const result = fn();
        resolve(result);
      });
    });
  },

  scheduleDelayed(id, delayMs, fn, priority = 5) {
    if (!id || typeof fn !== 'function') return () => {};
    this.unregister(id);
    if (delayMs <= 0) {
      try { fn(); } catch { /* task */ }
      return () => {};
    }
    const due = Date.now() + delayMs;
    const tick = Math.min(250, Math.max(16, delayMs));
    return this.register({
      id,
      kind: 'interval',
      intervalMs: tick,
      priority,
      runWhenHidden: true,
      coalesce: true,
      fn: () => {
        if (Date.now() >= due) {
          this.unregister(id);
          fn();
        }
      },
    });
  },
};

if (typeof window !== 'undefined') {
  window.__SOMOSUM_TASK_SCHEDULER__ = TaskScheduler;
}
