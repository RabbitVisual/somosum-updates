import { getPrefs, saveNavigationState } from './store.js';
import { saveCultoIndex } from '../program/culto-manager.js';

export function resolveActiveCultoId(cultoIndex, prefsNav) {
  const diskId = cultoIndex?.activeId || null;
  const prefsId = prefsNav?.activeCultoId || null;
  const cultos = cultoIndex?.cultos || [];
  if (!diskId && !prefsId) return null;
  if (diskId && prefsId && diskId === prefsId) return diskId;
  const diskValid = diskId && cultos.some((c) => c.id === diskId);
  const prefsValid = prefsId && cultos.some((c) => c.id === prefsId);
  if (diskValid) return diskId;
  if (prefsValid) return prefsId;
  return cultos[0]?.id || null;
}

export async function syncActiveCultoConfig(cultoIndex) {
  const prefs = getPrefs();
  const resolved = resolveActiveCultoId(cultoIndex, prefs.navigation);
  if (!resolved) return cultoIndex;
  const next = { ...cultoIndex, activeId: resolved };
  if (prefs.navigation?.activeCultoId !== resolved) {
    saveNavigationState({ activeCultoId: resolved });
  }
  if (cultoIndex.activeId !== resolved) {
    await saveCultoIndex(next);
  }
  return next;
}
