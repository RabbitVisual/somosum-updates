import { resetServerCache, waitForServer } from './storage/adapters/server-adapter.js';
import { TaskScheduler } from './task-scheduler.js';
import { TaskIds } from './task-registry.js';

let globalMonitor = null;

export class HealthMonitor {
  constructor(app) {
    this.app = app;
    this.intervalId = null;
    this.failCount = 0;
    this.lastOk = true;
    this.everOk = false;
    this.offlineNotified = false;
    this.paused = false;
    this.checkIntervalMs = 8000;
    this.bootGraceUntil = Date.now() + 90000;
    this._reconnecting = false;
    this.projectionOk = false;
    this.syncOk = true;
    this.syncLatencyMs = null;
    this.savePending = false;
    this.programDirty = false;
    this.loadGraceUntil = 0;
    this._okStreak = 0;
  }

  pause() {
    this.paused = true;
  }

  resume() {
    this.paused = false;
  }

  /** Evita falsos "ocupado/offline" enquanto a projeção ou muitos assets carregam. */
  beginLoadGrace(ms = 90000) {
    this.loadGraceUntil = Date.now() + ms;
    this.paused = true;
    this.failCount = Math.min(this.failCount, 2);
    this.updateServerBadge(this.lastOk);
  }

  endLoadGrace() {
    this.loadGraceUntil = 0;
    this.paused = false;
    this.failCount = Math.min(this.failCount, 2);
  }

  setProjectionStatus(connected) {
    this.projectionOk = !!connected;
    this.updateProjectionBadge();
  }

  setSyncStatus(status, latencyMs = null) {
    this.syncOk = status === 'ok';
    this.syncLatencyMs = latencyMs;
    this.updateSyncBadge();
  }

  setSavePending(pending) {
    this.savePending = !!pending;
    this.updateSaveBadge();
  }

  setProgramDirty(dirty) {
    this.programDirty = !!dirty;
    this.updateSaveBadge();
  }

  start(intervalMs = 10000, { initialDelayMs = 6000 } = {}) {
    this.checkIntervalMs = intervalMs;
    this.stop();
    const run = async () => {
      if (this.paused) return;
      await this.check();
      let delay;
      if (this.lastOk && this.failCount === 0) {
        delay = this._okStreak >= 4 ? 60000 : this.checkIntervalMs;
      } else {
        delay = this.lastOk
          ? this.checkIntervalMs
          : Math.min(30000, this.checkIntervalMs + this.failCount * 2000);
      }
      TaskScheduler.setIntervalMs(TaskIds.HEALTH_PROBE, delay);
    };
    this._healthDispose = TaskScheduler.register({
      id: TaskIds.HEALTH_PROBE,
      kind: 'interval',
      intervalMs: initialDelayMs,
      priority: 8,
      fn: run,
    });
    globalMonitor = this;
  }

  scheduleNext(_delayMs) {
    /* legado — noop; intervalo ajustado em start()/run */
  }

  stop() {
    this._healthDispose?.();
    this._healthDispose = null;
    TaskScheduler.unregister(TaskIds.HEALTH_PROBE);
    if (globalMonitor === this) globalMonitor = null;
  }

  async tryReconnect() {
    if (this._reconnecting) return false;
    this._reconnecting = true;
    try {
      resetServerCache();
      return await waitForServer(15, 500);
    } finally {
      this._reconnecting = false;
    }
  }

  markBootOk() {
    this.failCount = 0;
    this.everOk = true;
    this.lastOk = true;
    this.offlineNotified = false;
    this.updateServerBadge(true);
  }

  async check() {
    if (this.paused) return;
    if (this.loadGraceUntil && Date.now() < this.loadGraceUntil) return;

    let ok = false;
    let saveQueue = 0;
    const pingMs = this.failCount >= 3 ? 10000 : 6000;
    try {
      const res = await fetch('/api/ping', { cache: 'no-store', signal: AbortSignal.timeout(pingMs) });
      ok = res.ok;
      if (ok) {
        try {
          const healthRes = await fetch('/api/health', { cache: 'no-store', signal: AbortSignal.timeout(3000) });
          if (healthRes.ok) {
            const health = await healthRes.json();
            saveQueue = health.saveQueue || 0;
          }
        } catch { /* ignore */ }
      }
    } catch {
      ok = false;
    }

    if (!ok && this.savePending && this.failCount < 8) {
      ok = true;
    }

    if (!ok && this.loadGraceUntil && Date.now() < this.loadGraceUntil + 5000) {
      return;
    }

    if (!ok && this.failCount >= 3 && this.failCount < 10) {
      ok = await this.tryReconnect();
    }

    if (!ok) this.failCount += 1;
    this.updateServerBadge(ok);

    if (ok) {
      this._okStreak += 1;
      const wasSustainedOffline = this.offlineNotified || this.failCount >= 10;
      this.failCount = 0;
      this.everOk = true;
      const wasOffline = !this.lastOk && wasSustainedOffline;
      this.lastOk = true;
      this.offlineNotified = false;
      if (wasOffline && this.everOk) {
        this.app?.onServerOnline?.();
      }
      return;
    }

    this.lastOk = false;
    this._okStreak = 0;

    const pastGrace = Date.now() > this.bootGraceUntil;
    const sustainedOffline = this.failCount >= 10;
    if (pastGrace && this.everOk && sustainedOffline && !this.offlineNotified) {
      this.offlineNotified = true;
      this.app?.onServerOffline?.(this.failCount);
    }
  }

  updateServerBadge(ok) {
    const inLoadGrace = this.loadGraceUntil && Date.now() < this.loadGraceUntil;
    if (inLoadGrace && !ok) {
      ok = true;
    }
    const warn = !ok && this.failCount >= 10;
    const softWarn = !ok && this.failCount >= 6 && this.failCount < 10;
    const text = ok ? 'Servidor OK' : (warn ? 'Reconectando…' : (softWarn ? 'Ocupado…' : 'Verificando…'));
    const badge = document.getElementById('server-health');
    if (badge) {
      badge.textContent = text;
      badge.classList.toggle('is-offline', warn);
      badge.title = ok
        ? 'Servidor local respondendo'
        : (warn ? 'Servidor ocupado ou reiniciando' : (softWarn ? 'Gravando dados — aguarde' : 'Verificando servidor…'));
    }
    const dot = document.getElementById('health-indicator');
    if (dot) {
      dot.title = badge?.title || text;
      dot.className = `health-indicator health-indicator--${ok ? 'ok' : (warn ? 'warn' : 'idle')}`;
      dot.textContent = '●';
    }
    this.updateUnifiedPanel();
  }

  updateProjectionBadge() {
    const el = document.getElementById('projection-health');
    if (!el) return;
    el.textContent = this.projectionOk ? 'Projeção OK' : 'Aguardando tela';
    el.classList.toggle('is-offline', !this.projectionOk);
    el.title = this.projectionOk ? 'Tela de projeção conectada' : 'Abra screen.html no projetor';
    this.updateUnifiedPanel();
  }

  updateSyncBadge() {
    const el = document.getElementById('sync-health');
    if (!el) return;
    if (this.syncLatencyMs != null && this.syncOk) {
      el.textContent = `Sync ${this.syncLatencyMs}ms`;
    } else if (this.syncOk) {
      el.textContent = 'Sync OK';
    } else {
      el.textContent = 'Re-sincronizando';
    }
    el.classList.toggle('is-offline', !this.syncOk);
    this.updateUnifiedPanel();
  }

  updateSaveBadge() {
    const el = document.getElementById('save-health');
    if (!el) return;
    if (this.savePending) {
      el.textContent = 'Salvando…';
      el.classList.add('is-pending');
      el.classList.remove('is-dirty');
    } else if (this.programDirty) {
      el.textContent = 'Não salvo';
      el.classList.remove('is-pending');
      el.classList.add('is-dirty');
    } else {
      el.textContent = 'Salvo';
      el.classList.remove('is-pending', 'is-dirty');
    }
    this.updateUnifiedPanel();
  }

  updateUnifiedPanel() {
    const panel = document.getElementById('status-unified');
    if (!panel) return;
    if (this.lastOk && this.projectionOk) {
      panel.textContent = '● Sistema OK';
      panel.dataset.state = 'ok';
    } else if (!this.lastOk) {
      panel.textContent = '● Servidor…';
      panel.dataset.state = 'warn';
    } else {
      panel.textContent = '● Sem projeção';
      panel.dataset.state = 'idle';
    }
    panel.title = [
      this.lastOk ? 'Servidor OK' : 'Servidor ocupado',
      this.projectionOk ? 'Projeção conectada' : 'Projeção aguardando',
      this.syncOk ? (this.syncLatencyMs != null ? `Sync ${this.syncLatencyMs}ms` : 'Sync OK') : 'Sync…',
      this.savePending ? 'Salvando…' : (this.programDirty ? 'Não salvo' : 'Salvo'),
    ].join(' · ');
  }
}

export function startHealthMonitor({ onStatusChange, intervalMs = 8000 } = {}) {
  const mon = new HealthMonitor({
    onServerOffline: (failCount) => onStatusChange?.(false, failCount),
    onServerOnline: () => onStatusChange?.(true),
  });
  mon.start(intervalMs);
  return mon;
}

export function stopHealthMonitor() {
  globalMonitor?.stop();
}

export function pauseHealthMonitor() {
  globalMonitor?.pause();
}

export function resumeHealthMonitor() {
  globalMonitor?.resume();
}

export function isServerHealthy() {
  return globalMonitor ? globalMonitor.lastOk : true;
}

export function setProjectionHealth(connected) {
  globalMonitor?.setProjectionStatus(connected);
}

export function setSyncHealth(status, latencyMs) {
  globalMonitor?.setSyncStatus(status, latencyMs);
}

export function setSavePending(pending) {
  globalMonitor?.setSavePending(pending);
}

export function setProgramDirty(dirty) {
  globalMonitor?.setProgramDirty(dirty);
}

export function beginLoadGrace(ms = 90000) {
  globalMonitor?.beginLoadGrace(ms);
}

export function endLoadGrace() {
  globalMonitor?.endLoadGrace();
}
