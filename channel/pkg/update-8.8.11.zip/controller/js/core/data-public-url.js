/** URL pública para leitura de arquivos allowlisted em data/ (substitui /data/ direto). */
export function dataPublicUrl(relativePath) {
  const rel = String(relativePath || '').replace(/^\/+/, '').replace(/^data\//, '');
  if (!rel || rel.includes('..')) return '';
  return `/api/data/${rel}`;
}
