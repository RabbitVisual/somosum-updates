/**
 * History stack — undo/redo genérico por editor.
 */
export class HistoryStack {
  constructor(limit = 50) {
    this.limit = limit;
    this.stack = [];
    this.index = -1;
  }

  push(snapshot) {
    const clone = typeof structuredClone === 'function'
      ? structuredClone(snapshot)
      : JSON.parse(JSON.stringify(snapshot));
    this.stack = this.stack.slice(0, this.index + 1);
    this.stack.push(clone);
    if (this.stack.length > this.limit) this.stack.shift();
    this.index = this.stack.length - 1;
  }

  canUndo() { return this.index > 0; }
  canRedo() { return this.index < this.stack.length - 1; }

  undo() {
    if (!this.canUndo()) return null;
    this.index -= 1;
    return this.stack[this.index];
  }

  redo() {
    if (!this.canRedo()) return null;
    this.index += 1;
    return this.stack[this.index];
  }

  clear() {
    this.stack = [];
    this.index = -1;
  }
}

/** Bind Ctrl+Z / Ctrl+Y on an element scope (document by default). */
export function bindHistoryHotkeys(history, { onUndo, onRedo, target = document } = {}) {
  const handler = (e) => {
    if (!(e.ctrlKey || e.metaKey)) return;
    const key = e.key.toLowerCase();
    if (key === 'z' && !e.shiftKey) {
      e.preventDefault();
      const snap = history.undo();
      if (snap != null) onUndo?.(snap);
    } else if (key === 'y' || (key === 'z' && e.shiftKey)) {
      e.preventDefault();
      const snap = history.redo();
      if (snap != null) onRedo?.(snap);
    }
  };
  target.addEventListener('keydown', handler);
  return () => target.removeEventListener('keydown', handler);
}
