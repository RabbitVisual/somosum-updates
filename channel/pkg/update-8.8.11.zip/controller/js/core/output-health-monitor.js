/**
 * Output Health Monitor — ack latency, vídeo persistente, revision.
 * Polling só para health/recovery (Projetor.md Fase 5).
 */
export function createOutputHealthMonitor({ getEngine, onUnhealthy } = {}) {
  let lastAckAt = 0;
  let lastRevision = 0;
  let timer = null;
  let lastUnhealthyAt = 0;

  const snapshot = () => {
    const engine = typeof getEngine === 'function' ? getEngine() : null;
    const video = engine?.lyricsBgPersistEl?.querySelector?.('video');
    const videoOk = !video
      || (!video.error && !video.paused && video.readyState >= 2);
    const ackAge = lastAckAt ? Date.now() - lastAckAt : null;
    return {
      lastAckAt,
      lastRevision,
      ackAgeMs: ackAge,
      videoPaused: !!video?.paused,
      videoError: !!video?.error,
      videoOk,
      overlay: engine?.overlay || null,
      slideType: engine?.currentSlide?.type || null,
      healthy: videoOk && (ackAge == null || ackAge < 8000),
    };
  };

  const noteAck = (revision = null) => {
    lastAckAt = Date.now();
    if (revision != null) lastRevision = Number(revision) || lastRevision;
  };

  const noteRevision = (revision) => {
    if (revision != null) lastRevision = Number(revision) || lastRevision;
  };

  const tick = () => {
    const s = snapshot();
    if (!s.healthy && Date.now() - lastUnhealthyAt > 4000) {
      lastUnhealthyAt = Date.now();
      try { onUnhealthy?.(s); } catch { /* ignore */ }
      // Auto-revive vídeo sem wait de recovery 3s
      const engine = typeof getEngine === 'function' ? getEngine() : null;
      const video = engine?.lyricsBgPersistEl?.querySelector?.('video');
      if (video && (video.paused || video.error)) {
        try { engine._playBgVideo?.(video); } catch { /* ignore */ }
      }
    }
    try {
      window.__SOMOSUM_OUTPUT_HEALTH = s;
    } catch { /* ignore */ }
  };

  const start = (intervalMs = 2500) => {
    stop();
    timer = setInterval(tick, intervalMs);
    tick();
  };

  const stop = () => {
    if (timer) clearInterval(timer);
    timer = null;
  };

  return { noteAck, noteRevision, snapshot, start, stop };
}
