import {
  resolveShortcuts,
  eventMatchesChord,
  loadShortcutDefaultsFromDisk,
  DEFAULT_SHORTCUTS,
} from './shortcut-map.js';

/**
 * Atalhos table-driven (U1-D).
 * @param {Record<string, Function>} handlers
 * @param {{ bindings?: Record<string,string> }|null} shortcutMap
 */
export function bindShortcuts(handlers, shortcutMap = null) {
  const map = shortcutMap?.bindings
    ? shortcutMap
    : { bindings: { ...DEFAULT_SHORTCUTS.bindings } };

  const actionFor = (event) => {
    const bindings = map.bindings || {};
    for (const [action, chord] of Object.entries(bindings)) {
      if (eventMatchesChord(event, chord)) return action;
    }
    return null;
  };

  function onKeyDown(event) {
    if (event.repeat) return;
    const tag = event.target?.tagName?.toLowerCase();
    if (tag === 'input' || tag === 'textarea' || tag === 'select') {
      if (event.code !== 'Escape') return;
    }

    const action = actionFor(event);
    if (!action) return;

    if (action === 'next' || action === 'nextAlt') {
      if (event.code === 'Space') event.preventDefault();
      event.preventDefault();
      handlers.next?.(event);
      return;
    }
    if (action === 'prev') {
      event.preventDefault();
      handlers.prev?.(event);
      return;
    }
    if (action === 'blank') {
      event.preventDefault();
      handlers.blank?.(event);
      return;
    }
    if (action === 'logo') {
      event.preventDefault();
      handlers.logo?.(event);
      return;
    }
    if (action === 'countdown') {
      event.preventDefault();
      handlers.countdown?.(event);
      return;
    }
    if (action === 'clearOverlay') {
      event.preventDefault();
      handlers.clearOverlay?.(event);
      return;
    }
    if (action === 'docs') {
      event.preventDefault();
      handlers.docs?.(event);
      return;
    }
    if (action === 'tour') {
      event.preventDefault();
      handlers.tour?.(event);
      return;
    }
    if (action === 'fullscreen') {
      event.preventDefault();
      handlers.fullscreen?.(event);
      return;
    }
    if (/^jump[1-9]$/.test(action)) {
      const n = Number(action.slice(4)) - 1;
      event.preventDefault();
      handlers.jumpToItem?.(n);
    }
  }

  window.addEventListener('keydown', onKeyDown);
  return () => window.removeEventListener('keydown', onKeyDown);
}

/** Carrega defaults de disco (opcional) e resolve com prefs. */
export async function resolveAppShortcuts(prefs) {
  const fileDefaults = await loadShortcutDefaultsFromDisk();
  return resolveShortcuts(prefs, fileDefaults);
}
