/**
 * Fetch via proxy local Kestrel — contorna CORS do GitHub Releases / raw.
 */
export function isExternalHttpUrl(url) {
  const s = String(url || '');
  if (!/^https?:\/\//i.test(s)) return false;
  try {
    const u = new URL(s);
    const host = u.hostname.toLowerCase();
    if (host === '127.0.0.1' || host === 'localhost' || host === '::1') return false;
    return true;
  } catch {
    return true;
  }
}

/**
 * Hosts que já enviam Access-Control-Allow-Origin: * — podem ser baixados
 * direto do WebView2 (sem o proxy loopback). Assim o fluxo de atualização
 * funciona mesmo em engines antigos que não tenham a rota /api/catalog/proxy.
 * (GitHub Releases redireciona p/ release-assets.githubusercontent.com SEM CORS.)
 */
const CORS_FRIENDLY_HOSTS = new Set([
  'raw.githubusercontent.com',
  'cdn.jsdelivr.net',
]);

export function isCorsFriendlyHost(url) {
  try {
    return CORS_FRIENDLY_HOSTS.has(new URL(String(url || '')).hostname.toLowerCase());
  } catch {
    return false;
  }
}

export function catalogProxyUrl(remoteUrl) {
  return `/api/catalog/proxy?url=${encodeURIComponent(String(remoteUrl))}`;
}

/**
 * Se a URL for externa (GitHub/CDN), usa /api/catalog/proxy; senão fetch normal.
 * Exceção: hosts com CORS (raw/jsDelivr) vão direto — não dependem do proxy,
 * o que mantém o canal de atualização funcionando em qualquer versão do runtime.
 * @param {string} url
 * @param {RequestInit} [init]
 */
export async function fetchCatalog(url, init = {}) {
  const target = String(url || '');
  const useProxy = isExternalHttpUrl(target) && !isCorsFriendlyHost(target);
  const finalUrl = useProxy ? catalogProxyUrl(target) : target;
  return fetch(finalUrl, { ...init, cache: init.cache || 'no-store' });
}
