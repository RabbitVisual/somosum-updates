/**
 * Persistencia de monitores conhecidos por displayHash (hot-plug).
 * Schema Display & Presentation Core 1.0 (Projetor.md).
 */
import { getPrefs, savePrefs } from './store.js';

function displayKey(d) {
  return d?.displayHash || d?.displayId || d?.deviceName || `idx:${d?.index ?? 0}`;
}

function normalizeEntry(raw, d = null) {
  const hash = raw.displayHash || displayKey(d || raw);
  const identity = raw.identity || {
    manufacturer: raw.manufacturer || d?.manufacturer || '',
    model: raw.model || d?.model || '',
    friendlyName: raw.friendlyName || d?.friendlyName || '',
  };
  const native = raw.nativeMode || raw.maxMode || d?.recommendedMode || d?.maxMode || null;
  const last = raw.lastMode || d?.currentMode || native;
  const projection = {
    fullscreen: raw.projection?.fullscreen !== false,
    role: raw.projection?.role || raw.role || d?.role || null,
    safeArea: raw.projection?.safeArea || null,
    projectorProfileId: raw.projection?.projectorProfileId || raw.projectorProfileId || null,
    colorPolicy: raw.projection?.colorPolicy || 'standard',
  };
  return {
    displayId: raw.displayId || `DISPLAY-${hash}`,
    displayHash: hash,
    deviceName: raw.deviceName || d?.deviceName || '',
    friendlyName: identity.friendlyName || raw.friendlyName || '',
    index: raw.index ?? d?.index ?? 0,
    role: projection.role,
    identity,
    nativeMode: native ? { w: native.w, h: native.h, hz: native.hz || 60 } : null,
    lastMode: last ? { w: last.w, h: last.h, hz: last.hz || 60 } : null,
    maxMode: raw.maxMode || native || null,
    projection,
    rendering: raw.rendering || { vsync: true },
  };
}

export function mergeKnownDisplays(snapshot) {
  if (!snapshot?.displays?.length) return snapshot;

  const prefs = getPrefs();
  const known = [...(prefs.displayEngine?.knownDisplays || [])];
  let changed = false;

  for (const d of snapshot.displays) {
    const hash = displayKey(d);
    let entry = known.find((k) => k.displayHash === hash || k.displayId === d.displayId
      || (d.deviceName && k.deviceName && k.deviceName === d.deviceName)
      || (d.deviceId && k.deviceId && k.deviceId === d.deviceId));
    if (!entry) {
      known.push(normalizeEntry({
        displayHash: hash,
        displayId: d.displayId,
        deviceName: d.deviceName || '',
        deviceId: d.deviceId || '',
        friendlyName: d.friendlyName || '',
        index: d.index ?? 0,
        role: d.role || null,
        manufacturer: d.manufacturer,
        model: d.model,
        maxMode: d.maxMode || d.recommendedMode || d.currentMode || null,
        nativeMode: d.recommendedMode || d.maxMode || null,
        lastMode: d.currentMode || null,
      }, d));
      changed = true;
    } else {
      const savedRole = entry.role || entry.projection?.role || null;
      const liveRole = d.role && d.role !== 'unknown' ? d.role : null;
      const role = liveRole || savedRole || null;
      const next = normalizeEntry({
        ...entry,
        ...d,
        displayHash: hash,
        role,
        projection: {
          ...(entry.projection || {}),
          role,
        },
      }, d);
      const idx = known.indexOf(entry);
      const same = JSON.stringify(entry) === JSON.stringify({ ...entry, ...next, index: next.index });
      if (!same || entry.index !== next.index) {
        known[idx] = {
          ...entry,
          ...next,
          role,
          projection: {
            ...entry.projection,
            ...next.projection,
            role, // nunca clobber papel salvo com "unknown"
          },
        };
        changed = true;
      }
    }
  }

  if (changed) {
    savePrefs({ displayEngine: { knownDisplays: known.slice(-32) } });
  }

  const displays = snapshot.displays.map((d) => {
    const hash = displayKey(d);
    const entry = known.find((k) => k.displayHash === hash || k.displayId === d.displayId);
    if (!entry) return d;
    return {
      ...d,
      knownIndex: entry.index,
      knownRole: entry.role || entry.projection?.role,
      displayId: d.displayId || entry.displayId,
      knownProfile: entry,
    };
  });

  return { ...snapshot, displays };
}

export function findKnownDisplayByHash(hash) {
  if (!hash) return null;
  const known = getPrefs().displayEngine?.knownDisplays || [];
  return known.find((k) => k.displayHash === hash || k.displayId === hash) || null;
}

export function upsertKnownDisplayProfile(profile) {
  if (!profile?.displayHash && !profile?.displayId) return null;
  const prefs = getPrefs();
  const known = [...(prefs.displayEngine?.knownDisplays || [])];
  const normalized = normalizeEntry(profile);
  const idx = known.findIndex(
    (k) => k.displayHash === normalized.displayHash || k.displayId === normalized.displayId,
  );
  if (idx >= 0) known[idx] = { ...known[idx], ...normalized };
  else known.push(normalized);
  savePrefs({ displayEngine: { knownDisplays: known.slice(-32) } });
  return normalized;
}

export function listKnownDisplays() {
  return getPrefs().displayEngine?.knownDisplays || [];
}

/** Safe area por monitor (override persistido ou perfil). */
export function getSafeAreaForDisplay(displayOrHash, profileSafeArea = null) {
  const hash = typeof displayOrHash === 'string'
    ? displayOrHash
    : displayKey(displayOrHash);
  const entry = findKnownDisplayByHash(hash);
  return entry?.projection?.safeArea
    || profileSafeArea
    || { top: 4, right: 4, bottom: 4, left: 4 };
}

export function setSafeAreaOverride(displayOrHash, safeArea) {
  if (!safeArea || typeof safeArea !== 'object') return null;
  const hash = typeof displayOrHash === 'string'
    ? displayOrHash
    : displayKey(displayOrHash);
  const entry = findKnownDisplayByHash(hash);
  if (!entry) return null;
  return upsertKnownDisplayProfile({
    ...entry,
    projection: {
      ...(entry.projection || {}),
      safeArea: {
        top: Number(safeArea.top) || 0,
        right: Number(safeArea.right) || 0,
        bottom: Number(safeArea.bottom) || 0,
        left: Number(safeArea.left) || 0,
      },
    },
  });
}
