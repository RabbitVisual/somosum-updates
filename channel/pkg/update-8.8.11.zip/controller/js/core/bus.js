import { SyncHub, SyncMessageTypes, loadRemoteToken } from './sync-hub.js';
import { randomId } from './uuid.js';
import { getPrefs } from './store.js';
import { buildPushSyncCommand, runtimeEventToBusMessage } from '../runtime/legacy-runtime-adapter.js';
import { isDuplicateMessage, DEDUP_WINDOW_MS } from './bus-dedup.js';
import { postLocalSync, listenLocalSync, localSyncAvailable } from './local-sync-bridge.js';

const CHANNEL_NAME = 'somosum-projecao';
const STORAGE_KEY = 'somosum-bus-fallback';

export { isDuplicateMessage, DEDUP_WINDOW_MS } from './bus-dedup.js';

function getRuntimeClient() {
  if (typeof window === 'undefined') return null;
  return window.__SOMOSUM_RUNTIME__ || null;
}

function shouldMirrorToRuntime() {
  const cfg = getPrefs().runtimeEngine || {};
  if (!cfg.enabled || cfg.bridgePreferred === false) return false;
  if (typeof window !== 'undefined' && window.document?.documentElement?.dataset?.productionMode === '1') {
    return false;
  }
  const rt = getRuntimeClient();
  if (!rt?.isBridgeAvailable?.()) return cfg.legacyFallback === false;
  return cfg.bridgePreferred !== false;
}

export class ProjectionBus {
  constructor(role = 'control') {
    this.role = role;
    this.listeners = new Set();
    this.processedIds = new Map();
    this.hub = new SyncHub(role);
    this.channel =
      typeof BroadcastChannel !== 'undefined'
        ? new BroadcastChannel(CHANNEL_NAME)
        : null;
    this._localSync = localSyncAvailable();
    this._disposeLocal = null;

    if (this.channel) {
      this.channel.onmessage = (event) => this._dispatch(event.data, 'channel');
    }

    this.hub.on((message) => this._dispatch(message, 'hub'));

    // Ponte nativa: Screen/Stage/Control recebem sem Kestrel (dedup por id).
    this._disposeLocal = listenLocalSync((message) => this._dispatch(message, 'local'));

    window.addEventListener('storage', (event) => {
      if (event.key !== STORAGE_KEY || !event.newValue) return;
      try {
        this._dispatch(JSON.parse(event.newValue), 'storage');
      } catch {
        /* ignore malformed payloads */
      }
    });

    const startHttpRelay = async () => {
      await this.hub.primeToLatest();
      this.hub.startPolling();
    };

    // fetchState só depois — apps registram bus.on() logo após o construtor;
    // se aplicar FULL_STATE antes, o evento se perde (listener ainda não existe).
    if (role === 'control') {
      loadRemoteToken().then(startHttpRelay);
    } else if (role === 'screen') {
      loadRemoteToken().then(async () => {
        await this.hub.primeToLatest();
        // Não aplicar .sync-state cache na abertura — screen pede estado fresco via heartbeat
        startHttpRelay();
      });
    } else {
      loadRemoteToken().then(async () => {
        await startHttpRelay();
        // Reaplica estado após um tick para pegar listeners já registrados
        queueMicrotask(() => {
          this.hub.fetchState({ apply: true }).catch(() => {});
        });
        setTimeout(() => {
          this.hub.fetchState({ apply: true }).catch(() => {});
        }, 400);
      });
    }

    /** Re-sincroniza estado do servidor (Remote/Stage após bind de UI). */
    this.resyncFromServer = () => this.hub.fetchState({ apply: true });
  }

  send(type, payload = {}, { batch = false } = {}) {
    const message = {
      id: randomId(),
      type,
      payload,
      ts: Date.now(),
      from: this.role,
    };

    // 1) Ponte local nativa — Controle↔Projeção/Stage no EXE (zero Kestrel).
    if (this._localSync) {
      postLocalSync(message);
    }

    if (this.channel) {
      this.channel.postMessage(message);
    } else {
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(message));
      } catch {
        /* storage full or blocked */
      }
    }

    // 2) WS/HTTP — Remote na LAN + catch-up / persistência (não bloqueia paint local).
    if (batch) {
      this.hub.pushMessageBatched(message);
    } else {
      void this.hub.pushMessage(message);
    }

    if (shouldMirrorToRuntime()) {
      const rt = getRuntimeClient();
      if (rt?.mirrorBusMessage) {
        rt.mirrorBusMessage(message);
      } else if (rt?.execute) {
        const command = buildPushSyncCommand(message, this.role);
        rt.execute({ ...command, source: this.role });
      }
    }

    return message;
  }

  /** Envia mensagem e aguarda resultado do push HTTP (Remote/Stage na LAN). */
  async sendAsync(type, payload = {}, { batch = false } = {}) {
    const message = {
      id: randomId(),
      type,
      payload,
      ts: Date.now(),
      from: this.role,
    };

    if (this._localSync) {
      postLocalSync(message);
    }

    if (this.channel) {
      this.channel.postMessage(message);
    } else {
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(message));
      } catch { /* storage full or blocked */ }
    }

    const push = batch
      ? await this.hub.pushMessageBatch([message]).then(() => ({ ok: true }))
      : await this.hub.pushMessage(message);

    if (shouldMirrorToRuntime()) {
      const rt = getRuntimeClient();
      if (rt?.mirrorBusMessage) {
        rt.mirrorBusMessage(message);
      } else if (rt?.execute) {
        const command = buildPushSyncCommand(message, this.role);
        rt.execute({ ...command, source: this.role });
      }
    }

    return { message, push };
  }

  on(handler) {
    this.listeners.add(handler);
    return () => this.listeners.delete(handler);
  }

  onAck(handler) {
    this.hub.onAck = handler;
  }

  getSyncStatus() {
    return this.hub.getSyncStatus();
  }

  getLastAckAge() {
    return this.hub.getLastAckAge();
  }

  _isDuplicate(id) {
    return isDuplicateMessage(id, this.processedIds);
  }

  _dispatch(message, _source = 'channel') {
    if (!message || message.from === this.role) return;
    if (this._isDuplicate(message.id)) return;

    // Ack local: notifica hub para recovery não disparar FULL_STATE à toa.
    if (_source === 'local' && (message.type === 'slide_ack' || message.type === 'remote_ack')) {
      try {
        this.hub.noteAck?.(message);
      } catch { /* ignore */ }
    }

    if (_source !== 'runtime' && !message._runtimeMirror && shouldMirrorToRuntime()) {
      getRuntimeClient()?.ingestBusMessage?.(message);
    }

    for (const handler of this.listeners) {
      handler(message);
    }
  }

  /** Entrada para eventos espelhados pelo Runtime sem reenviar ao bridge. */
  ingestRuntimeEvent(event) {
    const message = runtimeEventToBusMessage(event);
    if (!message) return;
    this._dispatch(message, 'runtime');
  }
}

export const MessageTypes = SyncMessageTypes;
