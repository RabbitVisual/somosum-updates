import { LogService, LogCategory } from '../logging/log-service.js';

const JOURNAL_KEY = 'somosum-recovery-journal';
const MAX_ENTRIES = 300;

export const RecoveryJournal = {
  append(event) {
    const entries = this.getAll();
    entries.push({
      ...event,
      ts: new Date().toISOString(),
      id: `rj-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
    });
    while (entries.length > MAX_ENTRIES) entries.shift();
    try {
      localStorage.setItem(JOURNAL_KEY, JSON.stringify(entries));
    } catch { /* quota */ }
  },
  getAll() {
    try {
      return JSON.parse(localStorage.getItem(JOURNAL_KEY) || '[]');
    } catch {
      return [];
    }
  },
  clear() {
    localStorage.removeItem(JOURNAL_KEY);
  },
};

export function logRecovery(type, detail = {}) {
  RecoveryJournal.append({ type, detail });
  LogService.debug(`Recovery: ${type}`, {
    module: 'recovery-journal',
    category: LogCategory.BOOT,
    detail,
  });
}
