import { RecoveryJournal } from './recovery-journal.js';

let lastEvent = null;

export const RecoveryMonitor = {
  setStatus(event) {
    lastEvent = { ...event, at: Date.now() };
    window.dispatchEvent(new CustomEvent('somosum-recovery-status', { detail: lastEvent }));
  },
  getStatus() {
    return lastEvent;
  },
  getJournal(limit = 50) {
    return RecoveryJournal.getAll().slice(-limit);
  },
};
