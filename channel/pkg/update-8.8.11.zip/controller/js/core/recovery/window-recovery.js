import { logRecovery } from './recovery-journal.js';
import { RecoveryQueue } from './recovery-queue.js';
import { MessageTypes } from '../bus.js';

export function createWindowRecovery(bus, { role = 'screen' } = {}) {
  return {
    requestState(reason = 'window_recovery') {
      logRecovery('window_recovery', { role, reason });
      RecoveryQueue.enqueue(async () => {
        bus?.send?.(MessageTypes.HEARTBEAT, { needState: true, role, reason });
      }, { priority: 10 });
    },
    onBoot() {
      setTimeout(() => this.requestState('boot'), 800);
    },
  };
}
