import { logRecovery } from './recovery-journal.js';

const CRASH_KEY = 'somosum-session-active';

export const CrashRecovery = {
  markSessionStart() {
    sessionStorage.setItem(CRASH_KEY, JSON.stringify({ startedAt: Date.now(), url: location.pathname }));
  },
  markSessionEnd() {
    sessionStorage.removeItem(CRASH_KEY);
  },
  wasUnexpectedReload() {
    try {
      const raw = sessionStorage.getItem(CRASH_KEY);
      if (!raw) return false;
      const data = JSON.parse(raw);
      return Date.now() - (data.startedAt || 0) < 8 * 60 * 60 * 1000;
    } catch {
      return false;
    }
  },
  onBoot(handler) {
    if (this.wasUnexpectedReload()) {
      logRecovery('crash_recovery', { surface: location.pathname });
      handler?.();
    }
    this.markSessionStart();
    window.addEventListener('beforeunload', () => this.markSessionEnd());
  },
};
