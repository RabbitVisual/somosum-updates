import { logRecovery } from './recovery-journal.js';
import { RecoveryQueue } from './recovery-queue.js';
import { defer } from '../defer.js';
import { triggerRecoveryAuthoritative } from '../../runtime/facades/recovery-runtime.js';

const MAX_BACKOFF_MS = 30000;
const LIGHT_RECOVERY_ATTEMPTS = 2;

export function createProjectionRecovery({
  onRecover,
  onRecoverLight,
  ackTimeoutMs = 3000,
} = {}) {
  let lastSlideTs = 0;
  let lastAckTs = 0;
  let disposeCheck = null;
  let recoveryAttempts = 0;
  let lastRecoveryAt = 0;

  return {
    noteSlideSent(ts = Date.now()) {
      lastSlideTs = ts;
      this.scheduleCheck();
    },
    noteAck(ts = Date.now()) {
      lastAckTs = ts;
      recoveryAttempts = 0;
      disposeCheck?.();
      disposeCheck = null;
    },
    scheduleCheck() {
      disposeCheck?.();
      disposeCheck = defer(() => {
        const age = Date.now() - Math.max(lastSlideTs, lastAckTs);
        if (!lastSlideTs || age <= ackTimeoutMs || lastAckTs >= lastSlideTs) return;

        const backoff = Math.min(MAX_BACKOFF_MS, ackTimeoutMs + recoveryAttempts * 2500);
        if (Date.now() - lastRecoveryAt < backoff) return;

        recoveryAttempts += 1;
        lastRecoveryAt = Date.now();
        logRecovery('projection_recovery', { age, attempt: recoveryAttempts, backoff });

        if (recoveryAttempts <= LIGHT_RECOVERY_ATTEMPTS && typeof onRecoverLight === 'function') {
          RecoveryQueue.enqueue(async () => onRecoverLight?.({ age, attempt: recoveryAttempts }), { priority: 20 });
          this.scheduleCheck();
          return;
        }

        triggerRecoveryAuthoritative('projection', 'control', { age, attempt: recoveryAttempts });
        RecoveryQueue.enqueue(async () => onRecover?.({ age, attempt: recoveryAttempts }), { priority: 20 });
      }, ackTimeoutMs + 200, 20);
    },
  };
}
