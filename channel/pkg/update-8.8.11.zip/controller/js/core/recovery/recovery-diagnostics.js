import { runRecoveryDiagnostics } from '../../runtime/facades/recovery-runtime.js';
import { RecoveryMonitor } from './recovery-monitor.js';

export async function getRecoveryDiagnosticsReport() {
  const core = await runRecoveryDiagnostics();
  const status = RecoveryMonitor.getStatus();
  return {
    status,
    ...core,
    events: RecoveryMonitor.getJournal(30),
  };
}
