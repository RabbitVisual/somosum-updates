import { DatabaseEngine } from '../database/database-engine.js';
import { logRecovery } from './recovery-journal.js';
import { TaskScheduler } from '../task-scheduler.js';
import { TaskIds } from '../task-registry.js';

const CHECKPOINT_KEY = 'somosum-last-checkpoint';
let intervalMs = 15 * 60 * 1000;

let disposeCheckpoint = null;

export const CheckpointRecovery = {
  setIntervalMs(ms) {
    if (typeof ms === 'number' && ms >= 60000) intervalMs = ms;
    if (disposeCheckpoint) {
      this.stop();
      this.startAuto(this._activeCheck);
    }
  },
  startAuto(activeCheck) {
    this._activeCheck = activeCheck;
    if (disposeCheckpoint) return;
    disposeCheckpoint = TaskScheduler.register({
      id: TaskIds.CHECKPOINT,
      kind: 'interval',
      intervalMs,
      priority: 10,
      fn: async () => {
        if (!activeCheck?.()) return;
        await this.create('auto');
      },
    });
  },
  stop() {
    disposeCheckpoint?.();
    disposeCheckpoint = null;
    TaskScheduler.unregister(TaskIds.CHECKPOINT);
  },
  async create(label = 'manual') {
    try {
      await DatabaseEngine.init();
      const snap = await DatabaseEngine.createSnapshot(label);
      localStorage.setItem(CHECKPOINT_KEY, JSON.stringify(snap));
      logRecovery('checkpoint', { label, songs: snap.songs?.length });
      return snap;
    } catch {
      return null;
    }
  },
  getLast() {
    try {
      return JSON.parse(localStorage.getItem(CHECKPOINT_KEY) || 'null');
    } catch {
      return null;
    }
  },
};
