import { logRecovery } from './recovery-journal.js';

export const SyncRecovery = {
  async fetchFullState() {
    try {
      const res = await fetch('/api/sync/state', { cache: 'no-store' });
      if (!res.ok) return null;
      return await res.json();
    } catch {
      return null;
    }
  },
  async replayJournal() {
    try {
      const res = await fetch('/api/journal/status', { cache: 'no-store' });
      if (!res.ok) return null;
      const status = await res.json();
      if (status.pending > 0) {
        logRecovery('sync_recovery_journal', status);
        await fetch('/api/journal/checkpoint', { method: 'POST' });
      }
      return status;
    } catch {
      return null;
    }
  },
};
