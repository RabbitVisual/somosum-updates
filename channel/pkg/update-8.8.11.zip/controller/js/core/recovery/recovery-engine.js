import { CrashRecovery } from './crash-recovery.js';
import { createWindowRecovery } from './window-recovery.js';
import { createProjectionRecovery } from './projection-recovery.js';
import { SyncRecovery } from './sync-recovery.js';
import { CheckpointRecovery } from './checkpoint-recovery.js';
import { RecoveryMonitor } from './recovery-monitor.js';
import { RecoveryQueue } from './recovery-queue.js';
import { logRecovery } from './recovery-journal.js';
import { LogService, LogCategory } from '../logging/log-service.js';

let instance = null;

export class RecoveryEngine {
  constructor() {
    this.projection = null;
    this.window = null;
    this.booted = false;
  }

  static getInstance() {
    if (!instance) instance = new RecoveryEngine();
    return instance;
  }

  init({ role = 'control', bus = null, onPushFullState = null, isCultoActive = null } = {}) {
    if (this.booted) return this;
    this.booted = true;

    CrashRecovery.onBoot(() => {
      RecoveryMonitor.setStatus({ type: 'crash_recovery', role });
      SyncRecovery.replayJournal();
    });

    if (role === 'screen' || role === 'stage' || role === 'remote') {
      this.window = createWindowRecovery(bus, { role });
      this.window.onBoot();
    }

    if (role === 'control') {
      this.projection = createProjectionRecovery({
        onRecoverLight: () => {
          RecoveryMonitor.setStatus({ type: 'projection_recovery_light' });
          onPushFullState?.({ force: true, reason: 'recovery-light', light: true });
        },
        onRecover: () => {
          RecoveryMonitor.setStatus({ type: 'projection_recovery' });
          onPushFullState?.({ force: true, reason: 'recovery' });
        },
      });
      CheckpointRecovery.startAuto(() => isCultoActive?.() ?? false);
    }

    LogService.debug('RecoveryEngine ativo', {
      module: 'recovery-engine',
      category: LogCategory.BOOT,
      detail: { role },
    });
    return this;
  }

  noteSlideSent() {
    this.projection?.noteSlideSent();
  }

  noteSlideAck() {
    this.projection?.noteAck();
  }

  async runDiagnostics() {
    const journal = RecoveryMonitor.getJournal(20);
    const syncState = await SyncRecovery.fetchFullState();
    const wal = await SyncRecovery.replayJournal();
    return { journal, syncState: !!syncState, wal, lastCheckpoint: CheckpointRecovery.getLast()?.createdAt };
  }

  requestWindowState(bus, reason) {
    this.window?.requestState(reason);
  }

  enqueue(task, opts) {
    RecoveryQueue.enqueue(task, opts);
  }

  shutdown() {
    CheckpointRecovery.stop();
    CrashRecovery.markSessionEnd();
  }
}

export function getRecoveryEngine() {
  return RecoveryEngine.getInstance();
}

export async function runRecoveryDiagnostics() {
  return RecoveryEngine.getInstance().runDiagnostics();
}
