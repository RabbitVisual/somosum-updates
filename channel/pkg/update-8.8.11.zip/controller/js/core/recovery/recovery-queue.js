const queue = [];
let processing = false;

export const RecoveryQueue = {
  enqueue(task, { priority = 0 } = {}) {
    queue.push({ task, priority, addedAt: Date.now() });
    queue.sort((a, b) => b.priority - a.priority);
    this.process();
  },
  async process() {
    if (processing || !queue.length) return;
    processing = true;
    while (queue.length) {
      const { task } = queue.shift();
      try {
        await task();
      } catch { /* continue */ }
    }
    processing = false;
  },
};
