/**
 * @deprecated Prefer js/ui/theme/theme-engine.js — thin re-export.
 */
export {
  THEMES,
  ATMOSPHERES,
  applyTheme,
  applyAtmosphere,
  getThemeList,
  ThemeEngine,
  AtmosphereEngine,
  getAtmosphere,
  listPickerAtmospheres,
  normalizeAtmosphereId,
  resolveLiveAtmosphereId,
  resolvePrefsAtmosphereId,
  paintAtmosphere,
} from '../ui/theme/theme-engine.js';
