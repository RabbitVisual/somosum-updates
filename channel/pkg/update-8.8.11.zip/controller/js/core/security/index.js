import { wireCspReporting } from './csp-manager.js';
import { fetchRemoteTokenFromApi } from './auth-manager.js';

let bootstrapped = false;

export function bootstrapSecurity() {
  if (bootstrapped) return;
  bootstrapped = true;
  wireCspReporting();
  if (typeof window !== 'undefined') {
    window.SOMOSUM_SECURITY = {
      bootstrap: bootstrapSecurity,
      ensureToken: fetchRemoteTokenFromApi,
    };
  }
}

export {
  getAuthToken, setAuthToken, authHeaders, createPairToken, fetchRemoteTokenFromApi,
} from './auth-manager.js';
export { ensureRemoteToken, rotateRemoteToken, createPairToken as mintPairToken } from './token-manager.js';
export { secureFetch, withAuthQuery } from './api-security.js';
export { validateProtocol, validateSyncMessage } from './protocol-validator.js';
export { validateFetchInput, validateSyncCommand } from './request-validator.js';
export { readSessionToken, writeSessionToken, clearSessionToken } from './secure-storage.js';
export { emitSecurityEvent, onSecurityEvent } from './security-events.js';
export { runSecurityAudit, auditReportHtml } from './security-audit.js';
export { wireCspReporting } from './csp-manager.js';

if (typeof window !== 'undefined') {
  queueMicrotask(() => { try { bootstrapSecurity(); } catch { /* */ } });
}
