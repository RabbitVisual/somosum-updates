const SESSION_KEY = 'somosum.network.session';

export function readSessionToken() {
  try { return localStorage.getItem(SESSION_KEY) || ''; } catch { return ''; }
}

export function writeSessionToken(token) {
  if (!token) return;
  try { localStorage.setItem(SESSION_KEY, token); } catch { /* ignore */ }
}

export function clearSessionToken() {
  try { localStorage.removeItem(SESSION_KEY); } catch { /* ignore */ }
}

export function readPairTokenFromUrl() {
  try {
    return new URLSearchParams(location.search).get('token')?.trim() || '';
  } catch {
    return '';
  }
}
