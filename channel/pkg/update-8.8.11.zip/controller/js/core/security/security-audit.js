export async function runSecurityAudit() {
  if (!['127.0.0.1', 'localhost', '::1'].includes(location.hostname)) {
    return { ok: false, error: 'loopback_only' };
  }
  try {
    const res = await fetch('/api/security/audit', { cache: 'no-store' });
    if (!res.ok) return { ok: false, error: `HTTP ${res.status}` };
    return res.json();
  } catch (err) {
    return { ok: false, error: err?.message || String(err) };
  }
}

export function auditReportHtml(report) {
  if (!report) return '<p>Auditoria indisponível</p>';
  const checks = (report.checks || []).map((c) =>
    `<tr><td>${c.id}</td><td>${c.ok ? 'OK' : 'Falha'}</td><td>${c.detail || ''}</td></tr>`
  ).join('');
  return `
    <div class="security-audit-report">
      <p>Aprovados: <strong>${report.pass ?? 0}</strong> · Falhas: <strong>${report.fail ?? 0}</strong></p>
      <table><thead><tr><th>Verificação</th><th>Status</th><th>Detalhe</th></tr></thead>
      <tbody>${checks || '<tr><td colspan="3">—</td></tr>'}</tbody></table>
    </div>`;
}
