import { readSessionToken, readPairTokenFromUrl, writeSessionToken } from './secure-storage.js';
import { emitSecurityEvent } from './security-events.js';

let activeToken = null;

export function getAuthToken() {
  if (activeToken) return activeToken;
  const urlTok = readPairTokenFromUrl();
  if (urlTok) {
    activeToken = urlTok;
    writeSessionToken(urlTok);
    return activeToken;
  }
  const stored = readSessionToken();
  if (stored) {
    activeToken = stored;
    return activeToken;
  }
  return null;
}

export function setAuthToken(token) {
  activeToken = token || null;
  if (token) writeSessionToken(token);
}

export function authHeaders(extra = {}) {
  const token = getAuthToken();
  const headers = { ...extra };
  if (token) headers['X-Somosum-Token'] = token;
  return headers;
}

export async function fetchRemoteTokenFromApi() {
  if (!['127.0.0.1', 'localhost', '::1'].includes(location.hostname)) return null;
  try {
    const res = await fetch('/api/remote-token', { cache: 'no-store' });
    if (!res.ok) return null;
    const token = (await res.text()).trim();
    if (token) {
      setAuthToken(token);
      emitSecurityEvent('auth.token_loaded', { source: 'api' });
    }
    return token || null;
  } catch {
    return null;
  }
}

export async function createPairToken() {
  if (!['127.0.0.1', 'localhost', '::1'].includes(location.hostname)) return null;
  try {
    const res = await fetch('/api/auth/pair-token', { method: 'POST' });
    if (!res.ok) return null;
    const data = await res.json();
    if (data?.token) {
      emitSecurityEvent('token.pair_created', { ttl: data.expiresInSeconds });
      return data.token;
    }
  } catch { /* ignore */ }
  return null;
}
