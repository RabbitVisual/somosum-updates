import { fetchRemoteTokenFromApi, createPairToken, getAuthToken, setAuthToken } from './auth-manager.js';

export { getAuthToken, setAuthToken, createPairToken, fetchRemoteTokenFromApi };

export async function ensureRemoteToken() {
  const existing = getAuthToken();
  if (existing) return existing;
  return fetchRemoteTokenFromApi();
}

export async function rotateRemoteToken() {
  if (!['127.0.0.1', 'localhost', '::1'].includes(location.hostname)) return false;
  try {
    const res = await fetch('/api/auth/rotate-token', { method: 'POST' });
    return res.ok;
  } catch {
    return false;
  }
}
