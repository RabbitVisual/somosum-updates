const listeners = new Set();

export function emitSecurityEvent(name, detail = {}) {
  const entry = { name, detail, ts: Date.now() };
  listeners.forEach((fn) => { try { fn(entry); } catch { /* */ } });
  try {
    window.dispatchEvent(new CustomEvent('somosum:security', { detail: entry }));
  } catch { /* ignore */ }
}

export function onSecurityEvent(fn) {
  listeners.add(fn);
  return () => listeners.delete(fn);
}
