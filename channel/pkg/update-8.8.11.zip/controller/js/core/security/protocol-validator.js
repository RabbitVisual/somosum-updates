import { assertCompatible } from '../protocol-compat.js';
import { emitSecurityEvent } from './security-events.js';

export function validateProtocol(localMeta, remoteMeta) {
  const result = assertCompatible(localMeta, remoteMeta);
  if (!result.ok) emitSecurityEvent('protocol.mismatch', { reason: result.reason });
  return result;
}

export function validateSyncMessage(message) {
  if (!message || typeof message !== 'object') return { ok: false, reason: 'invalid_message' };
  if (message.protocol != null && Number(message.protocol) < 3) {
    emitSecurityEvent('protocol.mismatch', { protocol: message.protocol });
    return { ok: false, reason: 'protocol_too_old' };
  }
  return { ok: true };
}
