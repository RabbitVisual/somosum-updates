import { bootstrapSecurity } from './index.js';
import { wireCspReporting } from './csp-manager.js';
import { onSecurityEvent } from './security-events.js';

let managerReady = false;

export function initSecurityManager() {
  if (managerReady) return;
  managerReady = true;
  bootstrapSecurity();
  onSecurityEvent((evt) => {
    if (evt.name === 'auth.fail' || evt.name === 'static.blocked') {
      try { console.warn('[SOMOSUM Security]', evt.name, evt.detail); } catch { /* */ }
    }
  });
}

export { bootstrapSecurity, wireCspReporting };
