import { emitSecurityEvent } from './security-events.js';

const MAX_BODY = 32 * 1024 * 1024;

export function validateFetchInput(url, options = {}) {
  if (!url || String(url).length > 512) {
    emitSecurityEvent('validation.fail', { url });
    return { ok: false, reason: 'invalid_url' };
  }
  const body = options.body;
  if (body && typeof body === 'string' && body.length > MAX_BODY) {
    emitSecurityEvent('validation.fail', { reason: 'body_too_large' });
    return { ok: false, reason: 'body_too_large' };
  }
  return { ok: true };
}

export function validateSyncCommand(message) {
  if (!message?.type) return { ok: false, reason: 'missing_type' };
  if (typeof message.type !== 'string' || message.type.length > 64) return { ok: false, reason: 'invalid_type' };
  return { ok: true };
}
