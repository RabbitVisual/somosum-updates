import { authHeaders, getAuthToken } from './auth-manager.js';
import { validateFetchInput } from './request-validator.js';
import { emitSecurityEvent } from './security-events.js';

export async function secureFetch(url, options = {}) {
  const check = validateFetchInput(url, options);
  if (!check.ok) throw new Error(check.reason || 'validation_failed');

  const headers = authHeaders(options.headers || {});
  const res = await fetch(url, { ...options, headers });

  if (res.status === 401) emitSecurityEvent('auth.fail', { url });
  if (res.status === 429) emitSecurityEvent('rate.limited', { url });

  return res;
}

export function withAuthQuery(url) {
  const token = getAuthToken();
  if (!token) return url;
  const sep = url.includes('?') ? '&' : '?';
  return `${url}${sep}token=${encodeURIComponent(token)}`;
}
