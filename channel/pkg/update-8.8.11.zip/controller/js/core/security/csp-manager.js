export function reportCspViolation(event) {
  try {
    console.warn('[SOMOSUM CSP]', event?.violatedDirective, event?.blockedURI);
  } catch { /* ignore */ }
}

export function wireCspReporting() {
  if (typeof document === 'undefined') return;
  document.addEventListener('securitypolicyviolation', reportCspViolation);
}
