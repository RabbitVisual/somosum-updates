import { getPrefs, savePrefs, saveProgram, getProgram } from './store.js';
import { DiskAdapter } from './storage/adapters/disk-adapter.js';
import { logToServer } from './storage/adapters/server-adapter.js';
import { saveCulto, getCulto, loadCultoIndex } from '../program/culto-manager.js';
import { createDefaultProgram } from '../program/programa-templates.js';
import { normalizeWelcomeData } from '../slides/welcome-config.js';
import { sanitizeCountdownPersistedMedia } from './countdown.js';
import { PRODUCT_LOGO, isLegacyProductLogo } from './brand-assets.js';

const MIGRATION_KEY = 'somosum-migration-v2';
const MIGRATION_V3_KEY = 'somosum-migration-v3-domingo-23';
const MIGRATION_V4_KEY = 'somosum-migration-v4-production';
const MIGRATION_V5_KEY = 'somosum-migration-v5-introito-bible';
const MIGRATION_V6_KEY = 'somosum-migration-v6-cbav-logo';
const MIGRATION_V7_KEY = 'somosum-migration-v7-somosum-logo';
const LEGACY_LOGO = 'IMG/LOGO/LOGO.png';
const CBAV_LOGO = 'IMG/LOGO/cbav-logo.png';

function normalizeBibleItems(items) {
  if (!Array.isArray(items)) return { items, changed: false };
  let changed = false;
  const next = items.map((item) => {
    if (item.slideType !== 'bible' || !item.bible) return item;
    const title = item.title || '';
    const isIntro = /introito/i.test(title);
    const mode = item.bible.displayMode;
    if (isIntro && mode !== 'excerpt') {
      changed = true;
      return {
        ...item,
        bible: { ...item.bible, displayMode: 'excerpt', showText: true },
      };
    }
    if (!isIntro && mode === 'verses') {
      // v2 antigo removia displayMode:'verses' — destruía a escolha salva.
      // Manter modo e só garantir showText coerente.
      if (item.bible.showText !== true) {
        changed = true;
        return {
          ...item,
          bible: { ...item.bible, displayMode: 'verses', showText: true },
        };
      }
      return item;
    }
    return item;
  });
  return { items: next, changed };
}

/** Remove referenceOverride de introito quando não bate com capítulo/versículo do picker. */
function sanitizeIntroitoOverride(bible = {}) {
  const override = bible.referenceOverride?.trim();
  if (!override) return { bible, changed: false };
  const ch = Number(bible.chapter);
  const vs = Number(bible.verseStart);
  const ve = Number(bible.verseEnd ?? bible.verseStart ?? vs);
  if (!ch || !vs) return { bible, changed: false };
  const chapterHit = ve !== vs
    ? new RegExp(`\\b${ch}\\s*[:.]\\s*${vs}\\s*[-–]\\s*${ve}\\b`).test(override)
    : new RegExp(`\\b${ch}\\s*[:.]\\s*${vs}\\b`).test(override)
      && !new RegExp(`\\b${ch}\\s*[:.]\\s*${vs}\\s*[-–]\\s*\\d+\\b`).test(override);
  if (chapterHit) return { bible, changed: false };
  const { referenceOverride, ...rest } = bible;
  return { bible: rest, changed: true };
}

function normalizeProgramItems(items, church = {}) {
  if (!Array.isArray(items)) return { items, changed: false };
  let changed = false;
  const next = items.map((item) => {
    let out = item;
    if (item.slideType === 'welcome' && item.data) {
      const repaired = normalizeWelcomeData(item.data, church);
      if (JSON.stringify(repaired) !== JSON.stringify(item.data)) {
        changed = true;
        out = { ...item, data: repaired };
      }
    }
    if (item.slideType === 'bible' && /introito/i.test(item.title || '') && item.bible) {
      const { bible, changed: introChanged } = sanitizeIntroitoOverride(item.bible);
      if (introChanged) {
        changed = true;
        out = { ...out, bible };
      }
    }
    return out;
  });
  return { items: next, changed };
}

async function runProductionMigration() {
  if (localStorage.getItem(MIGRATION_V4_KEY) === 'done') return;
  const prefs = getPrefs();
  const church = prefs.church || {};
  let fixed = 0;

  const program = await getProgram();
  if (program?.length) {
    const { items, changed } = normalizeProgramItems(program, church);
    if (changed) {
      await saveProgram(items);
      fixed += 1;
    }
  }

  const index = await loadCultoIndex();
  for (const c of index.cultos || []) {
    const culto = await getCulto(c.id);
    if (!culto?.items?.length) continue;
    const { items, changed } = normalizeProgramItems(culto.items, church);
    if (changed) {
      await saveCulto(c.id, items, c);
      fixed += 1;
    }
  }

  if (fixed > 0) {
    logToServer('INFO', `Migração v4: ${fixed} programa(s)/culto(s) reparados`);
  }
  localStorage.setItem(MIGRATION_V4_KEY, 'done');
}

const INTROITO_ITEM_ID = 'a1000002-0000-4000-8000-000000000002';

function repairIntroitoItems(items) {
  if (!Array.isArray(items)) return { items, changed: false };
  let changed = false;
  const next = items.map((item) => {
    if (item.slideType !== 'bible') return item;
    const isIntro = item.data?.role === 'introito'
      || item.id === INTROITO_ITEM_ID
      || /introito/i.test(item.title || '');
    if (!isIntro) return item;
    const bible = { ...(item.bible || {}) };
    let bibleChanged = false;
    if (bible.displayMode === 'reference' || !bible.displayMode) {
      bible.displayMode = 'excerpt';
      bible.showText = true;
      bibleChanged = true;
    }
    const titleOk = /introito/i.test(item.title || '');
    if (!titleOk || bibleChanged || item.data?.role !== 'introito') {
      changed = true;
      return {
        ...item,
        title: 'Introito Bíblico',
        data: { ...(item.data || {}), role: 'introito' },
        bible,
      };
    }
    return item;
  });
  return { items: next, changed };
}

async function runIntroitoMigration() {
  if (localStorage.getItem(MIGRATION_V5_KEY) === 'done') return;
  let fixed = 0;

  const program = await getProgram();
  if (program?.length) {
    const { items, changed } = repairIntroitoItems(program);
    if (changed) {
      await saveProgram(items);
      fixed += 1;
    }
  }

  const index = await loadCultoIndex();
  for (const c of index.cultos || []) {
    const culto = await getCulto(c.id);
    if (!culto?.items?.length) continue;
    const { items, changed } = repairIntroitoItems(culto.items);
    if (changed) {
      await saveCulto(c.id, items, c);
      fixed += 1;
    }
  }

  if (fixed > 0) {
    logToServer('INFO', `Migração v5: introito reparado em ${fixed} programa(s)/culto(s)`);
  }
  localStorage.setItem(MIGRATION_V5_KEY, 'done');
}

async function runCbavLogoMigration() {
  if (localStorage.getItem(MIGRATION_V6_KEY) === 'done') return;
  const prefs = getPrefs();
  const logoPath = prefs.church?.logoPath || '';
  if (logoPath === LEGACY_LOGO || logoPath.endsWith('/LOGO.png')) {
    savePrefs({
      ...prefs,
      church: { ...prefs.church, logoPath: CBAV_LOGO },
    });
    logToServer('INFO', 'Logo atualizada para CBAV (cbav-logo.png)');
  }
  localStorage.setItem(MIGRATION_V6_KEY, 'done');
}

async function runSomosumLogoMigration() {
  if (localStorage.getItem(MIGRATION_V7_KEY) === 'done') return;
  const prefs = getPrefs();
  const logoPath = prefs.church?.logoPath || '';
  if (isLegacyProductLogo(logoPath) || logoPath === CBAV_LOGO || logoPath.endsWith('cbav-logo.png')) {
    savePrefs({
      ...prefs,
      church: { ...prefs.church, logoPath: PRODUCT_LOGO },
    });
    logToServer('INFO', 'Logo atualizada para SOMOSUM oficial');
  }
  try {
    const config = await DiskAdapter.load('config.json');
    if (config?.church && isLegacyProductLogo(config.church.logoPath)) {
      config.church.logoPath = PRODUCT_LOGO;
      await DiskAdapter.save('config.json', config);
    }
  } catch { /* offline */ }
  localStorage.setItem(MIGRATION_V7_KEY, 'done');
}

function fixCountdownPhantom(prefs) {
  const cd = prefs.countdown || {};
  if (!cd.active) return prefs;
  const now = Date.now();
  const started = cd.startedAt || 0;
  const age = now - started;
  const pastTarget = cd.targetMs ? now - cd.targetMs : 0;

  const stale =
    age > 4 * 60 * 60 * 1000
    || !cd.targetMs
    || (pastTarget > 120_000)
    || (cd.phase === 'announce' && pastTarget > 90_000)
    || (cd.phase === 'transition' && pastTarget > 120_000)
    || (cd.phase === 'running' && pastTarget > 30_000);

  if (stale) {
    logToServer('WARN', 'Pré-culto encerrado automaticamente (sessão expirada)', { phase: cd.phase });
    return {
      ...prefs,
      countdown: {
        ...cd,
        active: false,
        phase: 'idle',
        targetMs: null,
        startedAt: null,
      },
    };
  }
  return prefs;
}

/** Culto domingo alterado pela atualização v2 (Ceia/Comunicados no lugar da ordem 23 anos). */
function isBrokenDomingoProgram(items) {
  if (!Array.isArray(items) || items.length < 8) return false;
  const titles = items.map((i) => (i.title || '').toLowerCase());
  const hasDed = titles.some((t) => t.includes('dedicação de vidas'));
  const hasConfra = titles.some((t) => t.includes('confraternização'));
  const hasComm = items.some((i) => i.slideType === 'communion');
  if (hasDed && hasConfra) return false;
  if (hasComm || titles.includes('bênção') || titles.includes('benção')) return true;
  const msgIdx = titles.findIndex((t) => t.includes('mensagem'));
  const oraIdx = titles.findIndex((t) => t === 'oração');
  return msgIdx >= 0 && oraIdx >= 0 && msgIdx < 12 && !hasDed;
}

function mergeDomingoRestore(oldItems, freshItems) {
  const songByTitle = new Map();
  (oldItems || []).forEach((item) => {
    if (item.slideType === 'lyrics' && item.songId) songByTitle.set(item.title, item.songId);
  });
  const oldMsg = (oldItems || []).find((i) => i.slideType === 'message');
  const oldIntro = (oldItems || []).find((i) => i.slideType === 'bible' && /introito/i.test(i.title || ''));
  return freshItems.map((item) => {
    const next = { ...item };
    if (item.slideType === 'lyrics' && songByTitle.has(item.title)) {
      next.songId = songByTitle.get(item.title);
    }
    if (item.slideType === 'message' && oldMsg?.data) {
      next.data = {
        ...item.data,
        preacher: oldMsg.data.preacher || item.data.preacher,
        preacherFrom: oldMsg.data.preacherFrom || item.data.preacherFrom,
        preacherPhotoId: oldMsg.data.preacherPhotoId || item.data.preacherPhotoId,
        theme: oldMsg.data.theme || item.data.theme,
        reference: oldMsg.data.reference || item.data.reference,
      };
    }
    if (item.slideType === 'bible' && /introito/i.test(item.title || '') && oldIntro?.bible) {
      next.bible = { ...item.bible, ...oldIntro.bible };
      if (oldIntro.title) next.title = oldIntro.title;
    }
    return next;
  });
}

async function restoreBrokenDomingoCultos() {
  if (localStorage.getItem(MIGRATION_V3_KEY) === 'done') return;
  const index = await loadCultoIndex();
  let restored = 0;
  for (const meta of index.cultos || []) {
    if (meta.type !== 'domingo') continue;
    const culto = await getCulto(meta.id);
    if (!culto?.items?.length || !isBrokenDomingoProgram(culto.items)) continue;
    const items = mergeDomingoRestore(culto.items, createDefaultProgram());
    await saveCulto(meta.id, items, {
      ...meta,
      templateId: 'domingo-23-anos',
      title: meta.title?.includes('23 Anos') ? meta.title : `${meta.title || 'Culto de Celebração'} — 23 Anos`,
    });
    restored += 1;
  }
  if (restored > 0) {
    logToServer('INFO', `Ordem 23 Anos restaurada em ${restored} culto(s) domingo`);
  }
  localStorage.setItem(MIGRATION_V3_KEY, 'done');
}

export async function runDataMigration() {
  try {
    const v2Done = localStorage.getItem(MIGRATION_KEY) === 'done';

    if (!v2Done) {
      let prefs = getPrefs();
      prefs = fixCountdownPhantom(prefs);
      savePrefs(prefs);

      const program = await getProgram();
      if (program?.length) {
        const { items, changed } = normalizeBibleItems(program);
        if (changed) await saveProgram(items);
      }

      const legacyProgram = await DiskAdapter.load('programa.json');
      if (Array.isArray(legacyProgram)) {
        const { items, changed } = normalizeBibleItems(legacyProgram);
        if (changed) await DiskAdapter.save('programa.json', items);
      }

      const index = await loadCultoIndex();
      for (const c of index.cultos || []) {
        const culto = await getCulto(c.id);
        if (!culto?.items?.length) continue;
        const { items, changed } = normalizeBibleItems(culto.items);
        if (changed) await saveCulto(c.id, items, c);
      }

      localStorage.setItem(MIGRATION_KEY, 'done');
      logToServer('INFO', 'Migração v2 concluída');
    }

    await restoreBrokenDomingoCultos();
    await runProductionMigration();
    await runIntroitoMigration();
    await runCbavLogoMigration();
    await runSomosumLogoMigration();
  } catch (err) {
    logToServer('ERROR', 'Migração falhou', { message: err.message });
  }
}

export function fixCountdownOnBoot() {
  const prefs = getPrefs();
  let next = fixCountdownPhantom(prefs);
  const { countdown, changed: mediaChanged } = sanitizeCountdownPersistedMedia(next.countdown || {});
  if (mediaChanged) {
    logToServer('WARN', 'Pré-culto: mídia blob/data removida (não persiste entre sessões)');
    next = { ...next, countdown };
  }
  if (next !== prefs || mediaChanged) savePrefs(next);
  return next;
}

export { normalizeBibleItems, normalizeProgramItems };
