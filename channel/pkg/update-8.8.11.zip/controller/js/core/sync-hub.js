/**
 * SyncHub — relay HTTP para sincronização entre abas e PCs na LAN.
 * Complementa BroadcastChannel com fila sequenciada no servidor local.
 */

import { randomId } from './uuid.js';
import { TaskScheduler } from './task-scheduler.js';
import { TaskIds } from './task-registry.js';
import { isWebSocketSupported, SyncSocket } from '../remote/sync-socket.js';
import {
  getDeviceFingerprint,
  getStoredDeviceId,
  getRemoteDeviceLabel,
  getStageDeviceLabel,
  getRemoteClientId,
  getStageClientId,
} from './client-presence.js';

// Polling adaptativo: repouso longo quando não há mensagens na fila HTTP.
const POLL_IDLE_MS = 1200;
const POLL_ACTIVE_MS = 250;
const POLL_SCREEN_IDLE_MS = 800;
const POLL_SCREEN_ACTIVE_MS = 250;
/** Com WS saudável, Screen usa poll só como rede de segurança lenta */
const POLL_SCREEN_WS_IDLE_MS = 5000;
const POLL_SCREEN_WS_ACTIVE_MS = 2000;
const POLL_TIMEOUT_SEC = 0;
const DEDUP_WINDOW_MS = 2000;
const WS_HEALTH_MS = 2000;

import { buildPushBatchBody } from './sync-hub-batch.js';

let remoteToken = null;
const SESSION_STORAGE_KEY = 'somosum.network.session';
const SESSION_KIND_KEY = 'somosum.network.session.kind';

function readSessionFrom(store) {
  try {
    const token = store.getItem(SESSION_STORAGE_KEY) || null;
    if (!token) return null;
    if (store.getItem(SESSION_KIND_KEY) !== 'pin') {
      try {
        store.removeItem(SESSION_STORAGE_KEY);
        store.removeItem(SESSION_KIND_KEY);
      } catch { /* ignore */ }
      return null;
    }
    return token;
  } catch {
    return null;
  }
}

export function getStoredSessionToken() {
  // Sessão confiável (localStorage) ou só desta aba (sessionStorage).
  return readSessionFrom(localStorage) || readSessionFrom(sessionStorage);
}

/** @param {string} token @param {{ trust?: boolean }} [opts] trust=false → só na aba */
export function storeSessionToken(token, opts = {}) {
  if (!token) return;
  const trust = opts.trust !== false;
  try {
    const primary = trust ? localStorage : sessionStorage;
    const other = trust ? sessionStorage : localStorage;
    primary.setItem(SESSION_STORAGE_KEY, token);
    primary.setItem(SESSION_KIND_KEY, 'pin');
    try {
      other.removeItem(SESSION_STORAGE_KEY);
      other.removeItem(SESSION_KIND_KEY);
    } catch { /* ignore */ }
  } catch { /* ignore */ }
  remoteToken = token;
}

export function clearStoredSessionToken() {
  try {
    localStorage.removeItem(SESSION_STORAGE_KEY);
    localStorage.removeItem(SESSION_KIND_KEY);
  } catch { /* ignore */ }
  try {
    sessionStorage.removeItem(SESSION_STORAGE_KEY);
    sessionStorage.removeItem(SESSION_KIND_KEY);
  } catch { /* ignore */ }
  if (remoteToken && (remoteToken === readSessionFrom(localStorage) || remoteToken === readSessionFrom(sessionStorage))) {
    /* noop */
  }
  // Não limpa pair-token da URL em memória se ainda estiver ativo
  try {
    const params = new URLSearchParams(location.search);
    const urlTok = params.get('token')?.trim();
    remoteToken = urlTok || null;
  } catch {
    remoteToken = null;
  }
}

/** Valida sessão PIN no servidor (dispositivo revogado / expirado). */
export async function validateStoredSession() {
  const token = getStoredSessionToken();
  if (!token) return false;
  try {
    const res = await fetch(`/api/network/session/validate?token=${encodeURIComponent(token)}`, {
      cache: 'no-store',
    });
    // Só limpa sessão quando o servidor responde com certeza (200 + ok:false).
    // 401/403/rede: não apaga — pode ser transitório ou auth mal classificada.
    if (res.status === 200) {
      const data = await res.json().catch(() => null);
      if (!data?.ok) {
        clearStoredSessionToken();
        return false;
      }
      return true;
    }
    if (res.status === 404) {
      clearStoredSessionToken();
      return false;
    }
    return !!token;
  } catch {
    return true;
  }
}

export async function loadRemoteToken() {
  try {
    const params = new URLSearchParams(location.search);
    const urlTok = params.get('token')?.trim();
    if (urlTok) {
      const stored = getStoredSessionToken();
      // Sessão do PIN tem prioridade sobre o pair-token curto do QR
      if (stored && stored !== urlTok) {
        remoteToken = stored;
        return remoteToken;
      }
      // Pair-token do QR fica só em memória — não gravar como sessão
      remoteToken = urlTok;
      return remoteToken;
    }
  } catch { /* ignore */ }
  const stored = getStoredSessionToken();
  if (stored) {
    remoteToken = stored;
    return remoteToken;
  }
  if (!['127.0.0.1', 'localhost', '::1'].includes(location.hostname)) {
    return null;
  }
  try {
    const res = await fetch('/api/remote-token', { cache: 'no-store' });
    if (res.ok) {
      remoteToken = (await res.text()).trim() || null;
      return remoteToken;
    }
  } catch { /* ignore */ }
  return null;
}

export function getRemoteToken() {
  return remoteToken;
}

function tokenQuery() {
  return remoteToken ? `&token=${encodeURIComponent(remoteToken)}` : '';
}

export class SyncHub {
  constructor(role = 'control') {
    this.role = role;
    this.listeners = new Set();
    this.processedIds = new Map();
    this.lastSeq = 0;
    this.pollAbort = null;
    this.pollRunning = false;
    this.pushEnabled = true; // control, remote, screen, stage — profiles WebView2 isolados precisam do HTTP
    this._batchQueue = [];
    this._batchScheduled = false;
    this._lastAckAt = 0;
    this.onAck = null;
    this._ws = null;
    this._useWebSocket = (role === 'remote' || role === 'control' || role === 'stage' || role === 'screen' || role === 'panel' || role === 'presenter')
      && isWebSocketSupported();
    this._pollInFlight = false;
    this._pollPausedForWs = false;
    this._pollBurstUntil = 0;
    this._wsLastMsgAt = 0;
  }

  _isWsHealthy() {
    if (!this._ws?.connected) return false;
    if (!this._wsLastMsgAt) return true;
    return (Date.now() - this._wsLastMsgAt) < WS_HEALTH_MS;
  }

  on(handler) {
    this.listeners.add(handler);
    return () => this.listeners.delete(handler);
  }

  _isDuplicate(id) {
    if (!id) return false;
    const now = Date.now();
    for (const [key, ts] of this.processedIds) {
      if (now - ts > DEDUP_WINDOW_MS) this.processedIds.delete(key);
    }
    if (this.processedIds.has(id)) return true;
    this.processedIds.set(id, now);
    return false;
  }

  _dispatch(message) {
    if (!message || message.from === this.role) return;
    if (this._isDuplicate(message.id)) return;
    if (message.type === 'slide_ack' || message.type === 'remote_ack') {
      this.noteAck(message);
    }
    for (const handler of this.listeners) {
      handler(message);
    }
  }

  /** Marca ack (caminho local ou hub) para recovery/health. */
  noteAck(message) {
    this._lastAckAt = Date.now();
    this.onAck?.(message);
  }

  async pushMessage(message) {
    if (!this.pushEnabled || !message) {
      return { ok: false, error: 'disabled', message };
    }
    const viaWs = !!(this._ws?.connected && this._ws.push(message));
    // WS-first: caminho autoritativo — HTTP só fallback (WS down ou push falhou)
    if (viaWs) {
      return { ok: true, status: 200, via: 'ws', message };
    }
    try {
      const res = await fetch('/api/sync/push' + (remoteToken ? `?token=${encodeURIComponent(remoteToken)}` : ''), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json; charset=utf-8' },
        body: JSON.stringify(message),
        signal: AbortSignal.timeout(8000),
      });
      if (res.ok) {
        const data = await res.json().catch(() => ({}));
        if (data.seq) this.lastSeq = Math.max(this.lastSeq, data.seq);
        return {
          ok: true,
          status: res.status,
          seq: data.seq,
          via: 'http',
          message,
        };
      }
      const err = res.status === 403 ? 'auth' : res.status === 429 ? 'rate_limit' : 'http';
      return { ok: false, status: res.status, error: err, message };
    } catch {
      return { ok: false, error: 'network', message };
    }
  }

  pushMessageBatched(message) {
    if (!this.pushEnabled) return message;
    // WS conectado: entrega imediata (sem esperar rAF + HTTP batch)
    if (this._ws?.connected && this._ws.push(message)) {
      return message;
    }
    this._batchQueue.push(message);
    if (!this._batchScheduled) {
      this._batchScheduled = true;
      TaskScheduler.scheduleFrame(() => {
        this._batchScheduled = false;
        const batch = this._batchQueue.splice(0);
        if (!batch.length) return;
        if (this._ws?.connected) {
          for (const msg of batch) {
            if (!this._ws.push(msg)) {
              void this.pushMessage(msg);
            }
          }
          return;
        }
        void this.pushMessageBatch(batch);
      });
    }
    return message;
  }

  async pushMessageBatch(messages) {
    if (!this.pushEnabled || !messages?.length) return;
    if (this._ws?.connected) {
      let allOk = true;
      for (const msg of messages) {
        if (!this._ws.push(msg)) {
          allOk = false;
          break;
        }
      }
      if (allOk) return;
    }
    try {
      const res = await fetch('/api/sync/push-batch' + (remoteToken ? `?token=${encodeURIComponent(remoteToken)}` : ''), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json; charset=utf-8' },
        body: buildPushBatchBody(messages),
        signal: AbortSignal.timeout(8000),
      });
      if (res.ok) {
        const data = await res.json().catch(() => ({}));
        if (data.lastSeq) this.lastSeq = Math.max(this.lastSeq, data.lastSeq);
      } else {
        for (const msg of messages) await this.pushMessage(msg);
      }
    } catch {
      for (const msg of messages) {
        try { await this.pushMessage(msg); } catch { /* offline */ }
      }
    }
  }

  async pushImmediate(type, payload = {}) {
    return this.pushMessage({
      id: randomId(),
      type,
      payload,
      ts: Date.now(),
      from: this.role,
    });
  }

  sendBatched(type, payload = {}) {
    return this.pushMessageBatched({
      id: randomId(),
      type,
      payload,
      ts: Date.now(),
      from: this.role,
    });
  }

  async fetchState({ apply = true } = {}) {
    try {
      const res = await fetch(`/api/sync/state?_=1${tokenQuery()}`, { cache: 'no-store' });
      if (!res.ok) return null;
      const text = await res.text();
      if (!text || text === '{}') return null;
      const parsed = JSON.parse(text);
      if (apply && parsed?.type) this._dispatch(parsed);
      return parsed;
    } catch {
      return null;
    }
  }

  async primeToLatest() {
    try {
      const res = await fetch(
        `/api/sync/poll?since=999999999&timeout=0${tokenQuery()}`,
        { cache: 'no-store', signal: AbortSignal.timeout(3000) }
      );
      if (!res.ok) return false;
      const data = await res.json();
      if (data.seq) this.lastSeq = Math.max(this.lastSeq, data.seq);
      return true;
    } catch {
      return false;
    }
  }

  _deviceContextForWs() {
    const fp = getDeviceFingerprint();
    const deviceId = getStoredDeviceId();
    let deviceLabel = '';
    if (this.role === 'remote') deviceLabel = getRemoteDeviceLabel() || 'Celular';
    else if (this.role === 'stage') deviceLabel = getStageDeviceLabel() || 'Stage';
    else if (this.role === 'screen') deviceLabel = 'Projetor';
    else if (this.role === 'presenter') deviceLabel = 'Presenter';
    return {
      deviceFingerprint: fp,
      deviceId,
      deviceLabel,
      clientId: this.role === 'remote' ? getRemoteClientId() : (this.role === 'stage' ? getStageClientId() : ''),
    };
  }

  _startWebSocket() {
    if (!this._useWebSocket || this._ws) return;
    this._ws = new SyncSocket(
      this.role,
      () => remoteToken || getStoredSessionToken() || '',
      () => this._deviceContextForWs(),
    );
    this._ws.on((msg) => {
      if (msg.type !== 'ws_open' && msg.type !== 'ws_close') {
        this._wsLastMsgAt = Date.now();
      }
      if (msg.type === 'ws_open') {
        this._failStreak = 0;
        this._pausePollForWs();
        this._dispatch({ type: 'ws_open', from: 'server' });
        // Catch-up: pedir backlog desde lastSeq (não avançar seq em ws_connected)
        try { this._ws.poll(this.lastSeq || 0); } catch { /* ignore */ }
      }
      if (msg.type === 'ws_close') {
        this._failStreak = Math.min((this._failStreak || 0) + 1, 5);
        this._resumePollAfterWs();
        // SyncSocket owns reconnect — do not call reconnect() here (CONNECTING race / console spam).
      }
      if (msg.type === 'network:rebind') {
        this._dispatch({ type: 'network:rebind', from: 'server' });
      }
      if (msg.from && msg.from !== this.role) this._dispatch(msg);
      else if (msg.type && !['ws_open', 'ws_close', 'network:rebind'].includes(msg.type)) this._dispatch(msg);
    });
    this._ws.connect();
  }

  /** Com WS UP: poll vira heartbeat lento (5–10 s). Sem WS: intervalo normal. */
  _pausePollForWs() {
    this._pollPausedForWs = true;
    if (this._pollTaskId) {
      TaskScheduler.setIntervalMs(this._pollTaskId, this._pollIntervalMs(false));
    }
  }

  _resumePollAfterWs() {
    this._pollPausedForWs = false;
    if (this._pollTaskId && this.pollRunning) {
      TaskScheduler.setIntervalMs(this._pollTaskId, this._pollIntervalMs(true));
    }
  }

  _startHttpPollLoop() {
    if (this._pollTaskId) return;
    this._failStreak = 0;
    this._idleStreak = 0;
    this._hasBroadcastChannel = typeof BroadcastChannel !== 'undefined';
    this._pollTaskId = `${TaskIds.SYNC_POLL}-${this.role}`;
    const initialMs = this._pollIntervalMs(true);
    try { TaskScheduler.start(); } catch { /* ignore */ }
    TaskScheduler.register({
      id: this._pollTaskId,
      kind: 'interval',
      intervalMs: initialMs,
      priority: 2,
      runWhenHidden: true,
      coalesce: true,
      fn: () => this._pollOnce(),
    });
  }

  async startPolling() {
    if (this.pollRunning) return;
    await loadRemoteToken();

    // Garante o loop — Remote não chamava markAppReady e o poll nunca rodava.
    try { TaskScheduler.start(); } catch { /* ignore */ }

    this.pollRunning = true;
    // Remote: HTTP poll SEMPRE (LAN/celular) + WS opcional como atalho.
    this._startHttpPollLoop();
    this._startWebSocket();
  }

  _pollIntervalMs(active = false) {
    const wsHealthy = this._isWsHealthy();
    // Screen: poll lento com WS saudável; rápido só como fallback
    if (this.role === 'screen') {
      if (wsHealthy) {
        return active ? POLL_SCREEN_WS_ACTIVE_MS : POLL_SCREEN_WS_IDLE_MS;
      }
      return active ? POLL_SCREEN_ACTIVE_MS : POLL_SCREEN_IDLE_MS;
    }
    // Remote após comando: burst curto para ACK/STAGE_STATE (mesmo com WS up)
    if (this.role === 'remote' && this._pollBurstUntil && Date.now() < this._pollBurstUntil) {
      return active ? 120 : 200;
    }
    // Com WebSocket ativo, HTTP poll é só heartbeat / fallback — evita martelar a rede
    const wsUp = !!(this._ws?.connected) || this._pollPausedForWs;
    if (wsUp) {
      // Remote: rede de segurança mais rápida (ACK + estado do culto)
      if (this.role === 'remote') {
        return active ? 400 : 1200;
      }
      // Heartbeat lento: 5s ativo / 10s idle — demais papéis
      return active ? 5000 : 10000;
    }
    if (this.role === 'remote') {
      return active ? 120 : 350;
    }
    if (this.role === 'control') {
      return active ? 120 : 320;
    }
    if (this.role === 'stage') {
      return active ? 150 : 450;
    }
    return active ? POLL_ACTIVE_MS : POLL_IDLE_MS;
  }

  /** Poll imediato (após comando Remote ou ACK). */
  async flushPoll() {
    if (!this.pollRunning || this._pollInFlight) return;
    this._idleStreak = 0;
    await this._pollOnce();
  }

  /**
   * Força poll rápido.
   * @param {{ burstMs?: number }} [opts] Remote: burstMs mantém 120–200ms por N ms + flush imediato.
   */
  boostPolling(opts = {}) {
    if (!this.pollRunning || !this._pollTaskId) return;
    this._idleStreak = 0;
    this._failStreak = 0;
    const burstMs = Number(opts?.burstMs);
    if (this.role === 'remote') {
      this._pollBurstUntil = Date.now() + (Number.isFinite(burstMs) && burstMs > 0 ? burstMs : 3500);
      TaskScheduler.setIntervalMs(this._pollTaskId, 120);
      void this.flushPoll();
      return;
    }
    TaskScheduler.setIntervalMs(this._pollTaskId, this._pollIntervalMs(true));
  }

  async _pollOnce() {
    if (!this.pollRunning || this._pollInFlight) return;
    this._pollInFlight = true;
    let hadMessages = false;
    try {
      const res = await fetch(
        `/api/sync/poll?since=${this.lastSeq}&timeout=${POLL_TIMEOUT_SEC}${tokenQuery()}`,
        { cache: 'no-store', signal: AbortSignal.timeout((POLL_TIMEOUT_SEC + 5) * 1000) }
      );
      if (res.ok) {
        this._failStreak = 0;
        const data = await res.json();
        if (data.seq) this.lastSeq = Math.max(this.lastSeq, data.seq);
        const messages = data.messages || [];
        hadMessages = messages.length > 0;
        for (const entry of messages) {
          if (entry.seq) this.lastSeq = Math.max(this.lastSeq, entry.seq);
          if (entry.message) this._dispatch(entry.message);
        }
        this._idleStreak = hadMessages ? 0 : (this._idleStreak || 0) + 1;
      } else {
        this._failStreak = Math.min((this._failStreak || 0) + 1, 5);
      }
    } catch {
      this._failStreak = Math.min((this._failStreak || 0) + 1, 5);
    } finally {
      this._pollInFlight = false;
    }
    if ((this._failStreak || 0) > 0) {
      const backoff = Math.min(POLL_IDLE_MS * 4 * Math.pow(2, this._failStreak), 30000);
      TaskScheduler.setIntervalMs(this._pollTaskId, backoff);
      return;
    }
    const idleDelay = (this._idleStreak || 0) >= 3
      ? this._pollIntervalMs(false)
      : (hadMessages ? this._pollIntervalMs(true) : this._pollIntervalMs(false));
    TaskScheduler.setIntervalMs(this._pollTaskId, idleDelay);
  }

  stopPolling() {
    this.pollRunning = false;
    this.pollAbort?.abort();
    if (this._ws) {
      this._ws.disconnect();
      this._ws = null;
    }
    if (this._pollTaskId) TaskScheduler.unregister(this._pollTaskId);
  }

  getLastAckAge() {
    if (!this._lastAckAt) return null;
    return Date.now() - this._lastAckAt;
  }

  getSyncStatus() {
    const ackAge = this.getLastAckAge();
    if (ackAge === null) return 'idle';
    if (ackAge < 5000) return 'ok';
    if (ackAge < 15000) return 'warn';
    return 'error';
  }
}

export const SyncMessageTypes = {
  SLIDE: 'slide',
  OVERLAY: 'overlay',
  OVERLAY_LAYER: 'overlay_layer',
  SETTINGS: 'settings',
  ASSETS: 'assets',
  AMBIENT: 'ambient',
  COUNTDOWN: 'countdown',
  HEARTBEAT: 'heartbeat',
  REQUEST_STATE: 'request_state',
  FULL_STATE: 'full_state',
  STAGE_STATE: 'stage_state',
  STAGE_NOTE: 'stage_note',
  STAGE_ALERT: 'stage_alert',
  STAGE_LAYOUT: 'stage_layout',
  REMOTE_CMD: 'remote_cmd',
  REMOTE_ACK: 'remote_ack',
  SLIDE_ACK: 'slide_ack',
  FONTS_RELOAD: 'fonts_reload',
};
