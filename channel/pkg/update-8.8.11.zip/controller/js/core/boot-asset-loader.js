/**
 * Boot Asset Loader — ponto único de boot HTTP (sem ?v= manual nos HTML).
 * Fetch /api/app-meta → injeta CSS → boot-inline → módulos da superfície.
 */
(function () {
  'use strict';

  if (location.protocol === 'file:') return;

  (function ensureRootFavicon() {
    var head = document.head;
    if (!head || head.querySelector('link[rel="icon"][href*="somosum.ico"]')) return;
    var links = [
      { rel: 'icon', href: '/launcher/somosum.ico', type: 'image/x-icon', sizes: 'any' },
      { rel: 'icon', href: '/IMG/LOGO/SOMOSUM.png', type: 'image/png' },
      { rel: 'apple-touch-icon', href: '/IMG/LOGO/SOMOSUM.png' },
    ];
    links.forEach(function (spec) {
      var link = document.createElement('link');
      link.rel = spec.rel;
      link.href = spec.href;
      if (spec.type) link.type = spec.type;
      if (spec.sizes) link.sizes = spec.sizes;
      head.appendChild(link);
    });
  })();

  var tag = document.currentScript;
  var surface = (tag && tag.getAttribute('data-surface')) || 'control';
  var skipPing = tag && tag.getAttribute('data-skip-ping') === '1';
  var extraScripts = (tag && tag.getAttribute('data-scripts') || '')
    .split(',').map(function (s) { return s.trim(); }).filter(Boolean);
  var extraModules = (tag && tag.getAttribute('data-modules') || '')
    .split(',').map(function (s) { return s.trim(); }).filter(Boolean);
  var registerSw = tag && tag.getAttribute('data-sw') === '1';

  var MAX_WAIT_MS = 120000;
  var start = Date.now();
  var meta = null;
  var revision = '8.7.8';

  function resolvePath(src) {
    if (!src) return src;
    if (/^https?:\/\//i.test(src)) return src;
    var s = String(src).replace(/^\.\//, '');
    return s.charAt(0) === '/' ? s : '/' + s;
  }

  function assetUrl(src) {
    var path = resolvePath(src).split('?')[0];
    return path + '?v=' + encodeURIComponent(revision);
  }

  function loadStylesheet(href) {
    return new Promise(function (resolve, reject) {
      var link = document.createElement('link');
      link.rel = 'stylesheet';
      link.href = assetUrl(href);
      link.onload = function () { resolve(); };
      link.onerror = function () { reject(new Error('css:' + href)); };
      document.head.appendChild(link);
    });
  }

  function loadScript(src, asModule) {
    return new Promise(function (resolve, reject) {
      var s = document.createElement('script');
      s.src = assetUrl(src);
      if (asModule) s.type = 'module';
      s.onload = function () { resolve(); };
      s.onerror = function () { reject(new Error('script:' + src)); };
      (asModule ? document.body : document.head).appendChild(s);
    });
  }

  function sleep(ms) {
    return new Promise(function (r) { setTimeout(r, ms); });
  }

  function ping() {
    var ctrl = typeof AbortController !== 'undefined' ? new AbortController() : null;
    var timer = ctrl ? setTimeout(function () { ctrl.abort(); }, 2500) : null;
    return fetch('/api/ping', { cache: 'no-store', signal: ctrl ? ctrl.signal : undefined })
      .then(function (r) { if (timer) clearTimeout(timer); return r.ok; })
      .catch(function () { if (timer) clearTimeout(timer); return false; });
  }

  function fetchMeta() {
    return fetch('/api/app-meta', { cache: 'no-store' })
      .then(function (r) { if (!r.ok) throw new Error('app-meta'); return r.json(); })
      .catch(function () {
        return {
          version: revision,
          assetRevision: revision,
          protocol: 3,
          assets: null,
        };
      });
  }

  function installMeta(m) {
    meta = m;
    revision = m.assetRevision || m.version || revision;
    window.__SOMOSUM_META__ = m;
    window.SOMOSUM_VERSION = m.version || revision;
    window.SOMOSUM_PROTOCOL = m.protocol != null ? m.protocol : 3;
    window.SOMOSUM_ASSET_REVISION = revision;
    try {
      localStorage.setItem('somosum.shell.assetRevision', revision);
    } catch (e) { /* ignore */ }
  }

  function getSurfaceAssets(name) {
    var assets = (meta && meta.assets) || {};
    var shared = assets.shared || {};
    var def = assets[name] || {};
    return {
      fa: shared.fa || [
        'vendor/fontawesome-pro/css/fontawesome.css',
        'vendor/fontawesome-pro/css/duotone.css',
        'css/fa-somosum.css',
      ],
      critical: (shared.critical || []).concat(def.critical || []),
      deferred: def.deferred || [],
      designer: def.designer || [],
      modules: (def.modules || []).concat(extraModules),
      scripts: (def.scripts || []).concat(extraScripts),
    };
  }

  function injectAssets(def) {
    var chain = Promise.resolve();
    def.fa.concat(def.critical).forEach(function (href) {
      chain = chain.then(function () { return loadStylesheet(href); });
    });
    return chain;
  }

  function loadDeferred(def) {
    if (!def.deferred.length) return;
    requestAnimationFrame(function () {
      def.deferred.forEach(function (href) {
        loadStylesheet(href).catch(function () {});
      });
    });
  }

  function waitForServer() {
    return new Promise(function (resolve, reject) {
      (async function () {
        if (await ping()) {
          window.__somosumServerReady = true;
          window.dispatchEvent(new Event('somosum-server-ready'));
          resolve();
          return;
        }
        var attempt = 0;
        while (!(await ping())) {
          if (Date.now() - start > MAX_WAIT_MS) {
            reject(new Error('timeout'));
            return;
          }
          await sleep(Math.min(120 + attempt * 80, 700));
          attempt++;
        }
        window.__somosumServerReady = true;
        window.dispatchEvent(new Event('somosum-server-ready'));
        resolve();
      })();
    });
  }

  function registerSwIfNeeded() {
    if (!registerSw || !('serviceWorker' in navigator)) return Promise.resolve();
    return navigator.serviceWorker.register(assetUrl('/sw.js'))
      .then(function (reg) {
        try { reg.update(); } catch (e) { /* ignore */ }
        if (reg.active) {
          reg.active.postMessage({ type: 'SET_REVISION', revision: revision });
        }
      })
      .catch(function () {});
  }

  function runBoot() {
    return (async function () {
      if (!skipPing && !window.__somosumServerReady) {
        await waitForServer();
      }
      installMeta(await fetchMeta());
      await registerSwIfNeeded();
      var def = getSurfaceAssets(surface);
      await injectAssets(def);
      await loadScript('js/core/boot-splash-api.js');
      if (window.__somosumPendingSplashConfig && window.__somosumInitBootSplash) {
        window.__somosumInitBootSplash(window.__somosumPendingSplashConfig);
      }
      var standalone = surface === 'panel' || surface === 'diagnostics' || surface === 'docs';
      if (standalone) {
        for (var si = 0; si < def.scripts.length; si++) {
          await loadScript(def.scripts[si], false);
        }
        for (var mi = 0; mi < def.modules.length; mi++) {
          await loadScript(def.modules[mi], true);
        }
        loadDeferred(def);
        return;
      }
      var bootTag = document.createElement('script');
      bootTag.src = assetUrl('js/core/boot-inline.js');
      bootTag.setAttribute('data-skip-ping', '1');
      if (def.modules.length) bootTag.setAttribute('data-modules', def.modules.join(','));
      if (def.scripts.length) bootTag.setAttribute('data-scripts', def.scripts.join(','));
      document.body.appendChild(bootTag);
      loadDeferred(def);
    })();
  }

  window.SOMOSUM_START_BOOT = function (opts) {
    opts = opts || {};
    if (opts.surface) surface = opts.surface;
    if (opts.scripts) extraScripts = String(opts.scripts).split(',').map(function (s) { return s.trim(); }).filter(Boolean);
    if (opts.modules) extraModules = String(opts.modules).split(',').map(function (s) { return s.trim(); }).filter(Boolean);
    return runBoot().catch(function (err) {
      console.error('[SOMOSUM boot-asset-loader]', err);
      var el = document.getElementById('boot-loading');
      if (el) {
        el.innerHTML = '<div class="su-boot-splash__card"><h1 class="su-boot-splash__title">Falha ao iniciar</h1>'
          + '<p class="su-boot-splash__status">Abra o SOMOSUM.exe e pressione Ctrl+F5.</p>'
          + '<button type="button" class="su-btn su-btn--primary" onclick="location.reload()" style="margin-top:1rem">Tentar novamente</button></div>';
      }
    });
  };

  if (tag && tag.getAttribute('data-autostart') !== '0') {
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', function () { window.SOMOSUM_START_BOOT(); });
    } else {
      window.SOMOSUM_START_BOOT();
    }
  }
})();
