export function createServerProbe() {
  let lastOk = true;
  let latencyMs = 0;
  return {
    async ping() {
      const t0 = performance.now();
      try {
        const res = await fetch('/api/ping', { cache: 'no-store', signal: AbortSignal.timeout(4000) });
        latencyMs = Math.round(performance.now() - t0);
        lastOk = res.ok;
      } catch {
        lastOk = false;
        latencyMs = 9999;
      }
      return { ok: lastOk, latencyMs };
    },
    sample() {
      return { ok: lastOk, latencyMs, fail: !lastOk, warn: lastOk && latencyMs > 800 };
    },
  };
}
