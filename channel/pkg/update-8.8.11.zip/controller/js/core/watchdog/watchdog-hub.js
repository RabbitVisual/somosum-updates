import { LogService, LogCategory } from '../logging/log-service.js';
import { createFpsProbe } from './fps-probe.js';
import { createMemoryProbe } from './memory-probe.js';
import { createServerProbe } from './server-probe.js';
import { createSyncProbe } from './sync-probe.js';
import { createIdbProbe } from './idb-probe.js';
import { TaskScheduler } from '../task-scheduler.js';
import { TaskIds } from '../task-registry.js';

let hub = null;

const SLEEP_HEALTHY_MS = 60000;
const SLEEP_WARN_MS = 30000;
const SLEEP_FAIL_MS = 12000;

export class WatchdogHub {
  constructor({ getAckAge = null } = {}) {
    this.fps = createFpsProbe();
    this.memory = createMemoryProbe();
    this.server = createServerProbe();
    this.sync = createSyncProbe(getAckAge);
    this.idb = null;
    this.metrics = {};
    this.handlers = new Set();
    this._healthyStreak = 0;
    this._sleepMs = SLEEP_HEALTHY_MS;
    this._running = false;
    this._lastPingAt = 0;
    this._disposeWatchdog = null;
  }

  static getInstance(opts) {
    if (!hub) hub = new WatchdogHub(opts);
    return hub;
  }

  async start() {
    if (this._running) return;
    this._running = true;
    this.idb = await createIdbProbe();
    this._disposeWatchdog = TaskScheduler.register({
      id: TaskIds.WATCHDOG_CYCLE,
      kind: 'interval',
      intervalMs: 8000,
      priority: 8,
      fn: () => this.runCycle(),
    });
  }

  onUpdate(fn) {
    this.handlers.add(fn);
    return () => this.handlers.delete(fn);
  }

  async runCycle() {
    if (!this._running) return;

    const needFpsSample = this._healthyStreak < 2 || this.metrics?.fps?.fail || this.metrics?.fps?.warn;
    if (needFpsSample) {
      await this.fps.measureWindow(600);
    }

    const now = Date.now();
    if (!this._lastPingAt || now - this._lastPingAt > 45000) {
      await this.server.ping();
      this._lastPingAt = now;
    }

    const samples = {
      fps: this.fps.sample(),
      memory: this.memory.sample(),
      server: this.server.sample(),
      sync: this.sync.sample(),
      idb: await this.idb.sample(),
      ts: now,
    };

    this.metrics = samples;
    this.handlers.forEach((h) => { try { h(samples); } catch { /* */ } });

    const anyFail = samples.fps.fail || samples.memory.fail || samples.server.fail || samples.sync.fail;
    const anyWarn = samples.fps.warn || samples.memory.warn || samples.server.warn || samples.sync.warn;

    if (anyFail) {
      this._healthyStreak = 0;
      this._sleepMs = SLEEP_FAIL_MS;
      if (samples.fps.fail) {
        LogService.warn('FPS baixo', { module: 'watchdog', category: LogCategory.PERFORMANCE, detail: samples.fps });
        window.dispatchEvent(new CustomEvent('somosum-watchdog-fps-low', { detail: samples.fps }));
        this.remediateFps();
      }
      if (samples.memory.fail) {
        LogService.warn('Memória alta', { module: 'watchdog', category: LogCategory.MEMORY, detail: samples.memory });
        window.dispatchEvent(new CustomEvent('somosum-watchdog-memory-high', { detail: samples.memory }));
        this.remediateMemory();
      }
    } else if (anyWarn) {
      this._healthyStreak = 0;
      this._sleepMs = SLEEP_WARN_MS;
      // Low-Spec Pro: avisar operador quando FPS < 20 (warn band)
      if (samples.fps?.lowSpecToast || samples.fps?.warn) {
        window.dispatchEvent(new CustomEvent('somosum-watchdog-fps-low', { detail: samples.fps }));
      }
    } else {
      this._healthyStreak += 1;
      this._sleepMs = this._healthyStreak >= 3 ? SLEEP_HEALTHY_MS : SLEEP_WARN_MS;
    }

    TaskScheduler.setIntervalMs(TaskIds.WATCHDOG_CYCLE, this._sleepMs);
    return samples;
  }

  getMetrics() {
    return this.metrics;
  }

  stop() {
    this._running = false;
    this.fps.stop();
    this._disposeWatchdog?.();
    this._disposeWatchdog = null;
    TaskScheduler.unregister(TaskIds.WATCHDOG_CYCLE);
  }

  remediateFps() {
    if (window.__SOMOSUM_LIVE_ACTIVE) {
      this.remediateLight();
      return;
    }
    import('../../render/asset-cache.js').then(({ ImageCache, VideoCache }) => {
      ImageCache.clear?.();
      VideoCache.clear?.();
    }).catch(() => {});
    document.querySelectorAll('.has-lyrics-fx').forEach((el) => el.classList.remove('has-lyrics-fx'));
  }

  remediateLight() {
    import('../../render/asset-cache.js').then(({ ImageCache, VideoCache }) => {
      ImageCache.trim?.(Math.max(8, Math.floor((ImageCache._maxSize || 20) * 0.5)));
      VideoCache.trim?.(1);
    }).catch(() => {});
    document.querySelectorAll('.has-lyrics-fx').forEach((el) => el.classList.remove('has-lyrics-fx'));
  }

  remediateMemory() {
    if (window.__SOMOSUM_LIVE_ACTIVE) {
      this.remediateLight();
      return;
    }
    this.remediateFps();
    if (window.gc) try { window.gc(); } catch { /* */ }
    import('../recovery/checkpoint-recovery.js').then((m) => m.CheckpointRecovery.create('watchdog-memory')).catch(() => {});
  }
}

export function getWatchdogHub(opts) {
  return WatchdogHub.getInstance(opts);
}
