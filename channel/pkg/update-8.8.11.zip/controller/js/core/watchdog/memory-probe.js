export function createMemoryProbe() {
  return {
    sample() {
      const mem = performance?.memory;
      if (!mem) return { ok: true, usedMB: null, limitMB: null };
      const usedMB = Math.round(mem.usedJSHeapSize / 1048576);
      const limitMB = Math.round(mem.jsHeapSizeLimit / 1048576);
      const ratio = usedMB / limitMB;
      return {
        usedMB,
        limitMB,
        ratio,
        ok: ratio < 0.85,
        warn: ratio >= 0.85 && ratio < 0.95,
        fail: ratio >= 0.95,
      };
    },
  };
}
