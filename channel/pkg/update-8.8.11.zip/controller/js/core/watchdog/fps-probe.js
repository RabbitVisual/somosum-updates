/** Amostra FPS sob demanda — sem loop contínuo de requestAnimationFrame. */
export function createFpsProbe() {
  let lastFps = 60;
  let measuring = false;

  return {
    start() { /* sem RAF permanente */ },
    stop() { measuring = false; },
    async measureWindow(ms = 700) {
      if (measuring) return lastFps;
      measuring = true;
      let frames = 0;
      const t0 = performance.now();
      return new Promise((resolve) => {
        const tick = (ts) => {
          frames += 1;
          if (ts - t0 < ms) {
            requestAnimationFrame(tick);
            return;
          }
          lastFps = Math.max(1, Math.round((frames * 1000) / (ts - t0)));
          measuring = false;
          resolve(lastFps);
        };
        requestAnimationFrame(tick);
      });
    },
    sample() {
      const fps = lastFps;
      // Low-Spec Pro: warn abaixo de 20fps (toast no Controle); fail abaixo de 15
      return {
        fps,
        ok: fps >= 20,
        warn: fps < 20 && fps >= 15,
        fail: fps < 15,
        lowSpecToast: fps < 20,
      };
    },
  };
}
