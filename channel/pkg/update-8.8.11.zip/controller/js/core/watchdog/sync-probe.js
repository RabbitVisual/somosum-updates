export function createSyncProbe(getAckAge) {
  return {
    sample() {
      const age = getAckAge?.() ?? null;
      if (age == null) return { ok: true, age: null };
      return { age, ok: age < 2000, warn: age >= 2000 && age < 5000, fail: age >= 5000 };
    },
  };
}
