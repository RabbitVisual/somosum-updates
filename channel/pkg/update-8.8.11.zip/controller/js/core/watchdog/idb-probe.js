export async function createIdbProbe() {
  return {
    async sample() {
      try {
        if (!indexedDB) return { ok: false, fail: true };
        const dbs = await indexedDB.databases?.();
        return { ok: true, stores: dbs?.length ?? 1 };
      } catch {
        return { ok: false, fail: true };
      }
    },
  };
}
