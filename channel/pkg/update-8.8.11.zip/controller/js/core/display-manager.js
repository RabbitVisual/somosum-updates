/** Display helpers — toda comunicação nativa via Engine Connectivity Manager. */

import { url as assetUrl } from './asset-registry.js';
let _displayListCache = null;
let _displayListCacheAt = 0;

function engine() {
  return typeof window !== 'undefined' ? window.Engine : null;
}

export function resolveDisplaysList(snapshotOverride = null) {
  const snap = snapshotOverride?.displays
    ? snapshotOverride
    : (snapshotOverride || getCachedDisplaySnapshot());
  if (snap?.displays?.length) return snap.displays;

  return engine()?.display?.list?.() || [];
}

export function parseDisplaysJson(json) {
  try {
    const parsed = typeof json === 'string' ? JSON.parse(json || '[]') : json;
    return Array.isArray(parsed) ? parsed : (parsed?.displays || []);
  } catch {
    return [];
  }
}

export function invalidateDisplayCache() {
  _displayListCache = null;
  _displayListCacheAt = 0;
}

export function listDisplaysFast(maxAgeMs = 1500) {
  const now = Date.now();
  if (_displayListCache && now - _displayListCacheAt < maxAgeMs) {
    return _displayListCache;
  }
  const list = resolveDisplaysList();
  if (list.length) {
    _displayListCache = list;
    _displayListCacheAt = now;
    return list;
  }
  return null;
}

export async function listDisplays() {
  const fast = listDisplaysFast(0);
  if (fast?.length) return fast;
  return resolveDisplaysList();
}

export function applyPushedDisplaySnapshot(snapshot) {
  if (!snapshot?.displays?.length) return null;
  engine()?.display?.applySnapshot?.(snapshot);
  _displayListCache = snapshot.displays;
  _displayListCacheAt = Date.now();
  return snapshot;
}

export function getCachedDisplaySnapshot(maxAgeMs = 5000) {
  const snap = engine()?.display?.getSnapshot?.();
  if (!snap) return null;
  if (!maxAgeMs || maxAgeMs <= 0) return snap;
  const ts = snap.timestamp || 0;
  if (!ts || Date.now() - ts <= maxAgeMs) return snap;
  return null;
}

export { DisplayProjectionEngine, bootDisplayProjectionEngine } from '../runtime/facades/display-runtime.js';

export function openStageNative(displayIndex = -1, opts = {}) {
  const eng = typeof window !== 'undefined' ? window.Engine : null;
  const shell = eng?.shell;
  const layout = opts.layout ? String(opts.layout) : '';
  if (layout) {
    try {
      localStorage.setItem('somosum-stage-pro-layout', layout);
      localStorage.setItem('somosum-stage-open-layout', layout);
    } catch { /* ignore */ }
  }
  if (shell?.isAvailable?.()) {
    try {
      if (Number.isFinite(displayIndex) && displayIndex >= 0) {
        shell.setStageDisplay?.(displayIndex);
      }
      if (opts.fullscreen != null) {
        shell.setStageFullscreen?.(!!opts.fullscreen);
      }
      if (layout && typeof shell.setStageOpenLayout === 'function') {
        shell.setStageOpenLayout(layout);
      }
      shell.openStage(Number.isFinite(displayIndex) ? displayIndex : -1);
      return true;
    } catch (err) {
      console.warn('[SOMOSUM] openStage nativo falhou', err);
    }
  }
  const port = window.location.port || '8765';
  const page = assetUrl('/stage.html');
  const q = layout ? `?layout=${encodeURIComponent(layout)}` : '';
  const url = `http://127.0.0.1:${port}${page}${q}`;
  const win = window.open(url, 'somosum-stage', 'width=1100,height=720,menubar=no,toolbar=no,location=no,status=no,resizable=yes');
  return !!win && !win.closed;
}

export function openProjectionNative(displayIndex = -1) {
  const engine = typeof window !== 'undefined' ? window.Engine : null;
  if (engine?.shell) {
    engine.shell.openProjection(displayIndex);
    return true;
  }
  return false;
}

export function ensureVisibleBounds(bounds, displays) {
  if (!bounds || !displays?.length) return bounds;
  const match = displays.find((d) =>
    bounds.x >= d.x && bounds.y >= d.y
    && bounds.x < d.x + (d.width || d.bounds?.w || 0)
    && bounds.y < d.y + (d.height || d.bounds?.h || 0)
  );
  if (match) return bounds;
  const primary = displays.find((d) => d.primary) || displays[0];
  const pw = primary.width || primary.bounds?.w || 1920;
  const ph = primary.height || primary.bounds?.h || 1080;
  const px = primary.x ?? primary.bounds?.x ?? 0;
  const py = primary.y ?? primary.bounds?.y ?? 0;
  return {
    x: px + Math.max(0, (pw - bounds.width) / 2),
    y: py + Math.max(0, (ph - bounds.height) / 2),
    width: bounds.width,
    height: bounds.height,
  };
}

if (typeof window !== 'undefined') {
  window.addEventListener('engine-display-changed', (ev) => {
    if (ev?.detail?.snapshot) applyPushedDisplaySnapshot(ev.detail.snapshot);
  });
  window.addEventListener('somosum-display-changed', (ev) => {
    if (ev?.detail?.snapshot) applyPushedDisplaySnapshot(ev.detail.snapshot);
  });
}
