/** Stub minimo embutido no HTML — roda do cache mesmo se servidor reiniciando. */
(function () {
  if (location.protocol === 'file:') return;
  var start = Date.now();
  var MAX = 120000;
  function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }
  function ping() {
    return fetch('/api/ping', { cache: 'no-store' })
      .then(function (res) { return res.ok; })
      .catch(function () { return false; });
  }
  function bootError(msg) {
    var el = document.getElementById('boot-loading');
    if (!el) return;
    el.innerHTML = '<div style="max-width:420px"><h1 style="font-size:1.2rem;margin:0 0 .75rem">Servidor offline</h1><p style="color:#888;line-height:1.6;margin:0 0 1rem">' + msg + '</p><button onclick="location.reload()" style="background:#d4c68d;color:#111;border:none;padding:.7rem 1.4rem;border-radius:6px;cursor:pointer">Tentar novamente</button></div>';
  }
  window.SOMOSUM_START_BOOT = function (opts) {
    opts = opts || {};
    (async function () {
      while (!(await ping())) {
        if (Date.now() - start > MAX) {
          bootError('Abra <strong>app\\SOMOSUM.exe</strong> e aguarde o icone na bandeja.');
          return;
        }
        await sleep(400);
      }
      window.__somosumServerReady = true;
      var s = document.createElement('script');
      s.src = 'js/core/boot-inline.js';
      s.setAttribute('data-skip-ping', '1');
      if (opts.scripts) s.setAttribute('data-scripts', opts.scripts);
      if (opts.modules) s.setAttribute('data-modules', opts.modules);
      document.body.appendChild(s);
    })();
  };
})();
