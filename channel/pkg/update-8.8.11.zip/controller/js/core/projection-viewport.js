/**
 * ProjectionViewport — contrato único client/DPR/bounds/safeArea/configVersion.
 * Compara snapshot nativo × window × client × visualViewport.
 */

export function captureProjectionViewport(viewportEl) {
  const el = viewportEl || document.documentElement;
  const vv = window.visualViewport;
  const dpr = window.devicePixelRatio || 1;
  const clientW = el.clientWidth || window.innerWidth || 0;
  const clientH = el.clientHeight || window.innerHeight || 0;
  const viewportW = vv?.width || clientW;
  const viewportH = vv?.height || clientH;
  const physicalW = Math.round(clientW * dpr);
  const physicalH = Math.round(clientH * dpr);
  const aspectRatio = clientH > 0 ? clientW / clientH : 16 / 9;

  return {
    clientWidth: clientW,
    clientHeight: clientH,
    viewportWidth: viewportW,
    viewportHeight: viewportH,
    devicePixelRatio: dpr,
    physicalWidth: physicalW,
    physicalHeight: physicalH,
    aspectRatio,
    displayId: el.dataset?.displayId || '',
    configurationVersion: el.dataset?.configurationVersion || '',
    safeArea: {
      top: parseFloat(el.style.getPropertyValue('--safe-top') || '0') || 0,
      right: parseFloat(el.style.getPropertyValue('--safe-right') || '0') || 0,
      bottom: parseFloat(el.style.getPropertyValue('--safe-bottom') || '0') || 0,
      left: parseFloat(el.style.getPropertyValue('--safe-left') || '0') || 0,
    },
    capturedAt: Date.now(),
  };
}

function closeEnough(a, b, tolerance = 3) {
  if (!Number.isFinite(a) || !Number.isFinite(b)) return true;
  return Math.abs(a - b) <= tolerance;
}

/**
 * @returns {{ mismatch: boolean, flags: string[], viewport: object }}
 */
export function compareViewportMismatch(viewport, display, snapshotMeta = {}) {
  const flags = [];
  if (!viewport || !display) return { mismatch: false, flags, viewport };

  const bounds = display.bounds || {};
  const mode = display.currentMode || {};
  const expectedW = bounds.w || mode.w || display.width || 0;
  const expectedH = bounds.h || mode.h || display.height || 0;
  const dpi = display.dpiScale || 1;

  if (expectedW > 0 && !closeEnough(viewport.clientWidth, expectedW, Math.max(4, expectedW * 0.06))) {
    flags.push('VIEWPORT');
  }
  if (expectedH > 0 && !closeEnough(viewport.clientHeight, expectedH, Math.max(4, expectedH * 0.06))) {
    flags.push('VIEWPORT');
  }
  if (dpi > 1 && !closeEnough(viewport.devicePixelRatio, dpi, 0.12)) {
    flags.push('DPI');
  }
  const configVersion = snapshotMeta.configurationVersion || display.configurationVersion || '';
  if (configVersion && viewport.configurationVersion
    && configVersion !== viewport.configurationVersion) {
    flags.push('DISPLAY');
  }
  const expectedAspect = display.aspectRatio || '';
  if (expectedAspect && expectedAspect !== 'unknown') {
    const parts = expectedAspect.split(':').map(Number);
    if (parts.length === 2 && parts[0] > 0 && parts[1] > 0) {
      const expectedRatio = parts[0] / parts[1];
      const actualRatio = viewport.aspectRatio || (viewport.clientWidth / Math.max(1, viewport.clientHeight));
      if (Math.abs(expectedRatio - actualRatio) > 0.08) flags.push('ASPECT');
    }
  }

  return { mismatch: flags.length > 0, flags: [...new Set(flags)], viewport };
}

export function buildProjectionGeometryDiagnostic({
  viewport,
  display,
  nativeDiagnostic = null,
  snapshot = null,
} = {}) {
  const mismatch = compareViewportMismatch(viewport, display, snapshot || {});
  return {
    ok: !mismatch.mismatch && (nativeDiagnostic?.ok !== false),
    flags: [...new Set([...(nativeDiagnostic?.flags || []), ...mismatch.flags])],
    viewport,
    display: display ? {
      deviceName: display.deviceName,
      bounds: display.bounds,
      dpiScale: display.dpiScale,
      aspectRatio: display.aspectRatio,
      configurationVersion: snapshot?.configurationVersion || display.configurationVersion,
    } : null,
    native: nativeDiagnostic || null,
    capturedAt: Date.now(),
  };
}

export function applyProjectionViewportDataset(viewportEl, viewport, snapshot, outputIndex = 1) {
  if (!viewportEl || !viewport) return;
  viewportEl.dataset.projectionViewport = `${Math.round(viewport.clientWidth)}x${Math.round(viewport.clientHeight)}`;
  viewportEl.dataset.devicePixelRatio = String(viewport.devicePixelRatio);
  if (snapshot?.configurationVersion) {
    viewportEl.dataset.configurationVersion = snapshot.configurationVersion;
  }
  if (snapshot?.displays?.length) {
    const want = Number(outputIndex) > 1 ? 'projection2' : 'projection';
    const proj = snapshot.displays.find((d) => d.role === want)
      || (want === 'projection'
        ? (snapshot.displays.find((d) => !d.primary) || snapshot.displays[0])
        : (snapshot.displays.find((d) => !d.primary && d.role !== 'projection') || snapshot.displays[0]));
    if (proj?.displayId) viewportEl.dataset.displayId = proj.displayId;
    if (proj?.role) viewportEl.dataset.displayRole = proj.role;
  }
}
