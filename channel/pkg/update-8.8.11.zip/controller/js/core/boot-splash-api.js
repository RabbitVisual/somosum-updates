/**
 * Boot splash compartilhado — API global (não é módulo ES).
 * Carregar após o markup #boot-loading (fora de #app).
 *
 * window.__somosumInitBootSplash({ minMs, messages, titleReady })
 * window.__somosumDismissBootSplash(done)  → Promise
 * window.__somosumBootSplashReady()        → marca UI pronta (espera paint)
 */
(function (global) {
  'use strict';
  if (global.__somosumBootSplashApi) return;

  var state = {
    t0: Date.now(),
    minMs: 1600,
    dismissed: false,
    uiReady: false,
    progressTimer: null,
    msgTimer: null,
    messages: [],
  };

  function $(id) { return document.getElementById(id); }

  function setProgress(pct) {
    var bar = $('boot-bar');
    if (bar) bar.style.width = Math.max(4, Math.min(100, pct)) + '%';
  }

  function setStatus(text) {
    var el = $('boot-status');
    if (!el) return;
    el.classList.remove('is-swap');
    el.textContent = text;
  }

  function waitPaint() {
    return new Promise(function (resolve) {
      requestAnimationFrame(function () {
        requestAnimationFrame(function () { resolve(); });
      });
    });
  }

  function init(opts) {
    opts = opts || {};
    state.t0 = Date.now();
    state.minMs = opts.minMs != null ? opts.minMs : 1600;
    state.dismissed = false;
    state.uiReady = false;
    state.messages = opts.messages || [
      'Conectando ao servidor local...',
      'Carregando a ordem do culto...',
      'Preparando a previa e a projecao...',
      'Sincronizando bibliotecas...',
      'Quase pronto...'
    ];
    global.__SOMOSUM_BOOT_T0 = state.t0;
    global.__SOMOSUM_MIN_SPLASH_MS = state.minMs;

    var msgIdx = 0;
    clearInterval(state.progressTimer);
    clearInterval(state.msgTimer);

    state.progressTimer = setInterval(function () {
      if (state.dismissed) return;
      var elapsed = Date.now() - state.t0;
      var pct = Math.min(90, 4 + (elapsed / state.minMs) * 86);
      setProgress(pct);
    }, 100);

    state.msgTimer = setInterval(function () {
      if (state.dismissed) return;
      var el = $('boot-status');
      if (!el || !state.messages.length) return;
      msgIdx = (msgIdx + 1) % state.messages.length;
      el.classList.add('is-swap');
      setTimeout(function () {
        if (state.dismissed) return;
        el.textContent = state.messages[msgIdx];
        el.classList.remove('is-swap');
      }, 260);
    }, 1100);
  }

  /** Chamar quando o shell/DOM principal já estiver pintado. */
  function markUiReady() {
    state.uiReady = true;
  }

  /** Atalho: marca pronto e inicia dismiss (respeita minMs). */
  function finish(done) {
    markUiReady();
    return dismiss(done);
  }

  function dismiss(done) {
    if (state.dismissed) {
      if (typeof done === 'function') done();
      return Promise.resolve();
    }

    return new Promise(function (resolve) {
      function tryFinish() {
        if (!state.uiReady) {
          setTimeout(tryFinish, 50);
          return;
        }
        var elapsed = Date.now() - state.t0;
        var wait = Math.max(0, state.minMs - elapsed);
        state.dismissed = true;
        clearInterval(state.progressTimer);
        clearInterval(state.msgTimer);
        setStatus('Tudo pronto');
        setProgress(100);

        setTimeout(function () {
          waitPaint().then(function () {
            var el = $('boot-loading');
            if (el) {
              el.classList.add('is-done');
              el.setAttribute('aria-busy', 'false');
              setTimeout(function () {
                el.remove();
                if (typeof done === 'function') done();
                resolve();
              }, 220);
            } else {
              if (typeof done === 'function') done();
              resolve();
            }
          });
        }, wait);
      }
      tryFinish();
    });
  }

  global.__somosumInitBootSplash = init;
  global.__somosumBootSplashReady = markUiReady;
  global.__somosumDismissBootSplash = dismiss;
  global.__somosumFinishBootSplash = finish;
  global.__somosumBootSplashApi = true;
})(typeof window !== 'undefined' ? window : globalThis);
