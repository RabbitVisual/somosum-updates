/**
 * ProtocolCompat — validação de compatibilidade entre superfícies e Engine.
 */
import { APP_META } from './app-meta.js';

function parseSemver(v) {
  const m = String(v || '0.0.0').match(/^(\d+)\.(\d+)\.(\d+)/);
  if (!m) return [0, 0, 0];
  return [+m[1], +m[2], +m[3]];
}

function semverLt(a, b) {
  const va = parseSemver(a);
  const vb = parseSemver(b);
  for (let i = 0; i < 3; i++) {
    if (va[i] < vb[i]) return true;
    if (va[i] > vb[i]) return false;
  }
  return false;
}

export function assertCompatible(localMeta, remoteMeta) {
  const local = localMeta || APP_META;
  const remote = remoteMeta || {};
  const lp = local.protocol ?? APP_META.protocol;
  const rp = remote.protocol ?? lp;
  const minP = local.minProtocol ?? APP_META.minProtocol;

  if (rp < minP) {
    return {
      ok: false,
      reason: 'protocol_too_old',
      userMessage: `Esta janela usa protocolo ${rp}, mas o sistema exige ${minP}. Atualize o SOMOSUM.exe e pressione Ctrl+F5.`,
    };
  }

  if (lp !== rp && remote.surface && remote.surface !== detectLocalSurface()) {
    return {
      ok: false,
      reason: 'protocol_mismatch',
      userMessage: 'Versões de protocolo diferentes entre superfícies. Reinicie todas as janelas pelo Painel.',
    };
  }

  const engineMin = local.engineMin || APP_META.engineMin;
  const remoteVer = remote.version || remote.runtimeVersion;
  if (remoteVer && semverLt(remoteVer, engineMin)) {
    return {
      ok: false,
      reason: 'engine_too_old',
      userMessage: `Engine ${remoteVer} abaixo do mínimo ${engineMin}. Reinstale ou atualize o pacote.`,
    };
  }

  const surfaceKey = remote.surface || detectLocalSurface();
  const minSurf = local.surfaces?.[surfaceKey]?.minVersion;
  if (minSurf && remoteVer && semverLt(remoteVer, minSurf)) {
    return {
      ok: false,
      reason: 'surface_too_old',
      userMessage: `${remote.label || surfaceKey} desatualizado (${remoteVer}). Mínimo: ${minSurf}.`,
    };
  }

  return { ok: true, reason: 'compatible', userMessage: '' };
}

export function detectLocalSurface() {
  const path = (location.pathname || '').split('/').pop() || '';
  const map = {
    'control.html': 'control',
    'screen.html': 'screen',
    'stage.html': 'stage',
    'remote.html': 'remote',
    'panel.html': 'panel',
    'diagnostics.html': 'diagnostics',
  };
  if (path.includes('panel')) return 'panel';
  if (path.includes('diagnostics')) return 'diagnostics';
  return map[path] || 'unknown';
}

export function buildPresenceMeta(extra = {}) {
  const meta = typeof window !== 'undefined' && window.__SOMOSUM_META__
    ? window.__SOMOSUM_META__
    : APP_META;
  return {
    version: meta.version,
    protocol: meta.protocol,
    assetRevision: meta.assetRevision,
    build: meta.build,
    surface: detectLocalSurface(),
    ...extra,
  };
}

export async function fetchEngineMeta() {
  try {
    const r = await fetch('/api/app-meta', { cache: 'no-store' });
    if (!r.ok) return null;
    return await r.json();
  } catch {
    return null;
  }
}

export async function validateWithEngine(localMeta) {
  const engine = await fetchEngineMeta();
  if (!engine) return { ok: true, reason: 'engine_unreachable', userMessage: '' };
  return assertCompatible(localMeta || APP_META, engine);
}

export function showCompatBanner(result) {
  if (!result || result.ok || !result.userMessage) return;
  const id = 'somosum-compat-banner';
  if (document.getElementById(id)) return;
  const el = document.createElement('div');
  el.id = id;
  el.setAttribute('role', 'alert');
  el.style.cssText = 'position:fixed;bottom:0;left:0;right:0;z-index:999998;padding:.85rem 1rem;background:#3a2010;color:#f3efe6;font:550 .88rem/1.45 Segoe UI,sans-serif;text-align:center;border-top:2px solid #d4c68d';
  el.textContent = result.userMessage;
  document.body.appendChild(el);
}
