/**
 * Fontes do SOMOSUM — pasta fonts/ (+ FONTE/) e fontes do sistema nos pickers.
 * Cada arquivo vira uma família real (Montserrat, Roboto…); Somosum UI/Display
 * continuam para arquivos de marca.
 */
let loaded = false;
let catalogLoaded = false;
let fontList = [];
let fontCatalog = [];

export const SYSTEM_FONT_STACKS = [
  'Segoe UI',
  'Georgia',
  'Arial',
  'Verdana',
  'Tahoma',
  'Trebuchet MS',
  'Times New Roman',
  'Palatino Linotype',
  'Impact',
  'Consolas',
];

const BASE_FONTS = [...SYSTEM_FONT_STACKS];
const BRAND_UI = 'Somosum UI';
const BRAND_DISPLAY = 'Somosum Display';

const WEIGHT_STYLE_RE = /[-_]?(thin|hairline|extralight|ultra-?light|ultralight|light|regular|normal|medium|semibold|semi-?bold|demibold|demi-?bold|extrabold|extra-?bold|ultrabold|ultra-?bold|bold|black|heavy|italic|oblique|variable|var|wght\d*)/gi;

/** Família canônica a partir do nome do arquivo. */
export function familyNameFromFile(filename) {
  const base = String(filename || '')
    .replace(/\.(woff2|woff|ttf|otf)$/i, '')
    .trim();
  if (!base) return BRAND_UI;

  const lower = base.toLowerCase();
  if (/somossum[\s_-]*ui|somos[\s_-]*ui|^ui[-_]/i.test(lower)) return BRAND_UI;
  if (/somossum[\s_-]*display|somos[\s_-]*display|display|serif|title|headline|palatino|antiqua/i.test(lower)
    && /somos|brand|display|serif|title|headline|palatino|antiqua/i.test(lower)
    && !/montserrat|roboto|opensans|open.?sans|lato|inter|poppins|raleway|nunito|playfair|merriweather|oswald|rubik|source/i.test(lower)) {
    // Arquivos explícitos de marca / display genérico
    if (/somos|display|serif|title|headline|palatino|antiqua/i.test(lower)) {
      if (/display|serif|title|headline|palatino|antiqua/i.test(lower)) return BRAND_DISPLAY;
    }
  }
  if (/^somossumui|^somosui/i.test(lower)) return BRAND_UI;
  if (/^somossumdisplay|^somosdisplay/i.test(lower)) return BRAND_DISPLAY;

  // Montserrat-Bold → Montserrat; OpenSans_Condensed-Bold → Open Sans Condensed
  let family = base
    .replace(WEIGHT_STYLE_RE, ' ')
    .replace(/([a-z])([A-Z])/g, '$1 $2')
    .replace(/[-_]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
  // Prefixo de pasta: fontes_xx / font-xxx
  family = family.replace(/^(fontes?|fonts?|family)\s+/i, '').trim();
  if (!family) family = base.split(/[-_]/)[0] || base;
  if (/^open\s*sans(\s+semi)?\s*condensed$/i.test(family)) {
    return /semi/i.test(family) ? 'Open Sans Semi Condensed' : 'Open Sans Condensed';
  }
  if (/^open\s*sans$/i.test(family)) return 'Open Sans';
  if (/^roboto(\s+semi)?\s*condensed$/i.test(family)) {
    return /semi/i.test(family) ? 'Roboto Semi Condensed' : 'Roboto Condensed';
  }
  if (/^roboto$/i.test(family)) return 'Roboto';
  if (/^montserrat$/i.test(family)) return 'Montserrat';
  if (/^source\s*sans/i.test(family)) return 'Source Sans 3';
  if (/^noto\s*sans/i.test(family)) return 'Noto Sans';
  if (/^pt\s*sans/i.test(family)) return 'PT Sans';
  // Title Case
  return family.replace(/\b\w/g, (c) => c.toUpperCase());
}

function brandFamilyForFile(name) {
  return familyNameFromFile(name);
}

/** Extrai peso/estilo do nome do arquivo para @font-face correto. */
export function parseFontFaceMeta(filename) {
  const base = String(filename || '').replace(/\.(woff2|woff|ttf|otf)$/i, '');
  let weight = 400;
  let style = 'normal';
  const lower = base.toLowerCase();

  if (/\b(thin|hairline)\b/.test(lower)) weight = 100;
  else if (/\b(extralight|ultra-light|ultralight)\b/.test(lower)) weight = 200;
  else if (/\blight\b/.test(lower)) weight = 300;
  else if (/\bmedium\b/.test(lower)) weight = 500;
  else if (/\b(semibold|semi-bold|demibold|demi-bold)\b/.test(lower)) weight = 600;
  else if (/\b(extrabold|extra-bold|ultrabold|ultra-bold)\b/.test(lower)) weight = 800;
  else if (/\bbold\b/.test(lower)) weight = 700;
  else if (/\b(black|heavy)\b/.test(lower)) weight = 900;

  if (/\bitalic\b|\boblique\b/.test(lower)) style = 'italic';

  return {
    family: familyNameFromFile(filename),
    weight,
    style,
  };
}

/** Família efetiva: pasta (prioridade) ou nome do arquivo. */
export function resolveFontFileFamily(file) {
  const fromFolder = String(file?.family || '').trim();
  if (fromFolder) return fromFolder;
  return familyNameFromFile(file?.name || file?.path || '');
}

function buildFontFaceRule(file) {
  const family = resolveFontFileFamily(file);
  const meta = parseFontFaceMeta(file.name);
  const ext = (file.name || '').toLowerCase();
  const fmt = ext.endsWith('.woff2')
    ? 'woff2'
    : ext.endsWith('.woff')
      ? 'woff'
      : ext.endsWith('.otf')
        ? 'opentype'
        : 'truetype';
  const safeFamily = String(family || meta.family).replace(/'/g, "\\'");
  return `@font-face{font-family:'${safeFamily}';src:url('/api/fonts/file?name=${encodeURIComponent(file.name)}') format('${fmt}');font-weight:${meta.weight};font-style:${meta.style};font-display:swap;}`;
}

export function resetFontsCache() {
  loaded = false;
  catalogLoaded = false;
  fontList = [];
  fontCatalog = [];
  document.getElementById('somosum-fonts')?.remove();
}

/** Lista fontes disponíveis sem injetar @font-face na UI. */
export async function fetchFontCatalog() {
  if (catalogLoaded) return fontCatalog;
  if (location.protocol === 'file:') {
    catalogLoaded = true;
    return fontCatalog;
  }
  try {
    const res = await fetch('/api/fonts', { cache: 'no-store' });
    if (!res.ok) {
      catalogLoaded = true;
      return fontCatalog;
    }
    const files = await res.json();
    if (!Array.isArray(files)) {
      catalogLoaded = true;
      return fontCatalog;
    }
    fontCatalog = files.filter((f) => f?.name);
    fontList = [...new Set(fontCatalog.map((f) => resolveFontFileFamily(f)).filter(Boolean))]
      .sort((a, b) => a.localeCompare(b, 'pt-BR'));
    catalogLoaded = true;
  } catch {
    catalogLoaded = true;
  }
  return fontCatalog;
}

function injectFontFaceSheet(files) {
  if (!files.length) return;
  const sheet = document.getElementById('somosum-fonts') || document.createElement('style');
  sheet.id = 'somosum-fonts';
  sheet.textContent = files.map(buildFontFaceRule).join('\n');
  if (!sheet.parentNode) document.head.appendChild(sheet);
}

/**
 * Carrega fontes custom para projeção/designer/controle.
 * @param {{ injectFaces?: boolean, force?: boolean }} opts
 */
export async function loadCustomFonts(opts = {}) {
  const injectFaces = opts.injectFaces !== false;
  const force = !!opts.force;
  if (force) resetFontsCache();

  if (loaded && (!injectFaces || document.getElementById('somosum-fonts'))) {
    return fontList;
  }

  const files = await fetchFontCatalog();
  if (injectFaces && files.length) {
    injectFontFaceSheet(files);
    await preloadFontsForCanvas(fontList);
  }

  loaded = true;
  return fontList;
}

/** Assinatura leve do catálogo — detecta fontes novas sem baixar os arquivos. */
export function fontCatalogSignature(files = fontCatalog) {
  return (files || [])
    .map((f) => `${f.name}:${f.size || 0}:${f.family || ''}`)
    .sort()
    .join('|');
}

let _fontWatchTimer = null;
let _lastFontSig = '';

/**
 * Observa view/fonts + FONTE/fonte e reinjeta @font-face quando o operador adiciona arquivos.
 * @param {{ intervalMs?: number, onChange?: (families: string[]) => void }} opts
 */
export function startFontCatalogWatch(opts = {}) {
  const intervalMs = Math.max(4000, Number(opts.intervalMs) || 8000);
  const onChange = typeof opts.onChange === 'function' ? opts.onChange : null;
  if (_fontWatchTimer) return;
  _lastFontSig = fontCatalogSignature();
  const tick = async () => {
    try {
      resetFontsCache();
      const files = await fetchFontCatalog();
      const sig = fontCatalogSignature(files);
      if (sig && sig !== _lastFontSig) {
        _lastFontSig = sig;
        injectFontFaceSheet(files);
        await preloadFontsForCanvas(fontList);
        loaded = true;
        onChange?.(fontList);
        try {
          window.dispatchEvent(new CustomEvent('somosum-fonts-changed', { detail: { families: fontList } }));
        } catch { /* ignore */ }
      } else {
        loaded = true;
      }
    } catch { /* ignore */ }
  };
  _fontWatchTimer = setInterval(tick, intervalMs);
  // Primeira checagem um pouco depois do boot
  setTimeout(tick, 2500);
}

export function stopFontCatalogWatch() {
  if (_fontWatchTimer) {
    clearInterval(_fontWatchTimer);
    _fontWatchTimer = null;
  }
}

/** Força recarregar catálogo + @font-face (botão Recarregar fontes). */
export async function reloadCustomFonts() {
  const list = await loadCustomFonts({ injectFaces: true, force: true });
  _lastFontSig = fontCatalogSignature();
  try {
    window.dispatchEvent(new CustomEvent('somosum-fonts-changed', { detail: { families: list } }));
  } catch { /* ignore */ }
  return list;
}

/** Konva desenha em canvas — fontes precisam estar carregadas via document.fonts antes do draw. */
export async function preloadFontsForCanvas(families = []) {
  if (!document.fonts?.load) return;
  const all = [...new Set([...BASE_FONTS, ...families].filter(Boolean))];
  await Promise.all(
    all.map(async (name) => {
      try {
        await document.fonts.load(`16px "${name}"`);
        await document.fonts.load(`400 48px "${name}"`);
        await document.fonts.load(`600 48px "${name}"`);
        await document.fonts.load(`700 64px "${name}"`);
        await document.fonts.load(`italic 48px "${name}"`);
      } catch { /* fonte indisponivel */ }
    }),
  );
}

export function getCustomFontList() {
  return [...fontList];
}

/** Opções do seletor: pasta fonts/ primeiro, depois sistema. */
export function getFontPickerOptions({ includeEmpty = true } = {}) {
  const custom = getCustomFontList();
  const system = SYSTEM_FONT_STACKS.filter((f) => !custom.includes(f));
  const opts = [
    ...custom.map((f) => ({ value: f, label: f, group: 'fonts' })),
    ...system.map((f) => ({ value: f, label: f, group: 'system' })),
  ];
  if (includeEmpty) return [{ value: '', label: 'Padrão do sistema', group: 'default' }, ...opts];
  return opts;
}

/** HTML <option> / <optgroup> para selects de fonte (só famílias). */
export function fontPickerOptionsHtml(selected = '', { includeEmpty = true, extra = [] } = {}) {
  const custom = [...new Set([...getCustomFontList(), ...(extra || [])].filter(Boolean))]
    .sort((a, b) => a.localeCompare(b, 'pt-BR'));
  const system = SYSTEM_FONT_STACKS.filter((f) => !custom.includes(f));
  const esc = (t) => String(t ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/"/g, '&quot;');
  const opt = (value, label = value) =>
    `<option value="${esc(value)}" ${selected === value ? 'selected' : ''}>${esc(label)}</option>`;
  let html = includeEmpty ? opt('', 'Padrão do sistema') : '';
  if (custom.length) {
    html += `<optgroup label="Pasta fonts/FONTE (${custom.length})">${custom.map((f) => opt(f)).join('')}</optgroup>`;
  }
  if (system.length) {
    html += `<optgroup label="Sistema Windows">${system.map((f) => opt(f)).join('')}</optgroup>`;
  }
  if (selected && selected !== '' && !custom.includes(selected) && !system.includes(selected)) {
    html = `${opt(selected)}${html}`;
  }
  return html;
}

/** HTML <option> / <optgroup> para selects de fonte. */
export function fontPickerHtml(selected = '', opts = {}) {
  return fontPickerOptionsHtml(selected, opts);
}

export function fontVariantOptionsHtml(family, weight, style) {
  const variants = getVariantsForFamily(family);
  if (!variants.length) return '';
  const key = fontVariantKey(weight, style);
  const esc = (t) => String(t ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/"/g, '&quot;');
  return variants.map((v) =>
    `<option value="${esc(v.key)}" ${v.key === key ? 'selected' : ''}>${esc(v.label)}</option>`
  ).join('');
}

export function fontDisplayName(filename) {
  return familyNameFromFile(filename);
}

export function applyTextTransform(text, transform) {
  if (!text || !transform || transform === 'none') return text ?? '';
  if (transform === 'uppercase') return text.toUpperCase();
  if (transform === 'lowercase') return text.toLowerCase();
  if (transform === 'capitalize') {
    return text.replace(/\S+/g, (w) => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase());
  }
  return text;
}

export function fontFamilyCss(family, weightStyle = null) {
  if (!family) return 'var(--font-sans)';
  const ff = `'${family}', var(--font-sans)`;
  if (!weightStyle) return ff;
  return ff;
}

export const SYSTEM_FONT_VARIANTS = [
  { key: '400:normal', weight: 400, style: 'normal', label: 'Regular' },
  { key: '500:normal', weight: 500, style: 'normal', label: 'Medium' },
  { key: '600:normal', weight: 600, style: 'normal', label: 'SemiBold' },
  { key: '700:normal', weight: 700, style: 'normal', label: 'Bold' },
  { key: '400:italic', weight: 400, style: 'italic', label: 'Itálico' },
  { key: '700:italic', weight: 700, style: 'italic', label: 'Bold Itálico' },
];

export function fontVariantKey(weight, style) {
  const w = Number(weight) || 400;
  const s = style === 'italic' ? 'italic' : 'normal';
  return `${w}:${s}`;
}

export function parseFontVariantKey(key) {
  if (!key) return { weight: 400, style: 'normal' };
  const [w, s] = String(key).split(':');
  return { weight: Number(w) || 400, style: s === 'italic' ? 'italic' : 'normal' };
}

export function variantLabel(weight, style) {
  const w = Number(weight) || 400;
  const italic = style === 'italic';
  const names = {
    100: 'Thin',
    200: 'ExtraLight',
    300: 'Light',
    400: 'Regular',
    500: 'Medium',
    600: 'SemiBold',
    700: 'Bold',
    800: 'ExtraBold',
    900: 'Black',
  };
  const base = names[w] || `Peso ${w}`;
  return italic ? `${base} Itálico` : base;
}

/** Agrupa arquivos da pasta fonts/ por família (nome da subpasta) → variantes. */
export function getFontFamilyMap(catalog = fontCatalog) {
  const map = new Map();
  for (const file of catalog || []) {
    if (!file?.name) continue;
    const meta = parseFontFaceMeta(file.name);
    const family = resolveFontFileFamily(file) || meta.family;
    if (!family) continue;
    if (!map.has(family)) map.set(family, []);
    const key = fontVariantKey(meta.weight, meta.style);
    const list = map.get(family);
    if (!list.some((v) => v.key === key)) {
      list.push({
        key,
        weight: meta.weight,
        style: meta.style,
        label: variantLabel(meta.weight, meta.style),
        file: file.name,
        path: file.path || file.name,
      });
    }
  }
  for (const [family, variants] of map) {
    variants.sort((a, b) => {
      if (a.style !== b.style) return a.style === 'normal' ? -1 : 1;
      return a.weight - b.weight;
    });
    map.set(family, variants);
  }
  return map;
}

export function isCustomFontFamily(family) {
  if (!family) return false;
  return getFontFamilyMap().has(family);
}

/** Variantes disponíveis: arquivos reais em fonts/ ou presets do sistema. */
export function getVariantsForFamily(family) {
  if (!family) return [];
  const custom = getFontFamilyMap().get(family);
  if (custom?.length) return custom;
  if (SYSTEM_FONT_STACKS.includes(family)) return [...SYSTEM_FONT_VARIANTS];
  return [...SYSTEM_FONT_VARIANTS];
}

export function resolveFontStyle(style = {}) {
  const family = style.fontFamily || null;
  const weight = style.fontWeight != null ? Number(style.fontWeight) : 400;
  const fontStyle = style.fontStyle === 'italic' ? 'italic' : 'normal';
  return { fontFamily: family, fontWeight: weight, fontStyle };
}

export function fontWeightStyleCssDecl(style = {}) {
  const parts = [];
  if (style.fontWeight != null && style.fontWeight !== '') {
    parts.push(`--font-weight: ${Number(style.fontWeight) || 400}`);
  }
  if (style.fontStyle) {
    parts.push(`--font-style: ${style.fontStyle}`);
  }
  return parts.length ? `${parts.join('; ')};` : '';
}
