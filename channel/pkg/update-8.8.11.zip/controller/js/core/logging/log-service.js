/**
 * LogService — logging profissional com níveis, categorias, ring buffer e flush em batch.
 */
import { buildLogContext, formatStack } from './log-context.js';

let serverOk = null;
let serverCheckAt = 0;

async function canReachServer() {
  if (location.protocol === 'file:') return false;
  const now = Date.now();
  if (serverOk !== null && now - serverCheckAt < 5000) return serverOk;
  try {
    const res = await fetch('/api/ping', { cache: 'no-store', signal: AbortSignal.timeout(3000) });
    serverOk = res.ok;
  } catch {
    serverOk = false;
  }
  serverCheckAt = now;
  return serverOk;
}

export const LogLevel = {
  TRACE: 'TRACE',
  DEBUG: 'DEBUG',
  INFO: 'INFO',
  WARN: 'WARN',
  ERROR: 'ERROR',
  FATAL: 'FATAL',
};

export const LogCategory = {
  GENERAL: 'GENERAL',
  SYNC: 'SYNC',
  NETWORK: 'NETWORK',
  DATABASE: 'DATABASE',
  RENDER: 'RENDER',
  PERFORMANCE: 'PERFORMANCE',
  MEMORY: 'MEMORY',
  CPU: 'CPU',
  GPU: 'GPU',
  PROJECTION: 'PROJECTION',
  STAGE: 'STAGE',
  REMOTE: 'REMOTE',
  BOOT: 'BOOT',
  LYRICS: 'LYRICS',
};

const LEVEL_PRIORITY = {
  TRACE: 0,
  DEBUG: 1,
  INFO: 2,
  WARN: 3,
  ERROR: 4,
  FATAL: 5,
};

const RING_MAX = 500;
const FLUSH_MS = 2000;
const BATCH_MAX = 25;

let logFlushRegistered = false;

const ringBuffer = [];
const pendingFlush = [];
let flushTimer = null;
let minLevel = LogLevel.INFO;
let consoleMirror = true;
/** Console só espelha WARN+ por padrão (evita spam LYRICS/PERFORMANCE). */
let consoleMirrorMinLevel = LogLevel.WARN;

function shouldLog(level) {
  return (LEVEL_PRIORITY[level] ?? 2) >= (LEVEL_PRIORITY[minLevel] ?? 2);
}

function shouldMirrorConsole(level) {
  if (!consoleMirror) return false;
  return (LEVEL_PRIORITY[level] ?? 2) >= (LEVEL_PRIORITY[consoleMirrorMinLevel] ?? 3);
}

function pushRing(entry) {
  ringBuffer.push(entry);
  if (ringBuffer.length > RING_MAX) ringBuffer.shift();
}

function scheduleFlush() {
  ensureLogFlushTask();
  if (flushTimer) return;
  flushTimer = setTimeout(() => {
    flushTimer = null;
    flushToServer();
  }, FLUSH_MS);
}

function ensureLogFlushTask() {
  if (logFlushRegistered) return;
  logFlushRegistered = true;
  import('../task-scheduler.js').then(({ TaskScheduler }) => {
    TaskScheduler.register({
      id: 'log-flush-idle',
      kind: 'idle',
      priority: 10,
      fn: () => {
        if (pendingFlush.length) flushToServer();
      },
    });
  }).catch(() => {});
}

async function flushToServer() {
  if (!pendingFlush.length) return;
  if (location.protocol === 'file:') {
    pendingFlush.length = 0;
    return;
  }
  if (!(await canReachServer())) {
    scheduleFlush();
    return;
  }
  const batch = pendingFlush.splice(0, BATCH_MAX);
  try {
    await fetch('/api/log', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json; charset=utf-8' },
      body: JSON.stringify({ batch }),
      keepalive: true,
    });
  } catch {
    pendingFlush.unshift(...batch);
    scheduleFlush();
  }
  if (pendingFlush.length) scheduleFlush();
}

const entryListeners = new Set();

function createEntry(level, message, { module, category, detail, stack, latencyMs } = {}) {
  const entry = {
    level,
    message: String(message ?? '').slice(0, 2000),
    context: buildLogContext({ module, category }),
    detail: detail ?? null,
    stack: stack ? String(stack).slice(0, 4000) : null,
    latencyMs: latencyMs ?? null,
  };
  pushRing(entry);
  pendingFlush.push(entry);
  scheduleFlush();
  if (shouldMirrorConsole(level)) {
    const tag = `[SOMOSUM:${category || 'GENERAL'}]`;
    const fn = level === LogLevel.ERROR || level === LogLevel.FATAL
      ? console.error
      : level === LogLevel.WARN
        ? console.warn
        : level === LogLevel.DEBUG || level === LogLevel.TRACE
          ? console.debug
          : console.info;
    fn(tag, message, detail || '');
  }
  if (LEVEL_PRIORITY[level] >= LEVEL_PRIORITY[LogLevel.WARN]) {
    entryListeners.forEach((fn) => {
      try { fn(entry); } catch { /* ignore */ }
    });
  }
  return entry;
}

export const LogService = {
  setMinLevel(level) {
    if (LEVEL_PRIORITY[level] != null) minLevel = level;
  },
  setConsoleMirror(on, { minLevel: mirrorMin } = {}) {
    consoleMirror = !!on;
    if (mirrorMin && LEVEL_PRIORITY[mirrorMin] != null) {
      consoleMirrorMinLevel = mirrorMin;
    }
  },
  setConsoleMirrorMinLevel(level) {
    if (LEVEL_PRIORITY[level] != null) consoleMirrorMinLevel = level;
  },
  /** Assina entradas WARN+ (ex.: badge do console DEV). */
  onSignificant(handler) {
    if (typeof handler === 'function') entryListeners.add(handler);
    return () => entryListeners.delete(handler);
  },
  trace(message, opts) {
    if (!shouldLog(LogLevel.TRACE)) return null;
    return createEntry(LogLevel.TRACE, message, opts);
  },
  debug(message, opts) {
    if (!shouldLog(LogLevel.DEBUG)) return null;
    return createEntry(LogLevel.DEBUG, message, opts);
  },
  info(message, opts) {
    if (!shouldLog(LogLevel.INFO)) return null;
    return createEntry(LogLevel.INFO, message, opts);
  },
  warn(message, opts) {
    if (!shouldLog(LogLevel.WARN)) return null;
    return createEntry(LogLevel.WARN, message, opts);
  },
  error(message, opts) {
    return createEntry(LogLevel.ERROR, message, {
      ...opts,
      stack: opts?.stack || formatStack(opts?.err),
    });
  },
  fatal(message, opts) {
    return createEntry(LogLevel.FATAL, message, {
      ...opts,
      stack: opts?.stack || formatStack(opts?.err),
    });
  },
  getRingBuffer() {
    return ringBuffer.slice();
  },
  flush() {
    return flushToServer();
  },
};

/** Adapter retrocompatível com logToServer(level, message, detail). */
export async function logToServer(level, message, detail = null) {
  const lvl = String(level || 'INFO').toUpperCase();
  const cat = detail?.category || LogCategory.GENERAL;
  const mod = detail?.module || 'legacy';
  const stack = detail?.stack || null;
  const { category, module, stack: _s, ...rest } = detail || {};
  LogService[lvl.toLowerCase()]?.(message, {
    module: mod,
    category: cat,
    detail: Object.keys(rest).length ? rest : null,
    stack,
  });
  return true;
}
