import { getAppMeta, APP_VERSION } from '../app-meta.js';

const ROLE_MAP = {
  'control.html': 'control',
  'screen.html': 'screen',
  'stage.html': 'stage',
  'remote.html': 'remote',
};

export function detectSurfaceRole() {
  const path = (location.pathname || '').split('/').pop() || '';
  return ROLE_MAP[path] || path.replace('.html', '') || 'unknown';
}

export function getMemorySnapshot() {
  const mem = performance?.memory;
  if (!mem) return null;
  return {
    usedJSHeapSize: mem.usedJSHeapSize,
    totalJSHeapSize: mem.totalJSHeapSize,
    jsHeapSizeLimit: mem.jsHeapSizeLimit,
  };
}

export function buildLogContext({ module = 'core', category = 'GENERAL', extra = null } = {}) {
  const meta = getAppMeta();
  const ctx = {
    ts: new Date().toISOString(),
    module,
    category,
    version: meta.version || APP_VERSION,
    build: meta.build,
    protocol: meta.protocol,
    assetRevision: meta.assetRevision,
    surface: detectSurfaceRole(),
    url: location.pathname,
    memory: getMemorySnapshot(),
    userAgent: navigator.userAgent?.slice(0, 120) || '',
  };
  if (extra && typeof extra === 'object') Object.assign(ctx, extra);
  return ctx;
}

export function formatStack(err) {
  if (!err) return null;
  if (typeof err === 'string') return err;
  if (err.stack) return String(err.stack).slice(0, 4000);
  if (err.message) return String(err.message);
  return String(err);
}

/** Abort/timeout esperado em fetch com AbortSignal — não é falha de boot. */
export function isBenignAbort(err) {
  if (!err) return false;
  const name = err.name || '';
  const msg = String(err.message || err || '');
  if (name === 'AbortError' || name === 'TimeoutError') return true;
  if (/aborted a request|signal timed out|operation was aborted/i.test(msg)) return true;
  return false;
}

/** Erros de negócio esperados — não são falha de boot. */
export function isBenignAppError(err) {
  if (isBenignAbort(err)) return true;
  const msg = String(err?.message || err || '');
  return msg === 'protected_song' || msg === 'not_system_default';
}
