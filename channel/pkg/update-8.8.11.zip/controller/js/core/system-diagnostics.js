/**
 * Motor de diagnóstico SOMOSUM — verifica servidor, pacote, rede, monitores e runtime.
 * Retorna checks com status, detalhe e solução acionável.
 */

import { localSyncAvailable } from './local-sync-bridge.js';

export const STATUS = { OK: 'ok', WARN: 'warn', FAIL: 'fail' };

function check(id, status, title, detail, solution = '', action = null) {
  return { id, status, title, detail, solution, action };
}

function countSummary(checks) {
  const summary = { ok: 0, warn: 0, fail: 0, total: checks.length };
  checks.forEach((c) => {
    if (c.status === STATUS.OK) summary.ok += 1;
    else if (c.status === STATUS.WARN) summary.warn += 1;
    else summary.fail += 1;
  });
  summary.ready = summary.fail === 0 && summary.warn <= 2;
  return summary;
}

async function timedFetch(url, ms = 6000) {
  const ctrl = typeof AbortController !== 'undefined' ? new AbortController() : null;
  const timer = ctrl ? setTimeout(() => ctrl.abort(), ms) : null;
  try {
    const res = await fetch(url, { cache: 'no-store', signal: ctrl?.signal });
    if (timer) clearTimeout(timer);
    return res;
  } catch (err) {
    if (timer) clearTimeout(timer);
    throw err;
  }
}

function parseDisplays(native) {
  if (!native?.getDisplays) return [];
  try {
    const raw = native.getDisplays();
    if (Array.isArray(raw)) return raw;
    return JSON.parse(raw) || [];
  } catch {
    return [];
  }
}

/** Engine desta janela ou do parent (iframe embutido no Painel). */
function resolveEngine() {
  if (typeof window === 'undefined') return null;
  try {
    if (window.Engine) return window.Engine;
  } catch { /* ignore */ }
  try {
    if (window.parent && window.parent !== window && window.parent.Engine) {
      return window.parent.Engine;
    }
  } catch { /* cross-origin — ignore */ }
  return null;
}

function isWebView2Host() {
  try {
    return !!(window.chrome?.webview || window.somosumNative || window.somosumNativeShell);
  } catch {
    return false;
  }
}

function detectNativeShell(engine) {
  try {
    if (engine?.shell?.isNativeShell?.()) return true;
  } catch { /* ignore */ }
  try {
    if (engine?.shell?.isAvailable?.()) return true;
  } catch { /* ignore */ }
  const env = engine?.getStatus?.()?.environment || engine?.environment;
  if (env === 'webview2' || env === 'engine') return true;
  return isWebView2Host();
}

function shellBridge() {
  const engine = resolveEngine();
  const shell = engine?.shell || null;
  if (!shell) return null;
  const available = (() => {
    try { return !!shell.isAvailable?.(); } catch { return false; }
  })();
  if (!available && !detectNativeShell(engine)) return null;
  return {
    isNativeShell: () => detectNativeShell(engine),
    getDisplays: () => {
      try {
        if (typeof shell.getDisplays === 'function') {
          const list = shell.getDisplays();
          if (Array.isArray(list)) return list;
        }
      } catch { /* ignore */ }
      try {
        return shell.getDisplaysJson?.();
      } catch {
        return [];
      }
    },
    getProjectorDisplayIndex: () => {
      try { return shell.getProjectorDisplayIndex?.(); } catch { return 0; }
    },
    openScreenOnDisplay: (i) => shell.openProjection?.(i),
    openControl: () => shell.openControl?.(),
    restartServer: () => shell.restartServer?.(),
    registerHttpPorts: () => shell.registerHttpPorts?.(),
    openFolder: (p) => shell.openFolder?.(p),
  };
}

function screenFallbackDisplays() {
  if (typeof screen === 'undefined') return [];
  return [{
    index: 0,
    width: screen.width || 1920,
    height: screen.height || 1080,
    primary: true,
    friendlyName: 'Monitor principal',
  }];
}

function readSyncStats() {
  try {
    if (window.__SOMOSUM_SYNC_STATS) return window.__SOMOSUM_SYNC_STATS;
  } catch { /* ignore */ }
  try {
    if (window.parent && window.parent !== window && window.parent.__SOMOSUM_SYNC_STATS) {
      return window.parent.__SOMOSUM_SYNC_STATS;
    }
  } catch { /* ignore */ }
  return null;
}

export async function runClientChecks({ native = null, screenConnected = null } = {}) {
  const checks = [];
  const engine = resolveEngine();
  const bridge = native || shellBridge();
  const nativeOk = detectNativeShell(engine) || !!bridge?.isNativeShell?.();

  if (nativeOk) {
    checks.push(check(
      'native-shell',
      STATUS.OK,
      'Shell nativo (WebView2)',
      'SOMOSUM.exe com WebView2 integrado',
      ''
    ));
  } else {
    checks.push(check(
      'native-shell',
      STATUS.WARN,
      'Shell nativo (WebView2)',
      'Executando no navegador — monitores e janelas nativas ficam limitados',
      'Feche o navegador e abra pelo ícone SOMOSUM na bandeja',
      'openControl'
    ));
  }

  let displays = parseDisplays(bridge);
  if (!displays.length) {
    try {
      const fromShell = engine?.shell?.getDisplays?.();
      if (Array.isArray(fromShell) && fromShell.length) displays = fromShell;
    } catch { /* ignore */ }
  }
  if (!displays.length) {
    try {
      const fromDiag = engine?.getDiagnostics?.()?.monitors?.displays;
      if (Array.isArray(fromDiag) && fromDiag.length) displays = fromDiag;
    } catch { /* ignore */ }
  }
  if (!displays.length) displays = screenFallbackDisplays();

  if (displays.length) {
    const primary = displays.find((d) => d.primary);
    const projIdx = typeof bridge?.getProjectorDisplayIndex === 'function'
      ? (Number(bridge.getProjectorDisplayIndex()) || 0)
      : (displays.length > 1 ? 1 : 0);
    const proj = displays[projIdx] || displays[0];
    const fromScreenApi = !bridge && displays.length === 1;
    checks.push(check(
      'displays',
      STATUS.OK,
      `Monitores detectados (${displays.length})`,
      displays.map((d, i) =>
        `Monitor ${i + 1}: ${d.width || '?'}×${d.height || '?'}${d.primary ? ' (primário)' : ''}${i === projIdx ? ' ← projetor' : ''}`
      ).join(' · ') + (fromScreenApi ? ' · via API de tela' : ''),
      displays.length === 1
        ? 'Notebook com 1 tela: use "Projetor teste" no Painel ou bandeja'
        : ''
    ));
    if (primary && proj && primary.index === proj.index && displays.length > 1) {
      checks.push(check(
        'projector-same-as-primary',
        STATUS.WARN,
        'Projetor no monitor primário',
        'Controle e projeção podem competir pelo mesmo espaço',
        'Ajustes → Projeção → selecione o monitor externo (HDMI/VGA)',
        'openSettingsProjection'
      ));
    }
  } else {
    checks.push(check(
      'displays',
      STATUS.OK,
      'Monitores',
      'Detecção multi-monitor não disponível nesta superfície — use o Painel ou a bandeja para abrir a Projeção',
      ''
    ));
  }

  if (screenConnected === true) {
    checks.push(check('projection-live', STATUS.OK, 'Projeção conectada', 'Tela de projeção responde ao controle', ''));
  } else if (screenConnected === false) {
    checks.push(check(
      'projection-live',
      STATUS.WARN,
      'Projeção aguardando',
      'Nenhuma tela de projeção conectada no momento',
      'Clique "Abrir projeção" ou bandeja → Projeção. Aguarde até 45s na primeira abertura.',
      'openProjection'
    ));
  }

  try {
    if (localSyncAvailable()) {
      checks.push(check(
        'local-bridge',
        STATUS.OK,
        'Ponte local Controle↔Projeção',
        'PostWebMessage nativo (sem Wi‑Fi) — casal local instantâneo',
        ''
      ));
    } else if (typeof BroadcastChannel !== 'undefined') {
      checks.push(check(
        'broadcast',
        STATUS.WARN,
        'Sync local (browser)',
        'Sem shell nativo — BroadcastChannel/WS; no EXE use SOMOSUM.exe',
        'Abra pelo SOMOSUM.exe para ponte local'
      ));
    } else {
      checks.push(check(
        'broadcast',
        STATUS.WARN,
        'Canal de sync',
        'BroadcastChannel não disponível — sync via WebSocket/HTTP',
        'Use Edge/Chrome/WebView2 atualizado'
      ));
    }
  } catch {
    checks.push(check('local-bridge', STATUS.WARN, 'Canal de sync', 'Não foi possível testar ponte local', ''));
  }

  const dpr = window.devicePixelRatio || 1;
  if (dpr > 1.25) {
    checks.push(check(
      'dpi',
      dpr > 1.5 ? STATUS.WARN : STATUS.OK,
      `Escala de tela ${Math.round(dpr * 100)}%`,
      `devicePixelRatio=${dpr.toFixed(2)} — com PerMonitorV2 o texto deve ficar nítido`,
      dpr > 1.5 ? 'Se a imagem parecer borrada, reinicie o SOMOSUM.exe após atualizar' : ''
    ));
  }

  try {
    const ts = window.__SOMOSUM_TASK_SCHEDULER__;
    if (ts?.getMetrics) {
      const m = ts.getMetrics();
      checks.push(check(
        'task-scheduler',
        STATUS.OK,
        'Scheduler central',
        `${m.activeTasks} tarefa(s) registrada(s); tick ${m.tickMs}ms; modo ${m.mode || 'active'}`,
        ''
      ));
    }
  } catch { /* ignore */ }

  try {
    const hub = window.__SOMOSUM_ANALYZER_HUB__;
    if (hub?.getLastSnapshot) {
      const snap = hub.getLastSnapshot();
      checks.push(check(
        'analyzer-hub',
        STATUS.OK,
        'Analyzer Hub (enterprise)',
        snap ? `Snapshot ${new Date(snap.ts).toLocaleTimeString('pt-BR')}` : 'Aguardando primeiro snapshot (opcional)',
        ''
      ));
    }
  } catch { /* ignore */ }

  // Telemetria só existe no processo JS do Controle — ausência no Painel/Diagnóstico não é falha.
  try {
    const st = readSyncStats();
    if (st) {
      const ageSec = Math.round((Date.now() - (st.windowStartedAt || Date.now())) / 1000);
      const detail = `FULL agendado ${st.fullStateScheduled || 0} · enviado ${st.fullStateSent || 0} · coalescidos ${st.coalescedDrops || 0} · STAGE delta ${st.stageDelta || 0} / full ${st.stageFull || 0} (${ageSec}s)`;
      const heavy = (st.coalescedDrops || 0) > 40 || (st.fullStateSent || 0) > 30;
      checks.push(check(
        'sync-cascade',
        heavy ? STATUS.WARN : STATUS.OK,
        'Cascata sync (telemetria)',
        detail,
        heavy ? 'Muitos FULL_STATE — avance slides com calma; modo produção reduz carga.' : ''
      ));
    } else {
      checks.push(check(
        'sync-cascade',
        STATUS.OK,
        'Cascata sync (telemetria)',
        'Medida no Controle durante o culto — não se aplica a esta janela',
        ''
      ));
    }
  } catch { /* ignore */ }

  return checks;
}

export async function runServerDiagnostics({ includeClient = true, screenConnected = null } = {}) {
  const checks = [];
  let health = null;
  let diagnostics = null;
  const t0 = performance.now();

  try {
    const pingRes = await timedFetch('/api/ping', 8000);
    const pingOk = pingRes.ok && (await pingRes.text()).trim() === 'ok';
    const pingMs = Math.round(performance.now() - t0);
    checks.push(check(
      'server-ping',
      pingOk ? STATUS.OK : STATUS.FAIL,
      'Servidor local (ping)',
      pingOk ? `Respondeu em ${pingMs}ms na porta ${location.port || '8765'}` : 'Servidor não respondeu a /api/ping',
      pingOk ? '' : 'Verifique se SOMOSUM.exe está na bandeja. Ajustes → Reiniciar servidor. Não abra control.html direto pelo Explorer.',
      pingOk ? null : 'restartServer'
    ));
  } catch {
    checks.push(check(
      'server-ping',
      STATUS.FAIL,
      'Servidor local (ping)',
      'Timeout ou conexão recusada',
      'Abra SOMOSUM.exe e aguarde o ícone dourado. Se a porta estiver ocupada, encerre SOMOSUM na bandeja e abra de novo.',
      'restartServer'
    ));
  }

  try {
    const secRes = await timedFetch('/api/security/audit', 6000);
    if (secRes.ok) {
      const audit = await secRes.json().catch(() => null);
      const pass = audit?.pass ?? audit?.passed ?? 0;
      const fail = audit?.fail ?? audit?.failed ?? 0;
      const events = audit?.recentEvents?.length ?? audit?.events?.length ?? 0;
      checks.push(check(
        'security-audit',
        fail > 0 ? STATUS.WARN : STATUS.OK,
        'Auditoria de segurança',
        `${pass} OK · ${fail} falha(s) · ${events} evento(s) recentes`,
        fail > 0 ? 'Revise Ajustes → Rede e rotacione token Remote se necessário.' : ''
      ));
    }
  } catch { /* optional */ }

  try {
    const hRes = await timedFetch('/api/health', 8000);
    if (hRes.ok) health = await hRes.json();
  } catch { /* handled below */ }

  try {
    const dRes = await timedFetch('/api/diagnostics', 12000);
    if (dRes.ok) diagnostics = await dRes.json();
  } catch { /* optional */ }

  if (diagnostics?.checks?.length) {
    diagnostics.checks.forEach((c) => checks.push(c));
  } else if (health) {
    checks.push(check(
      'health-ready',
      health.readyForService ? STATUS.OK : STATUS.WARN,
      'Pronto para culto',
      health.readyForService ? 'Pacote offline íntegro' : 'Alguns itens do pacote precisam de atenção',
      health.readyForService ? '' : 'Veja os itens abaixo e corrija antes do culto'
    ));
    checks.push(check('pkg-konva', health.konva ? STATUS.OK : STATUS.FAIL, 'Designer (Konva)', health.konva ? 'vendor/konva.min.js OK' : 'Konva ausente ou corrompido', health.konva ? '' : 'Reinstale o pacote SOMOSUM completo (pasta vendor/)'));
    checks.push(check(
      'pkg-bibles',
      health.bibles >= 1 ? STATUS.OK : STATUS.FAIL,
      'Bíblias offline',
      `${health.bibles || 0} versão(ões) em storage/private/biblias/offline`,
      health.bibles >= 1 ? '' : 'Extraia o pacote completo — pasta storage/private/biblias/offline/'
    ));
    checks.push(check(
      'pkg-fonts',
      (health.fonts || 0) >= 1 ? STATUS.OK : STATUS.WARN,
      'Fontes',
      `${health.fonts || 0} arquivo(s) em fonts/`,
      (health.fonts || 0) >= 1 ? '' : 'Copie as fontes oficiais para fonts/ ou reinstale o pacote'
    ));
    checks.push(check(
      'pkg-exe',
      health.somosumExe ? STATUS.OK : STATUS.FAIL,
      'SOMOSUM.exe',
      health.somosumExe ? 'Trampolim na raiz e/ou app/SOMOSUM.exe OK' : 'EXE ausente na pasta do programa',
      health.somosumExe ? '' : 'Execute scripts\\compile-launcher.ps1 ou reinstale pelo Setup'
    ));
    checks.push(check(
      'pkg-data',
      health.dataWritable ? STATUS.OK : STATUS.FAIL,
      'Pasta data gravável',
      health.dataWritable ? 'Gravação de programa e config OK' : 'Sem permissão de escrita em data/',
      health.dataWritable ? '' : 'Use Preparar rede (UAC) ou instale com SOMOSUM-Setup.exe fora de pastas bloqueadas'
    ));
    checks.push(check(
      'server-errors',
      (health.errors || 0) === 0 ? STATUS.OK : ((health.errors || 0) < 5 ? STATUS.WARN : STATUS.FAIL),
      'Erros HTTP',
      `${health.errors || 0} erro(s) · ${health.requests || 0} HTTP total (inclui boot) · fila save ${health.saveQueue || 0}`,
      (health.errors || 0) > 0 ? 'Veja logs/somosum-*.log — Reiniciar servidor se a fila save não zerar' : '',
      (health.saveQueue || 0) > 3 ? 'restartServer' : null
    ));
    if (health.lanModeRequested) {
      checks.push(check(
        'lan-bind',
        health.lanBindOk ? STATUS.OK : STATUS.FAIL,
        'Rede LAN',
        health.lanBindOk ? `Ativo — IP ${health.lanIp || '?'}` : 'LAN solicitado mas bind falhou',
        health.lanBindOk ? '' : 'Use Preparar rede no menu SOMOSUM (UAC uma vez por PC)',
        health.lanBindOk ? null : 'registerPorts'
      ));
    }
  } else {
    checks.push(check(
      'health-api',
      STATUS.FAIL,
      'API /api/health',
      'Não foi possível ler o status detalhado',
      'Servidor pode estar reiniciando — aguarde 10s e clique "Analisar novamente"',
      'restartServer'
    ));
  }

  if (includeClient) {
    const clientChecks = await runClientChecks({ screenConnected });
    checks.push(...clientChecks);
  }

  const summary = countSummary(checks);
  return {
    checks,
    summary,
    health,
    diagnostics,
    version: health?.version || diagnostics?.version || window.SOMOSUM_VERSION || '—',
    ranAt: new Date().toISOString(),
  };
}

export function renderDiagnosticsHtml(result) {
  const { checks, summary, version, ranAt } = result;
  const pill = summary.fail
    ? 'Com problemas'
    : (summary.warn ? 'Atenção' : 'Sistema OK');
  const pillClass = summary.fail ? 'fail' : (summary.warn ? 'warn' : 'ok');

  const rows = checks.map((c) => {
    const icon = c.status === STATUS.OK ? '✓' : (c.status === STATUS.WARN ? '!' : '✗');
    const sol = c.solution
      ? `<p class="diag-solution"><strong>Solução:</strong> ${escapeHtml(c.solution)}</p>`
      : '';
    const act = c.action
      ? `<button type="button" class="diag-action-btn" data-diag-action="${escapeHtml(c.action)}">Corrigir</button>`
      : '';
    return `<article class="diag-row diag-row--${c.status}">
      <span class="diag-icon" aria-hidden="true">${icon}</span>
      <div class="diag-body">
        <h3>${escapeHtml(c.title)}</h3>
        <p>${escapeHtml(c.detail)}</p>
        ${sol}
        ${act}
      </div>
    </article>`;
  }).join('');

  return `
    <header class="diag-header">
      <div>
        <p class="diag-kicker">SOMOSUM v${escapeHtml(version)}</p>
        <h1>Diagnóstico do sistema</h1>
        <p class="diag-meta">${escapeHtml(new Date(ranAt).toLocaleString('pt-BR'))} · ${summary.ok} OK · ${summary.warn} avisos · ${summary.fail} falhas</p>
      </div>
      <span class="diag-pill diag-pill--${pillClass}">${pill}</span>
    </header>
    <div class="diag-list">${rows}</div>`;
}

export function escapeHtml(t) {
  const d = document.createElement('div');
  d.textContent = t ?? '';
  return d.innerHTML;
}

export async function exportDiagnosticsReport(result) {
  const lines = [
    'SOMOSUM — Relatório de diagnóstico',
    `Versão: ${result.version}`,
    `Data: ${result.ranAt}`,
    `Resumo: ${result.summary.ok} OK, ${result.summary.warn} avisos, ${result.summary.fail} falhas`,
    '',
  ];
  result.checks.forEach((c) => {
    lines.push(`[${c.status.toUpperCase()}] ${c.title}`);
    lines.push(`  ${c.detail}`);
    if (c.solution) lines.push(`  Solução: ${c.solution}`);
    lines.push('');
  });
  return lines.join('\n');
}

export function handleDiagnosticAction(action, ctx = {}) {
  const shell = window.Engine?.shell;
  const shellOk = shell?.isAvailable?.();
  switch (action) {
    case 'restartServer':
      if (shellOk && shell.restartServer) {
        shell.restartServer();
        return true;
      }
      import('./server-restart.js').then(({ requestSoftRestart }) => requestSoftRestart());
      return true;
    case 'registerPorts':
      if (shellOk && shell.registerHttpPorts) {
        shell.registerHttpPorts();
        return true;
      }
      return false;
    case 'openControl':
      if (shellOk && shell.openControl) {
        shell.openControl();
        return true;
      }
      return false;
    case 'openProjection':
      if (shellOk && shell.openProjection) {
        shell.openProjection(-1);
        return true;
      }
      return false;
    case 'openSettingsProjection':
      if (ctx.app?.setView) {
        ctx.app.setView('settings');
        return true;
      }
      if (shellOk && shell.openControl) {
        shell.openControl();
        try { localStorage.setItem('somosum.control.openSettings', 'projection'); } catch { /* ignore */ }
        return true;
      }
      return false;
    case 'openFolderLogs':
    case 'folder-logs':
      if (shellOk && shell.openFolder) {
        shell.openFolder('logs');
        return true;
      }
      return false;
    case 'openFolderData':
      if (shellOk && shell.openFolder) {
        shell.openFolder('data');
        return true;
      }
      return false;
    default:
      return false;
  }
}
