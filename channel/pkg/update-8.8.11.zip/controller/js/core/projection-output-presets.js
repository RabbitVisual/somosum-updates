/**
 * Presets de saída (inspirado Holyrics public/screen_2/stage/stream).
 * Mapeia papéis SOMOSUM → geometria + margem de crop + filtros de conteúdo.
 */
export const OUTPUT_PRESETS = {
  public: {
    id: 'public',
    role: 'projection',
    label: 'Projeção principal',
    contentFilter: ['lyrics', 'bible', 'welcome', 'media', 'blank'],
    margin: { top: 0, right: 0, bottom: 0, left: 0 },
    fullscreen: true,
  },
  projection2: {
    id: 'projection2',
    role: 'projection2',
    label: 'Projeção 2',
    contentFilter: ['lyrics', 'bible', 'welcome', 'media', 'blank'],
    margin: { top: 0, right: 0, bottom: 0, left: 0 },
    fullscreen: true,
  },
  stage: {
    id: 'stage',
    role: 'stage',
    label: 'Stage / operador',
    contentFilter: ['lyrics', 'bible', 'chords', 'next'],
    margin: { top: 2, right: 2, bottom: 2, left: 2 },
    fullscreen: false,
    stageView: {
      showNextLine: true,
      showComments: true,
      uppercase: false,
    },
  },
  stream_html: {
    id: 'stream_html',
    role: 'browser',
    label: 'Saída HTML (browser)',
    contentFilter: ['lyrics', 'bible', 'welcome'],
    margin: { top: 0, right: 0, bottom: 0, left: 0 },
    pollMs: 250,
  },
};

export function resolveOutputPreset(surface = 'screen', outputIndex = 1) {
  if (surface === 'stage') return OUTPUT_PRESETS.stage;
  if (Number(outputIndex) > 1) return OUTPUT_PRESETS.projection2;
  if (surface === 'browser') return OUTPUT_PRESETS.stream_html;
  return OUTPUT_PRESETS.public;
}

export function applyOutputPresetVars(target, preset) {
  if (!target || !preset) return;
  target.dataset.outputPreset = preset.id;
  target.dataset.outputRole = preset.role;
  const m = preset.margin || {};
  target.style.setProperty('--output-margin-top', `${m.top || 0}%`);
  target.style.setProperty('--output-margin-right', `${m.right || 0}%`);
  target.style.setProperty('--output-margin-bottom', `${m.bottom || 0}%`);
  target.style.setProperty('--output-margin-left', `${m.left || 0}%`);
}
