import { installErrorBoundary, onError } from './error-boundary.js';
import { LogService, LogCategory, LogLevel } from './logging/log-service.js';
import { installDevToolsOverlay, isDevConsoleAllowed } from './dev-tools-overlay.js';
import { isProductionMode } from './production-mode.js';

/** Operador (Controle/Remote) — nunca Projeção/Púlpito ao vivo. */
const DEV_OVERLAY_SURFACES = new Set(['control', 'remote', 'diagnostics', 'panel']);

let bootstrapped = false;

export function bootstrapLogging({ module = 'boot', devOverlay = null } = {}) {
  if (bootstrapped) return;
  bootstrapped = true;
  installErrorBoundary({ module });

  const mountOverlay = () => {
    if (isProductionMode() || !isDevConsoleAllowed()) return;
    const allow = devOverlay ?? DEV_OVERLAY_SURFACES.has(module);
    if (!allow) return;
    try { installDevToolsOverlay({ module }); } catch { /* ignore */ }
  };

  if (typeof document !== 'undefined' && document.body) mountOverlay();
  else if (typeof document !== 'undefined') {
    document.addEventListener('DOMContentLoaded', mountOverlay, { once: true });
  }

  // Padrão: ring buffer guarda INFO; console só WARN+ (exceto verbose/produção).
  if (!isProductionMode()) {
    LogService.setConsoleMirror(true, { minLevel: LogLevel.WARN });
  }

  LogService.debug('Bootstrap logging pronto', {
    module,
    category: LogCategory.BOOT,
    detail: {
      surface: module,
      productionMode: isProductionMode(),
      minLevel: LogLevel.INFO,
    },
  });

  return { onError, LogService, LogCategory };
}
