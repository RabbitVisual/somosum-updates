/**
 * Sino na transição do pré-culto — arquivo em audio/ ou tom sintético (offline).
 * Toca na aba Controle (gesto do usuário), não na Projeção.
 */
import { encodeAudioPath } from './ambient-audio.js';

let _audioCtx = null;
let _audioUnlocked = false;
let _knownPaths = new Set();
const _preloaded = new Map();

export const DEFAULT_BELL_PATHS = ['audio/sino.mp3'];

export function setKnownAudioPaths(paths = []) {
  _knownPaths = new Set((paths || []).filter(Boolean));
}

export function unlockBellAudio() {
  _audioUnlocked = true;
  if (_audioCtx?.state === 'suspended') {
    _audioCtx.resume().catch(() => {});
  }
}

function getAudioContext() {
  if (!_audioUnlocked) return null;
  if (!_audioCtx) {
    _audioCtx = new (window.AudioContext || window.webkitAudioContext)();
  }
  if (_audioCtx.state === 'suspended') {
    _audioCtx.resume().catch(() => {});
  }
  return _audioCtx;
}

export function preloadBellSound(path) {
  if (!path || !_knownPaths.has(path)) return null;
  if (_preloaded.has(path)) return _preloaded.get(path);
  const audio = new Audio(encodeAudioPath(path));
  audio.preload = 'auto';
  audio.load();
  _preloaded.set(path, audio);
  return audio;
}

export function playSyntheticBell(volume = 0.65) {
  const ctx = getAudioContext();
  if (!ctx) return false;

  try {
    const now = ctx.currentTime;
    const master = ctx.createGain();
    master.gain.setValueAtTime(0, now);
    master.gain.linearRampToValueAtTime(volume, now + 0.02);
    master.gain.exponentialRampToValueAtTime(0.001, now + 3.2);
    master.connect(ctx.destination);

    const partials = [
      { freq: 523.25, gain: 1 },
      { freq: 784.88, gain: 0.55 },
      { freq: 1046.5, gain: 0.35 },
      { freq: 1318.5, gain: 0.2 },
    ];

    partials.forEach(({ freq, gain }, i) => {
      const osc = ctx.createOscillator();
      const g = ctx.createGain();
      osc.type = i === 0 ? 'sine' : 'triangle';
      osc.frequency.setValueAtTime(freq, now);
      osc.frequency.exponentialRampToValueAtTime(freq * 0.992, now + 2.5);
      g.gain.setValueAtTime(gain, now);
      g.gain.exponentialRampToValueAtTime(0.001, now + 2.8 + i * 0.08);
      osc.connect(g);
      g.connect(master);
      osc.start(now);
      osc.stop(now + 3.5);
    });

    setTimeout(() => {
      try {
        const t = ctx.currentTime;
        const osc2 = ctx.createOscillator();
        const g2 = ctx.createGain();
        osc2.type = 'sine';
        osc2.frequency.setValueAtTime(659.25, t);
        g2.gain.setValueAtTime(0, t);
        g2.gain.linearRampToValueAtTime(volume * 0.35, t + 0.03);
        g2.gain.exponentialRampToValueAtTime(0.001, t + 2);
        osc2.connect(g2);
        g2.connect(ctx.destination);
        osc2.start(t);
        osc2.stop(t + 2.2);
      } catch {
        /* ignore */
      }
    }, 520);

    return true;
  } catch {
    return false;
  }
}

function playAudioFile(src, volume = 0.7) {
  return new Promise((resolve) => {
    const audio = new Audio(encodeAudioPath(src));
    audio.volume = Math.min(1, Math.max(0, volume));
    audio.preload = 'auto';

    const fail = () => resolve(false);
    const succeed = () => resolve(true);

    audio.addEventListener('error', fail, { once: true });
    audio.addEventListener('canplaythrough', () => {
      audio.play().then(succeed).catch(fail);
    }, { once: true });
    audio.load();

    setTimeout(() => {
      if (audio.readyState >= 2) {
        audio.play().then(succeed).catch(fail);
      }
    }, 400);
  });
}

export async function playBellSound(options = {}) {
  const { bellPath = null, volume = 0.7, tryDefaults = true } = options;
  unlockBellAudio();

  const tryPath = async (path) => {
    if (!path || !_knownPaths.has(path)) return false;
    return playAudioFile(path, volume);
  };

  if (bellPath) {
    const ok = await tryPath(bellPath);
    if (ok) return true;
  }

  if (tryDefaults) {
    for (const path of DEFAULT_BELL_PATHS) {
      const ok = await tryPath(path);
      if (ok) return true;
    }
  }

  return playSyntheticBell(volume);
}
