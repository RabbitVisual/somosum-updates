/**
 * Timers centralizados — use em vez de setTimeout/setInterval raw (gate Strict).
 */
import { TaskScheduler } from './task-scheduler.js';

let deferSeq = 0;

export function defer(fn, ms = 0, priority = 5) {
  if (typeof fn !== 'function') return () => {};
  if (ms <= 0) {
    try { fn(); } catch { /* task */ }
    return () => {};
  }
  deferSeq += 1;
  const id = `defer-${deferSeq}`;
  return TaskScheduler.scheduleDelayed(id, ms, fn, priority);
}

export function sleep(ms) {
  return new Promise((resolve) => {
    defer(resolve, ms);
  });
}

export function scheduleRaf(fn) {
  return TaskScheduler.scheduleFrame(fn);
}
