const PREFIX = 'somosum-culto-cache:';
const INDEX_KEY = 'somosum-culto-index-cache';

export function cacheCulto(id, payload) {
  if (!id || !payload) return;
  try {
    localStorage.setItem(`${PREFIX}${id}`, JSON.stringify(payload));
  } catch { /* quota */ }
}

export function getCachedCulto(id) {
  if (!id) return null;
  try {
    const raw = localStorage.getItem(`${PREFIX}${id}`);
    if (!raw) return null;
    const data = JSON.parse(raw);
    if (Array.isArray(data)) return { id, items: data };
    if (data?.items) return { id, ...data };
    return null;
  } catch {
    return null;
  }
}

export function cacheCultoIndex(index) {
  try {
    localStorage.setItem(INDEX_KEY, JSON.stringify(index));
  } catch { /* quota */ }
}

export function getCachedCultoIndex() {
  try {
    const raw = localStorage.getItem(INDEX_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}
