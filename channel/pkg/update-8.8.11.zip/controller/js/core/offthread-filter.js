/**
 * Busca/filtro off-main-thread para listas (worship, media).
 */
import { runWorkerTask, isWorkerSupported } from './worker-pool.js';

export async function filterItemsOffThread(items, query, fields = ['title', 'name', 'author']) {
  const list = Array.isArray(items) ? items : [];
  const q = String(query || '').trim();
  if (!q) return list;
  if (!isWorkerSupported() || list.length < 40) {
    const nq = q.toLowerCase();
    return list.filter((it) => fields.some((f) => String(it?.[f] || '').toLowerCase().includes(nq)));
  }
  try {
    const url = new URL('../workers/idb-query-worker.js', import.meta.url);
    const result = await runWorkerTask(url, {
      op: 'filter',
      items: list,
      query: q,
      fields,
    }, {
      fallback: () => {
        const nq = q.toLowerCase();
        return { items: list.filter((it) => fields.some((f) => String(it?.[f] || '').toLowerCase().includes(nq))) };
      },
    });
    return result?.items || list;
  } catch {
    const nq = q.toLowerCase();
    return list.filter((it) => fields.some((f) => String(it?.[f] || '').toLowerCase().includes(nq)));
  }
}
