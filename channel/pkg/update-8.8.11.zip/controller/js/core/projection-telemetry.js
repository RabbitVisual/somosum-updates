/** Logs estruturados de projeção — sem segredos/tokens. */

const DEBUG = (() => {
  try {
    return localStorage.getItem('SOMOSUM_PROJECTION_LOG') === '1'
      || new URLSearchParams(location.search).get('projLog') === '1';
  } catch {
    return false;
  }
})();

export function logProjection(tag, detail = {}) {
  if (!DEBUG && tag !== 'VIEWPORT_MISMATCH' && tag !== 'DISPLAY_LOST') return;
  const payload = { tag, ts: Date.now(), ...detail };
  console.info(`[SOMOSUM:${tag}]`, payload);
  try {
    window.dispatchEvent(new CustomEvent('somosum-projection-log', { detail: payload }));
  } catch { /* ignore */ }
}

export function logHotplug(phase, detail = {}) {
  logProjection('HOTPLUG', { phase, ...detail });
}

export function logViewportMismatch(flags, detail = {}) {
  logProjection('VIEWPORT_MISMATCH', { flags, ...detail });
}

export function logColorPolicy(policyId, display = null) {
  logProjection('COLOR_POLICY', {
    policyId,
    colorProfile: display?.colorProfile || null,
    hdrCapable: display?.hdrCapable ?? null,
  });
}

export function logVideoLayout(mode, detail = {}) {
  logProjection('VIDEO_LAYOUT', { mode, ...detail });
}
