/** Registro central de teardown — executado no pagehide. */
const disposables = new Set();

export function registerDisposable(fn) {
  if (typeof fn !== 'function') return () => {};
  disposables.add(fn);
  return () => disposables.delete(fn);
}

export function runAllDisposables() {
  for (const fn of [...disposables]) {
    try { fn(); } catch { /* ignore */ }
  }
  disposables.clear();
}

if (typeof window !== 'undefined') {
  window.addEventListener('pagehide', () => runAllDisposables(), { capture: true });
}
