/** Monta body JSON do push-batch (unit-testable, sem fetch). */
export function buildPushBatchBody(messages) {
  return JSON.stringify({ messages: messages || [] });
}
