/** Resolve URL de mídia em disco (evita duplicar dataUrl em flatSlides). */
import { dataPublicUrl } from './data-public-url.js';

/** IDs/paths legados do pack antigo → arquivos reais em system/media/. */
const SYSTEM_MEDIA_ALIASES = {
  // Loops coloridos → vídeos do pack
  'sys-loop-azul': 'system/media/animados/SOMOSUM_01.mp4',
  'sys-loop-dourado': 'system/media/animados/SOMOSUM_02.mp4',
  'sys-loop-noite': 'system/media/animados/SOMOSUM_03.mp4',
  'sys-loop-vinho': 'system/media/animados/SOMOSUM_04.mp4',
  // Stills coloridos → estáticos reais
  'sys-bg-azul': 'system/media/estaticos/SOMOS_01_ESTATICO.webp',
  'sys-bg-dourado': 'system/media/estaticos/SOMOS_02_ESTATICO.webp',
  'sys-bg-escuro': 'system/media/estaticos/SOMOS_03_ESTATICO.webp',
  'sys-bg-neutro': 'system/media/estaticos/SOMOS_04_ESTATICO.webp',
};

const STATIC_COUNT = 8;

function pad2(n) {
  return String(n).padStart(2, '0');
}

/** SOMOSUM_S01…S18 (pack stills antigo) → SOMOS_01…08_ESTATICO (cicla). */
function resolveLegacyStillId(id) {
  const m = /^SOMOSUM_S(\d{1,2})$/i.exec(id);
  if (!m) return null;
  const n = Number(m[1]);
  if (!Number.isFinite(n) || n < 1) return null;
  const idx = ((n - 1) % STATIC_COUNT) + 1;
  return `system/media/estaticos/SOMOS_${pad2(idx)}_ESTATICO.webp`;
}

/** Extrai id canônico de path/src legado. */
function canonicalizeSystemMediaId(idOrSrc = '') {
  let raw = String(idOrSrc || '').trim();
  if (!raw) return '';
  raw = raw.replace(/\\/g, '/');
  // basename se for URL/path
  const slash = raw.lastIndexOf('/');
  if (slash >= 0) raw = raw.slice(slash + 1);
  raw = raw.replace(/\.(mp4|webm|webp|png|jpe?g|gif)$/i, '');
  return raw;
}

/**
 * Resolve alias de mídia do sistema (loops + stills legados).
 * Aceita id, filename ou path (`/system/media/stills/SOMOSUM_S01.webp`).
 */
export function resolveSystemLoopAlias(idOrSrc = '') {
  const raw = String(idOrSrc || '').trim().replace(/\\/g, '/');
  if (!raw) return null;

  const id = canonicalizeSystemMediaId(raw);
  const fromMap = SYSTEM_MEDIA_ALIASES[id]
    || SYSTEM_MEDIA_ALIASES[raw]
    || SYSTEM_MEDIA_ALIASES[raw.replace(/^\/+/, '')];
  if (fromMap) return `/${fromMap}`;

  const still = resolveLegacyStillId(id);
  if (still) return `/${still}`;

  // Path legado stills/SOMOSUM_Sxx.webp
  const stillPath = /(?:^|\/)(?:stills\/)?(SOMOSUM_S\d{1,2})(?:\.webp)?$/i.exec(raw);
  if (stillPath) {
    const mapped = resolveLegacyStillId(stillPath[1]);
    if (mapped) return `/${mapped}`;
  }

  // Path legado sys-bg-*.webp na raiz de system/media
  const bgPath = /(?:^|\/)(sys-bg-\w+)(?:\.webp)?$/i.exec(raw);
  if (bgPath && SYSTEM_MEDIA_ALIASES[bgPath[1]]) {
    return `/${SYSTEM_MEDIA_ALIASES[bgPath[1]]}`;
  }

  return null;
}

/** IDs de pack antigo que não existem mais no disco — devem sair do IDB. */
export function isObsoleteSystemMediaId(id = '') {
  const key = canonicalizeSystemMediaId(id);
  if (!key) return false;
  if (SYSTEM_MEDIA_ALIASES[key]) return true;
  if (/^SOMOSUM_S\d{1,2}$/i.test(key)) return true;
  return false;
}

export function mediaDiskUrl(media) {
  if (!media?.id) return null;
  const alias = resolveSystemLoopAlias(media.id) || resolveSystemLoopAlias(media.path) || resolveSystemLoopAlias(media.src);
  if (alias) return alias;
  if (media.system || media.src?.startsWith('/system/')) {
    const p = media.path || '';
    if (p.startsWith('system/')) return `/${p.replace(/\\/g, '/')}`;
    if (p) return `/system/media/${media.id}.${extFromMime(media.mimeType || media.mime || '', media.kind)}`;
  }
  const mime = media.mimeType || media.mime || '';
  const ext = extFromMime(mime, media.kind);
  return dataPublicUrl(`media/${media.id}.${ext}`);
}

function extFromMime(mime = '', kind = '') {
  if (mime.includes('jpeg') || mime.includes('jpg')) return 'jpg';
  if (mime.includes('webp')) return 'webp';
  if (mime.includes('gif')) return 'gif';
  if (mime.includes('png')) return 'png';
  if (mime.includes('video') || kind === 'video') {
    return mime.includes('webm') ? 'webm' : 'mp4';
  }
  if (kind === 'video') return 'mp4';
  return 'webp';
}

export function normalizeMediaIndex(raw) {
  if (!raw || typeof raw !== 'object') return {};
  if (Array.isArray(raw.media)) {
    const map = {};
    for (const entry of raw.media) {
      if (!entry?.id) continue;
      map[entry.id] = {
        ...entry,
        mimeType: entry.mimeType || entry.mime || '',
        kind: entry.kind || (String(entry.mimeType || entry.mime || '').includes('video') ? 'video' : 'image'),
        category: entry.category || entry.kind || 'image',
        system: !!entry.system,
        readonly: !!(entry.readonly || entry.system),
      };
    }
    return map;
  }
  const map = {};
  for (const [key, entry] of Object.entries(raw)) {
    if (key === 'version' || key === 'updatedAt') continue;
    if (!entry || typeof entry !== 'object' || !entry.id) continue;
    const { dataUrl, ...lean } = entry;
    map[entry.id] = {
      ...lean,
      mimeType: lean.mimeType || lean.mime || '',
      system: !!lean.system,
      readonly: !!(lean.readonly || lean.system),
    };
  }
  return map;
}

export function diskRelativePath(meta) {
  if (meta?.system) {
    if (meta.path) return String(meta.path).replace(/\\/g, '/');
    return `system/media/${meta.id}.${extFromMime(meta.mimeType || '', meta.kind)}`;
  }
  if (meta?.path) return String(meta.path).replace(/^data\//, '');
  const url = mediaDiskUrl(meta);
  if (!url) return null;
  return url.replace(/^\/?data\//, '');
}

export function resolveMediaSrc(media) {
  if (!media) return '';
  const aliasFromId = resolveSystemLoopAlias(media.id);
  if (aliasFromId) return aliasFromId;
  if (media.src) {
    const aliasFromSrc = resolveSystemLoopAlias(media.src) || resolveSystemLoopAlias(media.src.split('/').pop());
    if (aliasFromSrc) return aliasFromSrc;
    return media.src;
  }
  if (media.system) {
    const p = media.path ? String(media.path).replace(/\\/g, '/') : '';
    if (p.startsWith('system/')) return `/${p}`;
    if (p.startsWith('/system/')) return p;
    return mediaDiskUrl(media) || '';
  }
  const rel = diskRelativePath(media);
  if (rel) {
    if (rel.startsWith('system/')) return `/${rel}`;
    return dataPublicUrl(rel.replace(/\\/g, '/'));
  }
  return mediaDiskUrl(media) || media.dataUrl || '';
}

export function leanMediaIndexEntries(map) {
  return Object.values(map || {}).map((m) => {
    const { dataUrl, ...lean } = m;
    return {
      id: lean.id,
      name: lean.name || 'Mídia',
      kind: lean.kind || 'image',
      category: lean.category || lean.kind || 'image',
      mimeType: lean.mimeType || lean.mime || '',
      path: lean.path || diskRelativePath(lean),
      tags: lean.tags || [],
      updatedAt: lean.updatedAt || Date.now(),
      sizeBytes: lean.sizeBytes || null,
      favorite: !!lean.favorite,
      system: !!lean.system,
      readonly: !!(lean.readonly || lean.system),
    };
  });
}

export function buildMediaIndexPayload(map) {
  return {
    version: 2,
    updatedAt: new Date().toISOString(),
    media: leanMediaIndexEntries(map),
  };
}

/** Remove entradas de mídia cujo arquivo não existe (evita 404 no boot e miniaturas vazias). */
export async function pruneMissingMediaFromIndex(indexMap) {
  if (!indexMap || typeof indexMap !== 'object') return [];
  const removed = [];
  for (const [id, meta] of Object.entries(indexMap)) {
    if (!meta) continue;
    const url = resolveMediaSrc({ ...meta, id });
    if (!url || url.startsWith('blob:')) continue;
    try {
      const res = await fetch(url, { method: 'HEAD', cache: 'no-store' });
      if (!res.ok) {
        delete indexMap[id];
        removed.push(id);
      }
    } catch { /* offline — mantém */ }
  }
  return removed;
}

/** Opções HTML para selects de fundo (sistema primeiro: animados / estáticos). */
export function mediaBackgroundOptionsHtml(mediaList, selectedId) {
  const list = Array.isArray(mediaList) ? mediaList : [];
  const anim = list.filter((m) => m.system && (m.category === 'fundo-animado' || m.category === 'loop' || (m.kind === 'video' && m.system)));
  const still = list.filter((m) => m.system && (m.category === 'fundo-estatico' || m.category === 'background' || (m.kind === 'image' && m.system)));
  const user = list.filter((m) => !m.system);
  const opt = (m) => {
    const kind = m.kind === 'video' ? 'animado' : 'estático';
    const label = m.system ? `${m.name}` : `${m.name} (${kind})`;
    const sel = selectedId === m.id ? 'selected' : '';
    return `<option value="${escAttr(m.id)}" ${sel}>${esc(label)}</option>`;
  };
  let html = `<option value="">Gradiente / tema</option>`;
  if (anim.length) {
    html += `<optgroup label="Fundos animados (sistema)">${anim.map(opt).join('')}</optgroup>`;
  }
  if (still.length) {
    html += `<optgroup label="Fundos estáticos (sistema)">${still.map(opt).join('')}</optgroup>`;
  }
  if (user.length) {
    html += `<optgroup label="Minha biblioteca">${user.map(opt).join('')}</optgroup>`;
  }
  return html;
}

/**
 * Grade selecionável de fundos para Boas-Vindas (sem digitar URL).
 * @returns {{ html: string, selectedId: string, selectedKind: string }}
 */
export function welcomeBackgroundPickerHtml(mediaList, {
  selectedId = '',
  selectedSrc = '',
  churchBg = '',
  churchBgLabel = 'Foto da igreja',
  idField = 'insp-w-bg-media-id',
  kindField = 'insp-w-bg-kind',
  includeChurch = true,
} = {}) {
  const list = Array.isArray(mediaList) ? mediaList : [];
  const anim = list.filter((m) =>
    m.kind === 'video' || m.category === 'fundo-animado' || m.category === 'loop');
  const still = list.filter((m) =>
    m.kind !== 'video'
    && (m.category === 'fundo-estatico' || m.category === 'background' || m.kind === 'image' || !m.kind));
  const seen = new Set();
  const tiles = [];
  const pushUnique = (m) => {
    if (!m?.id || seen.has(m.id)) return;
    seen.add(m.id);
    tiles.push(m);
  };
  anim.forEach(pushUnique);
  still.forEach(pushUnique);

  let resolvedId = selectedId || '';
  if (!resolvedId && selectedSrc) {
    const hit = tiles.find((m) => {
      const src = resolveMediaSrc(m);
      return src && (selectedSrc === src || selectedSrc.endsWith(src) || src.endsWith(selectedSrc.replace(/^\//, '')));
    });
    if (hit) resolvedId = hit.id;
  }

  const selectedMedia = tiles.find((m) => m.id === resolvedId);
  const selectedKind = selectedMedia?.kind === 'video' ? 'video' : 'image';
  const selectedLabel = resolvedId
    ? (selectedMedia?.name || 'Mídia')
    : (includeChurch ? churchBgLabel : 'Gradiente / tema');

  const tileBtn = (opts) => {
    const selected = !!opts.selected;
    const kind = opts.kind === 'video' ? 'video' : 'image';
    const visual = opts.src && kind === 'image'
      ? `style="background-image:url('${escAttr(opts.src)}')"`
      : '';
    const videoClass = kind === 'video' ? ' is-video' : '';
    const srcAttr = opts.src ? ` data-bg-src="${escAttr(opts.src)}"` : '';
    return `<button type="button" class="welcome-bg-tile${videoClass}${selected ? ' is-selected' : ''}"
      role="option" aria-selected="${selected ? 'true' : 'false'}"
      data-bg-id="${escAttr(opts.id || '')}" data-bg-kind="${kind}"
      data-bg-label="${escAttr(opts.label)}"${srcAttr}
      title="${escAttr(opts.label)}">
      <span class="welcome-bg-tile-visual" ${visual} aria-hidden="true"></span>
      <span class="welcome-bg-tile-label">${esc(opts.label)}</span>
      ${kind === 'video' ? '<span class="welcome-bg-tile-badge">Vídeo</span>' : ''}
    </button>`;
  };

  const section = (title, body) => (body
    ? `<div class="welcome-bg-section"><p class="welcome-bg-section-title">${esc(title)}</p><div class="welcome-bg-section-grid">${body}</div></div>`
    : '');

  const churchSelected = !resolvedId;
  const churchKind = /\.(mp4|webm|mov)(\?|$)/i.test(String(churchBg || '')) ? 'video' : 'image';
  const churchTiles = includeChurch && churchBg
    ? tileBtn({
      id: '',
      label: churchBgLabel,
      src: churchBg || '',
      kind: churchKind,
      selected: churchSelected,
    })
    : '';

  const animTiles = tiles.filter((m) => m.kind === 'video');
  const stillTiles = tiles.filter((m) => m.kind !== 'video');
  const videoGrid = animTiles.map((m) => tileBtn({
    id: m.id,
    label: m.name || 'Mídia',
    src: resolveMediaSrc(m),
    kind: 'video',
    selected: m.id === resolvedId,
  })).join('');
  const imageGrid = stillTiles.map((m) => tileBtn({
    id: m.id,
    label: m.name || 'Mídia',
    src: resolveMediaSrc(m),
    kind: 'image',
    selected: m.id === resolvedId,
  })).join('');

  const html = `
    <div class="welcome-bg-picker" data-welcome-bg-picker data-church-bg-label="${escAttr(churchBgLabel)}">
      <input type="hidden" id="${escAttr(idField)}" value="${escAttr(resolvedId)}" />
      <input type="hidden" id="${escAttr(kindField)}" value="${escAttr(selectedKind)}" />
      <div class="welcome-bg-grid" role="listbox" aria-label="Fundo das boas-vindas">
        ${section('Vídeos', videoGrid)}
        ${section('Imagens', imageGrid)}
        ${section(churchBgLabel, churchTiles)}
      </div>
      <p class="welcome-bg-picker-selected-label" data-welcome-bg-label>Fundo atual: <strong>${esc(selectedLabel)}</strong></p>
      <p class="form-hint">Toque em um fundo da biblioteca. Rolagem interna — vídeos e imagens abaixo.</p>
    </div>`;

  return { html, selectedId: resolvedId, selectedKind };
}

/** Grade de fundo para slides do programa (sem foto da igreja). */
export function slideBackgroundPickerHtml(mediaList, options = {}) {
  return welcomeBackgroundPickerHtml(mediaList, {
    includeChurch: false,
    churchBg: '',
    idField: 'insp-slide-bg-media-id',
    kindField: 'insp-slide-bg-kind',
    ...options,
  });
}

export const bindSlideBackgroundPicker = bindWelcomeBackgroundPicker;
export const syncSlideBackgroundPickerUI = syncWelcomeBackgroundPickerUI;

/** Reaplica estado visual dos tiles sem re-montar o HTML. */
export function syncWelcomeBackgroundPickerUI(pickerOrRoot, { id = '', kind = 'image', label = '' } = {}) {
  const picker = pickerOrRoot?.matches?.('[data-welcome-bg-picker]')
    ? pickerOrRoot
    : pickerOrRoot?.querySelector?.('[data-welcome-bg-picker]');
  if (!picker) return;
  const idInput = picker.querySelector('input[id$="-bg-media-id"], #insp-w-bg-media-id, #wiz-w-bg-media-id');
  const kindInput = picker.querySelector('input[id$="-bg-kind"], #insp-w-bg-kind, #wiz-w-bg-kind');
  const resolvedKind = kind === 'video' ? 'video' : 'image';
  if (idInput) idInput.value = id || '';
  if (kindInput) kindInput.value = resolvedKind;
  let selectedLabel = label;
  let selectedBtn = null;
  picker.querySelectorAll('.welcome-bg-tile').forEach((b) => {
    const on = (b.getAttribute('data-bg-id') || '') === (id || '');
    b.classList.toggle('is-selected', on);
    b.setAttribute('aria-selected', on ? 'true' : 'false');
    if (on) {
      selectedBtn = b;
      if (!selectedLabel) selectedLabel = b.getAttribute('data-bg-label') || b.title || 'Fundo';
    }
  });
  const labelEl = picker.querySelector('[data-welcome-bg-label]');
  const churchLabel = picker.getAttribute('data-church-bg-label') || 'Foto da igreja';
  if (labelEl) {
    labelEl.innerHTML = `Fundo atual: <strong>${esc(selectedLabel || (id ? 'Mídia' : churchLabel))}</strong>`;
  }
  selectedBtn?.scrollIntoView?.({ block: 'nearest', behavior: 'smooth' });
}

/** Liga cliques da grade de fundo (inspetor / wizard) — delegação no container. */
export function bindWelcomeBackgroundPicker(root, { onChange } = {}) {
  const picker = root?.querySelector?.('[data-welcome-bg-picker]');
  if (!picker || picker.dataset.bound === '1') return;
  picker.dataset.bound = '1';
  const idInput = picker.querySelector('input[id$="-bg-media-id"], #insp-w-bg-media-id, #wiz-w-bg-media-id');
  const kindInput = picker.querySelector('input[id$="-bg-kind"], #insp-w-bg-kind, #wiz-w-bg-kind');

  const stopPreview = (btn) => {
    const visual = btn?.querySelector?.('.welcome-bg-tile-visual');
    const vid = visual?.querySelector?.('video');
    if (vid) {
      vid.pause();
      vid.remove();
    }
    btn?._previewTimer && clearTimeout(btn._previewTimer);
    btn._previewTimer = null;
  };

  const startPreview = (btn) => {
    if (!btn?.classList?.contains('is-video')) return;
    const src = btn.getAttribute('data-bg-src');
    if (!src) return;
    stopPreview(btn);
    btn._previewTimer = setTimeout(() => {
      const visual = btn.querySelector('.welcome-bg-tile-visual');
      if (!visual || !picker.contains(btn)) return;
      if (visual.querySelector('video')) return;
      const vid = document.createElement('video');
      vid.src = src;
      vid.muted = true;
      vid.loop = true;
      vid.playsInline = true;
      vid.autoplay = true;
      vid.className = 'welcome-bg-tile-preview-video';
      visual.appendChild(vid);
      vid.play().catch(() => {});
    }, 850);
  };

  picker.querySelectorAll('.welcome-bg-tile.is-video').forEach((btn) => {
    btn.addEventListener('mouseenter', () => startPreview(btn));
    btn.addEventListener('mouseleave', () => stopPreview(btn));
    btn.addEventListener('focus', () => startPreview(btn));
    btn.addEventListener('blur', () => stopPreview(btn));
  });

  picker.addEventListener('click', (ev) => {
    const btn = ev.target?.closest?.('.welcome-bg-tile');
    if (!btn || !picker.contains(btn)) return;
    ev.preventDefault();
    picker.querySelectorAll('.welcome-bg-tile.is-video').forEach((b) => {
      if (b !== btn) stopPreview(b);
    });
    const id = btn.getAttribute('data-bg-id') || '';
    const kind = btn.getAttribute('data-bg-kind') === 'video' ? 'video' : 'image';
    const label = btn.getAttribute('data-bg-label') || btn.title || '';
    if (idInput) {
      idInput.value = id;
      idInput.dispatchEvent(new Event('change', { bubbles: true }));
    }
    if (kindInput) {
      kindInput.value = kind;
      kindInput.dispatchEvent(new Event('change', { bubbles: true }));
    }
    syncWelcomeBackgroundPickerUI(picker, { id, kind, label });
    onChange?.({ id, kind, label });
  });
}

function esc(t) {
  const d = document.createElement('div');
  d.textContent = t ?? '';
  return d.innerHTML;
}
function escAttr(t) {
  return esc(t).replace(/"/g, '&quot;');
}
