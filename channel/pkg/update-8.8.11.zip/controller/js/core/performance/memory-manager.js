/**
 * MemoryManager — fachada de limpeza progressiva com live-guard.
 */
import { AutoCleanup } from '../memory/auto-cleanup.js';
import { IdleSoftCleanup } from '../memory/idle-soft-cleanup.js';

function isLiveBlocked() {
  return !!(typeof window !== 'undefined'
    && (window.__SOMOSUM_LIVE_ACTIVE || window.__SOMOSUM_COUNTDOWN_LIVE));
}

let softRuns = 0;
let hardRuns = 0;
let lastSoftAt = 0;
let lastHardAt = 0;

export const MemoryManager = {
  start() {
    AutoCleanup.start();
  },

  stop() {
    AutoCleanup.stop();
  },

  noteSlideActivity() {
    IdleSoftCleanup.noteSlideActivity();
  },

  async softCleanup() {
    lastSoftAt = Date.now();
    softRuns += 1;
    await AutoCleanup.runLightCleanup();
    try {
      const { ResourceManager } = await import('./resource-manager.js');
      ResourceManager.revokeStaleObjectUrls?.();
    } catch { /* ignore */ }
    window.dispatchEvent(new CustomEvent('somosum-memory-soft-cleanup', {
      detail: { live: isLiveBlocked(), at: lastSoftAt },
    }));
    return { ok: true, live: isLiveBlocked() };
  },

  async hardCleanup() {
    if (isLiveBlocked()) {
      return { ok: false, reason: 'live-guard' };
    }
    lastHardAt = Date.now();
    hardRuns += 1;
    await AutoCleanup.runLightCleanup();
    try {
      const { ImageCache, VideoCache } = await import('../../render/asset-cache.js');
      ImageCache.trim?.(4);
      VideoCache.trim?.(0);
    } catch { /* ignore */ }
    try {
      const { ResourceManager } = await import('./resource-manager.js');
      ResourceManager.revokeAllObjectUrls?.();
    } catch { /* ignore */ }
    window.dispatchEvent(new CustomEvent('somosum-memory-hard-cleanup', {
      detail: { at: lastHardAt },
    }));
    return { ok: true };
  },

  snapshot() {
    return {
      softRuns,
      hardRuns,
      lastSoftAt,
      lastHardAt,
      liveGuard: isLiveBlocked(),
    };
  },
};
