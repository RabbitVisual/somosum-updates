/**
 * IdleManager — agenda trabalho só em idle / fora de live.
 */
import { TaskScheduler } from '../task-scheduler.js';
import { TaskIds } from '../task-registry.js';
import { IdleSoftCleanup } from '../memory/idle-soft-cleanup.js';

const queue = [];
let started = false;
let runs = 0;

function isLive() {
  return !!(typeof window !== 'undefined'
    && (window.__SOMOSUM_LIVE_ACTIVE || window.__SOMOSUM_COUNTDOWN_LIVE));
}

function isIdleEnough() {
  if (typeof document !== 'undefined' && document.visibilityState === 'hidden') return true;
  return Date.now() - (window.__SOMOSUM_LAST_ACTIVITY_AT || Date.now()) > 4000;
}

async function drainQueue() {
  if (isLive() || !isIdleEnough()) return;
  while (queue.length) {
    const job = queue.shift();
    if (!job) break;
    try {
      await job.fn();
      runs += 1;
    } catch { /* ignore */ }
    if (isLive()) break;
  }
}

export const IdleManager = {
  start(surface = 'default') {
    if (started) return;
    started = true;
    IdleSoftCleanup.start();
    TaskScheduler.register({
      id: TaskIds.PERF_IDLE_DRAIN || 'perf-idle-drain',
      kind: 'interval',
      intervalMs: 5000,
      priority: 10,
      runWhenHidden: true,
      fn: () => { void drainQueue(); },
    });
    window.addEventListener('pointerdown', () => {
      window.__SOMOSUM_LAST_ACTIVITY_AT = Date.now();
    }, { passive: true, capture: true });
    window.addEventListener('keydown', () => {
      window.__SOMOSUM_LAST_ACTIVITY_AT = Date.now();
    }, { passive: true, capture: true });
    void surface;
  },

  schedule(fn, { priority = 10 } = {}) {
    if (typeof fn !== 'function') return;
    queue.push({ fn, priority, at: Date.now() });
    queue.sort((a, b) => a.priority - b.priority);
  },

  snapshot() {
    return {
      queueDepth: queue.length,
      runs,
      live: isLive(),
      idleSoftStarted: started,
    };
  },
};
