/**
 * LazyLoader — import dinâmico com dedupe e grupos de boot.
 */
import { AssetLoader } from './asset-loader.js';

/** @type {Map<string, Promise<any>>} */
const pending = new Map();
/** @type {Map<string, any>} */
const loaded = new Map();

const REGISTRY = Object.freeze({
  'bible-reader': () => import('../../bible/bible-reader.js'),
  'bible-service': () => import('../../bible/bible-service.js'),
  'slide-designer': () => import('../../designer/slide-designer.js'),
  konva: () => import('../../../vendor/konva.min.js'),
  strong: () => import('../../bible/strong-service.js'),
});

export const BootGroup = Object.freeze({
  Critical: 'critical',
  Immediate: 'immediate',
  Deferred: 'deferred',
  Lazy: 'lazy',
  OnDemand: 'onDemand',
});

export const LazyLoader = {
  async load(id) {
    if (loaded.has(id)) return loaded.get(id);
    if (pending.has(id)) return pending.get(id);
    const factory = REGISTRY[id];
    if (!factory) throw new Error(`LazyLoader: módulo desconhecido "${id}"`);
    const promise = AssetLoader.importModule(id, factory).then((mod) => {
      loaded.set(id, mod);
      pending.delete(id);
      return mod;
    }).catch((err) => {
      pending.delete(id);
      throw err;
    });
    pending.set(id, promise);
    return promise;
  },

  preload(id) {
    void this.load(id).catch(() => {});
  },

  isLoaded(id) {
    return loaded.has(id);
  },

  snapshot() {
    return {
      loaded: [...loaded.keys()],
      pending: [...pending.keys()],
    };
  },
};
