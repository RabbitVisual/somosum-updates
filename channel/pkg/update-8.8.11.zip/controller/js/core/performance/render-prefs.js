/**
 * Preferências de projeção fluida — modo leigo + resolução inteligente.
 * mode: auto | fluid | economy
 *
 * IMPORTANTE: Canvas só cobre tipos simples (letra/tema). Bíblia/welcome/etc.
 * usam DOM. Por isso `auto` = DOM confiável (culto real); `fluid` tenta Canvas
 * onde suportado e cai para DOM no resto.
 */
import { ResourceGovernor } from '../../runtime/resource-governor.js';

export const RENDER_MODE_OPTIONS = [
  {
    id: 'auto',
    label: 'Automático (recomendado)',
    hint: 'Projeção confiável (DOM) + ponte local no EXE. Melhor para o culto.',
  },
  {
    id: 'fluid',
    label: 'Máxima fluidez',
    hint: 'Canvas nas letras (prévia); projetor permanece DOM estável.',
  },
  {
    id: 'economy',
    label: 'Economia',
    hint: 'Menos efeitos. O sistema também ativa sozinho em PC fraco.',
  },
];

/** Tipos que o compositor Canvas2D consegue pintar com texto legível. */
export const CANVAS_SLIDE_TYPES = new Set([
  'lyrics',
  'lyrics-title',
  'blank',
  'theme',
  'section',
  'announcement',
]);

export function slideSupportsCanvas(slide) {
  if (!slide) return false;
  const t = String(slide.type || '');
  if (!CANVAS_SLIDE_TYPES.has(t)) return false;
  if (t === 'blank' || t === 'theme') return true;
  const lines = Array.isArray(slide.lines) ? slide.lines : [];
  const title = String(slide.title || slide.text || '').trim();
  return lines.length > 0 || !!title;
}

const PROFILE_PRESETS = {
  // Culto real: DOM sempre legível; ponte local nativa dá fluidez Control→Screen
  auto: { engine: 'dom', postFx: false, previewMode: 'dom' },
  fluid: { engine: 'canvas', postFx: true, previewMode: 'dom' },
  economy: { engine: 'dom', postFx: false, previewMode: 'dom' },
  safeDom: { engine: 'dom', postFx: false, previewMode: 'dom' },
};

function deviceMemoryGb() {
  try {
    return Number(navigator.deviceMemory) || 0;
  } catch {
    return 0;
  }
}

/** Detecta hardware fraco (RAM ≤4GB, GPU software, flag explícita). */
export function detectLowSpecHardware(prefs = {}) {
  if (prefs?.lowSpec || prefs?.ui?.lowSpec || window.__SOMOSUM_LOW_SPEC) return true;
  const mem = deviceMemoryGb();
  if (mem > 0 && mem <= 4) return true;
  const gpu = readGpuTier();
  if (gpu === 'software') return true;
  const profile = readProfileName();
  return profile === 'eco' || profile === 'live-eco';
}

export function applyAutoLowSpecHints(prefs = {}) {
  const lowSpec = detectLowSpecHardware(prefs);
  if (lowSpec) {
    try {
      window.__SOMOSUM_LOW_SPEC = true;
    } catch { /* ignore */ }
  }
  return lowSpec;
}

function readGpuTier() {
  try {
    const snap = ResourceGovernor.getSnapshot?.();
    if (snap?.gpu?.tier) return snap.gpu.tier;
  } catch { /* ignore */ }
  return 'unknown';
}

function readProfileName() {
  try {
    const p = ResourceGovernor.getProfile?.();
    return typeof p === 'string' ? p : (p?.name || '');
  } catch {
    return '';
  }
}

function canvasAvailable() {
  try {
    const c = document.createElement('canvas');
    return !!(c.getContext?.('2d'));
  } catch {
    return false;
  }
}

/**
 * Resolve engine/postFx/preview a partir do modo + hardware.
 */
export function resolveRenderPrefs(prefs = {}, opts = {}) {
  const mode = String(prefs?.render?.mode || opts.mode || 'auto').toLowerCase();
  const lowSpec = detectLowSpecHardware({ ...prefs, ...opts });
  applyAutoLowSpecHints(prefs);
  const mem = deviceMemoryGb();
  const gpu = opts.gpuTier || readGpuTier();
  const profile = opts.profileName || readProfileName();
  const canCanvas = canvasAvailable();

  if (mode === 'fluid') {
    if (!canCanvas || lowSpec || gpu === 'software' || mem > 0 && mem <= 4) {
      return decorate('fluid', PROFILE_PRESETS.economy,
        'Fluidez pedida → DOM (PC limitado / sem Canvas)');
    }
    return decorate('fluid', PROFILE_PRESETS.fluid, 'Máxima fluidez (Canvas nas letras)');
  }

  if (mode === 'economy') {
    return decorate('economy', PROFILE_PRESETS.economy, 'Economia — DOM leve');
  }

  // auto — sempre DOM confiável para culto (bíblia, welcome, etc.)
  if (lowSpec || (mem > 0 && mem <= 4) || gpu === 'software' || profile === 'eco' || profile === 'live-eco') {
    return decorate('auto', {
      ...PROFILE_PRESETS.economy,
      previewMode: lowSpec ? 'bitmap' : PROFILE_PRESETS.economy.previewMode,
    },
      `Automático → economia (${lowSpec ? 'Low-Spec' : gpu === 'software' ? 'GPU software' : mem && mem <= 4 ? `${mem}GB RAM` : 'perfil eco'})`);
  }
  return decorate('auto', PROFILE_PRESETS.auto, 'Automático → projeção confiável (DOM)');
}

function decorate(mode, preset, reason) {
  const engineLabel = preset.engine === 'canvas' ? 'Canvas+DOM' : 'DOM';
  const fxLabel = preset.postFx ? 'efeitos suaves' : 'sem efeitos extras';
  const prevLabel = preset.previewMode === 'bitmap' ? 'prévia leve' : 'prévia completa';
  return {
    mode,
    engine: preset.engine,
    postFx: !!preset.postFx,
    previewMode: preset.previewMode || 'dom',
    reason,
    statusLabel: `${engineLabel} · ${fxLabel} · ${prevLabel}`,
  };
}

export function hydrateRenderPrefs(prefs = {}) {
  const resolved = resolveRenderPrefs(prefs);
  return {
    ...prefs,
    render: {
      ...(prefs.render || {}),
      mode: resolved.mode,
      engine: resolved.engine,
      postFx: resolved.postFx,
      previewMode: resolved.previewMode,
      reason: resolved.reason,
      statusLabel: resolved.statusLabel,
      resolvedAt: Date.now(),
    },
  };
}

/** Chave estável para detectar mudança real nas prefs de render. */
export function renderPrefsKey(prefs = {}) {
  const r = prefs?.render || {};
  return JSON.stringify({
    mode: r.mode || 'auto',
    engine: r.engine || 'dom',
    postFx: !!r.postFx,
    previewMode: r.previewMode || 'dom',
  });
}

/**
 * Superfície de projeção (Screen) sempre DOM — evita flicker/tela preta do Canvas
 * enquanto o compositor 8.1 amadurece. Controle/prévia mantém prefs resolvidas.
 */
export function hydrateRenderPrefsForSurface(prefs = {}, surface = 'control') {
  const hydrated = hydrateRenderPrefs(prefs);
  if (surface === 'screen' || surface === 'projector') {
    return {
      ...hydrated,
      render: {
        ...hydrated.render,
        engine: 'dom',
        postFx: false,
        reason: 'Projeção (DOM estável)',
        statusLabel: 'DOM · projeção confiável',
      },
    };
  }
  return hydrated;
}

export function applyRenderMode(prefs = {}, mode = 'auto') {
  const next = {
    ...prefs,
    render: {
      ...(prefs.render || {}),
      mode: String(mode || 'auto').toLowerCase(),
    },
  };
  return hydrateRenderPrefs(next);
}

export function describeRenderPrefs(prefs = {}) {
  const r = prefs.render || resolveRenderPrefs(prefs);
  const opt = RENDER_MODE_OPTIONS.find((o) => o.id === (r.mode || 'auto'));
  return {
    modeLabel: opt?.label || 'Automático',
    statusLabel: r.statusLabel || resolveRenderPrefs(prefs).statusLabel,
    reason: r.reason || '',
  };
}

export async function ensureRenderPrefsPersisted(getPrefsFn, savePrefsFn, opts = {}) {
  const current = typeof getPrefsFn === 'function' ? getPrefsFn() : getPrefsFn;
  let base = current || {};
  // Migração: mode auto/economy com engine canvas legado → re-hidrata
  const mode = String(base?.render?.mode || 'auto').toLowerCase();
  if (base?.render?.engine === 'canvas' && mode !== 'fluid') {
    base = { ...base, render: { ...base.render, mode: mode === 'economy' ? 'economy' : 'auto' } };
  }
  const hydrated = opts.surface
    ? hydrateRenderPrefsForSurface(base, opts.surface)
    : hydrateRenderPrefs(base);
  const before = JSON.stringify({
    mode: current?.render?.mode,
    engine: current?.render?.engine,
    postFx: current?.render?.postFx,
    previewMode: current?.render?.previewMode,
  });
  const after = JSON.stringify({
    mode: hydrated.render.mode,
    engine: hydrated.render.engine,
    postFx: hydrated.render.postFx,
    previewMode: hydrated.render.previewMode,
  });
  if (before !== after && typeof savePrefsFn === 'function') {
    await savePrefsFn({ render: hydrated.render });
  }
  try {
    window.__SOMOSUM_RENDER = hydrated.render;
    document.documentElement.dataset.renderEngine = hydrated.render.engine;
    document.documentElement.dataset.renderMode = hydrated.render.mode;
  } catch { /* ignore */ }
  return hydrated;
}
