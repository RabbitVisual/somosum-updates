/**
 * FrameBudget — orçamento único (8–16 ms) via eventos de overrun.
 */
let overruns = 0;
let lastOverrunMs = 0;
let lastOverrunAt = 0;
let coalescePending = false;
const coalesceQueue = new Map();
let wired = false;

function onOverBudget(ev) {
  overruns += 1;
  lastOverrunMs = ev.detail?.elapsed ?? ev.detail?.ms ?? 0;
  lastOverrunAt = Date.now();
  window.__SOMOSUM_FRAME_OVER_BUDGET = true;
}

export const FrameBudget = {
  start() {
    if (wired) return;
    wired = true;
    window.addEventListener('somosum-frame-over-budget', onOverBudget);
  },

  stop() {
    wired = false;
    window.removeEventListener('somosum-frame-over-budget', onOverBudget);
  },

  /** Coalesce UI commits quando over budget (sync Critical permanece). */
  coalesceUi(key, fn) {
    if (typeof fn !== 'function') return;
    coalesceQueue.set(key, fn);
    if (coalescePending) return;
    coalescePending = true;
    requestAnimationFrame(() => {
      coalescePending = false;
      if (window.__SOMOSUM_FRAME_OVER_BUDGET) {
        const batch = [...coalesceQueue.values()];
        coalesceQueue.clear();
        for (const run of batch) {
          try { run(); } catch { /* ignore */ }
        }
      } else {
        coalesceQueue.forEach((run, k) => {
          try { run(); } catch { /* ignore */ }
          coalesceQueue.delete(k);
        });
      }
      window.__SOMOSUM_FRAME_OVER_BUDGET = false;
    });
  },

  snapshot() {
    return {
      overruns,
      lastOverrunMs,
      lastOverrunAt,
      budgetMs: 16,
      frameOverBudget: !!window.__SOMOSUM_FRAME_OVER_BUDGET,
    };
  },
};
