/**
 * PerformanceProfiler — snapshot boot/FPS/RAM/slide/sync para Diagnóstico.
 */
import { RenderProfiler } from '../render-engine/render-profiler.js';
import { TaskScheduler } from '../task-scheduler.js';

const bootAt = typeof performance !== 'undefined' ? performance.now() : Date.now();
let bootCompleteAt = 0;
let fpsEstimate = null;
let fpsSamples = [];

function heapSnapshot() {
  const mem = typeof performance !== 'undefined' ? performance.memory : null;
  if (!mem?.usedJSHeapSize) return null;
  return {
    usedMb: Math.round(mem.usedJSHeapSize / (1024 * 1024)),
    totalMb: Math.round(mem.totalJSHeapSize / (1024 * 1024)),
    limitMb: Math.round(mem.jsHeapSizeLimit / (1024 * 1024)),
  };
}

function trackFps() {
  let last = performance.now();
  let frames = 0;
  const tick = (now) => {
    frames += 1;
    if (now - last >= 1000) {
      fpsEstimate = frames;
      fpsSamples.push(frames);
      if (fpsSamples.length > 30) fpsSamples.shift();
      frames = 0;
      last = now;
    }
    requestAnimationFrame(tick);
  };
  requestAnimationFrame(tick);
}

export const PerformanceProfiler = {
  markBootComplete() {
    if (!bootCompleteAt) bootCompleteAt = performance.now();
  },

  startFpsProbe() {
    if (typeof requestAnimationFrame === 'function') trackFps();
  },

  snapshot(modules = {}) {
    const sched = TaskScheduler.getMetrics?.() || {};
    const render = RenderProfiler.snapshot?.() || {};
    return {
      bootMs: bootCompleteAt ? Math.round(bootCompleteAt - bootAt) : null,
      fpsEstimate,
      fpsAvg: fpsSamples.length
        ? Math.round(fpsSamples.reduce((a, b) => a + b, 0) / fpsSamples.length)
        : null,
      heap: heapSnapshot(),
      scheduler: sched,
      render,
      modules,
      exportedAt: Date.now(),
    };
  },

  toReportHtml(snap) {
    const s = snap || this.snapshot();
    const rows = [
      ['Boot (ms)', s.bootMs ?? '—'],
      ['FPS (est.)', s.fpsEstimate ?? '—'],
      ['FPS (média)', s.fpsAvg ?? '—'],
      ['Heap (MB)', s.heap ? `${s.heap.usedMb} / ${s.heap.limitMb}` : '—'],
      ['Scheduler overrun (ms)', s.scheduler?.lastOverrunMs ?? '—'],
      ['Render writes', s.render?.writes ?? '—'],
    ];
    return `<table class="perf-diag-table"><tbody>${
      rows.map(([k, v]) => `<tr><th>${k}</th><td>${v}</td></tr>`).join('')
    }</tbody></table>`;
  },
};
