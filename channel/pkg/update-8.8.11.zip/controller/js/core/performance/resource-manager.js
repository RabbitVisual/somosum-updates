/**
 * ResourceManager — dedupe de objectURLs / refs de mídia; bridge leve ao ResourceGovernor.
 */
const objectUrls = new Map();
let cacheHits = 0;
let cacheMisses = 0;

export const ResourceManager = {
  trackObjectUrl(key, url) {
    if (!key || !url) return url;
    const prev = objectUrls.get(key);
    if (prev && prev !== url) {
      try { URL.revokeObjectURL(prev); } catch { /* ignore */ }
    }
    objectUrls.set(key, url);
    return url;
  },

  revokeObjectUrl(key) {
    const url = objectUrls.get(key);
    if (!url) return;
    objectUrls.delete(key);
    try { URL.revokeObjectURL(url); } catch { /* ignore */ }
  },

  revokeStaleObjectUrls(maxAgeMs = 30 * 60 * 1000) {
    if (objectUrls.size < 32) return 0;
    let revoked = 0;
    for (const [key] of [...objectUrls.entries()].slice(0, Math.floor(objectUrls.size / 3))) {
      this.revokeObjectUrl(key);
      revoked += 1;
      if (revoked >= 24) break;
    }
    return revoked;
  },

  revokeAllObjectUrls() {
    for (const key of [...objectUrls.keys()]) this.revokeObjectUrl(key);
  },

  noteCacheHit() { cacheHits += 1; },
  noteCacheMiss() { cacheMisses += 1; },

  async applyEcoProfile() {
    try {
      const { ResourceGovernor } = await import('../../runtime/resource-governor.js');
      const live = !!window.__SOMOSUM_LIVE_ACTIVE;
      ResourceGovernor.forceProfile(live ? 'live-eco' : 'eco');
    } catch { /* ignore */ }
  },

  snapshot() {
    return {
      objectUrlCount: objectUrls.size,
      cacheHits,
      cacheMisses,
    };
  },
};
