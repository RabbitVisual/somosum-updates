export {
  bootstrapPerformance,
  buildSnapshot,
  MemoryManager,
  ResourceManager,
  LazyLoader,
  IdleManager,
  FrameBudget,
  AssetLoader,
  PerformanceProfiler,
} from './performance-manager.js';

export { VirtualRenderer, mountVirtualListHost, mountVirtualGrid } from './virtual-renderer.js';
export { TaskScheduler, TaskIds, TaskPriority } from './task-scheduler.js';
export {
  RENDER_MODE_OPTIONS,
  CANVAS_SLIDE_TYPES,
  slideSupportsCanvas,
  resolveRenderPrefs,
  hydrateRenderPrefs,
  applyRenderMode,
  describeRenderPrefs,
  ensureRenderPrefsPersisted,
} from './render-prefs.js';

import { bootstrapPerformance } from './performance-manager.js';

if (typeof window !== 'undefined') {
  queueMicrotask(() => {
    try { bootstrapPerformance(); } catch { /* offline */ }
  });
}
