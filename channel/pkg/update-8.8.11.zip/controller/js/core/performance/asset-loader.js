/**
 * AssetLoader — dedupe de import() e fetch de mídia com cancelamento.
 */
/** @type {Map<string, Promise<any>>} */
const importCache = new Map();
/** @type {Map<string, AbortController>} */
const fetchControllers = new Map();
let loads = 0;
let hits = 0;

export const AssetLoader = {
  async importModule(key, factory) {
    if (importCache.has(key)) {
      hits += 1;
      return importCache.get(key);
    }
    loads += 1;
    const promise = Promise.resolve().then(factory);
    importCache.set(key, promise);
    return promise;
  },

  prefetchUrl(url, priority = 'low') {
    if (!url) return;
    try {
      const link = document.createElement('link');
      link.rel = priority === 'high' ? 'preload' : 'prefetch';
      link.as = url.match(/\.(mp4|webm|mov)/i) ? 'video' : 'fetch';
      link.href = url;
      document.head.appendChild(link);
    } catch { /* ignore */ }
  },

  async fetchMedia(url, { key = url, signal = null } = {}) {
    if (!url) throw new Error('fetchMedia: url vazia');
    const prev = fetchControllers.get(key);
    prev?.abort?.();
    const controller = signal ? null : new AbortController();
    if (controller) fetchControllers.set(key, controller);
    loads += 1;
    const res = await fetch(url, { signal: signal || controller?.signal, cache: 'force-cache' });
    if (!res.ok) throw new Error(`fetchMedia ${res.status}`);
    return res;
  },

  cancel(key) {
    fetchControllers.get(key)?.abort?.();
    fetchControllers.delete(key);
  },

  snapshot() {
    return {
      importCacheSize: importCache.size,
      activeFetches: fetchControllers.size,
      loads,
      hits,
    };
  },
};
