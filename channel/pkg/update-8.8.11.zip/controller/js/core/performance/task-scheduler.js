/**
 * Bridge tipado sobre TaskScheduler existente — prioridades Critical→Idle.
 */
export {
  TaskScheduler,
} from '../task-scheduler.js';

export {
  TaskIds,
} from '../task-registry.js';

/** Prioridades documentadas (menor número = mais urgente). */
export const TaskPriority = Object.freeze({
  Critical: 0,
  High: 2,
  Normal: 5,
  Low: 8,
  Idle: 10,
});
