/**
 * VirtualRenderer — wrapper padronizado sobre ui/kit/virtual-list.
 */
import { mountVirtualList } from '../../ui/kit/virtual-list.js';

export function mountVirtualListHost(host, opts) {
  return mountVirtualList(host, opts);
}

/**
 * Grid virtualizado por linhas (cards com altura fixa por linha).
 */
export function mountVirtualGrid(host, {
  items = [],
  rowHeight = 200,
  minColWidth = 168,
  gap = 14,
  renderCell,
  className = 'media-grid-row',
} = {}) {
  if (!host || typeof renderCell !== 'function') return { dispose() {} };

  const measureCols = () => {
    const w = host.clientWidth || 640;
    return Math.max(1, Math.floor((w + gap) / (minColWidth + gap)));
  };

  let cols = measureCols();
  let rows = [];
  const rebuildRows = () => {
    cols = measureCols();
    rows = [];
    for (let i = 0; i < items.length; i += cols) {
      rows.push(items.slice(i, i + cols));
    }
  };
  rebuildRows();

  host.classList.add('su-virtual-grid-host');
  const list = mountVirtualList(host, {
    items: rows,
    rowHeight,
    renderRow: (rowItems, rowIndex) => {
      const cells = rowItems.map((item, idx) => renderCell(item, rowIndex * cols + idx)).join('');
      return `<div class="${className}" style="display:grid;grid-template-columns:repeat(${cols},minmax(0,1fr));gap:${gap}px">${cells}</div>`;
    },
  });

  const onResize = () => {
    const next = measureCols();
    if (next === cols) return;
    rebuildRows();
    list.refresh(rows);
  };
  window.addEventListener('resize', onResize, { passive: true });

  return {
    refresh(nextItems) {
      items = nextItems || [];
      rebuildRows();
      list.refresh(rows);
    },
    dispose() {
      window.removeEventListener('resize', onResize);
      list.dispose?.();
    },
  };
}

export const VirtualRenderer = {
  mountVirtualList: mountVirtualListHost,
  mountVirtualGrid,
};
