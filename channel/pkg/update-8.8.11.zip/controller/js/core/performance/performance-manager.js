/**
 * PerformanceManager — fachada + bootstrapPerformance().
 */
import { MemoryManager } from './memory-manager.js';
import { ResourceManager } from './resource-manager.js';
import { LazyLoader } from './lazy-loader.js';
import { IdleManager } from './idle-manager.js';
import { FrameBudget } from './frame-budget.js';
import { AssetLoader } from './asset-loader.js';
import { PerformanceProfiler } from './performance-profiler.js';

let bootstrapped = false;
let lowSpecAutoChecked = false;

function detectWeakHardware() {
  const cores = typeof navigator !== 'undefined' ? navigator.hardwareConcurrency : null;
  const mem = typeof navigator !== 'undefined' ? navigator.deviceMemory : null;
  // Notebooks modernos costumam reportar 4 núcleos — não forçar economia só por isso.
  // Economia automática só em hardware claramente fraco.
  if (cores != null && cores <= 2) return { weak: true, reason: 'cores', cores };
  if (mem != null && mem <= 2) return { weak: true, reason: 'deviceMemory', deviceMemoryGb: mem };
  if (cores != null && cores <= 4 && mem != null && mem <= 4) {
    return { weak: true, reason: 'cores+memory', cores, deviceMemoryGb: mem };
  }
  return { weak: false };
}

function readPrefsLowSpec() {
  try {
    const raw = localStorage.getItem('somosum-prefs');
    if (!raw) return false;
    const prefs = JSON.parse(raw);
    return !!(prefs?.lowSpec || prefs?.ui?.lowSpec);
  } catch {
    return false;
  }
}

function applyLowSpecCss(on) {
  document.documentElement.classList.toggle('somosum-low-spec', on);
  window.__SOMOSUM_LOW_SPEC = on;
  if (on) void ResourceManager.applyEcoProfile();
}

async function maybeAutoLowSpec() {
  if (lowSpecAutoChecked) return;
  lowSpecAutoChecked = true;
  if (readPrefsLowSpec()) {
    applyLowSpecCss(true);
    return;
  }
  const hw = detectWeakHardware();
  if (!hw.weak) return;
  // Aplica sozinho — sem exigir checkbox; prefs só registram o estado.
  applyLowSpecCss(true);
  try {
    const raw = localStorage.getItem('somosum-prefs');
    const prefs = raw ? JSON.parse(raw) : {};
    prefs.lowSpec = true;
    prefs.ui = { ...(prefs.ui || {}), lowSpec: true, lowSpecAuto: true };
    localStorage.setItem('somosum-prefs', JSON.stringify(prefs));
  } catch { /* ignore */ }
  window.dispatchEvent(new CustomEvent('somosum-low-spec-auto', { detail: hw }));
}

export function bootstrapPerformance(surface = 'default') {
  if (bootstrapped) return;
  bootstrapped = true;

  MemoryManager.start();
  IdleManager.start(surface);
  FrameBudget.start();
  PerformanceProfiler.startFpsProbe();

  void maybeAutoLowSpec();

  // ResourceGovernor comanda o perfil em runtime; low-spec CSS acompanha eco automático.
  window.addEventListener('somosum-resource-profile', (ev) => {
    const name = ev?.detail?.profile;
    if (name === 'eco' || name === 'live-eco') applyLowSpecCss(true);
  });

  if (typeof window !== 'undefined') {
    window.SOMOSUM_PERFORMANCE = {
      bootstrap: bootstrapPerformance,
      snapshot: () => buildSnapshot(),
      MemoryManager,
      ResourceManager,
      LazyLoader,
      IdleManager,
      FrameBudget,
      AssetLoader,
      PerformanceProfiler,
      applyLowSpec: applyLowSpecCss,
      detectWeakHardware,
    };

    window.addEventListener('somosum-app-ready', () => {
      PerformanceProfiler.markBootComplete();
      IdleManager.schedule(() => LazyLoader.preload('bible-reader'), { priority: 10 });
    }, { once: true });
  }
}

export function buildSnapshot() {
  return {
    surface: typeof document !== 'undefined' ? document.documentElement?.dataset?.surface : null,
    isLive: !!window.__SOMOSUM_LIVE_ACTIVE,
    lowSpec: !!window.__SOMOSUM_LOW_SPEC,
    frameOverBudget: !!window.__SOMOSUM_FRAME_OVER_BUDGET,
    hardware: detectWeakHardware(),
    memory: MemoryManager.snapshot(),
    idle: IdleManager.snapshot(),
    frame: FrameBudget.snapshot(),
    assets: AssetLoader.snapshot(),
    lazy: LazyLoader.snapshot(),
    resources: ResourceManager.snapshot(),
    profiler: PerformanceProfiler.snapshot({
      memory: MemoryManager.snapshot(),
      idle: IdleManager.snapshot(),
      frame: FrameBudget.snapshot(),
    }),
  };
}

export { MemoryManager, ResourceManager, LazyLoader, IdleManager, FrameBudget, AssetLoader, PerformanceProfiler };
