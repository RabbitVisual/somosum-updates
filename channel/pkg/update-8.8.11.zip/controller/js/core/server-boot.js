/**
 * Protege o boot da aplicacao contra quedas breves do servidor (F5, reinicio suave).
 * Mostra overlay "Reconectando..." em vez de pagina de erro imediata.
 */

let _bootOverlay = null;
let _retryTimer = null;
let _scriptFailCount = 0;
let _gaveUp = false;

function ensureOverlay() {
  if (_bootOverlay) return _bootOverlay;
  _bootOverlay = document.createElement('div');
  _bootOverlay.id = 'somosum-boot-overlay';
  _bootOverlay.style.cssText = `
    position:fixed;inset:0;z-index:999999;display:none;align-items:center;justify-content:center;
    background:rgba(0,0,0,0.92);color:#d4c68d;font-family:Segoe UI,sans-serif;text-align:center;padding:2rem;
  `;
  _bootOverlay.innerHTML = `
    <div style="max-width:480px">
      <p style="letter-spacing:.15em;font-size:.8rem;color:#888;margin:0 0 .75rem">SOMOSUM</p>
      <h2 style="margin:0 0 .75rem;font-size:1.35rem" id="somosum-boot-title">Reconectando ao servidor…</h2>
      <p style="color:#aaa;line-height:1.6;margin:0 0 1rem" id="somosum-boot-msg">
        O servidor local esta reiniciando ou ocupado. Aguarde — a pagina recarrega automaticamente.
      </p>
      <div style="width:48px;height:48px;border:3px solid rgba(212,198,141,.25);border-top-color:#d4c68d;border-radius:50%;margin:0 auto 1rem;animation:somosumSpin .8s linear infinite"></div>
      <button type="button" id="somosum-boot-retry" style="background:#d4c68d;color:#111;border:none;padding:.65rem 1.25rem;border-radius:6px;cursor:pointer;font-size:.95rem">Tentar agora</button>
    </div>
    <style>@keyframes somosumSpin{to{transform:rotate(360deg)}}</style>`;
  document.body.appendChild(_bootOverlay);
  _bootOverlay.querySelector('#somosum-boot-retry')?.addEventListener('click', () => {
    window.location.reload();
  });
  return _bootOverlay;
}

function showReconnectOverlay(message) {
  if (location.protocol === 'file:') return;
  const el = ensureOverlay();
  el.style.display = 'flex';
  const msg = el.querySelector('#somosum-boot-msg');
  if (msg && message) msg.textContent = message;
}

function hideReconnectOverlay() {
  if (_bootOverlay) _bootOverlay.style.display = 'none';
}

async function waitAndReload() {
  if (_gaveUp || location.protocol === 'file:') return;
  showReconnectOverlay();
  try {
    const { waitForServer, resetServerCache } = await import('./storage/adapters/server-adapter.js');
    resetServerCache();
    const ok = await waitForServer(100, 500);
    if (ok) {
      hideReconnectOverlay();
      window.location.reload();
      return;
    }
  } catch { /* ignore */ }
  if (!_gaveUp) {
    _retryTimer = setTimeout(waitAndReload, 2000);
  }
}

export function installServerBootGuard(options = {}) {
  if (location.protocol === 'file:') return;

  const maxWaitMs = options.maxWaitMs ?? 120000;
  const start = Date.now();

  window.addEventListener('error', (e) => {
    if (_gaveUp) return;
    if (e.target && e.target.tagName === 'SCRIPT') {
      _scriptFailCount += 1;
      if (Date.now() - start < maxWaitMs) {
        showReconnectOverlay('Scripts não carregaram — aguardando servidor local…');
        clearTimeout(_retryTimer);
        _retryTimer = setTimeout(waitAndReload, 800);
      }
    }
  }, true);

  window.addEventListener('unhandledrejection', () => {
    if (Date.now() - start < maxWaitMs && _scriptFailCount > 0) {
      showReconnectOverlay();
    }
  });

  setTimeout(() => {
    if (_scriptFailCount > 0 && document.getElementById('boot-loading')) {
      _gaveUp = false;
      waitAndReload();
    }
  }, 3000);
}

export function markAppReady() {
  hideReconnectOverlay();
  clearTimeout(_retryTimer);
  const removeSplash = () => {
    document.getElementById('boot-loading')?.remove();
    document.getElementById('diag-loading')?.remove();
    document.getElementById('somosum-boot-overlay')?.remove();
  };
  // Controle: o dismiss com mínimo ~5s é feito por __somosumDismissBootSplash
  if (typeof window.__somosumDismissBootSplash === 'function' && document.getElementById('boot-loading')) {
    /* splash ainda sob controle do Controle — não remover cedo */
  } else {
    removeSplash();
  }
  import('./task-scheduler.js').then(({ TaskScheduler }) => {
    TaskScheduler.start();
  }).catch(() => {});
  window.dispatchEvent(new CustomEvent('somosum-app-ready'));
}

export { showReconnectOverlay, hideReconnectOverlay, waitAndReload };
