/**
 * Error Boundary global — captura exceções e evita travamento do culto.
 */
import { LogService, LogCategory } from './logging/log-service.js';
import { formatStack, isBenignAbort, isBenignAppError } from './logging/log-context.js';

const wrappedFns = new WeakMap();
let installed = false;
const errorHandlers = new Set();

export function safeCall(fn, { module = 'core', fallback = null, label = '' } = {}) {
  return (...args) => {
    try {
      const result = fn(...args);
      if (result && typeof result.then === 'function') {
        return result.catch((err) => {
          LogService.error(label || 'Promise rejection', {
            module,
            category: LogCategory.GENERAL,
            err,
            detail: { label },
          });
          notifyHandlers(err);
          return fallback;
        });
      }
      return result;
    } catch (err) {
      LogService.error(label || 'Sync error', {
        module,
        category: LogCategory.GENERAL,
        err,
        detail: { label },
      });
      notifyHandlers(err);
      return fallback;
    }
  };
}

export function safeAsync(fn, opts) {
  const wrapped = safeCall(fn, opts);
  return (...args) => Promise.resolve(wrapped(...args));
}

export function wrapMethod(target, methodName, opts = {}) {
  if (!target || typeof target[methodName] !== 'function') return;
  const original = target[methodName];
  if (wrappedFns.has(original)) return;
  const wrapped = safeCall(original.bind(target), {
    module: opts.module || methodName,
    label: opts.label || methodName,
    fallback: opts.fallback,
  });
  wrappedFns.set(original, wrapped);
  target[methodName] = wrapped;
}

export function onError(handler) {
  if (typeof handler === 'function') errorHandlers.add(handler);
  return () => errorHandlers.delete(handler);
}

function notifyHandlers(err) {
  errorHandlers.forEach((h) => {
    try { h(err); } catch { /* ignore */ }
  });
}

export function installErrorBoundary({ module = 'boot' } = {}) {
  if (installed) return;
  installed = true;

  window.addEventListener('error', (e) => {
    LogService.error(e.message || 'Uncaught error', {
      module,
      category: LogCategory.BOOT,
      stack: formatStack(e.error) || `${e.filename}:${e.lineno}:${e.colno}`,
      detail: { source: e.filename, line: e.lineno, col: e.colno },
    });
    notifyHandlers(e.error || e);
    e.preventDefault?.();
    return true;
  });

  window.addEventListener('unhandledrejection', (e) => {
    const reason = e.reason;
    if (isBenignAbort(reason) || isBenignAppError(reason)) {
      e.preventDefault?.();
      return;
    }
    LogService.error(String(reason?.message || reason), {
      module,
      category: LogCategory.BOOT,
      err: reason,
      detail: { type: 'unhandledrejection' },
    });
    notifyHandlers(reason);
    e.preventDefault?.();
  });

  LogService.debug('Error boundary instalado', {
    module: 'error-boundary',
    category: LogCategory.BOOT,
  });
}
