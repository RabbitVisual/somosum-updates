import { secureFetch } from './security/api-security.js';
import { isAllowedDataPath, OPTIONAL_DISK_DEFAULTS } from './storage/schema.js';
import { dataPublicUrl } from './data-public-url.js';

/** Defaults para JSON opcionais: remote-macros.json, macros.json, bible-history.json, ccli-usage.json */
export { OPTIONAL_DISK_DEFAULTS };
export { dataPublicUrl };

function isAllowedFile(fileName) {
  return isAllowedDataPath(fileName);
}

const debounceTimers = new Map();
/** fileName -> { data, silent, timer } — permite flush imediato ao salvar/fechar */
const debouncePending = new Map();
let serverAvailable = null;
let lastServerCheck = 0;
const SERVER_CHECK_MS = 5000;
let bootWaitPromise = null;

export function resetServerCache() {
  serverAvailable = null;
  lastServerCheck = 0;
}

/** Uma unica espera por recarregamento de pagina — evita dezenas de pings paralelos no F5. */
export async function waitForServerBoot(maxAttempts = 60, delayMs = 400) {
  if (location.protocol === 'file:') return false;
  if (serverAvailable === true) return true;
  if (!bootWaitPromise) {
    bootWaitPromise = (async () => {
      resetServerCache();
      const ok = await waitForServer(maxAttempts, delayMs);
      if (ok) {
        serverAvailable = true;
        lastServerCheck = Date.now();
      }
      return ok;
    })();
  }
  return bootWaitPromise;
}

export async function isServerAvailable() {
  if (location.protocol === 'file:') return false;
  const now = Date.now();
  if (serverAvailable !== null && now - lastServerCheck < SERVER_CHECK_MS) {
    return serverAvailable;
  }
  try {
    const res = await fetch('/api/ping', { cache: 'no-store', signal: AbortSignal.timeout(4000) });
    serverAvailable = res.ok;
  } catch {
    serverAvailable = false;
  }
  lastServerCheck = now;
  return serverAvailable;
}

/** Aguarda o servidor local ficar pronto (ex.: boot via SOMOSUM.exe / TrayMode). */
export async function waitForServer(maxAttempts = 60, delayMs = 500) {
  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    lastServerCheck = 0;
    try {
      const res = await fetch('/api/ping', {
        cache: 'no-store',
        signal: AbortSignal.timeout(2500),
      });
      if (res.ok) {
        serverAvailable = true;
        lastServerCheck = Date.now();
        return true;
      }
    } catch {
      serverAvailable = false;
    }
    // Ramp: primeiras tentativas rapidas, depois estabiliza no delayMs.
    const wait = Math.min(120 + (attempt - 1) * 80, delayMs);
    await new Promise((r) => setTimeout(r, wait));
  }
  return false;
}

export async function loadFromDisk(fileName) {
  if (!isAllowedFile(fileName)) return null;
  if (!(await isServerAvailable())) return null;
  try {
    const res = await fetch(dataPublicUrl(fileName), { cache: 'no-store' });
    if (!res.ok) {
      if (res.status === 404 && Object.prototype.hasOwnProperty.call(OPTIONAL_DISK_DEFAULTS, fileName)) {
        const seeded = structuredClone(OPTIONAL_DISK_DEFAULTS[fileName]);
        // Grava na hora para o próximo boot não gerar 404 no Network do DevTools
        void saveToDisk(fileName, seeded, { silent: true }).catch(() => {});
        return seeded;
      }
      return null;
    }
    return await res.json();
  } catch {
    return null;
  }
}

const COMPACT_DISK_FILES = new Set([
  'letras.json',
  'worship-library-backup.json',
  'cultos.json',
  'program.json',
  'media/index.json',
]);

export async function saveToDisk(fileName, data, { retry = true, silent = false } = {}) {
  if (!isAllowedFile(fileName)) return false;
  if (!(await isServerAvailable())) {
    if (retry && (await waitForServer(3, 400))) {
      return saveToDisk(fileName, data, { retry: false, silent });
    }
    return false;
  }
  try {
    const pretty = !COMPACT_DISK_FILES.has(fileName);
    const body = pretty ? JSON.stringify(data, null, 2) : JSON.stringify(data);
    const res = await secureFetch(`/api/save?file=${encodeURIComponent(fileName)}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json; charset=utf-8' },
      body,
      signal: AbortSignal.timeout(12000),
    });
    if (res.ok || res.status === 202) {
      serverAvailable = true;
      lastServerCheck = Date.now();
      if (!silent) {
        if (res.status === 202) {
          window.dispatchEvent(new CustomEvent('somosum-disk-pending', { detail: { file: fileName } }));
        } else {
          window.dispatchEvent(new CustomEvent('somosum-disk-saved', { detail: { file: fileName } }));
        }
      }
      return true;
    }
    return false;
  } catch {
    if (retry && (await waitForServer(2, 400))) {
      return saveToDisk(fileName, data, { retry: false, silent });
    }
    return false;
  }
}

export function saveToDiskDebounced(fileName, data, delayMs = 500, { silent = false } = {}) {
  const prev = debouncePending.get(fileName);
  if (prev?.timer) clearTimeout(prev.timer);
  clearTimeout(debounceTimers.get(fileName));
  const timer = setTimeout(() => {
    debouncePending.delete(fileName);
    debounceTimers.delete(fileName);
    void saveToDisk(fileName, data, { silent });
  }, delayMs);
  debouncePending.set(fileName, { data, silent, timer });
  debounceTimers.set(fileName, timer);
}

/** Grava imediatamente todos os saves pendentes (ordem, letras, config). */
export async function flushDebouncedDiskWrites() {
  const entries = [...debouncePending.entries()];
  debouncePending.clear();
  for (const [fileName, entry] of entries) {
    if (entry?.timer) clearTimeout(entry.timer);
    debounceTimers.delete(fileName);
  }
  for (const [fileName, entry] of entries) {
    if (!entry) continue;
    await saveToDisk(fileName, entry.data, { silent: entry.silent });
  }
}

export async function saveAssetToDisk(id, dataUrl, mimeType = 'image/png') {
  if (!(await isServerAvailable())) return false;
  try {
    const res = await secureFetch('/api/save-asset', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json; charset=utf-8' },
      body: JSON.stringify({ id, dataUrl, mimeType }),
    });
    return res.ok;
  } catch {
    return false;
  }
}

export async function saveMediaToDisk(id, dataUrl, mimeType = 'image/png') {
  if (!(await isServerAvailable())) return false;
  try {
    const res = await secureFetch('/api/save-media', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json; charset=utf-8' },
      body: JSON.stringify({ id, dataUrl, mimeType }),
    });
    return res.ok;
  } catch {
    return false;
  }
}

export async function deleteMediaFromDisk(id) {
  if (!(await isServerAvailable())) return false;
  try {
    const res = await secureFetch('/api/delete-media', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json; charset=utf-8' },
      body: JSON.stringify({ id }),
    });
    return res.ok;
  } catch {
    return false;
  }
}

export async function uploadAudioFile(file) {
  if (!(await isServerAvailable())) return false;
  try {
    const dataUrl = await new Promise((resolve, reject) => {
      const r = new FileReader();
      r.onload = () => resolve(r.result);
      r.onerror = reject;
      r.readAsDataURL(file);
    });
    const res = await secureFetch('/api/audio/upload', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json; charset=utf-8' },
      body: JSON.stringify({ fileName: file.name, dataUrl }),
    });
    return res.ok;
  } catch {
    return false;
  }
}

export async function logToServer(level, message, detail = null) {
  const { logToServer: logViaService } = await import('./logging/log-service.js');
  return logViaService(level, message, detail);
}

export { isAllowedFile };
