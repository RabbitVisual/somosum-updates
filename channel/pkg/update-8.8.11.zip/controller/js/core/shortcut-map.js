/**
 * Mapa de atalhos configuráveis (U1-D).
 * Defaults em data/shortcuts.json; overrides em prefs.shortcuts.
 */
import { dataPublicUrl } from './data-public-url.js';

export const DEFAULT_SHORTCUTS = {
  version: 1,
  bindings: {
    next: 'ArrowRight',
    nextAlt: 'Space',
    prev: 'ArrowLeft',
    blank: 'KeyB',
    logo: 'KeyL',
    countdown: 'KeyC',
    clearOverlay: 'Escape',
    docs: 'KeyD',
    tour: 'Shift+Slash',
    commandPalette: 'Ctrl+KeyK',
    quickSearch: 'Ctrl+Shift+KeyF',
    undo: 'Ctrl+KeyZ',
    redo: 'Ctrl+KeyY',
    saveProgram: 'Ctrl+KeyS',
    jump1: 'Digit1',
    jump2: 'Digit2',
    jump3: 'Digit3',
    jump4: 'Digit4',
    jump5: 'Digit5',
    jump6: 'Digit6',
    jump7: 'Digit7',
    jump8: 'Digit8',
    jump9: 'Digit9',
  },
};

const ACTION_LABELS = {
  next: 'Próximo slide',
  nextAlt: 'Próximo (alternativo)',
  prev: 'Slide anterior',
  blank: 'Tela preta',
  logo: 'Logo',
  countdown: 'Pré-culto',
  clearOverlay: 'Limpar overlay',
  docs: 'Documentação',
  tour: 'Tour guiado',
  commandPalette: 'Paleta de comandos',
  quickSearch: 'Busca rápida',
  undo: 'Desfazer',
  redo: 'Refazer',
  saveProgram: 'Salvar ordem',
  jump1: 'Ir ao item 1',
  jump2: 'Ir ao item 2',
  jump3: 'Ir ao item 3',
  jump4: 'Ir ao item 4',
  jump5: 'Ir ao item 5',
  jump6: 'Ir ao item 6',
  jump7: 'Ir ao item 7',
  jump8: 'Ir ao item 8',
  jump9: 'Ir ao item 9',
};

export function actionLabels() {
  return { ...ACTION_LABELS };
}

/** Parse "Ctrl+Shift+KeyF" → { ctrl, shift, alt, code } */
export function parseChord(chord) {
  const parts = String(chord || '').split('+').map((p) => p.trim()).filter(Boolean);
  const out = { ctrl: false, shift: false, alt: false, meta: false, code: '' };
  for (const p of parts) {
    const low = p.toLowerCase();
    if (low === 'ctrl' || low === 'control') out.ctrl = true;
    else if (low === 'shift') out.shift = true;
    else if (low === 'alt') out.alt = true;
    else if (low === 'meta' || low === 'cmd' || low === 'command') out.meta = true;
    else out.code = p;
  }
  return out;
}

export function formatChord({ ctrl, shift, alt, meta, code }) {
  const parts = [];
  if (ctrl) parts.push('Ctrl');
  if (meta) parts.push('Meta');
  if (alt) parts.push('Alt');
  if (shift) parts.push('Shift');
  if (code) parts.push(code);
  return parts.join('+');
}

export function eventMatchesChord(event, chord) {
  const p = parseChord(chord);
  if (!p.code) return false;
  const ctrlOrMeta = !!(event.ctrlKey || event.metaKey);
  if (p.ctrl || p.meta) {
    if (!ctrlOrMeta) return false;
  } else if (ctrlOrMeta && p.code !== 'Escape') {
    // plain bindings shouldn't fire with modifiers (except Escape)
    if (event.ctrlKey || event.metaKey) return false;
  }
  if (!!p.shift !== !!event.shiftKey) return false;
  if (!!p.alt !== !!event.altKey) return false;
  return event.code === p.code;
}

/**
 * Resolve final map: defaults ← fileDefaults ← prefs.shortcuts
 */
export function resolveShortcuts(prefs = {}, fileDefaults = null) {
  const base = {
    version: 1,
    bindings: {
      ...DEFAULT_SHORTCUTS.bindings,
      ...(fileDefaults?.bindings || {}),
    },
  };
  const overrides = prefs?.shortcuts?.bindings || prefs?.shortcuts || {};
  if (overrides && typeof overrides === 'object' && !Array.isArray(overrides)) {
    // support both { bindings: {} } and flat { next: 'KeyX' }
    const flat = overrides.bindings && typeof overrides.bindings === 'object'
      ? overrides.bindings
      : overrides;
    for (const [k, v] of Object.entries(flat)) {
      if (typeof v === 'string' && v.trim()) base.bindings[k] = v.trim();
    }
  }
  return base;
}

export function findShortcutConflicts(bindings) {
  const byChord = new Map();
  const conflicts = [];
  for (const [action, chord] of Object.entries(bindings || {})) {
    const key = String(chord);
    if (!byChord.has(key)) byChord.set(key, []);
    byChord.get(key).push(action);
  }
  for (const [chord, actions] of byChord) {
    if (actions.length > 1) conflicts.push({ chord, actions });
  }
  return conflicts;
}

export function exportShortcuts(map) {
  return JSON.stringify({
    version: map?.version || 1,
    bindings: { ...(map?.bindings || DEFAULT_SHORTCUTS.bindings) },
  }, null, 2);
}

export function importShortcuts(raw) {
  let parsed = raw;
  if (typeof raw === 'string') parsed = JSON.parse(raw);
  if (!parsed || typeof parsed !== 'object') throw new Error('JSON inválido');
  const bindings = parsed.bindings && typeof parsed.bindings === 'object'
    ? parsed.bindings
    : parsed;
  const cleaned = {};
  for (const [k, v] of Object.entries(bindings)) {
    if (typeof v === 'string' && v.trim() && DEFAULT_SHORTCUTS.bindings[k] !== undefined) {
      cleaned[k] = v.trim();
    }
  }
  return { version: Number(parsed.version) || 1, bindings: cleaned };
}

export async function loadShortcutDefaultsFromDisk() {
  try {
    const res = await fetch(dataPublicUrl('shortcuts.json'), { cache: 'no-store' });
    if (!res.ok) return null;
    return await res.json();
  } catch {
    return null;
  }
}
