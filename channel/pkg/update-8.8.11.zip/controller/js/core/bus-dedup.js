/** Dedup puro para ProjectionBus / SyncHub (unit-testable). */
export const DEDUP_WINDOW_MS = 2000;

export function isDuplicateMessage(id, processedIds, now = Date.now(), windowMs = DEDUP_WINDOW_MS) {
  if (!id) return false;
  for (const [key, ts] of processedIds) {
    if (now - ts > windowMs) processedIds.delete(key);
  }
  if (processedIds.has(id)) return true;
  processedIds.set(id, now);
  return false;
}
