/**
 * Boot loader - aguarda ping e carrega scripts/modulos.
 * Versão via window.__SOMOSUM_META__ (AssetRegistry / boot-asset-loader).
 */
(function () {
  'use strict';

  var meta = window.__SOMOSUM_META__ || {};
  var VERSION = meta.assetRevision || meta.version || '8.8.2';
  var AUTHOR = 'Reinan Rodrigues';
  var MAX_WAIT_MS = 120000;

  if (location.protocol === 'file:') return;

  var tag = document.currentScript;
  var skipPing = tag && tag.getAttribute('data-skip-ping') === '1';
  var modules = (tag && tag.getAttribute('data-modules') || '')
    .split(',').map(function (s) { return s.trim(); }).filter(Boolean);
  var scripts = (tag && tag.getAttribute('data-scripts') || '')
    .split(',').map(function (s) { return s.trim(); }).filter(Boolean);

  var overlay = null;
  var start = Date.now();

  window.SOMOSUM_VERSION = meta.version || VERSION;
  window.SOMOSUM_AUTHOR = AUTHOR;

  function showOverlay(msg) {
    if (!overlay) {
      overlay = document.createElement('div');
      overlay.id = 'somosum-boot-overlay';
      overlay.style.cssText = 'position:fixed;inset:0;z-index:999999;display:flex;align-items:center;justify-content:center;background:rgba(0,0,0,.93);color:#d4c68d;font-family:Segoe UI,sans-serif;text-align:center;padding:2rem';
      overlay.innerHTML = '<div style="max-width:460px"><p style="letter-spacing:.12em;font-size:.78rem;color:#888;margin:0 0 .6rem">SOMOSUM v' + window.SOMOSUM_VERSION + '</p><h2 style="margin:0 0 .65rem;font-size:1.25rem">Conectando...</h2><p style="color:#aaa;line-height:1.55;margin:0 0 1rem" id="somosum-boot-msg"></p><div style="width:44px;height:44px;border:3px solid rgba(212,198,141,.2);border-top-color:#d4c68d;border-radius:50%;margin:0 auto .85rem;animation:somosumSpin .75s linear infinite"></div><button type="button" id="somosum-boot-retry" style="background:#d4c68d;color:#111;border:none;padding:.6rem 1.2rem;border-radius:6px;cursor:pointer;font-size:.92rem">Tentar agora</button></div><style>@keyframes somosumSpin{to{transform:rotate(360deg)}}</style>';
      document.body.appendChild(overlay);
      overlay.querySelector('#somosum-boot-retry').addEventListener('click', function () { location.reload(); });
    }
    overlay.style.display = 'flex';
    var m = overlay.querySelector('#somosum-boot-msg');
    if (m && msg) m.textContent = msg;
  }

  function hideOverlay() {
    if (overlay) overlay.style.display = 'none';
  }

  function sleep(ms) {
    return new Promise(function (resolve) { setTimeout(resolve, ms); });
  }

  function ping() {
    var ctrl = typeof AbortController !== 'undefined' ? new AbortController() : null;
    var timer = ctrl ? setTimeout(function () { ctrl.abort(); }, 2500) : null;
    return fetch('/api/ping', { cache: 'no-store', signal: ctrl ? ctrl.signal : undefined })
      .then(function (r) { if (timer) clearTimeout(timer); return r.ok; })
      .catch(function () { if (timer) clearTimeout(timer); return false; });
  }

  function waitForServer() {
    return new Promise(function (resolve, reject) {
      (async function () {
        var attempt = 0;
        if (await ping()) {
          window.__somosumServerReady = true;
          window.dispatchEvent(new Event('somosum-server-ready'));
          resolve();
          return;
        }
        showOverlay('Aguardando servidor local - verifique SOMOSUM.exe na bandeja.');
        while (!(await ping())) {
          if (Date.now() - start > MAX_WAIT_MS) {
            showOverlay('Servidor não respondeu. Abra SOMOSUM.exe e clique em Tentar agora.');
            reject(new Error('timeout'));
            return;
          }
          await sleep(Math.min(120 + attempt * 80, 700));
          attempt++;
        }
        window.__somosumServerReady = true;
        window.dispatchEvent(new Event('somosum-server-ready'));
        resolve();
      })();
    });
  }

  function resolveAssetPath(src) {
    if (!src) return src;
    var clean = String(src).split('?')[0];
    if (/^https?:\/\//i.test(clean) || clean.charAt(0) === '/') return clean;
    return '/' + clean.replace(/^\.\//, '');
  }

  function versionedUrl(src) {
    var path = resolveAssetPath(src);
    var base = path.split('?')[0];
    return base + '?v=' + encodeURIComponent(VERSION);
  }

  function loadScript(src) {
    return new Promise(function (resolve, reject) {
      var s = document.createElement('script');
      s.src = versionedUrl(src);
      s.onload = function () { resolve(); };
      s.onerror = function () { reject(new Error('script:' + src)); };
      document.head.appendChild(s);
    });
  }

  function loadModule(src) {
    return new Promise(function (resolve, reject) {
      var s = document.createElement('script');
      s.type = 'module';
      s.src = versionedUrl(src);
      s.onload = function () { resolve(); };
      s.onerror = function () { reject(new Error('module:' + src)); };
      document.body.appendChild(s);
    });
  }

  function loadAssets() {
    return (async function () {
      try {
        for (var i = 0; i < scripts.length; i++) {
          await loadScript(scripts[i]);
        }
        for (var j = 0; j < modules.length; j++) {
          await loadModule(modules[j]);
        }
        hideOverlay();
      } catch (err) {
        var detail = (err && err.message) ? err.message : String(err);
        showOverlay('Falha ao carregar: ' + detail + ' - Ctrl+F5 ou Tentar agora.');
        console.error('[SOMOSUM boot]', err);
      }
    })();
  }

  window.SOMOSUM_BOOT = {
    version: VERSION,
    waitForServer: waitForServer,
    loadAssets: loadAssets,
  };

  if (skipPing || window.__somosumServerReady) {
    loadAssets();
  } else {
    waitForServer().then(loadAssets);
  }
})();
