/**
 * Escala global de UI para Windows 100%–200% (PerMonitorV2).
 * Não altera ZoomFactor do WebView2 — só CSS custom properties.
 *
 * Preferências do usuário (Ajustes → Escala) têm prioridade sobre DPI automático.
 * Em notebooks com DPI alto, o auto-scale é limitado para não comprimir o Controle.
 */

function detectUiScale() {
  const dpr = window.devicePixelRatio || 1;
  // Cap: 1.25 — evita inspetor/toolbar ilegíveis em 125–200% Windows
  if (dpr >= 1.9) return 1.25;
  if (dpr >= 1.45) return 1.15;
  if (dpr >= 1.2) return 1.1;
  return 1;
}

function applyUiScale(scale) {
  const root = document.documentElement;
  const clamped = Math.min(1.4, Math.max(0.85, Number(scale) || 1));
  root.style.setProperty('--ui-scale', String(clamped));
  root.dataset.uiScale = String(clamped);
}

/** Preferência do usuário bloqueia sobrescrita por resize/DPI. */
export function lockUiScaleFromUser() {
  document.documentElement.dataset.uiScaleUser = '1';
}

export function initUiScale(nativeDpi = null) {
  const apply = () => {
    if (document.documentElement.dataset.uiScaleUser === '1') return;
    let scale = detectUiScale();
    if (nativeDpi && nativeDpi > 96) {
      const fromNative = Math.min(1.25, Math.round((nativeDpi / 96) * 100) / 100);
      scale = Math.max(scale, fromNative >= 1.2 ? Math.min(1.25, fromNative) : 1);
    }
    applyUiScale(scale);
  };
  apply();
  window.addEventListener('resize', apply, { passive: true });
  try {
    const dpiRaw = window.Engine?.shell?.getSystemDpi?.();
    const dpi = parseFloat(dpiRaw);
    if (Number.isFinite(dpi) && document.documentElement.dataset.uiScaleUser !== '1') {
      applyUiScale(Math.min(1.25, Math.max(detectUiScale(), dpi / 96)));
    }
  } catch { /* ignore */ }
  return apply;
}
