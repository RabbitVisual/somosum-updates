export const DEFAULT_AMBIENT = {
  trackPath: null,
  volume: 0.3,
  playing: false,
  loop: true,
  autoWithCountdown: true,
};

export function normalizeAmbientState(raw = {}) {
  const volume = Number(raw.volume);
  return {
    trackPath: raw.trackPath || null,
    volume: Number.isFinite(volume) ? Math.min(1, Math.max(0, volume)) : DEFAULT_AMBIENT.volume,
    playing: !!raw.playing,
    loop: raw.loop !== false,
    autoWithCountdown: raw.autoWithCountdown !== false,
  };
}

export function getAmbientFromPrefs(prefs = {}) {
  return normalizeAmbientState({ ...DEFAULT_AMBIENT, ...(prefs.ambient || {}) });
}

/** Codifica caminhos locais (espaços, acentos) para o elemento audio. */
export function encodeAudioPath(path) {
  if (!path) return '';
  if (/^https?:\/\//i.test(path)) return path;
  return path
    .split('/')
    .map((seg, i) => (i === 0 ? seg : encodeURIComponent(seg)))
    .join('/');
}

function normalizeTrackList(data) {
  if (Array.isArray(data)) return data;
  if (data && typeof data === 'object' && (data.path || data.fileName)) return [data];
  return [];
}

export async function loadAmbientTracks() {
  try {
    const res = await fetch(`/api/ambient-audio?t=${Date.now()}`, { cache: 'no-store' });
    if (!res.ok) return [];
    const raw = await res.json();
    return normalizeTrackList(raw).filter((t) => t.path && t.fileName);
  } catch {
    return [];
  }
}
