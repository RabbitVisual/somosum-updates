import { bootstrapStorage } from './storage/index.js';

let bootPromise = null;

export function initStoragePlatform() {
  if (!bootPromise) bootPromise = bootstrapStorage();
  return bootPromise;
}
