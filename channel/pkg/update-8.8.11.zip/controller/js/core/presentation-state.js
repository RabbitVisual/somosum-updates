/**
 * Presentation State — commit atômico por revision (Projetor.md Fases 4–6).
 */
import { lyricsBackgroundKey } from '../slides/templates.js';

export function buildPresentationState({
  slide,
  programState = {},
  prefs = null,
  theme = null,
  revision = 0,
} = {}) {
  const bgKey = slide ? lyricsBackgroundKey(slide) : null;
  return {
    revision: Number(revision) || 0,
    activeSlide: slide || null,
    theme: theme || null,
    backgroundKey: bgKey,
    overlay: programState.overlay || null,
    currentIndex: programState.currentIndex ?? null,
    styleFingerprint: slideStyleFingerprint(slide, prefs),
  };
}

export function slideStyleFingerprint(slide, prefs = null) {
  if (!slide) return '';
  const style = slide.style || {};
  const lyrics = slide.lyricsStyle || prefs?.globalLyricsStyle || {};
  return [
    slide.type,
    style.fontSize,
    style.titleSize,
    style.textSize,
    style.refSize,
    style.mottoSize,
    style.preacherSize,
    style.fromSize,
    style.photoSize,
    style.nameSize,
    style.fontFamily,
    style.fontWeight,
    style.fontStyle,
    style.textTransform,
    style.align,
    style.vAlign,
    style.lineHeight,
    style.marginTop,
    style.marginBottom,
    style.marginLeft,
    style.marginRight,
    style.titleColor,
    style.textColor,
    style.refColor,
    style.textEffect,
    style.bgDim,
    style.contentWidth,
    style.cardWidth,
    lyrics.fontSize,
    lyrics.fontFamily,
    lyrics.fontWeight,
    lyrics.fontStyle,
    lyrics.lineHeight,
    lyrics.textTransform,
    lyrics.marginTop,
    lyrics.marginBottom,
    lyrics.marginLeft,
    lyrics.marginRight,
    lyrics.align,
    slide.lyricsFx?.ambient,
  ].map((v) => String(v ?? '')).join('|');
}

/**
 * Diff mínimo entre estados — screen decide patch vs remount.
 */
export function diffPresentationState(prev, next) {
  if (!prev) return { full: true, reason: 'no-prev' };
  if (!next) return { full: true, reason: 'no-next' };
  if ((next.revision || 0) < (prev.revision || 0)) {
    return { full: false, stale: true, reason: 'stale-revision' };
  }
  const sameBg = prev.backgroundKey && prev.backgroundKey === next.backgroundKey;
  const sameType = prev.activeSlide?.type === next.activeSlide?.type;
  const sameStyle = prev.styleFingerprint === next.styleFingerprint;
  const onlyOverlay = prev.activeSlide?.id === next.activeSlide?.id
    && prev.backgroundKey === next.backgroundKey
    && prev.overlay !== next.overlay;
  const onlyLines = sameBg && sameType && sameStyle
    && prev.activeSlide?.type === 'lyrics'
    && next.activeSlide?.type === 'lyrics'
    && prev.activeSlide?.lines?.join('|') !== next.activeSlide?.lines?.join('|');
  const onlyStyle = sameBg && sameType && !sameStyle
    && prev.activeSlide?.id === next.activeSlide?.id;

  return {
    full: !(onlyOverlay || onlyLines || onlyStyle),
    sameBg,
    onlyOverlay,
    onlyLines,
    onlyStyle,
    stale: false,
  };
}
