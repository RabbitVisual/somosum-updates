/**
 * Templates built-in — Song, Bible, Preview shell, Stage, Remote, Settings snippets.
 */
import { registerTemplate } from './template-registry.js';
import { html, esc, rawHtml } from './safe-html.js';

export function registerBuiltinTemplates() {
  registerTemplate('EmptyState', ({ title = 'Nada por aqui', message = '' } = {}) => html`
    <div class="su-empty">
      <h3 class="su-empty__title">${title}</h3>
      <p class="su-empty__message">${message}</p>
    </div>
  `);

  registerTemplate('Toast', ({ message = '', type = 'info' } = {}) => {
    const icon = type === 'success' ? '✓' : type === 'error' ? '✕' : type === 'warn' ? '!' : 'i';
    return html`
      <span class="su-toast__icon" aria-hidden="true">${icon}</span>
      <span class="su-toast__text">${message}</span>
    `;
  });

  registerTemplate('DialogShell', ({
    title = '', message = '', confirmLabel = 'Confirmar', cancelLabel = 'Cancelar', danger = false,
  } = {}) => html`
    <div class="su-dialog" role="dialog" aria-modal="true" aria-labelledby="su-dialog-title">
      <h3 class="su-dialog__title" id="su-dialog-title">${title}</h3>
      <p class="su-dialog__message">${message}</p>
      <div class="su-dialog__actions">
        <button type="button" class="su-btn su-btn--secondary" data-action="cancel">${cancelLabel}</button>
        <button type="button" class="su-btn ${danger ? 'su-btn--danger' : 'su-btn--primary'}" data-action="confirm">${confirmLabel}</button>
      </div>
    </div>
  `);

  registerTemplate('SongTitle', ({ title = '', artist = '' } = {}) => html`
    <div class="song-title-block">
      <strong class="song-title">${title}</strong>
      ${artist ? html`<span class="song-artist">${artist}</span>` : rawHtml('')}
    </div>
  `);

  registerTemplate('BibleRef', ({ reference = '', version = '' } = {}) => html`
    <div class="bible-ref">
      <span class="bible-ref__text">${reference}</span>
      ${version ? html`<span class="bible-ref__ver">${version}</span>` : rawHtml('')}
    </div>
  `);

  registerTemplate('PreviewShell', ({ body = '' } = {}) => {
    // body já deve ser SafeHtmlString / trusted do slide-engine
    return html`<div class="preview-scaler" id="preview-scaler">${typeof body === 'object' && body?.toString ? rawHtml(body.toString()) : rawHtml(String(body || ''))}</div>`;
  });

  registerTemplate('StageAlert', ({ text = '', kind = 'note' } = {}) => html`
    <div class="stage-alert stage-alert--${kind}" role="status">
      <p class="stage-alert__text">${text}</p>
    </div>
  `);

  registerTemplate('RemoteStatus', ({ label = '', online = false } = {}) => html`
    <div class="remote-status ${online ? 'is-online' : 'is-offline'}">
      <span class="remote-status__dot" aria-hidden="true"></span>
      <span class="remote-status__label">${label}</span>
    </div>
  `);

  registerTemplate('RemoteBanner', ({ kind = '', text = '' } = {}) => html`
    <div class="remote-alert-banner">
      <span class="remote-alert-kind">${kind}</span>
      <span class="remote-alert-text">${text}</span>
    </div>
  `);

  registerTemplate('InspectorSticky', ({ actions = '' } = {}) => html`
    <div class="insp-sticky-actions">${typeof actions === 'object' && actions?.toString ? rawHtml(actions.toString()) : rawHtml(String(actions || ''))}</div>
  `);

  registerTemplate('SettingsRow', ({ label = '', value = '' } = {}) => html`
    <div class="settings-row">
      <dt>${label}</dt>
      <dd>${value}</dd>
    </div>
  `);

  // Inspector field label
  registerTemplate('InspectorLabel', ({ text = '', forId = '' } = {}) => html`
    <label class="insp-label" ${forId ? rawHtml(`for="${esc(forId)}"`) : rawHtml('')}>${text}</label>
  `);

  registerTemplate('MediaThumbLabel', ({ name = '', kind = '' } = {}) => html`
    <div class="media-thumb-label">
      <span class="media-thumb-name">${name}</span>
      ${kind ? html`<span class="media-thumb-kind">${kind}</span>` : rawHtml('')}
    </div>
  `);
}
