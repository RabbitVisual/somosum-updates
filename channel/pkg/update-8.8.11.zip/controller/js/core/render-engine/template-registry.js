/**
 * Template Registry — registro central de templates nomeados.
 */
import { html as safeHtmlTag, SafeHtmlString } from './safe-html.js';
import { TemplateCache } from './template-cache.js';

const registry = new Map();

/**
 * @param {string} name
 * @param {(data: object) => SafeHtmlString|string|Node} renderFn
 * @param {{ cache?: boolean }} [opts]
 */
export function registerTemplate(name, renderFn, opts = {}) {
  if (!name || typeof renderFn !== 'function') {
    throw new Error(`registerTemplate: invalid ${name}`);
  }
  registry.set(name, { renderFn, cache: opts.cache !== false });
  return name;
}

export function hasTemplate(name) {
  return registry.has(name);
}

export function listTemplates() {
  return [...registry.keys()];
}

/**
 * Renderiza template registrado.
 * @returns {SafeHtmlString|string|Node}
 */
export function renderTemplate(name, data = {}) {
  const entry = registry.get(name);
  if (!entry) throw new Error(`Template não registrado: ${name}`);

  if (entry.cache) {
    const key = TemplateCache.key(name, data);
    const hit = TemplateCache.get(key);
    if (hit != null) return hit;
    const out = entry.renderFn(data);
    TemplateCache.set(key, out);
    return out;
  }
  return entry.renderFn(data);
}

/** Helper para templates string-based seguros. */
export function defineHtmlTemplate(name, stringsFn) {
  return registerTemplate(name, (data) => {
    const result = stringsFn(data, safeHtmlTag);
    return result instanceof SafeHtmlString ? result : safeHtmlTag`${result}`;
  });
}

export const TemplateRegistry = {
  register: registerTemplate,
  has: hasTemplate,
  list: listTemplates,
  render: renderTemplate,
  defineHtml: defineHtmlTemplate,
};

export default TemplateRegistry;
