/**
 * Render Queue — fila única de commits (RAF + batch).
 * Integra com RenderScheduler existente quando disponível.
 */
import { RenderProfiler } from './render-profiler.js';

const PRIORITY = { critical: 0, live: 1, normal: 2, idle: 3 };

const pending = new Map();
let rafId = 0;
let flushing = false;

function scheduleRaf() {
  if (rafId || flushing) return;
  rafId = requestAnimationFrame(() => {
    rafId = 0;
    flush();
  });
}

function flush() {
  if (!pending.size) return;
  flushing = true;
  const t0 = performance.now();
  const jobs = [...pending.entries()].sort(
    (a, b) => (PRIORITY[a[1].priority] ?? 2) - (PRIORITY[b[1].priority] ?? 2),
  );
  pending.clear();
  let ran = 0;
  let coalesced = 0;
  for (const [, job] of jobs) {
    try {
      if (job.coalesced) coalesced += 1;
      job.fn();
      ran += 1;
    } catch (err) {
      console.error('[RenderEngine.queue]', err);
    }
  }
  flushing = false;
  RenderProfiler.recordBatch({ ran, coalesced, ms: performance.now() - t0 });
  if (pending.size) scheduleRaf();
}

/**
 * Agenda um render por chave (coalesce automático).
 */
export function enqueue(key, fn, { priority = 'normal' } = {}) {
  if (typeof fn !== 'function') return;
  const existing = pending.get(key);
  if (existing) {
    existing.fn = fn;
    existing.coalesced = true;
    if ((PRIORITY[priority] ?? 2) < (PRIORITY[existing.priority] ?? 2)) {
      existing.priority = priority;
    }
    RenderProfiler.recordDiscard('coalesce');
  } else {
    pending.set(key, { fn, priority, coalesced: false });
  }

  // Preferir RenderScheduler do produto quando existir
  try {
    const RS = typeof window !== 'undefined' && window.SOMOSUM_RENDER_SCHEDULER;
    if (RS?.enqueue) {
      RS.enqueue(key, fn, priority);
      return;
    }
  } catch { /* */ }

  scheduleRaf();
}

/** Microtask para updates síncronos leves (após paint atual). */
export function enqueueMicro(key, fn) {
  if (typeof fn !== 'function') return;
  queueMicrotask(() => {
    try { fn(); } catch (err) { console.error('[RenderEngine.micro]', err); }
  });
}

export function flushSync() {
  if (rafId) {
    cancelAnimationFrame(rafId);
    rafId = 0;
  }
  flush();
}

export function pendingCount() {
  return pending.size;
}

export const RenderQueue = {
  enqueue,
  enqueueMicro,
  flushSync,
  pendingCount,
};

export default RenderQueue;
