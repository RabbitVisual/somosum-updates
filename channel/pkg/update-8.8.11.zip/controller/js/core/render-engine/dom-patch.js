/**
 * DOM Patch — atualização incremental preservando foco, scroll e mídia.
 */
import { setText, html, attrs } from './safe-dom.js';
import { SafeHtmlString } from './safe-html.js';
import { RenderProfiler } from './render-profiler.js';

const MEDIA_TAGS = new Set(['VIDEO', 'AUDIO', 'CANVAS', 'IFRAME']);

function sameTag(a, b) {
  return a?.nodeType === b?.nodeType
    && (a.nodeType !== Node.ELEMENT_NODE || a.tagName === b.tagName);
}

function isMedia(el) {
  return el?.nodeType === Node.ELEMENT_NODE && MEDIA_TAGS.has(el.tagName);
}

function snapshotMedia(el) {
  if (!isMedia(el)) return null;
  if (el.tagName === 'VIDEO' || el.tagName === 'AUDIO') {
    return {
      currentTime: el.currentTime,
      paused: el.paused,
      muted: el.muted,
      volume: el.volume,
      src: el.currentSrc || el.src,
    };
  }
  return { tag: el.tagName };
}

function restoreMedia(el, snap) {
  if (!snap || !isMedia(el)) return;
  if (el.tagName === 'VIDEO' || el.tagName === 'AUDIO') {
    try {
      if (snap.muted != null) el.muted = snap.muted;
      if (snap.volume != null) el.volume = snap.volume;
      if (Number.isFinite(snap.currentTime)) el.currentTime = snap.currentTime;
      if (!snap.paused) {
        const p = el.play?.();
        if (p?.catch) p.catch(() => {});
      }
    } catch { /* */ }
  }
}

/**
 * Patch superficial: atualiza atributos/texto de um nó existente.
 * @returns {'patched'|'replaced'|'skipped'}
 */
export function patchElement(live, next, options = {}) {
  const { preserveMedia = true } = options;
  if (!live || !next) return 'skipped';

  if (live.nodeType === Node.TEXT_NODE && next.nodeType === Node.TEXT_NODE) {
    if (live.textContent !== next.textContent) {
      live.textContent = next.textContent;
      RenderProfiler.recordPatch('text');
    }
    return 'patched';
  }

  if (!sameTag(live, next)) {
    live.replaceWith(next);
    RenderProfiler.recordPatch('replaced');
    return 'replaced';
  }

  if (live.nodeType !== Node.ELEMENT_NODE) return 'skipped';

  const mediaSnap = preserveMedia ? snapshotMedia(live) : null;

  // Atributos
  const liveAttrs = new Set([...live.attributes].map((a) => a.name));
  const nextAttrs = [...next.attributes];
  for (const a of nextAttrs) {
    if (live.getAttribute(a.name) !== a.value) {
      live.setAttribute(a.name, a.value);
      RenderProfiler.recordPatch('attr');
    }
    liveAttrs.delete(a.name);
  }
  for (const name of liveAttrs) {
    if (name === 'style' && mediaSnap) continue;
    live.removeAttribute(name);
    RenderProfiler.recordPatch('attr-remove');
  }

  // Filhos
  patchChildren(live, next, options);

  if (mediaSnap) restoreMedia(live, mediaSnap);
  return 'patched';
}

export function patchChildren(parent, nextParent, options = {}) {
  const liveKids = [...parent.childNodes];
  const nextKids = [...nextParent.childNodes];
  const max = Math.max(liveKids.length, nextKids.length);

  for (let i = 0; i < max; i++) {
    const live = liveKids[i];
    const next = nextKids[i];
    if (!next && live) {
      live.remove();
      RenderProfiler.recordPatch('remove');
      continue;
    }
    if (next && !live) {
      parent.appendChild(next.cloneNode(true));
      RenderProfiler.recordPatch('append');
      continue;
    }
    if (isMedia(live) && isMedia(next) && live.tagName === next.tagName) {
      // Preserva nó de mídia; só sincroniza attrs não-destrutivos
      const snap = snapshotMedia(live);
      for (const a of [...next.attributes]) {
        if (a.name === 'src' && live.getAttribute('src') === a.value) continue;
        if (live.getAttribute(a.name) !== a.value) live.setAttribute(a.name, a.value);
      }
      restoreMedia(live, snap);
      RenderProfiler.recordPatch('media-preserve');
      continue;
    }
    patchElement(live, next, options);
  }
}

/**
 * Atualiza host com HTML/Node de forma incremental quando possível.
 */
export function patchHost(host, content, options = {}) {
  if (!host) return;
  const t0 = performance.now();
  const scrollTop = host.scrollTop;
  const scrollLeft = host.scrollLeft;
  const activeId = document.activeElement?.id;

  let nextRoot;
  if (content instanceof Node) {
    nextRoot = content;
  } else if (content instanceof SafeHtmlString || typeof content === 'string') {
    const wrap = document.createElement('div');
    html(wrap, content, { sanitize: options.sanitize !== false && !(content instanceof SafeHtmlString) });
    nextRoot = wrap;
  } else {
    return;
  }

  // Se host vazio ou full replace forçado
  if (options.full || !host.childNodes.length) {
    while (host.firstChild) host.removeChild(host.firstChild);
    while (nextRoot.firstChild) host.appendChild(nextRoot.firstChild);
    RenderProfiler.recordPatch('full');
  } else {
    const probe = document.createElement(host.tagName);
    while (nextRoot.firstChild) probe.appendChild(nextRoot.firstChild);
    patchChildren(host, probe, options);
  }

  host.scrollTop = scrollTop;
  host.scrollLeft = scrollLeft;
  if (activeId) {
    const el = document.getElementById(activeId);
    if (el?.focus) {
      try { el.focus({ preventScroll: true }); } catch { /* */ }
    }
  }
  RenderProfiler.recordTiming('patchHost', performance.now() - t0);
}

/** Atualiza só texto de um seletor (zero HTML). */
export function patchText(root, selector, value) {
  const el = typeof selector === 'string' ? root?.querySelector?.(selector) : selector;
  if (!el) return false;
  setText(el, value);
  RenderProfiler.recordPatch('text-sel');
  return true;
}

/** Atualiza attrs de um seletor. */
export function patchAttrs(root, selector, map) {
  const el = typeof selector === 'string' ? root?.querySelector?.(selector) : selector;
  if (!el) return false;
  attrs(el, map);
  RenderProfiler.recordPatch('attrs-sel');
  return true;
}

export default {
  patchElement,
  patchChildren,
  patchHost,
  patchText,
  patchAttrs,
};
