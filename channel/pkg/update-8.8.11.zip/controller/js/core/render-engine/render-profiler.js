/**
 * Render Profiler — métricas internas (Diagnóstico / DevTools).
 */
const state = {
  writes: 0,
  patches: Object.create(null),
  timings: [],
  batches: [],
  discards: 0,
  cacheHits: 0,
  cacheMisses: 0,
  enabled: false,
};

const MAX_TIMINGS = 200;

function isEnabled() {
  if (state.enabled) return true;
  try {
    return typeof localStorage !== 'undefined'
      && localStorage.getItem('somosum.render.profiler') === '1';
  } catch {
    return false;
  }
}

export const RenderProfiler = {
  enable(on = true) {
    state.enabled = !!on;
    try {
      localStorage.setItem('somosum.render.profiler', on ? '1' : '0');
    } catch { /* */ }
  },

  isEnabled,

  recordWrite(kind = 'html') {
    if (!isEnabled()) return;
    state.writes += 1;
    state.patches[kind] = (state.patches[kind] || 0) + 1;
  },

  recordPatch(kind = 'patch') {
    if (!isEnabled()) return;
    state.patches[kind] = (state.patches[kind] || 0) + 1;
  },

  recordTiming(label, ms) {
    if (!isEnabled()) return;
    state.timings.push({ label, ms, ts: Date.now() });
    if (state.timings.length > MAX_TIMINGS) state.timings.shift();
  },

  recordBatch({ ran, coalesced, ms }) {
    if (!isEnabled()) return;
    state.batches.push({ ran, coalesced, ms, ts: Date.now() });
    if (state.batches.length > MAX_TIMINGS) state.batches.shift();
  },

  recordDiscard(reason = 'coalesce') {
    if (!isEnabled()) return;
    state.discards += 1;
    state.patches[`discard:${reason}`] = (state.patches[`discard:${reason}`] || 0) + 1;
  },

  recordCache(hit) {
    if (!isEnabled()) return;
    if (hit) state.cacheHits += 1;
    else state.cacheMisses += 1;
  },

  snapshot() {
    const avg = state.timings.length
      ? state.timings.reduce((s, t) => s + t.ms, 0) / state.timings.length
      : 0;
    return {
      writes: state.writes,
      patches: { ...state.patches },
      discards: state.discards,
      cacheHits: state.cacheHits,
      cacheMisses: state.cacheMisses,
      avgTimingMs: Math.round(avg * 100) / 100,
      recentTimings: state.timings.slice(-20),
      recentBatches: state.batches.slice(-20),
      enabled: isEnabled(),
    };
  },

  reset() {
    state.writes = 0;
    state.patches = Object.create(null);
    state.timings = [];
    state.batches = [];
    state.discards = 0;
    state.cacheHits = 0;
    state.cacheMisses = 0;
  },

  /** HTML seguro para painel de diagnóstico. */
  toReportHtml() {
    const s = this.snapshot();
    const rows = Object.entries(s.patches)
      .map(([k, v]) => `<tr><td>${k}</td><td>${v}</td></tr>`)
      .join('');
    return `
      <div class="render-profiler-report">
        <p>Writes: <strong>${s.writes}</strong> · Discards: <strong>${s.discards}</strong></p>
        <p>Cache: ${s.cacheHits} hits / ${s.cacheMisses} misses · Avg: ${s.avgTimingMs} ms</p>
        <table><thead><tr><th>Patch</th><th>Count</th></tr></thead><tbody>${rows || '<tr><td colspan="2">—</td></tr>'}</tbody></table>
      </div>`;
  },
};

if (typeof window !== 'undefined') {
  window.SOMOSUM_RENDER_PROFILER = RenderProfiler;
}

export default RenderProfiler;
