/**
 * Template Cache — reutiliza resultados de templates por chave.
 */
import { RenderProfiler } from './render-profiler.js';

const MAX = 128;
const store = new Map();

function stableStringify(obj) {
  if (obj == null) return 'null';
  if (typeof obj !== 'object') return JSON.stringify(obj);
  if (Array.isArray(obj)) return `[${obj.map(stableStringify).join(',')}]`;
  const keys = Object.keys(obj).sort();
  return `{${keys.map((k) => `${JSON.stringify(k)}:${stableStringify(obj[k])}`).join(',')}}`;
}

export function key(name, data) {
  try {
    return `${name}::${stableStringify(data)}`;
  } catch {
    return `${name}::${String(data)}`;
  }
}

export function get(cacheKey) {
  if (!store.has(cacheKey)) {
    RenderProfiler.recordCache(false);
    return null;
  }
  // LRU: reinserir
  const val = store.get(cacheKey);
  store.delete(cacheKey);
  store.set(cacheKey, val);
  RenderProfiler.recordCache(true);
  return val;
}

export function set(cacheKey, value) {
  if (store.has(cacheKey)) store.delete(cacheKey);
  store.set(cacheKey, value);
  while (store.size > MAX) {
    const first = store.keys().next().value;
    store.delete(first);
  }
}

export function clear(prefix) {
  if (!prefix) {
    store.clear();
    return;
  }
  for (const k of [...store.keys()]) {
    if (k.startsWith(prefix)) store.delete(k);
  }
}

export function size() {
  return store.size;
}

export const TemplateCache = { key, get, set, clear, size };
export default TemplateCache;
