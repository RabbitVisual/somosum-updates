/**
 * SafeDOM — API única de manipulação de DOM (sem innerHTML direto no produto).
 * Apenas este módulo (e dom-patch) pode escrever HTML no DOM.
 */
import { escapeHtml, escapeAttr, SafeHtmlString, sanitizeHtml } from './safe-html.js';
import { RenderProfiler } from './render-profiler.js';

const INFRA_FLAG = '__SOMOSUM_SAFE_DOM__';

export function createElement(tag, props = {}, ...children) {
  const el = document.createElement(tag);
  applyProps(el, props);
  append(el, ...children);
  return el;
}

export function text(value) {
  return document.createTextNode(value == null ? '' : String(value));
}

/**
 * Define conteúdo HTML de forma controlada.
 * Aceita string (sanitizada), SafeHtmlString (trusted) ou Node.
 */
export function html(el, content, { sanitize = true } = {}) {
  if (!el) return el;
  RenderProfiler.recordWrite('html');
  clearChildren(el);
  if (content == null) return el;
  if (content instanceof Node) {
    el.appendChild(content);
    return el;
  }
  if (content instanceof SafeHtmlString) {
    el[INFRA_FLAG] = true;
    el.innerHTML = content.toString();
    return el;
  }
  const str = String(content);
  el[INFRA_FLAG] = true;
  el.innerHTML = sanitize ? sanitizeHtml(str) : escapeHtml(str);
  return el;
}

/** Atribui texto seguro (nunca interpreta HTML). */
export function setText(el, value) {
  if (!el) return el;
  el.textContent = value == null ? '' : String(value);
  return el;
}

export function attr(el, name, value) {
  if (!el) return el;
  if (value == null || value === false) {
    el.removeAttribute(name);
    return el;
  }
  if (value === true) {
    el.setAttribute(name, '');
    return el;
  }
  el.setAttribute(name, escapeAttr(value));
  return el;
}

export function attrs(el, map = {}) {
  Object.entries(map).forEach(([k, v]) => attr(el, k, v));
  return el;
}

export function append(parent, ...children) {
  if (!parent) return parent;
  const frag = fragment(...children);
  parent.appendChild(frag);
  return parent;
}

export function replace(oldNode, newNode) {
  if (!oldNode?.parentNode) return newNode;
  oldNode.parentNode.replaceChild(newNode, oldNode);
  return newNode;
}

export function clearChildren(el) {
  if (!el) return el;
  while (el.firstChild) el.removeChild(el.firstChild);
  return el;
}

export function fragment(...children) {
  const frag = document.createDocumentFragment();
  for (const child of children) {
    if (child == null || child === false) continue;
    if (Array.isArray(child)) {
      append(frag, ...child);
      continue;
    }
    if (child instanceof Node) {
      frag.appendChild(child);
      continue;
    }
    if (child instanceof SafeHtmlString) {
      const wrap = document.createElement('div');
      wrap[INFRA_FLAG] = true;
      wrap.innerHTML = child.toString();
      while (wrap.firstChild) frag.appendChild(wrap.firstChild);
      continue;
    }
    frag.appendChild(text(child));
  }
  return frag;
}

export function svg(tag, props = {}, ...children) {
  const el = document.createElementNS('http://www.w3.org/2000/svg', tag);
  Object.entries(props).forEach(([k, v]) => {
    if (v == null || v === false) return;
    el.setAttribute(k, v === true ? '' : String(v));
  });
  append(el, ...children);
  return el;
}

/** Ícone FA Duotone — estrutura segura. */
export function icon(name, { className = 'su-fa', duotone = true } = {}) {
  const i = createElement('i', {
    class: `${duotone ? 'fa-duotone' : 'fa-solid'} fa-${name} ${className}`.trim(),
    'aria-hidden': 'true',
  });
  return i;
}

export function image(src, { alt = '', className = '', width, height } = {}) {
  const img = createElement('img', { src, alt, class: className || undefined });
  if (width) img.width = width;
  if (height) img.height = height;
  return img;
}

function applyProps(el, props) {
  if (!props) return;
  Object.entries(props).forEach(([key, value]) => {
    if (value == null || value === false) return;
    if (key === 'class' || key === 'className') {
      el.className = String(value);
      return;
    }
    if (key === 'style' && typeof value === 'object') {
      Object.assign(el.style, value);
      return;
    }
    if (key === 'dataset' && typeof value === 'object') {
      Object.entries(value).forEach(([dk, dv]) => {
        if (dv != null) el.dataset[dk] = String(dv);
      });
      return;
    }
    if (key.startsWith('on') && typeof value === 'function') {
      el.addEventListener(key.slice(2).toLowerCase(), value);
      return;
    }
    if (key === 'textContent' || key === 'text') {
      el.textContent = String(value);
      return;
    }
    if (key === 'html' || key === 'innerHTML') {
      html(el, value);
      return;
    }
    attr(el, key, value);
  });
}

/** Monta árvore e substitui conteúdo do host sem flicker desnecessário. */
export function mount(host, node, { preserveFocus = true } = {}) {
  if (!host) return null;
  const active = preserveFocus ? document.activeElement : null;
  const activeId = active?.id;
  clearChildren(host);
  if (node) host.appendChild(node instanceof DocumentFragment ? node : fragment(node));
  if (preserveFocus && activeId) {
    const again = document.getElementById(activeId);
    if (again && typeof again.focus === 'function') {
      try { again.focus({ preventScroll: true }); } catch { /* */ }
    }
  }
  return host;
}

export default {
  createElement,
  text,
  html,
  setText,
  attr,
  attrs,
  append,
  replace,
  clearChildren,
  fragment,
  svg,
  icon,
  image,
  mount,
};
