/**
 * SafeHTML — única implementação oficial de escape HTML do SOMOSUM.
 * Todo conteúdo de usuário/JSON/sync/bíblia/louvor deve passar por aqui.
 */

const ENTITY_MAP = {
  '&': '&amp;',
  '<': '&lt;',
  '>': '&gt;',
  '"': '&quot;',
  "'": '&#39;',
};

const ENTITY_RE = /[&<>"']/g;

/** Escape para conteúdo de texto em HTML. */
export function escapeHtml(value) {
  if (value == null) return '';
  return String(value).replace(ENTITY_RE, (ch) => ENTITY_MAP[ch]);
}

/** Alias canônico curto (compat com esc()). */
export function esc(value) {
  return escapeHtml(value);
}

/** Escape para atributos HTML. */
export function escapeAttr(value) {
  return escapeHtml(value).replace(/`/g, '&#96;');
}

/** Alias canônico (compat com escAttr()). */
export function escAttr(value) {
  return escapeAttr(value);
}

/** @deprecated use escapeHtml */
export function htmlEscape(value) {
  return escapeHtml(value);
}

/** @deprecated use escapeHtml */
export function encodeHtml(value) {
  return escapeHtml(value);
}

/**
 * Sanitiza HTML permitindo apenas tags/atributos seguros (allowlist).
 * Não usa innerHTML do documento — parser em DOMParser.
 */
const ALLOWED_TAGS = new Set([
  'b', 'strong', 'i', 'em', 'u', 'br', 'span', 'p', 'div',
  'ul', 'ol', 'li', 'a', 'small', 'sub', 'sup', 'mark',
]);

const ALLOWED_ATTRS = new Set(['class', 'href', 'title', 'aria-hidden', 'role']);

export function sanitizeHtml(dirty, { allowTags = ALLOWED_TAGS, allowAttrs = ALLOWED_ATTRS } = {}) {
  if (dirty == null || dirty === '') return '';
  const str = String(dirty);
  if (!str.includes('<')) return escapeHtml(str);

  let doc;
  try {
    doc = new DOMParser().parseFromString(`<body>${str}</body>`, 'text/html');
  } catch {
    return escapeHtml(str);
  }

  const walk = (node, out) => {
    for (const child of [...node.childNodes]) {
      if (child.nodeType === Node.TEXT_NODE) {
        out.push(document.createTextNode(child.textContent || ''));
        continue;
      }
      if (child.nodeType !== Node.ELEMENT_NODE) continue;
      const tag = child.tagName.toLowerCase();
      if (!allowTags.has(tag)) {
        walk(child, out);
        continue;
      }
      const el = document.createElement(tag);
      for (const attr of [...child.attributes]) {
        const name = attr.name.toLowerCase();
        if (!allowAttrs.has(name)) continue;
        if (name === 'href') {
          const href = String(attr.value || '').trim();
          if (/^(https?:|mailto:|\/|#)/i.test(href) && !/^\s*javascript:/i.test(href)) {
            el.setAttribute('href', href);
          }
          continue;
        }
        el.setAttribute(name, attr.value);
      }
      const kids = [];
      walk(child, kids);
      kids.forEach((k) => el.appendChild(k));
      out.push(el);
    }
  };

  const body = doc.body || doc.documentElement;
  const nodes = [];
  walk(body, nodes);
  const wrap = document.createElement('div');
  nodes.forEach((n) => wrap.appendChild(n));
  return wrap.innerHTML;
}

/**
 * Constrói string HTML a partir de partes já escapadas ou valores brutos.
 * Valores passam por escapeHtml; TrustedHTML / SafeHtmlString passam crus.
 */
export class SafeHtmlString {
  constructor(html) {
    this._html = String(html ?? '');
  }
  toString() {
    return this._html;
  }
  valueOf() {
    return this._html;
  }
}

export function rawHtml(html) {
  return new SafeHtmlString(html);
}

export function html(strings, ...values) {
  let out = '';
  for (let i = 0; i < strings.length; i++) {
    out += strings[i];
    if (i < values.length) {
      const v = values[i];
      if (v instanceof SafeHtmlString) out += v.toString();
      else if (Array.isArray(v)) out += v.map((x) => (x instanceof SafeHtmlString ? x.toString() : escapeHtml(x))).join('');
      else out += escapeHtml(v);
    }
  }
  return new SafeHtmlString(out);
}

export default {
  escapeHtml,
  esc,
  escapeAttr,
  escAttr,
  htmlEscape,
  encodeHtml,
  sanitizeHtml,
  rawHtml,
  html,
  SafeHtmlString,
};
