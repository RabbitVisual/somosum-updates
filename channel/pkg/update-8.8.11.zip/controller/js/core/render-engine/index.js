﻿/**
 * SOMOSUM Render Engine — fachada pública.
 *
 * Uso:
 *   import { esc, escAttr, setHtml, rawHtml, patchHost, enqueue } from '../../core/render-engine/index.js';
 *
 * ATENÇÃO: `html` = tagged template (SafeHtmlString).
 *           `setHtml` = grava HTML no DOM (safe-dom).
 * Nunca faça `import { html as setHtml }` — isso pega o template tag e o painel fica vazio.
 */
export {
  escapeHtml, esc, escapeAttr, escAttr,
  htmlEscape, encodeHtml, sanitizeHtml,
  rawHtml, html, SafeHtmlString,
} from './safe-html.js';

export {
  createElement, text, html as setHtml, setText,
  attr, attrs, append, replace, clearChildren,
  fragment, svg, icon, image, mount,
} from './safe-dom.js';

export {
  patchElement, patchChildren, patchHost, patchText, patchAttrs,
} from './dom-patch.js';

export {
  enqueue, enqueueMicro, flushSync, pendingCount, RenderQueue,
} from './render-queue.js';

export {
  registerTemplate, hasTemplate, listTemplates, renderTemplate,
  defineHtmlTemplate, TemplateRegistry,
} from './template-registry.js';

export { TemplateCache } from './template-cache.js';

export {
  registerComponent, hasComponent, createComponent, listComponents,
  ComponentRegistry,
} from './component-registry.js';

export { RenderProfiler } from './render-profiler.js';

import { registerBuiltinTemplates } from './builtins.js';

let bootstrapped = false;

/** Inicializa templates/componentes built-in (idempotente). */
export function bootstrapRenderEngine() {
  if (bootstrapped) return;
  bootstrapped = true;
  registerBuiltinTemplates();
  if (typeof window !== 'undefined') {
    import('../render-scheduler.js').then(({ RenderScheduler }) => {
      window.SOMOSUM_RENDER_SCHEDULER = {
        enqueue(key, fn, priority = 'normal') {
          RenderScheduler.markDirty(key, { full: fn, priority });
        },
      };
    }).catch(() => { /* offline boot */ });
  }
}

if (typeof window !== 'undefined') {
  queueMicrotask(() => {
    try { bootstrapRenderEngine(); } catch { /* */ }
  });
}
