/**
 * Component Registry — componentes UI Kit reutilizáveis via SafeDOM.
 */
import {
  createElement, setText, append, icon as faIcon, html,
} from './safe-dom.js';
import { esc, rawHtml } from './safe-html.js';

const components = new Map();

export function registerComponent(name, factory) {
  if (!name || typeof factory !== 'function') {
    throw new Error(`registerComponent: invalid ${name}`);
  }
  components.set(name, factory);
  return name;
}

export function hasComponent(name) {
  return components.has(name);
}

export function createComponent(name, props = {}) {
  const factory = components.get(name);
  if (!factory) throw new Error(`Componente não registrado: ${name}`);
  return factory(props);
}

export function listComponents() {
  return [...components.keys()];
}

/* ─── Built-in UI Kit bridges ─── */

registerComponent('Button', ({
  label = '', variant = 'primary', type = 'button', className = '', onClick, attrs: extra = {},
} = {}) => {
  const btn = createElement('button', {
    type,
    class: `su-btn su-btn--${variant} ${className}`.trim(),
    ...extra,
  });
  setText(btn, label);
  if (onClick) btn.addEventListener('click', onClick);
  return btn;
});

registerComponent('Badge', ({ text = '', variant = 'soft', className = '' } = {}) => {
  const el = createElement('span', { class: `su-badge su-badge--${variant} ${className}`.trim() });
  setText(el, text);
  return el;
});

registerComponent('EmptyState', ({
  title = 'Nada por aqui', message = '', icon = 'inbox',
} = {}) => {
  const root = createElement('div', { class: 'su-empty' });
  append(root, faIcon(icon, { className: 'su-empty__icon su-fa' }));
  const h = createElement('h3', { class: 'su-empty__title' });
  setText(h, title);
  const p = createElement('p', { class: 'su-empty__message' });
  setText(p, message);
  append(root, h, p);
  return root;
});

registerComponent('Skeleton', ({ lines = 3, className = '' } = {}) => {
  const root = createElement('div', { class: `su-skeleton ${className}`.trim(), 'aria-hidden': 'true' });
  for (let i = 0; i < lines; i++) {
    append(root, createElement('div', { class: 'su-skeleton__line' }));
  }
  return root;
});

registerComponent('Toolbar', ({ className = '', children = [] } = {}) => {
  const bar = createElement('div', { class: `su-toolbar ${className}`.trim() });
  append(bar, ...children);
  return bar;
});

registerComponent('Card', ({ title = '', body = null, className = '' } = {}) => {
  const card = createElement('div', { class: `su-card ${className}`.trim() });
  if (title) {
    const h = createElement('h3', { class: 'su-card__title' });
    setText(h, title);
    append(card, h);
  }
  if (body) append(card, body);
  return card;
});

registerComponent('PreviewFrame', ({ className = '', content = null } = {}) => {
  const frame = createElement('div', { class: `su-preview-frame ${className}`.trim() });
  if (content) append(frame, content);
  return frame;
});

registerComponent('Dialog', ({
  title = '', message = '', confirmLabel = 'Confirmar', cancelLabel = 'Cancelar', danger = false, wide = false,
} = {}) => {
  const dialog = createElement('div', {
    class: `su-dialog${wide ? ' su-dialog--wide' : ''}`,
    role: 'dialog',
    'aria-modal': 'true',
    'aria-labelledby': 'su-dialog-title',
  });
  const titleEl = createElement('h3', { class: 'su-dialog__title', id: 'su-dialog-title' });
  setText(titleEl, title);
  const messageEl = createElement('p', { class: 'su-dialog__message' });
  setText(messageEl, message);
  const actions = createElement('div', { class: 'su-dialog__actions' });
  const cancelBtn = createElement('button', {
    type: 'button', class: 'su-btn su-btn--secondary', 'data-action': 'cancel',
  });
  setText(cancelBtn, cancelLabel);
  const confirmBtn = createElement('button', {
    type: 'button',
    class: `su-btn ${danger ? 'su-btn--danger' : 'su-btn--primary'}`,
    'data-action': 'confirm',
  });
  setText(confirmBtn, confirmLabel);
  append(actions, cancelBtn, confirmBtn);
  append(dialog, titleEl, messageEl, actions);
  return dialog;
});

registerComponent('Tabs', ({
  tabs = [], active = 0, className = '', onSelect,
} = {}) => {
  const root = createElement('div', { class: `su-tabs ${className}`.trim() });
  const bar = createElement('div', { class: 'su-tabs__bar', role: 'tablist' });
  const panels = createElement('div', { class: 'su-tabs__panels' });
  tabs.forEach((tab, i) => {
    const btn = createElement('button', {
      type: 'button',
      class: `su-tabs__tab${i === active ? ' is-active' : ''}`,
      role: 'tab',
      'aria-selected': i === active ? 'true' : 'false',
      'data-tab-idx': String(i),
    });
    setText(btn, tab.label || '');
    btn.addEventListener('click', () => onSelect?.(i, tab));
    append(bar, btn);
    const panel = createElement('div', {
      class: `su-tabs__panel${i === active ? ' is-active' : ''}`,
      role: 'tabpanel',
      hidden: i !== active ? '' : null,
    });
    if (tab.content) append(panel, tab.content);
    append(panels, panel);
  });
  append(root, bar, panels);
  return root;
});

registerComponent('PropertyGrid', ({ rows = [], className = '' } = {}) => {
  const grid = createElement('dl', { class: `su-property-grid ${className}`.trim() });
  rows.forEach(({ label = '', value = '' }) => {
    const dt = createElement('dt', { class: 'su-property-grid__label' });
    setText(dt, label);
    const dd = createElement('dd', { class: 'su-property-grid__value' });
    if (value instanceof Node) append(dd, value);
    else setText(dd, value);
    append(grid, dt, dd);
  });
  return grid;
});

/** Toast shell (texto seguro). */
registerComponent('Toast', ({ message = '', type = 'info' } = {}) => {
  const el = createElement('div', {
    class: `su-toast su-toast--${type}`,
    role: 'status',
  });
  const iconMap = { success: '✓', error: '✕', warn: '!', info: 'i' };
  const ic = createElement('span', { class: 'su-toast__icon', 'aria-hidden': 'true' });
  setText(ic, iconMap[type] || 'i');
  const tx = createElement('span', { class: 'su-toast__text' });
  setText(tx, message);
  append(el, ic, tx);
  return el;
});

export const ComponentRegistry = {
  register: registerComponent,
  has: hasComponent,
  create: createComponent,
  list: listComponents,
};

export default ComponentRegistry;
