/**
 * Test pattern + overlay diagnóstico (?diag=1) — não polui culto normal.
 */
import { captureProjectionViewport } from './projection-viewport.js';

let overlayEl = null;

export function isProjectionDiagnosticMode() {
  try {
    const qs = new URLSearchParams(location.search);
    return qs.get('diag') === '1' || localStorage.getItem('SOMOSUM_PROJECTION_DIAG') === '1';
  } catch {
    return false;
  }
}

export function mountProjectionDiagnosticOverlay(viewportEl, engine) {
  if (!isProjectionDiagnosticMode()) return () => {};
  if (overlayEl) return () => overlayEl?.remove();

  overlayEl = document.createElement('div');
  overlayEl.id = 'projection-diag-overlay';
  overlayEl.className = 'projection-diag-overlay';
  overlayEl.setAttribute('aria-hidden', 'true');
  overlayEl.innerHTML = `
    <div class="projection-diag-grid"></div>
    <div class="projection-diag-safe"></div>
    <div class="projection-diag-center"></div>
    <div class="projection-diag-readout"></div>
  `;
  document.body.appendChild(overlayEl);

  const readout = overlayEl.querySelector('.projection-diag-readout');
  const tick = () => {
    const vp = captureProjectionViewport(viewportEl);
    const disp = engine?.projectionDisplay;
    readout.textContent = [
      `VP ${vp.clientWidth}×${vp.clientHeight}`,
      `DPR ${vp.devicePixelRatio.toFixed(2)}`,
      disp?.deviceName ? `DEV ${disp.deviceName}` : '',
      disp?.aspectRatio ? `AR ${disp.aspectRatio}` : '',
      disp?.dpiScale ? `DPI ${disp.dpiScale}` : '',
      engine?.snapshot?.configurationVersion ? `CFG ${engine.snapshot.configurationVersion}` : '',
    ].filter(Boolean).join(' · ');
  };
  tick();
  const interval = setInterval(tick, 1000);
  window.addEventListener('resize', tick, { passive: true });

  return () => {
    clearInterval(interval);
    window.removeEventListener('resize', tick);
    overlayEl?.remove();
    overlayEl = null;
  };
}

export function showDisplayLostBadge(show) {
  let el = document.getElementById('projection-display-lost');
  if (!show) {
    el?.remove();
    return;
  }
  if (el) return;
  el = document.createElement('div');
  el.id = 'projection-display-lost';
  el.className = 'projection-display-lost-badge';
  el.textContent = 'Monitor de projeção desconectado — aguardando reconexão…';
  document.body.appendChild(el);
}

export function bindNativeProjectionMessages(viewportEl, engine, onGeometry) {
  const handler = (ev) => {
    const data = ev?.data;
    if (!data || typeof data !== 'object') return;
    if (data.type === 'projection-state') {
      showDisplayLostBadge(data.state === 'DISPLAY_LOST' || data.state === 'DEGRADED');
    }
    if (data.type === 'projection-geometry' && data.diagnostic) {
      onGeometry?.(data.diagnostic);
    }
  };
  try {
    window.chrome?.webview?.addEventListener?.('message', handler);
  } catch { /* browser */ }
  return () => {
    try { window.chrome?.webview?.removeEventListener?.('message', handler); } catch { /* */ }
  };
}
