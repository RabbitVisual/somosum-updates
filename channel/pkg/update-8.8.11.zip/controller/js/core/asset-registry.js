/**
 * AssetRegistry — URLs versionadas centralizadas (SSOT via AppMeta).
 */
import { APP_META, installAppMeta } from './app-meta.js';

let _meta = APP_META;
let _revision = APP_META.assetRevision || APP_META.version;

const loadedStyles = new Set();
const loadedScripts = new Set();

export function install(meta) {
  if (meta) {
    _meta = installAppMeta(meta);
    _revision = _meta.assetRevision || _meta.version || APP_META.assetRevision;
  }
  return _meta;
}

export function getMeta() {
  return _meta;
}

export function getRevision() {
  return _revision;
}

export function resolvePath(src) {
  if (!src) return src;
  if (/^https?:\/\//i.test(src)) return src;
  const s = String(src).replace(/^\.\//, '');
  return s.charAt(0) === '/' ? s : `/${s}`;
}

/** Único ponto que anexa ?v= — permitido pelo gate de governança. */
export function url(src) {
  const path = resolvePath(src);
  if (!path || /^https?:\/\//i.test(path)) return path;
  const base = path.split('?')[0];
  const extra = path.includes('?') ? '&' + path.slice(path.indexOf('?') + 1) : '';
  return `${base}?v=${encodeURIComponent(_revision)}${extra}`;
}

export function loadStylesheet(href, { id } = {}) {
  const u = url(href);
  if (loadedStyles.has(u)) return Promise.resolve();
  return new Promise((resolve, reject) => {
    const link = document.createElement('link');
    link.rel = 'stylesheet';
    link.href = u;
    if (id) link.id = id;
    link.onload = () => { loadedStyles.add(u); resolve(); };
    link.onerror = () => reject(new Error(`css:${href}`));
    document.head.appendChild(link);
  });
}

export function loadScript(src, { defer = false, module = false } = {}) {
  const u = url(src);
  if (loadedScripts.has(u)) return Promise.resolve();
  return new Promise((resolve, reject) => {
    const s = document.createElement('script');
    s.src = u;
    if (defer) s.defer = true;
    if (module) s.type = 'module';
    s.onload = () => { loadedScripts.add(u); resolve(); };
    s.onerror = () => reject(new Error(`script:${src}`));
    (module ? document.body : document.head).appendChild(s);
  });
}

export function loadModule(src) {
  return loadScript(src, { module: true });
}

export function injectCritical(cssList) {
  const list = Array.isArray(cssList) ? cssList : [];
  return Promise.all(list.map((href) => loadStylesheet(href)));
}

export function preload(paths) {
  const list = Array.isArray(paths) ? paths : [];
  list.forEach((href) => {
    const link = document.createElement('link');
    link.rel = 'preload';
    link.as = href.endsWith('.css') ? 'style' : 'script';
    link.href = url(href);
    document.head.appendChild(link);
  });
}

export function getSurfaceAssets(surface) {
  const assets = _meta.assets || APP_META.assets || {};
  const shared = assets.shared || {};
  const surfaceDef = assets[surface] || {};
  return {
    fa: shared.fa || [],
    critical: [...(shared.critical || []), ...(surfaceDef.critical || [])],
    deferred: surfaceDef.deferred || [],
    designer: surfaceDef.designer || [],
    modules: surfaceDef.modules || [],
    scripts: surfaceDef.scripts || [],
  };
}

export async function bootSurface(surface, { extraScripts = [], extraModules = [] } = {}) {
  const def = getSurfaceAssets(surface);
  await injectCritical([...def.fa, ...def.critical]);
  preload(def.deferred.slice(0, 4));
  for (const src of def.scripts) await loadScript(src);
  for (const src of extraScripts) await loadScript(src);
  for (const src of [...def.modules, ...extraModules]) await loadModule(src);
  if (def.deferred.length) {
    requestAnimationFrame(() => {
      injectCritical(def.deferred).catch(() => {});
    });
  }
}

export function importModule(specifier) {
  return import(url(specifier));
}

export async function loadDesignerAssets() {
  const def = getSurfaceAssets('control');
  const css = [...new Set([...def.fa, ...def.designer.filter((p) => p.endsWith('.css'))])];
  await injectCritical(css);
  for (const src of def.designer.filter((p) => p.endsWith('.js'))) {
    await loadScript(src);
  }
}

/** Instância global para boot clássico (IIFE). */
export function createAssetRegistry(meta) {
  install(meta);
  return {
    install,
    url,
    loadStylesheet,
    loadScript,
    loadModule,
    injectCritical,
    preload,
    getSurfaceAssets,
    bootSurface,
    loadDesignerAssets,
    importModule,
    getRevision,
    getMeta,
  };
}

if (typeof window !== 'undefined') {
  window.SOMOSUM_ASSET_REGISTRY = {
    install,
    url,
    loadStylesheet,
    loadScript,
    loadModule,
    injectCritical,
    preload,
    getSurfaceAssets,
    bootSurface,
    loadDesignerAssets,
    importModule,
    getRevision,
    getMeta,
  };
}
