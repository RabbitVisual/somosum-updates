/**
 * Inicializa AssetRegistry + CacheManager + ProtocolCompat após boot-asset-loader.
 */
import { install as installRegistry } from './asset-registry.js';
import { ensureFresh } from './cache-manager.js';
import { validateWithEngine, showCompatBanner } from './protocol-compat.js';

export async function initAppMetaRuntime() {
  const meta = typeof window !== 'undefined' ? window.__SOMOSUM_META__ : null;
  if (!meta) return null;
  installRegistry(meta);
  await ensureFresh(meta);
  const compat = await validateWithEngine(meta);
  showCompatBanner(compat);
  return { meta, compat };
}
