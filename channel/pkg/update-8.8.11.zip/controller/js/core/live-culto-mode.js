/**
 * Políticas de performance durante culto ao vivo (projetor conectado + autoLive).
 * Modo apresentação "Iniciar culto" — layout leve no Controle.
 */

let cachesReduced = false;
let cultoPresentationActive = false;

export function isLiveCultoActive() {
  return !!window.__SOMOSUM_LIVE_ACTIVE;
}

/** Modo apresentação: ordem + prévia, inspetor oculto (edição rápida opcional). */
export function isCultoPresentation() {
  return cultoPresentationActive || document.documentElement.dataset.cultoOps === '1';
}

/** Bloqueia sync pesado do inspetor (rebuild global) durante o culto. */
export function shouldBlockHeavyInspectorSync() {
  return isLiveCultoActive();
}

export async function applyLiveCultoRuntime() {
  if (!isLiveCultoActive() && !isCultoPresentation()) {
    await restoreNormalCaches();
    return;
  }
  document.documentElement.dataset.liveCulto = '1';
  if (cachesReduced) return;
  try {
    const { ImageCache, VideoCache } = await import('../render/asset-cache.js');
    const prod = !!window.__SOMOSUM_PRODUCTION_CACHE_MAX;
    ImageCache._maxSize = prod ? 20 : 40;
    VideoCache._maxSize = prod ? 4 : 6;
    cachesReduced = true;
  } catch { /* ignore */ }
}

export async function restoreNormalCaches() {
  document.documentElement.removeAttribute('data-live-culto');
  if (!cachesReduced) return;
  try {
    const { ImageCache, VideoCache } = await import('../render/asset-cache.js');
    ImageCache._maxSize = 60;
    VideoCache._maxSize = 12;
    cachesReduced = false;
  } catch { /* ignore */ }
}

/** Intervalo de debounce para sync ao projetor durante live-edit (ms). Uma camada só. */
export function liveProjectorDebounceMs() {
  try {
    if (window.somosumNativeShell || window.chrome?.webview) return 0;
  } catch { /* ignore */ }
  return 8;
}

export function applyCultoPresentationDom(active) {
  document.documentElement.dataset.cultoOps = active ? '1' : '';
  for (const sel of ['.program-grid', '.live-console-grid']) {
    const grid = document.querySelector(sel);
    grid?.classList.toggle('program-grid--culto-ops', !!active);
    grid?.classList.remove('program-grid--quick-edit');
  }
  document.getElementById('culto-quick-edit-backdrop')?.toggleAttribute('hidden', true);
  document.getElementById('btn-culto-start')?.toggleAttribute('hidden', !!active);
  document.getElementById('btn-culto-end')?.toggleAttribute('hidden', !active);
  document.getElementById('btn-culto-quick-edit')?.toggleAttribute('hidden', !active);
  document.getElementById('program-culto-hint')?.toggleAttribute('hidden', !active);
  document.getElementById('btn-culto-quick-close')?.toggleAttribute('hidden', true);
}

export async function enterCultoPresentation(app) {
  cultoPresentationActive = true;
  applyCultoPresentationDom(true);

  if (app?.isRehearsal?.()) {
    app.toggleRehearsal?.();
    const btn = document.getElementById('btn-rehearsal');
    if (btn) {
      btn.classList.remove('is-active');
      btn.textContent = 'Ao vivo';
    }
  }

  if (app?.prefs) {
    app.prefs.cultoPresentation = true;
    try {
      const { savePrefs } = await import('./store.js');
      await savePrefs(app.prefs);
    } catch { /* ignore */ }
  }

  if (!app?.screenConnected) {
    try {
      await app?.openProjectionScreen?.();
    } catch { /* ignore */ }
  }

  app?.updateLiveBadge?.();
  await applyLiveCultoRuntime();
  app?.toast?.('Modo culto — ordem, sequência e controles. Use Editar item para ajustes rápidos.', 'success');
}

export async function exitCultoPresentation(app) {
  cultoPresentationActive = false;
  applyCultoPresentationDom(false);

  if (app?.prefs) {
    app.prefs.cultoPresentation = false;
    try {
      const { savePrefs } = await import('./store.js');
      await savePrefs(app.prefs);
    } catch { /* ignore */ }
  }

  await applyLiveCultoRuntime();
  app?.toast?.('Modo culto encerrado', 'success');
}

export function restoreCultoPresentationFromPrefs(app) {
  if (app?.prefs?.cultoPresentation) {
    cultoPresentationActive = true;
    applyCultoPresentationDom(true);
    void applyLiveCultoRuntime();
  }
}

export function toggleCultoQuickEdit(open) {
  const grid = document.querySelector('.live-console-grid, .program-grid');
  if (!grid || !isCultoPresentation()) return false;
  const next = open ?? !grid.classList.contains('program-grid--quick-edit');
  grid.classList.toggle('program-grid--quick-edit', next);
  document.getElementById('culto-quick-edit-backdrop')?.toggleAttribute('hidden', !next);
  document.getElementById('btn-culto-quick-close')?.toggleAttribute('hidden', !next);
  document.getElementById('btn-culto-quick-edit')?.classList.toggle('is-active', next);
  if (next) {
    requestAnimationFrame(() => {
      document.getElementById('inspector-body')?.querySelector('.inspector-scroll')?.scrollTo?.(0, 0);
    });
  }
  return next;
}
