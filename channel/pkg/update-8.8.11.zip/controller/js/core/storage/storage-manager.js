import { DatabaseEngine } from '../database/database-engine.js';
import { transactionManager } from '../database/transaction-manager.js';
import { coordinatedSave, getQueueDepth } from '../database/save-coordinator.js';
import * as Repos from './repository/index.js';
import { CacheLayer } from './cache/cache-layer.js';
import { IndexEngine } from './index/index-engine.js';
import { SqliteCatalogAdapter } from './adapters/sqlite-catalog-adapter.js';
import { SearchEngine } from './search/search-engine.js';
import { QueryManager } from './query-manager.js';
import { FileManager } from './files/file-manager.js';
import { BackupEngine } from './backup/backup-engine.js';
import { IntegrityManager } from './integrity/integrity-manager.js';
import { MigrationEngine } from './migration/migration-engine.js';
import { StorageMetrics } from './monitor/storage-metrics.js';
import { STORAGE_SCHEMA_VERSION, DOMAIN_MATRIX } from './schema.js';
import { LogService, LogCategory } from '../logging/log-service.js';

let initialized = false;

export const StorageManager = {
  schemaVersion: STORAGE_SCHEMA_VERSION,
  domainMatrix: DOMAIN_MATRIX,
  repos: Repos,
  cache: CacheLayer,
  search: SearchEngine,
  query: QueryManager,
  files: FileManager,
  backup: BackupEngine,
  integrity: IntegrityManager,
  migration: MigrationEngine,
  metrics: StorageMetrics,
  transactions: transactionManager,
  coordinator: { save: coordinatedSave, queueDepth: getQueueDepth },
  database: DatabaseEngine,

  async init() {
    if (initialized) return this;
    initialized = true;
    await DatabaseEngine.init();
    await MigrationEngine.run();
    try {
      await IndexEngine.rebuildAll();
      setTimeout(() => {
        void SqliteCatalogAdapter.rebuildIfOnline();
      }, 8000);
    } catch (err) {
      LogService.warn('Index rebuild parcial no boot', {
        module: 'storage-manager',
        category: LogCategory.DATABASE,
        err,
      });
    }
    if (typeof window !== 'undefined') {
      window.SOMOSUM_STORAGE = this;
    }
    LogService.debug('Storage Platform 8.0 inicializado', {
      module: 'storage-manager',
      category: LogCategory.DATABASE,
      detail: { schemaVersion: STORAGE_SCHEMA_VERSION },
    });
    return this;
  },

  async snapshot() {
    return StorageMetrics.snapshot(this.repos);
  },

  invalidate(domain) {
    CacheLayer.invalidate(domain);
    IndexEngine.invalidate(domain);
  },
};

export async function bootstrapStorage() {
  return StorageManager.init();
}
