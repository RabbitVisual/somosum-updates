import { IndexEngine } from '../index/index-engine.js';
import { fuzzyScore, tokenize } from '../index/token-index.js';
import { songRepository } from '../repository/song-repository.js';
import { bibleRepository } from '../repository/bible-repository.js';
import { mediaRepository } from '../repository/media-repository.js';
import { cultoRepository } from '../repository/culto-repository.js';

const LOADERS = {
  async songs(ids) {
    const all = await songRepository.getAll();
    const map = new Map(all.map((s) => [s.id, s]));
    return ids.map(({ id, score }) => ({ ...map.get(id), _score: score })).filter((s) => s.id);
  },
  async media(ids) {
    const all = await mediaRepository.getAll();
    const list = Array.isArray(all) ? all : Object.values(all || {});
    const map = new Map(list.map((m) => [m.id, m]));
    return ids.map(({ id, score }) => ({ ...map.get(id), _score: score })).filter((m) => m?.id);
  },
  async cultos(ids) {
    const idx = await cultoRepository.loadIndex();
    const map = new Map((idx?.cultos || []).map((c) => [c.id, c]));
    return ids.map(({ id, score }) => ({ ...map.get(id), _score: score })).filter((c) => c?.id);
  },
  async bible(_ids, q) {
    const hist = await bibleRepository.listHistory();
    const t = String(q || '').toLowerCase();
    return (hist || []).filter((h) =>
      String(h.ref || '').toLowerCase().includes(t)
      || String(h.translation || '').toLowerCase().includes(t)).slice(0, 30);
  },
};

export const SearchEngine = {
  async query({
    domain = 'songs',
    q = '',
    filters = {},
    sort = 'score',
    limit = 30,
    offset = 0,
    fuzzy = false,
  } = {}) {
    const query = String(q || '').trim();
    if (!query) return { items: [], total: 0, limit, offset };

    let hits = IndexEngine.search(domain, query, { limit: limit + offset + 50 });
    if (!hits.length && domain !== 'bible') {
      if (domain === 'media') await IndexEngine.rebuildMedia();
      else if (domain === 'cultos') await IndexEngine.rebuildCultos();
      else await IndexEngine.rebuildSongs();
      hits = IndexEngine.search(domain, query, { limit: limit + offset + 50 });
    }

    if (fuzzy && hits.length < 3 && domain === 'songs') {
      const all = await songRepository.getAll();
      const extra = all
        .map((s) => ({
          id: s.id,
          score: Math.max(0, 10 - fuzzyScore(query, s.title)),
        }))
        .filter((x) => x.score > 5)
        .sort((a, b) => b.score - a.score)
        .slice(0, limit);
      hits = [...hits, ...extra];
    }

    const loader = LOADERS[domain];
    if (!loader) return { items: [], total: 0, limit, offset };
    let items = domain === 'bible'
      ? await loader(hits, query)
      : await loader(hits.slice(offset, offset + limit));

    if (filters.category) {
      items = items.filter((i) => i.category === filters.category);
    }
    if (sort === 'title') items.sort((a, b) => String(a.title).localeCompare(String(b.title), 'pt-BR'));
    else if (sort === 'date') items.sort((a, b) => String(b.date || b.updatedAt).localeCompare(String(a.date || a.updatedAt)));

    return {
      items: items.slice(0, limit),
      total: hits.length,
      limit,
      offset,
      tokens: tokenize(query),
    };
  },
};
