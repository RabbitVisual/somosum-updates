export {
  bootstrapStorage,
  StorageManager,
} from './storage-manager.js';

export { STORAGE_SCHEMA_VERSION, DOMAIN_MATRIX, isAllowedDataPath } from './schema.js';
export { QueryManager } from './query-manager.js';
export { SearchEngine } from './search/search-engine.js';
export { CacheLayer } from './cache/cache-layer.js';
export { IndexEngine } from './index/index-engine.js';
export { BackupEngine, RestoreEngine } from './backup/backup-engine.js';
export { FileManager } from './files/file-manager.js';
export { IntegrityManager } from './integrity/integrity-manager.js';
export { MigrationEngine } from './migration/migration-engine.js';
export { StorageMetrics } from './monitor/storage-metrics.js';
export { DiskAdapter } from './adapters/disk-adapter.js';
export { SqliteCatalogAdapter } from './adapters/sqlite-catalog-adapter.js';
export * from './adapters/server-adapter.js';
export * from './repository/index.js';
