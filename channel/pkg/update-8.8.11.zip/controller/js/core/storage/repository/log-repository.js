import { BaseRepository } from './base-repository.js';
import { LogService } from '../../logging/log-service.js';

class LogRepository extends BaseRepository {
  constructor() {
    super('logs');
  }
  info(msg, ctx) { return LogService.info(msg, ctx); }
  warn(msg, ctx) { return LogService.warn(msg, ctx); }
  error(msg, ctx) { return LogService.error(msg, ctx); }
  debug(msg, ctx) { return LogService.debug?.(msg, ctx); }
}

export const logRepository = new LogRepository();
