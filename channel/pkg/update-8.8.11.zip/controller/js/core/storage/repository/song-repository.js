import { SongRepository as LegacySongRepo } from '../../database/repositories/song-repository.js';
import { BaseRepository } from './base-repository.js';
import { validateSong } from '../../database/integrity-validator.js';

class SongRepository extends BaseRepository {
  constructor() {
    super('songs', { diskPath: 'letras.json', idbStore: 'songs', validate: validateSong });
  }
  getAll() { return LegacySongRepo.getAll(); }
  getById(id) { return LegacySongRepo.getById(id); }
  save(song) { return LegacySongRepo.save(song); }
  delete(id) { return LegacySongRepo.delete(id); }
  purgeStressSongs() { return LegacySongRepo.purgeStressSongs(); }
  search(q, opts) { return LegacySongRepo.getAll().then((all) => this.paginateFilter(all, q, opts)); }
  paginateFilter(all, q, { limit, offset, field = 'title' } = {}) {
    let list = all;
    if (q) {
      const t = String(q).toLowerCase();
      list = list.filter((s) =>
        String(s.title || '').toLowerCase().includes(t)
        || String(s.artist || '').toLowerCase().includes(t));
    }
    return this.paginate(list, { limit, offset });
  }
}

export const songRepository = new SongRepository();
