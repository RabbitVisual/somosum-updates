import { BaseRepository } from './base-repository.js';

/** Stub — API estável para usuários futuros (7.9+) */
class UserRepository extends BaseRepository {
  constructor() {
    super('users');
  }
  async list() { return []; }
  async get(_id) { return null; }
  async save(_user) { return null; }
  async delete(_id) { return false; }
}

export const userRepository = new UserRepository();
