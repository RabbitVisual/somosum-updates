import { BaseRepository } from './base-repository.js';
import { DiskAdapter } from '../adapters/disk-adapter.js';

class OverlayRepository extends BaseRepository {
  constructor() {
    super('overlays', { diskPath: 'overlays.json' });
  }
  async getAll() { return (await DiskAdapter.load('overlays.json')) || []; }
  async saveAll(list) {
    return DiskAdapter.saveCoordinated('overlays:save', 'overlays.json', list);
  }
}

export const overlayRepository = new OverlayRepository();

class AvisoRepository extends BaseRepository {
  constructor() {
    super('avisos', { diskPath: 'avisos/index.json' });
  }
  async getIndex() { return (await DiskAdapter.load('avisos/index.json')) || { avisos: [] }; }
  async saveIndex(idx) {
    return DiskAdapter.saveCoordinated('avisos:index', 'avisos/index.json', idx);
  }
}

export const avisoRepository = new AvisoRepository();
