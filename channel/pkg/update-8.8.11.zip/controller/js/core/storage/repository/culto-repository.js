import { BaseRepository } from './base-repository.js';
import { DiskAdapter } from '../adapters/disk-adapter.js';
import {
  loadCultoIndex,
  getCulto,
  saveCulto,
  deleteCulto,
  listCultos,
} from '../../../program/culto-manager.js';

class CultoRepository extends BaseRepository {
  constructor() {
    super('cultos', { diskPath: 'cultos/index.json' });
  }
  loadIndex() { return loadCultoIndex(); }
  get(id) { return getCulto(id); }
  save(id, items, meta) { return saveCulto(id, items, meta); }
  delete(id) { return deleteCulto(id); }
  listAll() { return listCultos?.() ?? this.loadIndex().then((i) => i?.cultos || []); }
}

export const cultoRepository = new CultoRepository();
