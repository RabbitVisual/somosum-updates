import { BaseRepository } from './base-repository.js';
import { DiskAdapter } from '../adapters/disk-adapter.js';
import { appendReading, listReadings } from '../../../bible/reading-history.js';
import { loadChapterFromIdb, saveChapterToIdb } from '../../../bible/bible-pack-loader.js';

class BibleRepository extends BaseRepository {
  constructor() {
    super('bible', { diskPath: 'bible-history.json' });
  }
  listHistory() { return listReadings(); }
  appendReading(entry) { return appendReading(entry); }
  async loadHistory() { return DiskAdapter.load('bible-history.json'); }
  async saveHistory(data) {
    return DiskAdapter.saveCoordinated('bible:history', 'bible-history.json', data);
  }
  async getChapter(versionKey, bookAbbrev, chapter) {
    return loadChapterFromIdb(versionKey, bookAbbrev, chapter);
  }
  async putChapter(versionKey, bookAbbrev, chapter, verses) {
    return saveChapterToIdb(versionKey, bookAbbrev, chapter, verses);
  }
}

export const bibleRepository = new BibleRepository();
