import { AssetRepository as LegacyAssetRepo } from '../../database/repositories/asset-repository.js';
import { BaseRepository } from './base-repository.js';

class AssetRepository extends BaseRepository {
  constructor() {
    super('assets', { diskPath: 'assets/index.json', idbStore: 'assets' });
  }
  get(key) { return LegacyAssetRepo.get(key); }
  getAll() { return LegacyAssetRepo.getAll(); }
  save(key, dataUrl, mime) { return LegacyAssetRepo.save(key, dataUrl, mime); }
  delete(key) { return LegacyAssetRepo.delete(key); }
}

export const assetRepository = new AssetRepository();
