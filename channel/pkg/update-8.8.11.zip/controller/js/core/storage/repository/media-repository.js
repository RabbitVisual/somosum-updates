import { MediaRepository as LegacyMediaRepo, isStressMedia } from '../../database/repositories/media-repository.js';
import { BaseRepository } from './base-repository.js';

class MediaRepository extends BaseRepository {
  constructor() {
    super('media', { diskPath: 'media/index.json', idbStore: 'media' });
  }
  getAll() { return LegacyMediaRepo.getAll(); }
  getById(id) { return LegacyMediaRepo.getById(id); }
  save(entry) { return LegacyMediaRepo.save(entry); }
  delete(id) { return LegacyMediaRepo.delete(id); }
  purgeStressMedia() { return LegacyMediaRepo.purgeStressMedia(); }
  purgeObsoleteSystemMedia(validSystemIds) {
    return LegacyMediaRepo.purgeObsoleteSystemMedia(validSystemIds);
  }
}

export { isStressMedia };
export const mediaRepository = new MediaRepository();
