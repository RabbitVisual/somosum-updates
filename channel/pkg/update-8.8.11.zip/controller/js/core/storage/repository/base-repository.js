import { coordinatedSave } from '../../database/save-coordinator.js';
import { transactionManager } from '../../database/transaction-manager.js';
import { DiskAdapter } from '../adapters/disk-adapter.js';
import { getMemoryCache } from '../adapters/memory-adapter.js';

export class BaseRepository {
  constructor(domain, {
    diskPath = null,
    idbStore = null,
    validate = null,
    cacheSize = 200,
  } = {}) {
    this.domain = domain;
    this.diskPath = diskPath;
    this.idbStore = idbStore;
    this.validate = validate;
    this.cache = getMemoryCache(`repo:${domain}`, cacheSize);
  }

  stamp(entity) {
    const now = Date.now();
    return {
      ...entity,
      _v: (entity._v || 0) + 1,
      updatedAt: now,
      createdAt: entity.createdAt || now,
    };
  }

  paginate(list, { limit = 50, offset = 0 } = {}) {
    const slice = Array.isArray(list) ? list : [];
    return {
      items: slice.slice(offset, offset + limit),
      total: slice.length,
      limit,
      offset,
      hasMore: offset + limit < slice.length,
    };
  }

  async loadDisk() {
    if (!this.diskPath) return null;
    return DiskAdapter.load(this.diskPath);
  }

  async saveDisk(data, label = `${this.domain}:save`) {
    if (!this.diskPath) return false;
    return DiskAdapter.saveCoordinated(label, this.diskPath, data, { silent: true });
  }

  async saveTransactional(data, label) {
    if (!this.diskPath) return false;
    const snapshot = await this.loadDisk();
    return DiskAdapter.saveTransactional(label, this.diskPath, data, {
      rollbackFn: snapshot != null ? () => snapshot : null,
    });
  }

  invalidateCache(key = null) {
    if (key) this.cache.delete(key);
    else this.cache.clear?.();
  }

  validateEntity(entity) {
    if (!this.validate) return true;
    return this.validate(entity);
  }

  get transactions() {
    return transactionManager;
  }

  get coordinator() {
    return { save: coordinatedSave };
  }
}
