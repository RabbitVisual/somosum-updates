import { BaseRepository } from './base-repository.js';
import { DiskAdapter } from '../adapters/disk-adapter.js';

class HistoryRepository extends BaseRepository {
  constructor() {
    super('history', { diskPath: 'macros.json' });
  }
  async loadMacros() { return DiskAdapter.load('macros.json'); }
  async saveMacros(data) {
    return DiskAdapter.saveCoordinated('history:macros', 'macros.json', data);
  }
  async loadRemoteMacros() { return DiskAdapter.load('remote-macros.json'); }
  async saveRemoteMacros(data) {
    return DiskAdapter.saveCoordinated('history:remote-macros', 'remote-macros.json', data);
  }
  async loadCcliUsage() { return DiskAdapter.load('ccli-usage.json'); }
  async saveCcliUsage(data) {
    return DiskAdapter.saveCoordinated('history:ccli', 'ccli-usage.json', data);
  }
}

export const historyRepository = new HistoryRepository();
