import { ProgramRepository as LegacyProgramRepo } from '../../database/repositories/program-repository.js';
import { BaseRepository } from './base-repository.js';

class ProgramRepository extends BaseRepository {
  constructor() {
    super('program', { diskPath: 'programa.json', idbStore: 'program' });
  }
  getItems() { return LegacyProgramRepo.getItems(); }
  saveItems(items) { return LegacyProgramRepo.saveItems(items); }
  getCurrent() { return LegacyProgramRepo.getCurrent?.() ?? LegacyProgramRepo.getItems(); }
}

export const programRepository = new ProgramRepository();
export const slideRepository = programRepository;
