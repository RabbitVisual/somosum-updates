import { BaseRepository } from './base-repository.js';
import { DiskAdapter } from '../adapters/disk-adapter.js';

class TemplateRepository extends BaseRepository {
  constructor() {
    super('templates', { diskPath: 'templates/index.json' });
  }
  async loadIndex() {
    return (await DiskAdapter.load('templates/index.json')) || { templates: [] };
  }
  async saveIndex(index) {
    return DiskAdapter.saveCoordinated('templates:index', 'templates/index.json', index);
  }
  async get(id) {
    return DiskAdapter.load(`templates/${id}.json`);
  }
  async save(id, data) {
    await DiskAdapter.saveCoordinated(`templates:${id}`, `templates/${id}.json`, data);
    const idx = await this.loadIndex();
    const list = idx.templates || [];
    const entry = { id, title: data.title || id, updatedAt: Date.now() };
    const i = list.findIndex((t) => t.id === id);
    if (i >= 0) list[i] = { ...list[i], ...entry };
    else list.push(entry);
    idx.templates = list;
    await this.saveIndex(idx);
    return data;
  }
}

export const templateRepository = new TemplateRepository();
