import { BaseRepository } from './base-repository.js';
import {
  loadWorshipMeta,
  saveWorshipMeta,
  getPlaylists,
  savePlaylist,
} from '../../../worship/worship-meta.js';

class PlaylistRepository extends BaseRepository {
  constructor() {
    super('playlists', { diskPath: 'worship-meta.json' });
  }
  loadMeta() { return loadWorshipMeta(); }
  saveMeta(meta) { return saveWorshipMeta(meta); }
  listPlaylists() { return getPlaylists(); }
  save(playlist) { return savePlaylist(playlist); }
}

export const playlistRepository = new PlaylistRepository();
