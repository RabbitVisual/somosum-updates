import { BaseRepository } from './base-repository.js';
import { getPrefs, savePrefs } from '../../store.js';
import { DiskAdapter } from '../adapters/disk-adapter.js';

class ConfigRepository extends BaseRepository {
  constructor() {
    super('config', { diskPath: 'config.json', idbStore: 'meta' });
  }
  getPrefs() { return getPrefs(); }
  savePrefs(prefs) { return savePrefs(prefs); }
  async loadConfig() { return DiskAdapter.load('config.json'); }
  async saveConfig(cfg) {
    return DiskAdapter.saveCoordinated('config:save', 'config.json', cfg);
  }
}

export const configRepository = new ConfigRepository();
