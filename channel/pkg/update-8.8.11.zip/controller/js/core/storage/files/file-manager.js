import {
  saveMediaToDisk,
  saveAssetToDisk,
  deleteMediaFromDisk,
  uploadAudioFile,
  dataPublicUrl,
} from '../../file-store.js';
import { DiskAdapter } from '../adapters/disk-adapter.js';
import { isAllowedDataPath } from '../schema.js';

export const FileManager = {
  isAllowed: isAllowedDataPath,
  loadJson: (path) => DiskAdapter.load(path),
  saveJson: (path, data, label) => DiskAdapter.saveCoordinated(label || `file:${path}`, path, data),
  saveMedia: saveMediaToDisk,
  saveAsset: saveAssetToDisk,
  deleteMedia: deleteMediaFromDisk,
  uploadAudio: uploadAudioFile,
  resolvePublicUrl(path) {
    const p = String(path || '').trim();
    if (!p) return '';
    if (p.startsWith('data:') || p.startsWith('blob:') || p.startsWith('http')) return p;
    const rel = p.startsWith('/') ? p.replace(/^\/+/, '') : p.replace(/^\/+/, '');
    return dataPublicUrl(rel.replace(/^data\//, ''));
  },
};
