import { runDataMigration } from '../../migration.js';
import { STORAGE_SCHEMA_VERSION } from '../schema.js';
import { DiskAdapter } from '../adapters/disk-adapter.js';

const MIGRATION_FLAG = 'somosum-storage-schema';

export const MigrationEngine = {
  version: STORAGE_SCHEMA_VERSION,

  async getStoredVersion() {
    try {
      const meta = await DiskAdapter.load('meta.json');
      return meta?.storageSchemaVersion || Number(localStorage.getItem(MIGRATION_FLAG)) || 0;
    } catch {
      return 0;
    }
  },

  async setVersion(v) {
    localStorage.setItem(MIGRATION_FLAG, String(v));
    const meta = (await DiskAdapter.load('meta.json')) || {};
    meta.storageSchemaVersion = v;
    await DiskAdapter.saveCoordinated('migration:version', 'meta.json', meta);
  },

  async run() {
    await runDataMigration();
    const current = await this.getStoredVersion();
    if (current < STORAGE_SCHEMA_VERSION) {
      await this.setVersion(STORAGE_SCHEMA_VERSION);
    }
    return { from: current, to: STORAGE_SCHEMA_VERSION };
  },

  async rollbackSnapshot(snapshot) {
    if (!snapshot?.path || snapshot.data == null) return false;
    return DiskAdapter.saveCoordinated('migration:rollback', snapshot.path, snapshot.data);
  },
};
