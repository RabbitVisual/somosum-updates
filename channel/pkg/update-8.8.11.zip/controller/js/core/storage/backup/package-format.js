export const PACKAGE_VERSION = 6;

export function buildPackage(payload, { label = 'somosum' } = {}) {
  return {
    version: PACKAGE_VERSION,
    label,
    createdAt: new Date().toISOString(),
    checksum: null,
    ...payload,
  };
}

export function validatePackage(data) {
  if (!data || typeof data !== 'object') return { ok: false, error: 'invalid' };
  if (!data.version || data.version < 5) return { ok: false, error: 'version' };
  return { ok: true };
}

export const PACKAGE_DOMAINS = [
  'songs', 'program', 'prefs', 'assets', 'media', 'cultos', 'overlays', 'templates', 'worshipMeta',
];
