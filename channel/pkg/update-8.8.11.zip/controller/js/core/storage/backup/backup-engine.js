import { exportBackup, importBackup } from '../../store.js';
import { validatePackage, PACKAGE_DOMAINS } from './package-format.js';
import { coordinatedSave } from '../../database/save-coordinator.js';
import { LogService, LogCategory } from '../../logging/log-service.js';

async function runIncrementalApi() {
  try {
    const res = await fetch('/api/backup/incremental', { method: 'POST' });
    return res.ok ? await res.json() : null;
  } catch {
    return null;
  }
}

async function getBackupStatusApi() {
  try {
    const res = await fetch('/api/backup/status', { cache: 'no-store' });
    return res.ok ? await res.json() : null;
  } catch {
    return null;
  }
}

export const BackupEngine = {
  async exportFull() {
    return exportBackup();
  },
  exportJson() {
    return this.exportFull();
  },
  async importFull(data) {
    const v = validatePackage(data);
    if (!v.ok) throw new Error(`Backup inválido: ${v.error}`);
    return coordinatedSave('backup:import-full', () => importBackup(data), { priority: 10 });
  },
  async importJson(data, { partial = false } = {}) {
    if (partial && data) {
      const filtered = { ...data, version: data.version || 6 };
      for (const key of Object.keys(filtered)) {
        if (!PACKAGE_DOMAINS.includes(key) && key !== 'version') delete filtered[key];
      }
      if (!filtered.songs) delete filtered.songs;
      if (!filtered.program) delete filtered.program;
      await importBackup(filtered);
      LogService.info('Restauração parcial', { module: 'backup-engine', category: LogCategory.DATABASE });
      return true;
    }
    return this.importFull(data);
  },
  async importPartial(data, domains = []) {
    const v = validatePackage(data);
    if (!v.ok) throw new Error(`Backup inválido: ${v.error}`);
    const filtered = { version: data.version || 6 };
    for (const d of domains.length ? domains : PACKAGE_DOMAINS) {
      if (data[d] != null) filtered[d] = data[d];
    }
    await importBackup(filtered);
    return true;
  },
  runIncremental: runIncrementalApi,
  getStatus: getBackupStatusApi,
  downloadZip() {
    const a = document.createElement('a');
    a.href = '/api/backup.zip';
    a.download = '';
    a.click();
  },
  async restoreCulto(cultoId, cultoData) {
    if (!cultoId || !cultoData) return false;
    return coordinatedSave(`backup:restore-culto:${cultoId}`, async () => {
      const { saveCulto } = await import('../../../program/culto-manager.js');
      await saveCulto(cultoId, cultoData.items || [], cultoData.meta || cultoData);
      LogService.info('Restore parcial culto', { module: 'backup-engine', category: LogCategory.DATABASE, detail: { cultoId } });
      return true;
    });
  },
};

export const RestoreEngine = BackupEngine;
