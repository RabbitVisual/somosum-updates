import { getMemoryCache } from '../adapters/memory-adapter.js';
import { policyFor } from './policies.js';

const SESSION_PREFIX = 'somosum-cache:';

export const CacheLayer = {
  stats: { hits: 0, misses: 0 },

  getMemory(domain) {
    const p = policyFor(domain);
    return getMemoryCache(domain, p.memory);
  },

  getSession(domain, key) {
    try {
      const raw = sessionStorage.getItem(`${SESSION_PREFIX}${domain}:${key}`);
      if (!raw) return null;
      const { v, exp } = JSON.parse(raw);
      if (exp && Date.now() > exp) {
        sessionStorage.removeItem(`${SESSION_PREFIX}${domain}:${key}`);
        return null;
      }
      this.stats.hits += 1;
      return v;
    } catch {
      return null;
    }
  },

  setSession(domain, key, value, ttlMs) {
    const p = policyFor(domain);
    const exp = Date.now() + (ttlMs || p.ttlMs || 60000);
    try {
      sessionStorage.setItem(`${SESSION_PREFIX}${domain}:${key}`, JSON.stringify({ v: value, exp }));
    } catch { /* quota */ }
  },

  async get(domain, key, loader) {
    const mem = this.getMemory(domain);
    const hit = mem.get(`${domain}:${key}`);
    if (hit != null) {
      this.stats.hits += 1;
      return hit;
    }
    const sess = this.getSession(domain, key);
    if (sess != null) return sess;
    this.stats.misses += 1;
    if (!loader) return null;
    const v = await loader();
    if (v != null) {
      mem.set(`${domain}:${key}`, v);
      if (policyFor(domain).session) this.setSession(domain, key, v);
    }
    return v;
  },

  invalidate(domain, key = null) {
    const mem = this.getMemory(domain);
    if (key) mem.delete(`${domain}:${key}`);
    else mem.clear?.();
    if (key) {
      try { sessionStorage.removeItem(`${SESSION_PREFIX}${domain}:${key}`); } catch { /* */ }
    }
  },

  snapshot() {
    return { ...this.stats, hitRate: this.stats.hits / Math.max(1, this.stats.hits + this.stats.misses) };
  },
};
