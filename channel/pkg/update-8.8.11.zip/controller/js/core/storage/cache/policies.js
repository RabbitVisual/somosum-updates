/** TTL e invalidação por domínio */
export const CACHE_POLICIES = {
  songs: { memory: 300, ttlMs: 120000, persistIndex: true },
  media: { memory: 150, ttlMs: 60000, persistIndex: true },
  cultos: { memory: 50, ttlMs: 30000, session: true },
  bible: { memory: 80, ttlMs: 180000 },
  config: { memory: 20, ttlMs: 600000, session: true },
  default: { memory: 100, ttlMs: 60000 },
};

export function policyFor(domain) {
  return CACHE_POLICIES[domain] || CACHE_POLICIES.default;
}
