import { SearchEngine } from './search/search-engine.js';
import { StorageMetrics } from './monitor/storage-metrics.js';

export const QueryManager = {
  async search(opts) {
    const t0 = performance.now();
    try {
      return await SearchEngine.query(opts);
    } finally {
      StorageMetrics.recordQuery(performance.now() - t0);
    }
  },

  async paginate(repo, { limit = 50, offset = 0, filter = null } = {}) {
    const t0 = performance.now();
    try {
      let list = repo.getAll ? await repo.getAll() : [];
      if (filter) list = list.filter(filter);
      if (repo.paginate) return repo.paginate(list, { limit, offset });
      return {
        items: list.slice(offset, offset + limit),
        total: list.length,
        limit,
        offset,
        hasMore: offset + limit < list.length,
      };
    } finally {
      StorageMetrics.recordQuery(performance.now() - t0);
    }
  },
};
