/** Token index — busca parcial O(n) com ranking simples */

export function tokenize(text) {
  return String(text || '')
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .split(/[^\p{L}\p{N}]+/u)
    .filter((t) => t.length > 1);
}

export function buildTokenIndex(items, { idKey = 'id', fields = ['title'] } = {}) {
  const map = new Map();
  for (const item of items) {
    const id = item[idKey];
    if (!id) continue;
    const tokens = new Set();
    for (const f of fields) {
      for (const t of tokenize(item[f])) tokens.add(t);
    }
    for (const t of tokens) {
      if (!map.has(t)) map.set(t, new Set());
      map.get(t).add(id);
    }
  }
  return map;
}

export function searchTokenIndex(map, query, { limit = 50 } = {}) {
  const q = tokenize(query);
  if (!q.length) return [];
  const scores = new Map();
  for (const term of q) {
    for (const [token, ids] of map) {
      if (!token.includes(term) && !term.includes(token)) continue;
      const weight = token === term ? 3 : token.startsWith(term) ? 2 : 1;
      for (const id of ids) {
        scores.set(id, (scores.get(id) || 0) + weight);
      }
    }
  }
  return [...scores.entries()]
    .sort((a, b) => b[1] - a[1])
    .slice(0, limit)
    .map(([id, score]) => ({ id, score }));
}

/** Levenshtein limitado para fuzzy curto */
export function fuzzyScore(a, b, maxDist = 2) {
  a = String(a || '').toLowerCase();
  b = String(b || '').toLowerCase();
  if (a === b) return 0;
  if (Math.abs(a.length - b.length) > maxDist) return maxDist + 1;
  const dp = Array.from({ length: a.length + 1 }, (_, i) => [i]);
  for (let j = 1; j <= b.length; j++) dp[0][j] = j;
  for (let i = 1; i <= a.length; i++) {
    for (let j = 1; j <= b.length; j++) {
      dp[i][j] = Math.min(
        dp[i - 1][j] + 1,
        dp[i][j - 1] + 1,
        dp[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1),
      );
    }
  }
  return dp[a.length][b.length];
}
