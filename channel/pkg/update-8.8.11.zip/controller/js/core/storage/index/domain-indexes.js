/** Re-export domain index builders */
export { IndexEngine as DomainIndexes } from './index-engine.js';
