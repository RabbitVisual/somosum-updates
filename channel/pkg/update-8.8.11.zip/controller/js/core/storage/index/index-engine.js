import { DiskAdapter } from '../adapters/disk-adapter.js';
import { buildTokenIndex, searchTokenIndex } from './token-index.js';
import { songRepository } from '../repository/song-repository.js';
import { mediaRepository } from '../repository/media-repository.js';
import { cultoRepository } from '../repository/culto-repository.js';

const INDEX_FILES = {
  songs: 'indexes/songs.json',
  media: 'indexes/media.json',
  cultos: 'indexes/cultos.json',
  bible: 'indexes/bible.json',
};

const runtime = {
  songs: null,
  media: null,
  cultos: null,
  bible: null,
};

export const IndexEngine = {
  async loadPersisted(domain) {
    const path = INDEX_FILES[domain];
    if (!path) return null;
    const data = await DiskAdapter.load(path);
    if (data?.tokens) runtime[domain] = new Map(Object.entries(data.tokens).map(([k, v]) => [k, new Set(v)]));
    return data;
  },

  async persist(domain, tokenMap) {
    const path = INDEX_FILES[domain];
    if (!path || !tokenMap) return;
    const tokens = {};
    for (const [k, set] of tokenMap) tokens[k] = [...set];
    await DiskAdapter.saveCoordinated(`index:${domain}`, path, {
      domain,
      updatedAt: Date.now(),
      tokens,
    });
  },

  async rebuildSongs() {
    const songs = await songRepository.getAll();
    runtime.songs = buildTokenIndex(songs, { fields: ['title', 'artist', 'category'] });
    await this.persist('songs', runtime.songs);
    return songs.length;
  },

  async rebuildMedia() {
    const media = await mediaRepository.getAll();
    const list = Array.isArray(media) ? media : Object.values(media || {});
    runtime.media = buildTokenIndex(list, { idKey: 'id', fields: ['title', 'name', 'tags'] });
    await this.persist('media', runtime.media);
    return list.length;
  },

  async rebuildCultos() {
    const idx = await cultoRepository.loadIndex();
    const cultos = idx?.cultos || [];
    runtime.cultos = buildTokenIndex(cultos, { fields: ['title', 'type', 'date'] });
    await this.persist('cultos', runtime.cultos);
    return cultos.length;
  },

  async rebuildAll() {
    const [s, m, c] = await Promise.all([
      this.rebuildSongs(),
      this.rebuildMedia(),
      this.rebuildCultos(),
    ]);
    try {
      const { SqliteCatalogAdapter } = await import('../adapters/sqlite-catalog-adapter.js');
      await SqliteCatalogAdapter.rebuildIfOnline();
    } catch { /* offline boot */ }
    return { songs: s, media: m, cultos: c };
  },

  search(domain, query, opts) {
    const map = runtime[domain];
    if (!map) return [];
    return searchTokenIndex(map, query, opts);
  },

  invalidate(domain) {
    runtime[domain] = null;
  },
};
