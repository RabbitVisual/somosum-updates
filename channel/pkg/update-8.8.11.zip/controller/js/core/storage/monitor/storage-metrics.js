import { CacheLayer } from '../cache/cache-layer.js';
import { getQueueDepth } from '../../database/save-coordinator.js';
import { transactionManager } from '../../database/transaction-manager.js';

const timings = {
  queries: [],
  writes: [],
  backups: [],
};

function pushTiming(bucket, ms) {
  bucket.push(ms);
  if (bucket.length > 100) bucket.shift();
}

function p95(arr) {
  if (!arr.length) return 0;
  const s = [...arr].sort((a, b) => a - b);
  return s[Math.floor(s.length * 0.95)] || 0;
}

export const StorageMetrics = {
  recordQuery(ms) { pushTiming(timings.queries, ms); },
  recordWrite(ms) { pushTiming(timings.writes, ms); },
  recordBackup(ms) { pushTiming(timings.backups, ms); },

  async fetchServerMetrics() {
    try {
      const res = await fetch('/api/storage/metrics', { cache: 'no-store' });
      return res.ok ? await res.json() : null;
    } catch {
      return null;
    }
  },

  async snapshot(repos = {}) {
    const server = await this.fetchServerMetrics();
    const counts = {};
    for (const [name, repo] of Object.entries(repos)) {
      try {
        if (repo.getAll) counts[name] = (await repo.getAll()).length;
        else if (repo.loadIndex) {
          const idx = await repo.loadIndex();
          counts[name] = idx?.cultos?.length ?? idx?.templates?.length ?? 0;
        }
      } catch { counts[name] = -1; }
    }
    return {
      schemaVersion: 9,
      server,
      counts,
      cache: CacheLayer.snapshot(),
      saveQueue: getQueueDepth(),
      pendingJournal: transactionManager.getPendingJournal?.()?.length ?? 0,
      timings: {
        queryP95Ms: p95(timings.queries),
        writeP95Ms: p95(timings.writes),
        backupP95Ms: p95(timings.backups),
      },
    };
  },
};
