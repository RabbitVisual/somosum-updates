import { DatabaseEngine } from '../../database/database-engine.js';
import { OrphanFixer } from './orphan-fixer.js';
import { cultoRepository } from '../repository/culto-repository.js';
import { mediaRepository } from '../repository/media-repository.js';
import { DiskAdapter } from '../adapters/disk-adapter.js';

export const IntegrityManager = {
  async scan() {
    const integrity = await DatabaseEngine.getIntegrity?.() ?? {};
    const tourKeysRemoved = OrphanFixer.cleanTourKeys();
    return { integrity, tourKeysRemoved, ts: Date.now() };
  },

  async validateCulto(cultoId) {
    const culto = await cultoRepository.get(cultoId);
    const issues = [];
    if (!culto) {
      issues.push({ code: 'missing', message: 'Culto não encontrado' });
      return { ok: false, issues };
    }
    const items = culto.items || [];
    if (!items.length) issues.push({ code: 'empty_slides', message: 'Programa sem itens' });

    const mediaAll = await mediaRepository.getAll();
    const mediaList = Array.isArray(mediaAll) ? mediaAll : Object.keys(mediaAll || {});
    const validIds = new Set(
      Array.isArray(mediaList)
        ? mediaList.map((m) => m.id || m)
        : mediaList,
    );

    for (const item of items) {
      const mid = item.mediaId || item.media?.id;
      if (mid && !validIds.has(mid)) {
        issues.push({ code: 'missing_media', message: `Mídia ausente: ${mid}`, mediaId: mid });
      }
      if (item.slideType === 'bible' && !item.bible?.reference && !item.bible?.book) {
        issues.push({ code: 'invalid_bible', message: 'Referência bíblica incompleta' });
      }
    }

    return { ok: issues.length === 0, issues, cultoId };
  },

  async autoFixCulto(cultoId) {
    const culto = await cultoRepository.get(cultoId);
    if (!culto?.items) return { fixed: 0 };
    const mediaAll = await mediaRepository.getAll();
    const list = Array.isArray(mediaAll) ? mediaAll : Object.values(mediaAll || {});
    const validIds = list.map((m) => m.id).filter(Boolean);
    const { items, fixed } = OrphanFixer.removeMissingMediaRefs(culto.items, validIds);
    if (fixed > 0) {
      await cultoRepository.save(cultoId, items, culto.meta || {});
    }
    return { fixed };
  },

  async verifyDiskPaths(paths) {
    const missing = [];
    for (const p of paths || []) {
      if (!DiskAdapter.isAllowed(p)) continue;
      const data = await DiskAdapter.load(p);
      if (data == null) missing.push(p);
    }
    return { missing, ok: missing.length === 0 };
  },
};
