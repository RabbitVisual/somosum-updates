/** Correções automáticas seguras */
export const OrphanFixer = {
  removeMissingMediaRefs(items, validMediaIds) {
    const valid = new Set(validMediaIds);
    let fixed = 0;
    const next = (items || []).map((item) => {
      const mid = item.mediaId || item.media?.id;
      if (!mid || valid.has(mid)) return item;
      fixed += 1;
      const { mediaId, media, ...rest } = item;
      return rest;
    });
    return { items: next, fixed };
  },

  dedupeById(list, idKey = 'id') {
    const seen = new Set();
    const out = [];
    let dupes = 0;
    for (const row of list || []) {
      const id = row[idKey];
      if (!id || seen.has(id)) { dupes += 1; continue; }
      seen.add(id);
      out.push(row);
    }
    return { items: out, dupes };
  },

  cleanTourKeys() {
    const keys = [];
    for (let v = 2; v <= 10; v += 1) keys.push(`somosum.tour.v${v}.done`);
    keys.push('tour.v2', 'tour.v3', 'tour.v4', 'tour.v5', 'tour.v6');
    let removed = 0;
    for (const k of keys) {
      if (localStorage.getItem(k) != null) {
        localStorage.removeItem(k);
        removed += 1;
      }
    }
    return removed;
  },
};
