/**
 * Storage Platform SSOT — allowlist + domain matrix (7.9.0)
 */
export const STORAGE_SCHEMA_VERSION = 10;

/** Arquivos JSON exatos permitidos em data/ */
export const ALLOWED_EXACT_FILES = [
  'programa.json',
  'letras.json',
  'worship-meta.json',
  'worship-library-backup.json',
  'config.json',
  'meta.json',
  'cultos/index.json',
  'assets/index.json',
  'media/index.json',
  'overlays.json',
  'templates/index.json',
  'avisos/index.json',
  'remote-macros.json',
  'macros.json',
  'bible-history.json',
  'ccli-usage.json',
  '.sync-state.json',
  'indexes/songs.json',
  'indexes/bible.json',
  'indexes/media.json',
  'indexes/cultos.json',
  'shortcuts.json',
  'plugins/index.json',
  'default-hinarios.json',
];

/** JSON opcionais — ausência no disco é normal; espelha StorageAllowlist.OptionalJsonDefaults */
export const OPTIONAL_DISK_DEFAULTS = {
  'remote-macros.json': {},
  'macros.json': {},
  'bible-history.json': { version: 1, entries: [] },
  'ccli-usage.json': { version: 1, entries: [] },
  'worship-meta.json': {
    version: 2,
    categories: [],
    playlists: [],
    lyricsSearchSites: [],
    updatedAt: 0,
  },
  'media/index.json': { version: 2, media: [] },
  'templates/index.json': { templates: [] },
  'assets/index.json': {},
  'cultos/index.json': { version: 2, cultos: [], activeId: null, updatedAt: null },
  'plugins/index.json': { version: 2, plugins: [] },
  'avisos/index.json': { version: 1, items: [] },
  'shortcuts.json': { version: 1, bindings: {} },
  'worship-library-backup.json': { version: 1, savedAt: null, songCount: 0, songs: [], worshipMeta: null },
};

/** Prefixos de path permitidos (sem ..) */
export const ALLOWED_PREFIXES = ['cultos/', 'assets/', 'media/', 'templates/', 'indexes/'];

/** Arquivos de plugin offline — espelha StorageAllowlist */
export const PLUGIN_ENTRY_PATTERN = /^plugins\/[a-z0-9-]+\/plugin\.js$/;
export const PLUGIN_MANIFEST_PATTERN = /^plugins\/[a-z0-9-]+\/manifest\.json$/;
export const PLUGIN_PREFS_PATTERN = /^plugins\/[a-z0-9-]+\/prefs\.json$/;
export const PLUGIN_ASSET_PATTERN = /^plugins\/[a-z0-9-]+\/assets\/[a-zA-Z0-9._-]+\.(css|png|jpg|jpeg|gif|webp|svg)$/;

/**
 * Matrix: domínio → onde persiste
 * disk = SSOT | idb = cache runtime | ls = ephemeral UI only
 */
export const DOMAIN_MATRIX = {
  songs: { disk: 'letras.json', idb: 'songs', repo: 'songs' },
  program: { disk: 'programa.json', idb: 'program', repo: 'program' },
  media: { disk: 'media/index.json', idb: 'media', repo: 'media' },
  assets: { disk: 'assets/index.json', idb: 'assets', repo: 'assets' },
  cultos: { disk: 'cultos/', idb: null, repo: 'cultos' },
  templates: { disk: 'templates/', idb: null, repo: 'templates' },
  overlays: { disk: 'overlays.json', idb: null, repo: 'overlays' },
  avisos: { disk: 'avisos/index.json', idb: null, repo: 'avisos' },
  playlists: { disk: 'worship-meta.json', idb: null, repo: 'playlists' },
  config: { disk: 'config.json', idb: 'meta', repo: 'config', ls: 'somosum-prefs' },
  bibleHistory: { disk: 'bible-history.json', idb: null, repo: 'bible' },
  macros: { disk: 'macros.json', idb: null, repo: 'history' },
  remoteMacros: { disk: 'remote-macros.json', idb: null, repo: 'history' },
  ccli: { disk: 'ccli-usage.json', idb: null, repo: 'history' },
  logs: { disk: null, idb: null, repo: 'logs' },
  users: { disk: null, idb: null, repo: 'users' },
};

export function isAllowedDataPath(fileName) {
  if (!fileName || fileName.includes('..')) return false;
  const n = fileName.replace(/\\/g, '/');
  if (ALLOWED_EXACT_FILES.includes(n)) return true;
  if (PLUGIN_ENTRY_PATTERN.test(n)) return true;
  if (PLUGIN_MANIFEST_PATTERN.test(n)) return true;
  if (PLUGIN_PREFS_PATTERN.test(n)) return true;
  if (PLUGIN_ASSET_PATTERN.test(n)) return true;
  return ALLOWED_PREFIXES.some((p) => n.startsWith(p));
}

export function getDomainForDiskPath(path) {
  const n = String(path || '').replace(/\\/g, '/');
  for (const [domain, cfg] of Object.entries(DOMAIN_MATRIX)) {
    if (!cfg.disk) continue;
    if (cfg.disk === n || (cfg.disk.endsWith('/') && n.startsWith(cfg.disk))) return domain;
  }
  return null;
}
