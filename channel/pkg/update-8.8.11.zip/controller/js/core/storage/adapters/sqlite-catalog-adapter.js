/**
 * Client adapter — catálogo SQLite via Engine (/api/catalog/*)
 */
const DEFAULT_TIMEOUT = 8000;
const REBUILD_TIMEOUT = 90000;

async function fetchJson(path, opts = {}) {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), opts.timeout || DEFAULT_TIMEOUT);
  try {
    const res = await fetch(path, {
      method: opts.method || 'GET',
      headers: opts.body ? { 'Content-Type': 'application/json' } : undefined,
      body: opts.body ? JSON.stringify(opts.body) : undefined,
      cache: 'no-store',
      signal: ctrl.signal,
    });
    if (!res.ok) throw new Error(`catalog ${path} ${res.status}`);
    return await res.json();
  } finally {
    clearTimeout(t);
  }
}

export const SqliteCatalogAdapter = {
  async query(domain, q, { limit = 50 } = {}) {
    const params = new URLSearchParams({ domain, q: q || '', limit: String(limit) });
    return fetchJson(`/api/catalog/query?${params}`);
  },

  async rebuild() {
    return fetchJson('/api/catalog/rebuild', { method: 'POST', body: {}, timeout: REBUILD_TIMEOUT });
  },

  async stats() {
    return fetchJson('/api/catalog/stats');
  },

  async rebuildIfOnline() {
    try {
      const ping = await fetch('/api/ping', { cache: 'no-store' });
      if (!ping.ok) return null;
      return this.rebuild();
    } catch {
      return null;
    }
  },
};
