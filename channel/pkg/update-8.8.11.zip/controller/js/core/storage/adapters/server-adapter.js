/** Re-export utilitários de servidor (não são I/O de domínio JSON) */
export {
  resetServerCache,
  waitForServerBoot,
  waitForServer,
  isServerAvailable,
  logToServer,
  uploadAudioFile,
  saveMediaToDisk,
  saveAssetToDisk,
  deleteMediaFromDisk,
  flushDebouncedDiskWrites,
  dataPublicUrl,
} from '../../file-store.js';
