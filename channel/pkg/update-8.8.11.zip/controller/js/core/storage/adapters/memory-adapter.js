import { MemoryCache } from '../../database/memory-cache.js';

const caches = new Map();

export function getMemoryCache(namespace, max = 200) {
  if (!caches.has(namespace)) caches.set(namespace, new MemoryCache(max));
  return caches.get(namespace);
}

export const MemoryAdapter = {
  getCache: getMemoryCache,
  clearNamespace(ns) {
    caches.delete(ns);
  },
  clearAll() {
    caches.clear();
  },
};
