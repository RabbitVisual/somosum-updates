/**
 * Disk adapter — único caminho para gravação JSON em data/
 */
import {
  loadFromDisk,
  saveToDisk,
  saveToDiskDebounced,
  flushDebouncedDiskWrites as flush,
  isServerAvailable,
} from '../../file-store.js';
import { isAllowedDataPath } from '../schema.js';
import { coordinatedSave } from '../../database/save-coordinator.js';
import { transactionManager } from '../../database/transaction-manager.js';

export const DiskAdapter = {
  isAllowed: isAllowedDataPath,
  load: loadFromDisk,
  save: saveToDisk,
  saveDebounced: saveToDiskDebounced,
  flush,
  isOnline: isServerAvailable,

  async saveCoordinated(label, path, data, opts = {}) {
    if (!isAllowedDataPath(path)) throw new Error(`Path not allowed: ${path}`);
    return coordinatedSave(label, () => saveToDisk(path, data, opts), opts);
  },

  async saveTransactional(label, path, data, { rollbackFn = null, ...opts } = {}) {
    const snapshot = rollbackFn ? await loadFromDisk(path) : null;
    return transactionManager.commit([
      {
        label,
        run: () => this.saveCoordinated(label, path, data, opts),
        rollback: rollbackFn || (snapshot != null
          ? () => saveToDisk(path, snapshot, { silent: true })
          : null),
      },
    ]);
  },
};
