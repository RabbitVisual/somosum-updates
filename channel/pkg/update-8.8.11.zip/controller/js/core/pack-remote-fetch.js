/**
 * Download offline-first de pacotes ZIP (local → GitHub/CDN).
 */
import { readResponseWithProgress } from '../worship/hinario-pack-unzip.js';
import { isOnline } from '../plugins/plugin-pack-errors.js';
import { fetchCatalog } from './catalog-proxy-fetch.js';

export function remotePackUrl(manifest, pack, fileName = null) {
  const base = String(manifest?.cdnBaseUrl || '').trim().replace(/\/+$/, '');
  if (!base) return null;
  const file = fileName || pack?.file;
  const path = pack?.remotePath || file;
  if (!path) return null;
  return `${base}/${String(path).replace(/^\/+/, '')}`;
}

/**
 * @param {object} opts
 * @param {object} opts.manifest
 * @param {object} opts.pack
 * @param {string} opts.localUrl — ex. /content/packs/plugins/foo.zip
 * @param {(phase: string, pct: number) => void} [opts.onProgress]
 * @returns {Promise<Uint8Array>}
 */
export async function fetchPackBytes({ manifest, pack, localUrl, onProgress }) {
  onProgress?.('download', 0);

  if (!pack?.remoteOnly) {
    try {
      const localRes = await fetch(localUrl, { cache: 'no-store' });
      if (localRes.ok) {
        return readResponseWithProgress(localRes, (pct) => onProgress?.('download', pct));
      }
    } catch { /* tenta remoto */ }
  }

  const remoteUrl = remotePackUrl(manifest, pack);
  if (remoteUrl && isOnline()) {
    const remoteRes = await fetchCatalog(remoteUrl);
    if (remoteRes.ok) {
      return readResponseWithProgress(remoteRes, (pct) => onProgress?.('download', pct));
    }
    throw new Error(`pack_fetch_remote_${remoteRes.status}`);
  }

  if (!isOnline() && pack?.remoteOnly) throw new Error('network_offline');
  throw new Error(`pack_fetch_404:${pack?.file || 'unknown'}`);
}

export async function postPackBytes(url, bytes, { secureFetch } = {}) {
  const fetchFn = secureFetch || fetch;
  const res = await fetchFn(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/octet-stream' },
    body: bytes,
  });
  if (!res.ok) {
    const t = await res.text().catch(() => '');
    throw new Error(t || `post_bytes_${res.status}`);
  }
  return res.json();
}

/**
 * Instala pack: tenta arquivo local via API; se 404, baixa remoto e install-bytes.
 */
export async function installPackWithRemoteFallback({
  manifest,
  pack,
  localUrl,
  installUrl,
  installBytesUrl,
  onProgress,
  secureFetch,
}) {
  onProgress?.('download', 5);
  const qs = new URLSearchParams({ file: pack.file });
  if (pack.sha256) qs.set('sha256', pack.sha256);

  const fetchFn = secureFetch || fetch;
  let res = await fetchFn(`${installUrl}?${qs}`, { method: 'POST' });
  if (res.ok) return res.json();

  const errText = await res.text().catch(() => '');
  const hashMismatch = /hash_mismatch/i.test(errText);
  const needsRemote = res.status === 404 || /pack_not_found/i.test(errText) || hashMismatch;
  if (!needsRemote) throw new Error(errText || `install_failed_${res.status}`);

  // hash_mismatch: ZIP local costuma estar certo (com assets); ignora sha remoto stale.
  const bytes = await fetchPackBytes({ manifest, pack, localUrl, onProgress });
  onProgress?.('extract', 55);
  const bytesQs = new URLSearchParams({ file: pack.file });
  if (!hashMismatch && pack.sha256) bytesQs.set('sha256', pack.sha256);
  return postPackBytes(`${installBytesUrl}?${bytesQs}`, bytes, { secureFetch: fetchFn });
}
