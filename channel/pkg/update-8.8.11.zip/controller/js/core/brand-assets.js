/** Identidade visual oficial do produto SOMOSUM (fonte única). */
/** PRODUCT_* = chrome do sistema (Painel, favicon, EXE). Nunca trocar por upload da igreja. */
/** Projeção / Boas-vindas / slides → resolveChurchLogoUrl() (upload dinâmico ou default oficial). */
export const PRODUCT_LOGO = '/IMG/LOGO/SOMOSUM.png';
export const PRODUCT_LOGO_REL = 'IMG/LOGO/SOMOSUM.png';
export const PRODUCT_COVER = '/IMG/CAPA-SOMOSUM.svg';
export const PRODUCT_COVER_REL = 'IMG/CAPA-SOMOSUM.svg';
export const PRODUCT_FAVICON_ICO = '/launcher/somosum.ico';
export const PRODUCT_NAME = 'SOMOS UM';
export const PRODUCT_TAGLINE = 'Sistema de projeção para cultos';

/** Paths legados substituídos pela logo oficial. */
export const LEGACY_LOGO_PATHS = [
  '/IMG/LOGO/cbav-logo.png',
  'IMG/LOGO/cbav-logo.png',
  '/IMG/LOGO/LOGO.png',
  'IMG/LOGO/LOGO.png',
];

export function isLegacyProductLogo(path) {
  const p = String(path || '').trim();
  if (!p) return true;
  return LEGACY_LOGO_PATHS.some((legacy) => p === legacy || p.endsWith(legacy.replace(/^\//, '')));
}

/** Garante favicon ICO + PNG no <head> (DevTools, abas, PWA). */
export function ensureProductFavicons(doc = document) {
  const head = doc?.head;
  if (!head) return;
  const specs = [
    { rel: 'icon', href: PRODUCT_FAVICON_ICO, type: 'image/x-icon', sizes: 'any' },
    { rel: 'icon', href: PRODUCT_LOGO, type: 'image/png' },
    { rel: 'apple-touch-icon', href: PRODUCT_LOGO, type: 'image/png' },
    { rel: 'shortcut icon', href: PRODUCT_FAVICON_ICO, type: 'image/x-icon' },
  ];
  specs.forEach(({ rel, href, type, sizes }) => {
    const key = rel === 'icon' ? `${rel}:${type || ''}` : rel;
    const existing = [...head.querySelectorAll(`link[rel="${rel}"]`)].find((el) => {
      if (rel === 'icon' && type) return el.getAttribute('type') === type;
      if (rel === 'icon' && sizes) return el.getAttribute('sizes') === sizes;
      return !type && !sizes;
    });
    if (existing) {
      if (existing.getAttribute('href') !== href) existing.setAttribute('href', href);
      return;
    }
    const link = doc.createElement('link');
    link.rel = rel;
    link.href = href;
    if (type) link.type = type;
    if (sizes) link.sizes = sizes;
    head.appendChild(link);
  });
}
