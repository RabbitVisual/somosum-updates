/**
 * CacheManager — revision unificada entre superfícies e Service Worker.
 */
const LS_KEY = 'somosum.shell.assetRevision';

export function getStoredRevision() {
  try {
    return localStorage.getItem(LS_KEY) || '';
  } catch {
    return '';
  }
}

export function setStoredRevision(revision) {
  try {
    if (revision) localStorage.setItem(LS_KEY, revision);
  } catch { /* ignore */ }
}

export function cacheNameForRevision(revision) {
  return `somosum-shell-v${revision || '0'}`;
}

export async function notifyServiceWorker(revision) {
  if (!('serviceWorker' in navigator)) return;
  try {
    const reg = await navigator.serviceWorker.ready.catch(() => null);
    if (reg?.active) {
      reg.active.postMessage({ type: 'SET_REVISION', revision });
    }
  } catch { /* ignore */ }
}

export async function registerServiceWorker(swPath, revision) {
  if (!('serviceWorker' in navigator)) return null;
  const url = swPath.includes('?') ? swPath : `${swPath}?v=${encodeURIComponent(revision)}`;
  try {
    const reg = await navigator.serviceWorker.register(url);
    await notifyServiceWorker(revision);
    try { reg.update(); } catch { /* ignore */ }
    return reg;
  } catch {
    return null;
  }
}

/**
 * Garante cache coerente após update do EXE.
 * @returns {{ changed: boolean, revision: string }}
 */
export async function ensureFresh(meta) {
  const revision = meta?.assetRevision || meta?.version || '';
  const prev = getStoredRevision();
  const changed = Boolean(prev && revision && prev !== revision);

  setStoredRevision(revision);
  await notifyServiceWorker(revision);

  if (changed && meta?.surfaces?.remote) {
    window.dispatchEvent(new CustomEvent('somosum-asset-revision-changed', {
      detail: { from: prev, to: revision },
    }));
  }

  return { changed, revision };
}

export async function clearStaleCaches(currentRevision) {
  if (!('caches' in window)) return;
  const keep = cacheNameForRevision(currentRevision);
  try {
    const keys = await caches.keys();
    await Promise.all(
      keys
        .filter((k) => k.startsWith('somosum-shell-v') && k !== keep)
        .map((k) => caches.delete(k)),
    );
  } catch { /* ignore */ }
}

if (typeof window !== 'undefined') {
  window.SOMOSUM_CACHE_MANAGER = {
    ensureFresh,
    getStoredRevision,
    setStoredRevision,
    cacheNameForRevision,
    registerServiceWorker,
    clearStaleCaches,
  };
}
