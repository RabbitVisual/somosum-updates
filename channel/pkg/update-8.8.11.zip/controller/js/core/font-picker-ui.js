/**
 * Seletor família + variante (Bold, SemiBold, Italic…) — pasta fonts/ e sistema.
 */
import {
  fontPickerOptionsHtml,
  fontVariantOptionsHtml,
  fontVariantKey,
  parseFontVariantKey,
  getVariantsForFamily,
  fetchFontCatalog,
} from './fonts.js';

/**
 * HTML dos dois selects (família + categoria/peso).
 * @param {string} family
 * @param {{ familyId?: string, variantId?: string, fontWeight?: number, fontStyle?: string, includeEmpty?: boolean, extra?: string[] }} opts
 */
export function fontPickerPairHtml(family = '', opts = {}) {
  const {
    familyId = 'font-family',
    variantId = 'font-variant',
    fontWeight,
    fontStyle,
    includeEmpty = true,
    extra = [],
  } = opts;
  const variants = getVariantsForFamily(family);
  const onlyRegular = variants.length === 1 && variants[0]?.key === '400:normal';
  const showVariant = !!family && !onlyRegular;
  return `
    <div class="font-picker-pair">
      <select id="${familyId}" class="font-select font-family-select" aria-label="Família da fonte">
        ${fontPickerOptionsHtml(family, { includeEmpty, extra })}
      </select>
      <select id="${variantId}" class="font-select font-variant-select" aria-label="Estilo da fonte"
        ${showVariant ? '' : 'hidden'}>
        ${fontVariantOptionsHtml(family, fontWeight, fontStyle)}
      </select>
    </div>`;
}

export function readFontPickerPair(root, {
  familySelector = '.font-family-select',
  variantSelector = '.font-variant-select',
} = {}) {
  const familyEl = root?.querySelector?.(familySelector)
    || (familySelector.startsWith('#') ? document.getElementById(familySelector.slice(1)) : null);
  const variantEl = root?.querySelector?.(variantSelector)
    || (variantSelector.startsWith('#') ? document.getElementById(variantSelector.slice(1)) : null);
  const family = familyEl?.value || null;
  if (!family) {
    return { fontFamily: null, fontWeight: null, fontStyle: null };
  }
  const parsed = parseFontVariantKey(variantEl?.value);
  return {
    fontFamily: family,
    fontWeight: parsed.weight,
    fontStyle: parsed.style,
  };
}

function syncVariantSelect(variantEl, family, weight, style) {
  if (!variantEl) return;
  const variants = getVariantsForFamily(family);
  if (!family || !variants.length) {
    variantEl.hidden = true;
    variantEl.innerHTML = '';
    return;
  }
  variantEl.innerHTML = fontVariantOptionsHtml(family, weight, style);
  const onlyRegular = variants.length === 1 && variants[0].key === '400:normal';
  variantEl.hidden = !family || onlyRegular;
  if (!variantEl.value && variants.length) {
    variantEl.value = variants[0].key;
  }
}

/**
 * Liga família → repopula variantes; dispara onChange em ambos.
 */
export function bindFontPickerPair(root, {
  familySelector = '.font-family-select',
  variantSelector = '.font-variant-select',
  onChange,
} = {}) {
  if (!root) return;
  const familyEl = root.querySelector(familySelector);
  const variantEl = root.querySelector(variantSelector);
  if (!familyEl || !variantEl) return;

  const refresh = (resetVariant = false) => {
    const family = familyEl.value;
    let { weight, style } = parseFontVariantKey(variantEl.value);
    if (resetVariant) {
      const first = getVariantsForFamily(family)[0];
      if (first) {
        weight = first.weight;
        style = first.style;
      }
    }
    syncVariantSelect(variantEl, family, weight, style);
  };

  familyEl.addEventListener('change', () => {
    refresh(true);
    onChange?.();
  });
  variantEl.addEventListener('change', () => onChange?.());

  void fetchFontCatalog().then(() => refresh(false)).catch(() => refresh(false));
}
