/** Tipografia fluida para projeção — área, aspecto, DPI e contagem de linhas. */

function clamp(n, min, max) {
  return Math.max(min, Math.min(max, n));
}

/**
 * Busca binária de font-size (padrão Holyrics) — encaixa texto em caixa sem thrash linear.
 * @returns {number} px
 */
export function fitFontSizeBinarySearch({
  measureEl,
  text = '',
  maxWidth,
  maxHeight,
  minPx = 28,
  maxPx = 160,
  lineHeight = 1.4,
} = {}) {
  if (!measureEl || !maxWidth || !maxHeight) return minPx;
  const sample = String(text || 'Ag').trim() || 'Ag';
  let lo = minPx;
  let hi = maxPx;
  let best = minPx;

  const fits = (px) => {
    measureEl.style.fontSize = `${px}px`;
    measureEl.style.lineHeight = String(lineHeight);
    measureEl.textContent = sample;
    const rect = measureEl.getBoundingClientRect();
    return rect.width <= maxWidth && rect.height <= maxHeight;
  };

  while (lo <= hi) {
    const mid = Math.floor((lo + hi) / 2);
    if (fits(mid)) {
      best = mid;
      lo = mid + 1;
    } else {
      hi = mid - 1;
    }
  }
  return best;
}

function aspectFactor(aspect) {
  const a = String(aspect || '16:9');
  if (a === '4:3' || a === '4x3') return 1.14;
  if (a === '16:10' || a === '16x10') return 1.06;
  if (a === '21:9' || a === '21x9' || a === 'ultrawide') return 0.96;
  return 1.0;
}

export function computeTypography({
  viewportW = 1920,
  viewportH = 1080,
  lineCount = 3,
  maxCharsPerLine = 42,
  dpiScale = 1,
  aspectRatio = '16:9',
  operatorFontSize = 54,
  preferOperatorFont = false,
  fontBoost = 1.1,
  profile = null,
  safeArea = null,
  maxLegibility = false,
} = {}) {
  const area = viewportW * viewportH;
  const kAspect = aspectFactor(aspectRatio);
  const kDpi = dpiScale > 1.1 ? 1 / Math.sqrt(dpiScale) : 1;
  const safeShrink = safeArea
    ? 1 - (Math.max(safeArea.top, safeArea.bottom) + Math.max(safeArea.left, safeArea.right)) / 200
    : 1;

  const baseSize = Math.sqrt(area) * 0.028 * kAspect * kDpi * safeShrink;
  const lineFactor = clamp(3 / Math.max(1, lineCount), 0.72, 1.35);
  const charFactor = clamp(42 / Math.max(12, maxCharsPerLine), 0.85, 1.15);
  const boost = profile?.fontBoost || fontBoost;

  let size = baseSize * lineFactor * charFactor * boost;
  const min = profile?.typographyMin || 32;
  const max = profile?.typographyMax || 140;
  size = clamp(size, min, max);

  if (maxLegibility || profile?.maxLegibility || aspectRatio === '4:3') {
    const legibilityFloor = aspectRatio === '4:3' ? 64 : 52;
    size = Math.max(size, legibilityFloor);
  }

  const operatorClamp = clamp(operatorFontSize, min, max);
  // Inspetor / item: respeita o tamanho escolhido (com boost do projetor)
  if (preferOperatorFont) {
    size = clamp(operatorClamp * Math.min(boost, 1.25), min, max);
  } else {
    size = clamp((size + operatorClamp) / 2, min, max);
  }

  return {
    fontSizePx: Math.round(size),
    lineHeight: lineCount >= 4 ? 1.35 : 1.45,
    fontBoost: boost,
  };
}

export function applyTypographyVars(target, typography) {
  if (!target || !typography) return;
  target.style.setProperty('--dpe-lyrics-font-size', `${typography.fontSizePx}px`);
  target.style.setProperty('--dpe-font-boost', String(typography.fontBoost));
  target.style.setProperty('--dpe-line-height', String(typography.lineHeight));
  applyProjectionTypographyTokens(target, typography);
}

/** Tokens tipográficos de projeção — min / preferred / max. */
export function applyProjectionTypographyTokens(target, typography) {
  if (!target || !typography) return;
  const preferred = typography.fontSizePx || 54;
  const min = Math.max(28, Math.round(preferred * 0.72));
  const max = Math.min(160, Math.round(preferred * 1.35));
  const title = Math.round(preferred * 1.55);
  const secondary = Math.round(preferred * 0.78);
  const footer = Math.round(preferred * 0.62);

  target.style.setProperty('--projection-lyrics-size', `${preferred}px`);
  target.style.setProperty('--projection-title-size', `${title}px`);
  target.style.setProperty('--projection-secondary-size', `${secondary}px`);
  target.style.setProperty('--projection-footer-size', `${footer}px`);
  target.style.setProperty('--projection-lyrics-min', `${min}px`);
  target.style.setProperty('--projection-lyrics-max', `${max}px`);
  target.style.setProperty('--projection-lyrics-preferred', `${preferred}px`);
}
