/** Cliente do MediaConverter (POST /api/media/convert + poll status). */
import { dataPublicUrl } from './data-public-url.js';

const POLL_MS = 400;
const MAX_WAIT_MS = 15 * 60 * 1000;

export async function getConverterInfo() {
  try {
    const res = await fetch('/api/media/converter-info', { cache: 'no-store' });
    if (!res.ok) return { available: false };
    return await res.json();
  } catch {
    return { available: false };
  }
}

export async function fetchSystemMediaIndex() {
  try {
    const res = await fetch('/api/media/system', { cache: 'no-store' });
    if (!res.ok) return { version: 1, media: [] };
    return await res.json();
  } catch {
    return { version: 1, media: [] };
  }
}

/**
 * Envia arquivo bruto para conversão canônica.
 * @returns {Promise<{id, name, kind, category, mimeType, path, sizeBytes, src, converted: true}>}
 */
export async function convertAndSaveMediaFile(file, { category, onProgress } = {}) {
  if (!file) throw new Error('Arquivo inválido');
  const info = await getConverterInfo();
  if (!info?.available) {
    throw new Error('Conversor indisponível (ffmpeg). Instale app/tools/ffmpeg.');
  }

  const id = (crypto?.randomUUID?.() || `${Date.now()}-${Math.random().toString(16).slice(2)}`);
  const name = String(file.name || 'midia').replace(/\.[^.]+$/, '');
  const mimeType = file.type || 'application/octet-stream';
  const cat = category || (mimeType.startsWith('video/') || /\.gif$/i.test(file.name) ? 'video' : 'image');

  const qs = new URLSearchParams({
    id,
    name,
    mimeType,
    category: cat,
    fileName: file.name || name,
  });

  const res = await fetch(`/api/media/convert?${qs}`, {
    method: 'POST',
    body: file,
    headers: {
      'Content-Type': mimeType || 'application/octet-stream',
    },
  });
  const start = await res.json().catch(() => ({}));
  if (!res.ok || !start.ok) {
    throw new Error(start.error || `Falha ao enfileirar conversão (${res.status})`);
  }

  const jobId = start.jobId;
  const t0 = Date.now();
  while (Date.now() - t0 < MAX_WAIT_MS) {
    await sleep(POLL_MS);
    const stRes = await fetch(`/api/media/convert-status?jobId=${encodeURIComponent(jobId)}`, { cache: 'no-store' });
    const st = await stRes.json().catch(() => ({}));
    if (typeof onProgress === 'function') {
      onProgress({
        jobId,
        mediaId: id,
        status: st.status,
        progress: st.progress || 0,
        name,
      });
    }
    if (st.status === 'done') {
      const kind = st.kind || (String(st.mimeType || '').startsWith('video/') ? 'video' : 'image');
      const path = st.path || `media/${id}.${kind === 'video' ? 'mp4' : 'webp'}`;
      return {
        id,
        name: st.name || name,
        kind,
        category: st.category || cat,
        mimeType: st.mimeType || (kind === 'video' ? 'video/mp4' : 'image/webp'),
        path,
        sizeBytes: st.outputBytes || null,
        inputBytes: st.inputBytes || null,
        src: dataPublicUrl(path.replace(/^data\//, '')),
        converted: true,
        tags: [],
      };
    }
    if (st.status === 'error') {
      throw new Error(st.error || 'Conversão falhou');
    }
  }
  throw new Error('Timeout na conversão');
}

function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}
