/**
 * Backup restore com snapshot de rollback e validação completa.
 */
import { validateBackupPayload } from './json-validator.js';
import { coordinatedSave } from '../database/save-coordinator.js';
import { DatabaseEngine } from '../database/database-engine.js';
import { exportBackup, importBackupCore } from '../store.js';
import { LogService, LogCategory } from '../logging/log-service.js';

const ROLLBACK_KEY = 'somosum-import-rollback';

export async function createRollbackSnapshot() {
  const snap = await exportBackup();
  const checksum = await import('./json-validator.js').then((m) => m.computeBackupChecksum(snap));
  const payload = { ...snap, checksum, rollbackAt: new Date().toISOString() };
  try {
    localStorage.setItem(ROLLBACK_KEY, JSON.stringify(payload));
  } catch {
    await fetch('/api/save?file=meta.json', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ lastRollback: payload.exportedAt }),
    }).catch(() => {});
  }
  return payload;
}

export async function restoreRollbackSnapshot() {
  const raw = localStorage.getItem(ROLLBACK_KEY);
  if (!raw) throw new Error('Nenhum snapshot de rollback disponível.');
  const data = JSON.parse(raw);
  const validation = await validateBackupPayload(data);
  if (!validation.ok) throw new Error(`Rollback inválido: ${validation.errors.join(', ')}`);
  await coordinatedSave('rollback-restore', () => importBackupCore(data), { priority: 100 });
  LogService.info('Rollback restaurado', { module: 'backup-validator', category: LogCategory.DATABASE });
  return true;
}

export async function importBackupSafe(data, { partial = false } = {}) {
  const validation = await validateBackupPayload(data);
  if (!validation.ok) {
    throw new Error(`Backup rejeitado: ${validation.errors.join(', ')}`);
  }
  await createRollbackSnapshot();
  try {
    if (partial) {
      const filtered = { ...data, version: data.version || 5 };
      if (!filtered.songs) delete filtered.songs;
      if (!filtered.program) delete filtered.program;
      if (!filtered.media) delete filtered.media;
      if (!filtered.prefs) delete filtered.prefs;
      await coordinatedSave('import-partial', () => importBackupCore(filtered), { priority: 50 });
    } else {
      await coordinatedSave('import-full', () => importBackupCore(data), { priority: 50 });
    }
    await DatabaseEngine.getIntegrity();
    localStorage.removeItem(ROLLBACK_KEY);
    return { ok: true, validation };
  } catch (err) {
    LogService.error('Import falhou — tentando rollback', {
      module: 'backup-validator',
      category: LogCategory.DATABASE,
      err,
    });
    try {
      await restoreRollbackSnapshot();
    } catch (rollbackErr) {
      throw new Error(`Import falhou e rollback também: ${rollbackErr.message}`);
    }
    throw err;
  }
}
