/**
 * Validação estrutural de JSON e entidades SOMOSUM.
 */
import { SCHEMA_VERSION } from '../database/schema.js';

const MAX_BACKUP_BYTES = 120 * 1024 * 1024;
const MAX_SONGS = 10000;
const MAX_MEDIA = 5000;
const MAX_PROGRAM_ITEMS = 500;

export function validateSongEntity(song) {
  if (!song || typeof song !== 'object') return { ok: false, reason: 'song_invalid' };
  if (typeof song.id !== 'string' || !song.id) return { ok: false, reason: 'song_id' };
  if (typeof song.title !== 'string') return { ok: false, reason: 'song_title' };
  if (song.lyrics != null && typeof song.lyrics !== 'string') return { ok: false, reason: 'song_lyrics' };
  return { ok: true };
}

export function validateProgramEntity(items) {
  if (!Array.isArray(items)) return { ok: false, reason: 'program_not_array' };
  if (items.length > MAX_PROGRAM_ITEMS) return { ok: false, reason: 'program_too_large' };
  for (const item of items) {
    if (!item || typeof item !== 'object') return { ok: false, reason: 'program_item' };
    if (typeof item.id !== 'string') return { ok: false, reason: 'program_item_id' };
    if (typeof item.slideType !== 'string') return { ok: false, reason: 'program_item_type' };
  }
  return { ok: true };
}

export function validateMediaEntity(item) {
  if (!item || typeof item !== 'object') return { ok: false, reason: 'media_invalid' };
  if (typeof item.id !== 'string' || !item.id) return { ok: false, reason: 'media_id' };
  if (typeof item.name !== 'string') return { ok: false, reason: 'media_name' };
  return { ok: true };
}

export function validatePrefsEntity(prefs) {
  if (!prefs || typeof prefs !== 'object') return { ok: false, reason: 'prefs_invalid' };
  if (prefs.theme != null && typeof prefs.theme !== 'string') return { ok: false, reason: 'prefs_theme' };
  return { ok: true };
}

export async function computeBackupChecksum(data) {
  const json = JSON.stringify(data);
  const buf = new TextEncoder().encode(json);
  const hash = await crypto.subtle.digest('SHA-256', buf);
  return Array.from(new Uint8Array(hash)).map((b) => b.toString(16).padStart(2, '0')).join('');
}

export async function validateBackupPayload(data, { maxBytes = MAX_BACKUP_BYTES } = {}) {
  if (!data || typeof data !== 'object') return { ok: false, reason: 'empty', errors: ['empty'] };
  const errors = [];
  if (!data.version || data.version < 1 || data.version > 5) errors.push('version');
  if (data.songs) {
    if (!Array.isArray(data.songs)) errors.push('songs_not_array');
    else if (data.songs.length > MAX_SONGS) errors.push('songs_too_many');
    else data.songs.forEach((s, i) => {
      const v = validateSongEntity(s);
      if (!v.ok) errors.push(`song_${i}_${v.reason}`);
    });
  }
  if (data.program) {
    const v = validateProgramEntity(data.program);
    if (!v.ok) errors.push(v.reason);
  }
  if (data.prefs) {
    const v = validatePrefsEntity(data.prefs);
    if (!v.ok) errors.push(v.reason);
  }
  if (data.media) {
    if (!Array.isArray(data.media)) errors.push('media_not_array');
    else if (data.media.length > MAX_MEDIA) errors.push('media_too_many');
    else data.media.forEach((m, i) => {
      const v = validateMediaEntity(m);
      if (!v.ok) errors.push(`media_${i}_${v.reason}`);
    });
  }
  const size = new TextEncoder().encode(JSON.stringify(data)).length;
  if (size > maxBytes) errors.push('payload_too_large');
  if (data.checksum) {
    const { checksum, ...rest } = data;
    const computed = await computeBackupChecksum(rest);
    if (computed !== checksum) errors.push('checksum_mismatch');
  }
  return {
    ok: errors.length === 0,
    reason: errors[0] || null,
    errors,
    schemaVersion: SCHEMA_VERSION,
    sizeBytes: size,
  };
}

export function sanitizeJsonInput(raw) {
  if (typeof raw === 'string') {
    if (raw.length > MAX_BACKUP_BYTES) throw new Error('JSON excede tamanho máximo permitido.');
    return JSON.parse(raw);
  }
  return raw;
}
