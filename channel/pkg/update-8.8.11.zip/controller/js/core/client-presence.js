import { randomId } from './uuid.js';
import { TaskScheduler } from './task-scheduler.js';
import { TaskIds } from './task-registry.js';

const STORAGE_ID = 'somosum-stage-client-id';
const SCREEN_STORAGE_ID = 'somosum-screen-client-id';
const REMOTE_STORAGE_ID = 'somosum-remote-client-id';
const DEVICE_FINGERPRINT_KEY = 'somosum-device-fingerprint';
const DEVICE_ID_KEY = 'somosum-device-id';
const STORAGE_LABEL = 'somosum-stage-device-label';
const REMOTE_LABEL_KEY = 'somosum-remote-device-label';

function getScreenOutput() {
  try {
    const qs = new URLSearchParams(location.search);
    const raw = qs.get('output');
    const n = Number(raw);
    return Number.isFinite(n) && n > 1 ? String(Math.floor(n)) : '1';
  } catch {
    return '1';
  }
}

/** Identidade estável do aparelho físico — usada em pareamento e anti-duplicata. */
export function getDeviceFingerprint() {
  try {
    let id = localStorage.getItem(DEVICE_FINGERPRINT_KEY);
    if (!id) {
      id = randomId();
      localStorage.setItem(DEVICE_FINGERPRINT_KEY, id);
    }
    return id;
  } catch {
    return randomId();
  }
}

export function getStoredDeviceId() {
  try {
    return localStorage.getItem(DEVICE_ID_KEY) || '';
  } catch {
    return '';
  }
}

export function setStoredDeviceId(deviceId) {
  try {
    const v = String(deviceId || '').trim();
    if (v) localStorage.setItem(DEVICE_ID_KEY, v);
    else localStorage.removeItem(DEVICE_ID_KEY);
    return v;
  } catch {
    return '';
  }
}

export function getRemoteDeviceLabel() {
  try {
    return localStorage.getItem(REMOTE_LABEL_KEY) || '';
  } catch {
    return '';
  }
}

export function setRemoteDeviceLabel(label) {
  try {
    const v = String(label || '').trim().slice(0, 48);
    if (v) localStorage.setItem(REMOTE_LABEL_KEY, v);
    else localStorage.removeItem(REMOTE_LABEL_KEY);
    return v;
  } catch {
    return '';
  }
}

export function getStageClientId() {
  try {
    let id = localStorage.getItem(STORAGE_ID);
    if (!id) {
      id = randomId();
      localStorage.setItem(STORAGE_ID, id);
    }
    return id;
  } catch {
    return randomId();
  }
}

export function getRemoteClientId() {
  try {
    let id = localStorage.getItem(REMOTE_STORAGE_ID);
    if (!id) {
      id = randomId();
      localStorage.setItem(REMOTE_STORAGE_ID, id);
    }
    return id;
  } catch {
    return randomId();
  }
}

export function getScreenClientId() {
  const output = getScreenOutput();
  const key = output === '1' ? SCREEN_STORAGE_ID : `${SCREEN_STORAGE_ID}-${output}`;
  try {
    let id = localStorage.getItem(key);
    if (!id) {
      id = randomId();
      localStorage.setItem(key, id);
    }
    return output === '1' ? id : `${id}-out${output}`;
  } catch {
    return output === '1' ? randomId() : `${randomId()}-out${output}`;
  }
}

export function getStageDeviceLabel() {
  try {
    return localStorage.getItem(STORAGE_LABEL) || '';
  } catch {
    return '';
  }
}

export function setStageDeviceLabel(label) {
  try {
    const v = String(label || '').trim().slice(0, 48);
    if (v) localStorage.setItem(STORAGE_LABEL, v);
    else localStorage.removeItem(STORAGE_LABEL);
    return v;
  } catch {
    return '';
  }
}

export async function postClientPresence({ clientId, role = 'stage', label = '', meta = {}, deviceFingerprint, deviceId } = {}) {
  try {
    const fp = deviceFingerprint || getDeviceFingerprint();
    await fetch('/api/clients/presence', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json; charset=utf-8' },
      body: JSON.stringify({
        clientId,
        role,
        label,
        deviceFingerprint: fp,
        deviceId: deviceId || getStoredDeviceId(),
        meta: { deviceFingerprint: fp, ...meta },
      }),
      signal: AbortSignal.timeout(4000),
    });
  } catch { /* offline */ }
}

export async function fetchClientPresence(maxAgeMs = 30000) {
  try {
    const res = await fetch(`/api/clients/presence?maxAge=${maxAgeMs}`, { cache: 'no-store' });
    if (!res.ok) return [];
    const data = await res.json();
    return data.clients || [];
  } catch {
    return [];
  }
}

export async function fetchClientRegistry(maxAgeMs = 60000) {
  try {
    const res = await fetch(`/api/clients/registry?maxAge=${maxAgeMs}`, { cache: 'no-store' });
    if (!res.ok) return null;
    return res.json();
  } catch {
    return null;
  }
}

export function startPresenceHeartbeat(getMeta = () => ({})) {
  const clientId = getStageClientId();
  const tick = () => {
    const label = getStageDeviceLabel();
    const meta = typeof getMeta === 'function' ? getMeta() : {};
    postClientPresence({
      clientId,
      role: 'stage',
      label: label || inferDeviceLabel(),
      meta: {
        viewport: { w: window.innerWidth, h: window.innerHeight },
        ...meta,
      },
    });
  };
  tick();
  return TaskScheduler.register({
    id: TaskIds.CLIENT_PRESENCE,
    kind: 'interval',
    intervalMs: 5000,
    priority: 8,
    runWhenHidden: true,
    fn: tick,
  });
}

/** Heartbeat HTTP do Remote (celular) — aparece no Painel Gerencial. */
export function startRemotePresenceHeartbeat(getMeta = () => ({})) {
  const clientId = getRemoteClientId();
  const tick = () => {
    const label = getRemoteDeviceLabel() || inferDeviceLabel();
    const meta = typeof getMeta === 'function' ? getMeta() : {};
    postClientPresence({
      clientId,
      role: 'remote',
      label,
      meta: {
        viewport: { w: window.innerWidth, h: window.innerHeight },
        ...meta,
      },
    });
  };
  tick();
  return TaskScheduler.register({
    id: TaskIds.REMOTE_PRESENCE,
    kind: 'interval',
    intervalMs: 5000,
    priority: 8,
    runWhenHidden: true,
    fn: tick,
  });
}

/** Heartbeat HTTP da tela de projeção — controle detecta mesmo se sync falhar. */
export function startScreenPresenceHeartbeat(getMeta = () => ({})) {
  const clientId = getScreenClientId();
  const output = getScreenOutput();
  const tick = () => {
    const meta = typeof getMeta === 'function' ? getMeta() : {};
    postClientPresence({
      clientId,
      role: 'screen',
      label: output === '1' ? 'Projetor' : `Projetor ${output}`,
      meta: {
        viewport: { w: window.innerWidth, h: window.innerHeight },
        output: Number(output) || 1,
        ...meta,
      },
    });
  };
  tick();
  return TaskScheduler.register({
    id: output === '1' ? TaskIds.SCREEN_PRESENCE : `${TaskIds.SCREEN_PRESENCE}-${output}`,
    kind: 'interval',
    intervalMs: 4000,
    priority: 3,
    runWhenHidden: true,
    fn: tick,
  });
}

function inferDeviceLabel() {
  const w = window.innerWidth;
  if (w < 520) return 'Celular';
  if (w < 900) return 'Tablet';
  return 'Monitor';
}
