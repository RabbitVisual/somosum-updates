/**
 * Ícones globais SOMOSUM — Font Awesome Pro Duotone (local).
 * Use faIcon / faIconRaw para HTML; faClass para class string.
 */

/** Navegação principal do Controle */
export const SU_NAV = {
  cultos: 'calendar-days',
  program: 'list-timeline',
  live: 'list-timeline',
  lyrics: 'music',
  media: 'photo-film',
  bible: 'book-bible',
  library: 'books',
  designer: 'paintbrush-pencil',
  settings: 'gear',
  'plugin-store': 'puzzle-piece',
  /* Plugins (Plugin Studio rail) */
  pix: 'qrcode',
  moments: 'bolt',
  verse: 'book-open',
  tips: 'message-lines',
  stamp: 'stamp',
  diary: 'notebook',
  timer: 'stopwatch',
  alert: 'bell-on',
  puzzle: 'puzzle-piece',
  prayer: 'hands-praying',
  hymn: 'music',
  qr: 'qrcode',
  birthday: 'cake-candles',
  cake: 'cake-candles',
  agenda: 'calendar-days',
  calendar: 'calendar-days',
};

/** Painel Gerencial (EXE) */
export const SU_PANEL = {
  inicio: 'church',
  igreja: 'church',
  operacao: 'bolt',
  rede: 'wifi',
  monitores: 'display',
  recursos: 'gauge-high',
  dados: 'database',
  sobre: 'circle-info',
  control: 'grid-2',
  screen: 'presentation-screen',
  stage: 'music',
  remote: 'mobile-signal',
  loja: 'puzzle-piece',
};

/** Superfícies / apps */
export const SU_SURFACE = {
  control: 'grid-2',
  screen: 'presentation-screen',
  stage: 'music',
  remote: 'mobile-signal',
  panel: 'church',
  docs: 'book',
  portal: 'circle-play',
};

/** Tipos de slide (Programa + Designer presets) */
export const SU_SLIDE = {
  welcome: 'hand-wave',
  'bible-intro': 'book-open',
  introito: 'book-open',
  prayer: 'hands-praying',
  section: 'bookmark',
  participation: 'microphone',
  lyrics: 'music',
  'lyrics-title': 'music',
  bible: 'book-bible',
  'bible-interlinear': 'language',
  'bible-responsive': 'people-arrows',
  message: 'bullhorn',
  communion: 'wine-glass',
  announcements: 'bullhorn',
  theme: 'sparkles',
  media: 'photo-film',
  'media-audio': 'volume',
  offering: 'hand-holding-heart',
  countdown: 'hourglass-half',
  'countdown-pause': 'hourglass-half',
  custom: 'shapes',
  blank: 'square-dashed',
  logo: 'seal',
  'preacher-card': 'user-tie',
  'foto-card': 'image-portrait',
  ordem: 'list-ol',
  'welcome-quarta': 'hands-praying',
  'welcome-missoes': 'earth-americas',
  'welcome-mulheres': 'flower-tulip',
  'welcome-homens': 'cross',
  'welcome-jovens': 'sparkles',
  'welcome-criancas': 'sun',
  'welcome-especial': 'star',
  'welcome-aniversario': 'cake-candles',
  'quote-spurgeon': 'quote-left',
  'quote-hdl': 'quote-left',
  'quote-authority': 'quote-left',
  openingPrayer: 'hands-praying',
  praise: 'music',
  bibleReading: 'book-bible',
  dedication: 'hand-holding-heart',
  gratitude: 'dove',
  prayerAudio: 'headphones',
  fellowship: 'handshake',
  finalPrayer: 'sparkles',
};

/** Ações comuns */
export const SU_ACTION = {
  add: 'plus',
  save: 'floppy-disk',
  delete: 'trash',
  close: 'xmark',
  prev: 'chevron-left',
  next: 'chevron-right',
  play: 'circle-play',
  pause: 'circle-pause',
  refresh: 'arrows-rotate',
  search: 'magnifying-glass',
  check: 'circle-check',
  warn: 'triangle-exclamation',
  live: 'tower-broadcast',
  project: 'presentation-screen',
  undo: 'rotate-left',
  redo: 'rotate-right',
  zoomIn: 'magnifying-glass-plus',
  zoomOut: 'magnifying-glass-minus',
  zoomFit: 'expand',
  group: 'object-group',
  ungroup: 'object-ungroup',
  duplicate: 'copy',
  lock: 'lock',
  unlock: 'lock-open',
  visible: 'eye',
  hidden: 'eye-slash',
  minimize: 'chevron-down',
  volume: 'volume-high',
  volumeMute: 'volume-xmark',
  reset: 'arrow-rotate-left',
  frame: 'vector-square',
};

/** Designer toolbox (alias legado DS_ICONS) */
export const DS_ICONS = {
  models: 'grid-2',
  tools: 'screwdriver-wrench',
  background: 'fill-drip',
  layers: 'layer-group',
  media: 'photo-film',
  undo: 'rotate-left',
  redo: 'rotate-right',
  save: 'floppy-disk',
  project: 'presentation-screen',
  zoomIn: 'magnifying-glass-plus',
  zoomOut: 'magnifying-glass-minus',
  zoomFit: 'expand',
  group: 'object-group',
  ungroup: 'object-ungroup',
  text: 'font',
  rect: 'square',
  circle: 'circle',
  line: 'minus',
  image: 'image',
  folder: 'folder-open',
  logo: 'seal',
  frameRect: 'vector-square',
  frameRounded: 'square',
  frameCircle: 'circle',
  frameEllipse: 'circle',
  frameStar: 'star',
  frameHex: 'hexagon',
  frameDiamond: 'diamond',
  frameMask: 'mask',
  bgDark: 'moon',
  bgGold: 'gem',
  bgTheme: 'palette',
  bgBible: 'book-bible',
  bgImage: 'panorama',
  preacher: 'user-tie',
  alignLeft: 'align-left',
  alignCenterH: 'align-center',
  alignRight: 'align-right',
  alignTop: 'align-left',
  alignMiddle: 'align-center',
  alignBottom: 'align-right',
  alignCenter: 'bullseye',
  distributeH: 'arrows-left-right',
  distributeV: 'arrows-up-down',
  layerFront: 'bring-forward',
  layerForward: 'arrow-up',
  layerBackward: 'arrow-down',
  layerBack: 'send-backward',
  duplicate: 'copy',
  delete: 'trash',
  blockTitle: 'heading',
  blockVerse: 'quote-left',
  blockLogo: 'seal',
  master: 'clone',
  refresh: 'arrows-rotate',
  lock: 'lock',
  unlock: 'lock-open',
  visible: 'eye',
  hidden: 'eye-slash',
  search: 'magnifying-glass',
};

/** Abas do Remote */
export const SU_REMOTE = {
  control: 'sliders',
  order: 'list-timeline',
  macros: 'bolt',
  library: 'book-bible',
  alerts: 'bell',
};

/** Overlays */
export const SU_OVERLAY = {
  blank: 'square',
  logo: 'seal',
  silence: 'volume-xmark',
  stand: 'person',
  seat: 'chair',
  bar: 'minus',
  arrows: 'arrows-left-right',
};

const ALL = { ...SU_NAV, ...SU_PANEL, ...SU_SURFACE, ...SU_SLIDE, ...SU_ACTION, ...SU_REMOTE, ...DS_ICONS, ...SU_OVERLAY };

export function faClass(nameOrSuffix) {
  const suffix = ALL[nameOrSuffix] || nameOrSuffix || 'circle';
  return `fa-duotone fa-${suffix}`;
}

export function faIcon(nameOrSuffix, extraClass = '') {
  const extra = extraClass ? ` ${extraClass}` : '';
  return `<i class="${faClass(nameOrSuffix)}${extra}" aria-hidden="true"></i>`;
}

/** Quando o valor já é sufixo FA (ex.: SLIDE_TYPE_OPTIONS.icon) */
export function faIconRaw(faSuffix, extraClass = 'su-fa su-fa--sm') {
  if (!faSuffix) return faIcon('circle', extraClass);
  if (String(faSuffix).includes('fa-')) return `<i class="${faSuffix} ${extraClass}" aria-hidden="true"></i>`;
  return `<i class="fa-duotone fa-${faSuffix} ${extraClass}" aria-hidden="true"></i>`;
}

export function faBtnIcon(nameOrSuffix) {
  return faIcon(nameOrSuffix, 'su-fa');
}

export function faNavIconClass(key) {
  return faClass(SU_NAV[key] || key);
}

export function faNavIcon(key) {
  return faIcon(SU_NAV[key] || key, 'su-fa');
}

export function faPanelIcon(key) {
  return faIcon(SU_PANEL[key] || key, 'su-fa');
}

export function faRemoteTabIcon(key) {
  return faIcon(SU_REMOTE[key] || key, 'su-fa');
}

/** Ícone de aviso do pré-culto — sufixo FA ou emoji legado */
export function faNoticeIcon(icon, extraClass = 'su-fa su-fa--lg') {
  if (!icon) return faIcon('circle', extraClass);
  const s = String(icon);
  if (/^[a-z0-9-]+$/i.test(s) && s.includes('-')) return faIconRaw(s, extraClass);
  return s;
}

export function slideTypeFaSuffix(type) {
  return SU_SLIDE[type] || 'shapes';
}

export function slideTypeIcon(type, extraClass = 'su-fa su-fa--sm') {
  return faIconRaw(slideTypeFaSuffix(type), extraClass);
}

/** Aguarda Font Awesome Pro Duotone (vendor/fontawesome-pro) antes de montar UI rica. */
export async function ensureFontAwesomeReady(timeoutMs = 5000) {
  const probe = () => {
    try {
      if (document.fonts?.check) {
        return document.fonts.check('900 1em "Font Awesome 7 Duotone"');
      }
    } catch { /* ignore */ }
    return [...document.styleSheets].some((sheet) => {
      try {
        return sheet.href && /fontawesome-pro/i.test(sheet.href);
      } catch {
        return false;
      }
    });
  };

  if (probe()) return true;

  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    try {
      await document.fonts?.ready;
    } catch { /* ignore */ }
    if (probe()) return true;
    await new Promise((r) => setTimeout(r, 40));
  }
  return probe();
}

export function cultoBlockIcon(blockId) {
  const map = {
    welcome: SU_SLIDE.welcome,
    theme: SU_SLIDE.theme,
    introito: SU_SLIDE.introito,
    openingPrayer: SU_SLIDE.openingPrayer,
    praise: SU_SLIDE.praise,
    bibleReading: SU_SLIDE.bibleReading,
    dedication: SU_SLIDE.dedication,
    gratitude: SU_SLIDE.gratitude,
    prayerAudio: SU_SLIDE.prayerAudio,
    fellowship: SU_SLIDE.fellowship,
    message: SU_SLIDE.message,
    communion: SU_SLIDE.communion,
    finalPrayer: SU_SLIDE.finalPrayer,
  };
  return faIconRaw(map[blockId] || 'bookmark', 'su-fa');
}

function faRevQuery() {
  if (typeof window !== 'undefined' && window.SOMOSUM_ASSET_REGISTRY?.url) {
    const sample = window.SOMOSUM_ASSET_REGISTRY.url('css/fa-somosum.css');
    const idx = sample.indexOf('?');
    return idx >= 0 ? sample.slice(idx) : '';
  }
  const rev = (typeof window !== 'undefined' && (window.SOMOSUM_ASSET_REVISION || window.SOMOSUM_VERSION)) || '7.4.0';
  return `?v=${encodeURIComponent(rev)}`;
}

/** Links CSS FA para injetar em HTML estático */
export const FA_CSS_LINKS = `
  <link rel="stylesheet" href="vendor/fontawesome-pro/css/fontawesome.css${faRevQuery()}" />
  <link rel="stylesheet" href="vendor/fontawesome-pro/css/duotone.css${faRevQuery()}" />
  <link rel="stylesheet" href="css/fa-somosum.css${faRevQuery()}" />`;

export const FA_CSS_LINKS_ABS = `
  <link rel="stylesheet" href="/vendor/fontawesome-pro/css/fontawesome.css${faRevQuery()}" />
  <link rel="stylesheet" href="/vendor/fontawesome-pro/css/duotone.css${faRevQuery()}" />
  <link rel="stylesheet" href="/css/fa-somosum.css${faRevQuery()}" />`;
