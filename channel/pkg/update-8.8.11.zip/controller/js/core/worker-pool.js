/**
 * Pool fixo de Web Workers — fallback síncrono se indisponível.
 */

const pools = new Map();
let workerSupported = typeof Worker !== 'undefined';

export function isWorkerSupported() {
  return workerSupported;
}

export function getWorkerPool(scriptUrl, size = 2) {
  const key = String(scriptUrl);
  if (!pools.has(key)) {
    pools.set(key, new WorkerPool(scriptUrl, size));
  }
  return pools.get(key);
}

class WorkerPool {
  constructor(scriptUrl, size) {
    this.scriptUrl = scriptUrl;
    this.workers = [];
    this.queue = [];
    this.seq = 0;
    if (!workerSupported) return;
    try {
      for (let i = 0; i < size; i += 1) {
        const w = new Worker(scriptUrl, { type: 'module' });
        w._busy = false;
        this.workers.push(w);
      }
    } catch {
      workerSupported = false;
      this.workers = [];
    }
  }

  _pickWorker() {
    return this.workers.find((w) => !w._busy) || this.workers[0];
  }

  run(payload, transferables = []) {
    if (!this.workers.length) {
      return Promise.reject(new Error('workers-unavailable'));
    }
    const id = ++this.seq;
    const worker = this._pickWorker();
    return new Promise((resolve, reject) => {
      const onMsg = (e) => {
        if (e.data?.id !== id) return;
        worker.removeEventListener('message', onMsg);
        worker.removeEventListener('error', onErr);
        worker._busy = false;
        this._pump();
        if (e.data.ok) resolve(e.data.result);
        else reject(new Error(e.data.error || 'worker-failed'));
      };
      const onErr = (err) => {
        worker.removeEventListener('message', onMsg);
        worker.removeEventListener('error', onErr);
        worker._busy = false;
        reject(err);
      };
      worker._busy = true;
      worker.addEventListener('message', onMsg);
      worker.addEventListener('error', onErr);
      worker.postMessage({ id, ...payload }, transferables);
    });
  }

  enqueue(payload, transferables = []) {
    return new Promise((resolve, reject) => {
      this.queue.push({ payload, transferables, resolve, reject });
      this._pump();
    });
  }

  _pump() {
    if (!this.queue.length) return;
    const free = this.workers.some((w) => !w._busy);
    if (!free) return;
    const job = this.queue.shift();
    this.run(job.payload, job.transferables).then(job.resolve, job.reject);
  }

  terminate() {
    this.workers.forEach((w) => { try { w.terminate(); } catch { /* */ } });
    this.workers = [];
    this.queue = [];
  }
}

export async function runWorkerTask(scriptUrl, payload, { fallback = null, transferables = [] } = {}) {
  try {
    const pool = getWorkerPool(scriptUrl);
    return await pool.enqueue(payload, transferables);
  } catch {
    if (typeof fallback === 'function') return fallback(payload);
    throw new Error('worker-and-fallback-failed');
  }
}

if (typeof requestIdleCallback === 'function') {
  window.addEventListener('somosum-app-ready', () => {
    requestIdleCallback(() => {
      try {
        getWorkerPool(new URL('../workers/media-decode-worker.js', import.meta.url), 1);
      } catch { /* ignore */ }
    }, { timeout: 5000 });
  });
}
