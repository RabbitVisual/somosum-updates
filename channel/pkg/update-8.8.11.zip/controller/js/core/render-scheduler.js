/**
 * Render Scheduler — unico gateway para commits de UI.
 * RAF só fica ativo enquanto houver dirty; jobs incompletos voltam à fila.
 */
import { TaskScheduler } from './task-scheduler.js';
import { TaskIds } from './task-registry.js';
import { emitRenderIntent, emitRenderCommitMetrics } from '../runtime/render-intent-client.js';

const PRIORITY = { critical: 0, live: 1, normal: 2, idle: 3 };
const FRAME_BUDGET_MS = 8;

const dirty = new Map();
const metrics = {
  commits: 0,
  skippedFrames: 0,
  totalMs: 0,
  lastMs: 0,
};

let commitRegistered = false;

function ensureCommitLoop() {
  if (commitRegistered) return;
  commitRegistered = true;
  TaskScheduler.register({
    id: TaskIds.RENDER_COMMIT,
    kind: 'raf',
    priority: 2,
    fn: () => RenderScheduler.commit(),
  });
}

function pauseCommitLoop() {
  if (!commitRegistered) return;
  commitRegistered = false;
  TaskScheduler.unregister(TaskIds.RENDER_COMMIT);
}

function sortJobs(jobs) {
  return jobs.sort((a, b) => (PRIORITY[a.priority] ?? 2) - (PRIORITY[b.priority] ?? 2));
}

export const RenderScheduler = {
  markDirty(surface, { patch, priority = 'normal', full = null } = {}) {
    if (!surface) return;
    emitRenderIntent(surface, { patch, full, priority });
    const existing = dirty.get(surface) || { patches: [], full: null, priority: 'normal' };
    if (full) existing.full = full;
    if (typeof patch === 'function') existing.patches.push(patch);
    existing.priority = PRIORITY[priority] < PRIORITY[existing.priority] ? priority : existing.priority;
    dirty.set(surface, existing);
    ensureCommitLoop();
  },

  enqueue(surface, fn, priority = 'normal') {
    this.markDirty(surface, { patch: fn, priority });
  },

  commit() {
    if (!dirty.size) {
      pauseCommitLoop();
      return;
    }
    const start = performance.now();
    const jobs = sortJobs([...dirty.entries()]);
    dirty.clear();

    let i = 0;
    for (; i < jobs.length; i++) {
      if (performance.now() - start > FRAME_BUDGET_MS) {
        metrics.skippedFrames += 1;
        break;
      }
      const [, job] = jobs[i];
      try {
        if (typeof job.full === 'function') {
          job.full();
        } else {
          for (const patch of job.patches) patch();
        }
      } catch (err) {
        console.error('[SOMOSUM] RenderScheduler', err);
      }
    }

    // Re-enfileira o que não coube no budget — não descarta
    for (; i < jobs.length; i++) {
      const [surface, job] = jobs[i];
      const existing = dirty.get(surface);
      if (!existing) {
        dirty.set(surface, job);
      } else {
        if (job.full) existing.full = job.full;
        if (job.patches?.length) existing.patches.push(...job.patches);
        existing.priority = PRIORITY[job.priority] < PRIORITY[existing.priority]
          ? job.priority
          : existing.priority;
      }
    }

    const elapsed = performance.now() - start;
    metrics.commits += 1;
    metrics.totalMs += elapsed;
    metrics.lastMs = elapsed;
    emitRenderCommitMetrics({
      commits: metrics.commits,
      lastMs: metrics.lastMs,
      skippedFrames: metrics.skippedFrames,
      pending: dirty.size,
    });

    if (!dirty.size) pauseCommitLoop();
  },

  getMetrics() {
    return {
      ...metrics,
      avgMs: metrics.commits ? metrics.totalMs / metrics.commits : 0,
      pending: dirty.size,
    };
  },

  clear() {
    dirty.clear();
    pauseCommitLoop();
  },
};

if (typeof window !== 'undefined') {
  window.__SOMOSUM_RENDER_SCHEDULER__ = RenderScheduler;
}
