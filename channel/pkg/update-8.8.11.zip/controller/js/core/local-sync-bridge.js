/**
 * LocalSyncBridge — Controle ↔ Projeção/Stage via WebView2 PostWebMessage.
 * Um hop nativo (sem Kestrel). WS/HTTP continuam só para Remote / catch-up.
 */

const CHANNEL = 'somosum-local';

function hasWebView() {
  try {
    return !!(typeof window !== 'undefined' && window.chrome?.webview?.postMessage);
  } catch {
    return false;
  }
}

function isNativeShell() {
  try {
    return !!(window.somosumNativeShell || window.somosumRuntimeShell || hasWebView());
  } catch {
    return false;
  }
}

/**
 * @param {object} message — envelope ProjectionBus { id, type, payload, ts, from }
 * @returns {boolean} true se postou no caminho local
 */
export function postLocalSync(message) {
  if (!message || !hasWebView()) return false;
  try {
    window.chrome.webview.postMessage({
      type: 'local-sync',
      channel: CHANNEL,
      message,
    });
    return true;
  } catch {
    return false;
  }
}

/**
 * Escuta envelopes locais e entrega ao ProjectionBus sem reenviar.
 * @param {(message: object, source: string) => void} dispatch
 * @returns {() => void} dispose
 */
export function listenLocalSync(dispatch) {
  if (!hasWebView() || typeof dispatch !== 'function') return () => {};
  const handler = (ev) => {
    try {
      const data = typeof ev.data === 'string' ? JSON.parse(ev.data) : ev.data;
      if (!data || data.type !== 'local-sync') return;
      const message = data.message || data.payload;
      if (!message || typeof message !== 'object') return;
      dispatch(message, 'local');
    } catch { /* ignore */ }
  };
  window.chrome.webview.addEventListener('message', handler);
  return () => {
    try {
      window.chrome.webview.removeEventListener('message', handler);
    } catch { /* ignore */ }
  };
}

export function localSyncAvailable() {
  return isNativeShell() && hasWebView();
}
