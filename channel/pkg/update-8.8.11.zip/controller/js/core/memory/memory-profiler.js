/**
 * Memory Profiler — snapshots periodicos para auditoria enterprise.
 */
import { TaskScheduler } from '../task-scheduler.js';
import { TaskIds } from '../task-registry.js';
import { LogService, LogCategory } from '../logging/log-service.js';

const MAX_SAMPLES = 512;
const samples = [];
let running = false;
let disposeFn = null;

function countGlobals() {
  if (typeof window === 'undefined') return 0;
  return Object.keys(window).filter((k) => k.startsWith('__SOMOSUM')).length;
}

async function collectSnapshot() {
  const mem = typeof performance !== 'undefined' && performance.memory
    ? {
      used: performance.memory.usedJSHeapSize,
      total: performance.memory.totalJSHeapSize,
      limit: performance.memory.jsHeapSizeLimit,
    }
    : null;

  let imageCache = 0;
  let videoCache = 0;
  try {
    const { ImageCache, VideoCache } = await import('../../render/asset-cache.js');
    imageCache = ImageCache.getMetrics?.().size ?? ImageCache._map?.size ?? 0;
    videoCache = VideoCache.getMetrics?.().size ?? VideoCache._map?.size ?? 0;
  } catch { /* ignore */ }

  const ts = Date.now();
  const snap = {
    ts,
    heap: mem,
    caches: { image: imageCache, video: videoCache },
    tasks: TaskScheduler.getMetrics?.() ?? {},
    taskCount: TaskScheduler.getActiveTasks?.()?.length ?? 0,
    globals: countGlobals(),
    live: !!window.__SOMOSUM_LIVE_ACTIVE,
  };

  samples.push(snap);
  if (samples.length > MAX_SAMPLES) samples.shift();

  LogService.debug('Memory snapshot', {
    module: 'memory-profiler',
    category: LogCategory.MEMORY,
    detail: snap,
  });

  return snap;
}

export const MemoryProfiler = {
  start({ liveIntervalMs = 60000, idleIntervalMs = 30000 } = {}) {
    if (running) return;
    running = true;
    const tick = () => (window.__SOMOSUM_LIVE_ACTIVE ? liveIntervalMs : idleIntervalMs);
    disposeFn = TaskScheduler.register({
      id: TaskIds.MEMORY_PROFILER,
      kind: 'interval',
      intervalMs: tick(),
      priority: 9,
      fn: async () => {
        await collectSnapshot();
        TaskScheduler.setIntervalMs(TaskIds.MEMORY_PROFILER, tick());
      },
    });
    void collectSnapshot();
  },

  stop() {
    running = false;
    disposeFn?.();
    disposeFn = null;
    TaskScheduler.unregister(TaskIds.MEMORY_PROFILER);
  },

  getSamples(limit = 64) {
    return samples.slice(-limit);
  },

  exportJson() {
    return JSON.stringify({ exportedAt: Date.now(), samples }, null, 2);
  },

  async snapshot() {
    return collectSnapshot();
  },
};
