/**
 * Leak Detector — crescimento monotono de heap e drift de recursos.
 */
import { MemoryProfiler } from './memory-profiler.js';

let running = false;
let handler = null;

function analyze(samples) {
  if (samples.length < 8) return null;
  const heaps = samples.map((s) => s.heap?.used).filter(Boolean);
  if (heaps.length < 8) return null;
  const first = heaps.slice(0, Math.floor(heaps.length / 3));
  const last = heaps.slice(-Math.floor(heaps.length / 3));
  const avg = (arr) => arr.reduce((a, b) => a + b, 0) / arr.length;
  const start = avg(first);
  const end = avg(last);
  if (start <= 0) return null;
  const growth = (end - start) / start;
  const live = samples[samples.length - 1]?.live;
  const threshold = live ? 0.25 : 0.15;
  if (growth > threshold) {
    return { growth, start, end, live, suspect: true };
  }
  return { growth, start, end, live, suspect: false };
}

export const LeakDetector = {
  start() {
    if (running) return;
    running = true;
    handler = () => {
      const result = analyze(MemoryProfiler.getSamples(120));
      if (result?.suspect) {
        window.dispatchEvent(new CustomEvent('somosum-memory-leak-suspect', { detail: result }));
      }
    };
    window.addEventListener('somosum-analyzer-tick', handler);
  },

  stop() {
    running = false;
    if (handler) window.removeEventListener('somosum-analyzer-tick', handler);
    handler = null;
  },

  analyzeNow() {
    return analyze(MemoryProfiler.getSamples(120));
  },
};
