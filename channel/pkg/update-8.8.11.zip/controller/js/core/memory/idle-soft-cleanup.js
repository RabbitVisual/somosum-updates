/**
 * Idle soft cleanup — limpa caches após slide estático longo (Low-Spec Pro).
 * Não toca SyncCoordinator / estado de sync.
 */
import { TaskScheduler } from '../task-scheduler.js';
import { TaskIds } from '../task-registry.js';
import { AutoCleanup } from './auto-cleanup.js';

const IDLE_MS = 10 * 60 * 1000;
const CHECK_MS = 60 * 1000;

let started = false;
let lastSlideChangeAt = Date.now();
let lastCleanupAt = 0;

export function noteSlideActivity() {
  lastSlideChangeAt = Date.now();
}

async function maybeCleanup() {
  const idleFor = Date.now() - lastSlideChangeAt;
  if (idleFor < IDLE_MS) return;
  if (Date.now() - lastCleanupAt < IDLE_MS) return;
  lastCleanupAt = Date.now();
  await AutoCleanup.runLightCleanup();
  try {
    if (typeof window.gc === 'function') window.gc();
  } catch { /* expose-gc opcional */ }
  window.dispatchEvent(new CustomEvent('somosum-idle-cleanup', {
    detail: { idleMs: idleFor, live: !!window.__SOMOSUM_LIVE_ACTIVE },
  }));
}

export const IdleSoftCleanup = {
  start() {
    if (started) return;
    started = true;
    lastSlideChangeAt = Date.now();
    TaskScheduler.register({
      id: TaskIds.IDLE_SOFT_CLEANUP || 'idle-soft-cleanup',
      kind: 'interval',
      intervalMs: CHECK_MS,
      priority: 9,
      runWhenHidden: true,
      fn: () => { void maybeCleanup(); },
    });
  },

  stop() {
    started = false;
    try {
      TaskScheduler.unregister(TaskIds.IDLE_SOFT_CLEANUP || 'idle-soft-cleanup');
    } catch { /* ignore */ }
  },

  noteSlideActivity,
  maybeCleanup,
};
