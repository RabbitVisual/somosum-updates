/**
 * Auto Cleanup — limpeza leve automatica sob pressao de memoria.
 */

let running = false;
let handler = null;

async function runLightCleanup() {
  try {
    const { ImageCache, VideoCache } = await import('../../render/asset-cache.js');
    if (window.__SOMOSUM_LIVE_ACTIVE) {
      ImageCache.trim?.(Math.max(6, Math.floor((ImageCache._maxSize || 20) * 0.4)));
      VideoCache.trim?.(1);
    } else {
      ImageCache.trim?.(Math.max(10, Math.floor((ImageCache._maxSize || 60) * 0.5)));
      VideoCache.trim?.(2);
    }
  } catch { /* ignore */ }
  document.querySelectorAll('.has-lyrics-fx').forEach((el) => el.classList.remove('has-lyrics-fx'));
}

export const AutoCleanup = {
  start() {
    if (running) return;
    running = true;
    handler = (ev) => {
      if (ev.detail?.memory?.fail || ev.detail?.memory?.warn) {
        void runLightCleanup();
      }
    };
    window.addEventListener('somosum-watchdog-memory-high', handler);
    window.addEventListener('somosum-memory-leak-suspect', () => { void runLightCleanup(); });
  },

  stop() {
    running = false;
    if (handler) window.removeEventListener('somosum-watchdog-memory-high', handler);
    handler = null;
  },

  runLightCleanup,
};
