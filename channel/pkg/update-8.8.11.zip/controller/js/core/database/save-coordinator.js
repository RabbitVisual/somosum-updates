/**
 * SaveCoordinator — serializa gravações IDB + disco para evitar race conditions.
 */
import { LogService, LogCategory } from '../logging/log-service.js';

const queue = [];
let processing = false;
let generation = 0;

export function nextGeneration() {
  generation += 1;
  return generation;
}

export function getSaveGeneration() {
  return generation;
}

export function enqueueSave(label, fn, { priority = 0 } = {}) {
  return new Promise((resolve, reject) => {
    queue.push({ label, fn, priority, resolve, reject, addedAt: Date.now() });
    queue.sort((a, b) => b.priority - a.priority);
    pump();
  });
}

async function pump() {
  if (processing) return;
  processing = true;
  while (queue.length) {
    const job = queue.shift();
    try {
      const result = await job.fn();
      job.resolve(result);
    } catch (err) {
      LogService.error(`Save failed: ${job.label}`, {
        module: 'save-coordinator',
        category: LogCategory.DATABASE,
        err,
      });
      job.reject(err);
    }
  }
  processing = false;
}

export function getQueueDepth() {
  return queue.length + (processing ? 1 : 0);
}

/** Aguarda fila de gravação esvaziar (evita race com sync). */
export async function waitForSaveDrain(maxMs = 2000) {
  const { TaskScheduler } = await import('../task-scheduler.js');
  await TaskScheduler.waitFor(() => !processing && queue.length === 0, maxMs, 16);
}

export async function coordinatedSave(label, fn, opts) {
  return enqueueSave(label, fn, opts);
}
