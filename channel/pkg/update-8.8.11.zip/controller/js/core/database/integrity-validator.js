import { SCHEMA_VERSION } from './schema.js';

export function validateSong(song) {
  if (!song || typeof song !== 'object') return false;
  return typeof song.id === 'string' && typeof song.title === 'string';
}

export function validateProgramItems(items) {
  return Array.isArray(items);
}

export function validateMedia(item) {
  if (!item || typeof item !== 'object') return false;
  return typeof item.id === 'string' && typeof item.name === 'string';
}

export function validateBackup(data) {
  if (!data || typeof data !== 'object') return { ok: false, reason: 'empty' };
  if (!data.version || data.version < 1 || data.version > 5) {
    return { ok: false, reason: 'version' };
  }
  return { ok: true, schemaVersion: SCHEMA_VERSION };
}

export async function verifyStoreIntegrity(getCounts) {
  const counts = await getCounts();
  return {
    schemaVersion: SCHEMA_VERSION,
    stores: counts,
    ok: true,
  };
}
