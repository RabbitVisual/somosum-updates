import { JOURNAL_KEY } from './schema.js';
import { LogService, LogCategory } from '../logging/log-service.js';

const pendingOps = [];

function loadJournal() {
  try {
    const raw = localStorage.getItem(JOURNAL_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

function saveJournal(entries) {
  try {
    localStorage.setItem(JOURNAL_KEY, JSON.stringify(entries.slice(-200)));
  } catch { /* quota */ }
}

export class TransactionManager {
  constructor() {
    this.rollbackStack = [];
  }

  begin() {
    this.rollbackStack = [];
    return this;
  }

  recordRollback(fn) {
    this.rollbackStack.push(fn);
  }

  async commit(ops) {
    const journal = loadJournal();
    const batchId = `tx-${Date.now()}`;
    journal.push({ id: batchId, ops: ops.map((o) => o.label), ts: Date.now(), status: 'pending' });
    saveJournal(journal);
    try {
      for (const op of ops) {
        await op.run();
        if (op.rollback) this.recordRollback(op.rollback);
      }
      const j2 = loadJournal();
      const entry = j2.find((e) => e.id === batchId);
      if (entry) entry.status = 'committed';
      saveJournal(j2);
      this.rollbackStack = [];
      return true;
    } catch (err) {
      LogService.error('Transaction failed', {
        module: 'transaction-manager',
        category: LogCategory.DATABASE,
        err,
      });
      await this.rollback();
      const j2 = loadJournal();
      const entry = j2.find((e) => e.id === batchId);
      if (entry) entry.status = 'rolled_back';
      saveJournal(j2);
      return false;
    }
  }

  async rollback() {
    const stack = [...this.rollbackStack].reverse();
    this.rollbackStack = [];
    for (const fn of stack) {
      try { await fn(); } catch { /* best effort */ }
    }
  }

  getPendingJournal() {
    return loadJournal().filter((e) => e.status === 'pending');
  }
}

export const transactionManager = new TransactionManager();
