import { SCHEMA_VERSION } from './schema.js';
import { openDb, idbGetAll } from './idb-adapter.js';
import { transactionManager } from './transaction-manager.js';
import { verifyStoreIntegrity } from './integrity-validator.js';
import { SongRepository } from './repositories/song-repository.js';
import { ProgramRepository } from './repositories/program-repository.js';
import { MediaRepository } from './repositories/media-repository.js';
import { AssetRepository } from './repositories/asset-repository.js';
import { LogService, LogCategory } from '../logging/log-service.js';

let initialized = false;

export const DatabaseEngine = {
  schemaVersion: SCHEMA_VERSION,
  songs: SongRepository,
  program: ProgramRepository,
  media: MediaRepository,
  assets: AssetRepository,
  transactions: transactionManager,
  /** Storage Platform 7.9 — use StorageManager.repos para novos domínios */
  storageHub: () => import('../storage/storage-manager.js').then((m) => m.StorageManager),

  async init() {
    if (initialized) return;
    await openDb();
    initialized = true;
    LogService.debug('DatabaseEngine inicializado', {
      module: 'database-engine',
      category: LogCategory.DATABASE,
      detail: { schemaVersion: SCHEMA_VERSION },
    });
  },

  async getIntegrity() {
    return verifyStoreIntegrity(async () => {
      const [songs, media, assets, program] = await Promise.all([
        idbGetAll('songs'),
        idbGetAll('media'),
        idbGetAll('assets'),
        idbGetAll('program'),
      ]);
      return {
        songs: songs.length,
        media: media.length,
        assets: assets.length,
        program: program.length,
      };
    });
  },

  async createSnapshot(label = 'manual') {
    const [songs, programItems, media, assets] = await Promise.all([
      SongRepository.getAll(),
      ProgramRepository.getItems(),
      MediaRepository.getAll(),
      AssetRepository.getAll(),
    ]);
    return {
      label,
      schemaVersion: SCHEMA_VERSION,
      createdAt: new Date().toISOString(),
      songs,
      program: programItems,
      media: media.map((m) => ({ ...m, dataUrl: m.dataUrl ? '[blob]' : null })),
      assets,
    };
  },
};
