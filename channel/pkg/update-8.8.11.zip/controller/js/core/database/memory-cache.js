/** LRU cache em memória para repositories — com TTL e métricas. */
export class MemoryCache {
  constructor(maxSize = 200, ttlMs = 30 * 60 * 1000) {
    this.maxSize = maxSize;
    this.ttlMs = ttlMs;
    this.map = new Map();
    this.stats = { hits: 0, misses: 0, evictions: 0 };
  }

  get(key) {
    const entry = this.map.get(key);
    if (!entry) {
      this.stats.misses += 1;
      return undefined;
    }
    if (Date.now() - entry.at > this.ttlMs) {
      this.map.delete(key);
      this.stats.misses += 1;
      return undefined;
    }
    this.map.delete(key);
    this.map.set(key, entry);
    this.stats.hits += 1;
    return entry.value;
  }

  set(key, value) {
    if (this.map.has(key)) this.map.delete(key);
    this.map.set(key, { value, at: Date.now() });
    if (this.map.size > this.maxSize) {
      const first = this.map.keys().next().value;
      this.map.delete(first);
      this.stats.evictions += 1;
    }
  }

  delete(key) {
    this.map.delete(key);
  }

  clear() {
    this.map.clear();
  }

  getMetrics() {
    return { ...this.stats, size: this.map.size, maxSize: this.maxSize, ttlMs: this.ttlMs };
  }
}
