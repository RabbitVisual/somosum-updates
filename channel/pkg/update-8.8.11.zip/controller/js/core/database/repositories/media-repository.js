import { idbGet, idbGetAll, idbPut, idbDelete } from '../idb-adapter.js';
import { MemoryCache } from '../memory-cache.js';
import { validateMedia } from '../integrity-validator.js';
import { DiskAdapter } from '../../storage/adapters/disk-adapter.js';
import {
  saveMediaToDisk,
  deleteMediaFromDisk,
} from '../../storage/adapters/server-adapter.js';
import {
  normalizeMediaIndex,
  buildMediaIndexPayload,
  diskRelativePath,
  resolveMediaSrc,
} from '../../media-url.js';

const cache = new MemoryCache(100);

/** Mídias sintéticas de teste de carga — nunca devem aparecer na biblioteca. */
export function isStressMedia(item) {
  if (!item) return false;
  const id = String(item.id || '');
  const name = String(item.name || '');
  const path = String(item.path || '');
  const tags = Array.isArray(item.tags) ? item.tags : [];
  return id.startsWith('stress-img-')
    || id.startsWith('stress-vid-')
    || id.startsWith('stress-media-')
    || /^stress-image-\d+/i.test(name)
    || /stress-image-\d+/i.test(path)
    || tags.includes('stress');
}

function extFromMime(mime = '') {
  if (mime.includes('jpeg') || mime.includes('jpg')) return 'jpg';
  if (mime.includes('webp')) return 'webp';
  if (mime.includes('gif')) return 'gif';
  if (mime.includes('png')) return 'png';
  if (mime.includes('video')) return mime.includes('webm') ? 'webm' : 'mp4';
  return 'webp';
}

async function persistMediaIndex(map) {
  DiskAdapter.saveDebounced('media/index.json', buildMediaIndexPayload(map), 400, { silent: true });
}

export const MediaRepository = {
  async getAll() {
    const items = await idbGetAll('media');
    return items
      .filter((item) => !isStressMedia(item))
      .sort((a, b) => (a.name || '').localeCompare(b.name || '', 'pt-BR'))
      .map((item) => {
        const { dataUrl, ...meta } = item;
        return {
          ...meta,
          src: resolveMediaSrc(item),
          hasFile: !!(meta.path || dataUrl),
        };
      });
  },
  async getById(id) {
    if (isStressMedia({ id })) return null;
    const hit = cache.get(`media:${id}`);
    if (hit) return isStressMedia(hit) ? null : hit;
    const row = await idbGet('media', id);
    if (row && !isStressMedia(row)) {
      row.src = resolveMediaSrc(row);
      cache.set(`media:${id}`, row);
      return row;
    }
    return null;
  },
  async purgeStressMedia() {
    const all = await idbGetAll('media');
    let n = 0;
    for (const row of all) {
      if (!isStressMedia(row)) continue;
      await idbDelete('media', row.id);
      cache.delete?.(`media:${row.id}`);
      n += 1;
    }
    try {
      const indexRaw = await DiskAdapter.load('media/index.json');
      const indexMap = normalizeMediaIndex(indexRaw);
      let changed = false;
      for (const id of Object.keys(indexMap)) {
        if (isStressMedia(indexMap[id])) {
          delete indexMap[id];
          changed = true;
        }
      }
      if (changed) await persistMediaIndex(indexMap);
    } catch { /* ignore */ }
    return n;
  },
  /**
   * Remove IDs do pack antigo (sys-bg-*, SOMOSUM_S*, sys-loop-*) que quebram a biblioteca com 404.
   * O pack atual usa animados/SOMOSUM_NN + estaticos/SOMOS_NN_ESTATICO.
   */
  async purgeObsoleteSystemMedia(validSystemIds = null) {
    const { isObsoleteSystemMediaId } = await import('../../media-url.js');
    const keep = validSystemIds instanceof Set
      ? validSystemIds
      : (Array.isArray(validSystemIds) ? new Set(validSystemIds) : null);

    const isSystemEntry = (row) => !!(row?.system || row?.readonly || isObsoleteSystemMediaId(row?.id));

    const shouldPurgeSystemId = (id, entry) => {
      if (isObsoleteSystemMediaId(id)) return true;
      if (!keep) return false;
      const sys = entry?.system || entry?.readonly || isObsoleteSystemMediaId(id);
      if (!sys) return false;
      return keep.size === 0 || !keep.has(id);
    };

    const all = await idbGetAll('media');
    let n = 0;
    for (const row of all) {
      if (!row?.id) continue;
      if (!shouldPurgeSystemId(row.id, row)) continue;
      if (!isSystemEntry(row)) continue;
      await idbDelete('media', row.id);
      cache.delete?.(`media:${row.id}`);
      n += 1;
    }
    try {
      const indexRaw = await DiskAdapter.load('media/index.json');
      const indexMap = normalizeMediaIndex(indexRaw);
      let changed = false;
      for (const id of Object.keys(indexMap)) {
        if (!shouldPurgeSystemId(id, indexMap[id])) continue;
        delete indexMap[id];
        changed = true;
      }
      if (changed) await persistMediaIndex(indexMap);
    } catch { /* ignore */ }
    return n;
  },
  async save(item) {
    const payload = {
      ...item,
      updatedAt: Date.now(),
      createdAt: item.createdAt || Date.now(),
    };
    if (!validateMedia(payload) && payload.id) {
      payload.name = payload.name || 'Mídia';
    }
    const ext = extFromMime(payload.mimeType || '');
    payload.path = payload.path || `media/${payload.id}.${ext}`;

    await idbPut('media', payload);
    cache.set(`media:${payload.id}`, payload);

    if (payload.dataUrl) {
      saveMediaToDisk(payload.id, payload.dataUrl, payload.mimeType || 'image/png').catch(() => {});
    }

    const indexRaw = await DiskAdapter.load('media/index.json');
    const indexMap = normalizeMediaIndex(indexRaw);
    indexMap[payload.id] = {
      id: payload.id,
      name: payload.name,
      kind: payload.kind,
      category: payload.category || payload.kind,
      mimeType: payload.mimeType,
      path: payload.path || diskRelativePath(payload),
      tags: payload.tags || [],
      updatedAt: payload.updatedAt,
      sizeBytes: payload.sizeBytes || null,
      favorite: !!payload.favorite,
      system: !!payload.system,
      readonly: !!(payload.readonly || payload.system),
    };
    await persistMediaIndex(indexMap);
    return { ...payload, src: resolveMediaSrc(payload) };
  },
  async delete(id) {
    const row = await idbGet('media', id);
    if (row?.system || row?.readonly) {
      throw new Error('Mídia do sistema não pode ser excluída');
    }
    await idbDelete('media', id);
    cache.delete(`media:${id}`);
    await deleteMediaFromDisk(id).catch(() => {});
    const indexRaw = await DiskAdapter.load('media/index.json');
    const indexMap = normalizeMediaIndex(indexRaw);
    delete indexMap[id];
    await persistMediaIndex(indexMap);
  },
};
