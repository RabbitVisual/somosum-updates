import { idbGet, idbGetAll, idbPut, idbDelete } from '../idb-adapter.js';
import { DiskAdapter } from '../../storage/adapters/disk-adapter.js';
import { saveAssetToDisk } from '../../storage/adapters/server-adapter.js';

export const AssetRepository = {
  async get(key) {
    const row = await idbGet('assets', key);
    return row?.dataUrl ?? null;
  },
  async getAll() {
    const rows = await idbGetAll('assets');
    return Object.fromEntries(rows.map((r) => [r.key, r.dataUrl]));
  },
  async save(key, dataUrl, mimeType = 'image/png') {
    await idbPut('assets', { key, dataUrl, updatedAt: Date.now() });
    saveAssetToDisk(key, dataUrl, mimeType).catch(() => {});
    const index = (await DiskAdapter.load('assets/index.json')) || {};
    index[key] = { id: key, mimeType, updatedAt: Date.now() };
    DiskAdapter.saveDebounced('assets/index.json', index);
    return dataUrl;
  },
  async delete(key) {
    await idbDelete('assets', key);
  },
};
