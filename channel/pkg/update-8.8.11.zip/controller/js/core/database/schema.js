/** Schema e versão do banco SOMOSUM */
export const SCHEMA_VERSION = 5;
export const DB_NAME = 'somosum-db';
export const DB_VERSION = 5;

export const STORES = {
  songs: { keyPath: 'id' },
  program: { keyPath: 'id' },
  meta: { keyPath: 'key' },
  assets: { keyPath: 'key' },
  media: { keyPath: 'id' },
  bible_chapters: { keyPath: 'key' },
};

export const JOURNAL_KEY = 'somosum-db-journal';
export const SNAPSHOT_PREFIX = 'somosum-snapshot-';
