import { randomId } from '../core/uuid.js';

const COPY_PREFIX = 'Cópia — ';

/** Clona um item da ordem do culto com novo id e titulo prefixado. */
export function cloneProgramItem(item) {
  if (!item) return null;
  const copy = JSON.parse(JSON.stringify(item));
  copy.id = randomId();

  const originalTitle = String(item.title || 'Item').trim();
  copy.title = originalTitle.startsWith(COPY_PREFIX)
    ? `${COPY_PREFIX}${originalTitle}`
    : `${COPY_PREFIX}${originalTitle}`;

  if (copy.data && typeof copy.data === 'object') {
    if (['section', 'prayer', 'welcome'].includes(copy.slideType)) {
      copy.data.title = copy.title;
    } else if (copy.data.title === item.title || copy.data.title === item.data?.title) {
      copy.data.title = copy.title;
    }
  }

  return copy;
}

export function moveItemInList(items, fromIndex, toIndex) {
  if (!Array.isArray(items) || fromIndex === toIndex) return items;
  if (fromIndex < 0 || fromIndex >= items.length) return items;
  const next = [...items];
  const [moved] = next.splice(fromIndex, 1);
  let target = Math.max(0, Math.min(toIndex, next.length));
  if (fromIndex < toIndex) target = Math.max(0, toIndex - 1);
  next.splice(target, 0, moved);
  return next;
}
