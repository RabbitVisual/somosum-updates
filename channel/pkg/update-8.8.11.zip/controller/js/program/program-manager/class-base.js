﻿import {
  formatReference,
  formatReferenceParts,
  getPassage,
  splitPassageIntoSlides,
  splitPassageResponsive,
  buildInterlinearSlide,
  resolveBibleDisplayMode,
  resolveBibleDisplayReference,
  getVersions,
} from '../../bible/bible-service.js';
import { defaultOriginalLang } from '../../bible/book-bridge.js';
import { getBookName } from '../../bible/books-map.js';
import { sanitizeBibleRef } from '../../bible/bible-picker.js';
import { buildLyricsSlides, getLyricsStyle, resolveSlideBackground } from '../../lyrics/lyrics-splitter.js';
import { getSong, getMedia } from '../../core/store.js';
import { resolveMediaSrc, resolveSystemLoopAlias } from '../../core/media-url.js';
import { getMessageMode, resolveShowPreacherPhoto } from '../../slides/message-display-modes.js';
import {
  getDesignerSkin,
  buildSkinnedProjectionSlide,
  contentKindFromTemplateId,
  applyCustomOrdemProps,
  resolveCustomBackground,
  prepareCustomSlideForSync,
} from '../../designer/content-bindings.js';
import { isIntroitoProgramItem } from '../programa-templates.js';

const STYLE_DEFAULTS = {
  welcome: { titleSize: 92, textSize: 30, textTransform: 'none', align: 'center', titleColor: '#fff8ec', textColor: '#ffffff' },
  section: { titleSize: 86, textSize: 30, textTransform: 'uppercase', align: 'center', titleColor: '#ffffff', textColor: '#a8a8a8' },
  prayer: { titleSize: 86, textSize: 30, textTransform: 'uppercase', align: 'center', titleColor: '#d4af37', textColor: '#ffffff', backgroundPreset: 'dark' },
  bible: { titleSize: 92, textSize: 52, textTransform: 'uppercase', align: 'center', vAlign: 'center', titleColor: '#d4af37', textColor: '#ffffff', refColor: '#d4af37' },
  'bible-responsive': { titleSize: 82, textSize: 30, textTransform: 'none', align: 'center', titleColor: '#d4af37', textColor: '#ffffff', refColor: '#d4af37' },
  custom: { titleSize: 76, textSize: 34, textTransform: 'none', align: 'center', titleColor: '#d4af37', textColor: '#ffffff' },
  theme: { titleSize: 86, textSize: 34, textTransform: 'none', align: 'center', titleColor: '#d4af37', textColor: '#ffffff' },
  announcements: { titleSize: 72, textSize: 32, textTransform: 'none', align: 'left', titleColor: '#d4af37', textColor: '#ffffff' },
  communion: { fontSize: 64, textSize: 28, textTransform: 'none', align: 'center', animation: 'reverent', titleColor: '#ffffff', textColor: '#ffffff' },
  participation: { titleSize: 52, nameSize: 88, textSize: 36, textTransform: 'none', align: 'center', titleColor: '#d4af37', textColor: '#ffffff' },
  media: { titleSize: 34, textSize: 28, textTransform: 'none', align: 'center', titleColor: '#ffffff', textColor: '#ffffff' },
};

function itemStyle(item, type = item?.slideType) {
  return {
    ...(STYLE_DEFAULTS[type] || STYLE_DEFAULTS.custom),
    ...(item?.data?.style || {}),
  };
}

export { itemStyle };

/** Teto LRU do cache de letras em memória (P1 — cultos longos). */
export const MAX_SONGS_CACHE = 48;


export class ProgramManager {
  constructor(defaults = {}, prefs = {}) {
    this.items = [];
    this.defaults = defaults;
    this.prefs = prefs;
    this.flatSlides = [];
    this.slideMeta = [];
    this.currentIndex = 0;
    this.overlay = null;
    this.songsCache = new Map();
    this._rebuildGen = 0;
  }

  setItems(items, { resetNav = true } = {}) {
    this.items = items;
    if (resetNav) {
      this.currentIndex = 0;
      this.overlay = null;
    }
  }

  restoreNavigation({ currentIndex = 0, overlay = null } = {}) {
    if (typeof currentIndex === 'number') {
      this.currentIndex = Math.max(0, Math.min(currentIndex, Math.max(0, this.flatSlides.length - 1)));
    }
    this.overlay = overlay || null;
  }

  setDefaults(defaults) {
    this.defaults = defaults;
  }

  setPrefs(prefs) {
    this.prefs = { ...this.prefs, ...prefs };
  }

  async cacheSong(songId) {
    if (!songId) return null;
    if (this.songsCache.has(songId)) {
      // LRU: reinserir move para o fim (mais recente)
      const cached = this.songsCache.get(songId);
      this.songsCache.delete(songId);
      this.songsCache.set(songId, cached);
      return cached;
    }
    const song = await getSong(songId);
    if (song) this._setSongCache(songId, song);
    return song;
  }

  _setSongCache(songId, song) {
    if (this.songsCache.has(songId)) this.songsCache.delete(songId);
    this.songsCache.set(songId, song);
    while (this.songsCache.size > MAX_SONGS_CACHE) {
      const oldest = this.songsCache.keys().next().value;
      this.songsCache.delete(oldest);
    }
  }

  clearSongCache(songId) {
    if (songId) this.songsCache.delete(songId);
    else this.songsCache.clear();
  }

  resolveText(item) {
    if (item.data?.textEdited) return item.data?.text ?? '';
    const custom = item.data?.text;
    if (typeof custom === 'string') return custom;
    return '';
  }

  /**
   * If item has Designer skin, return custom projection with content injected.
   * Otherwise return null (caller uses HTML bible/welcome template).
   */
  skinnedSlideFromItem(item, {
    contentKind,
    style,
    reference = '',
    verseText = '',
    welcome = null,
  } = {}) {
    const skin = getDesignerSkin(item);
    if (!skin?.layers?.length) return null;
    const kind = contentKind
      || (isIntroitoProgramItem(item) ? 'introito' : null)
      || contentKindFromTemplateId(skin.templateId || item.data?.templateId)
      || (item.slideType === 'bible' ? 'bible' : null)
      || (item.slideType === 'welcome' ? 'welcome' : null);
    return buildSkinnedProjectionSlide({
      contentKind: kind,
      skin,
      style,
      reference,
      verseText,
      welcome: welcome || item.data,
      media: {
        photo: item.data?.photoSrc || item.data?.mediaSrc,
      },
      type: item.slideType,
    });
  }

  /** Anexa fundo vídeo/imagem/gradiente a slides flatten (exceto mídia como conteúdo). */
  async withSlideBackground(slides, item) {
    if (!Array.isArray(slides) || !slides.length) return slides || [];
    const slideType = item?.slideType;
    const skip = new Set(['media', 'media-audio']);
    if (skip.has(slideType)) return slides;
    // Slide Designer com camadas: não sobrescrever fundo (gradiente/imagem) com mídia global de letras
    if (slideType === 'custom' && getDesignerSkin(item)?.layers?.length) {
      return slides;
    }

    let background = null;
    // Boas-vindas: um fundo escolhido pelo operador deve vencer o fundo de skin/tema.
    let forceWelcomeBg = false;
    if (slideType === 'welcome') {
      const d = item.data || {};
      if (d.bgMediaId || d.bgMedia) forceWelcomeBg = true;
      if (d.bgMediaId) {
        const m = await getMedia(d.bgMediaId);
        if (m) {
          const src = resolveMediaSrc(m);
          if (src) {
            const isVideo = m.kind === 'video'
              || m.category === 'fundo-animado'
              || m.category === 'loop'
              || String(m.mimeType || m.mime || '').includes('video')
              || /\.(mp4|webm|mov)(\?|$)/i.test(src);
            background = { type: isVideo ? 'video' : 'image', src };
          }
        } else {
          const src = resolveSystemLoopAlias(d.bgMediaId);
          if (src) {
            background = {
              type: /\.mp4|\.webm/i.test(src) ? 'video' : 'image',
              src,
            };
          }
        }
      }
      if (!background && d.bgMedia) {
        const src = resolveSystemLoopAlias(d.bgMediaId)
          || resolveSystemLoopAlias(d.bgMedia)
          || d.bgMedia;
        background = { type: d.bgKind === 'video' ? 'video' : 'image', src };
      }
    }
    const style = itemStyle(item, slideType);
    if (!background) {
      background = await resolveSlideBackground(style, (id) => getMedia(id));
    }
    const hasMediaBg = background?.type === 'video' || background?.type === 'image';

    return slides.map((s) => {
      // Fundo escolhido ao vivo no slide de boas-vindas sobrepõe qualquer fundo de skin/tema
      if (forceWelcomeBg && hasMediaBg) return { ...s, background };
      if (s.background?.type === 'video' || s.background?.type === 'image') return s;
      if (hasMediaBg) {
        return { ...s, background };
      }
      return { ...s, background: s.background || background };
    });
  }

  async resolveItemSlides(item) {
    const slides = await this._resolveItemSlidesCore(item);
    return this.withSlideBackground(slides, item);
  }


  async rebuild(opts = {}) {
    const total = this.items.length;
    const lazy = opts.lazy !== false && total >= 24;
    const chunkSize = Math.max(4, Number(opts.chunkSize) || 16);
    const onProgress = typeof opts.onProgress === 'function' ? opts.onProgress : null;

    const gen = ++this._rebuildGen;
    const newFlatSlides = [];
    const newSlideMeta = [];

    for (let itemIndex = 0; itemIndex < total; itemIndex++) {
      if (gen !== this._rebuildGen) return this.flatSlides;
      const item = this.items[itemIndex];
      const slides = await this.resolveItemSlides(item);
      slides.forEach((slide, slideIndex) => {
        newFlatSlides.push(slide);
        newSlideMeta.push({
          itemIndex,
          slideIndex,
          itemId: item.id,
          itemTitle: item.title,
          slideType: item.slideType,
        });
      });
      if (lazy && itemIndex > 0 && (itemIndex + 1) % chunkSize === 0) {
        onProgress?.(itemIndex + 1, total);
        await new Promise((r) => setTimeout(r, 0));
        if (gen !== this._rebuildGen) return this.flatSlides;
      }
    }

    if (gen !== this._rebuildGen) return this.flatSlides;

    this.flatSlides = newFlatSlides;
    this.slideMeta = newSlideMeta;
    onProgress?.(total, total);

    if (this.currentIndex >= this.flatSlides.length) {
      this.currentIndex = Math.max(0, this.flatSlides.length - 1);
    }

    return this.flatSlides;
  }

  /** Reconstrói apenas um item (evita rebuild global durante culto ao vivo). */
  async rebuildItem(itemIndex) {
    const gen = ++this._rebuildGen;
    const item = this.items[itemIndex];
    if (!item) return this.flatSlides;

    const firstFlatIdx = this.slideMeta.findIndex((m) => m.itemIndex === itemIndex);
    const oldCount = this.getItemSlideRange(itemIndex).length;
    const metaBefore = this.getCurrentMeta();
    const localBefore = metaBefore?.itemIndex === itemIndex ? (metaBefore.slideIndex ?? 0) : null;

    const newSlides = await this.resolveItemSlides(item);
    if (gen !== this._rebuildGen) return this.flatSlides;

    if (firstFlatIdx < 0) {
      return this.rebuild();
    }

    const newMeta = newSlides.map((slide, slideIndex) => ({
      itemIndex,
      slideIndex,
      itemId: item.id,
      itemTitle: item.title,
      slideType: item.slideType,
    }));

    this.flatSlides = [
      ...this.flatSlides.slice(0, firstFlatIdx),
      ...newSlides,
      ...this.flatSlides.slice(firstFlatIdx + oldCount),
    ];
    this.slideMeta = [
      ...this.slideMeta.slice(0, firstFlatIdx),
      ...newMeta,
      ...this.slideMeta.slice(firstFlatIdx + oldCount),
    ];

    if (localBefore != null && newSlides.length > 0) {
      const clampedLocal = Math.min(localBefore, newSlides.length - 1);
      this.currentIndex = firstFlatIdx + clampedLocal;
    } else if (this.currentIndex >= this.flatSlides.length) {
      this.currentIndex = Math.max(0, this.flatSlides.length - 1);
    }
    return this.flatSlides;
  }

  /**
   * Rebuild incremental a partir de startIndex (insert/duplicate).
   * Itens anteriores permanecem; só re-resolve do índice em diante.
   */
  async rebuildFrom(startIndex = 0) {
    const start = Math.max(0, Math.min(startIndex, this.items.length));
    if (start === 0) return this.rebuild();

    const gen = ++this._rebuildGen;
    const keepMeta = this.slideMeta.filter((m) => m.itemIndex < start);
    const keepSlides = this.flatSlides.slice(0, keepMeta.length);
    const newFlat = [...keepSlides];
    const newMeta = [...keepMeta];

    for (let itemIndex = start; itemIndex < this.items.length; itemIndex++) {
      if (gen !== this._rebuildGen) return this.flatSlides;
      const item = this.items[itemIndex];
      const slides = await this.resolveItemSlides(item);
      slides.forEach((slide, slideIndex) => {
        newFlat.push(slide);
        newMeta.push({
          itemIndex,
          slideIndex,
          itemId: item.id,
          itemTitle: item.title,
          slideType: item.slideType,
        });
      });
    }

    if (gen !== this._rebuildGen) return this.flatSlides;
    this.flatSlides = newFlat;
    this.slideMeta = newMeta;
    if (this.currentIndex >= this.flatSlides.length) {
      this.currentIndex = Math.max(0, this.flatSlides.length - 1);
    }
    return this.flatSlides;
  }

  /**
   * Reordena blocos de slides sem re-resolver (move/nudge/drag).
   * fromIndex/toIndex são índices em items[].
   */
  reorderItemBlocks(fromIndex, toIndex) {
    if (fromIndex === toIndex) return this.flatSlides;
    if (fromIndex < 0 || toIndex < 0 || fromIndex >= this.items.length || toIndex >= this.items.length) {
      return this.flatSlides;
    }

    // Agrupa slides por itemIndex (ordem atual)
    const blocks = [];
    for (let i = 0; i < this.items.length; i++) {
      const indices = [];
      this.slideMeta.forEach((m, flatIdx) => {
        if (m.itemIndex === i) indices.push(flatIdx);
      });
      blocks.push({
        itemIndex: i,
        slides: indices.map((fi) => this.flatSlides[fi]),
        meta: indices.map((fi) => ({ ...this.slideMeta[fi] })),
      });
    }

    const [moved] = blocks.splice(fromIndex, 1);
    blocks.splice(toIndex, 0, moved);

    const newFlat = [];
    const newMeta = [];
    blocks.forEach((block, newItemIndex) => {
      block.slides.forEach((slide, slideIndex) => {
        newFlat.push(slide);
        const base = block.meta[slideIndex] || {};
        newMeta.push({
          ...base,
          itemIndex: newItemIndex,
          slideIndex,
        });
      });
    });

    this.flatSlides = newFlat;
    this.slideMeta = newMeta;
    if (this.currentIndex >= this.flatSlides.length) {
      this.currentIndex = Math.max(0, this.flatSlides.length - 1);
    }
    return this.flatSlides;
  }

  getCurrentSlide() {
    if (this.overlay === 'blank') return { type: 'blank' };
    if (this.overlay === 'logo') return { type: 'logo' };
    return this.flatSlides[this.currentIndex] || null;
  }

  getCurrentMeta() {
    return this.slideMeta[this.currentIndex] || null;
  }

  getItemSlideRange(itemIndex) {
    return this.slideMeta.filter((m) => m.itemIndex === itemIndex);
  }

  goToItemSlide(itemIndex, localSlideIndex) {
    const idx = this.slideMeta.findIndex(
      (m) => m.itemIndex === itemIndex && m.slideIndex === localSlideIndex
    );
    if (idx >= 0) return this.goTo(idx);
    return this.getCurrentSlide();
  }

  getLocalSlideIndex() {
    const meta = this.getCurrentMeta();
    return meta?.slideIndex ?? 0;
  }

  next() {
    if (this.overlay) {
      this.overlay = null;
      return this.getCurrentSlide();
    }
    if (this.currentIndex < this.flatSlides.length - 1) {
      this.currentIndex++;
    }
    return this.getCurrentSlide();
  }

  prev() {
    if (this.overlay) {
      this.overlay = null;
      return this.getCurrentSlide();
    }
    if (this.currentIndex > 0) {
      this.currentIndex--;
    }
    return this.getCurrentSlide();
  }

  goTo(index) {
    this.overlay = null;
    this.currentIndex = Math.max(0, Math.min(index, this.flatSlides.length - 1));
    return this.getCurrentSlide();
  }

  goToItem(itemIndex) {
    const idx = this.slideMeta.findIndex((m) => m.itemIndex === itemIndex);
    if (idx >= 0) return this.goTo(idx);
    return this.getCurrentSlide();
  }

  setBlank() {
    this.overlay = 'blank';
    return { type: 'blank' };
  }

  setLogo() {
    this.overlay = 'logo';
    return { type: 'logo' };
  }

  clearOverlay() {
    this.overlay = null;
    return this.getCurrentSlide();
  }

  getState() {
    return {
      items: this.items,
      currentIndex: this.currentIndex,
      overlay: this.overlay,
      slide: this.getCurrentSlide(),
      meta: this.getCurrentMeta(),
      total: this.flatSlides.length,
    };
  }

  applyState(state) {
    if (state.items) this.items = state.items;
    if (typeof state.currentIndex === 'number') this.currentIndex = state.currentIndex;
    if (state.overlay !== undefined) this.overlay = state.overlay;
  }
}

