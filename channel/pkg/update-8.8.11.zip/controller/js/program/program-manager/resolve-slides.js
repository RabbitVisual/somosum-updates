import {
  formatReference,
  formatReferenceParts,
  getPassage,
  splitPassageIntoSlides,
  splitPassageResponsive,
  buildInterlinearSlide,
  resolveBibleDisplayMode,
  resolveBibleDisplayReference,
  getVersions,
} from '../../bible/bible-service.js';
import { defaultOriginalLang } from '../../bible/book-bridge.js';
import { getBookName } from '../../bible/books-map.js';
import { sanitizeBibleRef } from '../../bible/bible-picker.js';
import { buildLyricsSlides, getLyricsStyle, resolveSlideBackground } from '../../lyrics/lyrics-splitter.js';
import { getSong, getMedia } from '../../core/store.js';
import { resolveMediaSrc } from '../../core/media-url.js';
import { getMessageMode, resolveShowPreacherPhoto } from '../../slides/message-display-modes.js';
import {
  getDesignerSkin,
  applyCustomOrdemProps,
  resolveCustomBackground,
  prepareCustomSlideForSync,
} from '../../designer/content-bindings.js';
import { isIntroitoProgramItem } from '../programa-templates.js';
import { itemStyle } from './class-base.js';

export const programManagerResolveSlides = {
  async _resolveItemSlidesCore(item) {
    switch (item.slideType) {
      case 'welcome': {
        const d = item.data || {};
        const skinned = this.skinnedSlideFromItem(item, {
          contentKind: 'welcome',
          style: itemStyle(item, 'welcome'),
          welcome: {
            years: d.years,
            theme: d.theme,
            extraLine: d.extraLine,
            badge: d.badge,
            churchName: d.churchName || this.prefs?.church?.name,
          },
        });
        if (skinned) return [skinned];
        return [{ type: 'welcome', ...d, style: itemStyle(item, 'welcome') }];
      }

      case 'section':
        return [{
          type: 'section',
          title: item.data?.title || item.title,
          style: itemStyle(item, 'section'),
        }];

      case 'participation': {
        const d = item.data || {};
        let songTitle = d.songTitle || '';
        if ((d.participationKind === 'musical' || item.songId) && item.songId) {
          const song = await getSong(item.songId);
          if (song?.title) songTitle = song.title;
        }
        return [{
          type: 'participation',
          participationLabel: d.participationLabel || 'Participação',
          participationKind: d.participationKind || 'musical',
          participantName: d.participantName || '',
          songTitle,
          extraText: d.extraText || '',
          style: itemStyle(item, 'participation'),
        }];
      }

      case 'prayer':
        return [{
          type: 'prayer',
          title: item.data?.title || item.title,
          text: item.data?.text || '',
          style: itemStyle(item, 'prayer'),
        }];

      case 'custom': {
        const text = this.resolveText(item);
        const d = item.data || {};
        const skin = getDesignerSkin(item);
        const style = {
          ...itemStyle(item, 'custom'),
          align: d.align || d.style?.align || 'center',
        };
        if (skin?.layers?.length) {
          const layers = applyCustomOrdemProps(skin.layers, d);
          const background = resolveCustomBackground(d, skin);
          return [prepareCustomSlideForSync({
            type: 'custom',
            title: d.title || item.title,
            subtitle: d.subtitle || '',
            text: text || d.text || '',
            layers,
            background,
            previewDataUrl: skin.previewDataUrl || d.previewDataUrl || undefined,
            designer: {
              version: skin.version || 3,
              width: skin.width,
              height: skin.height,
              preferBitmap: false,
            },
            style,
          })];
        }
        const preset = d.backgroundPreset || d.background?.preset;
        const background = d.background || (preset ? { type: 'gradient', preset } : undefined);
        return [{
          type: 'custom',
          title: d.title || item.title,
          subtitle: d.subtitle || '',
          text: text || d.text || '',
          layers: d.layers || [],
          background,
          previewDataUrl: d.previewDataUrl || undefined,
          designer: d.designer,
          style,
        }];
      }

      case 'message': {
        const d = item.data || {};
        const mode = d.messageMode || 'ref_pregador';
        const modeDef = getMessageMode(mode);
        const showPreacherPhoto = resolveShowPreacherPhoto(d) && d.showPreacherPhoto !== false;
        let preacherPhoto = null;
        if (showPreacherPhoto && d.preacherPhotoId) {
          const m = await getMedia(d.preacherPhotoId);
          if (m) preacherPhoto = resolveMediaSrc(m);
        }
        // Sem URL de foto = não exibe círculo (mesmo se o toggle estiver ligado).
        const showPhotoOnAir = !!(preacherPhoto && showPreacherPhoto);
        const b = item.bible || d.bible;
        const versionKey = b?.version || this.prefs.bibleVersion || 'naa';
        const showVersion = d.showVersion !== false;
        const refStyle = d.refStyle || b?.refStyle || 'colon';
        const override = (d.referenceOverride || b?.referenceOverride || '').trim();
        let reference = '';
        if (modeDef.showReference) {
          reference = override;
          const bibleRef = b;
          if (!reference && bibleRef?.book && bibleRef?.chapter) {
            const wholeChapter = bibleRef.wholeChapter || modeDef.wholeChapter;
            if (wholeChapter) {
              const vers = getVersions().find((v) => v.key === versionKey);
              const bookRef = `${getBookName(bibleRef.book)} ${bibleRef.chapter}`;
              reference = showVersion
                ? `${bookRef} (${vers?.abbrev || versionKey.toUpperCase()})`
                : bookRef;
            } else {
              reference = formatReference(
                bibleRef.book,
                bibleRef.chapter,
                bibleRef.verseStart,
                bibleRef.verseEnd,
                versionKey,
                { showVersion, style: refStyle }
              );
            }
          }
        }
        const theme = modeDef.showTheme ? (d.theme || '').trim() : '';
        const mottoText = (d.mottoText || '').trim();
        return [{
          type: 'message',
          messageMode: mode,
          theme,
          mottoText,
          showMotto: d.showMotto !== false,
          showPreacherPhoto: showPhotoOnAir,
          motto: '',
          reference,
          preacher: d.preacher || '',
          preacherFrom: d.preacherFrom || '',
          preacherPhoto,
          style: {
            fontSize: 80,
            refSize: 34,
            textSize: 30,
            mottoSize: 30,
            preacherSize: 32,
            fromSize: 22,
            photoSize: 200,
            layout: 'balanced',
            align: 'left',
            contentWidth: 94,
            cardWidth: 36,
            textTransform: 'uppercase',
            ...(d.style || {}),
          },
        }];
      }

      case 'theme':
        return [{ type: 'theme', ...item.data, style: itemStyle(item, 'theme') }];

      case 'bible': {
        const b = item.bible;
        const earlySkin = !b?.book || !b?.chapter
          ? this.skinnedSlideFromItem(item, {
            contentKind: isIntroitoProgramItem(item) ? 'introito' : 'bible',
            style: itemStyle(item, 'bible'),
            reference: b?.referenceOverride || '',
            verseText: b?.excerptText || '',
          })
          : null;
        if (earlySkin) return [earlySkin];
        if (!b?.book || !b?.chapter) {
          return [{
            type: 'custom',
            title: item.title,
            text: '',
          }];
        }
        const versionKey = b.version || this.prefs.bibleVersion || 'naa';
        let ref;
        try {
          ref = await sanitizeBibleRef(
            versionKey,
            b.book,
            b.chapter,
            b.verseStart,
            b.verseEnd
          );
        } catch (err) {
          return [{
            type: 'custom',
            title: item.title,
            text: `Erro ao carregar Bíblia: ${err.message}`,
            style: itemStyle(item, 'custom'),
          }];
        }

        const mode = resolveBibleDisplayMode(b);
        const style = itemStyle(item, 'bible');
        const showVersion = b.showVersion !== false;
        const refStyle = b.refStyle || 'colon';
        const chapterOnly = mode === 'chapter';
        const refLayout = b.refLayout || ((mode === 'reference' || chapterOnly) ? 'stacked' : 'inline');
        const refOpts = { style: refStyle, showVersion, layout: refLayout, chapterOnly };
        const referenceDot = formatReference(
          b.book,
          ref.chapter,
          ref.verseStart,
          ref.verseEnd,
          versionKey,
          { ...refOpts, style: 'dot', layout: 'inline' }
        );
        const referenceColon = formatReference(
          b.book,
          ref.chapter,
          ref.verseStart,
          ref.verseEnd,
          versionKey,
          { ...refOpts, layout: 'inline' }
        );
        const referenceFormatted = refStyle === 'dot' ? referenceDot : referenceColon;
        const referenceParts = formatReferenceParts(
          b.book,
          ref.chapter,
          ref.verseStart,
          ref.verseEnd,
          versionKey,
          { style: refStyle, showVersion, chapterOnly }
        );

        if (mode === 'excerpt') {
          const reference = resolveBibleDisplayReference(b, referenceFormatted);
          const excerptText = b.excerptText?.trim() || '';
          const skinned = this.skinnedSlideFromItem(item, {
            contentKind: isIntroitoProgramItem(item) ? 'introito' : 'bible',
            style,
            reference,
            verseText: excerptText,
          });
          if (skinned) return [skinned];
          return [{
            type: 'bible',
            displayMode: 'excerpt',
            reference,
            excerptText,
            style,
          }];
        }

        if (mode === 'interlinear') {
          try {
            const ptVersion = versionKey === 'grc-tr' || versionKey === 'heb-tagged'
              ? (this.prefs.bibleVersion || 'naa')
              : versionKey;
            const passage = await getPassage(
              ptVersion,
              b.book,
              ref.chapter,
              ref.verseStart,
              ref.verseEnd
            );
            const refLabel = resolveBibleDisplayReference(b, referenceFormatted);
            const slides = await buildInterlinearSlide(passage, {
              originalLang: b.originalLang || defaultOriginalLang(b.book),
              interlinear: {
                ...(b.interlinear || {}),
                versesPerSlide: b.interlinear?.versesPerSlide || this.prefs.versesPerSlide || 1,
              },
              versesPerSlide: b.interlinear?.versesPerSlide || this.prefs.versesPerSlide || 1,
            });
            return slides.map((slide) => ({
              ...slide,
              reference: refLabel,
              style,
            }));
          } catch (err) {
            return [{
              type: 'custom',
              title: item.title,
              text: `Erro interlinear: ${err.message}`,
              style: itemStyle(item, 'custom'),
            }];
          }
        }

        if (mode === 'verses') {
          try {
            const passage = await getPassage(
              versionKey,
              b.book,
              ref.chapter,
              ref.verseStart,
              ref.verseEnd
            );
            const refLabel = resolveBibleDisplayReference(b, referenceFormatted);
            let versesB = null;
            let versionB = null;
            if (b.dual && b.versionB && b.versionB !== versionKey) {
              try {
                const passageB = await getPassage(
                  b.versionB,
                  b.book,
                  ref.chapter,
                  ref.verseStart,
                  ref.verseEnd
                );
                versesB = passageB.verses;
                versionB = b.versionB;
              } catch { /* dual opcional */ }
            }
            return splitPassageIntoSlides(
              passage,
              this.prefs.versesPerSlide || 2,
              { versionKey, style: refStyle, showVersion }
            ).map((slide) => {
              const out = { ...slide, style, dual: !!versesB };
              if (versesB) {
                // Align versesB by verse numbers present on this slide
                const nums = new Set((slide.verses || []).map((v) => v.number));
                out.versesB = versesB.filter((v) => nums.has(v.number));
                out.versionB = versionB;
                out.versionLabel = versionKey;
                out.versionLabelB = versionB;
              }
              const verseText = (out.verses || [])
                .map((v) => (v.number != null ? `${v.number} ${v.text}` : v.text))
                .join('\n')
                .trim();
              const skinned = this.skinnedSlideFromItem(item, {
                contentKind: 'bible',
                style,
                reference: refLabel || out.reference || '',
                verseText,
              });
              return skinned || out;
            });
          } catch (err) {
            return [{
              type: 'custom',
              title: item.title,
              text: `Erro ao carregar Bíblia: ${err.message}`,
              style: itemStyle(item, 'custom'),
            }];
          }
        }

        return [{
          type: 'bible',
          referenceOnly: true,
          chapterOnly,
          reference: resolveBibleDisplayReference(b, referenceFormatted),
          refLayout,
          referenceParts,
          style,
        }].map((slide) => {
          const skinned = this.skinnedSlideFromItem(item, {
            contentKind: 'bible',
            style,
            reference: slide.reference,
            verseText: '',
          });
          return skinned || slide;
        });
      }

      case 'bible-responsive': {
        const b = item.bible;
        if (!b?.book || !b?.chapter) {
          return [{
            type: 'custom',
            title: item.title,
            text: '',
          }];
        }
        const versionKey = b.version || this.prefs.bibleVersion || 'naa';
        let ref;
        try {
          ref = await sanitizeBibleRef(
            versionKey,
            b.book,
            b.chapter,
            b.verseStart,
            b.verseEnd
          );
        } catch (err) {
          return [{
            type: 'custom',
            title: item.title,
            text: `Erro ao carregar Bíblia: ${err.message}`,
            style: itemStyle(item, 'custom'),
          }];
        }
        try {
          const passage = await getPassage(
            versionKey,
            b.book,
            ref.chapter,
            ref.verseStart,
            ref.verseEnd
          );
          const style = itemStyle(item, 'bible-responsive');
          const refStyle = b.refStyle || 'colon';
          const referenceFormatted = formatReference(
            b.book,
            ref.chapter,
            ref.verseStart,
            ref.verseEnd,
            versionKey,
            { style: refStyle, showVersion: b.showVersion !== false }
          );
          const refLabel = resolveBibleDisplayReference(b, referenceFormatted);
          return splitPassageResponsive(passage, {
            versesPerSlide: this.prefs.versesPerSlide || 2,
          }).map((slide) => ({
            ...slide,
            reference: refLabel,
            style,
          }));
        } catch (err) {
          return [{
            type: 'custom',
            title: item.title,
            text: `Erro leitura responsiva: ${err.message}`,
            style: itemStyle(item, 'custom'),
          }];
        }
      }

      case 'lyrics': {
        const song = await this.cacheSong(item.songId);
        const style = getLyricsStyle(song, this.prefs.globalLyricsStyle, item.data?.lyricsStyle);
        const background = await resolveSlideBackground(style, (id) => getMedia(id));
        const transition = item.data?.lyricsStyle?.transition || style.transition || null;
        const lyricsFx = item.data?.lyricsFx || this.prefs.lyricsFx || null;
        const slides = buildLyricsSlides(
          song || { title: item.title, artist: '', lyrics: '' },
          style,
          {
            itemTitle: item.title,
            placeholder: item.placeholder,
            background,
          }
        );
        const attachFx = (s) => {
          const out = { ...s };
          if (lyricsFx) {
            out.data = { ...(out.data || {}), lyricsFx };
            out.lyricsFx = lyricsFx;
          }
          return out;
        };
        if (!transition) return slides.map(attachFx);
        return slides.map((slide) => attachFx({ ...slide, transition }));
      }

      case 'announcements': {
        const d = item.data || {};
        const rawItems = Array.isArray(d.items) ? d.items : [];
        const items = rawItems.length
          ? rawItems
          : (typeof d.text === 'string' ? d.text : '')
              .split('\n')
              .map((line) => line.trim())
              .filter(Boolean)
              .map((text) => ({ icon: '•', text }));
        const perPage = d.perPage || 4;
        const slides = [];
        for (let i = 0; i < items.length; i += perPage) {
          slides.push({
            type: 'announcements',
            title: d.title || item.title || 'Comunicados',
            items: items.slice(i, i + perPage),
            page: Math.floor(i / perPage) + 1,
            totalPages: Math.ceil(items.length / perPage) || 1,
            style: itemStyle(item, 'announcements'),
          });
        }
        if (!slides.length) {
          slides.push({
            type: 'announcements',
            title: d.title || item.title || 'Comunicados',
            items: [],
            page: 1,
            totalPages: 1,
            style: itemStyle(item, 'announcements'),
          });
        }
        return slides;
      }

      case 'communion': {
        const d = item.data || {};
        const phases = Array.isArray(d.phases) ? d.phases : [];
        const style = itemStyle(item, 'communion');
        const transition = item.transition || null;
        if (!phases.length) {
          return [{
            type: 'communion',
            phase: { title: item.title || 'Ceia do Senhor', id: 'intro' },
            showCross: d.showCross === true,
            showElements: d.showElements !== false,
            useCommunionTheme: d.useCommunionTheme !== false,
            style,
            transition,
          }];
        }
        return phases.map((phase, i) => ({
          type: 'communion',
          phase,
          phaseIndex: i,
          totalPhases: phases.length,
          showCross: d.showCross === true,
          showElements: d.showElements !== false,
          useCommunionTheme: d.useCommunionTheme !== false,
          style,
          transition,
        }));
      }

      case 'media': {
        const m = item.mediaId ? await getMedia(item.mediaId) : null;
        if (!m) {
          return [{
            type: 'custom',
            title: item.title,
            text: 'Selecione uma imagem ou video na biblioteca de midia.',
          }];
        }
        return [{
          type: 'media',
          kind: m.kind,
          src: resolveMediaSrc(m),
          title: item.title || m.name,
          loop: item.data?.loop !== false,
          style: itemStyle(item, 'media'),
        }];
      }

      case 'deck':
      case 'pptx': {
        const list = Array.isArray(item.data?.slides) ? item.data.slides : [];
        if (!list.length) {
          return [{
            type: 'custom',
            title: item.title || 'Apresentação',
            text: 'Apresentação vazia — importe um .pptx em Ferramentas → PowerPoint.',
            style: itemStyle(item, 'custom'),
          }];
        }
        const out = [];
        for (const s of list) {
          if (s?.kind === 'media' && s.mediaId) {
            const m = await getMedia(s.mediaId);
            if (m) {
              out.push({
                type: 'media',
                kind: m.kind,
                src: resolveMediaSrc(m),
                title: s.title || item.title || m.name,
                loop: false,
                style: itemStyle(item, 'media'),
              });
              continue;
            }
          }
          out.push({
            type: 'custom',
            title: s?.title || item.title || '',
            text: s?.text || '',
            style: itemStyle(item, 'custom'),
          });
        }
        return out.length ? out : [{
          type: 'custom',
          title: item.title || 'Apresentação',
          text: '',
          style: itemStyle(item, 'custom'),
        }];
      }

      case 'media-audio': {
        const path = item.data?.audioPath || '';
        const d = item.data || {};
        return [{
          type: 'media-audio',
          title: d.screenTitle || item.title || 'Áudio',
          hint: d.hint || item.placeholder || '',
          src: path ? `/${path.replace(/^\//, '')}` : '',
          coverSrc: d.coverSrc || '',
          loop: d.loop === true,
          style: itemStyle(item, 'media'),
        }];
      }

      case 'offering': {
        const d = item.data || {};
        return [{
          type: 'offering',
          title: d.title || item.title || 'Oferta e Dízimos',
          subtitle: d.subtitle || '',
          verse: d.verse || '',
          offeringLayout: d.template || 'classic',
          style: itemStyle(item, 'section'),
        }];
      }

      case 'countdown': {
        const d = item.data || {};
        const mins = d.durationMin ? `${d.durationMin} min` : '';
        const note = [d.note, mins].filter(Boolean).join(' · ');
        return [{
          type: 'countdown-pause',
          title: d.title || item.title || 'Pausa',
          note,
          style: itemStyle(item, 'section'),
        }];
      }

      default:
        return [{ type: 'custom', title: item.title, text: '', style: itemStyle(item, 'custom') }];
    }
  }

  /**
   * Rebuild completo. Com lazy=true (default em programas grandes), cede ao event
   * loop a cada `chunkSize` itens para não congelar a UI (U3-B, 200+ itens).
   * @param {{ lazy?: boolean, chunkSize?: number, onProgress?: (done: number, total: number) => void }} [opts]
   */
};
