export { ProgramManager, MAX_SONGS_CACHE } from './class-base.js';
import { ProgramManager } from './class-base.js';
import { programManagerResolveSlides } from './resolve-slides.js';
Object.assign(ProgramManager.prototype, programManagerResolveSlides);
