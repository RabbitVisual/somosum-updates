﻿import { createCommunionItem } from '../../data/communion-defaults.js';
import {
  applyPackSlideDefaults,
  getCultoThemePack,
  welcomeVisualFromPack,
} from '../culto-theme-packs.js';
import {
  welcomeItem,
  introitoItem,
  themeSomosUmItem,
  prayerItem,
  sectionItem,
  lyricsItem,
  bibleReadingItem,
  messageItem,
  mediaAudioItem,
} from './items.js';

export const CULTO_WIZARD_BLOCKS = [
  { id: 'welcome', label: 'Boas-vindas', icon: 'hand-wave', hint: 'Tela de abertura do culto' },
  { id: 'theme', label: 'Tema / Divisa', icon: 'sparkles', hint: 'Slide de tema do evento' },
  { id: 'introito', label: 'Introito bíblico', icon: 'book-open', hint: 'Versículo de abertura' },
  { id: 'openingPrayer', label: 'Oração inicial', icon: 'hands-praying', hint: 'Momento de oração de abertura' },
  { id: 'praise', label: 'Momento de louvores', icon: 'music', hint: 'Bloco de músicas de louvor', count: true, defaultCount: 3 },
  { id: 'bibleReading', label: 'Leitura bíblica', icon: 'book-bible', hint: 'Leitura da Palavra' },
  { id: 'dedication', label: 'Dedicação de vidas e bens', icon: 'hand-holding-heart', hint: 'Seção + música(s) de dedicação', count: true, defaultCount: 1 },
  { id: 'gratitude', label: 'Gratidão e pedidos', icon: 'dove', hint: 'Seção + oração de gratidão' },
  { id: 'prayerAudio', label: 'Momento de oração (fundo musical)', icon: 'headphones', hint: 'Seção + áudio de fundo ~5 min' },
  { id: 'fellowship', label: 'Confraternização', icon: 'handshake', hint: 'Seção + música(s)', count: true, defaultCount: 2 },
  { id: 'message', label: 'Mensagem bíblica', icon: 'bullhorn', hint: 'Pregação / palavra' },
  { id: 'communion', label: 'Ceia do Senhor', icon: 'wine-glass', hint: 'Em memória de Cristo' },
  { id: 'finalPrayer', label: 'Oração final / bênção', icon: 'sparkles', hint: 'Encerramento' },
];

/**
 * Retorna o spec padrão do assistente para um tipo de culto.
 * Espelha as ordens embutidas, mas em formato editável.
 */
export function cultoWizardDefaults(type = 'domingo') {
  const base = {
    type,
    welcome: true,
    theme: false,
    introito: true,
    openingPrayer: true,
    praise: true,
    praiseCount: 3,
    bibleReading: true,
    dedication: true,
    dedicationCount: 1,
    gratitude: true,
    prayerAudio: false,
    fellowship: true,
    fellowshipCount: 2,
    message: true,
    communion: false,
    finalPrayer: true,
  };
  switch (type) {
    case 'quarta':
      return { ...base, dedication: false, dedicationCount: 0, fellowship: false, fellowshipCount: 0, prayerAudio: true, praiseCount: 3 };
    case 'especial':
      return { ...base, theme: true };
    case 'domingo-com-ceia':
      return { ...base, communion: true };
    case 'missoes':
      return { ...base, theme: true };
    case 'mulheres':
      return { ...base, praiseCount: 2, dedicationCount: 2, fellowship: false, fellowshipCount: 0, message: true };
    case 'homens':
      return { ...base, praiseCount: 3, dedication: false, dedicationCount: 0, fellowship: false, fellowshipCount: 0 };
    case 'jovens':
      return { ...base, openingPrayer: false, introito: false, praiseCount: 4, dedication: false, dedicationCount: 0, fellowship: false, fellowshipCount: 0 };
    case 'criancas':
      return { ...base, openingPrayer: false, introito: false, praiseCount: 2, bibleReading: true, dedication: false, dedicationCount: 0, gratitude: false, fellowship: false, fellowshipCount: 0, message: true, finalPrayer: true };
    case 'aniversario':
      return { ...base, theme: true };
    case 'domingo':
    default:
      return base;
  }
}

/**
 * Monta uma ordem de culto completa a partir das respostas do assistente.
 * Reutiliza os mesmos blocos das ordens embutidas e aplica o theme pack do tipo.
 * @param {object} spec ver cultoWizardDefaults()
 * @param {object} church prefs de igreja (nome/logo)
 */
export function createProgramFromWizardSpec(spec = {}, church = {}) {
  const type = spec.type || 'domingo';
  const pack = getCultoThemePack(type);
  const visual = welcomeVisualFromPack(type);
  const items = [];
  let musicNo = 0;
  const nextMusic = (suffix = '') => {
    musicNo += 1;
    const hint = suffix
      ? `Música ${musicNo} — ${suffix} — escolha no Louvores`
      : `Música ${musicNo} — escolha no Louvores`;
    return lyricsItem(`Música ${musicNo}`, hint);
  };
  const count = (key, fallback) => {
    const n = Number(spec[key]);
    if (!Number.isFinite(n) || n < 0) return fallback;
    return Math.min(12, Math.floor(n));
  };

  if (spec.welcome !== false) {
    items.push(welcomeItem({
      title: spec.welcomeTitle || 'Boas-Vindas',
      welcomePreset: pack.welcomePreset,
      ...visual,
    }, church));
  }
  if (spec.theme) {
    items.push(themeSomosUmItem());
  }
  if (spec.introito) {
    items.push(introitoItem());
  }
  if (spec.openingPrayer) {
    items.push(prayerItem('Oração inicial'));
  }
  if (spec.praise !== false && count('praiseCount', 3) > 0) {
    items.push(sectionItem(spec.praiseSectionTitle || 'Momento de louvores'));
    const n = count('praiseCount', 3);
    for (let i = 0; i < n; i++) items.push(nextMusic());
  }
  if (spec.bibleReading) {
    items.push(bibleReadingItem());
  }
  if (spec.dedication && count('dedicationCount', 1) > 0) {
    items.push(sectionItem('Dedicação de Vidas e Bens'));
    const n = count('dedicationCount', 1);
    for (let i = 0; i < n; i++) items.push(nextMusic('Dedicação'));
  }
  if (spec.gratitude) {
    items.push(sectionItem('Momento de expressão de gratidão e pedidos'));
    items.push(prayerItem('Oração de Gratidão'));
  }
  if (spec.prayerAudio) {
    items.push(sectionItem('Momento de oração'));
    items.push(mediaAudioItem('Fundo Musical para 5 min de oração', 'Selecione áudio de fundo / ~5 min'));
  }
  if (spec.fellowship && count('fellowshipCount', 2) > 0) {
    items.push(sectionItem('Confraternização'));
    const n = count('fellowshipCount', 2);
    for (let i = 0; i < n; i++) items.push(nextMusic('Confraternização'));
  }
  if (spec.message) {
    items.push(messageItem({ title: 'Mensagem Bíblica', reference: 'Livro, Capítulo, Versículo X a Y' }));
  }
  if (spec.communion) {
    items.push(createCommunionItem());
  }
  if (spec.finalPrayer !== false) {
    items.push(prayerItem('Oração Final / Bênção Apostólica'));
  }

  return applyPackSlideDefaults(items, pack);
}

/** Alias legado do plano original (programa-23-anos). */
export function createPrograma23Anos() {
  return createDefaultProgram();
}

/** @deprecated Mantido por compatibilidade. */
export function hydrateProgramItems(items) {
  return items;
}
