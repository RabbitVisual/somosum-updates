import { DiskAdapter } from '../core/storage/adapters/disk-adapter.js';
import { createProgramFromTemplate, createProgramFromWizardSpec } from './programa-templates.js';
import { cacheCulto, getCachedCulto, cacheCultoIndex, getCachedCultoIndex } from '../core/culto-cache.js';
import { localDateISO, localWeekRange } from '../control/utils/culto-date.js';

const INDEX_FILE = 'cultos/index.json';

export const CULTO_DEFAULTS = {
  domingo: { title: 'Culto de Celebração', serviceTime: '18:30' },
  'domingo-com-ceia': { title: 'Ceia do Senhor', serviceTime: '18:30' },
  quarta: { title: 'Culto de Oração', serviceTime: '19:00' },
  especial: { title: 'Culto Especial', serviceTime: '19:00' },
  missoes: { title: 'Culto de Missões', serviceTime: '19:00' },
  mulheres: { title: 'Ministério de Mulheres', serviceTime: '19:00' },
  homens: { title: 'Ministério de Homens', serviceTime: '19:00' },
  jovens: { title: 'Culto de Jovens', serviceTime: '19:00' },
  criancas: { title: 'Ministério Infantil', serviceTime: '10:00' },
  aniversario: { title: 'Aniversário da Congregação', serviceTime: '18:30' },
};

const TYPE_LABELS = {
  domingo: 'Celebração',
  'domingo-com-ceia': 'Ceia do Senhor',
  quarta: 'Oração',
  especial: 'Especial',
  missoes: 'Missões',
  mulheres: 'Mulheres',
  homens: 'Homens',
  jovens: 'Jovens',
  criancas: 'Crianças',
  aniversario: 'Aniversário',
  blank: 'Personalizado',
};

function cultoFileName(id) {
  return `cultos/${id}.json`;
}

function formatDateId(date, type) {
  return `${date}-${type}`;
}

function uniqueCultoId(date, type, cultos) {
  let id = formatDateId(date, type);
  let n = 0;
  while (cultos.some((c) => c.id === id)) {
    n += 1;
    id = `${formatDateId(date, type)}-${n}`;
  }
  return id;
}

function sortCultos(cultos) {
  return [...cultos].sort((a, b) => {
    const byDate = String(b.date || '').localeCompare(String(a.date || ''));
    if (byDate) return byDate;
    return String(a.serviceTime || '').localeCompare(String(b.serviceTime || ''));
  });
}

/** Une índices cache + disco para não perder culto em corrida de gravação 202. */
function mergeCultoIndexes(disk, cached) {
  const map = new Map();
  for (const src of [disk, cached]) {
    for (const c of src?.cultos || []) {
      if (!c?.id) continue;
      const prev = map.get(c.id);
      if (!prev || String(c.updatedAt || '') >= String(prev.updatedAt || '')) {
        map.set(c.id, { ...prev, ...c });
      }
    }
  }
  const diskTs = disk?.updatedAt || '';
  const cacheTs = cached?.updatedAt || '';
  const activeId = (cacheTs >= diskTs ? cached?.activeId : disk?.activeId)
    || cached?.activeId
    || disk?.activeId
    || null;
  const updatedAt = cacheTs >= diskTs ? (cacheTs || diskTs) : (diskTs || cacheTs);
  return {
    cultos: sortCultos([...map.values()]),
    activeId: map.has(activeId) ? activeId : ([...map.keys()][0] || null),
    updatedAt: updatedAt || new Date().toISOString(),
  };
}

function readWorkingIndex() {
  const cached = getCachedCultoIndex();
  if (cached?.cultos) return { cultos: [...cached.cultos], activeId: cached.activeId || null, updatedAt: cached.updatedAt };
  return { cultos: [], activeId: null };
}

export async function loadCultoIndex() {
  const data = await DiskAdapter.load(INDEX_FILE);
  const cached = getCachedCultoIndex();
  if (data?.cultos || cached?.cultos) {
    const merged = mergeCultoIndexes(data?.cultos ? data : null, cached?.cultos ? cached : null);
    cacheCultoIndex(merged);
    return merged;
  }
  return { cultos: [], activeId: null };
}

export async function saveCultoIndex(index) {
  const payload = {
    cultos: sortCultos(index.cultos || []),
    activeId: index.activeId || null,
    updatedAt: new Date().toISOString(),
    version: index.version || 1,
  };
  cacheCultoIndex(payload);
  const ok = await DiskAdapter.save(INDEX_FILE, payload);
  return ok;
}

export async function getCulto(id) {
  const cached = getCachedCulto(id);
  const data = await DiskAdapter.load(cultoFileName(id));
  if (data?._deleted) return null;

  let diskPayload = null;
  if (Array.isArray(data)) {
    diskPayload = { id, items: data };
  } else if (data && Array.isArray(data.items)) {
    diskPayload = { id, ...data };
  }

  // Prefere o mais recente entre disco e cache (evita perder ordem após save 202)
  if (diskPayload && cached?.items) {
    const diskTs = String(diskPayload.updatedAt || '');
    const cacheTs = String(cached.updatedAt || '');
    if (cacheTs && (!diskTs || cacheTs > diskTs)) {
      return cached;
    }
    cacheCulto(id, diskPayload);
    return diskPayload;
  }
  if (diskPayload) {
    cacheCulto(id, diskPayload);
    return diskPayload;
  }
  return cached;
}

/** Recria arquivo de culto ausente a partir do programa em cache. */
export async function repairCulto(id, fallbackItems = null) {
  const index = await loadCultoIndex();
  const meta = index.cultos.find((c) => c.id === id);
  if (!meta) return null;

  let items = fallbackItems;
  if (!items?.length) {
    const { getProgram } = await import('../core/store.js');
    items = await getProgram();
  }
  if (!Array.isArray(items) || items.length === 0) return null;

  await saveCulto(id, items, meta);
  return { id, items, ...meta };
}

export async function saveCulto(id, items, meta = {}) {
  const payload = {
    ...meta,
    id,
    items,
    updatedAt: new Date().toISOString(),
  };
  // Nunca deixar meta.items antigo sobrescrever a ordem atual
  payload.items = items;
  cacheCulto(id, payload);

  const fileOk = await DiskAdapter.save(cultoFileName(id), payload);

  // Base no cache (mais fresco) e mescla com disco — evita apagar culto recém-criado
  const working = readWorkingIndex();
  const disk = await DiskAdapter.load(INDEX_FILE);
  const index = mergeCultoIndexes(disk?.cultos ? disk : null, working);

  const existing = index.cultos.find((c) => c.id === id);
  const entry = {
    id,
    date: meta.date || existing?.date || localDateISO(),
    type: meta.type || existing?.type || 'especial',
    title: meta.title || existing?.title || 'Culto',
    serviceTime: meta.serviceTime ?? existing?.serviceTime ?? null,
    status: meta.status || existing?.status || 'draft',
    updatedAt: payload.updatedAt,
  };
  if (existing) Object.assign(existing, entry);
  else index.cultos.push(entry);
  index.cultos = sortCultos(index.cultos);
  if (meta.setActive) index.activeId = id;

  const indexOk = await saveCultoIndex(index);
  if (!fileOk || !indexOk) {
    return { ...payload, offline: true, indexOk: !!indexOk, fileOk: !!fileOk };
  }
  return payload;
}

export async function createCulto({ date, type, title, template, serviceTime, church, items: providedItems, wizardSpec }) {
  const index = await loadCultoIndex();
  const dayType = type || suggestCultoType(date);
  const defaults = CULTO_DEFAULTS[dayType] || CULTO_DEFAULTS.especial;
  const id = uniqueCultoId(date, dayType, index.cultos);
  const knownTpl = [
    'domingo', 'quarta', 'especial', 'domingo-com-ceia',
    'missoes', 'mulheres', 'homens', 'jovens', 'criancas', 'aniversario', 'blank',
  ];
  const defaultTpl = knownTpl.includes(dayType) ? dayType : 'domingo';
  const tpl = template || defaultTpl;
  let churchPrefs = church;
  if (!churchPrefs) {
    try {
      const { getPrefs } = await import('../core/store.js');
      churchPrefs = getPrefs()?.church || {};
    } catch {
      churchPrefs = {};
    }
  }
  let items;
  if (Array.isArray(providedItems)) {
    items = providedItems;
  } else if (wizardSpec && typeof wizardSpec === 'object') {
    items = createProgramFromWizardSpec({ ...wizardSpec, type: wizardSpec.type || dayType }, churchPrefs);
  } else {
    items = createProgramFromTemplate(tpl, churchPrefs);
  }
  const cultoTitle = title || defaults.title;
  const time = serviceTime || defaults.serviceTime;

  const saved = await saveCulto(id, items, {
    date,
    type: dayType,
    title: cultoTitle,
    serviceTime: time,
    status: 'draft',
    setActive: true,
  });

  // Alinha atmosfera de projeção ao pack do culto (SSOT)
  try {
    const { getCultoThemePack } = await import('./culto-theme-packs.js');
    const { savePrefs, getPrefs } = await import('../core/store.js');
    const atm = getCultoThemePack(dayType)?.atmosphereId;
    if (atm) {
      const prefs = getPrefs();
      savePrefs({ ...prefs, projectionTheme: atm, theme: atm });
    }
  } catch { /* ignore */ }

  return {
    id,
    date,
    type: dayType,
    title: cultoTitle,
    serviceTime: time,
    items,
    status: 'draft',
    offline: !!saved?.offline,
  };
}

export async function deleteCulto(id) {
  const index = await loadCultoIndex();
  index.cultos = index.cultos.filter((c) => c.id !== id);
  if (index.activeId === id) index.activeId = index.cultos[0]?.id || null;
  cacheCultoIndex(index);
  await DiskAdapter.save(cultoFileName(id), { id, _deleted: true, items: [], updatedAt: new Date().toISOString() });
  await saveCultoIndex(index);
  return index;
}

export async function setActiveCulto(id) {
  // Usa cache primeiro — DiskAdapter.load pode ainda não ter o culto recém-gravado (202)
  const working = readWorkingIndex();
  const disk = await DiskAdapter.load(INDEX_FILE);
  const index = mergeCultoIndexes(disk?.cultos ? disk : null, working.cultos.length ? working : null);
  index.activeId = id;
  await saveCultoIndex(index);
  return index;
}

export async function listCultos() {
  return loadCultoIndex();
}

export async function getActiveCulto() {
  const index = await loadCultoIndex();
  if (!index.activeId) return null;
  const culto = await getCulto(index.activeId);
  if (!culto) return null;
  const meta = index.cultos.find((c) => c.id === index.activeId);
  return { ...meta, items: culto.items };
}

export async function migrateLegacyProgram(programItems) {
  const index = await loadCultoIndex();
  if (index.cultos.length > 0) {
    for (const entry of index.cultos) {
      const existing = await getCulto(entry.id);
      if (!existing?.items?.length && Array.isArray(programItems) && programItems.length) {
        await repairCulto(entry.id, programItems);
      }
    }
    return index;
  }
  if (!Array.isArray(programItems) || programItems.length === 0) return index;

  const today = localDateISO();
  const id = `legacy-${today}`;
  await saveCulto(id, programItems, {
    date: today,
    type: 'especial',
    title: 'Programa Atual',
    status: 'draft',
    setActive: true,
  });
  return loadCultoIndex();
}

export function getCultosForMonth(cultos, year, month) {
  const prefix = `${year}-${String(month).padStart(2, '0')}`;
  return cultos.filter((c) => c.date?.startsWith(prefix));
}

export function getCultosForWeek(cultos, refDate = new Date()) {
  const { startStr, endStr } = localWeekRange(refDate);
  return cultos
    .filter((c) => c.date >= startStr && c.date <= endStr)
    .sort((a, b) => String(a.date || '').localeCompare(String(b.date || '')));
}

export function getCultosForDate(cultos, dateStr) {
  return (cultos || [])
    .filter((c) => c.date === dateStr)
    .sort((a, b) => String(a.serviceTime || '').localeCompare(String(b.serviceTime || '')));
}

export function suggestCultoType(dateStr) {
  const d = new Date(`${dateStr}T12:00:00`);
  const day = d.getDay();
  if (day === 0) return 'domingo';
  if (day === 3) return 'quarta';
  return 'especial';
}

export function statusLabel(status) {
  if (status === 'ready') return 'Pronto';
  if (status === 'done') return 'Realizado';
  return 'Rascunho';
}

export { TYPE_LABELS, formatDateId };
