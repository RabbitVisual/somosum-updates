/**
 * WebGL2 post-process — brilho + sombra suave (fullscreen quad).
 * Fallback silencioso se WebGL indisponível.
 */

const VERT = `#version 300 es
in vec2 a_pos;
out vec2 v_uv;
void main() {
  v_uv = a_pos * 0.5 + 0.5;
  gl_Position = vec4(a_pos, 0.0, 1.0);
}`;

const FRAG = `#version 300 es
precision highp float;
in vec2 v_uv;
uniform sampler2D u_tex;
uniform float u_brightness;
uniform float u_shadow;
out vec4 outColor;
void main() {
  vec4 c = texture(u_tex, v_uv);
  float vig = smoothstep(0.95, 0.35, length(v_uv - 0.5));
  c.rgb *= u_brightness;
  c.rgb *= mix(1.0 - u_shadow, 1.0, vig);
  outColor = c;
}`;

function compile(gl, type, src) {
  const sh = gl.createShader(type);
  gl.shaderSource(sh, src);
  gl.compileShader(sh);
  if (!gl.getShaderParameter(sh, gl.COMPILE_STATUS)) {
    gl.deleteShader(sh);
    return null;
  }
  return sh;
}

export class WebGlPostFx {
  constructor(canvas) {
    this.canvas = canvas;
    this.gl = null;
    this.program = null;
    this._ok = false;
    this._init();
  }

  get available() {
    return this._ok;
  }

  _init() {
    if (!this.canvas) return;
    const gl = this.canvas.getContext('webgl2', {
      alpha: true,
      antialias: false,
      preserveDrawingBuffer: false,
      powerPreference: 'high-performance',
    });
    if (!gl) return;
    const vs = compile(gl, gl.VERTEX_SHADER, VERT);
    const fs = compile(gl, gl.FRAGMENT_SHADER, FRAG);
    if (!vs || !fs) return;
    const prog = gl.createProgram();
    gl.attachShader(prog, vs);
    gl.attachShader(prog, fs);
    gl.linkProgram(prog);
    if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) return;
    this.gl = gl;
    this.program = prog;
    this._buf = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, this._buf);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([
      -1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, 1,
    ]), gl.STATIC_DRAW);
    this._tex = gl.createTexture();
    this._ok = true;
  }

  /**
   * @param {HTMLCanvasElement} sourceCanvas
   * @param {{ brightness?: number, shadow?: number }} opts
   */
  apply(sourceCanvas, opts = {}) {
    if (!this._ok || !this.gl || !sourceCanvas) return false;
    const gl = this.gl;
    const w = sourceCanvas.width || 1920;
    const h = sourceCanvas.height || 1080;
    if (this.canvas.width !== w || this.canvas.height !== h) {
      this.canvas.width = w;
      this.canvas.height = h;
    }
    gl.viewport(0, 0, w, h);
    gl.useProgram(this.program);

    gl.bindTexture(gl.TEXTURE_2D, this._tex);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, sourceCanvas);

    const loc = gl.getAttribLocation(this.program, 'a_pos');
    gl.bindBuffer(gl.ARRAY_BUFFER, this._buf);
    gl.enableVertexAttribArray(loc);
    gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0);

    gl.uniform1i(gl.getUniformLocation(this.program, 'u_tex'), 0);
    gl.uniform1f(gl.getUniformLocation(this.program, 'u_brightness'), opts.brightness ?? 1.05);
    gl.uniform1f(gl.getUniformLocation(this.program, 'u_shadow'), opts.shadow ?? 0.22);

    gl.drawArrays(gl.TRIANGLES, 0, 6);
    return true;
  }

  dispose() {
    const gl = this.gl;
    if (!gl) return;
    try {
      if (this._tex) gl.deleteTexture(this._tex);
      if (this._buf) gl.deleteBuffer(this._buf);
      if (this.program) gl.deleteProgram(this.program);
    } catch { /* ignore */ }
    this._ok = false;
  }
}

export function canUseWebGlPostFx() {
  try {
    const c = document.createElement('canvas');
    const gl = c.getContext('webgl2');
    return !!gl;
  } catch {
    return false;
  }
}
