/**
 * Canvas2D painter — tipografia + fundo sólido/gradiente (1920×1080 design).
 */
import { fitLinesInBox } from '../slide-overflow-fit.js';

const DESIGN_W = 1920;
const DESIGN_H = 1080;

export class Canvas2dPainter {
  constructor(canvas) {
    this.canvas = canvas;
    this.ctx = canvas?.getContext?.('2d', { alpha: true, desynchronized: true }) || null;
    this._bitmaps = new Map();
  }

  cacheBitmap(key, bitmap) {
    if (!key || !bitmap) return;
    const prev = this._bitmaps.get(key);
    try { prev?.close?.(); } catch { /* ignore */ }
    this._bitmaps.set(key, bitmap);
  }

  resize(w = DESIGN_W, h = DESIGN_H) {
    if (!this.canvas) return;
    if (this.canvas.width !== w || this.canvas.height !== h) {
      this.canvas.width = w;
      this.canvas.height = h;
    }
  }

  async paint(slide, ctxOpts = {}) {
    if (!this.ctx || !this.canvas) return false;
    this.resize();
    const ctx = this.ctx;
    ctx.clearRect(0, 0, DESIGN_W, DESIGN_H);

    await this._paintBackground(ctx, slide, ctxOpts);
    await this._paintText(ctx, slide, ctxOpts);
    return true;
  }

  async _paintBackground(ctx, slide, ctxOpts) {
    const key = slide?.id || slide?.type;
    const cached = key ? this._bitmaps.get(key) : null;
    if (cached) {
      ctx.drawImage(cached, 0, 0, DESIGN_W, DESIGN_H);
      return;
    }
    const bg = slide?.background;
    if (bg?.type === 'gradient' || slide?.type === 'theme') {
      const g = ctx.createLinearGradient(0, 0, DESIGN_W, DESIGN_H);
      g.addColorStop(0, bg?.color1 || slide?.color1 || '#0a0a0a');
      g.addColorStop(1, bg?.color2 || slide?.color2 || '#1a1a2e');
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, DESIGN_W, DESIGN_H);
      return;
    }
    // Vídeo/imagem: layer DOM persiste atrás — canvas transparente
    if (bg?.type === 'video' || bg?.type === 'image') {
      ctx.clearRect(0, 0, DESIGN_W, DESIGN_H);
      return;
    }
    ctx.fillStyle = '#000';
    ctx.fillRect(0, 0, DESIGN_W, DESIGN_H);
  }

  async _paintText(ctx, slide) {
    const lines = Array.isArray(slide?.lines) ? slide.lines : [];
    const title = slide?.title || '';
    const fontFamily = slide?.fontFamily
      || '"Segoe UI", system-ui, sans-serif';
    const baseSize = Number(slide?.fontSize) || (slide?.type === 'lyrics' ? 72 : 56);
    const maxW = DESIGN_W * 0.86;
    const maxH = DESIGN_H * 0.72;
    const textLines = lines.length ? lines.map(String) : (title ? [String(title)] : []);
    if (!textLines.length) return;

    let fontSize = baseSize;
    try {
      const fit = await fitLinesInBox({
        lines: textLines,
        fontFamily,
        fontSize: baseSize,
        maxW,
        maxH,
      });
      if (fit?.fontSize) fontSize = fit.fontSize;
    } catch { /* keep base */ }

    ctx.save();
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillStyle = slide?.color || '#ffffff';
    ctx.shadowColor = 'rgba(0,0,0,0.55)';
    ctx.shadowBlur = 18;
    ctx.shadowOffsetY = 4;
    // Subpixel-friendly when browser supports
    try { ctx.textRendering = 'optimizeLegibility'; } catch { /* ignore */ }
    ctx.font = `600 ${fontSize}px ${fontFamily}`;
    const lh = fontSize * 1.28;
    const totalH = textLines.length * lh;
    let y = (DESIGN_H - totalH) / 2 + lh / 2;
    for (const line of textLines) {
      ctx.fillText(line, DESIGN_W / 2, y, maxW);
      y += lh;
    }
    ctx.restore();
  }
}
