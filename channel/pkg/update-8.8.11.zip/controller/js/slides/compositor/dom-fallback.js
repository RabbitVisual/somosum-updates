/**
 * Encapsula o path DOM atual (fallback).
 */
export function paintDomFallback(stageEl, html, playVideos) {
  if (!stageEl) return;
  stageEl.style.visibility = '';
  stageEl.innerHTML = html;
  playVideos?.();
}
