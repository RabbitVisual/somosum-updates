/**
 * SlideCompositor — Canvas2D só para tipos suportados; resto → DOM.
 * Vídeo permanece no layer DOM (#lyrics-bg-persist) atrás do canvas.
 */
import { Canvas2dPainter } from './canvas2d-painter.js';
import { WebGlPostFx, canUseWebGlPostFx } from './webgl-postfx.js';
import { paintDomFallback } from './dom-fallback.js';
import { renderSlide } from '../templates.js';
import { slideSupportsCanvas } from '../../core/performance/render-prefs.js';

async function gpuAllowsPostFx(lowSpec) {
  if (lowSpec) return false;
  if (!canUseWebGlPostFx()) return false;
  try {
    const { ResourceGovernor } = await import('../../runtime/resource-governor.js');
    const snap = ResourceGovernor.getSnapshot?.();
    const tier = snap?.gpu?.tier || 'unknown';
    if (tier === 'software') return false;
    const profile = ResourceGovernor.getProfile?.();
    const name = typeof profile === 'string' ? profile : profile?.name;
    if (name === 'eco' || name === 'live-eco') return false;
    return true;
  } catch {
    return canUseWebGlPostFx();
  }
}

export class SlideCompositor {
  constructor({ paintCanvas, postFxCanvas, stageEl, prefs = {}, lowSpec = false } = {}) {
    this.paintCanvas = paintCanvas;
    this.postFxCanvas = postFxCanvas;
    this.stageEl = stageEl;
    this.prefs = prefs;
    this.lowSpec = lowSpec;
    this.painter = new Canvas2dPainter(paintCanvas);
    this.postFx = null;
    this._fps = 0;
    this._frames = 0;
    this._lastFpsAt = performance.now();
    this._styleCanvases();
    void this._initPostFx();
  }

  async _initPostFx() {
    const want = this.prefs?.render?.postFx !== false;
    if (!want) return;
    const ok = await gpuAllowsPostFx(this.lowSpec);
    if (!ok || !this.postFxCanvas) return;
    this.postFx = new WebGlPostFx(this.postFxCanvas);
    if (this.postFx.available) {
      this.postFxCanvas.hidden = false;
      this.postFxCanvas.style.display = 'block';
    } else {
      this.postFx = null;
    }
  }

  _styleCanvases() {
    for (const c of [this.paintCanvas, this.postFxCanvas]) {
      if (!c) continue;
      c.classList.add('screen-paint-canvas');
      c.style.position = 'absolute';
      c.style.inset = '0';
      c.style.width = '100%';
      c.style.height = '100%';
      c.style.pointerEvents = 'none';
      c.style.zIndex = c === this.postFxCanvas ? '3' : '2';
    }
  }

  cacheBitmap(key, bitmap) {
    this.painter.cacheBitmap(key, bitmap);
  }

  getFps() {
    return this._fps;
  }

  _useDom(slide, ctxOpts) {
    if (this.paintCanvas) {
      this.paintCanvas.hidden = true;
      this.paintCanvas.style.display = 'none';
      this.paintCanvas.style.opacity = '0';
    }
    if (this.postFxCanvas) {
      this.postFxCanvas.hidden = true;
      this.postFxCanvas.style.display = 'none';
    }
    paintDomFallback(this.stageEl, renderSlide(slide, ctxOpts), null);
  }

  async paint(slide, ctxOpts = {}) {
    const t0 = performance.now();
    try {
      // Bíblia / welcome / custom / etc. → DOM (Canvas ainda não cobre tipografia completa)
      if (!slideSupportsCanvas(slide)) {
        this._useDom(slide, ctxOpts);
        return false;
      }

      if (this.paintCanvas) {
        this.paintCanvas.hidden = false;
        this.paintCanvas.style.display = 'block';
        this.paintCanvas.style.opacity = this.postFx?.available ? '0' : '1';
      }
      const ok = await this.painter.paint(slide, ctxOpts);
      if (!ok) {
        this._useDom(slide, ctxOpts);
        return false;
      }
      // Canvas OK → esconde stage DOM
      if (this.stageEl) {
        this.stageEl.style.visibility = 'hidden';
        this.stageEl.innerHTML = '';
      }
      if (this.postFx?.available && this.paintCanvas) {
        this.postFx.apply(this.paintCanvas, {
          brightness: this.prefs?.render?.brightness ?? 1.05,
          shadow: this.prefs?.render?.shadow ?? 0.2,
        });
        this.paintCanvas.style.opacity = '0';
      } else if (this.paintCanvas) {
        this.paintCanvas.style.opacity = '1';
      }
      this._tickFps(t0);
      return true;
    } catch {
      this._useDom(slide, ctxOpts);
      return false;
    }
  }

  _tickFps(t0) {
    this._frames += 1;
    const now = performance.now();
    if (now - this._lastFpsAt >= 1000) {
      this._fps = this._frames;
      this._frames = 0;
      this._lastFpsAt = now;
      try {
        window.__SOMOSUM_RENDER_FPS = this._fps;
        window.__SOMOSUM_RENDER_MS = Math.round(now - t0);
      } catch { /* ignore */ }
    }
  }

  dispose() {
    this.postFx?.dispose?.();
  }
}
