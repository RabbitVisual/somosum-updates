export { SlideEngine } from './class-core.js';
import { SlideEngine } from './class-core.js';
import { slideEngineRuntime } from './class-runtime.js';
Object.assign(SlideEngine.prototype, slideEngineRuntime);
export { renderPreview, previewLyricsShellKey, ensurePreviewLyricsBackground, patchPreviewLyricsStage } from './preview.js';
