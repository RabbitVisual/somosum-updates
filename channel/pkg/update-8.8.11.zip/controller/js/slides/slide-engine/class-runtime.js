﻿import {
  renderSlide,
  lyricsBackgroundKey,
  renderLyricsBackgroundPersist,
  renderLyricsLinesBlock,
  normalizeMediaSrcKey,
  normalizeSlideBackground,
  applyLyricsStyleVars,
  applyMessageStyleVars,
  applySlideStyleVars,
} from '../templates.js';
import { applyLyricsFx, applyLyricsFxPatch } from '../../screen/lyrics-fx.js';
import { animateSlideChange } from '../animations.js';
import { ImageCache } from '../../render/asset-cache.js';
import { TaskScheduler } from '../../core/task-scheduler.js';
import { TaskIds } from '../../core/task-registry.js';
import { DisplayProjectionEngine } from '../../runtime/facades/display-runtime.js';
import { applyVideoLegibilityLayer } from '../../core/video-fit-engine.js';
import { WORKER_PREP_TYPES } from './class-core.js';

export const slideEngineRuntime = {
  _playStageVideos() {
    this.stageEl?.querySelectorAll('video').forEach((v) => this._playBgVideo(v));
  },

  clearLyricsBackground() {
    if (this.lyricsBgPersistEl) {
      const video = this.lyricsBgPersistEl.querySelector('video.lyrics-bg-video, video.slide-bg-video');
      if (video) {
        try {
          video.pause();
          video.removeAttribute('data-lyrics-persist');
        } catch { /* ignore */ }
      }
      this.lyricsBgPersistEl.innerHTML = '';
      this.lyricsBgPersistEl.hidden = true;
      delete this.lyricsBgPersistEl.dataset.bgKind;
    }
    this._lyricsBgKey = null;
    this._lyricsBgSlideType = null;
    try {
      document.documentElement.dataset.hasBgVideo = '0';
      const vp = this.root?.querySelector?.('.screen-viewport') || document.querySelector('.screen-viewport');
      if (vp) vp.dataset.hasBgVideo = '0';
    } catch { /* ignore */ }
  },

  /**
   * Fundo persistente (letras e demais slides com mídia): o <video> NÃO reinicia
   * a cada troca de item/estrofe. Só remonta se a mídia/gradiente for outro.
   */
  ensureLyricsBackground(slide) {
    const persist = this.lyricsBgPersistEl;
    if (!persist) return null;
    const bgKey = lyricsBackgroundKey(slide);
    const bg = slide?.background || {};
    const nextVideoSrc = bg.type === 'video' && bg.src ? bg.src : null;
    // Reuso por mídia (src/key) — NÃO exigir mesmo slide.type (lyrics↔title/bíblia remountava o decoder)

    const markBgKind = () => {
      const kind = nextVideoSrc ? 'video' : (bg.type === 'image' ? 'image' : 'gradient');
      persist.dataset.bgKind = kind;
      const hasVideo = kind === 'video' ? '1' : '0';
      try {
        document.documentElement.dataset.hasBgVideo = hasVideo;
        const vp = this.root?.querySelector?.('.screen-viewport') || document.querySelector('.screen-viewport');
        if (vp) {
          vp.dataset.hasBgVideo = hasVideo;
          applyVideoLegibilityLayer(vp, this.prefs || {});
        }
      } catch { /* ignore */ }
    };

    const existingVideo = persist.querySelector('video.lyrics-bg-video, video.slide-bg-video');
    if (nextVideoSrc && existingVideo) {
      const cur = existingVideo.getAttribute('src') || existingVideo.currentSrc || '';
      if (normalizeMediaSrcKey(cur) === normalizeMediaSrcKey(nextVideoSrc)) {
        persist.hidden = false;
        this._lyricsBgKey = bgKey;
        this._lyricsBgSlideType = slide?.type || null;
        markBgKind();
        this._playBgVideo(existingVideo);
        if (this.isLyricsSlide(slide)) {
          applyLyricsFxPatch(this.stageEl, slide, this.lyricsFxPrefs(slide), persist);
        }
        return bgKey;
      }
    }

    const hasStatic = persist.querySelector('.lyrics-bg-image, .lyrics-bg-gradient, .slide-bg-image, .slide-bg-gradient');
    if (!nextVideoSrc && this._lyricsBgKey === bgKey && hasStatic) {
      persist.hidden = false;
      this._lyricsBgSlideType = slide?.type || null;
      markBgKind();
      if (this.isLyricsSlide(slide)) {
        applyLyricsFxPatch(this.stageEl, slide, this.lyricsFxPrefs(slide), persist);
      }
      return bgKey;
    }

    // Fundo mudou de verdade — monta de novo
    persist.innerHTML = renderLyricsBackgroundPersist(slide, this.isLyricsSlide(slide) ? this.prefs : null);
    persist.hidden = false;
    this._lyricsBgKey = bgKey;
    this._lyricsBgSlideType = slide?.type || null;
    markBgKind();
    const video = persist.querySelector('video.lyrics-bg-video, video.slide-bg-video');
    if (video) {
      video.preload = 'auto';
      // Não registrar no VideoCache: trim/dispose matava o fundo ao vivo
      this._playBgVideo(video);
    }
    return bgKey;
  },

  patchLyricsSlide(slide) {
    if (slide.type === 'lyrics') {
      const slideEl = this.stageEl.querySelector('.slide-lyrics');
      if (!slideEl) return false;
      const body = slideEl.querySelector('.lyrics-body');
      if (!body) return false;
      applyLyricsStyleVars(slideEl, slide.style || {});
      body.innerHTML = renderLyricsLinesBlock(slide, this.prefs);
      return true;
    }
    if (slide.type === 'lyrics-title') {
      const slideEl = this.stageEl.querySelector('.slide-lyrics-title');
      if (!slideEl) return false;
      applyLyricsStyleVars(slideEl, slide.style || {});
      return true;
    }
    return false;
  },

  showLyricsSlide(slide, { patch = false } = {}) {
    const bgKey = this.ensureLyricsBackground(slide);
    const prefs = this.lyricsFxPrefs(slide);
    // Canvas só se o slide for tipografia simples; senão DOM (nunca tela preta)
    if (this._renderEngine === 'canvas' && this._compositor) {
      void this._compositor.paint(slide, this.ctx()).then((ok) => {
        this.currentSlide = slide;
        if (!ok) {
          applyLyricsFx(this.stageEl, slide, prefs, this.lyricsBgPersistEl);
        }
        this.ensureLyricsBackground(slide);
      }).catch(() => {
        const html = renderSlide(slide, this.ctx(), { persistBackground: true });
        this.stageEl.style.visibility = '';
        this.stageEl.innerHTML = html;
        this.currentSlide = slide;
        applyLyricsFx(this.stageEl, slide, prefs, this.lyricsBgPersistEl);
        this.ensureLyricsBackground(slide);
      });
      return bgKey;
    }
    if (patch && this.patchLyricsSlide(slide)) {
      this.currentSlide = slide;
      applyLyricsFxPatch(this.stageEl, slide, prefs, this.lyricsBgPersistEl);
      return bgKey;
    }
    const html = renderSlide(slide, this.ctx(), { persistBackground: true });
    this.stageEl.style.visibility = '';
    this.stageEl.innerHTML = html;
    this._lastSlideHtml = html;
    this.currentSlide = slide;
    applyLyricsFx(this.stageEl, slide, prefs, this.lyricsBgPersistEl);
    const lyricsEl = this.stageEl.querySelector('.slide-lyrics, .slide-lyrics-title');
    if (lyricsEl) applyLyricsStyleVars(lyricsEl, slide.style || {});
    this.ensureLyricsBackground(slide);
    return bgKey;
  },

  /** Seção/bíblia/mensagem/etc. com o mesmo vídeo de fundo — sem destruir o decoder. */
  showPersistedBackgroundSlide(slide, commitGen = this._renderGeneration) {
    if (commitGen !== this._renderGeneration) return this._lyricsBgKey;
    normalizeSlideBackground(slide);
    this.ensureLyricsBackground(slide);
    // Sempre DOM para slides complexos; compositor decide internamente
    if (this._renderEngine === 'canvas' && this._compositor) {
      void this._compositor.paint(slide, this.ctx()).then((ok) => {
        if (commitGen !== this._renderGeneration) return;
        this.currentSlide = slide;
        if (!ok) {
          this._playStageVideos();
        }
        this.ensureLyricsBackground(slide);
      }).catch(() => {
        if (commitGen !== this._renderGeneration) return;
        const html = renderSlide(slide, this.ctx(), { persistBackground: true });
        this.stageEl.style.visibility = '';
        this.stageEl.innerHTML = html;
        this._lastSlideHtml = html;
        this.currentSlide = slide;
        this._playStageVideos();
        this.ensureLyricsBackground(slide);
      });
      return this._lyricsBgKey;
    }
    const html = renderSlide(slide, this.ctx(), { persistBackground: true });
    if (commitGen !== this._renderGeneration) return this._lyricsBgKey;
    this.stageEl.style.visibility = '';
    this.stageEl.innerHTML = html;
    this._lastSlideHtml = html;
    this.currentSlide = slide;
    if (slide?.type === 'message') {
      const slideEl = this.stageEl.querySelector('.slide-message-pro, .slide[data-type="message"]');
      if (slideEl) applyMessageStyleVars(slideEl, slide.style || {});
    } else if (slide?.style && slide.type !== 'lyrics' && slide.type !== 'lyrics-title') {
      const slideEl = this.stageEl.querySelector(
        `.slide[data-type="${slide.type}"], .slide-${slide.type}, .slide`,
      );
      if (slideEl) applySlideStyleVars(slideEl, slide.style || {});
    }
    this._playStageVideos();
    this.ensureLyricsBackground(slide);
    import('../slide-overflow-fit.js').then((m) => {
      if (commitGen !== this._renderGeneration) return;
      m.fitSlideOverflow(this.stageEl);
    }).catch(() => {});
    return this._lyricsBgKey;
  },

  showSlide(slide, animate = true) {
    this._renderGeneration = (this._renderGeneration || 0) + 1;
    if (slide) {
      import('../../plugins/plugin-engine.js').then(({ PluginEngine }) => {
        PluginEngine.runHook('slide:change', { slide, animate }).catch(() => {});
      }).catch(() => {});
    }
    if (slide) normalizeSlideBackground(slide);
    if (slide?.bgImage) ImageCache.load(slide.bgImage).catch(() => {});
    if (!WORKER_PREP_TYPES.has(slide?.type)) {
      this._preparedHtml = null;
      this._preparedForSlideId = null;
    }
    this._preloadSlideHtml(slide);
    return this._pipeline.run({ slide, animate }, { priority: 'critical' });
  },

  _preloadSlideHtml(slide) {
    if (!slide || typeof requestIdleCallback !== 'function') return;
    if (!WORKER_PREP_TYPES.has(slide.type)) return;
    const key = slide?.id || slide?.type || '';
    requestIdleCallback(() => {
      import('../../core/worker-pool.js').then(({ runWorkerTask, isWorkerSupported }) => {
        if (!isWorkerSupported()) return;
        const url = new URL('../../workers/slide-prep-worker.js', import.meta.url);
        return runWorkerTask(url, { slide }, {
          fallback: () => ({ html: renderSlide(slide, this.ctx(), { persistBackground: true }) }),
        });
      }).then((result) => {
        if (result?.html && (slide?.id || slide?.type) === key) {
          this._preparedHtml = result.html;
          this._preparedForSlideId = key;
          if (result.bitmap && this._compositor?.cacheBitmap) {
            this._compositor.cacheBitmap(key, result.bitmap);
          }
        }
      }).catch(() => {});
    }, { timeout: 1200 });
  },

  showOverlayLayer(overlayId, payload = {}) {
    this.overlayLayer = { id: overlayId, payload };
    if (this.overlayLayerEl) {
      this.overlayLayerEl.innerHTML = renderOverlayHtml(overlayId, payload, this.ctx());
    }
  },

  clearOverlayLayer(clearHtml = true) {
    this.overlayLayer = null;
    if (clearHtml && this.overlayLayerEl) this.overlayLayerEl.innerHTML = '';
  },

  showOverlay(type) {
    this.overlay = type;
    this._lastSlideHtml = null;
    this.clearOverlayLayer();
    // Camada Overlay â‰  Background: blank/logo NÃO destrói o vídeo de fundo
    if (this.stageEl) {
      this.stageEl.style.visibility = type === 'blank' || type === 'logo' ? 'hidden' : '';
    }
    const html = type === 'logo' ? renderSlide({ type: 'logo' }, this.ctx()) : renderSlide({ type: 'blank' });
    animateSlideChange(this.overlayLayerEl || this.stageEl, () => {
      if (this.overlayLayerEl) {
        this.overlayLayerEl.innerHTML = html;
        this.overlayLayer = { id: type, payload: {} };
      } else {
        this.stageEl.innerHTML = html;
      }
    });
    // Mantém decoder vivo sob o blank
    const video = this.lyricsBgPersistEl?.querySelector('video');
    if (video) this._playBgVideo(video);
  },

  clearOverlay(slide) {
    this.overlay = null;
    this._lastSlideHtml = null;
    this.clearOverlayLayer(true);
    if (this.stageEl) this.stageEl.style.visibility = '';
    this.showSlide(slide || this.currentSlide, false);
  },

  startClock() {
    if (this._clockDispose) return;
    const tick = () => {
      const el = this.root.querySelector('#screen-clock');
      if (!el) return;
      const now = new Date();
      const timeEl = el.querySelector('.screen-clock-time');
      const dateEl = el.querySelector('.screen-clock-date');
      if (timeEl) {
        timeEl.textContent = now.toLocaleTimeString('pt-BR', {
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
        });
      }
      if (dateEl) {
        dateEl.textContent = now.toLocaleDateString('pt-BR', {
          weekday: 'short',
          day: 'numeric',
          month: 'short',
        });
      }
    };
    tick();
    if (this._clockDispose) this._clockDispose();
    this._clockDispose = TaskScheduler.register({
      id: TaskIds.SLIDE_CLOCK,
      kind: 'interval',
      intervalMs: 1000,
      priority: 6,
      fn: tick,
    });
  },

  hideCursorAfterIdle() {
    let timer;
    const reset = () => {
      document.body.classList.remove('cursor-hidden');
      clearTimeout(timer);
      timer = setTimeout(() => document.body.classList.add('cursor-hidden'), 3000);
    };
    window.addEventListener('mousemove', reset);
    reset();
    this._cursorDispose = () => {
      window.removeEventListener('mousemove', reset);
      clearTimeout(timer);
    };
  },

  /** Watchdog: revive vídeo de fundo se pausar/errar (todos os tipos). */
  startBgWatchdog() {
    if (this._bgWatchDispose) return;
    const tick = () => {
      const video = this.lyricsBgPersistEl?.querySelector('video.lyrics-bg-video, video.slide-bg-video');
      if (!video || this.lyricsBgPersistEl?.hidden) return;
      if (video.error || (video.paused && video.readyState >= 1)) {
        this._playBgVideo(video);
      }
    };
    this._bgWatchDispose = TaskScheduler.register({
      id: TaskIds.SLIDE_BG_WATCHDOG,
      kind: 'interval',
      intervalMs: 2800,
      priority: 8,
      fn: tick,
    });
  },

  dispose() {
    this._cursorDispose?.();
    this._clockDispose?.();
    this._disposeProjectionFit?.();
    this._compositor?.dispose?.();
    DisplayProjectionEngine.getInstance()?.detach?.();
  }
};
