import { LayerEngine } from '../layers/layer-engine.js';
import { TransitionEngine } from '../transitions/transition-engine.js';
import { EffectsEngine } from '../effects/effects-engine.js';

/** Wrapper profissional sobre SlideEngine existente */
export function enhanceSlideEngine(engine) {
  const layers = new LayerEngine(engine.stageEl);
  const transitions = new TransitionEngine(engine.stageEl);
  const effects = new EffectsEngine(engine.canvasEl || engine.stageEl);

  const origShow = engine.showSlide.bind(engine);
  engine.showSlide = async (slide, animate = true) => {
    layers.prepare(slide);
    effects.apply(slide);
    await transitions.before(slide, animate);
    const result = await origShow(slide, animate);
    await transitions.after(slide);
    return result;
  };
  engine._layerEngine = layers;
  engine._effectsEngine = effects;
  return engine;
}
