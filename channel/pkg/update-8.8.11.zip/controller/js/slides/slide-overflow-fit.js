/**
 * Fit tipográfico — main thread aplica; medição pesada no worker quando disponível.
 */
import { getDesignDimensions } from '../runtime/facades/display-runtime.js';
import { runWorkerTask, isWorkerSupported } from '../core/worker-pool.js';

const FIT_SELECTORS = [
  '.slide-bible .bible-body',
  '.slide-bible-reader .bible-reader-content',
  '.slide-announcements .announce-list',
  '.slide-participation .participation-inner',
];

function fitsBox(el, maxH) {
  return el.scrollHeight <= maxH + 2 && el.scrollWidth <= (el.clientWidth || 1920) + 2;
}

function shrinkFontSync(el, maxH, minScale = 0.55) {
  const style = getComputedStyle(el);
  const base = parseFloat(style.fontSize) || 16;
  if (!base) return;
  let scale = 1;
  let guard = 0;
  while (!fitsBox(el, maxH) && scale > minScale && guard < 24) {
    scale -= 0.04;
    el.style.fontSize = `${base * scale}px`;
    el.querySelectorAll('[style*="font-size"]').forEach((child) => {
      const fs = parseFloat(getComputedStyle(child).fontSize);
      if (fs) child.style.fontSize = `${fs * (1 - 0.04)}px`;
    });
    guard += 1;
  }
}

async function shrinkFontViaWorker(el, maxH, maxW) {
  const style = getComputedStyle(el);
  const base = parseFloat(style.fontSize) || 16;
  const fontFamily = style.fontFamily || 'Segoe UI, sans-serif';
  const text = (el.innerText || el.textContent || '').trim();
  const lines = text.split(/\n/).map((l) => l.trim()).filter(Boolean);
  if (!lines.length || !isWorkerSupported()) {
    shrinkFontSync(el, maxH);
    return;
  }
  try {
    const url = new URL('../workers/slide-fit-worker.js', import.meta.url);
    const result = await runWorkerTask(url, {
      lines,
      fontFamily,
      fontSize: base,
      maxW: maxW || el.clientWidth || 1600,
      maxH,
    }, {
      fallback: () => ({ fontSize: base, scale: 1 }),
    });
    if (result?.fontSize && result.fontSize < base) {
      el.style.fontSize = `${result.fontSize}px`;
    }
  } catch {
    shrinkFontSync(el, maxH);
  }
}

export function fitSlideOverflow(stageEl, designH) {
  if (!stageEl) return;
  const viewport = stageEl.closest('.screen-viewport') || stageEl;
  const dims = getDesignDimensions(viewport);
  const h = designH || dims.h || viewport.clientHeight || 1080;
  const w = dims.w || viewport.clientWidth || 1920;
  const safeH = Math.round(h * 0.88);
  requestAnimationFrame(() => {
    void (async () => {
      for (const sel of FIT_SELECTORS) {
        for (const el of stageEl.querySelectorAll(sel)) {
          el.style.fontSize = '';
          await shrinkFontViaWorker(el, safeH, Math.round(w * 0.88));
        }
      }
      stageEl.querySelectorAll('.bible-reader-verses').forEach((el) => {
        const maxH = Math.round(h * 0.62);
        let guard = 0;
        while (el.scrollHeight > maxH && guard < 20) {
          const verses = el.querySelectorAll('.bible-reader-verse');
          const fs = parseFloat(getComputedStyle(verses[0] || el).fontSize) || 44;
          const next = Math.max(22, fs - 2);
          verses.forEach((v) => { v.style.fontSize = `${next}px`; });
          guard += 1;
        }
      });
    })();
  });
}

/** API pública para compositor Canvas — só measureText no worker. */
export async function fitLinesInBox(opts) {
  if (!isWorkerSupported()) {
    return { fontSize: opts.fontSize || 64, scale: 1 };
  }
  const url = new URL('../workers/slide-fit-worker.js', import.meta.url);
  return runWorkerTask(url, opts, {
    fallback: () => ({ fontSize: opts.fontSize || 64, scale: 1 }),
  });
}
