/** Modos de exibição do slide Mensagem — inspetor, wizard, projeção e programa. */
export const MESSAGE_DISPLAY_MODES = [
  {
    id: 'tema_ref',
    label: 'Tema + referência (sem pregador)',
    hint: 'Somente tema e referência bíblica na tela — ideal para introito ou mensagem sem nome do pregador.',
    showTheme: true,
    showReference: true,
    showPreacher: false,
    wholeChapter: false,
    showMottoSection: true,
  },
  {
    id: 'ref_pregador',
    label: 'Referência + pregador',
    hint: 'Referência bíblica e nome do pregador — sem tema na tela. Foto opcional.',
    showTheme: false,
    showReference: true,
    showPreacher: true,
    wholeChapter: false,
    showMottoSection: true,
  },
  {
    id: 'tema_ref_pregador',
    label: 'Tema + referência + pregador',
    hint: 'Tema, referência e pregador. Desmarque a foto se quiser só nome e local.',
    showTheme: true,
    showReference: true,
    showPreacher: true,
    wholeChapter: false,
    showMottoSection: true,
  },
  {
    id: 'tema_capitulo_pregador',
    label: 'Tema + capítulo inteiro + pregador',
    hint: 'Tema, referência do capítulo completo e pregador — versículos individuais ficam ocultos.',
    showTheme: true,
    showReference: true,
    showPreacher: true,
    wholeChapter: true,
    showMottoSection: false,
  },
  {
    id: 'tema_pregador',
    label: 'Tema + pregador (sem referência)',
    hint: 'Somente tema e nome do pregador — ideal quando não há referência bíblica na tela.',
    showTheme: true,
    showReference: false,
    showPreacher: true,
    wholeChapter: false,
    showMottoSection: false,
  },
];

export function getMessageMode(modeId) {
  return MESSAGE_DISPLAY_MODES.find((m) => m.id === modeId)
    || MESSAGE_DISPLAY_MODES.find((m) => m.id === 'ref_pregador')
    || MESSAGE_DISPLAY_MODES[0];
}

export function messageModeOptionsHtml(selected = 'ref_pregador') {
  return MESSAGE_DISPLAY_MODES.map(
    (m) => `<option value="${m.id}" ${selected === m.id ? 'selected' : ''}>${m.label}</option>`
  ).join('');
}

export function resolveShowPreacherPhoto(data = {}) {
  if (data.showPreacherPhoto === false) return false;
  if (data.showPreacherPhoto === true) return true;
  return !!data.preacherPhotoId;
}

function setDisplay(node, visible) {
  if (node) node.style.display = visible ? '' : 'none';
}

/** Inspetor do Controle — mostra/oculta campos conforme o modo. */
export function applyMessageInspectorModeUI(el, modeId) {
  if (!el) return;
  const mode = getMessageMode(modeId);

  setDisplay(el.querySelector('#insp-msg-theme-wrap'), mode.showTheme);
  setDisplay(el.querySelector('#insp-msg-bible-wrap'), mode.showReference);
  setDisplay(el.querySelector('#insp-msg-motto-wrap'), mode.showMottoSection);
  setDisplay(el.querySelector('#insp-msg-verses-wrap'), mode.showReference && !mode.wholeChapter);
  setDisplay(el.querySelector('#insp-msg-verse-end-wrap'), mode.showReference && !mode.wholeChapter);

  setDisplay(el.querySelector('#insp-msg-preacher-wrap'), mode.showPreacher);
  setDisplay(el.querySelector('#insp-msg-photo-wrap'), mode.showPreacher);
  setDisplay(el.querySelector('#insp-msg-preacher-size-group'), mode.showPreacher);
  setDisplay(el.querySelector('#insp-msg-from-size-group'), mode.showPreacher);

  setDisplay(el.querySelector('#insp-msg-theme-size-group'), mode.showTheme);
  setDisplay(el.querySelector('#insp-msg-ref-size-group'), mode.showReference);
  setDisplay(el.querySelector('#insp-msg-motto-size-group'), mode.showMottoSection);
  setDisplay(el.querySelector('#insp-msg-text-size-group'), mode.showReference);

  const hint = el.querySelector('#insp-msg-mode-hint');
  if (hint) hint.textContent = mode.hint;
}

/** Wizard de adicionar slide Mensagem. */
export function applyMessageWizardModeUI(modal, modeId) {
  if (!modal) return;
  const mode = getMessageMode(modeId);

  setDisplay(modal.querySelector('#wiz-theme-wrap'), mode.showTheme);
  setDisplay(modal.querySelector('#wiz-bible-wrap'), mode.showReference);
  setDisplay(modal.querySelector('#wiz-msg-motto-wrap'), mode.showMottoSection);
  setDisplay(modal.querySelector('#wiz-preacher-wrap'), mode.showPreacher);

  const hint = modal.querySelector('#wiz-msg-mode-hint');
  if (hint) hint.textContent = mode.hint;
}

export function syncMessagePhotoInspectorUI(el) {
  if (!el) return;
  const photoId = el.querySelector('#insp-msg-photo')?.value;
  const showChk = el.querySelector('#insp-msg-show-photo');
  // Sem foto escolhida: não força desmarcar (operador pode marcar antes de escolher).
  // Sem círculo vazio na projeção — o render só desenha img se houver preacherPhoto.
  const wantShow = !!showChk?.checked;
  const showPhoto = wantShow && !!photoId;
  setDisplay(el.querySelector('#insp-msg-photo-size-wrap'), showPhoto);
  setDisplay(el.querySelector('#insp-msg-card-width-block'), showPhoto);
}
