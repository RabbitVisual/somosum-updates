const EFFECT_CLASSES = {
  rain: 'fx-rain',
  snow: 'fx-snow',
  fog: 'fx-fog',
  aurora: 'fx-aurora',
  glow: 'fx-glow',
  blur: 'fx-blur',
};

export class EffectsEngine {
  constructor(rootEl) {
    this.root = rootEl;
    this.canvas = null;
  }

  apply(slide) {
    const effects = slide?.effects || [];
    Object.values(EFFECT_CLASSES).forEach((c) => this.root?.classList.remove(c));
    effects.forEach((fx) => {
      const cls = EFFECT_CLASSES[fx];
      if (cls) this.root?.classList.add(cls);
    });
    if (effects.includes('particles')) this.ensureCanvas();
  }

  ensureCanvas() {
    if (this.canvas) return;
    const host = this.root;
    const w = host?.clientWidth || 1920;
    const h = host?.clientHeight || 1080;
    this.canvas = document.createElement('canvas');
    this.canvas.className = 'slide-fx-canvas';
    this.canvas.width = w;
    this.canvas.height = h;
    this.canvas.style.cssText = 'position:absolute;inset:0;width:100%;height:100%;pointer-events:none;';
    host?.appendChild(this.canvas);
  }

  clear() {
    this.canvas?.remove();
    this.canvas = null;
  }
}
