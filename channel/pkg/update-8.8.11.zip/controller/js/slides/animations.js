export const TRANSITIONS = [
  'fade',
  'slide-up',
  'slide-left',
  'slide-right',
  'zoom',
  'crossfade',
  'blur-in',
  'scale-up',
  'dissolve',
];

export const TRANSITION_LABELS = {
  fade: 'Suave (fade)',
  'slide-up': 'Deslizar para cima',
  'slide-left': 'Deslizar da direita',
  'slide-right': 'Deslizar da esquerda',
  zoom: 'Zoom',
  crossfade: 'Crossfade',
  'blur-in': 'Desfoque entrada',
  'scale-up': 'Ampliar',
  dissolve: 'Dissolver',
};

export function transitionLabel(id) {
  return TRANSITION_LABELS[id] || id || 'fade';
}

export function applyTransition(container, transitionName) {
  container.dataset.transition = transitionName || 'fade';
}

export function animateSlideChange(container, callback) {
  const transition = container.dataset.transition || 'fade';
  const heavy = transition === 'blur-in' || transition === 'crossfade';
  const duration = heavy ? 180 : 100;
  container.classList.add('is-leaving');
  setTimeout(() => {
    callback();
    container.classList.remove('is-leaving');
    container.classList.add('is-entering');
    requestAnimationFrame(() => {
      container.classList.remove('is-entering');
    });
  }, duration);
}
