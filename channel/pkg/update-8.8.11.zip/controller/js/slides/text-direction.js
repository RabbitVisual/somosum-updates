/**
 * Detecção de script e metadados RTL/LTR para slides (7.2 Exposição).
 */

const HEBREW_RE = /[\u0590-\u05FF]/;
const GREEK_RE = /[\u0370-\u03FF\u1F00-\u1FFF]/;

export function detectScript(text) {
  const t = String(text || '');
  if (HEBREW_RE.test(t)) return 'hebrew';
  if (GREEK_RE.test(t)) return 'greek';
  return 'latin';
}

export function scriptToLang(script) {
  if (script === 'hebrew') return 'he';
  if (script === 'greek') return 'grc';
  return 'pt';
}

export function scriptToDir(script) {
  return script === 'hebrew' ? 'rtl' : 'ltr';
}

/** Escapa HTML e envolve com dir/lang quando necessário. */
export function wrapScriptHtml(text, { lang, dir, className = '' } = {}) {
  const raw = String(text ?? '');
  const script = detectScript(raw);
  const useLang = lang || scriptToLang(script);
  const useDir = dir || scriptToDir(script);
  const esc = (s) => String(s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
  const cls = className ? ` class="${className}"` : '';
  if (useDir === 'rtl' || useLang === 'he' || useLang === 'grc') {
    return `<span dir="${useDir}" lang="${useLang}"${cls}>${esc(raw)}</span>`;
  }
  return esc(raw);
}

export function verseDirectionMeta(slide) {
  const lang = slide?.originalLang || slide?.lang;
  if (lang === 'he' || lang === 'heb-tagged') {
    return { lang: 'he', dir: 'rtl', script: 'hebrew' };
  }
  if (lang === 'grc' || lang === 'grc-tr') {
    return { lang: 'grc', dir: 'ltr', script: 'greek' };
  }
  const sample = slide?.verses?.[0]?.text || slide?.text || '';
  const script = detectScript(sample);
  return { lang: scriptToLang(script), dir: scriptToDir(script), script };
}
