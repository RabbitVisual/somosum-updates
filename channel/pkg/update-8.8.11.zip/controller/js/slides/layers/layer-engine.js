export class LayerEngine {
  constructor(rootEl) {
    this.root = rootEl;
    this.layers = [];
  }
  prepare(slide) {
    this.layers = slide?.layers || [];
    this.root?.style?.setProperty('--slide-layer-count', String(this.layers.length || 1));
  }
  getScene() {
    return { layers: this.layers, zOrder: this.layers.map((_, i) => i) };
  }
}
