export class SceneGraph {
  constructor() {
    this.nodes = [];
  }
  add(node, parentId = null) {
    const entry = { id: node.id || `n-${this.nodes.length}`, node, parentId, children: [] };
    this.nodes.push(entry);
    if (parentId) {
      const parent = this.nodes.find((n) => n.id === parentId);
      parent?.children.push(entry.id);
    }
    return entry.id;
  }
  flatten() {
    return this.nodes.map((n) => n.node);
  }
}
