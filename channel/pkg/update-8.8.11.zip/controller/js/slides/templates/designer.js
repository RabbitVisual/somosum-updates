import { esc } from '../../core/render-engine/index.js';
import { cssClipPathForFrame, computeFrameFillLayout, frameStrokeSvgHtml } from '../../designer/frame-utils.js';
import { renderPhotoCardHtml } from '../../designer/photo-card.js';
import { templateDesignDims } from './shared.js';

function cssTextStyle(layer) {
  const parts = [];
  const fs = layer.fontStyle || 'normal';
  if (fs.includes('bold')) parts.push('font-weight:700');
  if (fs.includes('italic')) parts.push('font-style:italic');
  if (layer.letterSpacing) parts.push(`letter-spacing:${layer.letterSpacing}px`);
  if (layer.lineHeight) parts.push(`line-height:${layer.lineHeight}`);
  const sw = Number(layer.strokeWidth) || 0;
  if (sw > 0 && layer.stroke) {
    parts.push(`-webkit-text-stroke:${sw}px ${layer.stroke}`);
    parts.push(`paint-order:stroke fill`);
  }
  return parts.join(';');
}

function cssShadow(layer) {
  const blur = layer.shadowBlur || 0;
  if (!blur) return '';
  const color = layer.shadowColor || 'rgba(0,0,0,0.55)';
  const ox = layer.shadowOffsetX || 0;
  const oy = layer.shadowOffsetY || 0;
  return `text-shadow:${ox}px ${oy}px ${blur}px ${color};filter:drop-shadow(${ox}px ${oy}px ${blur}px ${color});`;
}

export function renderDesignerLayer(layer, slide = null) {
  if (layer.kind === 'group' && Array.isArray(layer.children)) {
    const gx = layer.x || 0;
    const gy = layer.y || 0;
    const gRot = layer.rotation || 0;
    const gsx = layer.scaleX != null ? Number(layer.scaleX) : 1;
    const gsy = layer.scaleY != null ? Number(layer.scaleY) : 1;
    const gOp = layer.opacity != null ? layer.opacity : 1;
    const kids = layer.children.map((child) => {
      const next = {
        ...child,
        x: (child.x || 0) + gx,
        y: (child.y || 0) + gy,
        opacity: (child.opacity != null ? child.opacity : 1) * gOp,
      };
      if (gRot || gsx !== 1 || gsy !== 1) {
        next.rotation = (child.rotation || 0) + gRot;
        next.scaleX = (child.scaleX != null ? Number(child.scaleX) : 1) * gsx;
        next.scaleY = (child.scaleY != null ? Number(child.scaleY) : 1) * gsy;
      }
      return renderDesignerLayer(next, slide);
    }).join('');
    return kids;
  }
  const { w: DESIGN_W, h: DESIGN_H } = templateDesignDims(slide);
  const left = `${((layer.x || 0) / DESIGN_W) * 100}%`;
  const top = `${((layer.y || 0) / DESIGN_H) * 100}%`;
  const width = layer.width ? `${(layer.width / DESIGN_W) * 100}%` : 'auto';
  const height = layer.height ? `${(layer.height / DESIGN_H) * 100}%` : 'auto';
  const fontSize = `${layer.fontSize || 48}px`;
  const sx = layer.scaleX != null ? Number(layer.scaleX) : 1;
  const sy = layer.scaleY != null ? Number(layer.scaleY) : 1;
  const transforms = [];
  if (layer.rotation) transforms.push(`rotate(${layer.rotation}deg)`);
  if (sx !== 1 || sy !== 1) {
    transforms.push(`scale(${sx}, ${sy})`);
  }
  const rot = transforms.length
    ? `transform:${transforms.join(' ')};transform-origin:center center;`
    : '';
  const opacity = layer.opacity != null ? layer.opacity : 1;
  const hidden = layer.visible === false ? 'visibility:hidden;' : '';
  const align = layer.align || 'center';
  const justify = align === 'left' ? 'flex-start' : align === 'right' ? 'flex-end' : 'center';

  const base = `left:${left};top:${top};width:${width};height:${height};opacity:${opacity};${hidden}${rot}`;

  if (layer.kind === 'text') {
    const typo = cssTextStyle(layer);
    const shadow = cssShadow(layer);
    const textBox = `left:${left};top:${top};width:${width};height:auto;min-height:0;opacity:${opacity};${hidden}${rot};overflow:visible;white-space:pre-wrap;word-break:break-word;`;
    return `<div class="custom-layer custom-layer-text" style="${textBox};font-size:${fontSize};color:${layer.fill || '#fff'};font-family:${layer.fontFamily || 'Segoe UI'};text-align:${align};justify-content:${justify};${typo};${shadow}">${esc(layer.text || '')}</div>`;
  }
  if (layer.kind === 'image' && layer.src) {
    return `<img class="custom-layer custom-layer-image" src="${layer.src}" alt="" style="${base};object-fit:contain" />`;
  }
  if (layer.kind === 'shape') {
    if (layer.shape === 'circle') {
      const size = layer.radius ? layer.radius * 2 : layer.width || 160;
      const leftC = `${((layer.x || 0) / DESIGN_W) * 100}%`;
      const topC = `${((layer.y || 0) / DESIGN_H) * 100}%`;
      const sz = `${size}px`;
      return `<div class="custom-layer custom-layer-shape custom-layer-circle" style="left:${leftC};top:${topC};width:${sz};height:${sz};opacity:${opacity};${hidden}border-radius:50%;background:${layer.fill || 'rgba(212,198,141,0.35)'};border:${layer.strokeWidth || 0}px solid ${layer.stroke || 'transparent'};${rot}"></div>`;
    }
    if (layer.shape === 'line') {
      const x1 = layer.x || 0;
      const y1 = layer.y || 0;
      const pts = layer.points || [0, 0, 400, 0];
      const x2 = x1 + (pts[2] || 0);
      const y2 = y1 + (pts[3] || 0);
      const len = Math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2);
      const angle = Math.atan2(y2 - y1, x2 - x1) * (180 / Math.PI);
      return `<div class="custom-layer custom-layer-line" style="left:${(x1 / DESIGN_W) * 100}%;top:${(y1 / DESIGN_H) * 100}%;width:${(len / DESIGN_W) * 100}%;height:0;border-top:${layer.strokeWidth || 3}px solid ${layer.stroke || '#d4c68d'};transform:rotate(${angle}deg);transform-origin:left center;opacity:${opacity};${hidden}"></div>`;
    }
    const radius = layer.cornerRadius ? `${layer.cornerRadius}px` : '0';
    const border = layer.stroke && layer.strokeWidth ? `border:${layer.strokeWidth}px solid ${layer.stroke};` : '';
    return `<div class="custom-layer custom-layer-shape" style="${base};background:${layer.fill || 'rgba(212,198,141,0.35)'};border-radius:${radius};${border}"></div>`;
  }
  if (layer.kind === 'photo-card') {
    return renderPhotoCardHtml(layer);
  }
  if (layer.kind === 'frame') {
    const clip = cssClipPathForFrame(layer);
    const fw = layer.width || 400;
    const fh = layer.height || 400;
    const maskStyle = layer.maskSrc
      ? `-webkit-mask-image:url(${layer.maskSrc});mask-image:url(${layer.maskSrc});-webkit-mask-size:100% 100%;mask-size:100% 100%;`
      : '';
    let fillHtml = '';
    if (layer.fillSrc) {
      const nw = layer.fillNaturalW || 0;
      const nh = layer.fillNaturalH || 0;
      const isVideo = layer.fillKind === 'video' || /\.(mp4|webm|mov|m4v)(\?|$)/i.test(String(layer.fillSrc));
      const tag = isVideo ? 'video' : 'img';
      const mediaAttrs = isVideo
        ? `autoplay muted loop playsinline`
        : `alt=""`;
      if (nw > 0 && nh > 0) {
        const layout = computeFrameFillLayout(
          fw,
          fh,
          nw,
          nh,
          layer.fillFit || 'cover',
          layer.fillScale || 1,
          layer.fillOffsetX || 0,
          layer.fillOffsetY || 0,
        );
        const fillLeft = `${(layout.x / fw) * 100}%`;
        const fillTop = `${(layout.y / fh) * 100}%`;
        const fillW = `${(layout.width / fw) * 100}%`;
        const fillH = `${(layout.height / fh) * 100}%`;
        fillHtml = `<${tag} class="custom-layer-frame-fill" src="${layer.fillSrc}" ${mediaAttrs} style="left:${fillLeft};top:${fillTop};width:${fillW};height:${fillH};object-fit:fill"></${tag}>`;
      } else {
        const fit = layer.fillFit === 'contain' ? 'contain' : 'cover';
        const scale = layer.fillScale || 1;
        const ox = layer.fillOffsetX || 0;
        const oy = layer.fillOffsetY || 0;
        fillHtml = `<${tag} class="custom-layer-frame-fill" src="${layer.fillSrc}" ${mediaAttrs} style="left:0;top:0;width:100%;height:100%;object-fit:${fit};transform:translate(${ox}px,${oy}px) scale(${scale});transform-origin:center center"></${tag}>`;
      }
    }
    const strokeHtml = layer.maskSrc ? '' : frameStrokeSvgHtml(layer);
    return `<div class="custom-layer custom-layer-frame" style="${base};clip-path:${clip};${maskStyle}">
      ${fillHtml}
      ${strokeHtml}
      ${layer.maskSrc ? `<img class="custom-layer-frame-mask" src="${layer.maskSrc}" alt="" />` : ''}
    </div>`;
  }
  return '';
}
