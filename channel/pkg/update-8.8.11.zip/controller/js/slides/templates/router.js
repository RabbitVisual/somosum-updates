import { esc } from '../../core/render-engine/index.js';
import { applySlideRenderPlugins, appendPluginSlideChrome } from '../../plugins/slide-plugins.js';
import { getRenderOpts, setRenderOpts, url } from './shared.js';
import { PRODUCT_LOGO_REL } from '../../core/brand-assets.js';
import { getPluginTemplateRenderer } from './registry-background.js';
import { renderWelcome, renderSection, renderPrayer, renderParticipation } from './welcome-section.js';
import { renderVisitorWelcome } from './visitor-welcome.js';
import { renderLyricsTitle, renderLyrics } from './lyrics.js';
import { renderBible, renderBibleInterlinear, renderBibleResponsive, renderBibleReader } from './bible.js';
import {
  renderMediaAudio,
  renderOffering,
  renderCountdownPause,
  renderMessage,
  renderTheme,
  renderCustom,
  renderMedia,
  renderBlank,
  renderAnnouncements,
  renderCommunion,
  renderLogo,
} from './media-slides.js';

function fireSlideRenderHook(slide, context, options) {
  if (!slide) return;
  applySlideRenderPlugins(slide, context, options);
}

export function renderSlide(slide, context = {}, options = {}) {
  if (!slide) return renderBlank();
  const prevOpts = getRenderOpts();
  setRenderOpts(options || {});
  try {
    fireSlideRenderHook(slide, context, options);

    let html;
    switch (slide.type) {
      case 'welcome':
        html = renderWelcome(slide, context);
        break;
      case 'visitor-welcome':
        html = renderVisitorWelcome(slide, context);
        break;
      case 'section':
        html = renderSection(slide);
        break;
      case 'prayer':
        html = renderPrayer(slide);
        break;
      case 'participation':
        html = renderParticipation(slide);
        break;
      case 'lyrics-title':
        html = renderLyricsTitle(slide, options, context);
        break;
      case 'lyrics':
        html = renderLyrics(slide, options, context);
        break;
      case 'bible':
        html = renderBible(slide);
        break;
      case 'bible-interlinear':
        html = renderBibleInterlinear(slide, {
          liveView: options.liveView || context.interlinearView || slide.liveView || null,
          persistBackground: options.persistBackground,
        });
        break;
      case 'bible-responsive':
        html = renderBibleResponsive(slide);
        break;
      case 'bible-reader':
        html = renderBibleReader(slide);
        break;
      case 'message':
        html = renderMessage(slide);
        break;
      case 'theme':
        html = renderTheme(slide, context);
        break;
      case 'announcements':
        html = renderAnnouncements(slide);
        break;
      case 'communion':
        html = renderCommunion(slide);
        break;
      case 'custom':
        html = renderCustom(slide);
        break;
      case 'blank':
        html = renderBlank();
        break;
      case 'logo':
        html = renderLogo(context);
        break;
      case 'media':
        html = renderMedia(slide);
        break;
      case 'media-audio':
        html = renderMediaAudio(slide);
        break;
      case 'offering':
        html = renderOffering(slide);
        break;
      case 'countdown-pause':
        html = renderCountdownPause(slide);
        break;
      default: {
        const custom = getPluginTemplateRenderer(slide.type);
        if (custom) html = custom(slide, context, options) || renderBlank();
        else html = renderCustom({ title: slide.title, text: slide.text || '' });
        break;
      }
    }
    return appendPluginSlideChrome(html, slide);
  } finally {
    setRenderOpts(prevOpts);
  }
}

export function renderFooter(showVerse, defaults) {
  if (!showVerse) return '';
  const ev = defaults?.event || {};
  return `<footer class="screen-footer"><span>${esc(ev.motto)} — ${esc(ev.mottoText)}</span></footer>`;
}

export function renderWatermark(context = {}) {
  const logo = url(context, 'logo', PRODUCT_LOGO_REL);
  return `<img class="screen-watermark" src="${logo}" alt="" />`;
}

export function renderClock() {
  return `
    <div class="screen-clock" id="screen-clock" aria-hidden="true">
      <div class="screen-clock-card">
        <span class="screen-clock-time">00:00:00</span>
        <span class="screen-clock-date">—</span>
      </div>
    </div>`;
}
