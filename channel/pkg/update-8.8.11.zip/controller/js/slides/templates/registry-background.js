import { esc } from '../../core/render-engine/index.js';
import { resolveSystemLoopAlias } from '../../core/media-url.js';
import { defaultSlideGradientPreset, gradientClassForPreset, getRenderOpts } from './shared.js';

const pluginTemplateRenderers = new Map();
let templateHookBooted = false;

export function registerPluginTemplate(type, renderer) {
  if (!type || typeof renderer !== 'function') return false;
  pluginTemplateRenderers.set(String(type), renderer);
  return true;
}

export function unregisterPluginTemplate(type) {
  return pluginTemplateRenderers.delete(String(type));
}

export function getPluginTemplateRenderer(type) {
  return pluginTemplateRenderers.get(type);
}

async function ensureTemplatePlugins() {
  if (templateHookBooted) return;
  templateHookBooted = true;
  try {
    const { ensurePluginsLoaded } = await import('../../plugins/plugin-host.js');
    await ensurePluginsLoaded();
    const { PluginEngine } = await import('../../plugins/plugin-engine.js');
    await PluginEngine.runHook('template:register', {
      register: registerPluginTemplate,
      types: [...pluginTemplateRenderers.keys()],
    });
  } catch { /* ignore */ }
}

void ensureTemplatePlugins();

export function slideBackgroundHtml(slide, options = {}) {
  const bg = slide.background || { type: 'gradient', preset: defaultSlideGradientPreset(slide) };
  const persistAttr = options.persist ? ' data-slide-bg-persist="1" data-lyrics-persist="1"' : '';
  const videoCls = `slide-bg-video lyrics-bg-video${options.previewLight ? ' lyrics-bg-video--preview' : ''}`;
  if (bg.type === 'video' && bg.src) {
    if (options.previewLight) {
      return `<video class="${videoCls}"${persistAttr} src="${esc(bg.src)}" muted loop playsinline preload="metadata" disablepictureinpicture disableremoteplayback></video>`;
    }
    return `<video class="${videoCls}"${persistAttr} src="${esc(bg.src)}" autoplay muted loop playsinline preload="auto" disablepictureinpicture disableremoteplayback></video>`;
  }
  if (bg.type === 'image' && bg.src) {
    return `<div class="slide-bg slide-bg-image lyrics-bg-image ken-burns"${persistAttr} style="background-image:url('${esc(bg.src)}')"></div>`;
  }
  const preset = bg.preset || defaultSlideGradientPreset(slide);
  return `<div class="slide-bg ${gradientClassForPreset(preset)} slide-bg-gradient lyrics-bg-gradient"${persistAttr}></div>`;
}

export function lyricsBackgroundHtml(slide, options = {}) {
  return slideBackgroundHtml(slide, options);
}

export function slideBackgroundOverlayHtml() {
  return `<div class="slide-bg-overlay lyrics-bg-overlay"></div>`;
}

export function lyricsOverlayHtml() {
  return slideBackgroundOverlayHtml();
}

export function normalizeLyricsFx(slide, prefs = null) {
  const global = prefs?.lyricsFx || {};
  const local = slide?.lyricsFx || slide?.data?.lyricsFx || {};
  return { ...global, ...local };
}

export function renderLyricsAmbientLayer(slide, prefs = null) {
  const fx = normalizeLyricsFx(slide, prefs);
  const id = fx.ambient && fx.ambient !== 'none' ? fx.ambient : '';
  if (!id) return '';
  return `<div class="lyrics-ambient-layer lyrics-ambient-${id}" aria-hidden="true"></div>`;
}

export function renderSlideBackgroundBlock(slide, options = {}, prefs = null) {
  const ambient = options.includeAmbient ? renderLyricsAmbientLayer(slide, prefs) : '';
  const overlay = options.overlay !== false ? slideBackgroundOverlayHtml() : '';
  return `${slideBackgroundHtml(slide, options)}${ambient}${overlay}`;
}

export function normalizeMediaSrcKey(src) {
  if (!src) return '';
  try {
    let s = String(src).trim();
    s = s.replace(/^https?:\/\/[^/]+/i, '');
    s = decodeURIComponent(s);
    return s.replace(/^\.\//, '').replace(/^\/+/, '').toLowerCase();
  } catch {
    return String(src).trim().toLowerCase();
  }
}

export function slideBackgroundKey(slide) {
  const bg = slide?.background || { type: 'gradient', preset: defaultSlideGradientPreset(slide) };
  if (bg.type === 'video' && bg.src) return `video:${normalizeMediaSrcKey(bg.src)}`;
  if (bg.type === 'image' && bg.src) return `image:${normalizeMediaSrcKey(bg.src)}`;
  return `gradient:${bg.preset || defaultSlideGradientPreset(slide)}`;
}

export const lyricsBackgroundKey = slideBackgroundKey;

export function renderLyricsBackgroundPersist(slide, prefs = null, options = {}) {
  const ambient = renderLyricsAmbientLayer(slide, prefs);
  const isWelcome = slide?.type === 'welcome';
  const overlay = (options.overlay === false || isWelcome) ? '' : lyricsOverlayHtml();
  return `${lyricsBackgroundHtml(slide, options)}${ambient}${overlay}`;
}

export function normalizeSlideBackground(slide) {
  if (!slide || typeof slide !== 'object') return slide;
  const existing = slide.background;
  const w = slide.data || slide.welcome || {};
  // Já tem fundo com src — ainda assim corrige type image+mp4 e kind video
  if (existing?.src && (existing.type === 'video' || existing.type === 'image')) {
    const src = String(existing.src);
    const isVideo = existing.type === 'video'
      || w.bgKind === 'video'
      || slide.bgKind === 'video'
      || /\.(mp4|webm|mov)(\?|$)/i.test(src);
    if (isVideo && existing.type !== 'video') {
      slide.background = { ...existing, type: 'video' };
    }
    return slide;
  }
  const raw = String(
    existing?.src
    || w.bgMedia
    || slide.bgMedia
    || w.backgroundSrc
    || '',
  ).trim();
  const id = w.bgMediaId || slide.bgMediaId || '';
  const src = resolveSystemLoopAlias(id) || resolveSystemLoopAlias(raw) || raw;
  if (!src) return slide;
  const isVideo = existing?.type === 'video'
    || w.bgKind === 'video'
    || slide.bgKind === 'video'
    || /\.(mp4|webm|mov)(\?|$)/i.test(src);
  slide.background = {
    type: isVideo ? 'video' : 'image',
    src,
    ...(existing?.preset ? { preset: existing.preset } : {}),
  };
  return slide;
}

export function standardSlideBg(slide, options = {}) {
  const opts = { ...getRenderOpts(), ...options };
  if (opts.persistBackground) return '';
  const hasMedia = slide.background?.type === 'video' || slide.background?.type === 'image';
  if (hasMedia) {
    return `${slideBackgroundHtml(slide, options)}${slideBackgroundOverlayHtml()}`;
  }
  return slideBackgroundHtml(slide, options);
}
