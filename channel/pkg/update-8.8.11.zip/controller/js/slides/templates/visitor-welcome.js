/**
 * Slide exclusivo do plugin Boas-vindas a visitantes.
 * Visual próprio — não reutiliza o layout de Bem-vindo do programa.
 */
import { esc } from '../../core/render-engine/index.js';
import { slideStyleVars, url } from './shared.js';
import { PRODUCT_LOGO_REL } from '../../core/brand-assets.js';

function tipList(slide) {
  const fromVisitor = slide?._visitorCard?.lines;
  if (Array.isArray(fromVisitor) && fromVisitor.length) {
    return fromVisitor.map((t) => String(t || '').trim()).filter(Boolean);
  }
  if (Array.isArray(slide?.items) && slide.items.length) {
    return slide.items.map((it) => String(it?.text ?? it ?? '').trim()).filter(Boolean);
  }
  return [];
}

export function renderVisitorWelcome(slide, context = {}) {
  const church = context.prefs?.church || {};
  const logo = url(context, 'logo', church.logoPath || PRODUCT_LOGO_REL);
  const title = slide?.title || 'Seja bem-vindo!';
  const subtitle = slide?.subtitle || '';
  const churchLine = slide?._visitorCard?.churchLine
    || slide?.churchLine
    || (church.name || '');
  const tips = tipList(slide);
  const showLogo = slide?.showLogo !== false && !!logo;

  const tipsHtml = tips.length
    ? `<ol class="visitor-tips" aria-label="Orientações">
        ${tips.map((text, i) => `
          <li class="visitor-tip anim-visitor-tip" style="--vi-i:${i}">
            <span class="visitor-tip-index">${String(i + 1).padStart(2, '0')}</span>
            <span class="visitor-tip-text">${esc(text)}</span>
          </li>`).join('')}
      </ol>`
    : '';

  return `
    <div class="slide slide-visitor" data-type="visitor-welcome" style="${slideStyleVars(slide?.style)}">
      <div class="visitor-bg" aria-hidden="true">
        <div class="visitor-bg-base"></div>
        <div class="visitor-bg-glow visitor-bg-glow--a"></div>
        <div class="visitor-bg-glow visitor-bg-glow--b"></div>
        <div class="visitor-bg-frame"></div>
        <div class="visitor-bg-sheen"></div>
      </div>
      <div class="visitor-stage">
        <header class="visitor-hero">
          <p class="visitor-kicker anim-visitor-kicker"><span>Visitantes</span></p>
          ${showLogo ? `<div class="visitor-logo-wrap anim-visitor-logo"><img class="visitor-logo" src="${esc(logo)}" alt="" /></div>` : ''}
          <h1 class="visitor-title anim-visitor-title">${esc(title)}</h1>
          ${subtitle ? `<p class="visitor-subtitle anim-visitor-sub">${esc(subtitle)}</p>` : ''}
          ${churchLine ? `
            <div class="visitor-church anim-visitor-church">
              <span class="visitor-church-rule" aria-hidden="true"></span>
              <p class="visitor-church-name">${esc(churchLine)}</p>
            </div>` : ''}
        </header>
        ${tipsHtml ? `<div class="visitor-panel anim-visitor-panel">${tipsHtml}</div>` : ''}
      </div>
    </div>`;
}
