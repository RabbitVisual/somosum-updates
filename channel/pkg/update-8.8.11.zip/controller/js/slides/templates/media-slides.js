import { esc } from '../../core/render-engine/index.js';
import { applyTextTransform } from '../../core/fonts.js';
import { getMessageMode } from '../message-display-modes.js';
import {
  getRenderOpts,
  messageStyleVars,
  slideStyleVars,
  slidePersistClass,
  url,
} from './shared.js';
import {
  slideBackgroundHtml,
  slideBackgroundOverlayHtml,
  standardSlideBg,
} from './registry-background.js';
import { PRODUCT_LOGO_REL } from '../../core/brand-assets.js';
import { renderDesignerLayer } from './designer.js';

export function renderMediaAudio(slide) {
  const cover = slide.coverSrc || '';
  const loop = slide.loop ? ' loop' : '';
  return `
    <div class="slide slide-media-audio" data-type="media-audio" style="${slideStyleVars(slide.style)}">
      ${standardSlideBg(slide)}
      <div class="slide-content media-audio-content anim-fade-up">
        ${cover ? `<img class="media-audio-cover" src="${cover}" alt="" />` : '<div class="media-audio-icon">♫</div>'}
        <h2 class="media-audio-title">${esc(slide.title || 'Áudio')}</h2>
        ${slide.hint ? `<p class="media-audio-hint">${esc(slide.hint)}</p>` : ''}
        ${slide.src
          ? `<audio class="media-audio-el" src="${slide.src}" autoplay${loop}></audio>`
          : '<p class="media-audio-missing">Selecione um arquivo de áudio no inspetor</p>'}
      </div>
    </div>`;
}

function offeringKicker(layout, slide = null) {
  if (slide?.kicker || slide?.offeringKicker) return String(slide.kicker || slide.offeringKicker);
  if (layout === 'dizimo') return 'Dízimo';
  if (layout === 'mission') return 'Missões';
  if (layout === 'oferta') return 'Oferta';
  if (layout === 'sacred') return 'Adoração';
  if (layout === 'compact') return 'PIX';
  if (layout === 'split') return 'Contribua';
  if (layout === 'link' || layout === 'qr') return 'QR Code';
  return 'Contribuição';
}

function offeringPixMetaHtml(pix, { showPayload = true, compact = false } = {}) {
  if (!pix) return '';
  const payload = showPayload && pix.showPayload !== false && (pix.payload || '').trim();
  const showKey = pix.showKey !== false && !!(pix.key || '').trim();
  return `
    <div class="offering-pix-meta${compact ? ' offering-pix-meta--compact' : ''}">
      ${pix.holder ? `<p class="offering-pix-holder">${esc(pix.holder)}</p>` : ''}
      ${showKey ? `<p class="offering-pix-key"><span>Chave</span> ${esc(pix.key)}</p>` : ''}
      ${payload ? `<p class="offering-pix-payload"><span>Copia e Cola</span> ${esc(pix.payload)}</p>` : ''}
      ${pix.city ? `<p class="offering-pix-city">${esc(pix.city)}</p>` : ''}
      ${pix.note ? `<p class="offering-pix-note">${esc(pix.note)}</p>` : ''}
    </div>`;
}

function offeringQrFrame(pix, variant = 'scan') {
  if (!pix?.qrDataUrl) {
    return `<div class="offering-qr-missing">Configure a chave Pix no Studio</div>`;
  }
  const img = `<img class="offering-pix-qr" src="${esc(pix.qrDataUrl)}" alt="QR Code Pix" />`;
  if (variant === 'bare') return img;
  if (variant === 'glow') {
    return `
      <div class="offering-qr-glow">
        <div class="offering-qr-glow__ring" aria-hidden="true"></div>
        <div class="offering-qr-tilt">${img}</div>
      </div>`;
  }
  if (variant === 'white') {
    return `<div class="offering-qr-white">${img}</div>`;
  }
  if (variant === 'pix') {
    return `
      <div class="offering-qr-pix">
        <span class="offering-qr-pix__badge" aria-hidden="true">PIX</span>
        <div class="offering-qr-white">${img}</div>
        <div class="offering-qr-pix__hint">Escaneie com o app do banco</div>
      </div>`;
  }
  return `
    <div class="offering-qr-scan">
      <span class="offering-qr-scan__corner offering-qr-scan__corner--tl" aria-hidden="true"></span>
      <span class="offering-qr-scan__corner offering-qr-scan__corner--tr" aria-hidden="true"></span>
      <span class="offering-qr-scan__corner offering-qr-scan__corner--bl" aria-hidden="true"></span>
      <span class="offering-qr-scan__corner offering-qr-scan__corner--br" aria-hidden="true"></span>
      <div class="offering-qr-scan__beam" aria-hidden="true"></div>
      ${img}
    </div>`;
}

function offeringCopyBlock(slide, layout, { highlightSubtitle = false } = {}) {
  const kicker = offeringKicker(layout, slide);
  const sub = slide.subtitle
    ? (highlightSubtitle
      ? `<p class="offering-subtitle offering-subtitle--accent">${esc(slide.subtitle)}</p>`
      : `<p class="offering-subtitle">${esc(slide.subtitle)}</p>`)
    : '';
  return `
    <div class="offering-copy">
      <p class="offering-kicker">${esc(kicker)}</p>
      <h1 class="offering-title">${esc(slide.title || 'Oferta e Dízimos')}</h1>
      ${sub}
      ${slide.verse ? `<blockquote class="offering-verse">${esc(slide.verse)}</blockquote>` : ''}
    </div>`;
}

export function renderOffering(slide) {
  const pix = slide?.pix;
  const layout = slide.offeringLayout || slide.data?.template || 'classic';
  const hasPix = !!(pix && (pix.key || pix.payload || pix.qrDataUrl));
  const showPayload = pix?.showPayload !== false;

  let body = '';

  if (layout === 'split' && hasPix) {
    body = `
      <div class="offering-layout offering-layout--split">
        <div class="offering-layout__col offering-layout__col--copy anim-fade-up">
          ${offeringCopyBlock(slide, layout)}
          ${offeringPixMetaHtml(pix, { showPayload })}
        </div>
        <div class="offering-layout__col offering-layout__col--qr anim-fade-up delay-1">
          <div class="offering-decor offering-decor--orb" aria-hidden="true"></div>
          ${offeringQrFrame(pix, 'pix')}
        </div>
      </div>`;
  } else if (layout === 'mission' && hasPix) {
    body = `
      <div class="offering-layout offering-layout--mission">
        <div class="offering-layout__panel offering-layout__panel--info anim-fade-up">
          ${offeringCopyBlock(slide, layout, { highlightSubtitle: true })}
          ${offeringQrFrame(pix, 'white')}
          ${offeringPixMetaHtml(pix, { showPayload: false, compact: true })}
        </div>
        <div class="offering-layout__panel offering-layout__panel--visual" aria-hidden="true">
          <div class="offering-mission-shapes">
            <span class="offering-mission-star"></span>
            <span class="offering-mission-bloom"></span>
            <span class="offering-mission-cloud"></span>
          </div>
          <p class="offering-mission-tag">Missões · Evangelho</p>
        </div>
      </div>`;
  } else if (layout === 'oferta' && hasPix) {
    body = `
      <div class="offering-layout offering-layout--glow">
        <div class="offering-layout__col offering-layout__col--copy anim-fade-up">
          <p class="offering-kicker">Oferta</p>
          <h1 class="offering-title offering-title--impact">
            <span class="offering-title__line">Escaneie o</span>
            <span class="offering-title__line offering-title__line--accent">QR CODE</span>
            <span class="offering-title__line">${esc(slide.title || 'Oferta')}</span>
          </h1>
          ${slide.subtitle ? `<p class="offering-subtitle">${esc(slide.subtitle)}</p>` : ''}
          ${slide.verse ? `<blockquote class="offering-verse">${esc(slide.verse)}</blockquote>` : ''}
          ${offeringPixMetaHtml(pix, { showPayload: false, compact: true })}
        </div>
        <div class="offering-layout__col offering-layout__col--qr anim-fade-up delay-1">
          ${offeringQrFrame(pix, 'glow')}
          <p class="offering-scan-cta">Aponte a câmera</p>
        </div>
      </div>`;
  } else if (layout === 'dizimo' && hasPix) {
    body = `
      <div class="offering-layout offering-layout--dizimo">
        <div class="offering-layout__col offering-layout__col--copy anim-fade-up">
          ${offeringCopyBlock(slide, layout)}
        </div>
        <div class="offering-layout__col offering-layout__col--card anim-fade-up delay-1">
          ${offeringQrFrame(pix, 'scan')}
          ${offeringPixMetaHtml(pix, { showPayload })}
        </div>
      </div>`;
  } else if (layout === 'compact' && hasPix) {
    body = `
      <div class="offering-layout offering-layout--compact anim-fade-up">
        <p class="offering-kicker">${esc(offeringKicker(layout, slide))}</p>
        <h1 class="offering-title offering-title--compact">${esc(slide.title || 'PIX')}</h1>
        ${offeringQrFrame(pix, 'scan')}
        ${offeringPixMetaHtml(pix, { showPayload: false, compact: true })}
      </div>`;
  } else if (layout === 'sacred' && hasPix) {
    body = `
      <div class="offering-layout offering-layout--sacred anim-fade-up">
        <div class="offering-sacred-halo" aria-hidden="true"></div>
        ${offeringCopyBlock(slide, layout)}
        <div class="offering-sacred-card delay-1">
          ${offeringQrFrame(pix, 'white')}
          ${offeringPixMetaHtml(pix, { showPayload: false })}
        </div>
      </div>`;
  } else {
    body = `
      <div class="offering-layout offering-layout--classic anim-fade-up">
        ${offeringCopyBlock(slide, layout === 'classic' ? 'classic' : layout)}
        ${hasPix ? `
        <div class="offering-classic-card anim-fade-up delay-1">
          ${offeringQrFrame(pix, 'scan')}
          ${offeringPixMetaHtml(pix, { showPayload })}
        </div>` : ''}
      </div>`;
  }

  return `
    <div class="slide slide-offering slide-offering--${esc(layout)}${slidePersistClass()}" data-type="offering" style="${slideStyleVars(slide.style)}">
      ${standardSlideBg(slide)}
      <div class="slide-content offering-stage">
        ${body}
      </div>
    </div>`;
}

export function renderCountdownPause(slide) {
  return `
    <div class="slide slide-countdown-pause${slidePersistClass()}" data-type="countdown-pause" style="${slideStyleVars(slide.style)}">
      ${standardSlideBg(slide)}
      <div class="slide-content anim-fade-up">
        <p class="pause-kicker">Pausa</p>
        <h1 class="pause-title">${esc(slide.title || 'Pausa')}</h1>
        ${slide.note ? `<p class="pause-note">${esc(slide.note)}</p>` : ''}
      </div>
    </div>`;
}

export function renderMessage(slide) {
  const st = slide.style || {};
  const tt = st.textTransform || 'none';
  const modeDef = getMessageMode(slide.messageMode || 'ref_pregador');
  const showTheme = modeDef.showTheme && (slide.theme || '').trim();
  const showMotto = modeDef.showMottoSection && slide.showMotto !== false && (slide.mottoText || '').trim();
  const showReference = modeDef.showReference && (slide.reference || '').trim();
  const showPhoto = modeDef.showPreacher && slide.showPreacherPhoto === true && !!(slide.preacherPhoto || '').trim();
  const hasPreacher = modeDef.showPreacher && ((slide.preacher || '').trim() || (slide.preacherFrom || '').trim());
  const refOnly = showReference && !showTheme && !showMotto;
  const showLabels = st.showLabels !== false;
  let layout = st.layout || 'balanced';
  if (refOnly && layout !== 'center') layout = 'ref-only';
  const align = st.align || (layout === 'center' ? 'center' : 'left');
  const layoutClass = [
    `message-layout--${layout}`,
    `message-layout--align-${align}`,
    showLabels ? '' : 'message-layout--no-labels',
    showPhoto ? '' : 'message-layout--no-photo',
  ].filter(Boolean).join(' ');
  const label = (text) => (showLabels ? `<span class="msg-label">${text}</span>` : '');
  const preacherCard = hasPreacher ? `
        <div class="message-preacher-card anim-fade-up delay-2${showPhoto ? '' : ' message-preacher-card--text-only'}">
          ${showPhoto ? `<img class="msg-preacher-photo" src="${esc(slide.preacherPhoto)}" alt="" />` : ''}
          <div class="msg-preacher-info">
            ${label('Pregador')}
            <p class="msg-preacher-name">${esc(slide.preacher || '')}</p>
            ${slide.preacherFrom ? `<p class="msg-preacher-from">${esc(slide.preacherFrom)}</p>` : ''}
          </div>
        </div>` : '';
  return `
    <div class="slide slide-message-pro${slidePersistClass()}" data-type="message" style="${messageStyleVars({ ...st, align })}">
      ${standardSlideBg(slide)}
      <div class="slide-overlay message-overlay"></div>
      <div class="slide-content message-layout ${layoutClass} anim-fade-up">
        <div class="message-center">
          ${showTheme ? `
          <div class="message-block message-block-theme">
            ${label('Tema')}
            <h1 class="msg-theme-title">${esc(applyTextTransform(slide.theme, tt))}</h1>
          </div>` : ''}
          ${showMotto ? `
          <div class="message-block message-block-motto">
            ${label('Divisa')}
            <blockquote class="msg-motto-text">“${esc(slide.mottoText)}”</blockquote>
          </div>` : ''}
          ${showReference ? `
          <div class="message-block message-block-ref">
            ${label('Referência')}
            <p class="msg-reference">${esc(slide.reference)}</p>
          </div>` : ''}
        </div>
        ${preacherCard}
      </div>
    </div>`;
}

export function renderTheme(slide, context = {}) {
  const ev = context.defaults?.event || {};
  return `
    <div class="slide slide-theme${slidePersistClass()}" data-type="theme" style="${slideStyleVars(slide.style)}">
      ${standardSlideBg(slide)}
      <div class="slide-content">
        <p class="theme-label anim-fade-up">Divisa</p>
        <p class="theme-motto anim-fade-up delay-1">${esc(slide.motto || ev.motto)}</p>
        <blockquote class="theme-verse anim-glow delay-2">${esc(slide.mottoText || ev.mottoText)}</blockquote>
        <h1 class="theme-title anim-fade-up delay-3">${esc(slide.theme || ev.theme)}</h1>
      </div>
    </div>`;
}

export function renderCustom(slide) {
  const lowSpec = !!(window.__SOMOSUM_LOW_SPEC || slide.designer?.preferBitmap);
  const hasLayers = slide.layers?.length > 0;
  const preview = slide.previewDataUrl || slide.designer?.previewDataUrl || '';

  const designerBgBlock = () => {
    const bg = slide.background || {};
    const dim = Number(bg.dim || 0);
    const dimHtml = dim > 0
      ? `<div class="slide-bg-dim" style="opacity:${Math.min(0.85, dim)}"></div>`
      : '';
    if (bg.type === 'video' && bg.src) {
      return `${slideBackgroundHtml(slide)}${dimHtml}`;
    }
    let bgExtra = '';
    if (bg.type === 'color') {
      bgExtra = `background:${bg.value}`;
    } else if (bg.type === 'image' && bg.src) {
      const fit = bg.fit === 'contain' ? 'contain' : 'cover';
      bgExtra = `background-image:url('${bg.src}');background-size:${fit};background-position:center`;
    } else if (bg.type === 'gradient' || bg.preset) {
      const preset = bg.preset || 'dark';
      const gradients = {
        dark: 'linear-gradient(180deg,#0a0a0a,#1a1a1a)',
        gold: 'linear-gradient(160deg,#1a1510,#3d2e18,#1a1510)',
        theme: 'linear-gradient(200deg,#0c0a14,#1a1530,#12101a)',
        charcoal: 'linear-gradient(180deg,#0e0e0e,#242424)',
        communion: 'linear-gradient(150deg,#080604,#2a1810,#0d0a08)',
        bible: 'linear-gradient(190deg,#0a1018,#142030,#0a1018)',
      };
      const stops = Array.isArray(bg.colors) && bg.colors.length >= 2
        ? `linear-gradient(${bg.angle || 180}deg,${bg.colors.join(',')})`
        : (gradients[preset] || gradients.dark);
      bgExtra = `background:${stops}`;
    }
    return `<div class="slide-bg gradient-dark" style="${bgExtra}"></div>${dimHtml}`;
  };

  if (preview && (lowSpec || slide.designer?.preferBitmap)) {
    return `
      <div class="slide slide-custom slide-custom-canvas slide-custom-bitmap" data-type="custom" style="${slideStyleVars(slide.style)}">
        <img class="slide-preview-bitmap" src="${preview}" alt="" />
      </div>`;
  }

  if (hasLayers && !lowSpec) {
    const layerHtml = slide.layers.map((layer) => renderDesignerLayer(layer, slide)).join('');
    return `
      <div class="slide slide-custom slide-custom-canvas" data-type="custom" style="${slideStyleVars(slide.style)}">
        ${designerBgBlock()}
        <div class="custom-canvas-layers">${layerHtml}</div>
      </div>`;
  }

  if (preview && (lowSpec || hasLayers || !slide.title)) {
    return `
      <div class="slide slide-custom slide-custom-canvas slide-custom-bitmap" data-type="custom" style="${slideStyleVars(slide.style)}">
        <img class="slide-preview-bitmap" src="${preview}" alt="" />
      </div>`;
  }

  if (hasLayers) {
    const layerHtml = slide.layers.map((layer) => renderDesignerLayer(layer, slide)).join('');
    return `
      <div class="slide slide-custom slide-custom-canvas" data-type="custom" style="${slideStyleVars(slide.style)}">
        ${designerBgBlock()}
        <div class="custom-canvas-layers">${layerHtml}</div>
      </div>`;
  }

  const hasText = slide.text?.trim();
  const hasSub = slide.subtitle?.trim();
  const align = slide.style?.align || 'center';
  const bg = slide.background;
  let bgClass = 'gradient-dark';
  let bgStyle = '';
  if (bg?.type === 'video' && bg.src) {
    const dim = Number(bg.dim || 0);
    const dimHtml = dim > 0
      ? `<div class="slide-bg-dim" style="opacity:${Math.min(0.85, dim)}"></div>`
      : '';
    if (!hasText && slide.title) {
      return `
      <div class="slide slide-custom slide-custom-title" data-type="custom" style="${slideStyleVars(slide.style)};text-align:${align}">
        ${slideBackgroundHtml(slide)}${dimHtml}
        <div class="slide-content anim-fade-up">
          <h1 class="custom-title-only">${esc(slide.title)}</h1>
          ${hasSub ? `<p class="custom-subtitle">${esc(slide.subtitle)}</p>` : ''}
        </div>
      </div>`;
    }
    return `
    <div class="slide slide-custom" data-type="custom" style="${slideStyleVars(slide.style)};text-align:${align}">
      ${slideBackgroundHtml(slide)}${dimHtml}
      <div class="slide-content anim-fade-up">
        ${slide.title ? `<h2 class="custom-title">${esc(slide.title)}</h2>` : ''}
        ${hasSub ? `<p class="custom-subtitle">${esc(slide.subtitle)}</p>` : ''}
        ${hasText ? `<p class="custom-text">${esc(slide.text).replace(/\n/g, '<br>')}</p>` : ''}
      </div>
    </div>`;
  }
  if (bg?.type === 'color' && bg.value) {
    bgStyle = `background:${bg.value}`;
    bgClass = '';
  } else if (bg?.preset) {
    const map = { dark: 'gradient-dark', gold: 'gradient-theme', theme: 'gradient-theme', charcoal: 'gradient-dark', bible: 'gradient-bible', communion: 'gradient-communion' };
    bgClass = map[bg.preset] || 'gradient-dark';
  }
  if (!hasText && slide.title) {
    return `
      <div class="slide slide-custom slide-custom-title" data-type="custom" style="${slideStyleVars(slide.style)};text-align:${align}">
        <div class="slide-bg ${bgClass}" style="${bgStyle}"></div>
        <div class="slide-content anim-fade-up">
          <h1 class="custom-title-only">${esc(slide.title)}</h1>
          ${hasSub ? `<p class="custom-subtitle">${esc(slide.subtitle)}</p>` : ''}
        </div>
      </div>`;
  }
  return `
    <div class="slide slide-custom" data-type="custom" style="${slideStyleVars(slide.style)};text-align:${align}">
      <div class="slide-bg ${bgClass}" style="${bgStyle}"></div>
      <div class="slide-content anim-fade-up">
        ${slide.title ? `<h2 class="custom-title">${esc(slide.title)}</h2>` : ''}
        ${hasSub ? `<p class="custom-subtitle">${esc(slide.subtitle)}</p>` : ''}
        ${hasText ? `<p class="custom-text">${esc(slide.text).replace(/\n/g, '<br>')}</p>` : ''}
      </div>
    </div>`;
}

export function renderMedia(slide) {
  const caption = slide.showCaption !== false && slide.title
    ? `<div class="media-caption">${esc(slide.title)}</div>`
    : '';
  if (slide.kind === 'video') {
    return `
      <div class="slide slide-media" data-type="media" style="${slideStyleVars(slide.style)}">
        <video class="media-video" src="${slide.src}" autoplay muted playsinline ${slide.loop !== false ? 'loop' : ''}></video>
        ${caption}
      </div>`;
  }
  return `
    <div class="slide slide-media" data-type="media" style="${slideStyleVars(slide.style)}">
      <img class="media-image" src="${slide.src}" alt="" />
      ${caption}
    </div>`;
}

export function renderBlank() {
  return `<div class="slide slide-blank" data-type="blank"></div>`;
}

export function renderAnnouncements(slide) {
  const items = slide.items || [];
  const hasMediaBg = slide.background?.type === 'video' || slide.background?.type === 'image';
  const bgHtml = hasMediaBg
    ? `${slideBackgroundHtml(slide)}${slideBackgroundOverlayHtml()}`
    : standardSlideBg(slide);
  const bgSrc = slide.backgroundSrc || slide.bgSrc || '';
  const hasPhotoBg = !hasMediaBg && !!bgSrc;
  const legacyBgHtml = hasPhotoBg
    ? `<div class="slide-bg announcements-bg-image" style="background-image:url('${esc(bgSrc)}')"></div>
       <div class="slide-bg-dim announcements-bg-dim"></div>`
    : bgHtml;

  if (slide.carouselNotice) {
    const body = items[0]?.text || items[0] || '';
    return `
      <div class="slide slide-announcements is-carousel-notice${slidePersistClass()}" data-type="announcements" style="${slideStyleVars(slide.style)}">
        ${legacyBgHtml}
        <div class="slide-content announcements-content announcements-content--hero">
          <h1 class="announcements-title anim-fade-up">${esc(slide.title || 'Avisos')}</h1>
          ${body
            ? `<p class="announcements-hero-text anim-fade-up delay-1">${esc(String(body))}</p>`
            : '<p class="announcements-empty anim-fade-up">Nenhum aviso</p>'}
        </div>
      </div>`;
  }

  const bullets = items.map((item, i) => `
    <li class="announce-item anim-fade-up delay-${Math.min(i + 1, 6)}">
      <span class="announce-icon">${esc(item.icon || '•')}</span>
      <span class="announce-text">${esc(item.text || item)}</span>
    </li>`).join('');
  return `
    <div class="slide slide-announcements${hasPhotoBg || hasMediaBg ? ' has-photo-bg' : ''}${slidePersistClass()}" data-type="announcements" style="${slideStyleVars(slide.style)}">
      ${legacyBgHtml}
      <div class="slide-content announcements-content">
        <h1 class="announcements-title anim-fade-up">${esc(slide.title || 'Comunicados')}</h1>
        ${items.length ? `<ul class="announcements-list">${bullets}</ul>` : '<p class="announcements-empty anim-fade-up">Nenhum aviso cadastrado</p>'}
        ${slide.totalPages > 1 ? `<p class="announcements-page anim-fade-up delay-4">${slide.page} / ${slide.totalPages}</p>` : ''}
      </div>
    </div>`;
}

function communionCrossSvg() {
  return `<svg class="communion-cross" viewBox="0 0 64 64" aria-hidden="true"><path d="M28 8h8v20h20v8H36v20h-8V36H8v-8h20V8z" fill="currentColor"/></svg>`;
}

function communionWheatSvg() {
  return `<svg class="communion-wheat-svg" viewBox="0 0 120 160" aria-hidden="true" role="img">
    <defs>
      <linearGradient id="wheatGrad" x1="0%" y1="0%" x2="0%" y2="100%">
        <stop offset="0%" stop-color="#e8c97a"/>
        <stop offset="100%" stop-color="#b8862e"/>
      </linearGradient>
    </defs>
    <g fill="url(#wheatGrad)" stroke="#8b6914" stroke-width="1.2">
      <ellipse cx="60" cy="148" rx="28" ry="8" fill="#6b4a1a" opacity="0.6"/>
      <path d="M60 145V95" stroke="#a07830" stroke-width="3" fill="none"/>
      <path d="M60 110c-18-8-28-22-28-38 0 14 10 26 28 34"/>
      <path d="M60 95c18-8 28-22 28-38 0 14-10 26-28 34"/>
      <path d="M60 125c-14-6-22-16-22-28 0 10 8 18 22 24"/>
      <path d="M60 118c14-6 22-16 22-28 0 10-8 18-22 24"/>
      <path d="M60 138c-10-4-16-12-16-20 0 8 6 14 16 18"/>
      <path d="M60 133c10-4 16-12 16-20 0 8-6 14-16 18"/>
    </g>
  </svg>`;
}

function communionCupSvg() {
  return `<svg class="communion-cup-svg" viewBox="0 0 120 160" aria-hidden="true" role="img">
    <defs>
      <linearGradient id="cupGold" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stop-color="#e8c97a"/>
        <stop offset="100%" stop-color="#a07830"/>
      </linearGradient>
      <linearGradient id="wineGrad" x1="0%" y1="0%" x2="0%" y2="100%">
        <stop offset="0%" stop-color="#8b2942"/>
        <stop offset="100%" stop-color="#4a1020"/>
      </linearGradient>
    </defs>
    <ellipse cx="60" cy="132" rx="32" ry="6" fill="#2a1810" opacity="0.5"/>
    <path d="M35 55 L45 115 Q60 125 75 115 L85 55 Z" fill="url(#cupGold)" stroke="#8b6914" stroke-width="1.5"/>
    <path class="comm-cup-wine" d="M42 62 L48 108 Q60 116 72 108 L78 62 Z" fill="url(#wineGrad)" opacity="0.9"/>
    <path d="M60 55 L60 38 M52 38 L68 38" stroke="url(#cupGold)" stroke-width="3" fill="none" stroke-linecap="round"/>
    <ellipse cx="60" cy="55" rx="22" ry="5" fill="none" stroke="#c9a050" stroke-width="2"/>
  </svg>`;
}

function communionVisualForPhase(phaseId, showElements) {
  if (!showElements) return '';
  const id = phaseId || 'intro';
  if (id === 'bread') {
    return `<div class="communion-visual anim-fade-up delay-1">${communionWheatSvg()}</div>`;
  }
  if (id === 'cup') {
    return `<div class="communion-visual anim-fade-up delay-1">${communionCupSvg()}</div>`;
  }
  if (id === 'intro') {
    return `<div class="communion-visual anim-fade-up delay-1">${communionWheatSvg()}${communionCupSvg()}</div>`;
  }
  return '';
}

function communionPhaseDots(current, total) {
  if (total <= 1) return '';
  const dots = Array.from({ length: total }, (_, i) =>
    `<span class="communion-phase-dot${i === current ? ' is-active' : ''}"></span>`
  ).join('');
  return `<div class="communion-phase-dots">${dots}</div>`;
}

export function renderCommunion(slide) {
  const phase = slide.phase || {};
  const st = slide.style || {};
  const anim = st.animation || 'reverent';
  const phaseId = phase.id || 'intro';
  const idx = slide.phaseIndex ?? 0;
  const total = slide.totalPhases ?? 1;
  const ornament = slide.showCross ? communionCrossSvg() : `
    <div class="communion-ornament anim-fade-up">
      <span class="communion-ornament-line"></span>
      <span aria-hidden="true" class="su-fa" style="color:var(--comm-wheat);font-size:1.2rem"><i class="fa-duotone fa-sparkles" aria-hidden="true"></i></span>
      <span class="communion-ornament-line"></span>
    </div>`;
  const hasMediaBg = slide.background?.type === 'video' || slide.background?.type === 'image';
  const persistBg = !!getRenderOpts().persistBackground;
  const bgBlock = persistBg
    ? ''
    : hasMediaBg
      ? `${slideBackgroundHtml(slide)}${slideBackgroundOverlayHtml()}`
      : `<div class="slide-bg communion-bg"></div>`;
  return `
    <div class="slide slide-communion anim-${esc(anim)}${persistBg ? ' slide--bg-persist' : ''}" data-type="communion" data-phase="${esc(phaseId)}" style="${slideStyleVars(st)}">
      ${bgBlock}
      <div class="communion-grain"></div>
      <div class="slide-overlay communion-overlay"></div>
      <div class="communion-vignette"></div>
      <div class="slide-content communion-content">
        ${ornament}
        <h1 class="communion-title anim-fade-up">${esc(phase.title || 'Ceia do Senhor')}</h1>
        ${phase.subtitle ? `<p class="communion-subtitle anim-fade-up delay-1">${esc(phase.subtitle)}</p>` : ''}
        ${communionVisualForPhase(phaseId, slide.showElements !== false)}
        ${phase.reference ? `<p class="communion-ref anim-fade-up delay-2">${esc(phase.reference)}</p>` : ''}
        ${phase.text ? `<div class="communion-text-wrap anim-fade-up delay-3"><blockquote class="communion-text">${esc(phase.text)}</blockquote></div>` : ''}
        ${total > 1 ? `
          <p class="communion-phase-indicator anim-fade-up delay-4">${idx + 1} / ${total}</p>
          ${communionPhaseDots(idx, total)}` : ''}
      </div>
    </div>`;
}

export function renderLogo(context = {}) {
  const logo = url(context, 'logo', PRODUCT_LOGO_REL);
  return `
    <div class="slide slide-logo" data-type="logo">
      <div class="slide-bg"></div>
      <div class="slide-content">
        <img src="${logo}" alt="Logo" class="logo-full anim-fade-up" />
      </div>
    </div>`;
}
