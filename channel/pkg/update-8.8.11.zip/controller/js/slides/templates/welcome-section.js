import { esc } from '../../core/render-engine/index.js';
import { applyTextTransform } from '../../core/fonts.js';
import { resolveChurchWelcomeBgUrl } from '../../core/store.js';
import { resolveSystemLoopAlias } from '../../core/media-url.js';
import { normalizeWelcomeData, welcomeStyleVars, welcomeElementStyleAttr, resolveWelcomeElementPosition, WELCOME_SLOT_ELEMENT_ORDER } from '../welcome-config.js';
import { getRenderOpts, slideStyleVars, slidePersistClass, url } from './shared.js';
import { standardSlideBg } from './registry-background.js';
import { PRODUCT_LOGO_REL } from '../../core/brand-assets.js';

export function renderWelcome(slide, context = {}) {
  const ev = context.defaults?.event || {};
  const church = context.prefs?.church || {};
  const w = normalizeWelcomeData(slide, church);
  const defaultBg = url(context, 'welcomeBg', resolveChurchWelcomeBgUrl({ church, assets: context.assets }));
  const fromSlideBg = (slide.background?.type === 'video' || slide.background?.type === 'image')
    && slide.background?.src
    ? String(slide.background.src).trim()
    : '';
  const customBgRaw = String(w.bgMedia || fromSlideBg || '').trim();
  const customBg = resolveSystemLoopAlias(w.bgMediaId)
    || resolveSystemLoopAlias(customBgRaw)
    || customBgRaw;
  const bgIsVideo = slide.background?.type === 'video'
    || w.bgKind === 'video'
    || /\.(mp4|webm|mov)(\?|$)/i.test(customBg);
  const bg = customBg || defaultBg;
  const persistBg = !!getRenderOpts().persistBackground;
  const logo = url(context, 'logo', church.logoPath || PRODUCT_LOGO_REL);
  const churchName = church.name || ev.church || '';
  const layout = w.layout || 'center';
  const anim = w.animation || 'classic';
  const badgeStyle = w.badgeStyle || 'pill';
  const preset = w.welcomePreset || 'domingo';
  const bgClass = w.bgMotion === 'static' || bgIsVideo ? '' : 'ken-burns';
  const logoPos = w.showLogo ? (w.logoPosition || 'top') : 'hidden';
  const sparklesOn = !!w.sparkles || w.atmosParticles === 'sparkles';
  const particles = w.atmosParticles || 'none';
  const showChurchText = w.showChurchName && churchName;
  const layoutClass = [
    'slide',
    'slide-welcome',
    'welcome-positioned',
    persistBg ? 'slide--bg-persist' : '',
    w.scrimEnabled !== false ? 'welcome-scrim-on' : 'welcome-scrim-off',
    `welcome-skin--${preset}`,
    `welcome-layout--${layout}`,
    `welcome-logo--${logoPos}`,
    `welcome-anim--${anim}`,
    `welcome-overlay--${w.overlayStrength || 'strong'}`,
    `welcome-badge--${badgeStyle}`,
    sparklesOn ? 'welcome-has-sparkles' : '',
    w.textShine !== false ? 'welcome-text-shine' : '',
    particles !== 'none' ? `welcome-particles--${particles}` : '',
    bgIsVideo ? 'welcome-has-video-bg' : '',
  ].filter(Boolean).join(' ');

  const elWrap = (key, inner, extraClass = '') => {
    if (!inner) return '';
    const styleAttr = welcomeElementStyleAttr(key, w);
    const tstyle = w.textStyles?.[key] || 'classic';
    const cls = ['welcome-el', `welcome-el--${key}`, `welcome-tstyle--${tstyle}`, extraClass].filter(Boolean).join(' ');
    return `<div class="${cls}" style="${styleAttr}">${inner}</div>`;
  };

  const pieces = {
    logo: w.showLogo && logoPos !== 'hidden'
      ? elWrap('logo', `<div class="welcome-brand anim-welcome-logo"><img class="welcome-logo" src="${logo}" alt="" /></div>`)
      : '',
    badge: w.showBadge !== false && w.badge
      ? elWrap('badge', `<p class="welcome-badge welcome-badge-style--${badgeStyle} anim-welcome d1">${esc(w.badge)}</p>`)
      : '',
    churchName: showChurchText
      ? elWrap('churchName', `<p class="welcome-church anim-welcome d2">${esc(churchName)}</p>`)
      : '',
    years: w.showYears !== false
      ? elWrap('years', `<h1 class="welcome-years anim-welcome d3"><span class="welcome-years-inner">${esc(w.years)}</span></h1>`)
      : '',
    theme: w.showTheme !== false && w.theme
      ? elWrap('theme', `<p class="welcome-theme anim-welcome d4"><span class="welcome-theme-text">${esc(w.theme)}</span></p>`)
      : '',
    dateLine: w.showDate !== false && w.dateLine
      ? elWrap('dateLine', `<p class="welcome-date anim-welcome d5">${esc(w.dateLine)}</p>`)
      : '',
    subtitle: w.showSubtitle !== false && w.subtitle
      ? elWrap('subtitle', `<p class="welcome-sub anim-welcome d6">${esc(w.subtitle)}</p>`)
      : '',
    extraLine: w.showExtra !== false && w.extraLine
      ? elWrap('extraLine', `<p class="welcome-extra anim-welcome d7">${esc(w.extraLine)}</p>`)
      : '',
  };

  const slots = new Map();
  for (const key of WELCOME_SLOT_ELEMENT_ORDER) {
    const html = pieces[key];
    if (!html) continue;
    const slotId = resolveWelcomeElementPosition(key, w);
    if (!slots.has(slotId)) slots.set(slotId, []);
    slots.get(slotId).push(html);
  }

  const slotHtml = [...slots.entries()].map(([slotId, items]) =>
    `<div class="welcome-slot welcome-slot--${slotId}">${items.join('')}</div>`,
  ).join('');

  const stageInner = `<div class="welcome-position-stage">${slotHtml}</div>`;

  const bgLayer = persistBg
    ? ''
    : bgIsVideo
      ? `<video class="slide-bg welcome-bg welcome-bg-video" src="${esc(bg)}" autoplay muted playsinline loop></video>`
      : `<div class="slide-bg ${bgClass} welcome-bg" style="background-image:url('${bg}')"></div>`;

  const particleLayer = particles === 'petals'
    ? `<div class="welcome-petals" aria-hidden="true">${Array.from({ length: 12 }, (_, i) =>
      `<span class="welcome-petal" style="--i:${i}"></span>`).join('')}</div>`
    : particles === 'dust'
      ? `<div class="welcome-dust" aria-hidden="true"></div>`
      : '';

  return `
    <div class="${layoutClass}" data-type="welcome" data-welcome-preset="${esc(preset)}" style="${welcomeStyleVars(w)}">
      ${bgLayer}
      <div class="welcome-atmosphere" aria-hidden="true">
        <div class="welcome-atmos-mesh"></div>
        <div class="welcome-atmos-orb welcome-atmos-orb--a"></div>
        <div class="welcome-atmos-orb welcome-atmos-orb--b"></div>
        <div class="welcome-atmos-orb welcome-atmos-orb--c"></div>
        <div class="welcome-atmos-beam"></div>
        <div class="welcome-atmos-grid"></div>
        <div class="welcome-atmos-ring"></div>
        <div class="welcome-atmos-sheen"></div>
      </div>
      ${particleLayer}
      <div class="welcome-blur-scrim" aria-hidden="true"></div>
      <div class="slide-overlay welcome-overlay"></div>
      <div class="welcome-vignette" aria-hidden="true"></div>
      <div class="welcome-sparkles" aria-hidden="true"></div>
      <div class="welcome-edge welcome-edge--l" aria-hidden="true"></div>
      <div class="welcome-edge welcome-edge--r" aria-hidden="true"></div>
      <div class="slide-content welcome-content">
        ${stageInner}
      </div>
    </div>`;
}

export function renderSection(slide) {
  const subtitle = (slide.subtitle || '').trim();
  const text = (slide.text || '').trim();
  return `
    <div class="slide slide-section${slidePersistClass()}" data-type="section" style="${slideStyleVars(slide.style)}">
      ${standardSlideBg(slide)}
      <div class="slide-content">
        <h1 class="section-title anim-fade-up">${esc(slide.title)}</h1>
        ${subtitle ? `<p class="section-sub anim-fade-up">${esc(subtitle)}</p>` : ''}
        ${text ? `<p class="section-text anim-fade-up">${esc(text).replace(/\n/g, '<br>')}</p>` : ''}
      </div>
    </div>`;
}

export function renderPrayer(slide) {
  const text = (slide.text || '').trim();
  return `
    <div class="slide slide-prayer${slidePersistClass()}" data-type="prayer" style="${slideStyleVars(slide.style)}">
      ${standardSlideBg(slide)}
      <div class="slide-content">
        <h1 class="prayer-title anim-fade-up">${esc(slide.title || 'Oração')}</h1>
        ${text ? `<p class="prayer-text anim-fade-up">${esc(text).replace(/\n/g, '<br>')}</p>` : ''}
      </div>
    </div>`;
}

export function renderParticipation(slide) {
  const style = slide.style || {};
  const label = slide.participationLabel || 'Participação';
  const name = slide.participantName || '';
  const song = slide.songTitle || '';
  const extra = slide.extraText || '';
  const nameSize = style.nameSize || 88;
  return `
    <div class="slide slide-participation${slidePersistClass()}" data-type="participation" style="${slideStyleVars(style)}--part-name-size:${nameSize}px;">
      ${standardSlideBg(slide)}
      <div class="slide-content anim-fade-up">
        <p class="participation-kicker">${esc(label)}</p>
        ${name ? `<h1 class="participation-name" style="font-size:clamp(2rem,5vw,var(--part-name-size,${nameSize}px))">${esc(name)}</h1>` : ''}
        ${song ? `<p class="participation-song">${esc(song)}</p>` : ''}
        ${extra ? `<p class="participation-extra">${esc(extra)}</p>` : ''}
      </div>
    </div>`;
}
