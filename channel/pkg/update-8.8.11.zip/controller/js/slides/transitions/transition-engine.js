import { applyTransition } from '../animations.js';

export class TransitionEngine {
  constructor(stageEl) {
    this.stage = stageEl;
  }
  async before(slide, animate) {
    if (!animate || !slide?.transition) return;
    applyTransition(this.stage, slide.transition);
  }
  async after() {
    return true;
  }
}
