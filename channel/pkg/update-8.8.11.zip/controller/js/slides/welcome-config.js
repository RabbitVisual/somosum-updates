/** Presets e normalização do slide Boas-Vindas (temas por tipo de culto). */
import { fontFamilyCss } from '../core/fonts.js';
import { resolveMediaSrc, resolveSystemLoopAlias } from '../core/media-url.js';

/** Boas-vindas padrão — celebração / visitantes. */
export const DEFAULT_WELCOME_NORMAL = {
  badge: '',
  years: 'Bem-vindos',
  theme: '',
  subtitle: '',
  dateLine: '',
  extraLine: 'É uma alegria receber você',
  layout: 'center',
  logoPosition: 'top',
  logoSize: 260,
  showLogo: true,
  showChurchName: true,
  showBadge: true,
  showTheme: true,
  showSubtitle: true,
  showDate: true,
  showExtra: true,
  showYears: true,
  animation: 'classic',
  bgMotion: 'kenburns',
  overlayStrength: 'strong',
  accent: '#d4c68d',
  accentSoft: 'rgba(212, 198, 141, 0.28)',
  badgeStyle: 'pill',
  sparkles: false,
  textShine: true,
  atmosParticles: 'none',
  /** Id da mídia na biblioteca (preferencial). Vazio = foto da igreja. */
  bgMediaId: '',
  /** URL resolvida (preenchida pelo inspetor a partir do id). */
  bgMedia: '',
  bgKind: 'image',
  welcomePreset: 'domingo',
  overlayOpacity: 0.72,
  scrimEnabled: true,
  positions: {},
  colors: {},
  textStyles: {},
  sizes: {},
};

/** Preset legado / evento de aniversário da congregação (opcional). */
export const DEFAULT_WELCOME_ANNIVERSARY = {
  badge: 'Aniversário da Congregação',
  years: '23 Anos',
  theme: 'SOMOS UM',
  subtitle: 'Congregação Cristã no Brasil',
  dateLine: 'Sábado 11 e Domingo 12 de julho de 2026',
  extraLine: 'Celebramos a unidade em Cristo',
  layout: 'split-left',
  logoPosition: 'top',
  logoSize: 260,
  showLogo: true,
  showChurchName: true,
  animation: 'anniversary',
  bgMotion: 'kenburns',
  overlayStrength: 'strong',
  accent: '#e8c97a',
  accentSoft: 'rgba(232, 201, 122, 0.35)',
  badgeStyle: 'ribbon',
  sparkles: true,
  welcomePreset: 'aniversario',
};

/**
 * Catálogo único de Boas-Vindas.
 * Um modelo = identidade visual + textos sugeridos + atmosfera.
 * Ajuste fino (logo, campos, fundo) no inspetor / wizard.
 */
export const WELCOME_PRESETS = [
  {
    id: 'domingo',
    label: 'Celebração',
    description: 'Culto de domingo — tipografia clássica e ouro',
    data: {
      ...DEFAULT_WELCOME_NORMAL,
      badge: 'Culto de Celebração',
      years: 'Bem-vindos',
      theme: '',
      extraLine: 'A casa do Senhor se alegra com a sua presença',
      layout: 'center',
      animation: 'classic',
      overlayStrength: 'strong',
      accent: '#e4d4a0',
      accentSoft: 'rgba(228, 212, 160, 0.32)',
      badgeStyle: 'pill',
      textShine: true,
      atmosParticles: 'dust',
    },
  },
  {
    id: 'quarta',
    label: 'Oração',
    description: 'Culto de oração — tipografia serena e luz suave',
    data: {
      ...DEFAULT_WELCOME_NORMAL,
      badge: 'Culto de Oração',
      years: 'Bem-vindos',
      theme: '',
      showTheme: false,
      extraLine: 'Em silêncio e fé, apresentamos nosso coração a Deus',
      layout: 'center',
      animation: 'serene',
      overlayStrength: 'strong',
      bgMotion: 'static',
      accent: '#b8c9dc',
      accentSoft: 'rgba(184, 201, 220, 0.3)',
      badgeStyle: 'line',
      textShine: true,
      atmosParticles: 'none',
    },
  },
  {
    id: 'missoes',
    label: 'Missões',
    description: 'Culto de missões — hero com tipografia forte',
    data: {
      ...DEFAULT_WELCOME_NORMAL,
      badge: 'Culto de Missões',
      years: 'Ide',
      theme: 'E fazei discípulos',
      extraLine: 'Levantemos os olhos para a seara que já embranquece',
      layout: 'hero',
      animation: 'rise',
      overlayStrength: 'medium',
      accent: '#d4b483',
      accentSoft: 'rgba(212, 180, 131, 0.34)',
      badgeStyle: 'pill',
      textShine: true,
      atmosParticles: 'dust',
    },
  },
  {
    id: 'mulheres',
    label: 'Mulheres',
    description: 'Culto rosa — pétalas, degradê e tipografia elegante',
    data: {
      ...DEFAULT_WELCOME_NORMAL,
      badge: 'Ministério de Mulheres',
      years: 'Bem-vindas',
      theme: 'Filhas do Rei',
      extraLine: 'Fortalecidas na fé, no amor e na unidade',
      layout: 'split-left',
      animation: 'elegant',
      overlayStrength: 'medium',
      accent: '#f0b4c4',
      accentSoft: 'rgba(240, 180, 196, 0.42)',
      badgeStyle: 'pill',
      sparkles: false,
      textShine: true,
      atmosParticles: 'petals',
      bgMotion: 'kenburns',
    },
  },
  {
    id: 'homens',
    label: 'Homens',
    description: 'Culto de homens — azul sóbrio e tipografia firme',
    data: {
      ...DEFAULT_WELCOME_NORMAL,
      badge: 'Ministério de Homens',
      years: 'Bem-vindos',
      theme: 'Homens de fé',
      extraLine: 'Caráter, serviço e compromisso com Cristo',
      layout: 'split-left',
      animation: 'classic',
      overlayStrength: 'strong',
      accent: '#8eb0d8',
      accentSoft: 'rgba(142, 176, 216, 0.32)',
      badgeStyle: 'line',
      textShine: true,
      atmosParticles: 'none',
    },
  },
  {
    id: 'jovens',
    label: 'Jovens',
    description: 'Encontro de jovens — energia e brilho',
    data: {
      ...DEFAULT_WELCOME_NORMAL,
      badge: 'Ministério de Jovens',
      years: 'BEM-VINDOS',
      theme: 'Geração viva',
      showSubtitle: false,
      subtitle: '',
      extraLine: 'Apaixonados por Cristo — prontos para servir',
      layout: 'hero',
      animation: 'pulse',
      overlayStrength: 'medium',
      accent: '#f5dfa0',
      accentSoft: 'rgba(245, 223, 160, 0.45)',
      badgeStyle: 'pill',
      sparkles: true,
      textShine: true,
      atmosParticles: 'sparkles',
      logoSize: 200,
    },
  },
  {
    id: 'criancas',
    label: 'Crianças',
    description: 'Ministério infantil — alegre e acolhedor',
    data: {
      ...DEFAULT_WELCOME_NORMAL,
      badge: 'Ministério Infantil',
      years: 'Bem-vindos!',
      theme: 'Pequenos no Reino',
      extraLine: 'Jesus ama e abençoa cada criança',
      layout: 'hero',
      animation: 'playful',
      overlayStrength: 'light',
      accent: '#8fd4ef',
      accentSoft: 'rgba(143, 212, 239, 0.4)',
      badgeStyle: 'pill',
      sparkles: true,
      textShine: true,
      atmosParticles: 'sparkles',
    },
  },
  {
    id: 'ceia',
    label: 'Ceia do Senhor',
    description: 'Ceia do Senhor — tipografia sóbria e reverente',
    data: {
      ...DEFAULT_WELCOME_NORMAL,
      badge: 'Ceia do Senhor',
      years: 'Bem-vindos',
      theme: 'Fazei isto em memória de mim',
      extraLine: 'Em memória do corpo e do sangue do Senhor',
      layout: 'center',
      animation: 'serene',
      overlayStrength: 'strong',
      bgMotion: 'static',
      accent: '#c9a87a',
      accentSoft: 'rgba(201, 168, 122, 0.3)',
      badgeStyle: 'line',
      textShine: true,
      atmosParticles: 'dust',
    },
  },
  {
    id: 'noite',
    label: 'Noite',
    description: 'Culto noturno — ouro quente e atmosfera íntima',
    data: {
      ...DEFAULT_WELCOME_NORMAL,
      badge: 'Culto da Noite',
      years: 'Bem-vindos',
      theme: 'À luz da Palavra',
      extraLine: 'Uma noite para adorar e ouvir a Deus',
      layout: 'hero',
      animation: 'elegant',
      overlayStrength: 'strong',
      accent: '#e8c878',
      accentSoft: 'rgba(232, 200, 120, 0.36)',
      badgeStyle: 'ribbon',
      textShine: true,
      atmosParticles: 'dust',
    },
  },
  {
    id: 'familia',
    label: 'Família',
    description: 'Culto em família — acolhedor e claro',
    data: {
      ...DEFAULT_WELCOME_NORMAL,
      badge: 'Culto em Família',
      years: 'Bem-vindos',
      theme: 'Casa de oração',
      extraLine: 'Gerações unidas na adoração ao Senhor',
      layout: 'center',
      animation: 'classic',
      overlayStrength: 'medium',
      accent: '#dcc690',
      accentSoft: 'rgba(220, 198, 144, 0.34)',
      badgeStyle: 'pill',
      textShine: true,
      atmosParticles: 'none',
    },
  },
  {
    id: 'especial',
    label: 'Especial',
    description: 'Evento especial — personalize o tema no inspetor',
    data: {
      ...DEFAULT_WELCOME_NORMAL,
      badge: 'Culto Especial',
      years: 'Bem-vindos',
      theme: 'Tema do Evento',
      extraLine: 'Uma noite especial na presença de Deus',
      layout: 'hero',
      animation: 'elegant',
      overlayStrength: 'strong',
      accent: '#e6d4a4',
      accentSoft: 'rgba(230, 212, 164, 0.36)',
      badgeStyle: 'ribbon',
      textShine: true,
      atmosParticles: 'dust',
    },
  },
  {
    id: 'aniversario',
    label: 'Aniversário',
    description: 'Aniversário da congregação',
    data: {
      ...DEFAULT_WELCOME_ANNIVERSARY,
      showBadge: true,
      showTheme: true,
      showSubtitle: true,
      showDate: true,
      showExtra: true,
      textShine: true,
      atmosParticles: 'sparkles',
      bgMediaId: '',
      bgMedia: '',
      bgKind: 'image',
    },
  },
];

export const WELCOME_LAYOUTS = [
  { id: 'center', label: 'Centro clássico' },
  { id: 'split-left', label: 'Logo à esquerda' },
  { id: 'split-right', label: 'Logo à direita' },
  { id: 'hero', label: 'Hero — título grande' },
];

export const WELCOME_LOGO_POSITIONS = [
  { id: 'top', label: 'Acima do texto' },
  { id: 'left', label: 'Coluna esquerda' },
  { id: 'right', label: 'Coluna direita' },
  { id: 'bottom', label: 'Abaixo do texto' },
];

export const WELCOME_ANIMATIONS = [
  { id: 'classic', label: 'Clássico suave' },
  { id: 'elegant', label: 'Elegante' },
  { id: 'minimal', label: 'Minimal' },
  { id: 'serene', label: 'Sereno (oração)' },
  { id: 'pulse', label: 'Pulse (jovens)' },
  { id: 'rise', label: 'Rise (missões)' },
  { id: 'playful', label: 'Alegre (crianças)' },
  { id: 'anniversary', label: 'Aniversário (evento)' },
];

export const WELCOME_BADGE_STYLES = [
  { id: 'pill', label: 'Pílula' },
  { id: 'line', label: 'Linha sob texto' },
  { id: 'ribbon', label: 'Faixa destaque' },
];

export const WELCOME_POSITION_PRESETS = [
  { id: 'top-left', label: 'Topo esquerda' },
  { id: 'top-center', label: 'Topo centro' },
  { id: 'top-right', label: 'Topo direita' },
  { id: 'middle-left', label: 'Meio esquerda' },
  { id: 'center', label: 'Centro' },
  { id: 'middle-right', label: 'Meio direita' },
  { id: 'bottom-left', label: 'Baixo esquerda' },
  { id: 'bottom-center', label: 'Baixo centro' },
  { id: 'bottom-right', label: 'Baixo direita' },
];

export const WELCOME_TEXT_STYLE_PRESETS = [
  { id: 'classic', label: 'Clássico ouro', fontWeight: '600', letterSpacing: '0.02em' },
  { id: 'elegant', label: 'Elegante fino', fontWeight: '300', letterSpacing: '0.12em', textTransform: 'uppercase' },
  { id: 'bold', label: 'Impacto forte', fontWeight: '800', letterSpacing: '0.04em' },
  { id: 'soft', label: 'Suave acolhedor', fontWeight: '400', letterSpacing: '0.06em' },
  { id: 'impact', label: 'Hero grande', fontWeight: '900', letterSpacing: '-0.02em' },
  { id: 'script', label: 'Destaque manuscrito', fontWeight: '500', letterSpacing: '0.08em', fontStyle: 'italic' },
];

export const WELCOME_ELEMENT_KEYS = [
  { id: 'years', label: 'Título principal' },
  { id: 'badge', label: 'Etiqueta' },
  { id: 'theme', label: 'Tema' },
  { id: 'subtitle', label: 'Subtítulo' },
  { id: 'dateLine', label: 'Data' },
  { id: 'extraLine', label: 'Linha de apoio' },
  { id: 'churchName', label: 'Nome da igreja' },
  { id: 'logo', label: 'Logo' },
];

/** Ordem estável de empilhamento dentro de cada slot da grade 3×3. */
export const WELCOME_SLOT_ELEMENT_ORDER = [
  'logo', 'badge', 'churchName', 'years', 'theme', 'dateLine', 'subtitle', 'extraLine',
];

/** Presets rápidos de posição no inspetor (aba Elementos). */
export const WELCOME_LAYOUT_POSITION_PRESETS = {
  allCenter: {
    label: 'Tudo no centro (empilhado)',
    positions: {
      logo: 'center',
      badge: 'center',
      theme: 'center',
      years: 'center',
      subtitle: 'center',
      dateLine: 'center',
      extraLine: 'center',
      churchName: 'center',
    },
  },
  logoSide: {
    label: 'Logo lateral + texto centro',
    positions: {
      logo: 'middle-left',
      years: 'center',
      badge: 'center',
      theme: 'center',
      subtitle: 'bottom-center',
      dateLine: 'bottom-center',
      extraLine: 'bottom-center',
      churchName: 'center',
    },
  },
};

const POSITION_IDS = new Set(WELCOME_POSITION_PRESETS.map((p) => p.id));

export function logoPositionToPreset(logoPos = 'top') {
  const map = {
    top: 'top-center',
    left: 'middle-left',
    right: 'middle-right',
    bottom: 'bottom-center',
    hidden: 'center',
  };
  return map[logoPos] || 'top-center';
}

export function defaultWelcomePositions(layout = 'center') {
  const base = {
    badge: 'top-center',
    years: 'center',
    theme: 'center',
    subtitle: 'bottom-center',
    dateLine: 'bottom-center',
    extraLine: 'bottom-center',
    churchName: 'top-center',
    logo: logoPositionToPreset('top'),
  };
  if (layout === 'split-left') {
    return { ...base, logo: 'middle-left', years: 'middle-right', theme: 'middle-right', badge: 'middle-right' };
  }
  if (layout === 'split-right') {
    return { ...base, logo: 'middle-right', years: 'middle-left', theme: 'middle-left', badge: 'middle-left' };
  }
  if (layout === 'hero') {
    return { ...base, years: 'center', badge: 'top-center', extraLine: 'bottom-center' };
  }
  return base;
}

export function defaultWelcomeColors(accent = '#d4c68d') {
  const ink = '#fff8ec';
  const muted = 'rgba(255, 236, 205, 0.92)';
  return {
    years: ink,
    badge: accent,
    theme: accent,
    subtitle: muted,
    dateLine: muted,
    extraLine: muted,
    churchName: muted,
    logo: '',
  };
}

export function defaultWelcomeTextStyles() {
  return {
    years: 'impact',
    badge: 'elegant',
    theme: 'classic',
    subtitle: 'soft',
    dateLine: 'soft',
    extraLine: 'soft',
    churchName: 'classic',
    logo: 'classic',
  };
}

export function defaultWelcomeSizes() {
  return {
    years: 100,
    badge: 85,
    theme: 92,
    subtitle: 78,
    dateLine: 72,
    extraLine: 80,
    churchName: 82,
    logo: 100,
  };
}

/** Resolve fundo preservando URL quando mediaList ainda não carregou. */
export function resolveWelcomeBackground(data = {}, mediaList = [], church = {}) {
  const bgMediaId = String(data.bgMediaId || '').trim();
  const prevMedia = String(data.bgMedia || '').trim();
  const prevKind = data.bgKind === 'video' ? 'video' : 'image';
  const kindField = data.bgKind === 'video' ? 'video' : 'image';

  if (!bgMediaId) {
    return { bgMediaId: '', bgMedia: '', bgKind: 'image' };
  }

  const media = (mediaList || []).find((m) => m.id === bgMediaId);
  if (media) {
    // Packs do sistema costumam ter path sem src — resolveMediaSrc cobre path/system/alias
    const resolved = String(
      resolveMediaSrc(media)
      || resolveSystemLoopAlias(bgMediaId)
      || media.src
      || media.url
      || '',
    ).trim() || prevMedia;
    const srcHint = resolved || String(media.path || media.src || '');
    const isVideo = media.kind === 'video'
      || media.category === 'fundo-animado'
      || media.category === 'loop'
      || String(media.mimeType || media.mime || '').includes('video')
      || /\.(mp4|webm|mov)(\?|$)/i.test(srcHint)
      || kindField === 'video';
    return { bgMediaId, bgMedia: resolved, bgKind: isVideo ? 'video' : 'image' };
  }

  if (prevMedia) {
    return { bgMediaId, bgMedia: prevMedia, bgKind: prevKind };
  }

  return { bgMediaId, bgMedia: '', bgKind: kindField };
}

export function welcomeElementStyleAttr(key, w = {}) {
  const colors = w.colors || {};
  const sizes = w.sizes || {};
  const styles = w.textStyles || {};
  const styleId = styles[key] || 'classic';
  const preset = WELCOME_TEXT_STYLE_PRESETS.find((p) => p.id === styleId) || WELCOME_TEXT_STYLE_PRESETS[0];
  const color = colors[key] || '';
  const scale = Math.max(50, Math.min(160, Number(sizes[key]) || 100));
  const parts = [`--welcome-el-scale: ${scale / 100}`];
  if (color) parts.push(`--welcome-el-color: ${color}`);
  if (preset.fontWeight) parts.push(`font-weight: ${preset.fontWeight}`);
  if (preset.letterSpacing) parts.push(`letter-spacing: ${preset.letterSpacing}`);
  if (preset.textTransform) parts.push(`text-transform: ${preset.textTransform}`);
  if (preset.fontStyle) parts.push(`font-style: ${preset.fontStyle}`);
  return parts.join('; ');
}

export function welcomePositionClass(key, w = {}) {
  const pos = w.positions?.[key];
  const valid = pos && POSITION_IDS.has(pos) ? pos : null;
  return valid ? `welcome-pos--${valid}` : '';
}

/** Célula efetiva da grade 3×3 para agrupamento em slots. */
export function resolveWelcomeElementPosition(key, w = {}) {
  const pos = w.positions?.[key];
  if (pos && POSITION_IDS.has(pos)) return pos;
  if (key === 'logo' && w.showLogo !== false && (w.logoPosition || 'top') !== 'hidden') {
    return logoPositionToPreset(w.logoPosition || 'top');
  }
  return 'center';
}

export function welcomePresetForCultoType(cultoType = 'domingo') {
  const map = {
    quarta: 'quarta',
    especial: 'especial',
    missoes: 'missoes',
    mulheres: 'mulheres',
    homens: 'homens',
    jovens: 'jovens',
    criancas: 'criancas',
    ceia: 'ceia',
    noite: 'noite',
    familia: 'familia',
    aniversario: 'aniversario',
    domingo: 'domingo',
  };
  return map[cultoType] || 'domingo';
}

/** Resolve preset com dados da igreja (nome, tema, subtítulo). */
export function resolveWelcomePreset(presetId = 'domingo', church = {}) {
  const found = WELCOME_PRESETS.find((p) => p.id === presetId) || WELCOME_PRESETS[0];
  const base = { ...found.data, welcomePreset: found.id };
  const themedSkins = new Set(['jovens', 'criancas', 'mulheres', 'homens', 'missoes', 'ceia', 'noite', 'familia']);
  const churchSub = church.subtitle || church.name || '';
  const subtitle = (base.subtitle != null && String(base.subtitle).trim())
    ? base.subtitle
    : (themedSkins.has(found.id) ? '' : churchSub);
  return {
    ...base,
    theme: base.theme || church.defaultTheme || '',
    subtitle,
    years: base.years || church.defaultWelcomeTitle || 'Bem-vindos',
  };
}

/** Detecta seed antigo de aniversário (não evento personalizado). */
export function isStockAnniversaryWelcome(data = {}) {
  const years = String(data.years || '').trim();
  const badge = String(data.badge || '').trim();
  return (
    (/^23\s*anos$/i.test(years) || years === DEFAULT_WELCOME_ANNIVERSARY.years)
    && /anivers[aá]rio da congrega/i.test(badge)
  );
}

/**
 * Se o culto é dia comum e o welcome ainda é o seed de aniversário,
 * troca para o preset adequado (domingo/quarta/especial…).
 */
export function repairWelcomeDataForCulto(data = {}, cultoType = 'domingo', church = {}) {
  if (!isStockAnniversaryWelcome(data)) return data;
  if (data.welcomePreset === 'aniversario' && data.welcomeLocked) return data;
  const presetId = welcomePresetForCultoType(cultoType);
  if (presetId === 'aniversario') return data;
  return resolveWelcomePreset(presetId, church);
}

export function normalizeWelcomeData(data = {}, church = {}) {
  const d = { ...data };
  let dateLine = (d.dateLine ?? '').trim();
  let subtitle = (d.subtitle ?? '').trim();
  const extraLine = (d.extraLine ?? '').trim();
  const badge = (d.badge ?? '').trim();
  const churchSub = church.subtitle || church.name || '';

  if (/^\d{4}$/.test(subtitle) && !dateLine) {
    dateLine = '';
    subtitle = churchSub;
  }
  if (dateLine && /de\s*;?\s*$/i.test(dateLine) && /^\d{4}$/.test(subtitle)) {
    dateLine = dateLine.replace(/de\s*;?\s*$/i, `de ${subtitle}`);
    subtitle = churchSub;
  }
  if (dateLine && /^\d{4}$/.test(subtitle) && !dateLine.includes(subtitle)) {
    dateLine = `${dateLine} ${subtitle}`.trim();
    subtitle = churchSub;
  }

  let logoPos = d.logoPosition || 'top';
  if (logoPos === 'hidden') logoPos = 'top';
  const showLogo = d.showLogo !== false;
  if (!showLogo) logoPos = 'hidden';
  const looksAnniversary = /anivers[aá]rio/i.test(badge) || d.animation === 'anniversary';
  const presetId = d.welcomePreset || (looksAnniversary ? 'aniversario' : 'domingo');
  const catalog = WELCOME_PRESETS.find((p) => p.id === presetId)?.data || DEFAULT_WELCOME_NORMAL;
  const layout = d.layout || catalog.layout || 'center';
  const accent = d.accent || catalog.accent || DEFAULT_WELCOME_NORMAL.accent;
  const defaultPos = defaultWelcomePositions(layout);
  const positions = { ...defaultPos, ...(d.positions && typeof d.positions === 'object' ? d.positions : {}) };
  if (showLogo && d.logoPosition && d.logoPosition !== 'hidden') {
    positions.logo = positions.logo || logoPositionToPreset(d.logoPosition);
  }
  Object.keys(positions).forEach((k) => {
    if (!POSITION_IDS.has(positions[k])) positions[k] = defaultPos[k] || 'center';
  });

  const defaultColors = defaultWelcomeColors(accent);
  const colors = { ...defaultColors, ...(d.colors && typeof d.colors === 'object' ? d.colors : {}) };
  const textStyles = { ...defaultWelcomeTextStyles(), ...(d.textStyles && typeof d.textStyles === 'object' ? d.textStyles : {}) };
  const sizes = { ...defaultWelcomeSizes(), ...(d.sizes && typeof d.sizes === 'object' ? d.sizes : {}) };

  let overlayOpacity = Number(d.overlayOpacity);
  if (!Number.isFinite(overlayOpacity)) {
    const strengthMap = { strong: 0.78, medium: 0.55, light: 0.35 };
    overlayOpacity = strengthMap[d.overlayStrength] ?? strengthMap[catalog.overlayStrength] ?? 0.72;
  }
  overlayOpacity = Math.max(0, Math.min(1, overlayOpacity));

  return {
    ...d,
    badge,
    years: d.years || church.defaultWelcomeTitle || 'Bem-vindos',
    theme: d.theme || church.defaultTheme || '',
    subtitle: subtitle || churchSub,
    dateLine,
    extraLine,
    layout,
    logoPosition: showLogo ? logoPos : 'hidden',
    logoSize: Math.max(120, Math.min(480, Number(d.logoSize) || 260)),
    showLogo,
    showChurchName: d.showChurchName !== false,
    showBadge: d.showBadge !== false,
    showTheme: d.showTheme !== false,
    showSubtitle: d.showSubtitle !== false,
    showDate: d.showDate !== false,
    showExtra: d.showExtra !== false,
    showYears: d.showYears !== false,
    animation: d.animation || catalog.animation || (looksAnniversary ? 'anniversary' : 'classic'),
    bgMotion: d.bgMotion || catalog.bgMotion || 'kenburns',
    overlayStrength: d.overlayStrength || catalog.overlayStrength || 'strong',
    overlayOpacity,
    scrimEnabled: d.scrimEnabled !== false,
    accent,
    accentSoft: d.accentSoft || catalog.accentSoft || DEFAULT_WELCOME_NORMAL.accentSoft,
    badgeStyle: d.badgeStyle || catalog.badgeStyle || 'pill',
    sparkles: d.sparkles != null ? !!d.sparkles : !!catalog.sparkles,
    textShine: d.textShine !== false,
    atmosParticles: d.atmosParticles || catalog.atmosParticles || 'none',
    bgMediaId: String(d.bgMediaId || '').trim(),
    bgMedia: String(d.bgMedia || catalog.bgMedia || '').trim(),
    bgKind: d.bgKind === 'video' ? 'video' : 'image',
    welcomePreset: presetId,
    positions,
    colors,
    textStyles,
    sizes,
  };
}

export function welcomeStyleVars(slide = {}) {
  const st = slide.style || {};
  const ff = fontFamilyCss(st.fontFamily);
  const logoSize = Math.max(120, Math.min(480, Number(slide.logoSize) || 260));
  const accent = accentToHex(slide.accent || '#d4c68d');
  const accentSoft = slide.accentSoft || hexToAccentSoft(accent);
  return `
    --welcome-logo-size: ${logoSize}px;
    --welcome-accent: ${accent};
    --welcome-accent-soft: ${accentSoft};
    --welcome-overlay-tint: ${accentSoft};
    --welcome-overlay-opacity: ${Math.max(0, Math.min(1, Number(slide.overlayOpacity ?? 0.72)))};
    --slide-font-family: ${ff};
    --slide-title-size: ${st.titleSize || 92}px;
    --slide-text-size: ${st.textSize || 30}px;
    --slide-text-transform: ${st.textTransform || 'none'};
    --slide-align: ${st.align || 'center'};`;
}

/** Converte accent (#rgb / #rrggbb / rgba) para #rrggbb (input type=color). */
export function accentToHex(accent, fallback = '#d4c68d') {
  const s = String(accent || '').trim();
  if (/^#[0-9a-fA-F]{6}$/.test(s)) return s.toLowerCase();
  if (/^#[0-9a-fA-F]{3}$/.test(s)) {
    return `#${s[1]}${s[1]}${s[2]}${s[2]}${s[3]}${s[3]}`.toLowerCase();
  }
  const m = s.match(/rgba?\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)/i);
  if (m) {
    const hex = (n) => Math.max(0, Math.min(255, Number(n))).toString(16).padStart(2, '0');
    return `#${hex(m[1])}${hex(m[2])}${hex(m[3])}`;
  }
  return fallback;
}

export function hexToAccentSoft(hex, alpha = 0.3) {
  const h = accentToHex(hex);
  const m = /^#([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(h);
  if (!m) return 'rgba(212, 198, 141, 0.28)';
  return `rgba(${parseInt(m[1], 16)}, ${parseInt(m[2], 16)}, ${parseInt(m[3], 16)}, ${alpha})`;
}

/** Posição de logo coerente com o layout do preset. */
export function logoPositionForWelcomeLayout(layout, current = 'top') {
  if (layout === 'split-left') return 'left';
  if (layout === 'split-right') return 'right';
  if (current === 'left' || current === 'right') return 'top';
  return current || 'top';
}

/**
 * Monta data completa de boas-vindas a partir do preset (textos + identidade visual).
 * Usado pelo inspetor ao trocar template — não deixa campos “pela metade”.
 */
export function buildWelcomeDataFromPreset(presetId = 'domingo', church = {}, extras = {}) {
  const base = resolveWelcomePreset(presetId, church);
  const layout = extras.layout || base.layout || 'center';
  const accent = accentToHex(extras.accent || base.accent || DEFAULT_WELCOME_NORMAL.accent);
  return normalizeWelcomeData({
    ...base,
    ...extras,
    welcomePreset: presetId,
    layout,
    logoPosition: extras.logoPosition || logoPositionForWelcomeLayout(layout, base.logoPosition),
    accent,
    accentSoft: extras.accentSoft || base.accentSoft || hexToAccentSoft(accent),
    badgeStyle: extras.badgeStyle || base.badgeStyle || 'pill',
    sparkles: extras.sparkles != null ? !!extras.sparkles : !!base.sparkles,
    animation: extras.animation || base.animation || 'classic',
    bgMotion: extras.bgMotion || base.bgMotion || 'kenburns',
    overlayStrength: extras.overlayStrength || base.overlayStrength || 'strong',
  }, church);
}
