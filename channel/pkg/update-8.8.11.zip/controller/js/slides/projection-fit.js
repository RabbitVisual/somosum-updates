/** Thin wrapper — delega ao Display & Projection Engine (canvas dinâmico). */

import { DisplayProjectionEngine, getDesignDimensions } from '../runtime/facades/display-runtime.js';

export function getProjectionDesignSize(viewportEl) {
  const { w, h } = getDesignDimensions(viewportEl);
  return { w, h };
}

export const PROJECTION_DESIGN_W = typeof window !== 'undefined'
  ? (window.innerWidth || 0)
  : 0;

export const PROJECTION_DESIGN_H = typeof window !== 'undefined'
  ? (window.innerHeight || 0)
  : 0;

function readFontBoost() {
  try {
    const v = parseFloat(document.documentElement.dataset.projectionFontBoost);
    if (Number.isFinite(v) && v > 0) return v;
  } catch { /* ignore */ }
  return 1.15;
}

export function attachProjectionFit(viewportEl, canvasEl, options = {}) {
  if (!viewportEl || !canvasEl) return () => {};

  const engine = DisplayProjectionEngine.attach(viewportEl, canvasEl, options);
  document.documentElement.dataset.projectionFontBoost = String(readFontBoost());

  let disposeDiag = () => {};
  let disposeNative = () => {};
  import('../core/projection-diagnostic.js').then((mod) => {
    disposeDiag = mod.mountProjectionDiagnosticOverlay(viewportEl, engine);
    disposeNative = mod.bindNativeProjectionMessages(viewportEl, engine, (diag) => {
      engine.noteNativeGeometry?.(diag);
    });
  }).catch(() => {});

  return () => {
    disposeDiag();
    disposeNative();
    engine.detach();
  };
}
