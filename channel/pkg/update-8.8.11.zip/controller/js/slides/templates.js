export {
  registerPluginTemplate,
  unregisterPluginTemplate,
  slideBackgroundHtml,
  slideBackgroundOverlayHtml,
  renderSlideBackgroundBlock,
  normalizeMediaSrcKey,
  slideBackgroundKey,
  lyricsBackgroundKey,
  renderLyricsBackgroundPersist,
  normalizeSlideBackground,
} from './templates/registry-background.js';

export {
  renderWelcome,
  renderSection,
  renderPrayer,
  renderParticipation,
} from './templates/welcome-section.js';

export { renderVisitorWelcome } from './templates/visitor-welcome.js';

export {
  renderLyricsLinesBlock,
  applyLyricsStyleVars,
  lyricsStyleFingerprint,
  renderLyricsTitle,
  renderLyrics,
} from './templates/lyrics.js';

export {
  renderBibleInterlinear,
  renderBibleResponsive,
  renderBible,
  renderBibleReader,
} from './templates/bible.js';

export {
  renderMediaAudio,
  renderOffering,
  renderCountdownPause,
  renderMessage,
  renderTheme,
  renderCustom,
  renderMedia,
  renderBlank,
  renderAnnouncements,
  renderCommunion,
  renderLogo,
} from './templates/media-slides.js';

export { applyMessageStyleVars, applySlideStyleVars, applySlideLegibilityVars, messageStyleVars, slideStyleVars, slideTextEffectAttr } from './templates/shared.js';

export {
  renderSlide,
  renderFooter,
  renderWatermark,
  renderClock,
} from './templates/router.js';
