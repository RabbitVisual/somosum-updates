import { DiskAdapter } from '../core/storage/adapters/disk-adapter.js';

export const BUILTIN_OVERLAYS = {
  blank: { type: 'builtin', label: 'Tela preta', icon: 'square' },
  logo: { type: 'builtin', label: 'Logo', icon: 'seal' },
  silence: {
    type: 'message',
    label: 'Silêncio',
    icon: 'volume-xmark',
    title: 'Momento de silêncio e oração',
    subtitle: '',
  },
  stand: {
    type: 'message',
    label: 'Em pé',
    icon: 'person',
    title: 'Por favor, permaneçam em pé',
    subtitle: '',
  },
  seated: {
    type: 'message',
    label: 'Sentados',
    icon: 'chair',
    title: 'Podem se assentar',
    subtitle: '',
  },
  lowerThird: {
    type: 'lower-third',
    label: 'Lower third',
    icon: 'minus',
    text: 'Texto aqui',
  },
  ticker: {
    type: 'ticker',
    label: 'Faixa',
    icon: 'arrows-left-right',
    text: 'Comunicado urgente',
  },
};

export async function loadCustomOverlays() {
  const data = await DiskAdapter.load('overlays.json');
  return data?.custom || [];
}

export async function saveCustomOverlays(custom) {
  DiskAdapter.saveDebounced('overlays.json', { custom, updatedAt: new Date().toISOString() });
}

export function renderOverlayHtml(overlayId, payload = {}, context = {}) {
  const builtin = BUILTIN_OVERLAYS[overlayId];
  if (builtin?.type === 'message') {
    return `
      <div class="overlay-layer overlay-message anim-fade-up">
        <div class="overlay-message-box">
          <h2>${escapeHtml(builtin.title)}</h2>
          ${builtin.subtitle ? `<p>${escapeHtml(builtin.subtitle)}</p>` : ''}
        </div>
      </div>`;
  }
  if (overlayId === 'lowerThird' || payload.type === 'lower-third') {
    const text = payload.text || builtin?.text || '';
    return `
      <div class="overlay-layer overlay-lower-third anim-slide-up">
        <div class="overlay-lt-bar">${escapeHtml(text)}</div>
      </div>`;
  }
  if (overlayId === 'ticker' || payload.type === 'ticker') {
    const text = payload.text || builtin?.text || '';
    return `
      <div class="overlay-layer overlay-ticker">
        <div class="overlay-ticker-track"><span>${escapeHtml(text)}</span></div>
      </div>`;
  }
  if (payload.html) return payload.html;
  return '';
}

function escapeHtml(text) {
  const d = document.createElement('div');
  d.textContent = text ?? '';
  return d.innerHTML;
}

export function getOverlayList(custom = []) {
  const builtins = Object.entries(BUILTIN_OVERLAYS)
    .filter(([id]) => !['blank', 'logo'].includes(id))
    .map(([id, o]) => ({ id, ...o }));
  const customs = custom.map((c) => ({ id: c.id, type: 'custom', label: c.label, icon: c.icon || 'shapes', ...c }));
  return [...builtins, ...customs];
}
