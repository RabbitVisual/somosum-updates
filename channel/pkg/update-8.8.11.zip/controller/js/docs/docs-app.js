/** Documentação SOMOSUM — carrega e renderiza os .md oficiais (offline). */

const APP_AUTHOR = 'Reinan Rodrigues';
const APP_AUTHOR_EMAIL = 'r.rodriguesjs@gmail.com';
const APP_AUTHOR_PHONE = '75992034656';
const FALLBACK_VERSION = '7.4.0';

function formatPhoneBr(phone) {
  const d = String(phone).replace(/\D/g, '');
  if (d.length === 11) return `(${d.slice(0, 2)}) ${d.slice(2, 7)}-${d.slice(7)}`;
  if (d.length === 10) return `(${d.slice(0, 2)}) ${d.slice(2, 6)}-${d.slice(6)}`;
  return phone;
}

function escapeHtml(s) {
  return String(s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

let catalog = null;
let currentId = 'index';
let currentPlain = '';

function hashId() {
  const h = (location.hash || '#index').replace(/^#/, '').trim();
  return h || 'index';
}

function findItem(id) {
  if (!catalog) return null;
  for (const g of catalog.groups || []) {
    for (const item of g.items || []) {
      if (item.id === id) return item;
    }
  }
  return null;
}

function buildNav() {
  if (!catalog) return '';
  return (catalog.groups || []).map((g) => `
    <div class="docs-nav-group">
      <span class="docs-nav-label">${escapeHtml(g.title)}</span>
      <nav class="docs-nav">
        ${(g.items || []).map((l) =>
          `<a href="#${escapeHtml(l.id)}" data-doc="${escapeHtml(l.id)}">${escapeHtml(l.title)}</a>`
        ).join('')}
      </nav>
    </div>`).join('');
}

function setActiveNav(id) {
  document.querySelectorAll('.docs-nav a[data-doc]').forEach((a) => {
    a.classList.toggle('is-active', a.dataset.doc === id);
  });
}

function findDocByPath(relPath) {
  if (!catalog) return null;
  const norm = String(relPath || '')
    .replace(/\\/g, '/')
    .replace(/^\.\//, '')
    .replace(/^\//, '')
    .replace(/^docs\//i, '');
  const file = norm.split('/').pop();
  for (const g of catalog.groups || []) {
    for (const item of g.items || []) {
      const p = String(item.path || '').replace(/\\/g, '/');
      if (p === norm || p.endsWith('/' + norm) || p === file || p.endsWith('/' + file)) return item;
    }
  }
  return null;
}

/** Converte hrefs .md relativos em âncoras #docId do portal. */
function rewriteMdLinks(root) {
  root.querySelectorAll('a[href]').forEach((a) => {
    const href = a.getAttribute('href') || '';
    if (!/\.md($|#)/i.test(href) || /^https?:/i.test(href) || href.startsWith('/api')) return;
    const base = href.split('#')[0].replace(/\\/g, '/');
    const frag = href.includes('#') ? href.slice(href.indexOf('#') + 1) : '';
    const match = findDocByPath(base);
    if (match) {
      a.setAttribute('href', frag ? `#${match.id}` : `#${match.id}`);
    }
  });
}

function getMarked() {
  if (typeof marked === 'undefined') return null;
  return marked.marked || marked;
}

function renderMarkdown(md) {
  const api = getMarked();
  if (!api || typeof api.parse !== 'function') {
    return `<pre class="docs-md-fallback">${escapeHtml(md)}</pre>`;
  }
  try {
    if (typeof api.setOptions === 'function') {
      api.setOptions({ gfm: true, breaks: false });
    }
    return api.parse(md);
  } catch (e) {
    return `<pre class="docs-md-fallback">${escapeHtml(md)}</pre>`;
  }
}

async function fetchText(url) {
  const r = await fetch(url, { cache: 'no-store' });
  if (!r.ok) throw new Error(`${r.status} ${url}`);
  return r.text();
}

async function loadDoc(id) {
  const item = findItem(id) || findItem('index');
  const loading = document.getElementById('docs-loading');
  const article = document.getElementById('docs-article');
  const err = document.getElementById('docs-error');
  const empty = document.getElementById('docs-no-results');
  if (!item) {
    if (loading) loading.hidden = true;
    if (article) article.hidden = true;
    if (err) {
      err.hidden = false;
      err.textContent = 'Documento não encontrado no catálogo.';
    }
    return;
  }
  currentId = item.id;
  setActiveNav(currentId);
  if (loading) { loading.hidden = false; loading.textContent = `Abrindo ${item.title}…`; }
  if (article) article.hidden = true;
  if (err) err.hidden = true;
  if (empty) empty.classList.remove('is-visible');

  try {
    const path = `/docs/${String(item.path).replace(/\\/g, '/')}`;
    const md = await fetchText(path);
    currentPlain = md;
    const html = renderMarkdown(md);
    if (article) {
      article.innerHTML = `
        <header class="docs-article-head">
          <p class="docs-kicker">${escapeHtml(item.path)}</p>
          <h1 class="docs-article-title">${escapeHtml(item.title)}</h1>
        </header>
        <div class="docs-md-body">${html}</div>`;
      rewriteMdLinks(article);
      article.hidden = false;
    }
    document.title = `${item.title} — SOMOSUM`;
    const q = document.getElementById('docs-search');
    if (q) q.value = '';
    applySearch('');
    window.scrollTo(0, 0);
  } catch (e) {
    if (article) article.hidden = true;
    if (err) {
      err.hidden = false;
      err.innerHTML = `<strong>Falha ao carregar</strong> <code>${escapeHtml(item.path)}</code><br>${escapeHtml(e.message || e)}`;
    }
  } finally {
    if (loading) loading.hidden = true;
  }
}

function applySearch(q) {
  const empty = document.getElementById('docs-no-results');
  const body = document.querySelector('.docs-md-body');
  const article = document.getElementById('docs-article');
  if (!body || !article || article.hidden) return;
  const query = (q || '').trim().toLowerCase();
  if (!query) {
    body.querySelectorAll('.docs-search-hit').forEach((el) => el.classList.remove('docs-search-hit'));
    empty?.classList.remove('is-visible');
    return;
  }
  const match = currentPlain.toLowerCase().includes(query) || body.textContent.toLowerCase().includes(query);
  empty?.classList.toggle('is-visible', !match);
  body.querySelectorAll('h1,h2,h3,h4,p,li').forEach((el) => {
    el.classList.toggle('docs-search-hit', el.textContent.toLowerCase().includes(query));
  });
}

function initSearch() {
  const input = document.getElementById('docs-search');
  if (!input) return;
  input.addEventListener('input', () => applySearch(input.value));
}

async function loadVersion() {
  let ver = window.__SOMOSUM_META__?.version || FALLBACK_VERSION;
  let detail = '';
  try {
    const meta = await fetch('/api/app-meta', { cache: 'no-store' }).then((r) => (r.ok ? r.json() : null));
    if (meta?.version) {
      ver = String(meta.version);
      detail = [meta.build, meta.protocol != null ? `p${meta.protocol}` : '', meta.assetRevision ? `assets ${meta.assetRevision}` : '']
        .filter(Boolean).join(' · ');
    }
  } catch (_) {
    try {
      const raw = (await fetchText('/VERSION')).trim();
      if (raw) ver = raw.split(/\s+/)[0];
    } catch (_) { /* keep fallback */ }
  }
  const el = document.getElementById('docs-version');
  if (el) el.textContent = detail ? `v${ver} · ${detail}` : `v${ver}`;
}

function bindUi() {
  document.getElementById('docs-print')?.addEventListener('click', () => window.print());
  const author = document.getElementById('docs-author');
  if (author) author.textContent = APP_AUTHOR;
  const email = document.getElementById('docs-email');
  if (email) {
    email.href = `mailto:${APP_AUTHOR_EMAIL}`;
    email.textContent = APP_AUTHOR_EMAIL;
  }
  const phone = document.getElementById('docs-phone');
  if (phone) {
    phone.href = `tel:+55${APP_AUTHOR_PHONE}`;
    phone.textContent = formatPhoneBr(APP_AUTHOR_PHONE);
  }
}

async function initDocs() {
  bindUi();
  initSearch();
  try {
    catalog = await fetch('/docs/catalog.json', { cache: 'no-store' }).then((r) => {
      if (!r.ok) throw new Error('catalog.json');
      return r.json();
    });
  } catch (e) {
    const err = document.getElementById('docs-error');
    const loading = document.getElementById('docs-loading');
    if (loading) loading.hidden = true;
    if (err) {
      err.hidden = false;
      err.innerHTML = 'Não foi possível carregar <code>docs/catalog.json</code>. '
        + 'Reinicie o SOMOSUM.exe e abra Documentação pelo Controle ou pela bandeja. '
        + `<small>(${escapeHtml(e?.message || e)})</small>`;
    }
    return;
  }
  const nav = document.getElementById('docs-sidebar-nav');
  if (nav) nav.innerHTML = buildNav();
  await loadVersion();
  await loadDoc(hashId());
  window.addEventListener('hashchange', () => loadDoc(hashId()));
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initDocs);
} else {
  initDocs();
}
