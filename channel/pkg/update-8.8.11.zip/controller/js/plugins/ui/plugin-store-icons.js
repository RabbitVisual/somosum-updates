/**
 * Ícones da Loja — SVG inline (sem lazy-load / sem 404).
 */
const ICON_COLORS = {
  'culto-essencial': '#C45C26',
  'culto-oferta-pix': '#1B7F5A',
  'culto-momentos': '#2F6FED',
  'culto-diario': '#6B5B95',
  'culto-avisos-rodape': '#B8860B',
  'culto-timer-sermao': '#C0392B',
  'culto-versiculo-destaque': '#1A535C',
  'culto-alerta-equipe': '#E67E22',
  'culto-aniversariantes': '#E91E63',
  'culto-agenda-projetor': '#3F51B5',
  'culto-hino-rapido': '#00897B',
  'culto-pedidos-oracao': '#7B1FA2',
  'culto-qr-livre': '#455A64',
  'culto-contagem-abertura': '#C62828',
  'culto-texto-livre': '#546E7A',
  'culto-creditos-equipe': '#6A1B9A',
  'culto-visitantes': '#AD1457',
  'culto-clima-louvor': '#00695C',
  'google-drive-backup': '#4285F4',
};

/** Glyphs simples por plugin (path SVG 24x24). */
const ICON_GLYPHS = {
  'culto-essencial': 'M12 2l2.4 7.2H22l-6 4.4 2.3 7.2L12 16.8 5.7 20.8 8 13.6 2 9.2h7.6z',
  'culto-oferta-pix': 'M4 4h7v7H4V4zm9 0h7v7h-7V4zM4 13h7v7H4v-7zm9 3.5h3V13h-3v3.5zm0 3.5h7v-3h-7v3zm4-3.5h3V13h-3v3.5z',
  'culto-momentos': 'M12 2a10 10 0 100 20 10 10 0 000-20zm1 5v5.2l4 2.4-.8 1.3L11 13V7h2z',
  'culto-diario': 'M5 3h11a2 2 0 012 2v14l-4-2-4 2-4-2-4 2V5a2 2 0 012-2zm2 4h9v2H7V7zm0 4h9v2H7v-2z',
  'culto-avisos-rodape': 'M3 5h18v2H3V5zm0 6h14v2H3v-2zm0 6h10v2H3v-2z',
  'culto-timer-sermao': 'M9 2h6v2H9V2zm3 4a8 8 0 110 16 8 8 0 010-16zm1 3v5l3.5 2-.8 1.3L11 14V9h2z',
  'culto-versiculo-destaque': 'M6 4h5v2H8v3h2.5v2H8v5H6V4zm7 0h5v2h-3v3H17v2h-2v5h-2V4z',
  'culto-alerta-equipe': 'M12 2a7 7 0 017 7v3.3l1.5 2.7H3.5L5 12.3V9a7 7 0 017-7zm-2 17h4a2 2 0 11-4 0z',
  'culto-aniversariantes': 'M12 6c1.1 0 2-.9 2-2 0-.4-.1-.7-.3-1C15.1 3.6 16 4.7 16 6c0 1.1-.9 2-2 2H8c-.6 0-1-.4-1-1s.4-1 1-1h4zm-1 3h2v2h3v2h-3v2h-2v-2H8v-2h3V9zm-7 5c0-2.8 4.5-4.2 8-4.2s8 1.4 8 4.2V20H4v-6z',
  'culto-agenda-projetor': 'M7 2h2v2h6V2h2v2h3v16H4V4h3V2zm11 6H6v10h12V8zm-9 2h2v2H9v-2zm4 0h2v2h-2v-2zm4 0h2v2h-2v-2z',
  'culto-hino-rapido': 'M9 3v10.5A3.5 3.5 0 116.5 10H8V3h1zm7 0v8.5A3.5 3.5 0 1113.5 8H15V3h1z',
  'culto-pedidos-oracao': 'M12 21s-7-4.4-7-10a4 4 0 017-2.6A4 4 0 0119 11c0 5.6-7 10-7 10z',
  'culto-qr-livre': 'M3 3h8v8H3V3zm2 2v4h4V5H5zm8-2h8v8h-8V3zm2 2v4h4V5h-4zM3 13h8v8H3v-8zm2 2v4h4v-4H5zm10 0h2v2h-2v-2zm4 0h2v2h-2v-2zm-4 4h2v2h-2v-2zm4 0h2v5h-6v-2h2v-1h2v-2z',
  'culto-contagem-abertura': 'M12 2a10 10 0 100 20 10 10 0 000-20zm1 5v5.2l3.5 2.1-.9 1.4L11 13V7h2z',
  'culto-texto-livre': 'M4 4h16v2H4V4zm0 4h12v2H4V8zm0 4h16v2H4v-2zm0 4h10v2H4v-2z',
  'culto-creditos-equipe': 'M16 11c1.7 0 3-1.3 3-3s-1.3-3-3-3-3 1.3-3 3 1.3 3 3 3zM8 11c1.7 0 3-1.3 3-3S9.7 5 8 5 5 6.3 5 8s1.3 3 3 3zm0 2c-2.7 0-8 1.3-8 4v2h10v-2c0-1.5.7-2.7 2-3.5C10.6 13.2 9.2 13 8 13zm8 0c-.3 0-.7 0-1 .1 1.5.8 2.5 2.1 2.5 3.9v2H24v-2c0-2.7-5.3-4-8-4z',
  'culto-visitantes': 'M12 21s-7-4.4-7-10a4 4 0 017-2.6A4 4 0 0119 11c0 5.6-7 10-7 10z',
  'culto-clima-louvor': 'M9 3v10.5A3.5 3.5 0 116.5 10H8V3h1zm7 0v8.5A3.5 3.5 0 1113.5 8H15V3h1z',
  'google-drive-backup': 'M6.5 15.5L12 5l5.5 10.5H6.5zM4 17h7l-2 3H2l2-3zm9 0h7l2 3h-7l-2-3z',
};

function escAttr(t) {
  return String(t ?? '')
    .replace(/&/g, '&amp;')
    .replace(/"/g, '&quot;')
    .replace(/</g, '&lt;');
}

function letterOf(plug) {
  return String(plug?.name || plug?.id || '?').trim().slice(0, 1).toUpperCase() || '?';
}

function colorOf(plug) {
  return ICON_COLORS[plug?.id] || '#C45C26';
}

/**
 * Ícone sempre local (SVG) — evita Intervention de lazy-load e 404.
 * @param {object} plug
 * @param {{ sizeClass?: string }} [opts]
 */
export function pluginStoreIconHtml(plug, { sizeClass = '' } = {}) {
  const color = colorOf(plug);
  const glyph = ICON_GLYPHS[plug?.id];
  const letter = letterOf(plug);
  const inner = glyph
    ? `<svg class="ps-icon-svg" viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="${glyph}"/></svg>`
    : `<span class="ps-icon-letter" aria-hidden="true">${escAttr(letter)}</span>`;

  return `
    <span class="ps-icon ${sizeClass}" style="--ps-icon-accent:${color}" data-ps-icon="${escAttr(plug?.id || '')}" title="${escAttr(plug?.name || '')}">
      ${inner}
    </span>`;
}

export function pluginFeatureChips(capabilities = []) {
  const labels = {
    'host.control': 'Controle ao vivo',
    'ui.settings': 'Configurações',
    'ui.nav': 'Menu lateral',
    'ui.view': 'Tela do Studio',
    prefs: 'Preferências salvas',
    'slide.mutate': 'Altera slides',
    'remote.action': 'Ações no Remote',
    'stage.layout': 'Tela do Púlpito',
    'ui.toolbar': 'Botões rápidos',
    'command.palette': 'Atalhos',
    'bus.command': 'Sincroniza telas',
  };
  return (capabilities || [])
    .map((c) => labels[c])
    .filter(Boolean)
    .filter((v, i, a) => a.indexOf(v) === i)
    .slice(0, 8);
}
