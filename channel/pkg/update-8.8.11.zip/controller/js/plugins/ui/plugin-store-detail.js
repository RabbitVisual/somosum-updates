/**
 * Drawer de detalhe — Loja de Plugins (ações sempre visíveis).
 */
import { faIconRaw } from '../../core/fa-icons.js';
import { openPluginStudio } from '../studio/register-plugin-studio.js';
import {
  formatPackSize,
  formatPluginPackError,
  getPluginInstallState,
  installPluginPack,
  updatePluginPack,
  uninstallPluginPack,
} from '../plugin-pack-service.js';
import { pluginFeatureChips, pluginStoreIconHtml } from './plugin-store-icons.js';

function esc(t) {
  const d = document.createElement('div');
  d.textContent = t ?? '';
  return d.innerHTML;
}

function phaseLabel(phase, pct) {
  if (phase === 'download') return `Baixando… ${pct}%`;
  if (phase === 'extract') return `Instalando… ${pct}%`;
  if (phase === 'activate') return 'Ativando…';
  if (phase === 'remove') return 'Removendo…';
  if (phase === 'reload') return 'Atualizando menus…';
  if (phase === 'done') return 'Concluído';
  return 'Preparando…';
}

function categoryLabel(cat) {
  const map = { culto: 'Culto', equipe: 'Equipe', 'projeção': 'Projeção', projecao: 'Projeção', utilidades: 'Utilidades' };
  return map[cat] || String(cat || 'Plugin');
}

function pricingBadgeHtml(plug) {
  const p = plug?.pricing || {};
  // Só mostra preço quando for realmente pago. Nada de SKU, “em breve”, promo interna.
  if (p.model === 'paid' && p.priceDisplay) {
    return `<span class="ps-badge ps-badge--paid">${esc(p.priceDisplay)}</span>`;
  }
  return '';
}

function hasStudio(plug) {
  const caps = plug?.capabilities || [];
  return caps.includes('ui.nav') && caps.includes('ui.view');
}

function tagsHtml(tags) {
  if (!tags?.length) return '';
  return `<div class="ps-chip-row">${tags.map((t) => `<span class="ps-chip ps-chip--tag">${esc(t)}</span>`).join('')}</div>`;
}

function featuresHtml(plug) {
  const chips = pluginFeatureChips(plug.capabilities);
  if (!chips.length) return '';
  return `
    <section class="ps-drawer-section">
      <h3>O que inclui</h3>
      <div class="ps-chip-row">${chips.map((c) => `<span class="ps-chip">${esc(c)}</span>`).join('')}</div>
    </section>`;
}

/**
 * @param {object} opts
 */
export function openPluginStoreDetail({ plug, state: initialState, app, onClose, onChanged }) {
  document.getElementById('plugin-store-detail')?.remove();

  let state = { ...initialState };

  const overlay = document.createElement('div');
  overlay.className = 'ps-drawer-overlay';
  overlay.id = 'plugin-store-detail';
  document.body.appendChild(overlay);

  const close = () => {
    overlay.remove();
    document.removeEventListener('keydown', onKey);
    onClose?.();
  };

  const onKey = (e) => {
    if (e.key === 'Escape') close();
  };
  document.addEventListener('keydown', onKey);

  overlay.addEventListener('click', (e) => {
    if (e.target === overlay) close();
  });

  const render = () => {
    const studio = hasStudio(plug);
    let primary = 'install';
    let primaryLabel = 'Instalar';
    if (state.installed && state.updateAvailable) {
      primary = 'update';
      primaryLabel = `Atualizar para v${plug.version}`;
    } else if (state.installed) {
      primary = 'none';
      primaryLabel = 'Instalado';
    }

    overlay.innerHTML = `
      <aside class="ps-drawer" role="dialog" aria-modal="true" aria-labelledby="ps-detail-title">
        <button type="button" class="ps-drawer-close" aria-label="Fechar">${faIconRaw('xmark', 'su-fa')}</button>

        <div class="ps-drawer-banner" aria-hidden="true">
          <div class="ps-drawer-banner-glow"></div>
        </div>

        <div class="ps-drawer-scroll">
          <header class="ps-drawer-head">
            ${pluginStoreIconHtml(plug, { sizeClass: 'ps-icon--xl' })}
            <div class="ps-drawer-titles">
              <p class="ps-kicker">${esc(plug.publisher || plug.author || 'SOMOSUM')} · ${esc(categoryLabel(plug.category))}</p>
              <h2 id="ps-detail-title">${esc(plug.name)}</h2>
              <p class="ps-drawer-tagline">${esc(plug.tagline || plug.description)}</p>
              <div class="ps-drawer-meta">
                <span>Versão ${esc(state.catalogVersion || plug.version)}</span>
                <span>${esc(formatPackSize(plug.bytes))}</span>
                ${pricingBadgeHtml(plug)}
                ${state.installed
                  ? `<span class="ps-meta-ok">Já instalado</span>`
                  : '<span>Ainda não instalado</span>'}
                ${state.updateAvailable ? '<span class="ps-meta-warn">Há novidade</span>' : ''}
              </div>
            </div>
          </header>

          ${state.quarantined ? '<p class="ps-alert ps-alert--warn" role="alert">Este recurso está pausado — reative em Ajustes → Plugins.</p>' : ''}
          ${state.lastError ? `<p class="ps-alert ps-alert--warn" role="alert">Erro: ${esc(state.lastError.message || state.lastError)}</p>` : ''}

          <section class="ps-drawer-section">
            <h3>Sobre</h3>
            <p>${esc(plug.longDescription || plug.description)}</p>
          </section>

          <section class="ps-drawer-section">
            <h3>Como usar</h3>
            <p>${esc(plug.howTo || 'Instale, depois abra pelo menu do Controle ou em Ajustes → Plugins.')}</p>
          </section>

          ${(state.updateAvailable || !state.installed) && plug.changelog ? `
          <section class="ps-drawer-section">
            <h3>Novidades</h3>
            <p>${esc(plug.changelog)}</p>
          </section>` : ''}
        </div>

        <div class="ps-drawer-progress" hidden aria-live="polite">
          <div class="ps-drawer-progress-bar"><span></span></div>
          <span class="ps-drawer-progress-label"></span>
        </div>

        <footer class="ps-drawer-actions">
          ${primary === 'install' ? `<button type="button" class="ps-btn ps-btn--primary ps-btn--lg" data-ps-action="install">${primaryLabel}</button>` : ''}
          ${primary === 'update' ? `<button type="button" class="ps-btn ps-btn--primary ps-btn--lg" data-ps-action="update">${esc(primaryLabel)}</button>` : ''}
          ${primary === 'none' ? `<span class="ps-badge ps-badge--ok">${faIconRaw('check', 'su-fa')} Instalado</span>` : ''}
          ${studio && state.installed && state.enabled !== false
            ? `<button type="button" class="ps-btn ps-btn--secondary" data-ps-action="studio">Abrir Studio</button>`
            : ''}
          ${state.installed
            ? `<button type="button" class="ps-btn ps-btn--ghost" data-ps-action="settings">Ajustes</button>`
            : ''}
          ${state.installed
            ? `<button type="button" class="ps-btn ps-btn--danger" data-ps-action="uninstall">Desinstalar</button>`
            : `<button type="button" class="ps-btn ps-btn--ghost" data-ps-action="close">Fechar</button>`}
        </footer>
      </aside>`;

    bindActions();
  };

  const setProgress = (phase, pct = 0) => {
    const prog = overlay.querySelector('.ps-drawer-progress');
    const bar = overlay.querySelector('.ps-drawer-progress-bar span');
    const label = overlay.querySelector('.ps-drawer-progress-label');
    if (!prog || !bar || !label) return;
    prog.hidden = false;
    label.textContent = phaseLabel(phase, pct);
    const w = phase === 'download' ? Math.max(6, pct * 0.4)
      : phase === 'extract' ? 40 + pct * 0.35
      : phase === 'activate' ? 80 + pct * 0.15
      : phase === 'remove' ? 30 + pct * 0.4
      : phase === 'reload' ? 75
      : 100;
    bar.style.width = `${w}%`;
  };

  const bindActions = () => {
    overlay.querySelector('.ps-drawer-close')?.addEventListener('click', close);
    overlay.querySelector('[data-ps-action="close"]')?.addEventListener('click', close);

    const run = async (action) => {
      overlay.querySelectorAll('[data-ps-action]').forEach((b) => { b.disabled = true; });
      try {
        if (action === 'install') {
          await installPluginPack(plug.id, { onProgress: setProgress });
          app?.toast?.(`“${plug.name}” instalado`, 'success');
          state = await getPluginInstallState(plug.id, plug);
          setProgress('done', 100);
          onChanged?.();
          render();
          return;
        }
        if (action === 'update') {
          if (plug.changelog && !confirm(`Atualizar “${plug.name}” para v${plug.version}?\n\n${plug.changelog}`)) {
            overlay.querySelectorAll('[data-ps-action]').forEach((b) => { b.disabled = false; });
            return;
          }
          await updatePluginPack(plug.id, { onProgress: setProgress });
          app?.toast?.(`Atualizado para v${plug.version}`, 'success');
          state = await getPluginInstallState(plug.id, plug);
          onChanged?.();
          render();
          return;
        }
        if (action === 'uninstall') {
          if (!confirm(`Desinstalar “${plug.name}”?\n\nRemove o recurso deste PC.`)) {
            overlay.querySelectorAll('[data-ps-action]').forEach((b) => { b.disabled = false; });
            return;
          }
          await uninstallPluginPack(plug.id, { onProgress: setProgress });
          app?.toast?.('Removido', 'success');
          onChanged?.();
          close();
          return;
        }
        if (action === 'studio') {
          if (typeof app?.setView === 'function' && openPluginStudio(app, plug.id)) {
            close();
          } else {
            app?.toast?.('Abra o Controle para usar o Studio', 'info');
            try {
              if (typeof app?.openControl === 'function') app.openControl();
              else window.Engine?.shell?.openControl?.();
            } catch { /* ignore */ }
            close();
          }
          return;
        }
        if (action === 'settings') {
          try {
            if (typeof app?.openControl === 'function') app.openControl();
            else window.Engine?.shell?.openControl?.();
            try { location.hash = 'settings-plugins'; } catch { /* ignore */ }
            app?.toast?.('No Controle: Ajustes → Plugins', 'info');
          } catch {
            app?.toast?.('Abra Ajustes → Plugins no Controle', 'info');
          }
          close();
        }
      } catch (err) {
        app?.toast?.(formatPluginPackError(err), 'error');
        const prog = overlay.querySelector('.ps-drawer-progress');
        if (prog) prog.hidden = true;
        overlay.querySelectorAll('[data-ps-action]').forEach((b) => { b.disabled = false; });
      }
    };

    overlay.querySelectorAll('[data-ps-action]').forEach((btn) => {
      if (btn.dataset.psAction === 'close') return;
      btn.addEventListener('click', () => void run(btn.dataset.psAction));
    });
  };

  render();
}
