/**
 * Mini unzip (store + deflate via DecompressionStream when available) for plugin packages.
 */
function inflateRaw(data) {
  // Prefer DecompressionStream (Chromium/WebView2)
  if (typeof DecompressionStream === 'undefined') {
    throw new Error('ZIP com compressão não suportado neste ambiente');
  }
  // Use sync-ish path via temporary — actually DS is async. For install we need sync or async.
  return null;
}

async function inflateRawAsync(data) {
  if (typeof DecompressionStream === 'undefined') {
    throw new Error('Deflate ZIP requer WebView2 recente');
  }
  const ds = new DecompressionStream('deflate-raw');
  const blob = new Blob([data]);
  const stream = blob.stream().pipeThrough(ds);
  const ab = await new Response(stream).arrayBuffer();
  return new Uint8Array(ab);
}

function parseLocalFiles(data) {
  const view = new DataView(data.buffer, data.byteOffset, data.byteLength);
  const entries = [];
  let offset = 0;
  while (offset < data.length - 4) {
    if (view.getUint32(offset, true) !== 0x04034b50) break;
    const compMethod = view.getUint16(offset + 8, true);
    const compSize = view.getUint32(offset + 18, true);
    const nameLen = view.getUint16(offset + 26, true);
    const extraLen = view.getUint16(offset + 28, true);
    const nameStart = offset + 30;
    const name = new TextDecoder().decode(data.subarray(nameStart, nameStart + nameLen));
    const dataStart = nameStart + nameLen + extraLen;
    const chunk = data.subarray(dataStart, dataStart + compSize);
    entries.push({ name, compMethod, chunk });
    offset = dataStart + compSize;
  }
  return entries;
}

function toBase64(u8) {
  let s = '';
  const chunk = 0x8000;
  for (let i = 0; i < u8.length; i += chunk) {
    s += String.fromCharCode(...u8.subarray(i, i + chunk));
  }
  return btoa(s);
}

/**
 * @param {Uint8Array} data
 * @returns {Promise<{ id: string, files: Record<string, any>, meta: object }>}
 */
export async function unzipPluginPackage(data) {
  const entries = parseLocalFiles(data);
  if (!entries.length) throw new Error('ZIP vazio ou inválido');

  const decoded = {};
  for (const e of entries) {
    if (e.name.endsWith('/')) continue;
    let bytes = e.chunk;
    if (e.compMethod === 8) {
      bytes = await inflateRawAsync(e.chunk);
    } else if (e.compMethod !== 0) {
      throw new Error(`Método ZIP ${e.compMethod} não suportado`);
    }
    decoded[e.name.replace(/\\/g, '/')] = bytes;
  }

  // Find plugin root: .../manifest.json or .../plugin.js
  let root = '';
  let id = '';
  for (const name of Object.keys(decoded)) {
    const m = name.match(/(?:^|\/)(?:data\/)?plugins\/([a-z0-9-]+)\/(?:manifest\.json|plugin\.js)$/);
    if (m) {
      id = m[1];
      root = name.replace(/\/(?:manifest\.json|plugin\.js)$/, '');
      break;
    }
    const flat = name.match(/^([a-z0-9-]+)\/(?:manifest\.json|plugin\.js)$/);
    if (flat) {
      id = flat[1];
      root = flat[1];
      break;
    }
    if (name === 'plugin.js' || name === 'manifest.json') {
      // need id from manifest
    }
  }

  let manifest = null;
  for (const [name, bytes] of Object.entries(decoded)) {
    if (name.endsWith('manifest.json')) {
      try {
        manifest = JSON.parse(new TextDecoder().decode(bytes));
        if (!id && manifest.id) id = manifest.id;
        if (!root) root = name.replace(/\/?manifest\.json$/, '');
      } catch { /* ignore */ }
    }
  }
  if (!id?.match(/^[a-z0-9-]+$/)) throw new Error('manifest.id inválido no ZIP');

  const files = {};
  const prefix = root ? `${root}/` : '';
  for (const [name, bytes] of Object.entries(decoded)) {
    let rel = name;
    if (prefix && name.startsWith(prefix)) rel = name.slice(prefix.length);
    else if (name.startsWith(`plugins/${id}/`)) rel = name.slice(`plugins/${id}/`.length);
    else if (name.startsWith(`data/plugins/${id}/`)) rel = name.slice(`data/plugins/${id}/`.length);
    if (!rel || rel.includes('..')) continue;
    const full = `plugins/${id}/${rel}`;
    const isText = /\.(js|json|css|svg|txt|md)$/i.test(rel);
    if (isText) {
      files[full] = new TextDecoder().decode(bytes);
    } else {
      files[full] = { encoding: 'base64', data: toBase64(bytes) };
    }
  }

  if (!files[`plugins/${id}/plugin.js`]) {
    throw new Error('ZIP sem plugin.js');
  }

  const meta = {
    name: manifest?.name || id,
    description: manifest?.description || '',
    version: manifest?.version || '1.0.0',
    hooks: manifest?.hooks || ['activate', 'deactivate'],
    author: manifest?.author || '',
  };

  return { id, files, meta };
}

// silence unused
void inflateRaw;
