/**
 * Preferências de plugins — disco SSOT (prefs.json) + cache localStorage.
 * Probe por plugin (não kill-switch global).
 */
import { dataPublicUrl } from '../core/data-public-url.js';
import { FileManager } from '../core/storage/files/file-manager.js';

const memoryCache = new Map();
/** id -> true|false|null (unknown) */
const diskOkByPlugin = new Map();

function lsKey(id) {
  return `somosum-plugin:${id}`;
}

export function readPluginPrefs(id, defaults = {}) {
  if (memoryCache.has(id)) {
    return { ...defaults, ...memoryCache.get(id) };
  }
  try {
    const raw = localStorage.getItem(lsKey(id));
    if (!raw) return { ...defaults };
    const parsed = JSON.parse(raw);
    const obj = parsed && typeof parsed === 'object' ? parsed : {};
    memoryCache.set(id, obj);
    return { ...defaults, ...obj };
  } catch {
    return { ...defaults };
  }
}

export function writePluginPrefs(id, patch) {
  const next = { ...readPluginPrefs(id), ...patch };
  memoryCache.set(id, next);
  try {
    localStorage.setItem(lsKey(id), JSON.stringify(next));
  } catch { /* ignore */ }
  void flushPrefsToDisk(id);
  return next;
}

export async function syncPrefsFromDisk(id) {
  if (diskOkByPlugin.get(id) === false) return readPluginPrefs(id);
  try {
    const res = await fetch(dataPublicUrl(`plugins/${id}/prefs.json`), { cache: 'no-store' });
    if (res.status === 403) {
      diskOkByPlugin.set(id, false);
      return readPluginPrefs(id);
    }
    if (!res.ok) {
      // 404 = ok to try writes later
      diskOkByPlugin.set(id, res.status !== 403);
      return readPluginPrefs(id);
    }
    diskOkByPlugin.set(id, true);
    const data = await res.json();
    if (data && typeof data === 'object') {
      memoryCache.set(id, data);
      try { localStorage.setItem(lsKey(id), JSON.stringify(data)); } catch { /* */ }
      return data;
    }
  } catch { /* ignore */ }
  return readPluginPrefs(id);
}

export async function flushPrefsToDisk(id) {
  if (diskOkByPlugin.get(id) === false) {
    return memoryCache.get(id) || readPluginPrefs(id);
  }
  const data = memoryCache.get(id) || readPluginPrefs(id);
  try {
    const ok = await FileManager.saveJson(`plugins/${id}/prefs.json`, data, `plugin:${id}:prefs`);
    diskOkByPlugin.set(id, !!ok);
  } catch {
    diskOkByPlugin.set(id, false);
  }
  return data;
}

const commandHandlers = new Map();

export function registerPluginCommand(action, handler) {
  if (!action || typeof handler !== 'function') return;
  commandHandlers.set(String(action), handler);
}

export function unregisterPluginCommand(action) {
  commandHandlers.delete(String(action));
}

export function runPluginCommand(action, ctx = {}) {
  const fn = commandHandlers.get(String(action));
  if (!fn) return false;
  try {
    fn(ctx);
    return true;
  } catch (err) {
    console.warn('[plugin-cmd]', action, err);
    return false;
  }
}

export function listPluginCommands() {
  return [...commandHandlers.keys()];
}

export function clearPluginCommands() {
  commandHandlers.clear();
}

const configRegistry = new Map();

export function registerPluginConfig(id, meta = {}) {
  if (!id) return;
  configRegistry.set(String(id), {
    id: String(id),
    title: meta.title || id,
    howTo: meta.howTo || '',
    openLabel: meta.openLabel || 'Configurar',
    open: typeof meta.open === 'function' ? meta.open : null,
  });
}

export function unregisterPluginConfig(id) {
  configRegistry.delete(String(id));
}

export function getPluginConfig(id) {
  return configRegistry.get(String(id)) || null;
}

export function listPluginConfigs() {
  return [...configRegistry.values()];
}

export function clearPluginConfigs() {
  configRegistry.clear();
}

/** Painéis recebem host facade (passado pelo PluginAPI), não ControlApp. */
export function openPluginConfig(id, hostOrApp) {
  const meta = getPluginConfig(id);
  if (!meta?.open) return false;
  try {
    meta.open(hostOrApp);
    return true;
  } catch (err) {
    console.warn('[plugin-config]', id, err);
    return false;
  }
}
