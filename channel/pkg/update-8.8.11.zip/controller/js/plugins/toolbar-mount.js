/**
 * Mount plugin toolbar contributions into a host element.
 */
import { listContributions, onContributionsChanged } from './contributions.js';
import { esc, escAttr } from '../core/render-engine/index.js';

export function mountPluginToolbar(host, slot, app, { className = 'btn btn-secondary btn-sm' } = {}) {
  if (!host) return () => {};
  const render = () => {
    const items = listContributions('toolbar').filter((t) => (t.slot || 'program-culto-bar') === slot);
    let wrap = host.querySelector(`[data-plugin-toolbar="${CSS.escape(slot)}"]`);
    if (!wrap) {
      wrap = document.createElement('span');
      wrap.className = 'plugin-toolbar-slot';
      wrap.dataset.pluginToolbar = slot;
      host.appendChild(wrap);
    }
    wrap.innerHTML = items.map((t) => `
      <button type="button" class="${className}" data-plugin-tb="${escAttr(t.id)}" title="${escAttr(t.title || t.label || '')}">
        ${esc(t.label || t.id)}
      </button>`).join('');
    wrap.querySelectorAll('[data-plugin-tb]').forEach((btn) => {
      btn.onclick = () => {
        const item = items.find((i) => i.id === btn.dataset.pluginTb);
        try { item?.run?.({ app, host: app }); } catch (err) { console.warn('[plugin-toolbar]', err); }
      };
    });
  };
  render();
  return onContributionsChanged((kind) => {
    if (kind === 'toolbar' || kind === '*') render();
  });
}
