/**
 * Config schema — painel compartilhado Ajustes → Plugins.
 */
import { esc, escAttr } from '../core/render-engine/index.js';

/**
 * @param {Record<string, object>} schema
 * @param {Record<string, any>} values
 * @param {{ idPrefix?: string }} opts
 */
export function renderConfigForm(schema, values = {}, opts = {}) {
  if (!schema || typeof schema !== 'object') return '';
  const prefix = opts.idPrefix || 'plugin-cfg';
  const fields = Object.entries(schema).map(([key, def]) => {
    if (!def || typeof def !== 'object') return '';
    const type = def.type || 'text';
    const label = def.label || key;
    const hint = def.hint || '';
    const val = values[key] !== undefined ? values[key] : def.default;
    const fid = `${prefix}-${key}`;
    if (type === 'boolean') {
      return `<label class="plugin-cfg-field plugin-cfg-field--check">
        <input type="checkbox" id="${escAttr(fid)}" data-cfg-key="${escAttr(key)}" ${val ? 'checked' : ''}/>
        <span>${esc(label)}</span>
      </label>${hint ? `<p class="form-hint">${esc(hint)}</p>` : ''}`;
    }
    if (type === 'select' && Array.isArray(def.options)) {
      const optsHtml = def.options.map((o) => {
        const v = typeof o === 'object' ? o.value : o;
        const l = typeof o === 'object' ? (o.label || o.value) : o;
        return `<option value="${escAttr(String(v))}" ${String(val) === String(v) ? 'selected' : ''}>${esc(String(l))}</option>`;
      }).join('');
      return `<label class="plugin-cfg-field" for="${escAttr(fid)}">${esc(label)}
        <select id="${escAttr(fid)}" data-cfg-key="${escAttr(key)}" class="su-select">${optsHtml}</select>
      </label>${hint ? `<p class="form-hint">${esc(hint)}</p>` : ''}`;
    }
    if (type === 'number') {
      return `<label class="plugin-cfg-field" for="${escAttr(fid)}">${esc(label)}
        <input type="number" id="${escAttr(fid)}" data-cfg-key="${escAttr(key)}" class="su-input"
          value="${escAttr(val ?? '')}" min="${escAttr(def.min ?? '')}" max="${escAttr(def.max ?? '')}" step="${escAttr(def.step ?? '1')}"/>
      </label>${hint ? `<p class="form-hint">${esc(hint)}</p>` : ''}`;
    }
    if (type === 'textarea') {
      return `<label class="plugin-cfg-field" for="${escAttr(fid)}">${esc(label)}
        <textarea id="${escAttr(fid)}" data-cfg-key="${escAttr(key)}" class="su-input" rows="${def.rows || 3}">${esc(val ?? '')}</textarea>
      </label>${hint ? `<p class="form-hint">${esc(hint)}</p>` : ''}`;
    }
    return `<label class="plugin-cfg-field" for="${escAttr(fid)}">${esc(label)}
      <input type="text" id="${escAttr(fid)}" data-cfg-key="${escAttr(key)}" class="su-input" value="${escAttr(val ?? '')}"/>
    </label>${hint ? `<p class="form-hint">${esc(hint)}</p>` : ''}`;
  });
  return `<div class="plugin-cfg-form">${fields.filter(Boolean).join('')}</div>`;
}

/** Lê valores do form montado por renderConfigForm. */
export function readConfigForm(root, schema) {
  if (!root || !schema) return {};
  const out = {};
  for (const key of Object.keys(schema)) {
    const el = root.querySelector(`[data-cfg-key="${CSS.escape(key)}"]`);
    if (!el) continue;
    const def = schema[key] || {};
    if (def.type === 'boolean') out[key] = !!el.checked;
    else if (def.type === 'number') {
      const n = Number(el.value);
      out[key] = Number.isFinite(n) ? n : def.default;
    } else out[key] = el.value;
  }
  return out;
}

export function defaultsFromSchema(schema) {
  const out = {};
  if (!schema || typeof schema !== 'object') return out;
  for (const [key, def] of Object.entries(schema)) {
    if (def && typeof def === 'object' && 'default' in def) out[key] = def.default;
  }
  return out;
}
