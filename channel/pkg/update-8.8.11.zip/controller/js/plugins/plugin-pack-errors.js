const MESSAGES = {
  manifest_fetch_404: 'Catálogo de plugins não encontrado. Reinstale ou verifique model/content/packs/plugins/.',
  manifest_fetch_failed: 'Não foi possível carregar o catálogo de plugins.',
  pack_not_found: 'Pacote não encontrado no disco.',
  hash_mismatch: 'Verificação de integridade falhou (SHA256). Baixe o pacote novamente.',
  already_installed: 'Este plugin já está instalado. Use Atualizar se houver nova versão.',
  not_installed: 'Plugin não instalado.',
  update_failed_rollback: 'Atualização falhou — versão anterior restaurada automaticamente.',
  install_failed: 'Falha ao instalar o plugin.',
  uninstall_failed: 'Falha ao desinstalar o plugin.',
  incompatible_host: 'Plugin incompatível com esta versão do SOMOSUM.',
  network_offline: 'Sem conexão — usando catálogo local.',
  plugin_unavailable: 'Este plugin ainda não está disponível na Loja.',
};

export function isOnline() {
  return typeof navigator !== 'undefined' ? navigator.onLine !== false : true;
}

export function formatPluginPackError(err) {
  const raw = String(err?.message || err || '');
  for (const [key, msg] of Object.entries(MESSAGES)) {
    if (raw.includes(key)) return msg;
  }
  if (raw.startsWith('install_failed') || raw.startsWith('update_failed')) {
    return raw.split(':').slice(1).join(':').trim() || MESSAGES.install_failed;
  }
  return raw || 'Erro desconhecido ao processar plugin.';
}
