/**
 * Prévia 16:9 local do projetor (Plugin Studio) — não envia ao projetor real.
 */
import { prepareSlideWithPlugins } from '../slide-plugins.js';
import { renderPreview } from '../../slides/slide-engine.js';
import { refitStagePreviewContainer } from '../../ui/stage-preview-fit.js';
import { rawHtml, setHtml } from '../../core/render-engine/index.js';

function prepSlide(slide, app) {
  if (!slide) return null;
  const base = { ...slide };
  if (slide.style && typeof slide.style === 'object') base.style = { ...slide.style };
  if (slide.data && typeof slide.data === 'object') base.data = { ...slide.data };
  if (slide.pix && typeof slide.pix === 'object') base.pix = { ...slide.pix };
  return prepareSlideWithPlugins(base, app);
}

export function renderProjectorPreviewHtml(slide, app) {
  const prepared = prepSlide(slide, app);
  if (!prepared) {
    return '<p class="plugin-studio-preview-empty">Sem slide para prévia</p>';
  }
  const defaults = app?.defaults || {};
  const prefs = app?.prefs || {};
  const assets = app?.getAssetUrls?.() || {};
  return renderPreview(prepared, defaults, prefs, assets);
}

export function mountProjectorPreview(container, slide, app) {
  if (!container) return;
  setHtml(container, rawHtml(renderProjectorPreviewHtml(slide, app)));
  refitStagePreviewContainer(container);
  if (!container._studioFitObs && typeof ResizeObserver !== 'undefined') {
    container._studioFitObs = new ResizeObserver(() => refitStagePreviewContainer(container));
    container._studioFitObs.observe(container);
  }
}

export function updateProjectorPreview(container, slide, app) {
  mountProjectorPreview(container, slide, app);
}
