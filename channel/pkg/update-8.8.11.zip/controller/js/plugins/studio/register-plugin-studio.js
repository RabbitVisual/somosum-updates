/**
 * Registra Plugin Studio — nav lateral + view dedicada + open() → setView.
 */
import { CAPABILITIES } from '../plugin-api.js';

export const STUDIO_VIEW_ID = 'studio';

export function pluginStudioViewId(pluginId) {
  return `plugin:${pluginId}:${STUDIO_VIEW_ID}`;
}

export function isPluginStudioView(view, pluginId) {
  if (!view) return false;
  if (pluginId) return view === pluginStudioViewId(pluginId);
  return String(view).startsWith('plugin:') && String(view).endsWith(`:${STUDIO_VIEW_ID}`);
}

export function openPluginStudio(app, pluginId) {
  const viewId = pluginStudioViewId(pluginId);
  if (app?.setView) {
    app.setView(viewId);
    return true;
  }
  return false;
}

/**
 * @param {object} api — PluginAPI
 * @param {{
 *   iconKey: string,
 *   label: string,
 *   title?: string,
 *   hint?: string,
 *   order?: number,
 *   howTo?: string,
 *   openLabel?: string,
 *   renderStudio: (root: HTMLElement, app: object) => void | Promise<void>,
 * }} opts
 */
export function registerPluginStudio(api, opts) {
  const pluginId = api.id;
  const viewId = pluginStudioViewId(pluginId);
  const caps = api.capabilities || [];

  if (!caps.includes(CAPABILITIES.UI_NAV) && !caps.includes('ui.nav')) {
    console.warn(`[plugin-studio] ${pluginId} sem ui.nav`);
  }
  if (!caps.includes(CAPABILITIES.UI_VIEW) && !caps.includes('ui.view')) {
    console.warn(`[plugin-studio] ${pluginId} sem ui.view`);
  }

  api.ui.contributeView({
    viewId: STUDIO_VIEW_ID,
    render(root, app) {
      root.innerHTML = '<p class="form-hint plugin-studio-loading">Carregando Studio…</p>';
      try {
        const out = opts.renderStudio(root, app);
        if (out && typeof out.then === 'function') {
          out.catch((err) => {
            root.innerHTML = `<p class="form-hint">Erro ao abrir Studio: ${String(err?.message || err)}</p>`;
          });
        }
      } catch (err) {
        root.innerHTML = `<p class="form-hint">Erro ao abrir Studio: ${String(err?.message || err)}</p>`;
      }
    },
  });

  api.ui.contributeNav({
    viewId,
    label: opts.label || pluginId,
    title: opts.title || opts.label || pluginId,
    hint: opts.hint || 'Configurar plugin',
    iconKey: opts.iconKey || 'puzzle',
    group: 'plugins',
    groupLabel: 'Plugins',
    order: opts.order ?? 100,
  });

  api.ui.registerConfigPanel({
    title: opts.label || pluginId,
    howTo: opts.howTo || '',
    openLabel: opts.openLabel || 'Abrir Studio',
    open: (hostOrApp) => {
      const app = hostOrApp?.setView ? hostOrApp : hostOrApp?._app || hostOrApp;
      if (app?.setView) {
        app.setView(viewId);
        return;
      }
      try {
        hostOrApp?.navigation?.setView?.(viewId);
      } catch { /* ignore */ }
    },
  });

  return { viewId, open: () => openPluginStudio(null, pluginId) };
}
