/**
 * PluginAPI v2 — facade tipada; sem app cru; capabilities estritas.
 */
import {
  contribute,
  removeContribution,
  clearContributionsForPlugin,
  listContributions,
} from './contributions.js';
import {
  readPluginPrefs,
  writePluginPrefs,
  registerPluginCommand,
  unregisterPluginCommand,
  registerPluginConfig,
  unregisterPluginConfig,
} from './plugin-prefs.js';
import { defaultsFromSchema } from './config-schema.js';

export const PLUGIN_API_VERSION = 2;

export const CAPABILITIES = Object.freeze({
  UI_NAV: 'ui.nav',
  UI_TOOLBAR: 'ui.toolbar',
  UI_SETTINGS: 'ui.settings',
  UI_VIEW: 'ui.view',
  SLIDE_MUTATE: 'slide.mutate',
  BUS_COMMAND: 'bus.command',
  BUS_SEND: 'bus.send',
  PREFS: 'prefs',
  COMMAND_PALETTE: 'command.palette',
  REMOTE_ACTION: 'remote.action',
  STAGE_LAYOUT: 'stage.layout',
  TEMPLATE_REGISTER: 'template.register',
  HOST_CONTROL: 'host.control',
});

const CAP_SET = new Set(Object.values(CAPABILITIES));

/** Default mínimo — não libera tudo. */
const DEFAULT_CAPABILITIES = Object.freeze([
  CAPABILITIES.PREFS,
  CAPABILITIES.UI_SETTINGS,
]);

/** Hook name → required capability */
export const HOOK_CAPABILITIES = Object.freeze({
  'slide:render': CAPABILITIES.SLIDE_MUTATE,
  'template:register': CAPABILITIES.TEMPLATE_REGISTER,
  'program:beforeSave': CAPABILITIES.HOST_CONTROL,
  'bible:passage': CAPABILITIES.HOST_CONTROL,
  'remote:actions': CAPABILITIES.REMOTE_ACTION,
  'stage:layout': CAPABILITIES.STAGE_LAYOUT,
});

export function normalizeCapabilities(list) {
  if (!Array.isArray(list) || !list.length) {
    return new Set(DEFAULT_CAPABILITIES);
  }
  return new Set(list.filter((c) => CAP_SET.has(c)));
}

export function isKnownCapability(cap) {
  return CAP_SET.has(cap);
}

export function detectSurface() {
  try {
    const s = document.body?.dataset?.surface;
    if (s) return s;
  } catch { /* ignore */ }
  const path = (typeof location !== 'undefined' ? location.pathname : '') || '';
  if (path.includes('remote')) return 'remote';
  if (path.includes('stage')) return 'stage';
  if (path.includes('screen')) return 'screen';
  return 'control';
}

/**
 * Capabilities relevantes por superfície (activate scoped).
 */
export function surfaceAllowsContribution(surface, kind) {
  if (surface === 'control') return true;
  if (surface === 'screen') return kind === 'slide' || kind === 'hook';
  if (surface === 'stage') return kind === 'stageLayout' || kind === 'hook' || kind === 'slide';
  if (surface === 'remote') return kind === 'remoteAction' || kind === 'command';
  return true;
}

export function createPluginAPI({ pluginId, capabilities, app = null, manifest = {} }) {
  const id = String(pluginId);
  const caps = capabilities instanceof Set ? capabilities : normalizeCapabilities(capabilities);
  const contributionIds = [];
  const commandIds = [];
  const busUnsubs = [];
  const surface = detectSurface();

  function requireCap(cap) {
    if (!caps.has(cap)) {
      throw new Error(`Plugin ${id} sem capability: ${cap}`);
    }
  }

  function tryCap(cap) {
    return caps.has(cap);
  }

  const schemaDefaults = defaultsFromSchema(manifest.configSchema);

  function resolveApp() {
    return app
      || (typeof window !== 'undefined' ? window.__SOMOSUM_CONTROL_APP : null)
      || null;
  }

  function hostFacade() {
    const requireHost = () => requireCap(CAPABILITIES.HOST_CONTROL);
    const live = () => resolveApp();
    return {
      getPrefs: () => live()?.prefs || {},
      prefsChurch: () => ({
        name: (live()?.prefs?.church?.name || '').trim(),
        assets: live()?.getAssetUrls?.() || {},
      }),
      program: {
        get items() { return live()?.program?.items || []; },
        goToItem: (idx) => {
          requireHost();
          live()?.goToItem?.(idx);
        },
        getCurrentMeta: () => live()?.program?.getCurrentMeta?.() || null,
        clearOverlay: () => {
          requireHost();
          live()?.program?.clearOverlay?.();
        },
      },
      projection: {
        pushSlide: (opts) => {
          requireHost();
          const a = live();
          return a?._pushSlideCore?.(opts) || a?.pushToProjector?.(!!opts?.animate);
        },
        /** Envia um slide arbitrário ao projetor (não limpa mídia no ar). */
        sendSlide: (slide, animate = true) => {
          requireHost();
          if (!slide) return false;
          const a = live();
          if (a?.isCountdownLive?.()) {
            a?.toast?.('Pré-culto no ar — encerre a contagem antes de projetar', 'warn');
            return false;
          }
          a?.setMediaOnAir?.(slide);
          const ok = a?.sendSlideToProjector?.(slide, animate);
          try { a?.refreshStage?.({ skipInspector: true }); } catch { /* ignore */ }
          try { a?.updatePreviewBadge?.(); } catch { /* ignore */ }
          return !!ok;
        },
        broadcastOverlay: (kind) => {
          requireHost();
          live()?.broadcastOverlay?.(kind);
        },
        setMediaOnAir: (slide) => {
          requireHost();
          live()?.setMediaOnAir?.(slide);
        },
        clearMediaOnAir: () => {
          requireHost();
          live()?.clearMediaOnAir?.();
        },
        clearOverlay: () => {
          requireHost();
          const a = live();
          a?.clearOverlay?.() || a?.broadcastOverlay?.('clear');
        },
      },
      alerts: {
        send: (payload) => {
          requireHost();
          const a = live();
          a?.sendStageAlert?.(payload) || a?.bus?.send?.('STAGE_ALERT', payload);
        },
      },
      navigation: {
        setView: (v) => {
          requireHost();
          live()?.setView?.(v);
        },
        navigate: (dir) => {
          requireHost();
          live()?.navigate?.(dir);
        },
      },
      toast: (m, t) => {
        try { live()?.toast?.(m, t); } catch { /* ignore */ }
      },
      /** Pré-culto / contagem nativa do Console (mesma tela do botão Pré-culto). */
      countdown: {
        isLive: () => !!live()?.isCountdownLive?.(),
        start: (opts = {}) => {
          requireHost();
          return live()?.startCountdown?.(opts);
        },
        stop: () => {
          requireHost();
          return live()?.stopCountdown?.();
        },
      },
      get screenConnected() { return !!live()?.screenConnected; },
      get autoLive() { return !!live()?.autoLive; },
      getAssetUrls: () => live()?.getAssetUrls?.() || {},
      // Compat legado tipado (sem expor ControlApp)
      pushSlide: (opts) => hostFacade().projection.pushSlide(opts),
      sendStageAlert: (payload) => hostFacade().alerts.send(payload),
      setView: (v) => hostFacade().navigation.setView(v),
      broadcastOverlay: (kind) => hostFacade().projection.broadcastOverlay(kind),
      navigate: (dir) => hostFacade().navigation.navigate(dir),
      getProgram: () => live()?.program || null,
      sendSlideToProjector: (slide, animate = true) => live()?.sendSlideToProjector?.(slide, animate),
      setMediaOnAir: (slide) => live()?.setMediaOnAir?.(slide),
    };
  }

  const api = {
    id,
    apiVersion: PLUGIN_API_VERSION,
    manifest,
    capabilities: [...caps],
    surfaces: {
      current: surface,
      isControl: surface === 'control',
      isScreen: surface === 'screen',
      isStage: surface === 'stage',
      isRemote: surface === 'remote',
    },

    hasCapability(cap) {
      return caps.has(cap);
    },

    toast(msg, type = 'info') {
      try { app?.toast?.(msg, type); } catch { /* ignore */ }
    },

    prefs: {
      read(defaults = {}) {
        if (!tryCap(CAPABILITIES.PREFS)) return { ...schemaDefaults, ...defaults };
        return readPluginPrefs(id, { ...schemaDefaults, ...defaults });
      },
      write(patch) {
        if (!tryCap(CAPABILITIES.PREFS)) return schemaDefaults;
        return writePluginPrefs(id, patch);
      },
    },

    ui: {
      contributeNav(entry) {
        requireCap(CAPABILITIES.UI_NAV);
        if (!surfaceAllowsContribution(surface, 'nav') && surface !== 'control') return null;
        const cid = contribute('nav', { ...entry, pluginId: id });
        if (cid) contributionIds.push(['nav', cid]);
        return cid;
      },
      contributeToolbar(entry) {
        requireCap(CAPABILITIES.UI_TOOLBAR);
        if (surface !== 'control') return null;
        const cid = contribute('toolbar', { ...entry, pluginId: id });
        if (cid) contributionIds.push(['toolbar', cid]);
        return cid;
      },
      contributeSettings(entry) {
        requireCap(CAPABILITIES.UI_SETTINGS);
        if (surface !== 'control') return null;
        const cid = contribute('settings', { ...entry, pluginId: id });
        if (cid) contributionIds.push(['settings', cid]);
        return cid;
      },
      contributeView(entry) {
        requireCap(CAPABILITIES.UI_VIEW);
        if (surface !== 'control') return null;
        const viewId = entry.viewId || entry.id;
        if (!String(viewId).startsWith('plugin:') && !entry.allowAnyId) {
          entry = { ...entry, viewId: `plugin:${id}:${viewId}` };
        }
        if (typeof entry.render !== 'function') {
          throw new Error(`contributeView requer render()`);
        }
        const cid = contribute('view', { ...entry, pluginId: id });
        if (cid) contributionIds.push(['view', cid]);
        return cid;
      },
      contributeRemoteAction(entry) {
        requireCap(CAPABILITIES.REMOTE_ACTION);
        if (surface !== 'control' && surface !== 'remote') return null;
        const cid = contribute('remoteAction', { ...entry, pluginId: id });
        if (cid) contributionIds.push(['remoteAction', cid]);
        return cid;
      },
      contributeStageLayout(entry) {
        requireCap(CAPABILITIES.STAGE_LAYOUT);
        if (surface !== 'control' && surface !== 'stage') return null;
        const cid = contribute('stageLayout', { ...entry, pluginId: id });
        if (cid) contributionIds.push(['stageLayout', cid]);
        return cid;
      },
      registerConfigPanel(meta) {
        requireCap(CAPABILITIES.UI_SETTINGS);
        if (surface !== 'control') return;
        const open = meta.open;
        registerPluginConfig(id, {
          ...meta,
          open: typeof open === 'function'
            ? () => open(hostFacade())
            : null,
        });
      },
    },

    commands: {
      register(action, handler) {
        requireCap(CAPABILITIES.BUS_COMMAND);
        if (surface !== 'control') return;
        registerPluginCommand(action, (ctx) => handler({ ...ctx, host: hostFacade() }));
        commandIds.push(action);
      },
      registerPalette(entry) {
        requireCap(CAPABILITIES.COMMAND_PALETTE);
        if (surface !== 'control') return null;
        const cid = contribute('command', { ...entry, pluginId: id, run: entry.run });
        if (cid) contributionIds.push(['command', cid]);
        void import('../ux/command-palette.js').then(({ registerCommand }) => {
          registerCommand({
            id: entry.id || `plugin:${id}:${cid}`,
            label: entry.label || id,
            keywords: entry.keywords || [],
            run: () => entry.run?.({ host: hostFacade() }),
          });
        }).catch(() => {});
        return cid;
      },
    },

    bus: {
      send(type, payload) {
        requireCap(CAPABILITIES.BUS_SEND);
        try { app?.bus?.send?.(type, payload); } catch { /* ignore */ }
      },
      on(type, handler) {
        requireCap(CAPABILITIES.BUS_SEND);
        const bus = app?.bus;
        if (!bus?.on) return () => {};
        const off = bus.on(type, handler);
        busUnsubs.push(typeof off === 'function' ? off : () => {});
        return off;
      },
    },

    host: null,

    _dispose() {
      for (const [kind, cid] of contributionIds) removeContribution(kind, cid);
      contributionIds.length = 0;
      for (const action of commandIds) unregisterPluginCommand(action);
      commandIds.length = 0;
      unregisterPluginConfig(id);
      clearContributionsForPlugin(id);
      for (const off of busUnsubs) {
        try { off(); } catch { /* ignore */ }
      }
      busUnsubs.length = 0;
    },
  };

  api.host = hostFacade();
  return api;
}

export function listRemoteActionsFromContributions(ctx = null) {
  return listContributions('remoteAction', ctx).map((c) => ({
    id: c.id,
    label: c.label || c.id,
    cmd: c.cmd || c.action || c.id,
    pluginId: c.pluginId,
    prompt: c.prompt ? String(c.prompt) : '',
  }));
}

export function listStageLayoutsFromContributions(ctx = null) {
  return listContributions('stageLayout', ctx).map((c) => ({
    id: c.layoutId || c.id,
    label: c.label || c.id,
    pluginId: c.pluginId,
  }));
}
