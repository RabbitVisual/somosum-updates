/**
 * Plugin Control Center — Ajustes → Plugins (catálogo enable/disable + Abrir Studio).
 */
import { esc, escAttr } from '../control/utils/escape.js';
import { openPluginStudio } from './studio/register-plugin-studio.js';

function howToHtml(p, cfg) {
  const how = cfg?.howTo || p.description || 'Plugin de extensão do culto.';
  const shortcuts = [];
  if ((p.capabilities || []).includes('remote.action')) shortcuts.push('Remote — botões dedicados');
  if ((p.capabilities || []).includes('ui.toolbar')) shortcuts.push('Barra do culto no Controle');
  if ((p.capabilities || []).includes('slide.mutate')) shortcuts.push('Altera slides na projeção');
  const extra = shortcuts.length
    ? `<ul class="plugin-cc-shortcuts">${shortcuts.map((s) => `<li>${esc(s)}</li>`).join('')}</ul>`
    : '';
  return `<div class="plugin-cc-how"><strong>Como usar</strong><p>${esc(how)}</p>${extra}</div>`;
}

export function renderPluginControlCenter(host, list, app) {
  if (!host) return;
  if (!list.length) {
    host.innerHTML = '<p class="form-hint">Nenhum plugin instalado. Abra a <strong>Loja de Plugins</strong> (Ferramentas → Loja) ou use <strong>Instalar ZIP</strong>.</p>';
    return;
  }

  host.innerHTML = `<div class="plugin-cc-list">${list.map((p) => {
    const cfg = p._config || null;
    const hasStudio = (p.capabilities || []).includes('ui.nav') && (p.capabilities || []).includes('ui.view');
    const err = p.lastError ? `<p class="settings-warn form-hint">Erro: ${esc(p.lastError.message)}</p>` : '';
    const q = p.quarantined ? `<p class="settings-warn form-hint">Quarantine — use Reativar abaixo.</p>` : '';
    const caps = (p.capabilities || []).slice(0, 6).map((c) => `<span class="plugin-cap-chip">${esc(c)}</span>`).join('');
    return `
    <article class="plugin-cc-card${p.enabled ? '' : ' is-off'}${p.quarantined ? ' is-quarantine' : ''}" data-cc-plugin="${escAttr(p.id)}">
      <header class="plugin-cc-head" data-cc-toggle="${escAttr(p.id)}" role="button" tabindex="0" aria-expanded="false">
        <div>
          <strong>${esc(p.name || p.id)}</strong>
          <span class="muted"> · v${esc(p.version || '1')} · API ${esc(String(p.api || 2))}${p.activated ? ' · ativo' : ''}</span>
          <div class="plugin-cap-row">${caps}</div>
          ${err}${q}
        </div>
        <label class="settings-toggle settings-toggle--compact" onclick="event.stopPropagation()">
          <input type="checkbox" data-plugin-id="${escAttr(p.id)}" ${p.enabled ? 'checked' : ''} />
          <span>${p.enabled ? 'On' : 'Off'}</span>
        </label>
      </header>
      <div class="plugin-cc-body" hidden data-cc-body="${escAttr(p.id)}">
        ${howToHtml(p, cfg)}
        <div class="plugin-cc-actions">
          ${hasStudio && p.enabled ? `<button type="button" class="btn btn-primary btn-sm" data-plugin-studio="${escAttr(p.id)}">Abrir Studio</button>` : ''}
          ${hasStudio && !p.enabled ? '<p class="form-hint">Ative o plugin para abrir o Studio no menu lateral.</p>' : ''}
          ${!hasStudio && p.enabled ? '<p class="form-hint">Plugin ativo — sem página de Studio.</p>' : ''}
          ${p.quarantined ? `<button type="button" class="btn btn-secondary btn-sm" data-plugin-unq="${escAttr(p.id)}">Reativar</button>` : ''}
          <button type="button" class="btn btn-secondary btn-sm" data-plugin-uninstall="${escAttr(p.id)}">Desinstalar</button>
        </div>
      </div>
    </article>`;
  }).join('')}</div>`;

  host.querySelectorAll('[data-cc-toggle]').forEach((head) => {
    const open = () => {
      const id = head.dataset.ccToggle;
      const body = host.querySelector(`[data-cc-body="${id}"]`);
      if (!body) return;
      const on = body.hidden;
      body.hidden = !on;
      head.setAttribute('aria-expanded', on ? 'true' : 'false');
    };
    head.addEventListener('click', open);
    head.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); open(); }
    });
  });

  host.querySelectorAll('[data-plugin-studio]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const p = list.find((x) => x.id === btn.dataset.pluginStudio);
      if (!p?.enabled) {
        app?.toast?.('Ative o plugin primeiro', 'warn');
        return;
      }
      if (!openPluginStudio(app, btn.dataset.pluginStudio)) {
        app?.toast?.('Studio indisponível', 'warn');
      }
    });
  });
}
