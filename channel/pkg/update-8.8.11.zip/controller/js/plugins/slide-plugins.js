/**
 * Helpers de slide para plugins (stamp / tip / mutações pré-render e pré-sync).
 */
import { PluginEngine } from './plugin-engine.js';
import { esc } from '../core/render-engine/index.js';

const SKIP_STAMP_TYPES = new Set(['blank', 'logo', 'countdown', 'countdown-pause', 'media-audio']);

/**
 * Aplica hooks slide:render síncronos no objeto slide (mutação in-place).
 */
export function applySlideRenderPlugins(slide, context = {}, options = {}) {
  if (!slide || typeof slide !== 'object') return slide;
  try {
    PluginEngine.runHookSync('slide:render', { slide, context, options });
  } catch { /* ignore */ }
  return slide;
}

/**
 * Clone leve + plugins — para sync Controle → Projetor.
 */
export function prepareSlideWithPlugins(slide, app = null) {
  if (!slide) return slide;
  const next = { ...slide };
  if (slide.style && typeof slide.style === 'object') next.style = { ...slide.style };
  if (slide.data && typeof slide.data === 'object') next.data = { ...slide.data };
  if (slide.pix && typeof slide.pix === 'object') next.pix = { ...slide.pix };
  const context = {
    prefs: app?.prefs || {},
    assets: app?.getAssetUrls?.() || {},
    app,
  };
  applySlideRenderPlugins(next, context, { sync: true });
  return next;
}

/** HTML do carimbo institucional (se o plugin preencheu slide._cultoStamp). */
export function pluginStampHtml(slide) {
  const stamp = slide?._cultoStamp;
  if (!stamp?.enabled || !stamp.line) return '';
  if (SKIP_STAMP_TYPES.has(slide?.type)) return '';
  const pos = stamp.position || 'bottom-right';
  return `<div class="plugin-culto-stamp plugin-culto-stamp--${esc(pos)}" aria-hidden="true">${esc(stamp.line)}</div>`;
}

/** Aviso rotativo (plugin culto-avisos-rodape). */
export function pluginTipHtml(slide) {
  const tip = slide?._cultoTip;
  if (!tip?.enabled || !tip.text) return '';
  if (SKIP_STAMP_TYPES.has(slide?.type)) return '';
  const pos = tip.position || 'bottom-left';
  return `<div class="plugin-culto-tip plugin-culto-tip--${esc(pos)}" aria-hidden="true">${esc(tip.text)}</div>`;
}

/** Card de versículo em destaque (bem-vindo / seção / oração). */
export function pluginVerseCardHtml(slide) {
  const card = slide?._cultoVerseCard;
  if (!card?.enabled || !card.text) return '';
  return `<aside class="plugin-culto-verse-card" aria-hidden="true">
    ${card.reference ? `<p class="plugin-culto-verse-ref">${esc(card.reference)}</p>` : ''}
    <p class="plugin-culto-verse-text">${esc(card.text)}</p>
  </aside>`;
}

/** QR PIX discreto (boas-vindas / seção / etc. — plugin culto-oferta-pix). */
export function pluginPixMiniHtml(slide) {
  const mini = slide?._cultoPixMini;
  if (!mini?.enabled || !mini.qrDataUrl) return '';
  if (SKIP_STAMP_TYPES.has(slide?.type)) return '';
  const pos = mini.placement || 'bottom-right';
  const size = mini.size || 'md';
  const key = mini.key ? `<p class="plugin-culto-pix-key">${esc(mini.key)}</p>` : '';
  const holder = mini.holder ? `<p class="plugin-culto-pix-holder">${esc(mini.holder)}</p>` : '';
  return `<aside class="plugin-culto-pix-mini plugin-culto-pix-mini--${esc(pos)} plugin-culto-pix-mini--${esc(size)}" aria-hidden="true">
    <img class="plugin-culto-pix-qr" src="${esc(mini.qrDataUrl)}" alt="" />
    <div class="plugin-culto-pix-meta">
      <p class="plugin-culto-pix-label">${esc(mini.note || 'PIX')}</p>
      ${holder}${key}
    </div>
  </aside>`;
}

/** Anexa chrome de plugins ao HTML do slide. */
export function appendPluginSlideChrome(html, slide) {
  if (!html || typeof html !== 'string') return html;
  const inject = [
    pluginVerseCardHtml(slide),
    pluginStampHtml(slide),
    pluginTipHtml(slide),
    pluginPixMiniHtml(slide),
    slide?._pluginExtrasHtml || '',
  ].filter(Boolean).join('');
  if (!inject) return html;
  if (html.includes('</div>')) {
    const idx = html.lastIndexOf('</div>');
    if (idx >= 0) return `${html.slice(0, idx)}${inject}${html.slice(idx)}`;
  }
  return `${html}${inject}`;
}
