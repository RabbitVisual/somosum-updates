/**
 * PluginHost v2 — load, surface-scoped activate, install, load-gate generation.
 */
import { LogService, LogCategory } from '../core/logging/log-service.js';
import { dataPublicUrl } from '../core/data-public-url.js';
import { FileManager } from '../core/storage/files/file-manager.js';
import {
  PluginEngine,
  validatePluginManifest,
  resolvePluginEntry,
  PLUGIN_HOOKS,
  rebuildHooksPublic,
  clearQuarantine,
  isQuarantined,
  getQuarantine,
} from './plugin-engine.js';
import {
  createPluginAPI,
  normalizeCapabilities,
  PLUGIN_API_VERSION,
  detectSurface,
  isKnownCapability,
} from './plugin-api.js';
import { clearAllContributions, clearContributionsForPlugin, contribute } from './contributions.js';
import {
  clearPluginCommands,
  clearPluginConfigs,
  syncPrefsFromDisk,
  flushPrefsToDisk,
} from './plugin-prefs.js';

const PLUGIN_TIMEOUT_MS = 5000;
const activeApis = new Map();
const lastErrors = new Map();
const activated = new Set();
let hostApp = null;
let loadPromise = null;
let loadGeneration = 0;

export function setPluginHostApp(app) {
  hostApp = app || null;
}

export function getPluginHostApp() {
  return hostApp;
}

export function getPluginLastError(id) {
  return lastErrors.get(id) || null;
}

function setError(id, err) {
  lastErrors.set(id, {
    message: String(err?.message || err),
    at: new Date().toISOString(),
  });
}

function clearError(id) {
  lastErrors.delete(id);
}

function resolveHookFn(mod, name) {
  if (!mod) return null;
  const aliases = {
    'slide:render': 'slideRender',
    'remote:actions': 'remoteActions',
    'stage:layout': 'stageLayout',
    'template:register': 'templateRegister',
    'program:beforeSave': 'programBeforeSave',
    'bible:passage': 'biblePassage',
    activate: 'activate',
    deactivate: 'deactivate',
  };
  return mod?.hooks?.[name]
    || mod?.[name]
    || (aliases[name] ? mod?.[aliases[name]] : null)
    || mod?.default?.[name]
    || null;
}

async function loadModule(plugin) {
  if (!plugin?.load) return null;
  if (plugin._mod) return plugin._mod;
  const mod = await Promise.race([
    plugin.load(),
    new Promise((_, rej) => setTimeout(() => rej(new Error('plugin timeout')), PLUGIN_TIMEOUT_MS)),
  ]);
  plugin._mod = mod;
  return mod;
}

async function fetchManifestRich(id) {
  try {
    const res = await fetch(dataPublicUrl(`plugins/${id}/manifest.json`), { cache: 'no-store' });
    if (res.status === 403 || res.status === 404 || !res.ok) return null;
    return await res.json();
  } catch {
    return null;
  }
}

function mergeManifest(indexEntry, rich) {
  const base = { ...(indexEntry || {}), ...(rich || {}) };
  if (indexEntry?.enabled != null) base.enabled = indexEntry.enabled;
  if (indexEntry?.entry) base.entry = indexEntry.entry;
  if (indexEntry?.id) base.id = indexEntry.id;
  base.capabilities = rich?.capabilities || indexEntry?.capabilities || [];
  base.configSchema = rich?.configSchema || indexEntry?.configSchema || null;
  base.contributions = rich?.contributions || indexEntry?.contributions || null;
  const hooks = rich?.hooks || indexEntry?.hooks || ['activate', 'deactivate'];
  base.hooks = (hooks || []).filter((h) => h !== 'boot');
  base.api = rich?.api ?? indexEntry?.api ?? PLUGIN_API_VERSION;
  base.name = rich?.name || indexEntry?.name || base.id;
  base.description = rich?.description || indexEntry?.description || '';
  base.version = rich?.version || indexEntry?.version || '1.0.0';
  return base;
}

/**
 * Should this plugin run activate() on current surface?
 */
function shouldActivateOnSurface(plugin, surface) {
  const hooks = plugin.hooks || [];
  const caps = plugin.capabilities || [];
  if (surface === 'control') return true;
  if (surface === 'screen') {
    return hooks.includes('slide:render') || caps.includes('slide.mutate');
  }
  if (surface === 'stage') {
    return hooks.includes('stage:layout') || hooks.includes('slide:render')
      || caps.includes('stage.layout') || caps.includes('slide.mutate');
  }
  if (surface === 'remote') {
    return hooks.includes('remote:actions') || caps.includes('remote.action') || caps.includes('bus.command');
  }
  return true;
}

/**
 * Activate a registered, enabled plugin (surface-aware).
 */
export async function activatePlugin(id) {
  const plugin = PluginEngine.get(id);
  if (!plugin || plugin.enabled === false) return false;
  if (activated.has(id)) return true;
  if (isQuarantined(id)) {
    setError(id, new Error('plugin em quarantine'));
    return false;
  }

  const surface = detectSurface();
  if (!shouldActivateOnSurface(plugin, surface)) {
    // Still preload module for hooks on this surface without UI activate
    try {
      await loadModule(plugin);
    } catch (err) {
      setError(id, err);
      return false;
    }
    return false;
  }

  let api = null;
  try {
    const mod = await Promise.race([
      loadModule(plugin),
      new Promise((_, rej) => setTimeout(() => rej(new Error('plugin timeout')), PLUGIN_TIMEOUT_MS)),
    ]);
    const caps = normalizeCapabilities(plugin.capabilities);
    api = createPluginAPI({
      pluginId: id,
      capabilities: caps,
      app: hostApp,
      manifest: plugin,
    });

    const contrib = plugin.contributions || {};
    if (surface === 'control') {
      if (Array.isArray(contrib.nav) && caps.has('ui.nav')) {
        for (const n of contrib.nav) api.ui.contributeNav(n);
      }
      if (Array.isArray(contrib.toolbar) && caps.has('ui.toolbar')) {
        for (const t of contrib.toolbar) api.ui.contributeToolbar(t);
      }
    }
    if ((surface === 'control' || surface === 'remote') && Array.isArray(contrib.remote) && caps.has('remote.action')) {
      for (const r of contrib.remote) api.ui.contributeRemoteAction(r);
    }
    if ((surface === 'control' || surface === 'stage') && Array.isArray(contrib.stageLayouts) && caps.has('stage.layout')) {
      for (const s of contrib.stageLayouts) api.ui.contributeStageLayout(s);
    }

    const activateFn = resolveHookFn(mod, 'activate');
    if (typeof activateFn === 'function') {
      await Promise.race([
        Promise.resolve(activateFn(api)),
        new Promise((_, rej) => setTimeout(() => rej(new Error('plugin activate timeout')), PLUGIN_TIMEOUT_MS)),
      ]);
    }
    activeApis.set(id, api);
    activated.add(id);
    clearError(id);
    clearQuarantine(id);
    return true;
  } catch (err) {
    try { api?._dispose?.(); } catch { /* ignore */ }
    setError(id, err);
    LogService.warn?.('Plugin activate falhou', {
      module: `plugin:${id}`,
      category: LogCategory.BOOT,
      detail: { err: String(err?.message || err), surface },
    });
    return false;
  }
}

export async function deactivatePlugin(id) {
  const api = activeApis.get(id);
  const plugin = PluginEngine.get(id);
  try {
    if (plugin?._mod) {
      const deactivateFn = resolveHookFn(plugin._mod, 'deactivate');
      if (typeof deactivateFn === 'function') {
        const facade = api || createPluginAPI({
          pluginId: id,
          capabilities: normalizeCapabilities(plugin.capabilities),
          app: hostApp,
          manifest: plugin,
        });
        await Promise.race([
          Promise.resolve(deactivateFn(facade)),
          new Promise((resolve) => setTimeout(resolve, 2000)),
        ]);
      }
    }
  } catch (err) {
    setError(id, err);
  }
  try { api?._dispose?.(); } catch { /* ignore */ }
  activeApis.delete(id);
  activated.delete(id);
  clearContributionsForPlugin(id);
  // Keep module cached for hooks on other surfaces; only clear on disable
  return true;
}

export async function activateAllEnabled() {
  const surface = detectSurface();
  const list = PluginEngine.list().filter((p) => p.enabled);
  for (const p of list) {
    if (shouldActivateOnSurface(p, surface)) {
      await activatePlugin(p.id);
    } else {
      // Preload for sync hooks only
      const plugin = PluginEngine.get(p.id);
      if (plugin) {
        try { await loadModule(plugin); } catch { /* ignore */ }
      }
    }
  }
}

export async function deactivateAll() {
  for (const id of [...activated]) {
    await deactivatePlugin(id);
  }
  clearAllContributions();
}

export async function unquarantinePlugin(id) {
  clearQuarantine(id);
  clearError(id);
  if (PluginEngine.get(id)?.enabled) {
    activated.delete(id);
    await activatePlugin(id);
  }
  return true;
}

/**
 * Load index + manifests, register, preload (surface-aware), activate.
 */
export async function loadPluginsFromDisk(generation = null) {
  const gen = generation ?? loadGeneration;
  try {
    await deactivateAll();
    if (gen !== loadGeneration) return [];
    PluginEngine.clearRegistry();
    clearPluginCommands();
    clearPluginConfigs();
    clearAllContributions();
    activated.clear();
    activeApis.clear();

    const index = await FileManager.loadJson('plugins/index.json');
    if (!index?.plugins) return [];
    if (gen !== loadGeneration) return [];

    const loaded = [];
    const surface = detectSurface();

    for (const entry of index.plugins) {
      let rich = null;
      if (!Array.isArray(entry.capabilities) || !entry.capabilities.length) {
        rich = await fetchManifestRich(entry.id);
      } else {
        rich = {
          capabilities: entry.capabilities,
          hooks: entry.hooks,
          configSchema: entry.configSchema,
          contributions: entry.contributions,
          api: entry.api,
          name: entry.name,
          description: entry.description,
          version: entry.version,
        };
      }
      const merged = mergeManifest(entry, rich);
      const v = validatePluginManifest(merged);
      if (!v.ok) {
        setError(entry.id || 'unknown', new Error(`manifest inválido: ${v.reason}`));
        continue;
      }
      const url = resolvePluginEntry(
        merged.entry?.startsWith('/')
          ? merged.entry
          : `/api/data/plugins/${merged.id}/${(merged.entry || 'plugin.js').replace(/^.*\//, '')}`,
      );

      PluginEngine.register({
        ...merged,
        entry: url,
        enabled: merged.enabled !== false,
        capabilities: merged.capabilities,
        configSchema: merged.configSchema,
        contributions: merged.contributions,
        load: () => import(/* @vite-ignore */ url),
      });
      loaded.push(merged.id);
      void syncPrefsFromDisk(merged.id).catch(() => {});
    }

    if (gen !== loadGeneration) return [];

    try {
      const raw = localStorage.getItem('somosum-plugins-enabled');
      if (raw) {
        const map = JSON.parse(raw);
        let dirty = false;
        for (const [id, en] of Object.entries(map)) {
          const p = PluginEngine.get(id);
          if (p && p.enabled !== !!en) {
            p.enabled = !!en;
            dirty = true;
          }
        }
        if (dirty) await persistEnabledToIndex();
      }
    } catch { /* ignore */ }

    // Preload only plugins needed on this surface
    await PluginEngine.preloadModules((p) => shouldActivateOnSurface(p, surface)
      || (p.hooks || []).includes('slide:render')
      || (p.capabilities || []).includes('slide.mutate'));
    if (gen !== loadGeneration) return [];

    rebuildHooksPublic();
    await activateAllEnabled();
    if (gen !== loadGeneration) return [];

    if (surface === 'control') {
      try {
        contribute('toolbar', {
          pluginId: '_host',
          slot: 'program-culto-bar',
          id: 'plugin-hub-open',
          label: 'Plugins',
          order: 5,
          title: 'Configurar plugins ativos',
          run: ({ app }) => {
            void import('./plugin-hub.js').then(({ openPluginHub }) => {
              openPluginHub(app || hostApp || window.__SOMOSUM_CONTROL_APP);
            });
          },
        });
        contribute('toolbar', {
          pluginId: '_host',
          slot: 'topbar-more',
          id: 'plugin-hub-more',
          label: 'Configurar plugins…',
          order: 10,
          run: ({ app }) => {
            void import('./plugin-hub.js').then(({ openPluginHub }) => {
              openPluginHub(app || hostApp || window.__SOMOSUM_CONTROL_APP);
            });
          },
        });
      } catch { /* ignore */ }
    }

    LogService.debug('Plugins carregados (host)', {
      module: 'plugin-host',
      category: LogCategory.BOOT,
      detail: { loaded, activated: [...activated], surface, gen },
    });
    return loaded;
  } catch (err) {
    LogService.warn?.('loadPluginsFromDisk falhou', {
      module: 'plugin-host',
      category: LogCategory.BOOT,
      detail: { err: String(err?.message || err) },
    });
    return [];
  }
}

export function ensurePluginsLoaded() {
  if (!loadPromise) {
    const gen = loadGeneration;
    loadPromise = loadPluginsFromDisk(gen).finally(() => {
      // keep promise until reset
    });
  }
  return loadPromise;
}

export function resetPluginsLoadGate() {
  loadGeneration += 1;
  loadPromise = null;
}

export async function reloadPlugins() {
  resetPluginsLoadGate();
  return ensurePluginsLoaded();
}

let crossSurfaceReloadBound = false;
function bindCrossSurfacePluginReload() {
  if (crossSurfaceReloadBound || typeof window === 'undefined') return;
  crossSurfaceReloadBound = true;
  let lastToken = '';
  window.addEventListener('storage', (event) => {
    if (event.key !== 'somosum-plugins-reload' || !event.newValue || event.newValue === lastToken) return;
    lastToken = event.newValue;
    void reloadPlugins();
  });
  try {
    if (typeof BroadcastChannel !== 'undefined') {
      const ch = new BroadcastChannel('somosum-plugins');
      ch.onmessage = () => { void reloadPlugins(); };
    }
  } catch { /* ignore */ }
}
bindCrossSurfacePluginReload();

export async function setPluginEnabled(id, enabled) {
  const p = PluginEngine.get(id);
  if (!p) return false;
  if (!enabled) {
    await deactivatePlugin(id);
    p.enabled = false;
  } else {
    p.enabled = true;
    clearQuarantine(id);
    await activatePlugin(id);
  }
  rebuildHooksPublic();
  await persistEnabledToIndex();
  try {
    const map = {};
    for (const x of PluginEngine.list()) map[x.id] = x.enabled;
    localStorage.setItem('somosum-plugins-enabled', JSON.stringify(map));
  } catch { /* ignore */ }
  return true;
}

export async function persistEnabledToIndex() {
  const index = (await FileManager.loadJson('plugins/index.json')) || { version: 2, plugins: [] };
  const byId = new Map((index.plugins || []).map((p) => [p.id, p]));
  for (const p of PluginEngine.list()) {
    const row = byId.get(p.id) || { id: p.id, entry: p.entry, hooks: p.hooks };
    row.enabled = p.enabled;
    row.name = p.name;
    row.description = p.description;
    row.version = p.version;
    row.hooks = (p.hooks || []).filter((h) => h !== 'boot');
    row.capabilities = p.capabilities;
    row.api = p.api;
    row.entry = p.entry?.includes('/api/data/')
      ? p.entry
      : `/api/data/plugins/${p.id}/plugin.js`;
    byId.set(p.id, row);
  }
  index.version = Math.max(2, index.version || 1);
  index.plugins = [...byId.values()];
  return FileManager.saveJson('plugins/index.json', index, 'plugins:index');
}

export function listPluginsDetailed() {
  return PluginEngine.list().map((p) => ({
    ...p,
    activated: activated.has(p.id),
    lastError: lastErrors.get(p.id) || null,
    quarantined: isQuarantined(p.id),
    quarantine: getQuarantine(p.id),
    api: p.api ?? PLUGIN_API_VERSION,
    capabilities: p.capabilities || [],
    configSchema: p.configSchema || null,
  }));
}

export async function installPluginFiles(id, files, meta = {}) {
  if (!id?.match(/^[a-z0-9-]+$/)) throw new Error('id inválido');
  const caps = meta.capabilities;
  if (Array.isArray(caps)) {
    for (const c of caps) {
      if (!isKnownCapability(c)) throw new Error(`capability desconhecida: ${c}`);
    }
  }
  const { secureFetch } = await import('../core/security/api-security.js');
  const res = await secureFetch('/api/plugins/install', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json; charset=utf-8' },
    body: JSON.stringify({ id, files, meta }),
  });
  if (!res.ok) {
    const t = await res.text().catch(() => '');
    throw new Error(t || `install failed ${res.status}`);
  }
  return reloadPlugins();
}

export async function uninstallPlugin(id) {
  if (!id?.match(/^[a-z0-9-]+$/)) throw new Error('id inválido');
  await deactivatePlugin(id);
  const { secureFetch } = await import('../core/security/api-security.js');
  const res = await secureFetch(`/api/plugins/uninstall?id=${encodeURIComponent(id)}`, {
    method: 'POST',
  });
  if (!res.ok) {
    const t = await res.text().catch(() => '');
    throw new Error(t || `uninstall failed ${res.status}`);
  }
  PluginEngine.unregister(id);
  return reloadPlugins();
}

export async function flushAllPluginPrefs() {
  for (const p of PluginEngine.list()) {
    await flushPrefsToDisk(p.id);
  }
}

export { PLUGIN_HOOKS, resolveHookFn, detectSurface };
