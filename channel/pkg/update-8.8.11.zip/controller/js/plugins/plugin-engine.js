/**
 * PluginEngine — registry + hooks + quarantine (orquestrado pelo PluginHost).
 */
import { safeCall } from '../core/error-boundary.js';
import { LogService, LogCategory } from '../core/logging/log-service.js';
import { dataPublicUrl } from '../core/data-public-url.js';
import { HOOK_CAPABILITIES } from './plugin-api.js';

const registry = new Map();
const hooks = new Map();
const moduleCache = new Map();
const quarantine = new Map(); // id -> { count, until, reason }
const PLUGIN_TIMEOUT_MS = 5000;
const QUARANTINE_THRESHOLD = 3;
const QUARANTINE_MS = 5 * 60 * 1000;

export function resolvePluginEntry(entry) {
  if (!entry || typeof entry !== 'string') return entry;
  if (entry.startsWith('/api/data/')) return entry;
  const rel = entry.replace(/^\/+/, '').replace(/^data\//, '');
  if (!rel || rel.includes('..')) return entry;
  return dataPublicUrl(rel);
}

export const PLUGIN_HOOKS = Object.freeze([
  'activate',
  'deactivate',
  'slide:render',
  'slide:change',
  'background:rule',
  'remote:actions',
  'stage:layout',
  'template:register',
  'program:beforeSave',
  'bible:passage',
]);

export function validatePluginManifest(manifest) {
  if (!manifest || typeof manifest !== 'object') return { ok: false, reason: 'invalid' };
  if (typeof manifest.id !== 'string' || !manifest.id.match(/^[a-z0-9-]+$/)) return { ok: false, reason: 'id' };
  if (!Array.isArray(manifest.hooks)) return { ok: false, reason: 'hooks' };
  if (typeof manifest.entry !== 'string') return { ok: false, reason: 'entry' };
  return { ok: true };
}

function rebuildHooks() {
  hooks.clear();
  for (const plugin of registry.values()) {
    if (plugin.enabled === false) continue;
    (plugin.hooks || []).forEach((hook) => {
      if (hook === 'boot') return;
      if (!hooks.has(hook)) hooks.set(hook, []);
      hooks.get(hook).push(plugin.id);
    });
  }
}

export function rebuildHooksPublic() {
  rebuildHooks();
}

export function isQuarantined(id) {
  const q = quarantine.get(id);
  if (!q) return false;
  if (q.until && Date.now() > q.until) {
    quarantine.delete(id);
    return false;
  }
  return true;
}

export function clearQuarantine(id) {
  quarantine.delete(id);
}

export function getQuarantine(id) {
  return quarantine.get(id) || null;
}

function noteHookFailure(id, name, err) {
  const prev = quarantine.get(id) || { count: 0 };
  const count = (prev.count || 0) + 1;
  const entry = {
    count,
    reason: String(err?.message || err),
    hook: name,
    at: new Date().toISOString(),
  };
  if (count >= QUARANTINE_THRESHOLD) {
    entry.until = Date.now() + QUARANTINE_MS;
    LogService.warn?.('Plugin quarantined', {
      module: `plugin:${id}`,
      category: LogCategory.BOOT,
      detail: entry,
    });
  }
  quarantine.set(id, entry);
}

function pluginHasHookCap(plugin, hookName) {
  const need = HOOK_CAPABILITIES[hookName];
  if (!need) return true;
  const caps = plugin.capabilities || [];
  return Array.isArray(caps) && caps.includes(need);
}

function resolveHookFn(mod, name) {
  if (!mod) return null;
  return mod?.hooks?.[name]
    || mod?.[name]
    || (name === 'slide:render' ? mod?.slideRender : null)
    || (name === 'remote:actions' ? mod?.remoteActions : null)
    || (name === 'stage:layout' ? mod?.stageLayout : null)
    || (name === 'template:register' ? mod?.templateRegister : null)
    || (name === 'program:beforeSave' ? mod?.programBeforeSave : null)
    || (name === 'bible:passage' ? mod?.biblePassage : null)
    || (name === 'activate' ? mod?.activate : null)
    || (name === 'deactivate' ? mod?.deactivate : null)
    || mod?.default?.[name]
    || null;
}

async function loadPluginModule(plugin) {
  if (!plugin?.load) return null;
  if (moduleCache.has(plugin.id)) {
    plugin._mod = moduleCache.get(plugin.id);
    return moduleCache.get(plugin.id);
  }
  if (plugin._mod) {
    moduleCache.set(plugin.id, plugin._mod);
    return plugin._mod;
  }
  const mod = await Promise.race([
    plugin.load(),
    new Promise((_, rej) => setTimeout(() => rej(new Error('plugin timeout')), PLUGIN_TIMEOUT_MS)),
  ]);
  moduleCache.set(plugin.id, mod);
  plugin._mod = mod;
  return mod;
}

export const PluginEngine = {
  register(plugin) {
    const v = validatePluginManifest(plugin);
    if (!v.ok) return false;
    const entryUrl = resolvePluginEntry(plugin.entry);
    const entry = {
      ...plugin,
      entry: entryUrl,
      enabled: plugin.enabled !== false,
      name: plugin.name || plugin.id,
      description: plugin.description || '',
      version: plugin.version || '1.0.0',
      api: plugin.api ?? 2,
      capabilities: plugin.capabilities || [],
      configSchema: plugin.configSchema || null,
      contributions: plugin.contributions || null,
    };
    if (typeof plugin.load !== 'function') {
      entry.load = () => import(/* @vite-ignore */ entryUrl);
    }
    registry.set(entry.id, entry);
    rebuildHooks();
    return true;
  },

  get(id) {
    return registry.get(id) || null;
  },

  unregister(id) {
    registry.delete(id);
    moduleCache.delete(id);
    quarantine.delete(id);
    rebuildHooks();
  },

  clearRegistry() {
    registry.clear();
    hooks.clear();
    moduleCache.clear();
  },

  setEnabled(id, enabled) {
    const p = registry.get(id);
    if (!p) return false;
    p.enabled = !!enabled;
    if (!enabled) {
      moduleCache.delete(id);
      p._mod = null;
      quarantine.delete(id);
    } else {
      void loadPluginModule(p).catch(() => {});
    }
    rebuildHooks();
    return true;
  },

  async loadFromManifest(manifest) {
    if (!validatePluginManifest(manifest).ok) return false;
    const entryUrl = resolvePluginEntry(manifest.entry);
    return this.register({
      id: manifest.id,
      name: manifest.name,
      description: manifest.description,
      version: manifest.version,
      hooks: manifest.hooks,
      entry: entryUrl,
      enabled: manifest.enabled !== false,
      capabilities: manifest.capabilities,
      configSchema: manifest.configSchema,
      contributions: manifest.contributions,
      api: manifest.api,
      load: () => import(/* @vite-ignore */ entryUrl),
    });
  },

  async preloadModules(filterFn = null) {
    let ids = [...registry.values()].filter((p) => p.enabled !== false);
    if (typeof filterFn === 'function') ids = ids.filter(filterFn);
    await Promise.all(ids.map(async (p) => {
      const plugin = registry.get(p.id);
      if (!plugin) return;
      try {
        await loadPluginModule(plugin);
      } catch (err) {
        LogService.warn?.('Plugin preload falhou', {
          module: 'plugin-engine',
          category: LogCategory.BOOT,
          detail: { id: p.id, err: String(err?.message || err) },
        });
      }
    }));
  },

  runHookSync(name, ctx) {
    const ids = hooks.get(name) || [];
    const results = [];
    for (const id of ids) {
      const plugin = registry.get(id);
      if (!plugin || plugin.enabled === false) continue;
      if (isQuarantined(id)) continue;
      if (!pluginHasHookCap(plugin, name)) continue;
      const mod = moduleCache.get(id) || plugin._mod;
      if (!mod) continue;
      try {
        const fn = resolveHookFn(mod, name);
        if (typeof fn === 'function') {
          const t0 = performance.now();
          const out = fn(ctx);
          if (window.__SOMOSUM_LIVE_ACTIVE && performance.now() - t0 > 12) {
            noteHookFailure(id, name, new Error('hook lento em culto ao vivo'));
          }
          results.push({ id, out });
        }
      } catch (err) {
        noteHookFailure(id, name, err);
        LogService.warn?.('Plugin hook sync erro', {
          module: `plugin:${id}`,
          category: LogCategory.BOOT,
          detail: { name, err: String(err?.message || err) },
        });
      }
    }
    return results;
  },

  async runHook(name, ctx) {
    const ids = hooks.get(name) || [];
    const results = [];
    for (const id of ids) {
      const plugin = registry.get(id);
      if (!plugin?.load || plugin.enabled === false) continue;
      if (isQuarantined(id)) continue;
      if (!pluginHasHookCap(plugin, name)) continue;
      try {
        const mod = await loadPluginModule(plugin);
        const fn = resolveHookFn(mod, name);
        if (typeof fn === 'function') {
          const out = await Promise.race([
            Promise.resolve(fn(ctx)),
            new Promise((_, rej) => setTimeout(() => rej(new Error('plugin hook timeout')), PLUGIN_TIMEOUT_MS)),
          ]);
          results.push({ id, out });
        }
      } catch (err) {
        noteHookFailure(id, name, err);
        LogService.warn?.('Plugin hook erro', {
          module: `plugin:${id}`,
          category: LogCategory.BOOT,
          detail: { name, err: String(err?.message || err) },
        });
      }
    }
    return results;
  },

  list() {
    return [...registry.values()].map((p) => ({
      id: p.id,
      name: p.name,
      description: p.description,
      version: p.version,
      hooks: p.hooks,
      enabled: p.enabled !== false,
      entry: p.entry,
      api: p.api,
      capabilities: p.capabilities,
      configSchema: p.configSchema,
      contributions: p.contributions,
      quarantined: isQuarantined(p.id),
      quarantine: getQuarantine(p.id),
    }));
  },
};

export async function loadPluginsFromDisk() {
  const m = await import('./plugin-host.js');
  return m.loadPluginsFromDisk();
}

export async function ensurePluginsLoaded() {
  const m = await import('./plugin-host.js');
  return m.ensurePluginsLoaded();
}

export async function resetPluginsLoadGate() {
  const m = await import('./plugin-host.js');
  m.resetPluginsLoadGate();
}

export async function persistPluginEnabledMap() {
  const m = await import('./plugin-host.js');
  return m.persistEnabledToIndex();
}
