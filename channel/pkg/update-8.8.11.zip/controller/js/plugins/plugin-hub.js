/**
 * Plugin Hub — painel lateral (health, quarantine, link ao Studio).
 */
import { esc, escAttr } from '../core/render-engine/index.js';
import { getPluginConfig } from './plugin-prefs.js';
import { openPluginStudio } from './studio/register-plugin-studio.js';

const HUB_ID = 'somosum-plugin-hub';

function closeHub() {
  document.getElementById(HUB_ID)?.remove();
  document.getElementById(`${HUB_ID}-backdrop`)?.remove();
}

export async function openPluginHub(app, opts = {}) {
  if (typeof document === 'undefined') return;
  closeHub();

  const {
    ensurePluginsLoaded,
    setPluginHostApp,
    listPluginsDetailed,
    setPluginEnabled,
    unquarantinePlugin,
  } = await import('./plugin-host.js');
  setPluginHostApp(app);
  await ensurePluginsLoaded();

  const backdrop = document.createElement('div');
  backdrop.id = `${HUB_ID}-backdrop`;
  backdrop.className = 'plugin-hub-backdrop';
  backdrop.addEventListener('click', closeHub);

  const panel = document.createElement('aside');
  panel.id = HUB_ID;
  panel.className = 'plugin-hub';
  panel.setAttribute('role', 'dialog');
  panel.setAttribute('aria-label', 'Plugins do culto');
  panel.innerHTML = `
    <header class="plugin-hub__head">
      <div>
        <p class="plugin-hub__kicker">Extensões offline · API v2</p>
        <h2 class="plugin-hub__title">Plugins do culto</h2>
      </div>
      <button type="button" class="plugin-hub__close" aria-label="Fechar">×</button>
    </header>
    <p class="plugin-hub__lead">Plugins ativos. Configure no Studio (menu lateral) ou em Ajustes → Plugins.</p>
    <div class="plugin-hub__list" id="plugin-hub-list"></div>
    <div class="plugin-hub__detail" id="plugin-hub-detail" hidden></div>
    <footer class="plugin-hub__foot">
      <button type="button" class="su-btn" id="plugin-hub-settings">Abrir Ajustes → Plugins</button>
      <span class="plugin-hub__count" id="plugin-hub-count"></span>
    </footer>
  `;

  document.body.appendChild(backdrop);
  document.body.appendChild(panel);
  panel.querySelector('.plugin-hub__close')?.addEventListener('click', closeHub);
  panel.querySelector('#plugin-hub-settings')?.addEventListener('click', () => {
    closeHub();
    app?.setView?.('settings');
    try { location.hash = 'settings-plugins'; } catch { /* ignore */ }
    setTimeout(() => document.querySelector('[data-section="plugins"]')?.click(), 80);
  });

  const listEl = panel.querySelector('#plugin-hub-list');
  const detailEl = panel.querySelector('#plugin-hub-detail');
  const countEl = panel.querySelector('#plugin-hub-count');

  const statusBadge = (p) => {
    if (p.quarantined) return '<span class="plugin-hub__badge plugin-hub__badge--warn">Quarantine</span>';
    if (p.lastError) return '<span class="plugin-hub__badge plugin-hub__badge--err">Erro</span>';
    if (p.activated) return '<span class="plugin-hub__badge plugin-hub__badge--ok">Ativo</span>';
    if (p.enabled) return '<span class="plugin-hub__badge">Carregado</span>';
    return '<span class="plugin-hub__badge">Off</span>';
  };

  const hasStudio = (p) => (p.capabilities || []).includes('ui.nav') && (p.capabilities || []).includes('ui.view');

  const showDetail = (p) => {
    const cfg = getPluginConfig(p.id);
    const err = p.lastError ? `<p class="settings-warn form-hint">Erro: ${esc(p.lastError.message)}</p>` : '';
    const q = p.quarantine ? `<p class="settings-warn form-hint">Quarantine: ${esc(p.quarantine.reason || '')} (${p.quarantine.count || 0}x)</p>` : '';
    detailEl.hidden = false;
    listEl.hidden = true;
    detailEl.innerHTML = `
      <button type="button" class="plugin-hub__back" id="plugin-hub-back">← Voltar</button>
      <h3 class="plugin-hub__detail-title">${esc(p.name || p.id)} ${statusBadge(p)}</h3>
      <p class="plugin-hub__detail-desc">${esc(cfg?.howTo || p.description || '')}</p>
      ${err}${q}
      <div class="plugin-hub__detail-actions">
        ${hasStudio(p) ? '<button type="button" class="su-btn su-btn--primary" id="plugin-hub-open">Abrir Studio</button>' : ''}
        ${p.quarantined ? '<button type="button" class="su-btn" id="plugin-hub-unq">Reativar</button>' : ''}
        ${!hasStudio(p) && !p.quarantined ? '<p class="form-hint">Sem Studio — plugin ativo.</p>' : ''}
      </div>
    `;
    detailEl.querySelector('#plugin-hub-back')?.addEventListener('click', () => {
      detailEl.hidden = true;
      detailEl.innerHTML = '';
      listEl.hidden = false;
    });
    detailEl.querySelector('#plugin-hub-open')?.addEventListener('click', () => {
      closeHub();
      openPluginStudio(app, p.id);
    });
    detailEl.querySelector('#plugin-hub-unq')?.addEventListener('click', async () => {
      await unquarantinePlugin(p.id);
      app?.toast?.('Plugin reativado', 'success');
      renderList();
      detailEl.hidden = true;
      listEl.hidden = false;
    });
  };

  const renderList = () => {
    const enabled = listPluginsDetailed().filter((p) => p.enabled);
    const total = listPluginsDetailed();
    countEl.textContent = `${enabled.length} ativo(s) · ${total.length} instalado(s)`;
    if (!enabled.length) {
      listEl.innerHTML = `
        <p class="form-hint">Nenhum plugin ativo. Ative em Ajustes → Plugins.</p>
        <button type="button" class="su-btn su-btn--primary" id="plugin-hub-goto-set">Ir para Ajustes</button>`;
      listEl.querySelector('#plugin-hub-goto-set')?.addEventListener('click', () => {
        closeHub();
        app?.setView?.('settings');
        try { location.hash = 'settings-plugins'; } catch { /* */ }
      });
      return;
    }
    listEl.innerHTML = enabled.map((p) => {
      const cfg = getPluginConfig(p.id);
      const studio = hasStudio(p);
      return `
        <article class="plugin-hub__card" data-hub-id="${escAttr(p.id)}">
          <div class="plugin-hub__card-main">
            <strong>${esc(p.name || p.id)} ${statusBadge(p)}</strong>
            <span class="muted">v${esc(p.version || '1')} · API ${esc(String(p.api || 2))}</span>
            <p>${esc(cfg?.howTo || p.description || 'Plugin ativo')}</p>
            ${p.lastError ? `<p class="settings-warn form-hint">${esc(p.lastError.message)}</p>` : ''}
          </div>
          <div class="plugin-hub__card-actions">
            ${studio ? `<button type="button" class="su-btn su-btn--primary btn-sm" data-hub-studio="${escAttr(p.id)}">Abrir Studio</button>` : ''}
            ${p.quarantined ? `<button type="button" class="su-btn btn-sm" data-hub-unq="${escAttr(p.id)}">Reativar</button>` : ''}
            <button type="button" class="su-btn btn-sm" data-hub-off="${escAttr(p.id)}" title="Desativar">Off</button>
          </div>
        </article>`;
    }).join('');

    listEl.querySelectorAll('[data-hub-studio]').forEach((btn) => {
      btn.addEventListener('click', () => {
        closeHub();
        openPluginStudio(app, btn.dataset.hubStudio);
      });
    });
    listEl.querySelectorAll('[data-hub-unq]').forEach((btn) => {
      btn.addEventListener('click', async () => {
        await unquarantinePlugin(btn.dataset.hubUnq);
        app?.toast?.('Plugin reativado', 'success');
        renderList();
      });
    });
    listEl.querySelectorAll('[data-hub-off]').forEach((btn) => {
      btn.addEventListener('click', async () => {
        const id = btn.dataset.hubOff;
        const { isPluginStudioView } = await import('./studio/register-plugin-studio.js');
        await setPluginEnabled(id, false);
        app?.toast?.('Plugin desativado', 'info');
        if (isPluginStudioView(app?.view, id)) app?.setView?.('live');
        app?.renderSidebarNav?.();
        renderList();
      });
    });
  };

  renderList();
  if (opts.focusId) {
    const p = listPluginsDetailed().find((x) => x.id === opts.focusId);
    if (p?.enabled) showDetail(p);
  }
  requestAnimationFrame(() => panel.classList.add('is-open'));
}

export { closeHub };
