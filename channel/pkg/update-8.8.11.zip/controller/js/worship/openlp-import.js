/**
 * Import OpenLP XML / JSON service item (U2-E).
 */
import { normalizeSong } from './worship-schema.js';
import { cleanPastedLyrics, detectBlocks } from './worship-parser.js';
import { randomId } from '../core/uuid.js';

function decodeXml(s) {
  return String(s || '')
    .replace(/<!\[CDATA\[([\s\S]*?)\]\]>/gi, '$1')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&amp;/g, '&')
    .replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'")
    .replace(/<br\s*\/?>/gi, '\n')
    .replace(/<\/?[^>]+>/g, '');
}

function textAttr(tag, attr) {
  const m = tag.match(new RegExp(`${attr}="([^"]*)"`, 'i'));
  return m ? decodeXml(m[1]) : '';
}

/**
 * OpenLP song XML (simplified): <song><titles><title>…</title></titles><lyrics><verse>…</verse>
 */
export function parseOpenLpXml(xml) {
  const titleMatch = xml.match(/<title[^>]*>([\s\S]*?)<\/title>/i);
  const title = titleMatch ? decodeXml(titleMatch[1]).trim() : 'Música OpenLP';
  const authorMatch = xml.match(/<author[^>]*>([\s\S]*?)<\/author>/i)
    || xml.match(/authors?="([^"]*)"/i);
  const artist = authorMatch ? decodeXml(authorMatch[1]).trim() : '';

  const verses = [];
  const verseRe = /<verse[^>]*>([\s\S]*?)<\/verse>/gi;
  let m;
  while ((m = verseRe.exec(xml))) {
    const label = textAttr(m[0].slice(0, m[0].indexOf('>') + 1), 'type')
      || textAttr(m[0].slice(0, m[0].indexOf('>') + 1), 'name')
      || textAttr(m[0].slice(0, m[0].indexOf('>') + 1), 'label') || 'v';
    const linesMatch = m[1]?.match?.(/<lines[^>]*>([\s\S]*?)<\/lines>/i);
    const body = decodeXml(linesMatch ? linesMatch[1] : m[1]).trim();
    if (body) verses.push({ label, body });
  }

  // Fallback: <lyrics>…</lyrics> plain
  if (!verses.length) {
    const lyr = xml.match(/<lyrics[^>]*>([\s\S]*?)<\/lyrics>/i);
    if (lyr) {
      const body = decodeXml(lyr[1]).trim();
      if (body) verses.push({ label: 'v1', body });
    }
  }

  const lyrics = verses.map((v) => `[${v.label}]\n${v.body}`).join('\n\n');
  const cleaned = cleanPastedLyrics(lyrics);
  const detected = detectBlocks(cleaned);
  return normalizeSong({
    id: randomId(),
    title,
    artist,
    lyrics: detected.lyrics,
    blocks: detected.blocks,
    tags: ['openlp', 'importado'],
  });
}

export function parseOpenLpJson(obj) {
  const data = typeof obj === 'string' ? JSON.parse(obj) : obj;
  const item = data?.data || data?.serviceitem || data;
  const title = item?.title || item?.name || item?.header?.name || 'Música OpenLP';
  const artist = item?.author || item?.authors || item?.header?.author || '';
  let lyrics = '';
  if (Array.isArray(item?.verses)) {
    lyrics = item.verses.map((v, i) => {
      const label = v.tag || v.label || `v${i + 1}`;
      const text = Array.isArray(v.raw) ? v.raw.join('\n') : (v.text || v.lyrics || '');
      return `[${label}]\n${text}`;
    }).join('\n\n');
  } else if (typeof item?.lyrics === 'string') {
    lyrics = item.lyrics;
  } else if (Array.isArray(item?.slides)) {
    lyrics = item.slides.map((s, i) => `[v${i + 1}]\n${(s.text || s.html || '').replace(/<[^>]+>/g, '')}`).join('\n\n');
  }
  const cleaned = cleanPastedLyrics(lyrics);
  const detected = detectBlocks(cleaned);
  return normalizeSong({
    id: randomId(),
    title: String(title),
    artist: String(artist),
    lyrics: detected.lyrics,
    blocks: detected.blocks,
    tags: ['openlp', 'importado'],
  });
}

export function importOpenLpText(text, { fileName = '' } = {}) {
  const trimmed = String(text || '').trim();
  if (fileName.endsWith('.json') || trimmed.startsWith('{') || trimmed.startsWith('[')) {
    return [parseOpenLpJson(trimmed)];
  }
  if (/<song[\s>]/i.test(trimmed) || /<lyrics[\s>]/i.test(trimmed) || /openlp/i.test(trimmed)) {
    return [parseOpenLpXml(trimmed)];
  }
  throw new Error('Formato OpenLP nao reconhecido');
}
