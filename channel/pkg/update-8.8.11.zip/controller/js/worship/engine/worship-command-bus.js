/**
 * Command bus — dispatch unificado de comandos litúrgicos.
 */
export class WorshipCommandBus {
  constructor({ engine } = {}) {
    this.engine = engine;
    this._handlers = new Map();
    this._registerDefaults();
  }

  _registerDefaults() {
    const nav = (fn) => ({ engine }) => fn(engine);
    this.on('NEXT', nav((e) => e.navigator.next()));
    this.on('PREV', nav((e) => e.navigator.prev()));
    this.on('GOTO_FLAT', ({ engine, payload }) => engine.navigator.goToFlat(payload.index));
    this.on('GOTO_ITEM', ({ engine, payload }) => engine.navigator.goToItem(payload.itemIndex, payload.slideIndex));
    this.on('OVERLAY_BLANK', ({ engine }) => engine.overlay.setBlank());
    this.on('OVERLAY_LOGO', ({ engine }) => engine.overlay.setLogo());
    this.on('OVERLAY_CLEAR', ({ engine }) => engine.overlay.clear());
    this.on('RESTORE_SESSION', ({ engine }) => engine.recovery.restoreSession());
  }

  on(type, handler) {
    this._handlers.set(String(type).toUpperCase(), handler);
  }

  async dispatch(cmd) {
    const type = String(cmd?.type || '').toUpperCase();
    const handler = this._handlers.get(type);
    if (!handler) return { ok: false, error: `unknown command: ${type}` };
    try {
      const result = await handler({ engine: this.engine, payload: cmd.payload || {} });
      this.engine?.state?.patch({ seq: (this.engine.state.snapshot.seq || 0) + 1 });
      this._reportCommand(type);
      return { ok: true, result };
    } catch (err) {
      return { ok: false, error: err?.message || String(err) };
    }
  }

  _reportCommand(type) {
    try {
      fetch('/api/worship/metrics/record', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type, sessionId: this.engine?.state?.snapshot?.sessionId }),
      }).catch(() => {});
    } catch { /* offline */ }
  }
}
