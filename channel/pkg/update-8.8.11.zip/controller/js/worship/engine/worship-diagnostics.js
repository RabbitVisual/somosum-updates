import { getWorshipEngine } from './worship-engine.js';

export async function fetchWorshipMetrics() {
  try {
    const res = await fetch('/api/worship/metrics', { cache: 'no-store' });
    if (!res.ok) return null;
    return await res.json();
  } catch {
    return null;
  }
}

export function buildWorshipDiagnosticsHtml(metrics, engine) {
  const eng = engine || getWorshipEngine();
  const snap = eng?.getSnapshot?.() || {};
  const lines = [
    '<section class="diag-block"><h3>Worship Engine 8.0</h3>',
    '<ul>',
    `<li>Sessão: ${snap.sessionId || '—'}</li>`,
    `<li>Culto: ${snap.cultoId || '—'}</li>`,
    `<li>Fase: ${snap.phase || 'idle'}</li>`,
    `<li>Flat: ${snap.flatIndex ?? 0} · Item: ${snap.itemIndex ?? 0}</li>`,
  ];
  if (metrics) {
    lines.push(`<li>Comandos: ${metrics.commandCount ?? 0}</li>`);
    lines.push(`<li>Último cmd: ${metrics.lastCommand || '—'}</li>`);
    lines.push(`<li>Uptime: ${metrics.uptimeSec ?? 0}s</li>`);
  }
  lines.push('</ul></section>');
  return lines.join('');
}
