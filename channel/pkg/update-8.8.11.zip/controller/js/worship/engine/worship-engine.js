import { WorshipState } from '../services/worship-state.js';
import { WorshipSession } from '../services/worship-session.js';
import { WorshipTimeline } from '../services/worship-timeline.js';
import { WorshipNavigator } from '../services/worship-navigator.js';
import { WorshipHistory } from '../services/worship-history.js';
import { WorshipRecovery } from '../services/worship-recovery.js';
import { WorshipValidation } from '../services/worship-validation.js';
import { WorshipOverlayService } from '../services/worship-overlay-service.js';
import { WorshipScheduler } from '../services/worship-scheduler.js';
import { WorshipCommandBus } from './worship-command-bus.js';
import { wireStateSyncBridge } from '../runtime/state-sync-bridge.js';

let singleton = null;

export class WorshipEngine {
  constructor({ app, role = 'control' } = {}) {
    this.app = app;
    this.role = role;
    this.state = new WorshipState();
    this.session = new WorshipSession({ state: this.state, app });
    this.timeline = new WorshipTimeline({ program: app?.program });
    this.navigator = new WorshipNavigator({ program: app?.program, state: this.state, app });
    this.history = new WorshipHistory();
    this.recovery = new WorshipRecovery({ state: this.state, app, role });
    this.validation = new WorshipValidation({ app });
    this.overlay = new WorshipOverlayService({ program: app?.program, state: this.state, app });
    this.scheduler = new WorshipScheduler();
    this.commandBus = new WorshipCommandBus({ engine: this });
    this._bridge = null;
    this._startedAt = Date.now();
  }

  init() {
    if (this.role === 'control' && this.app) {
      this._bridge = wireStateSyncBridge(this, this.app);
      const cultoId = this.app.cultoIndex?.activeId;
      if (cultoId) this.session.start(cultoId, { phase: 'rehearsal' });
    }
    if (typeof window !== 'undefined') {
      window.SOMOSUM_WORSHIP_ENGINE = this;
    }
    return this;
  }

  command(type, payload) {
    return this.commandBus.dispatch({ type, payload });
  }

  getSnapshot() {
    const ps = this.app?.program?.getState?.() || {};
    return this.state.patch({
      cultoId: this.app?.cultoIndex?.activeId ?? this.state.snapshot.cultoId,
      itemIndex: ps.meta?.itemIndex ?? this.state.snapshot.itemIndex,
      flatIndex: ps.currentIndex ?? this.state.snapshot.flatIndex,
      slide: ps.slide ?? this.state.snapshot.slide,
      overlay: ps.overlay ?? this.state.snapshot.overlay,
    });
  }

  async validate(cultoId) {
    return this.validation.run(cultoId);
  }

  async restoreSession() {
    return this.recovery.restoreSession();
  }

  dispose() {
    this._bridge?.dispose?.();
    if (typeof window !== 'undefined' && window.SOMOSUM_WORSHIP_ENGINE === this) {
      delete window.SOMOSUM_WORSHIP_ENGINE;
    }
  }
}

export function bootstrapWorshipEngine(role = 'control', app = null) {
  if (singleton && singleton.role === role) {
    if (app && !singleton.app) singleton.app = app;
    return singleton;
  }
  singleton = new WorshipEngine({ app, role });
  singleton.init();
  return singleton;
}

export function getWorshipEngine() {
  return singleton;
}
