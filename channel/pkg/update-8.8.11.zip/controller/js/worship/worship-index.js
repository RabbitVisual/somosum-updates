/**
 * Índice invertido para busca instantânea — não percorre toda a tabela a cada query.
 * Rebuild em segundo plano (chunks) para não travar a UI.
 */
import { songSearchText } from './worship-schema.js';
import { parseHinarioQuery, songMatchesHinarioQuery } from './hinario-catalog.js';
import { isSystemDefaultSong } from './default-hinarios.js';

const MIN_TOKEN = 2;
const MAX_RESULTS = 200;

let _tokenIndex = new Map(); // token -> Set<songId>
let _songTokens = new Map(); // songId -> Set<token> — remoção O(tokens)
let _songMeta = new Map();   // songId -> { title, favorite, useCount, lastUsedAt, createdAt }
let _ready = false;
let _building = false;
let _pendingRebuild = null; // { songs, opts, resolve } — fila se rebuild chegar no meio

function tokenize(text) {
  return String(text || '')
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .split(/[^a-z0-9áàâãéêíóôõúüç]+/i)
    .filter((t) => t.length >= MIN_TOKEN);
}

function addToIndex(songId, tokens) {
  for (const token of tokens) {
    if (!_tokenIndex.has(token)) _tokenIndex.set(token, new Set());
    _tokenIndex.get(token).add(songId);
  }
}

export function isIndexReady() {
  return _ready;
}

export function clearIndex() {
  _tokenIndex.clear();
  _songTokens.clear();
  _songMeta.clear();
  _ready = false;
}

function indexTokensForSong(songId, text) {
  const tokens = new Set(tokenize(text));
  const allTok = new Set();
  for (const t of tokens) {
    allTok.add(t);
    addToIndex(songId, [t]);
    // Prefixos 3 e 4 chars — digitação parcial mais coerente
    if (t.length > 3) {
      const p3 = t.slice(0, 3);
      allTok.add(p3);
      addToIndex(songId, [p3]);
    }
    if (t.length > 4) {
      const p4 = t.slice(0, 4);
      allTok.add(p4);
      addToIndex(songId, [p4]);
    }
  }
  _songTokens.set(songId, allTok);
}

/** Rebuild completo — processa em chunks via idle callback. */
export function buildIndexAsync(songs, { onProgress, onDone } = {}) {
  if (_building) {
    return new Promise((resolve) => {
      _pendingRebuild = { songs, opts: { onProgress, onDone }, resolve };
    });
  }
  _building = true;
  clearIndex();

  return new Promise((resolve) => {
    const list = songs || [];
    let i = 0;
    const chunk = 80;

    const finish = () => {
      _ready = true;
      _building = false;
      onDone?.(list.length);
      resolve();
      if (_pendingRebuild) {
        const next = _pendingRebuild;
        _pendingRebuild = null;
        buildIndexAsync(next.songs, next.opts).then(next.resolve);
      }
    };

    const step = () => {
      const end = Math.min(i + chunk, list.length);
      for (; i < end; i++) {
        const song = list[i];
        if (!song?.id) continue;
        _songMeta.set(song.id, {
          title: song.title,
          favorite: !!song.favorite,
          useCount: song.useCount || 0,
          lastUsedAt: song.lastUsedAt || 0,
          createdAt: song.createdAt || 0,
        });
        indexTokensForSong(song.id, songSearchText(song));
      }
      onProgress?.(i, list.length);
      if (i < list.length) {
        if (typeof requestIdleCallback === 'function') {
          requestIdleCallback(step, { timeout: 40 });
        } else {
          setTimeout(step, 0);
        }
      } else {
        finish();
      }
    };

    if (typeof requestIdleCallback === 'function') {
      requestIdleCallback(step, { timeout: 40 });
    } else {
      setTimeout(step, 0);
    }
  });
}

/** Atualiza uma música no índice (O(tokens)) sem rebuild completo. */
export function indexSong(song) {
  if (!song?.id) return;
  removeFromIndex(song.id);
  _songMeta.set(song.id, {
    title: song.title,
    favorite: !!song.favorite,
    useCount: song.useCount || 0,
    lastUsedAt: song.lastUsedAt || 0,
    createdAt: song.createdAt || 0,
  });
  indexTokensForSong(song.id, songSearchText(song));
  // Não marcar ready no meio de rebuild completo (índice parcial)
  if (!_building) _ready = true;
}

export function removeFromIndex(songId) {
  const tokens = _songTokens.get(songId);
  if (tokens) {
    for (const t of tokens) {
      const set = _tokenIndex.get(t);
      if (!set) continue;
      set.delete(songId);
      if (set.size === 0) _tokenIndex.delete(t);
    }
    _songTokens.delete(songId);
  }
  _songMeta.delete(songId);
}

/**
 * Busca com ranking — alvo < 50 ms mesmo com milhares de músicas.
 * @param {string} query
 * @param {object} filters { favorite, category, playlistIds, tab }
 * @param {Map<string,object>} songMap id -> song (para filtros e ordenação)
 */
function songMatchesCategoryFilter(song, category) {
  if (!category) return true;
  if (category === '__none__') return !String(song.category || '').trim();
  const want = String(category).trim().toLowerCase();
  return String(song.category || '').trim().toLowerCase() === want;
}

function songMatchesBrowseFilter(song, filters = {}) {
  if (filters.includeSystemDefaults) return true;
  if (filters.onlySystemDefaults) return isSystemDefaultSong(song);
  if (filters.excludeSystemDefaults && isSystemDefaultSong(song)) return false;
  return true;
}

export function searchSongs(query, filters = {}, songMap = new Map()) {
  const hinarioParsed = parseHinarioQuery(query);
  if (hinarioParsed) {
    const matched = [];
    for (const song of songMap.values()) {
      if (!songMatchesHinarioQuery(song, hinarioParsed)) continue;
      if (filters.favorite && !song.favorite) continue;
      if (!songMatchesCategoryFilter(song, filters.category)) continue;
      matched.push({ song, score: 100 });
    }
    matched.sort((a, b) => (b.song.useCount || 0) - (a.song.useCount || 0));
    return matched.slice(0, MAX_RESULTS).map((m) => m.song);
  }

  const q = String(query || '').trim().toLowerCase()
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '');
  const words = q ? q.split(/\s+/).filter((w) => w.length >= MIN_TOKEN) : [];
  const hasCategory = !!filters.category;
  const hasPlaylist = !!filters.playlistSongIds?.length;
  const tab = filters.tab || 'all';

  let candidateIds = null;

  if (words.length === 0) {
    if (q.length >= 1) {
      // Digitação curta / 1 caractere: varre título/artista
      candidateIds = new Set();
      const needle = q;
      for (const song of songMap.values()) {
        const title = String(song.title || '').toLowerCase()
          .normalize('NFD').replace(/[\u0300-\u036f]/g, '');
        const artist = String(song.artist || '').toLowerCase()
          .normalize('NFD').replace(/[\u0300-\u036f]/g, '');
        if (title.startsWith(needle) || title.includes(needle) || artist.startsWith(needle)) {
          candidateIds.add(song.id);
        }
      }
    } else if (hasCategory || hasPlaylist || tab !== 'all') {
      candidateIds = new Set(songMap.keys());
    } else {
      // Browse vazio: só louvores do usuário (não hinários padrão)
      candidateIds = new Set(
        [...songMap.values()]
          .filter((s) => !isSystemDefaultSong(s))
          .map((s) => s.id),
      );
    }
  } else {
    for (const word of words) {
      const hits = _tokenIndex.get(word);
      if (!hits?.size) {
        // Fallback: prefixo em tokens do índice
        const partial = new Set();
        for (const [token, ids] of _tokenIndex) {
          if (token.startsWith(word)) ids.forEach((id) => partial.add(id));
        }
        if (!partial.size) {
          // Último recurso: substring em título (digitação com typo parcial)
          for (const song of songMap.values()) {
            const title = String(song.title || '').toLowerCase()
              .normalize('NFD').replace(/[\u0300-\u036f]/g, '');
            if (title.includes(word)) partial.add(song.id);
          }
        }
        if (!partial.size) return [];
        candidateIds = candidateIds
          ? new Set([...candidateIds].filter((id) => partial.has(id)))
          : partial;
      } else {
        candidateIds = candidateIds
          ? new Set([...candidateIds].filter((id) => hits.has(id)))
          : new Set(hits);
      }
    }
  }

  if (!candidateIds?.size) return [];

  const playlistSet = filters.playlistSongIds
    ? new Set(filters.playlistSongIds)
    : null;

  const scored = [];
  for (const id of candidateIds) {
    const song = songMap.get(id);
    if (!song) continue;

    if (!songMatchesBrowseFilter(song, filters)) continue;

    if (filters.favorite && !song.favorite) continue;
    if (!songMatchesCategoryFilter(song, filters.category)) continue;
    if (playlistSet && !playlistSet.has(id)) continue;

    if (tab === 'favorites' && !song.favorite) continue;
    if (tab === 'never-used' && (song.useCount || 0) > 0) continue;

    let score = 0;
    const norm = (s) => String(s || '').toLowerCase()
      .normalize('NFD').replace(/[\u0300-\u036f]/g, '');
    const title = norm(song.title);
    const artist = norm(song.artist);
    const ministry = norm(song.ministry);
    const key = norm(song.key);
    const lyricsRaw = song.lyrics || song.lyricsSnippet || '';
    const lyrics = lyricsRaw ? norm(lyricsRaw) : '';
    const searchWords = words.length ? words : (q ? [q] : []);
    if (searchWords.length) {
      for (const w of searchWords) {
        if (title === w) score += 20;
        else if (title.startsWith(w)) score += 12;
        else if (title.includes(w)) score += 6;
        if (artist.startsWith(w)) score += 5;
        else if (artist.includes(w)) score += 3;
        if (ministry.includes(w)) score += 2;
        if (key === w) score += 4;
        if (lyrics && lyrics.includes(w)) score += 2;
      }
    } else {
      score = 1;
    }
    if (song.favorite) score += 2;
    scored.push({ song, score });
  }

  scored.sort((a, b) => {
    if (tab === 'recent') return (b.song.lastUsedAt || 0) - (a.song.lastUsedAt || 0);
    if (tab === 'most-used') return (b.song.useCount || 0) - (a.song.useCount || 0);
    if (tab === 'recently-added') return (b.song.createdAt || 0) - (a.song.createdAt || 0);
    if (b.score !== a.score) return b.score - a.score;
    return (a.song.title || '').localeCompare(b.song.title || '', 'pt-BR');
  });

  return scored.slice(0, MAX_RESULTS).map((s) => s.song);
}

/** Adapter Storage Platform 7.9 — busca unificada (delegação opcional) */
export async function searchViaStoragePlatform(query, opts = {}) {
  const { SearchEngine } = await import('../core/storage/search/search-engine.js');
  const result = await SearchEngine.query({ domain: 'songs', q: query, ...opts });
  return result.items || [];
}
