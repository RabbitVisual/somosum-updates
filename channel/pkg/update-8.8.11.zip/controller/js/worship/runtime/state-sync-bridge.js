/**
 * Bridge Engine ↔ SyncCoordinator / ProjectionBus
 */
export function wireStateSyncBridge(engine, app) {
  if (!engine || !app?.syncCoordinator) return { dispose() {} };

  const unsub = engine.state.subscribe((snap) => {
    try {
      const slide = snap.slide || app.program?.getCurrentSlide?.();
      if (slide) engine.recovery.rememberSlide(slide);
    } catch { /* ignore */ }
  });

  const origEmit = app.syncCoordinator.emit.bind(app.syncCoordinator);
  app.syncCoordinator.emit = (opts = {}) => {
    engine.getSnapshot();
    return origEmit(opts);
  };

  app.worshipEngine = engine;
  app.worshipCommand = (type, payload) => engine.command(type, payload);

  return {
    dispose() {
      unsub?.();
      app.syncCoordinator.emit = origEmit;
    },
  };
}
