import { bootstrapWorshipEngine, getWorshipEngine } from '../engine/worship-engine.js';

/** Adapters read-only para Screen/Stage/Remote. */
export function createSurfaceAdapter(role, app = null) {
  const engine = getWorshipEngine() || bootstrapWorshipEngine(role, app);
  return {
    role,
    getSnapshot: () => engine.getSnapshot(),
    command: (type, payload) => engine.command(type, payload),
    restoreSession: () => engine.restoreSession(),
    failover: () => engine.recovery.failoverScreen(),
    stageRundown: () => engine.recovery.failoverStage(),
  };
}

export const SurfaceAdapters = {
  control(app) { return createSurfaceAdapter('control', app); },
  screen(app) { return createSurfaceAdapter('screen', app); },
  stage(app) { return createSurfaceAdapter('stage', app); },
  remote(app) { return createSurfaceAdapter('remote', app); },
};
