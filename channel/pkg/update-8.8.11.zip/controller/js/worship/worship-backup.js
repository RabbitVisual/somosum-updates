/**
 * Backup automático e recuperação da biblioteca de louvores (offline).
 * Snapshot debounced em worship-library-backup.json — sem APIs externas.
 */
import { DiskAdapter } from '../core/storage/adapters/disk-adapter.js';
import { getAllSongs } from '../core/store.js';
import { normalizeSong } from './worship-schema.js';

const BACKUP_FILE = 'worship-library-backup.json';
const DEBOUNCE_MS = 8000;
let _timer = null;

export async function scheduleWorshipBackup(songs, worshipMeta) {
  clearTimeout(_timer);
  _timer = setTimeout(() => {
    writeBackup(songs, worshipMeta).catch(() => { /* silent */ });
  }, DEBOUNCE_MS);
}

async function writeBackup(_songs, worshipMeta) {
  const fromDb = await getAllSongs();
  const payload = {
    version: 1,
    savedAt: new Date().toISOString(),
    songCount: fromDb?.length || 0,
    songs: (fromDb || []).map((s) => normalizeSong(s)),
    worshipMeta: worshipMeta || null,
  };
  DiskAdapter.saveDebounced(BACKUP_FILE, payload);
}

/** Tenta recuperar biblioteca se dados atuais estiverem vazios ou inválidos. */
export async function recoverWorshipLibraryIfNeeded(currentSongs) {
  const valid = (currentSongs || []).filter((s) => s?.id && s?.title);
  if (valid.length > 0) return { recovered: false, songs: valid };

  try {
    const backup = await DiskAdapter.load(BACKUP_FILE);
    const raw = backup?.songs;
    if (!Array.isArray(raw) || !raw.length) return { recovered: false, songs: [] };

    const songs = raw.map(normalizeSong).filter((s) => s.id && s.title);
    if (!songs.length) return { recovered: false, songs: [] };

    return { recovered: true, songs, worshipMeta: backup.worshipMeta || null };
  } catch {
    return { recovered: false, songs: [] };
  }
}

export async function getWorshipBackupInfo() {
  try {
    const backup = await DiskAdapter.load(BACKUP_FILE);
    return {
      exists: !!backup?.songs?.length,
      savedAt: backup?.savedAt || null,
      songCount: backup?.songCount || backup?.songs?.length || 0,
    };
  } catch {
    return { exists: false, savedAt: null, songCount: 0 };
  }
}
