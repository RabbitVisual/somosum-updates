/**
 * Exportação: TXT, PDF (impressão), DOCX simplificado, formato SOMOSUM (.json).
 */
import { WORSHIP_VERSION } from './worship-schema.js';

export function exportSongTxt(song) {
  const header = [
    song.title,
    song.subtitle,
    song.artist && `Autor: ${song.artist}`,
    song.composer && `Compositor: ${song.composer}`,
    song.ministry && `Ministério: ${song.ministry}`,
    song.key && `Tom: ${song.key}`,
    song.bpm && `BPM: ${song.bpm}`,
    song.category && `Categoria: ${song.category}`,
    song.theme && `Tema: ${song.theme}`,
  ].filter(Boolean).join('\n');

  return `${header}\n${'—'.repeat(40)}\n\n${song.lyrics || ''}`;
}

export function exportSongSomosum(song) {
  return JSON.stringify({
    format: 'somosum-worship',
    version: WORSHIP_VERSION,
    exportedAt: new Date().toISOString(),
    song,
  }, null, 2);
}

export function exportLibrarySomosum(songs) {
  return JSON.stringify({
    format: 'somosum-worship-library',
    version: WORSHIP_VERSION,
    exportedAt: new Date().toISOString(),
    songs,
  }, null, 2);
}

export function downloadText(filename, content, mime = 'text/plain;charset=utf-8') {
  const blob = content instanceof Uint8Array
    ? new Blob([content], { type: mime })
    : new Blob([content], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

/** Abre estúdio de impressão A4 (substitui PDF simples). */
export function exportSongPdf(song) {
  import('./ui/lyrics-print-studio.js').then(({ openLyricsPrintStudio }) => {
    openLyricsPrintStudio({ song });
  });
  return true;
}

/** DOCX mínimo (Open XML) — texto puro, sem formatação avançada. */
export function exportSongDocx(song) {
  const body = `${song.title}\n${song.artist || ''}\n\n${song.lyrics || ''}`;
  const xml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
<w:body><w:p><w:r><w:t xml:space="preserve">${escXml(body)}</w:t></w:r></w:p></w:body></w:document>`;
  const zip = buildMinimalDocx(xml);
  downloadText(safeFilename(song.title) + '.docx', zip, 'application/vnd.openxmlformats-officedocument.wordprocessingml.document');
  return true;
}

function esc(s) {
  return String(s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

function escXml(s) {
  return String(s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

function safeFilename(name) {
  return String(name || 'musica').replace(/[<>:"/\\|?*]/g, '_').slice(0, 80);
}

function buildMinimalDocx(documentXml) {
  const contentTypes = `<?xml version="1.0" encoding="UTF-8"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
<Default Extension="xml" ContentType="application/xml"/>
<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
</Types>`;
  const rels = `<?xml version="1.0" encoding="UTF-8"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="r1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
</Relationships>`;

  const files = {
    '[Content_Types].xml': contentTypes,
    '_rels/.rels': rels,
    'word/document.xml': documentXml,
  };

  return buildZip(files);
}

/** ZIP store-only builder para DOCX. */
function buildZip(files) {
  const parts = [];
  const central = [];
  let offset = 0;
  const enc = new TextEncoder();

  for (const [name, content] of Object.entries(files)) {
    const nameBytes = enc.encode(name);
    const data = enc.encode(content);
    const local = new Uint8Array(30 + nameBytes.length + data.length);
    const dv = new DataView(local.buffer);
    dv.setUint32(0, 0x04034b50, true);
    dv.setUint16(8, 0, true);
    dv.setUint32(18, data.length, true);
    dv.setUint32(22, data.length, true);
    dv.setUint16(26, nameBytes.length, true);
    local.set(nameBytes, 30);
    local.set(data, 30 + nameBytes.length);
    parts.push(local);

    const cd = new Uint8Array(46 + nameBytes.length);
    const cdv = new DataView(cd.buffer);
    cdv.setUint32(0, 0x02014b50, true);
    cdv.setUint16(10, 0, true);
    cdv.setUint32(20, data.length, true);
    cdv.setUint32(24, data.length, true);
    cdv.setUint16(28, nameBytes.length, true);
    cdv.setUint32(42, offset, true);
    cd.set(nameBytes, 46);
    central.push(cd);
    offset += local.length;
  }

  const centralSize = central.reduce((s, c) => s + c.length, 0);
  const end = new Uint8Array(22);
  const edv = new DataView(end.buffer);
  edv.setUint32(0, 0x06054b50, true);
  edv.setUint16(8, central.length, true);
  edv.setUint32(12, centralSize, true);
  edv.setUint32(16, offset, true);

  const total = new Uint8Array(offset + centralSize + 22);
  let pos = 0;
  for (const p of parts) { total.set(p, pos); pos += p.length; }
  for (const c of central) { total.set(c, pos); pos += c.length; }
  total.set(end, pos);
  return total;
}
