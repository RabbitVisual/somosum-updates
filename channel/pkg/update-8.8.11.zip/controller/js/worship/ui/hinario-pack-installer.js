/**
 * Modal de instalação/desinstalação de pacotes de hinários.
 */
import {
  fetchHinarioPackManifest,
  formatPackSize,
  getInstalledHinarioPacks,
  isHinarioPackInstalled,
  formatHinarioPackError,
} from '../hinario-pack-service.js';
import { loadWorshipMeta } from '../worship-meta.js';
import {
  installHinarioPackById,
  uninstallHinarioPackById,
  ensureDefaultHinariosSeeded,
} from '../worship-store.js';

function esc(t) {
  const d = document.createElement('div');
  d.textContent = t ?? '';
  return d.innerHTML;
}

function phaseLabel(phase, pct) {
  if (phase === 'download') return `Lendo pacote… ${pct}%`;
  if (phase === 'extract') return `Descompactando… ${pct}%`;
  if (phase === 'import') return 'Importando hinos…';
  if (phase === 'remove') return 'Removendo hinos…';
  if (phase === 'done') return 'Concluído';
  return 'Preparando…';
}

function setRowProgress(row, phase, pct = 0) {
  const prog = row.querySelector('.hinario-pack-progress');
  const bar = row.querySelector('.hinario-pack-progress-bar span');
  const label = row.querySelector('.hinario-pack-progress-label');
  if (!prog || !bar || !label) return;
  prog.hidden = false;
  label.textContent = phaseLabel(phase, pct);
  const w = phase === 'download' ? pct * 0.55
    : phase === 'extract' ? 55 + pct * 0.25
    : phase === 'import' ? 85
    : phase === 'remove' ? 50 + pct * 0.4
    : 100;
  bar.style.width = `${w}%`;
}

function clearRowProgress(row) {
  row?.querySelector('.hinario-pack-progress')?.setAttribute('hidden', '');
  row?.classList.remove('is-busy');
}

/**
 * @param {{ onInstalled?: () => void, toast?: (msg, type?) => void }} opts
 */
export async function openHinarioPackInstaller(opts = {}) {
  const { onInstalled, toast } = opts;
  let manifest;
  try {
    manifest = await fetchHinarioPackManifest();
  } catch (err) {
    toast?.(formatHinarioPackError(err), 'warn');
    return;
  }

  if (!manifest.packs.length) {
    toast?.('Nenhum hinário disponível no catálogo.', 'warn');
    return;
  }

  let meta = await loadWorshipMeta();
  const hasCdn = !!manifest.cdnBaseUrl;

  const overlay = document.createElement('div');
  overlay.className = 'hinario-pack-overlay';

  const renderList = () => {
    meta = meta || {};
    return manifest.packs.map((p) => {
      const done = isHinarioPackInstalled(meta, p.id);
      const remote = p.remoteOnly ? ' · CDN' : '';
      return `
        <li class="hinario-pack-row ${done ? 'is-installed' : ''}" data-pack-id="${esc(p.id)}">
          <div class="hinario-pack-row-main">
            <span class="hinario-pack-sigla">${esc(p.sigla)}</span>
            <div>
              <strong>${esc(p.name)}</strong>
              <span class="hinario-pack-meta">${p.count} hinos · ${formatPackSize(p.bytes)}${remote}</span>
            </div>
          </div>
          <div class="hinario-pack-row-action">
            ${done
              ? `<button type="button" class="btn btn-ghost btn-sm hinario-pack-uninstall">Remover</button>
                 <span class="hinario-pack-badge">Instalado</span>`
              : `<button type="button" class="btn btn-primary btn-sm hinario-pack-install">Instalar</button>`}
          </div>
          <div class="hinario-pack-progress" hidden>
            <div class="hinario-pack-progress-bar"><span></span></div>
            <span class="hinario-pack-progress-label"></span>
          </div>
        </li>`;
    }).join('');
  };

  overlay.innerHTML = `
    <div class="hinario-pack-dialog" role="dialog" aria-labelledby="hinario-pack-title">
      <header class="hinario-pack-dialog-head">
        <h2 id="hinario-pack-title">Hinários congregacionais</h2>
        <p class="hinario-pack-dialog-sub">Escolha quais hinários instalar na biblioteca. Os pacotes inclusos no SOMOSUM são lidos offline — sem Node nem internet.${hasCdn ? ' Pacotes extras podem ser baixados quando houver conexão.' : ''}</p>
        <button type="button" class="hinario-pack-close" aria-label="Fechar">×</button>
      </header>
      <ul class="hinario-pack-list">${renderList()}</ul>
      <footer class="hinario-pack-dialog-foot">
        <button type="button" class="btn btn-ghost btn-sm" id="hinario-pack-install-all">Instalar todos (offline)</button>
        <button type="button" class="btn btn-ghost hinario-pack-close-foot">Fechar</button>
      </footer>
    </div>`;

  document.body.appendChild(overlay);

  const close = () => overlay.remove();
  overlay.querySelector('.hinario-pack-close')?.addEventListener('click', close);
  overlay.querySelector('.hinario-pack-close-foot')?.addEventListener('click', close);
  overlay.addEventListener('click', (e) => { if (e.target === overlay) close(); });

  const afterChange = async () => {
    meta = await loadWorshipMeta();
    overlay.querySelector('.hinario-pack-list').innerHTML = renderList();
    bindRowActions();
    onInstalled?.();
  };

  async function runInstall(row, packId) {
    if (!packId || row.classList.contains('is-busy')) return;
    row.classList.add('is-busy');
    const btn = row.querySelector('.hinario-pack-install');
    if (btn) btn.disabled = true;
    try {
      const result = await installHinarioPackById(packId, {
        onProgress: (phase, pct) => setRowProgress(row, phase, pct),
      });
      clearRowProgress(row);
      if (result.alreadyInstalled) {
        toast?.(`${result.pack?.name || packId} já estava instalado.`, 'info');
      } else {
        toast?.(`${result.added} hinos de ${result.pack?.name || packId} instalados.`, 'success');
      }
      await afterChange();
    } catch (err) {
      clearRowProgress(row);
      if (btn) btn.disabled = false;
      toast?.(formatHinarioPackError(err), 'warn');
    }
  }

  async function runUninstall(row, packId) {
    if (!packId || row.classList.contains('is-busy')) return;
    const name = manifest.packs.find((p) => p.id === packId)?.name || packId;
    if (!confirm(`Remover "${name}" da biblioteca?\n\nOs hinos deste hinário serão excluídos. Louvores próprios não são afetados.`)) {
      return;
    }
    row.classList.add('is-busy');
    try {
      const result = await uninstallHinarioPackById(packId, {
        onProgress: (phase, pct) => setRowProgress(row, phase, pct),
      });
      clearRowProgress(row);
      if (result.notInstalled) {
        toast?.('Hinário não estava instalado.', 'info');
      } else if (result.empty) {
        toast?.('Registro limpo — nenhum hino encontrado.', 'info');
      } else {
        toast?.(`${result.removed} hinos removidos.`, 'success');
      }
      await afterChange();
    } catch (err) {
      clearRowProgress(row);
      toast?.(formatHinarioPackError(err), 'warn');
    }
  }

  function bindRowActions() {
    overlay.querySelectorAll('.hinario-pack-install').forEach((btn) => {
      btn.replaceWith(btn.cloneNode(true));
    });
    overlay.querySelectorAll('.hinario-pack-uninstall').forEach((btn) => {
      btn.replaceWith(btn.cloneNode(true));
    });

    overlay.querySelectorAll('.hinario-pack-install').forEach((btn) => {
      btn.addEventListener('click', () => {
        const row = btn.closest('.hinario-pack-row');
        void runInstall(row, row?.dataset.packId);
      });
    });
    overlay.querySelectorAll('.hinario-pack-uninstall').forEach((btn) => {
      btn.addEventListener('click', () => {
        const row = btn.closest('.hinario-pack-row');
        void runUninstall(row, row?.dataset.packId);
      });
    });
  }

  bindRowActions();

  overlay.querySelector('#hinario-pack-install-all')?.addEventListener('click', async () => {
    const btn = overlay.querySelector('#hinario-pack-install-all');
    if (btn.disabled) return;
    btn.disabled = true;
    try {
      const result = await ensureDefaultHinariosSeeded({ force: false });
      if (result.errors?.length) {
        toast?.(`Instalados ${result.added} hinos. Alguns falharam: ${result.errors[0].error}`, 'warn');
      } else if (result.added > 0) {
        toast?.(`${result.added} hinos instalados (todos os packs offline).`, 'success');
      } else {
        toast?.('Todos os hinários offline já estavam instalados.', 'info');
      }
      await afterChange();
    } catch (err) {
      toast?.(formatHinarioPackError(err), 'warn');
    } finally {
      btn.disabled = false;
    }
  });
}
