/**
 * Painel de importação/exportação Holyrics (.muf / .mufl).
 */
import {
  importHolyricsMuflFiles,
  encodeHolyricsMuflFromSong,
  holyricsMuflFileName,
  isHolyricsMuflFile,
  createStoreZip,
} from '../holyrics-mufl.js';
import { importWorshipSongsBulk } from '../worship-store.js';
import { getWorshipSongMap } from '../worship-store.js';

function esc(s) {
  return String(s ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function downloadBlob(filename, blob) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

export class HolyricsImportPanel {
  constructor(opts = {}) {
    this.onRefresh = opts.onRefresh;
    this.onPartialRefresh = opts.onPartialRefresh;
    this.onSuspendList = opts.onSuspendList;
    this.onResumeList = opts.onResumeList;
    this.getSelectedSong = opts.getSelectedSong;
    this.onToast = opts.onToast || (() => {});
    this.overlay = null;
    this._busy = false;
    this._cancelled = false;
  }

  open() {
    if (this.overlay) {
      this.overlay.hidden = false;
      return;
    }
    this.mount();
  }

  close() {
    if (this.overlay) this.overlay.hidden = true;
  }

  destroy() {
    this.overlay?.remove();
    this.overlay = null;
  }

  mount() {
    this.overlay = document.createElement('div');
    this.overlay.className = 'holyrics-import-overlay';
    this.overlay.innerHTML = `
      <div class="holyrics-import-dialog" role="dialog" aria-modal="true" aria-labelledby="hip-title">
        <header class="holyrics-import-head">
          <div>
            <p class="holyrics-import-kicker">Holyrics</p>
            <h2 id="hip-title">Importar / exportar .mufl</h2>
            <p class="holyrics-import-lead">Compatível com arquivos exportados pelo Holyrics (Music File *.muf / *.mufl).</p>
          </div>
          <button type="button" class="btn btn-ghost btn-icon" id="hip-close" title="Fechar">×</button>
        </header>

        <div class="holyrics-import-body">
          <section class="holyrics-import-section">
            <h3>Importar em massa</h3>
            <p class="holyrics-import-hint">Selecione uma pasta ou vários arquivos .mufl. Cada arquivo vira um louvor na biblioteca.</p>
            <div class="holyrics-import-actions">
              <label class="btn btn-primary">
                Escolher arquivos .mufl
                <input type="file" id="hip-files" accept=".muf,.mufl" multiple hidden />
              </label>
              <label class="btn btn-secondary">
                Escolher pasta
                <input type="file" id="hip-folder" accept=".muf,.mufl" multiple webkitdirectory hidden />
              </label>
            </div>
          </section>

          <section class="holyrics-import-section">
            <h3>Exportar</h3>
            <p class="holyrics-import-hint">Gera .mufl compatível com Holyrics a partir do louvor selecionado ou de toda a biblioteca do usuário.</p>
            <div class="holyrics-import-actions">
              <button type="button" class="btn btn-secondary" id="hip-export-selected">Exportar selecionado</button>
              <button type="button" class="btn btn-secondary" id="hip-export-all">Exportar biblioteca (ZIP)</button>
            </div>
          </section>

          <div class="holyrics-import-progress-wrap" id="hip-progress-wrap" hidden>
            <div class="holyrics-import-progress-track" aria-hidden="true">
              <div class="holyrics-import-progress-bar" id="hip-progress-bar"></div>
            </div>
            <p class="holyrics-import-progress-label" id="hip-progress-label" aria-live="polite"></p>
            <ul class="holyrics-import-errors" id="hip-errors" hidden></ul>
          </div>
        </div>

        <footer class="holyrics-import-foot">
          <button type="button" class="btn btn-ghost" id="hip-cancel">Fechar</button>
          <button type="button" class="btn btn-danger btn-sm" id="hip-abort" hidden>Interromper</button>
        </footer>
      </div>`;

    document.body.appendChild(this.overlay);

    this.overlay.querySelector('#hip-close').onclick = () => this.close();
    this.overlay.querySelector('#hip-cancel').onclick = () => this.close();
    this.overlay.querySelector('#hip-abort')?.addEventListener('click', () => {
      this._cancelled = true;
      this.setProgress({ label: 'Interrompendo após o lote atual…' });
    });
    this.overlay.addEventListener('click', (e) => {
      if (e.target === this.overlay) this.close();
    });

    this.overlay.querySelector('#hip-files').addEventListener('change', (e) => {
      const files = [...e.target.files || []].filter((f) => isHolyricsMuflFile(f.name));
      e.target.value = '';
      if (files.length) void this.runImport(files);
    });

    this.overlay.querySelector('#hip-folder').addEventListener('change', (e) => {
      const files = [...e.target.files || []].filter((f) => isHolyricsMuflFile(f.name));
      e.target.value = '';
      if (files.length) void this.runImport(files);
    });

    this.overlay.querySelector('#hip-export-selected').onclick = () => void this.exportSelected();
    this.overlay.querySelector('#hip-export-all').onclick = () => void this.exportAll();
  }

  setProgress({ percent = 0, label = '', errors = [] } = {}) {
    const wrap = this.overlay?.querySelector('#hip-progress-wrap');
    const bar = this.overlay?.querySelector('#hip-progress-bar');
    const lbl = this.overlay?.querySelector('#hip-progress-label');
    const errHost = this.overlay?.querySelector('#hip-errors');
    if (!wrap) return;
    wrap.hidden = false;
    if (bar) bar.style.width = `${Math.max(0, Math.min(100, percent))}%`;
    if (lbl) lbl.textContent = label;
    if (errHost) {
      if (errors?.length) {
        errHost.hidden = false;
        errHost.innerHTML = errors.slice(0, 12).map((e) =>
          `<li><strong>${esc(e.file)}</strong> — ${esc(e.message)}</li>`
        ).join('') + (errors.length > 12 ? `<li>… e mais ${errors.length - 12} erro(s)</li>` : '');
      } else {
        errHost.hidden = true;
        errHost.innerHTML = '';
      }
    }
  }

  async runImport(files) {
    if (this._busy) return;
    this._busy = true;
    this._cancelled = false;
    const abortBtn = this.overlay?.querySelector('#hip-abort');
    if (abortBtn) abortBtn.hidden = false;
    this.setProgress({ percent: 0, label: 'Preparando importação…', errors: [] });
    this.onSuspendList?.();

    let totalSaved = 0;
    let allErrors = [];

    try {
      const { songs, errors } = await importHolyricsMuflFiles(files, {
        shouldCancel: () => this._cancelled,
        onProgress: (p) => this.setProgress({ percent: p.percent, label: p.label, errors: [] }),
        onBatch: async (batchSongs) => {
          if (this._cancelled) return;
          const saved = await importWorshipSongsBulk(batchSongs, {
            batchSize: 40,
            onProgress: (p) => this.setProgress({
              percent: Math.min(98, 88 + Math.round(p.percent * 0.1)),
              label: p.label,
            }),
          });
          totalSaved += saved.length;
          await this.onPartialRefresh?.({ imported: totalSaved });
        },
      });
      allErrors = errors;

      if (totalSaved) {
        await this.onRefresh?.({ imported: totalSaved, errors: allErrors });
        this.onToast(`${totalSaved} louvor(es) importado(s)${allErrors.length ? ` · ${allErrors.length} erro(s)` : ''}.`, 'success');
      } else if (songs.length) {
        this.onToast('Nenhuma música nova — todas já existiam na biblioteca.', 'info');
      } else {
        this.onToast('Nenhum arquivo .mufl válido foi importado.', 'warn');
      }

      this.setProgress({
        percent: 100,
        label: `${totalSaved || songs.length} importado(s)${allErrors.length ? ` · ${allErrors.length} erro(s)` : ''}`,
        errors: allErrors,
      });
    } catch (err) {
      this.onToast(err.message || 'Erro na importação Holyrics', 'warn');
      this.setProgress({ percent: 0, label: err.message || 'Erro', errors: allErrors });
    } finally {
      this._busy = false;
      if (abortBtn) abortBtn.hidden = true;
      await this.onResumeList?.({ imported: totalSaved });
    }
  }

  async exportSelected() {
    const song = this.getSelectedSong?.();
    if (!song) {
      this.onToast('Selecione um louvor na biblioteca para exportar.', 'info');
      return;
    }
    await this.exportSongs([song]);
  }

  async exportAll() {
    const songs = [...getWorshipSongMap().values()].filter((s) => !s.protected && !s.systemDefault);
    if (!songs.length) {
      this.onToast('Nenhum louvor do usuário para exportar.', 'info');
      return;
    }
    await this.exportSongs(songs, { zip: true });
  }

  async exportSongs(songs, { zip = false } = {}) {
    if (this._busy) return;
    this._busy = true;
    try {
      if (songs.length === 1 && !zip) {
        const bytes = await encodeHolyricsMuflFromSong(songs[0]);
        downloadBlob(holyricsMuflFileName(songs[0]), new Blob([bytes], { type: 'application/octet-stream' }));
        this.onToast(`Exportado: ${holyricsMuflFileName(songs[0])}`, 'success');
        return;
      }

      const zipEntries = [];
      this.setProgress({ percent: 0, label: 'Gerando arquivos .mufl…' });
      for (let i = 0; i < songs.length; i++) {
        const s = songs[i];
        const bytes = await encodeHolyricsMuflFromSong(s);
        zipEntries.push({ name: holyricsMuflFileName(s), data: bytes });
        this.setProgress({
          percent: Math.round(((i + 1) / songs.length) * 100),
          label: `Exportando ${i + 1}/${songs.length}`,
        });
        if (i % 10 === 9) await new Promise((r) => requestAnimationFrame(r));
      }
      const zipBytes = createStoreZip(zipEntries);
      downloadBlob('biblioteca-holyrics-mufl.zip', new Blob([zipBytes], { type: 'application/zip' }));
      this.onToast(`${songs.length} arquivo(s) .mufl exportado(s) em ZIP.`, 'success');
    } catch (err) {
      this.onToast(err.message || 'Erro ao exportar Holyrics', 'warn');
    } finally {
      this._busy = false;
    }
  }
}

let _panel;

export function openHolyricsImportPanel(opts = {}) {
  if (!_panel) _panel = new HolyricsImportPanel(opts);
  else {
    _panel.onRefresh = opts.onRefresh;
    _panel.onPartialRefresh = opts.onPartialRefresh;
    _panel.onSuspendList = opts.onSuspendList;
    _panel.onResumeList = opts.onResumeList;
    _panel.getSelectedSong = opts.getSelectedSong;
    _panel.onToast = opts.onToast || _panel.onToast;
  }
  _panel.open();
  return _panel;
}
