/**
 * Estúdio de impressão — pipelines separados: Letra | Cifra (estilo Cifra Club).
 */
import {
  PAPER_SPECS,
  paginateLyrics,
  buildPaginatedPagesHtml,
  buildPrintStyles,
  songHasPrintableChords,
} from './lyrics-print-pagination.js';
import {
  paginateCifra,
  buildCifraPagesHtml,
  buildCifraPrintStyles,
} from './cifra-print-render.js';

/** Storages separados — evita conflito entre modos. */
const LYRICS_STORAGE_KEY = 'somosum-lyrics-print-settings';
const CIFRA_STORAGE_KEY = 'somosum-cifra-print-settings';
const MODE_STORAGE_KEY = 'somosum-print-mode';

const BRAND_PRINT = {
  title: '#8a7340',
  artist: '#a89860',
  lyrics: '#1a1a1a',
  muted: '#757575',
  gold: '#d4c68d',
  goldDim: '#a89860',
};

/** Presets Cifra Club: Letras e título / Acordes e artista */
const CIFRA_COLOR_PRESETS = [
  { id: 'black', color: '#424242', label: 'Preto' },
  { id: 'orange', color: '#ff7700', label: 'Laranja' },
  { id: 'magenta', color: '#e91e8c', label: 'Rosa' },
  { id: 'blue', color: '#1e88e5', label: 'Azul' },
  { id: 'green', color: '#43a047', label: 'Verde' },
];

const LYRICS_COLOR_PRESETS = [
  BRAND_PRINT.title, BRAND_PRINT.artist, BRAND_PRINT.gold, BRAND_PRINT.goldDim,
  BRAND_PRINT.lyrics, BRAND_PRINT.muted,
  '#000000', '#434343', '#9e9e9e', '#ffffff',
  '#e81a16', '#f56200', '#58a512', '#0075db',
];

const FONT_FAMILIES = [
  { id: 'Arial', label: 'Arial', class: '--fontFamilyArial', stack: 'Arial, Helvetica, sans-serif' },
  { id: 'Trebuchet', label: 'Trebuchet MS', class: '--fontFamilyTrebuchet', stack: '"Trebuchet MS", sans-serif' },
  { id: 'Verdana', label: 'Verdana', class: '--fontFamilyVerdana', stack: 'Verdana, sans-serif' },
  { id: 'Times', label: 'Times New Roman', class: '--fontFamilyTimes', stack: '"Times New Roman", Times, serif' },
  { id: 'Courier', label: 'Courier New', class: '--fontFamilyCourier', stack: '"Courier New", monospace' },
  { id: 'Georgia', label: 'Georgia', class: '--fontFamilyGeorgia', stack: 'Georgia, serif' },
];

const FONT_SIZE_STEPS = [
  { id: 'small', label: 'Pequeno', class: '--fontSizeSmall', pt: 10 },
  { id: 'medium', label: 'Médio', class: '--fontSizeMedium', pt: 12 },
  { id: 'large', label: 'Grande', class: '--fontSizeLarge', pt: 16 },
  { id: 'xlarge', label: 'Extra', class: '--fontSizeExtraLarge', pt: 20 },
];

const DEFAULT_LYRICS_SETTINGS = {
  paper: 'a4',
  fontFamily: 'Arial',
  fontSizeIndex: 1,
  columns: 2,
  colorTitle: BRAND_PRINT.title,
  colorArtist: BRAND_PRINT.artist,
  colorLyrics: BRAND_PRINT.lyrics,
};

const DEFAULT_CIFRA_SETTINGS = {
  paper: 'a4',
  fontFamily: 'Arial',
  fontSizeIndex: 1,
  includeDiagrams: true,
  /** Cifra Club: Letras e título */
  colorLyricsTitle: '#424242',
  /** Cifra Club: Acordes e artista */
  colorChordsArtist: '#ff7700',
};

function esc(s) {
  return String(s ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function loadJson(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return { ...fallback };
    return { ...fallback, ...JSON.parse(raw) };
  } catch {
    return { ...fallback };
  }
}

function saveJson(key, value) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch { /* ignore */ }
}

function fontContext(settings) {
  const font = FONT_FAMILIES.find((f) => f.id === settings.fontFamily) || FONT_FAMILIES[0];
  const size = FONT_SIZE_STEPS[settings.fontSizeIndex] || FONT_SIZE_STEPS[1];
  return { font: font.class, size: size.class, stack: font.stack, pt: size.pt };
}

/** Normaliza settings de cifra para o renderer. */
function resolveCifraSettings(cifra) {
  return {
    ...cifra,
    includeChords: true,
    columns: 1,
    colorLyrics: cifra.colorLyricsTitle,
    colorTitle: cifra.colorLyricsTitle,
    colorChords: cifra.colorChordsArtist,
    colorArtist: cifra.colorChordsArtist,
  };
}

function buildDocumentHtml(song, mode, lyricsSettings, cifraSettings) {
  const chordOn = mode === 'cifra';
  const settings = chordOn ? resolveCifraSettings(cifraSettings) : { ...lyricsSettings, includeChords: false };
  const ctx = fontContext(settings);
  const pagination = chordOn
    ? paginateCifra(song, settings, { fontStack: ctx.stack, fontPt: ctx.pt })
    : paginateLyrics(song, settings, { fontStack: ctx.stack, fontPt: ctx.pt });
  const pagesHtml = chordOn
    ? buildCifraPagesHtml(song, settings, ctx, pagination)
    : buildPaginatedPagesHtml(song, settings, ctx, pagination);
  const paper = pagination.paper;

  return `<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<title>${esc(song.title)} — Impressão${chordOn ? ' (cifra)' : ''}</title>
<style>${chordOn ? buildCifraPrintStyles(paper, ctx.stack, ctx.pt) : buildPrintStyles(paper, ctx.stack, ctx.pt, { chordMode: false })}</style>
</head>
<body>${pagesHtml}
<script>
(function(){
  function go(){ try { window.focus(); window.print(); } catch(e) {} }
  if (document.readyState === 'complete') setTimeout(go, 120);
  else window.addEventListener('load', function(){ setTimeout(go, 120); });
})();
</script>
</body></html>`;
}

function colorDotsHtml(presets, current, target) {
  return `
    <div class="lps-cc-swatches" data-color-group="${esc(target)}">
      ${presets.map((p) => {
        const on = String(current).toLowerCase() === p.color.toLowerCase();
        return `<button type="button" class="lps-cc-dot ${on ? 'is-on' : ''}" data-color-target="${esc(target)}" data-color="${esc(p.color)}" style="--dot:${esc(p.color)}" title="${esc(p.label)}" aria-label="${esc(p.label)}"></button>`;
      }).join('')}
      <label class="lps-cc-dot lps-cc-dot--custom" title="Cor personalizada">
        <input type="color" data-color-input="${esc(target)}" value="${esc(current)}" />
      </label>
    </div>`;
}

class LyricsPrintStudio {
  constructor(opts = {}) {
    this.song = opts.song;
    this.onToast = opts.onToast || (() => {});
    this.lyricsSettings = loadJson(LYRICS_STORAGE_KEY, DEFAULT_LYRICS_SETTINGS);
    this.cifraSettings = loadJson(CIFRA_STORAGE_KEY, DEFAULT_CIFRA_SETTINGS);
    this.mode = localStorage.getItem(MODE_STORAGE_KEY) === 'cifra' ? 'cifra' : 'lyrics';
    this.overlay = null;
    this._pagination = null;
  }

  get settings() {
    return this.mode === 'cifra' ? this.cifraSettings : this.lyricsSettings;
  }

  open(song) {
    if (song) this.song = song;
    const hasLyrics = !!this.song?.lyrics?.trim();
    const hasChords = songHasPrintableChords(this.song);
    if (!hasLyrics && !hasChords) {
      this.onToast('Esta música não tem letra nem cifra para imprimir.', 'warn');
      return;
    }
    if (!hasLyrics && hasChords) this.mode = 'cifra';
    if (this.mode === 'cifra' && !hasChords) this.mode = 'lyrics';
    if (this.overlay) {
      this.overlay.hidden = false;
      this.renderConfig();
      this.renderPreview();
      return;
    }
    this.mount();
  }

  close() {
    if (this.overlay) this.overlay.hidden = true;
  }

  destroy() {
    this.overlay?.remove();
    this.overlay = null;
  }

  mount() {
    this.overlay = document.createElement('div');
    this.overlay.className = 'lps-overlay';
    this.overlay.innerHTML = `
      <div class="lps-shell" role="dialog" aria-modal="true" aria-labelledby="lps-title">
        <header class="lps-head">
          <div>
            <p class="lps-kicker">Impressão</p>
            <h2 id="lps-title">Letra para papel</h2>
            <p class="lps-lead">Letra e cifra são configurações separadas — sem misturar layouts.</p>
          </div>
          <button type="button" class="btn btn-ghost btn-icon" id="lps-close" title="Fechar">×</button>
        </header>
        <div class="lps-workspace">
          <div class="lps-preview-host" id="lps-preview"></div>
          <aside class="lps-config su-light-surface" id="lps-config"></aside>
        </div>
      </div>`;

    document.body.appendChild(this.overlay);
    this.overlay.querySelector('#lps-close').onclick = () => this.close();
    this.overlay.addEventListener('click', (e) => {
      if (e.target === this.overlay) this.close();
    });
    this.renderConfig();
    this.renderPreview();
  }

  setMode(mode) {
    const hasChords = songHasPrintableChords(this.song);
    if (mode === 'cifra' && !hasChords) {
      this.onToast('Esta música não tem cifra ChordPro.', 'warn');
      return;
    }
    this.mode = mode === 'cifra' ? 'cifra' : 'lyrics';
    try { localStorage.setItem(MODE_STORAGE_KEY, this.mode); } catch { /* ignore */ }
    this.persistAndRefresh();
  }

  persistAndRefresh() {
    saveJson(LYRICS_STORAGE_KEY, this.lyricsSettings);
    saveJson(CIFRA_STORAGE_KEY, this.cifraSettings);
    this.renderPreview();
    this.renderConfig();
  }

  renderConfig() {
    const host = this.overlay?.querySelector('#lps-config');
    if (!host) return;
    const hasChords = songHasPrintableChords(this.song);
    const chordOn = this.mode === 'cifra' && hasChords;
    const s = chordOn ? this.cifraSettings : this.lyricsSettings;
    const sizeLabel = FONT_SIZE_STEPS[s.fontSizeIndex]?.label || 'Médio';
    const pageInfo = this._pagination
      ? `${this._pagination.totalPages} folha(s) · ${PAPER_SPECS[s.paper]?.label || 'A4'}${chordOn ? ' · cifra' : ''}`
      : '';

    if (chordOn) {
      host.innerHTML = this.renderCifraConfig(s, hasChords, pageInfo);
    } else {
      host.innerHTML = this.renderLyricsConfig(s, hasChords, pageInfo);
    }
    this.bindConfig(host, chordOn);
  }

  renderCifraConfig(s, hasChords, pageInfo) {
    const sizeLabel = FONT_SIZE_STEPS[s.fontSizeIndex]?.label || 'Médio';
    return `
      ${pageInfo ? `<p class="lps-config-pages">${esc(pageInfo)}</p>` : ''}
      <section class="lps-config-block">
        <label class="lps-config-label">Conteúdo</label>
        <div class="lps-config-row lps-content-toggle">
          <button type="button" class="lps-mode-btn" data-mode="lyrics">Letra</button>
          <button type="button" class="lps-mode-btn is-on" data-mode="chords">Cifra</button>
        </div>
        <p class="lps-config-hint">Painel dedicado · estilo Cifra Club · 1 coluna.</p>
      </section>
      <section class="lps-config-block">
        <label class="lps-config-label">Papel</label>
        <div class="lps-config-row">
          ${Object.values(PAPER_SPECS).map((p) =>
            `<button type="button" class="lps-paper-btn ${s.paper === p.id ? 'is-on' : ''}" data-paper="${p.id}">${p.label}</button>`
          ).join('')}
        </div>
      </section>
      <section class="lps-config-block lps-cc-colors">
        <label class="lps-config-label">Letras e título</label>
        ${colorDotsHtml(CIFRA_COLOR_PRESETS, s.colorLyricsTitle, 'colorLyricsTitle')}
        <label class="lps-config-label">Acordes e artista</label>
        ${colorDotsHtml(CIFRA_COLOR_PRESETS, s.colorChordsArtist, 'colorChordsArtist')}
      </section>
      <section class="lps-config-block">
        <label class="lps-config-label">Tamanho · ${sizeLabel}</label>
        <div class="lps-cc-pill">
          <button type="button" class="lps-cc-pill-btn" data-size="-" title="Diminuir">A</button>
          <span class="lps-cc-pill-label">texto</span>
          <button type="button" class="lps-cc-pill-btn lps-cc-pill-btn--lg" data-size="+" title="Aumentar">A</button>
        </div>
      </section>
      <section class="lps-config-block">
        <button type="button" class="lps-cc-toggle ${s.includeDiagrams !== false ? 'is-on' : ''}" id="lps-diagrams" title="Diagramas de acordes">
          <span class="lps-cc-toggle-icon" aria-hidden="true">▦</span>
          ${s.includeDiagrams !== false ? 'exibir diagramas' : 'ocultar diagramas'}
        </button>
      </section>
      <section class="lps-config-block lps-config-actions">
        <button type="button" class="btn btn-primary lps-print-btn" id="lps-print">imprimir</button>
        <button type="button" class="btn btn-ghost lps-reset-btn" id="lps-reset">resetar configurações</button>
      </section>`;
  }

  renderLyricsConfig(s, hasChords, pageInfo) {
    return `
      ${pageInfo ? `<p class="lps-config-pages">${esc(pageInfo)}</p>` : ''}
      <section class="lps-config-block">
        <label class="lps-config-label">Conteúdo</label>
        <div class="lps-config-row lps-content-toggle">
          <button type="button" class="lps-mode-btn is-on" data-mode="lyrics">Letra</button>
          <button type="button" class="lps-mode-btn" data-mode="chords" ${hasChords ? '' : 'disabled'} title="${hasChords ? 'Cifra com acordes' : 'Sem cifra nesta música'}">Cifra</button>
        </div>
        ${!hasChords ? '<p class="lps-config-hint">Sem cifra — adicione na aba Cifra do editor.</p>' : '<p class="lps-config-hint">Só letra · colunas e cores independentes da cifra.</p>'}
      </section>
      <section class="lps-config-block">
        <label class="lps-config-label">Papel</label>
        <div class="lps-config-row">
          ${Object.values(PAPER_SPECS).map((p) =>
            `<button type="button" class="lps-paper-btn ${s.paper === p.id ? 'is-on' : ''}" data-paper="${p.id}">${p.label}</button>`
          ).join('')}
        </div>
      </section>
      <section class="lps-config-block">
        <label class="lps-config-label">Fonte</label>
        <select class="lps-select" id="lps-font">
          ${FONT_FAMILIES.map((f) =>
            `<option value="${f.id}" ${s.fontFamily === f.id ? 'selected' : ''}>${f.label}</option>`
          ).join('')}
        </select>
        <label class="lps-config-label">Tamanho · ${FONT_SIZE_STEPS[s.fontSizeIndex]?.label || 'Médio'}</label>
        <div class="lps-config-row">
          <button type="button" class="lps-size-btn" data-size="-">A−</button>
          <button type="button" class="lps-size-btn" data-size="+">A+</button>
        </div>
      </section>
      <section class="lps-config-block lps-config-colors">
        <div class="lps-color-field">
          <label class="lps-config-label">Música</label>
          <button type="button" class="lps-color-btn" data-color-target="colorTitle" style="--swatch:${esc(s.colorTitle)}"></button>
        </div>
        <div class="lps-color-field">
          <label class="lps-config-label">Artista</label>
          <button type="button" class="lps-color-btn" data-color-target="colorArtist" style="--swatch:${esc(s.colorArtist)}"></button>
        </div>
        <div class="lps-color-field">
          <label class="lps-config-label">Letra</label>
          <button type="button" class="lps-color-btn" data-color-target="colorLyrics" style="--swatch:${esc(s.colorLyrics)}"></button>
        </div>
      </section>
      <section class="lps-config-block">
        <label class="lps-config-label">Colunas</label>
        <div class="lps-config-row">
          <button type="button" class="lps-col-btn ${s.columns === 1 ? 'is-on' : ''}" data-cols="1">▭</button>
          <button type="button" class="lps-col-btn ${s.columns === 2 ? 'is-on' : ''}" data-cols="2">▭▭</button>
        </div>
      </section>
      <section class="lps-config-block lps-config-actions">
        <button type="button" class="btn btn-primary lps-print-btn" id="lps-print">Imprimir</button>
        <button type="button" class="btn btn-ghost lps-reset-btn" id="lps-reset">Resetar configurações</button>
      </section>
      <div class="lps-palette" id="lps-palette" hidden>
        <div class="lps-palette-grid">
          ${LYRICS_COLOR_PRESETS.map((c) => `<button type="button" class="lps-swatch" data-color="${c}" style="background:${c}" title="${c}"></button>`).join('')}
          <label class="lps-swatch lps-swatch-custom" title="Cor personalizada">
            <input type="color" id="lps-color-input" value="#2a2a2a" hidden />…
          </label>
        </div>
      </div>`;
  }

  bindConfig(host, chordOn) {
    host.querySelectorAll('[data-mode]').forEach((btn) => {
      btn.onclick = () => {
        if (btn.disabled) return;
        this.setMode(btn.dataset.mode === 'chords' ? 'cifra' : 'lyrics');
      };
    });

    host.querySelectorAll('[data-paper]').forEach((btn) => {
      btn.onclick = () => {
        this.settings.paper = btn.dataset.paper;
        this.persistAndRefresh();
      };
    });

    host.querySelectorAll('[data-size]').forEach((btn) => {
      btn.onclick = () => {
        const delta = btn.dataset.size === '+' ? 1 : -1;
        this.settings.fontSizeIndex = Math.max(0, Math.min(FONT_SIZE_STEPS.length - 1, this.settings.fontSizeIndex + delta));
        this.persistAndRefresh();
      };
    });

    if (chordOn) {
      host.querySelector('#lps-diagrams')?.addEventListener('click', () => {
        const on = this.cifraSettings.includeDiagrams !== false;
        this.cifraSettings.includeDiagrams = !on;
        this.persistAndRefresh();
      });
      host.querySelectorAll('.lps-cc-dot[data-color]').forEach((btn) => {
        btn.onclick = () => {
          const key = btn.dataset.colorTarget;
          if (!key) return;
          this.cifraSettings[key] = btn.dataset.color;
          this.persistAndRefresh();
        };
      });
      host.querySelectorAll('[data-color-input]').forEach((input) => {
        input.addEventListener('input', (e) => {
          const key = e.target.dataset.colorInput;
          if (!key) return;
          this.cifraSettings[key] = e.target.value;
          this.persistAndRefresh();
        });
      });
      host.querySelector('#lps-reset').onclick = () => {
        this.cifraSettings = { ...DEFAULT_CIFRA_SETTINGS };
        this.persistAndRefresh();
        this.onToast('Configurações de cifra restauradas.', 'info');
      };
    } else {
      host.querySelector('#lps-font')?.addEventListener('change', (e) => {
        this.lyricsSettings.fontFamily = e.target.value;
        this.persistAndRefresh();
      });
      host.querySelectorAll('[data-cols]').forEach((btn) => {
        btn.onclick = () => {
          this.lyricsSettings.columns = Number(btn.dataset.cols);
          this.persistAndRefresh();
        };
      });
      let colorTarget = null;
      host.querySelectorAll('[data-color-target]').forEach((btn) => {
        btn.onclick = () => {
          colorTarget = btn.dataset.colorTarget;
          const pal = host.querySelector('#lps-palette');
          if (pal) pal.hidden = !pal.hidden;
        };
      });
      host.querySelectorAll('.lps-swatch[data-color]').forEach((btn) => {
        btn.onclick = () => {
          if (!colorTarget) return;
          this.lyricsSettings[colorTarget] = btn.dataset.color;
          host.querySelector('#lps-palette').hidden = true;
          this.persistAndRefresh();
        };
      });
      host.querySelector('#lps-color-input')?.addEventListener('input', (e) => {
        if (!colorTarget) return;
        this.lyricsSettings[colorTarget] = e.target.value;
        this.persistAndRefresh();
      });
      host.querySelector('#lps-reset').onclick = () => {
        this.lyricsSettings = { ...DEFAULT_LYRICS_SETTINGS };
        this.persistAndRefresh();
        this.onToast('Configurações de letra restauradas.', 'info');
      };
    }

    host.querySelector('#lps-print').onclick = () => this.print();
  }

  renderPreview() {
    const host = this.overlay?.querySelector('#lps-preview');
    if (!host || !this.song) return;
    const chordOn = this.mode === 'cifra' && songHasPrintableChords(this.song);
    const settings = chordOn
      ? resolveCifraSettings(this.cifraSettings)
      : { ...this.lyricsSettings, includeChords: false };
    const ctx = fontContext(settings);
    this._pagination = chordOn
      ? paginateCifra(this.song, settings, { fontStack: ctx.stack, fontPt: ctx.pt })
      : paginateLyrics(this.song, settings, { fontStack: ctx.stack, fontPt: ctx.pt });
    const paper = this._pagination.paper;
    const pagesHtml = chordOn
      ? buildCifraPagesHtml(this.song, settings, ctx, this._pagination)
      : buildPaginatedPagesHtml(this.song, settings, ctx, this._pagination);
    host.innerHTML = `<div class="lps-pages-stack" style="--lps-page-h:${paper.heightMm}mm">${pagesHtml}</div>`;
  }

  print() {
    const html = buildDocumentHtml(this.song, this.mode, this.lyricsSettings, this.cifraSettings);
    let w = null;
    try {
      const blob = new Blob([html], { type: 'text/html;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      w = window.open(url, '_blank', 'width=900,height=700');
      if (w) setTimeout(() => URL.revokeObjectURL(url), 60_000);
      else URL.revokeObjectURL(url);
    } catch {
      w = null;
    }

    if (!w) {
      w = window.open('', '_blank', 'width=900,height=700');
      if (!w) {
        this.onToast('Permita pop-ups para imprimir.', 'warn');
        return;
      }
      w.document.open();
      w.document.write(html);
      w.document.close();
    }

    try { w.focus(); } catch { /* ignore */ }
    const n = this._pagination?.totalPages || 1;
    this.onToast(`Impressão aberta — ${n} folha(s).`, 'success');
  }
}

let _studio;

export function openLyricsPrintStudio(opts = {}) {
  if (!_studio) _studio = new LyricsPrintStudio(opts);
  else {
    _studio.onToast = opts.onToast || _studio.onToast;
    if (opts.song) _studio.song = opts.song;
  }
  _studio.open(opts.song);
  return _studio;
}

export function exportSongPrint(song) {
  openLyricsPrintStudio({ song });
  return true;
}

export { PAPER_SPECS, paginateLyrics, splitLyricsColumns } from './lyrics-print-pagination.js';
