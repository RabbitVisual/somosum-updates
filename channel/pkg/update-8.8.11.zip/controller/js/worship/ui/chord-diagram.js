/**
 * Diagramas de acordes SVG — layout Cifra Club (X/O acima do nut, sem sobreposição).
 */
import { parseChordPro } from '../chordpro-parser.js';

const CHORD_NAME_RE = /\b([A-G][#b]?(?:maj|min|m|dim|aug|sus|add|maj7|m7|7|9|11|13|6|º|°|\d)*(?:\/[A-G][#b]?)?)\b/gi;

/** Fallback de mounts comuns quando o HTML não traz diagramas. */
export const COMMON_CHORD_SHAPES = {
  C: 'X 3 2 0 1 0',
  C4: 'X 3 3 0 1 X',
  C9: 'X 3 5 5 3 3',
  G: '3 2 0 0 0 3',
  'G/B': 'X 2 0 0 0 3',
  G4: '3 5 5 5 3 3',
  Am: 'X 0 2 2 1 0',
  Am7: 'X 0 2 0 1 0',
  F: '1 3 3 2 1 1',
  F9: '1 3 5 2 1 1',
  D: 'X X 0 2 3 2',
  Dm: 'X X 0 2 3 1',
  Em: '0 2 2 0 0 0',
  E: '0 2 2 1 0 0',
  Bm: 'X 2 4 4 3 2',
  B7: 'X 2 1 2 0 2',
  A: 'X 0 2 2 2 0',
  'C/G': '3 3 2 0 1 0',
  'Am/G': '3 0 2 2 1 0',
  'D7/F#': '2 X 0 2 1 2',
};

function esc(s) {
  return String(s ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

/** Parse mount Cifra Club: "X 0 2 0 1 0" (6ª→1ª corda). */
export function parseMount(mount) {
  return String(mount || '').trim().split(/\s+/).slice(0, 6);
}

function normalizeName(name) {
  return String(name || '').trim();
}

/** Coleta acordes únicos do ChordPro + shapes salvos + fallback. */
export function collectUniqueChords(chordSource, savedShapes = []) {
  const map = new Map();
  for (const s of savedShapes || []) {
    const n = normalizeName(s.name);
    if (n && s.mount) map.set(n, { name: n, mount: s.mount, tuning: s.tuning || 'E A D G B E' });
  }

  const parsed = parseChordPro(chordSource || '');
  for (const row of parsed.lines) {
    for (const ch of row.chords || []) {
      const n = normalizeName(ch);
      if (!n || map.has(n)) continue;
      const mount = COMMON_CHORD_SHAPES[n];
      if (mount) map.set(n, { name: n, mount, tuning: 'E A D G B E' });
    }
  }

  const src = String(chordSource || '');
  let m;
  const re = new RegExp(CHORD_NAME_RE.source, 'gi');
  while ((m = re.exec(src)) !== null) {
    const n = normalizeName(m[1]);
    if (!n || map.has(n)) continue;
    const mount = COMMON_CHORD_SHAPES[n];
    if (mount) map.set(n, { name: n, mount, tuning: 'E A D G B E' });
  }

  return [...map.values()];
}

/**
 * Diagrama estilo Cifra Club:
 *   Nome
 *   X o   o     ← mutada/aberta ACIMA do nut (nunca sob o nome)
 *   ═══════
 *   | | ● | |
 */
export function renderChordDiagramSvg(shape, opts = {}) {
  const name = normalizeName(shape?.name);
  const frets = parseMount(shape?.mount);
  if (!name || frets.length < 6) return '';

  const accent = opts.accent || '#f70';
  const w = 78;
  const h = 108;
  const padX = 14;
  const nameY = 13;
  const markerY = 28;
  const nutY = 36;
  const gridH = 52;
  const gridW = w - padX * 2;
  const stringGap = gridW / 5;
  const fretGap = gridH / 4;

  const nums = frets.map((f) => {
    if (/^x$/i.test(f)) return -1;
    const n = Number(f);
    return Number.isFinite(n) ? n : 0;
  });

  let baseFret = 1;
  const played = nums.filter((n) => n > 0);
  if (played.length && Math.min(...played) > 1) baseFret = Math.min(...played);

  // Pestana: cordas consecutivas no mesmo traste relativo
  let barre = null;
  if (played.length >= 3) {
    const atBase = [];
    for (let s = 0; s < 6; s += 1) {
      if (nums[s] === baseFret) atBase.push(s);
    }
    if (atBase.length >= 3 && atBase[atBase.length - 1] - atBase[0] + 1 === atBase.length) {
      barre = { from: atBase[0], to: atBase[atBase.length - 1], fret: 1 };
    }
  }

  const parts = [];
  parts.push(`<svg class="lps-chord-diagram" viewBox="0 0 ${w} ${h}" width="${w}" height="${h}" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="${esc(name)}">`);

  // Nome — bem acima dos marcadores X/O
  parts.push(`<text x="${w / 2}" y="${nameY}" text-anchor="middle" class="lps-chord-diagram-name" fill="${accent}" font-family="Arial, Helvetica, sans-serif" font-size="12" font-weight="700">${esc(name)}</text>`);

  if (baseFret > 1) {
    parts.push(`<text x="${padX - 6}" y="${nutY + fretGap * 0.7}" text-anchor="end" font-family="Arial, Helvetica, sans-serif" font-size="9" fill="#757575">${baseFret}ª</text>`);
  }

  // X / O acima do nut, abaixo do nome (espaço dedicado)
  for (let s = 0; s < 6; s += 1) {
    const val = nums[s];
    const x = padX + s * stringGap;
    if (val < 0) {
      parts.push(`<text x="${x}" y="${markerY}" text-anchor="middle" font-family="Arial, Helvetica, sans-serif" font-size="11" font-weight="600" fill="#9e9e9e">×</text>`);
    } else if (val === 0) {
      parts.push(`<circle cx="${x}" cy="${markerY - 3}" r="3.2" fill="none" stroke="#757575" stroke-width="1.2"/>`);
    }
  }

  // Nut
  parts.push(`<rect x="${padX}" y="${nutY}" width="${gridW}" height="3.5" fill="#424242" rx="0.5"/>`);

  // Cordas
  for (let s = 0; s < 6; s += 1) {
    const x = padX + s * stringGap;
    parts.push(`<line x1="${x}" y1="${nutY}" x2="${x}" y2="${nutY + gridH}" stroke="#bdbdbd" stroke-width="1"/>`);
  }
  // Trastes
  for (let f = 1; f <= 4; f += 1) {
    const y = nutY + f * fretGap;
    parts.push(`<line x1="${padX}" y1="${y}" x2="${padX + gridW}" y2="${y}" stroke="#e0e0e0" stroke-width="1"/>`);
  }

  // Pestana
  if (barre) {
    const x1 = padX + barre.from * stringGap;
    const x2 = padX + barre.to * stringGap;
    const cy = nutY + (barre.fret - 0.5) * fretGap;
    parts.push(`<rect x="${x1 - 4.5}" y="${cy - 4}" width="${x2 - x1 + 9}" height="8" rx="4" fill="${accent}"/>`);
  }

  // Dedos
  for (let s = 0; s < 6; s += 1) {
    const val = nums[s];
    if (val <= 0) continue;
    if (barre && val === baseFret && s >= barre.from && s <= barre.to) continue;
    const rel = val - baseFret + 1;
    if (rel < 1 || rel > 4) continue;
    const x = padX + s * stringGap;
    const cy = nutY + (rel - 0.5) * fretGap;
    parts.push(`<circle cx="${x}" cy="${cy}" r="5" fill="${accent}"/>`);
  }

  parts.push('</svg>');
  return parts.join('');
}

export function renderChordDiagramsGrid(shapes, opts = {}) {
  if (!shapes?.length) return '';
  const items = shapes.map((s) =>
    `<li class="lps-chord-diagram-item">${renderChordDiagramSvg(s, opts)}</li>`
  ).join('');
  return `<section class="lps-chord-diagrams" aria-label="Diagramas de acordes"><ul class="lps-chord-diagrams-grid">${items}</ul></section>`;
}
