/**
 * Render e paginação de cifra para impressão — estilo Cifra Club + SOMOSUM.
 * Unidade atômica: par acorde+letra (nunca quebra entre folhas).
 */
import { PRODUCT_LOGO, PRODUCT_LOGO_REL } from '../../core/brand-assets.js';
import { parseChordPro } from '../chordpro-parser.js';
import { parseTabLine } from '../../screen/stage-chord-render.js';
import {
  PAPER_SPECS,
  paperContentBox,
  composerLine,
} from './lyrics-print-pagination.js';
import { collectUniqueChords, renderChordDiagramsGrid } from './chord-diagram.js';

const CHORD_TOKEN = /^[A-G][#b]?(?:maj|min|m|dim|aug|sus|add|maj7|m7|7|9|11|13|6|º|°|\d)*(?:\/[A-G][#b]?)?$/i;
const DIRECTIVE = /^\{([^}:]+)(?::\s*(.*))?\}$/;
const TAB_PART_RE = /^parte\s+\d+/i;

function esc(s) {
  return String(s ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function mmToPx(mm) {
  return (mm * 96) / 25.4;
}

function productLogoUrl() {
  if (typeof location === 'undefined') return PRODUCT_LOGO;
  const path = PRODUCT_LOGO.startsWith('/') ? PRODUCT_LOGO : `/${PRODUCT_LOGO_REL}`;
  return `${location.origin}${path}`;
}

function chordRowFromParsed(row) {
  const lyric = row?.lyric || '';
  const chords = row?.chords || [];
  let chordLine = '';
  for (let i = 0; i < Math.max(chords.length, lyric.length); i += 1) {
    const ch = chords[i] || '';
    if (!ch) continue;
    // Evita colisão (ex.: Cº cobrindo o próximo acorde)
    if (chordLine.length > i) chordLine += ' ';
    while (chordLine.length < i) chordLine += ' ';
    chordLine += ch;
  }
  return { chordLine: chordLine.trimEnd(), lyric };
}

function isSectionBracket(name) {
  const n = String(name || '').trim();
  if (!n) return false;
  if (/^[A-G][#b]?(?:maj|min|m|dim|aug|sus|add|maj7|m7|M7|7|9|11|13|6|º|°|\d)*(?:\/[A-G][#b]?)?$/i.test(n)) {
    return false;
  }
  if (/^tab\s/i.test(n) || /tab\s-/i.test(n)) return true;
  if (/parte|intro|refr|solo|verso|ponte|final|outro|coro/i.test(n)) return true;
  if (n.includes(' ') && !/^[A-G][#b]?/.test(n)) return true;
  return n.length > 2;
}

/** Converte ChordPro em blocos atômicos para impressão. */
export function parseCifraPrintBlocks(source) {
  const raw = String(source || '').replace(/\r\n/g, '\n');
  const lines = raw.split('\n');
  const blocks = [];
  const meta = { key: '', capo: null, tuning: 'E A D G B E' };
  let tabGroup = null;

  const flushTab = () => { tabGroup = null; };

  for (const line of lines) {
    const trimmed = line.trim();

    const dir = trimmed.match(DIRECTIVE);
    if (dir) {
      flushTab();
      const name = dir[1].toLowerCase();
      const val = (dir[2] || '').trim();
      if (name === 'key' || name === 'k') meta.key = val;
      else if (name === 'capo') meta.capo = Number(val) || 0;
      else if (name === 'tuning') meta.tuning = /^[EADGBe](?:\s+[EADGBe]){5}$/i.test(val)
        ? val.replace(/\s+/g, ' ').toUpperCase()
        : 'E A D G B E';
      continue;
    }

    if (!trimmed) {
      flushTab();
      blocks.push({ type: 'blank' });
      continue;
    }

    if (TAB_PART_RE.test(trimmed)) {
      tabGroup = { type: 'tab', label: trimmed, rows: [], annotations: [] };
      blocks.push(tabGroup);
      continue;
    }

    const tabRow = parseTabLine(trimmed);
    if (tabRow) {
      if (!tabGroup) {
        tabGroup = { type: 'tab', label: '', rows: [], annotations: [] };
        blocks.push(tabGroup);
      }
      for (const ch of [...(tabRow.leadingChords || []), ...(tabRow.trailingChords || [])]) {
        if (ch && !tabGroup.annotations.includes(ch)) tabGroup.annotations.push(ch);
      }
      tabGroup.rows.push(tabRow);
      continue;
    }

    flushTab();

    if (/^\{[^}]+\}/.test(trimmed)) continue;

    const bracket = trimmed.match(/^\[([^\]]+)\]\s*(.*)$/);
    if (bracket) {
      const name = bracket[1].trim();
      const rest = bracket[2].trim();
      if (isSectionBracket(name)) {
        blocks.push({ type: 'section', title: name });
        if (rest) {
          if (isLikelyChordOnly(rest)) blocks.push({ type: 'chordOnly', text: rest });
          else blocks.push({ type: 'pair', row: parseChordPro(`${rest}\n`).lines[0] });
        }
        continue;
      }
    }

    if (isLikelyChordOnly(trimmed)) {
      blocks.push({ type: 'chordOnly', text: trimmed });
      continue;
    }

    const parsed = parseChordPro(`${trimmed}\n`);
    const row = parsed.lines[0];
    const hasChords = (row?.chords || []).some(Boolean);
    const hasLyric = !!(row?.lyric || '').trim();

    if (hasChords && hasLyric) {
      blocks.push({ type: 'pair', row });
    } else if (hasChords && !hasLyric) {
      blocks.push({ type: 'chordOnly', text: chordRowFromParsed(row).chordLine });
    } else if (hasLyric) {
      blocks.push({ type: 'pair', row: { chords: [], lyric: row.lyric } });
    }
  }

  return { blocks, meta };
}

function isLikelyChordOnly(text) {
  const tokens = String(text || '').trim().split(/\s+/).filter(Boolean)
    .map((p) => p.replace(/[|()[\]]/g, ''))
    .filter(Boolean);
  if (!tokens.length) return false;
  return tokens.every((p) => CHORD_TOKEN.test(p));
}

function colorizeChordTokens(text, colorChords) {
  return String(text || '').split(/(\s+)/).map((part) => {
    if (!part.trim()) return part;
    const clean = part.replace(/[|()[\]]/g, '');
    if (CHORD_TOKEN.test(clean)) {
      return `<span class="lps-chord" style="color:${esc(colorChords)}">${esc(part)}</span>`;
    }
    return esc(part);
  }).join('');
}

export function renderCifraBlockHtml(block, settings) {
  const colorChords = settings.colorChords || settings.colorChordsArtist || '#f70';
  const colorLyrics = settings.colorLyrics || settings.colorLyricsTitle || '#424242';

  switch (block.type) {
    case 'section':
      return `<div class="lps-cifra-section" style="color:${esc(colorChords)}">[${esc(block.title)}]</div>`;
    case 'blank':
      return '<div class="lps-cifra-blank" aria-hidden="true"></div>';
    case 'chordOnly':
      return `<div class="lps-chord-pair lps-chord-pair--chords-only"><div class="lps-chord-line">${colorizeChordTokens(block.text, colorChords)}</div></div>`;
    case 'tab': {
      const rows = (block.rows || []).map((r) =>
        `<div class="lps-tab-row"><span class="lps-tab-string">${esc(r.string)}</span><span class="lps-tab-bar">│</span><span class="lps-tab-fret">${esc(r.content)}</span></div>`
      ).join('');
      const label = block.label
        ? `<div class="lps-tab-label">${esc(block.label)}</div>`
        : '<div class="lps-tab-label">Tablatura</div>';
      const notes = (block.annotations || []).filter(Boolean);
      const chordHint = notes.length
        ? `<div class="lps-tab-chords">${notes.map((c) => `<span class="lps-chord">${esc(c)}</span>`).join(' ')}</div>`
        : '';
      return `<div class="lps-tab-diagram">${label}${chordHint}<div class="lps-tab-scroll"><div class="lps-tab-lines">${rows}</div></div></div>`;
    }
    case 'pair': {
      const { chordLine, lyric } = chordRowFromParsed(block.row);
      const chordHtml = chordLine
        ? `<div class="lps-chord-line">${colorizeChordTokens(chordLine, colorChords)}</div>`
        : '';
      const lyricHtml = lyric
        ? `<div class="lps-lyric-line" style="color:${esc(colorLyrics)}">${esc(lyric)}</div>`
        : '';
      return `<div class="lps-chord-pair">${chordHtml}${lyricHtml}</div>`;
    }
    default:
      return '';
  }
}

export function renderCifraBlocksHtml(blocks, settings) {
  return blocks.map((b) => renderCifraBlockHtml(b, settings)).join('');
}

function cifraMetaLine(song, meta) {
  const bits = [];
  const key = String(song.key || meta.key || '').trim();
  if (key && /^[A-G](?:#|b)?$/i.test(key)) bits.push(`Tom: ${key}`);
  const tuning = String(meta.tuning || '').trim().replace(/\s+/g, ' ');
  if (/^[EADGBe](?:\s+[EADGBe]){5}$/i.test(tuning)) {
    bits.push(`Afinação: ${tuning.toUpperCase()}`);
  }
  const capo = song.capo != null ? song.capo : meta.capo;
  if (capo) bits.push(`Capotraste: ${capo}`);
  if (song.bpm) bits.push(`${song.bpm} BPM`);
  return bits.join(' · ');
}

function mountMeasurer(widthMm, fontStack, fontPt) {
  const el = document.createElement('div');
  el.className = 'lps-measurer lps-measurer--cifra';
  el.style.cssText = [
    'position:fixed', 'left:-12000px', 'top:0', 'visibility:hidden',
    `width:${widthMm}mm`, `font-family:${fontStack}`,
    `font-size:${fontPt}pt`, 'line-height:1.5',
  ].join(';');
  document.body.appendChild(el);
  return el;
}

function measureHtml(el, html) {
  el.innerHTML = html;
  return el.getBoundingClientRect().height;
}

function measureHeaderHeights(song, contentWidthMm, fontStack) {
  const subtitle = [song.artist, song.ministry].filter(Boolean).join(' · ') || song.category || '';
  const wrap = document.createElement('div');
  wrap.style.cssText = `position:fixed;left:-12000px;width:${contentWidthMm}mm;visibility:hidden;padding-right:28mm;`;
  wrap.innerHTML = `
    <div class="lps-mh-full">
      <h1 style="margin:0 0 6px;font-size:1.45em;line-height:1.2;font-family:${fontStack}">${esc(song.title)}</h1>
      ${subtitle ? `<h2 style="margin:0 0 1rem;font-size:1.12em;font-weight:400;line-height:1.35;font-family:${fontStack}">${esc(subtitle)}</h2>` : ''}
    </div>
    <div class="lps-mh-compact">
      <p style="margin:0 0 0.6rem;font-size:0.92em;font-weight:600;line-height:1.25;font-family:${fontStack}">${esc(song.title)}</p>
    </div>`;
  document.body.appendChild(wrap);
  const full = wrap.querySelector('.lps-mh-full').getBoundingClientRect().height;
  const compact = wrap.querySelector('.lps-mh-compact').getBoundingClientRect().height;
  wrap.remove();
  return { full, compact };
}

function measureFooter(composer, meta, contentWidthMm, fontStack) {
  if (!composer && !meta) return 0;
  const wrap = document.createElement('div');
  wrap.style.cssText = `position:fixed;left:-12000px;width:${contentWidthMm}mm;visibility:hidden;`;
  wrap.innerHTML = `
    ${composer ? `<p style="margin:0;font-size:9pt;font-family:${fontStack}">${esc(composer)}</p>` : ''}
    ${meta ? `<p style="margin:0.25em 0 0;font-size:9pt;font-family:${fontStack}">${esc(meta)}</p>` : ''}`;
  document.body.appendChild(wrap);
  const h = wrap.getBoundingClientRect().height + 6;
  wrap.remove();
  return h;
}

function measureCifraMeta(metaHtml, widthMm, fontStack) {
  if (!metaHtml) return 0;
  const wrap = document.createElement('div');
  wrap.style.cssText = `position:fixed;left:-12000px;width:${widthMm}mm;visibility:hidden;font-family:${fontStack};font-size:9pt;`;
  wrap.innerHTML = metaHtml;
  document.body.appendChild(wrap);
  const h = wrap.getBoundingClientRect().height + 4;
  wrap.remove();
  return h;
}

/**
 * Pagina cifra por blocos atômicos + folha opcional de diagramas.
 */
export function paginateCifra(song, settings, { fontStack = 'Arial, Helvetica, sans-serif', fontPt = 12 } = {}) {
  const chordSrc = String(song?.chordSource || '').trim();
  const { blocks, meta } = parseCifraPrintBlocks(chordSrc);
  const paper = PAPER_SPECS[settings.paper] || PAPER_SPECS.a4;
  const box = paperContentBox(settings.paper);
  const composer = composerLine(song);
  const cifraMeta = cifraMetaLine(song, meta);
  const includeDiagrams = settings.includeDiagrams !== false;
  const shapes = includeDiagrams
    ? collectUniqueChords(chordSrc, song?.chordShapes || [])
    : [];

  if (typeof document === 'undefined') {
    return {
      pages: [{ blockIndices: blocks.map((_, i) => i), header: 'full', showComposer: true, showMeta: true, showDiagrams: includeDiagrams && shapes.length > 0 }],
      totalPages: 1,
      composer,
      cifraMeta,
      paper,
      box,
      shapes,
      blocks,
      diagramsHtml: '',
      chordMode: true,
    };
  }

  const headers = measureHeaderHeights(song, box.widthMm, fontStack);
  const footerH = measureFooter(composer, cifraMeta, box.widthMm, fontStack);
  const metaHtml = cifraMeta ? `<p class="lps-cifra-meta">${esc(cifraMeta)}</p>` : '';
  const metaH = measureCifraMeta(metaHtml, box.widthMm, fontStack);
  const contentHeightPx = mmToPx(box.heightMm);
  const measurer = mountMeasurer(box.widthMm, fontStack, fontPt);

  const blockHeights = blocks.map((b) =>
    measureHtml(measurer, renderCifraBlockHtml(b, settings))
  );

  const diagramsHtml = shapes.length
    ? renderChordDiagramsGrid(shapes, {
      accent: settings.colorChords || settings.colorChordsArtist || '#f70',
    })
    : '';
  const diagramsH = diagramsHtml ? measureHtml(measurer, diagramsHtml) + 12 : 0;

  const bodyLimit = (pg, reserveFooter = false) => {
    const hdr = pg.header === 'full' ? headers.full : headers.compact;
    const metaReserve = pg.header === 'full' && pg.showMeta ? metaH : 0;
    const footerReserve = reserveFooter && pg.showComposer ? footerH : 0;
    return contentHeightPx - hdr - metaReserve - footerReserve;
  };

  const pages = [];
  let page = { blockIndices: [], header: 'full', showComposer: false, showMeta: true, showDiagrams: false };
  let usedH = 0;

  const pushPage = () => {
    if (page.blockIndices.length || page.showDiagrams) pages.push(page);
    page = { blockIndices: [], header: 'compact', showComposer: false, showMeta: false, showDiagrams: false };
    usedH = 0;
  };

  for (let i = 0; i < blocks.length; i += 1) {
    const h = blockHeights[i];
    const limit = bodyLimit(page, false);
    if (usedH + h <= limit || !page.blockIndices.length) {
      page.blockIndices.push(i);
      usedH += h;
    } else {
      pushPage();
      page.blockIndices.push(i);
      usedH = h;
    }
  }

  if (page.blockIndices.length || !pages.length) pages.push(page);

  if (includeDiagrams && diagramsHtml) {
    const last = pages[pages.length - 1];
    const limit = bodyLimit(last, true);
    const bodyH = last.blockIndices.reduce((sum, idx) => sum + (blockHeights[idx] ?? 0), 0);

    if (bodyH + diagramsH <= limit) {
      last.showDiagrams = true;
    } else {
      pages.push({
        blocks: [],
        header: 'compact',
        showComposer: false,
        showMeta: false,
        showDiagrams: true,
      });
    }
  }

  pages[pages.length - 1].showComposer = !!(composer || cifraMeta);

  measurer.remove();

  return {
    pages,
    totalPages: pages.length,
    composer,
    cifraMeta,
    paper,
    box,
    shapes,
    blocks,
    diagramsHtml,
    chordMode: true,
  };
}

export function buildCifraPagesHtml(song, settings, fontClasses, pagination) {
  const { pages, totalPages, composer, cifraMeta, paper, diagramsHtml, blocks } = pagination;
  const logo = esc(productLogoUrl());
  const subtitle = [song.artist, song.ministry].filter(Boolean).join(' · ') || song.category || '';
  const metaHtml = cifraMeta ? `<p class="lps-cifra-meta">${esc(cifraMeta)}</p>` : '';
  // Cifra Club: "Letras e título" + "Acordes e artista"
  const colorText = settings.colorLyricsTitle || settings.colorLyrics || '#424242';
  const colorChords = settings.colorChordsArtist || settings.colorChords || '#f70';
  const resolved = { ...settings, colorLyrics: colorText, colorChords, colorTitle: colorText, colorArtist: colorChords };

  return pages.map((pg, idx) => {
    const n = idx + 1;
    const pageClasses = [
      'lps-page', 'lps-print-sheet', 'lps-page--cifra', fontClasses.font, fontClasses.size, paper.class,
      '--chordMode', '--singleColumn',
      pg.header === 'compact' ? '--compactHeader' : '',
      pg.showDiagrams && !pg.blockIndices?.length ? '--diagramsOnly' : '',
    ].filter(Boolean).join(' ');

    const header = pg.header === 'full'
      ? `<header class="lps-page-header">
          <h1 style="color:${esc(colorText)}">${esc(song.title)}</h1>
          ${subtitle ? `<h2 style="color:${esc(colorChords)}">${esc(subtitle)}</h2>` : ''}
          <img class="lps-brand-logo" src="${logo}" alt="SOMOSUM" />
        </header>`
      : `<header class="lps-page-header lps-page-header--compact">
          <p class="lps-page-continued" style="color:${esc(colorText)}">${esc(song.title)} <span class="lps-page-continued-mark">(continuação)</span></p>
          <img class="lps-brand-logo" src="${logo}" alt="SOMOSUM" />
        </header>`;

    const pageBlocks = (pg.blockIndices || []).map((bi) => blocks[bi]).filter(Boolean);
    const body = pageBlocks.length
      ? `<div class="lps-page-body lps-cifra-body" style="color:${esc(colorText)}">${renderCifraBlocksHtml(pageBlocks, resolved)}</div>`
      : '';

    const diagrams = pg.showDiagrams && diagramsHtml ? diagramsHtml : '';

    const footer = pg.showComposer
      ? `${composer ? `<p class="lps-composer">${esc(composer)}</p>` : ''}${cifraMeta ? `<p class="lps-meta-line">${esc(cifraMeta)}</p>` : ''}`
      : '';

    const sheetBreak = idx < pages.length - 1
      ? '<div class="lps-sheet-gap" aria-hidden="true"><span class="lps-sheet-gap-label">— quebra de folha —</span></div>'
      : '';

    return `<article class="${pageClasses}" data-paper="${paper.id}" data-page="${n}" data-total="${totalPages}" style="--lps-page-h:${paper.heightMm}mm;--lps-page-w:${paper.widthMm}mm">
        <div class="lps-page-badge">Folha ${n} / ${totalPages} · cifra</div>
        ${header}
        ${pg.showMeta && pg.header === 'full' ? metaHtml : ''}
        ${body}
        ${diagrams}
        ${footer}
      </article>${sheetBreak}`;
  }).join('');
}

export function buildCifraPrintStyles(paper, fontStack, fontPt) {
  const p = PAPER_SPECS[paper.id] || paper;
  return `
  @page { margin: ${p.marginTopMm}mm ${p.marginRightMm}mm ${p.marginBottomMm}mm ${p.marginLeftMm}mm; size: ${p.pageSize}; }
  * { box-sizing: border-box; }
  body { margin: 0; padding: 0; background: #fff; font-family: ${fontStack}; }
  .lps-print-sheet { page-break-after: always; break-after: page; }
  .lps-print-sheet:last-of-type { page-break-after: auto; break-after: auto; }
  .lps-page {
    position: relative;
    width: ${p.widthMm}mm;
    height: ${p.heightMm}mm;
    min-height: ${p.heightMm}mm;
    max-height: ${p.heightMm}mm;
    padding: ${p.marginTopMm}mm ${p.marginRightMm}mm ${p.marginBottomMm}mm ${p.marginLeftMm}mm;
    overflow: hidden;
  }
  .lps-page-header { padding-right: 28mm; margin-bottom: 0.3rem; }
  .lps-page-header h1 { margin: 0 0 6px; font-size: 1.45em; line-height: 1.2; font-family: ${fontStack}; }
  .lps-page-header h2 { margin: 0 0 0.85rem; font-size: 1.12em; font-weight: normal; line-height: 1.35; font-family: ${fontStack}; }
  .lps-page-continued { margin: 0 0 0.55rem; font-size: 0.92em; font-weight: 600; font-family: ${fontStack}; }
  .lps-page-continued-mark { font-weight: 400; opacity: 0.75; font-size: 0.92em; }
  .lps-brand-logo { position: absolute; top: ${p.marginTopMm}mm; right: ${p.marginRightMm}mm; height: 28px; max-width: 100px; object-fit: contain; }
  .lps-cifra-meta { margin: 0 0 0.65rem; font-size: 9pt; color: #666; font-family: ${fontStack}; }
  .lps-cifra-body { line-height: 1.5; font-size: ${fontPt}pt; font-family: ${fontStack}; }
  .lps-cifra-section { margin: 0.85em 0 0.35em; font-size: 0.95em; font-weight: 700; font-family: "Courier New", Courier, monospace; }
  .lps-cifra-blank { height: 0.75em; }
  .lps-chord-pair { margin: 0 0 0.2em; }
  .lps-chord-pair--chords-only { margin-bottom: 0.45em; }
  .lps-chord-line { white-space: pre; font-family: "Courier New", Courier, monospace; font-size: 1em; line-height: 1.25; font-variant-ligatures: none; min-height: 1.25em; letter-spacing: 0; }
  .lps-chord { font-weight: 700; }
  .lps-lyric-line { font-family: "Courier New", Courier, monospace; line-height: 1.45; margin-bottom: 0.4em; white-space: pre-wrap; }
  .lps-chord-diagrams { margin-top: 1.2em; padding-top: 0.75em; border-top: 1px solid #e8e8e8; }
  .lps-chord-diagrams-grid { list-style: none; margin: 0; padding: 0; display: flex; flex-wrap: wrap; gap: 8px 12px; align-items: flex-start; }
  .lps-chord-diagram-item { margin: 0; padding: 0; line-height: 0; }
  .lps-chord-diagram { display: block; overflow: visible; }
  .lps-tab-diagram { margin: 0.6em 0 0.85em; padding: 0.4em 0; border-top: 1px solid #eee; border-bottom: 1px solid #eee; }
  .lps-tab-label { font-size: 8pt; font-weight: 700; text-transform: uppercase; letter-spacing: 0.04em; color: #888; margin-bottom: 0.3em; font-family: ${fontStack}; }
  .lps-tab-scroll { overflow-x: auto; max-width: 100%; }
  .lps-tab-lines { width: max-content; }
  .lps-tab-row { display: flex; flex-wrap: nowrap; font-family: "Courier New", Courier, monospace; font-size: 8.5pt; line-height: 1.25; white-space: nowrap; }
  .lps-tab-string { flex: 0 0 12px; font-weight: 700; text-align: right; margin-right: 4px; color: #666; }
  .lps-tab-bar { color: #bbb; margin-right: 2px; }
  .lps-tab-fret { white-space: pre; }
  .lps-composer { margin: 0.6em 0 0; clear: both; font-size: 9pt; color: #bbb; font-family: ${fontStack}; }
  .lps-meta-line { margin: 0.2em 0 0; font-size: 9pt; color: #999; font-family: ${fontStack}; }
  .lps-page-badge, .lps-sheet-gap { display: none !important; }`;
}

/** Prévia compacta para editor (sem cabeçalho de folha). */
export function renderCifraPreviewHtml(song, settings = {}) {
  const chordSrc = String(song?.chordSource || '').trim();
  if (!chordSrc) return '';
  const { blocks, meta } = parseCifraPrintBlocks(chordSrc);
  const cifraMeta = cifraMetaLine(song, meta);
  const includeDiagrams = settings.includeDiagrams !== false;
  const shapes = includeDiagrams
    ? collectUniqueChords(chordSrc, song?.chordShapes || [])
    : [];
  const body = renderCifraBlocksHtml(blocks, {
    ...settings,
    colorChords: settings.colorChords || settings.colorChordsArtist || '#ff7700',
    colorLyrics: settings.colorLyrics || settings.colorLyricsTitle || '#424242',
  });
  const diagrams = shapes.length
    ? renderChordDiagramsGrid(shapes, {
      accent: settings.colorChords || settings.colorChordsArtist || '#ff7700',
    })
    : '';
  return `
    <div class="lps-cifra-preview">
      ${cifraMeta ? `<p class="lps-cifra-meta">${esc(cifraMeta)}</p>` : ''}
      <div class="lps-cifra-body">${body}</div>
      ${diagrams}
    </div>`;
}
