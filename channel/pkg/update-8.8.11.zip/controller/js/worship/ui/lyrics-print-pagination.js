/**
 * Paginação de letras para impressão — dimensões ISO/US e quebra por folha.
 */
import { PRODUCT_LOGO, PRODUCT_LOGO_REL } from '../../core/brand-assets.js';
import { parseChordPro, formatChordChartLines } from '../chordpro-parser.js';

/** Dimensões reais (mm) — margens iguais ao letras.mus.br print. */
export const PAPER_SPECS = {
  a4: {
    id: 'a4',
    label: 'A4',
    class: '--a4PaperSize',
    widthMm: 210,
    heightMm: 297,
    marginTopMm: 11.2,
    marginRightMm: 16.5,
    marginBottomMm: 11.2,
    marginLeftMm: 16.5,
    pageSize: 'A4 portrait',
  },
  bond: {
    id: 'bond',
    label: 'Ofício',
    class: '--bondPaperSize',
    widthMm: 216,
    heightMm: 356,
    marginTopMm: 11.2,
    marginRightMm: 16.5,
    marginBottomMm: 11.2,
    marginLeftMm: 16.5,
    pageSize: 'legal portrait',
  },
  letter: {
    id: 'letter',
    label: 'Carta',
    class: '--letterPaperSize',
    widthMm: 216,
    heightMm: 279,
    marginTopMm: 11.2,
    marginRightMm: 16.5,
    marginBottomMm: 11.2,
    marginLeftMm: 16.5,
    pageSize: 'letter portrait',
  },
};

export function paperContentBox(paperId) {
  const p = PAPER_SPECS[paperId] || PAPER_SPECS.a4;
  return {
    widthMm: p.widthMm - p.marginLeftMm - p.marginRightMm,
    heightMm: p.heightMm - p.marginTopMm - p.marginBottomMm,
    page: p,
  };
}

function mmToPx(mm) {
  return (mm * 96) / 25.4;
}

function esc(s) {
  return String(s ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

export function lyricsToLines(lyrics) {
  return String(lyrics || '').replace(/\r\n/g, '\n').split('\n');
}

/** Conteúdo efetivo da impressão: letra limpa ou cifra ChordPro formatada. */
export function resolvePrintContent(song, settings = {}) {
  const wantChords = !!settings.includeChords;
  const chordSrc = String(song?.chordSource || '').trim();
  if (wantChords && chordSrc) {
    const parsed = parseChordPro(chordSrc);
    const chart = formatChordChartLines(parsed.lines);
    if (chart.some((l) => String(l).trim())) {
      return { lines: chart, chordMode: true };
    }
  }
  return { lines: lyricsToLines(song?.lyrics), chordMode: false };
}

export function songHasPrintableChords(song) {
  return !!String(song?.chordSource || '').trim();
}

export function renderLinesHtml(lines, { chordMode = false } = {}) {
  const parts = [];
  for (const line of lines) {
    if (line === '') parts.push('<br>');
    else {
      const cls = chordMode ? 'lps-line lps-line--pre' : 'lps-line';
      parts.push(`<div class="${cls}">${esc(line)}</div>`);
    }
  }
  return parts.join('');
}

function productLogoUrl() {
  if (typeof location === 'undefined') return PRODUCT_LOGO;
  const path = PRODUCT_LOGO.startsWith('/') ? PRODUCT_LOGO : `/${PRODUCT_LOGO_REL}`;
  return `${location.origin}${path}`;
}

function mountMeasurer(columnWidthMm, fontStack, fontPt, { chordMode = false } = {}) {
  const el = document.createElement('div');
  el.className = 'lps-measurer';
  const extra = chordMode ? 'white-space:pre;font-variant-ligatures:none;' : '';
  el.style.cssText = [
    'position:fixed', 'left:-12000px', 'top:0', 'visibility:hidden',
    `width:${columnWidthMm}mm`, `font-family:${fontStack}`,
    `font-size:${fontPt}pt`, 'line-height:1.5', extra,
  ].filter(Boolean).join(';');
  document.body.appendChild(el);
  return el;
}

function measureHtml(el, html) {
  el.innerHTML = html;
  return el.getBoundingClientRect().height;
}

function measureHeaderHeights(song, contentWidthMm, fontStack) {
  const subtitle = [song.artist, song.ministry].filter(Boolean).join(' · ') || song.category || '';
  const wrap = document.createElement('div');
  wrap.style.cssText = `position:fixed;left:-12000px;width:${contentWidthMm}mm;visibility:hidden;padding-right:28mm;`;
  wrap.innerHTML = `
    <div class="lps-mh-full">
      <h1 style="margin:0 0 6px;font-size:1.45em;line-height:1.2;font-family:${fontStack}">${esc(song.title)}</h1>
      ${subtitle ? `<h2 style="margin:0 0 1rem;font-size:1.12em;font-weight:400;line-height:1.35;font-family:${fontStack}">${esc(subtitle)}</h2>` : ''}
    </div>
    <div class="lps-mh-compact">
      <p style="margin:0 0 0.6rem;font-size:0.92em;font-weight:600;line-height:1.25;font-family:${fontStack}">${esc(song.title)}</p>
    </div>`;
  document.body.appendChild(wrap);
  const full = wrap.querySelector('.lps-mh-full').getBoundingClientRect().height;
  const compact = wrap.querySelector('.lps-mh-compact').getBoundingClientRect().height;
  wrap.remove();
  return { full, compact };
}

function measureFooter(composer, meta, contentWidthMm, fontStack) {
  if (!composer && !meta) return 0;
  const wrap = document.createElement('div');
  wrap.style.cssText = `position:fixed;left:-12000px;width:${contentWidthMm}mm;visibility:hidden;`;
  wrap.innerHTML = `
    ${composer ? `<p style="margin:0;font-size:9pt;font-family:${fontStack}">${esc(composer)}</p>` : ''}
    ${meta ? `<p style="margin:0.25em 0 0;font-size:9pt;font-family:${fontStack}">${esc(meta)}</p>` : ''}`;
  document.body.appendChild(wrap);
  const h = wrap.getBoundingClientRect().height + 6;
  wrap.remove();
  return h;
}

export function composerLine(song) {
  const bits = [];
  if (song.composer?.trim()) bits.push(song.composer.trim());
  else if (song.artist?.trim()) bits.push(song.artist.trim());
  if (song.ministry?.trim() && song.ministry !== song.artist) bits.push(song.ministry.trim());
  return bits.length ? `Composição: ${bits.join(', ')}` : '';
}

/**
 * Quebra linhas em folhas com altura fixa (A4 / Ofício / Carta).
 * Com cifra: 1 coluna + monoespaçada (alinhamento dos acordes).
 */
export function paginateLyrics(song, settings, { fontStack = 'Arial, Helvetica, sans-serif', fontPt = 12 } = {}) {
  const { lines: sourceLines, chordMode } = resolvePrintContent(song, settings);
  // Cifra precisa de largura total — coluna dupla desalinha acordes
  const numCols = chordMode ? 1 : (settings.columns === 2 ? 2 : 1);
  const effectiveStack = chordMode
    ? '"Courier New", Courier, monospace'
    : fontStack;

  if (typeof document === 'undefined') {
    return {
      pages: [{ columns: [sourceLines], header: 'full', showComposer: true }],
      totalPages: 1,
      composer: composerLine(song),
      meta: '',
      paper: PAPER_SPECS[settings.paper] || PAPER_SPECS.a4,
      box: paperContentBox(settings.paper),
      columns: numCols,
      chordMode,
    };
  }

  const paper = PAPER_SPECS[settings.paper] || PAPER_SPECS.a4;
  const box = paperContentBox(settings.paper);
  const columnWidthMm = numCols === 2 ? box.widthMm * 0.48 : box.widthMm;
  const lines = sourceLines;
  const composer = composerLine(song);
  const metaBits = [];
  if (song.key) metaBits.push(`Tom: ${song.key}`);
  if (song.bpm) metaBits.push(`${song.bpm} BPM`);
  if (chordMode) metaBits.push('Cifra');
  const meta = metaBits.join(' · ');

  const headers = measureHeaderHeights(song, box.widthMm, effectiveStack);
  const footerH = measureFooter(composer, meta, box.widthMm, effectiveStack);
  const contentHeightPx = mmToPx(box.heightMm);
  const measurer = mountMeasurer(columnWidthMm, effectiveStack, fontPt, { chordMode });

  const pages = [];
  let page = { columns: numCols === 2 ? [[], []] : [[]], header: 'full' };
  let col = 0;
  let i = 0;

  const bodyLimit = (pg, reserveFooter = false) => {
    const hdr = pg.header === 'full' ? headers.full : headers.compact;
    const footerReserve = reserveFooter && (composer || meta) ? footerH : 0;
    return contentHeightPx - hdr - footerReserve;
  };

  const pageBodyHeight = (pg) => {
    let max = 0;
    for (const c of pg.columns) max = Math.max(max, colHeight(c));
    return max;
  };

  const colHeight = (colLines) =>
    colLines.length ? measureHtml(measurer, renderLinesHtml(colLines, { chordMode })) : 0;

  const columnFits = (pg, colIdx, line, footer = false) =>
    colHeight([...pg.columns[colIdx], line]) <= bodyLimit(pg, footer) + 0.5;

  const pickColumnForLine = (pg, line) => {
    const fits0 = columnFits(pg, 0, line);
    const fits1 = numCols === 2 && columnFits(pg, 1, line);
    if (!fits0 && !fits1) return -1;
    if (numCols === 1 || !fits1) return 0;
    if (!fits0) return 1;
    const h0 = colHeight(pg.columns[0]);
    const h1 = colHeight(pg.columns[1]);
    return h0 <= h1 ? 0 : 1;
  };

  const flattenPageLines = (pg) => {
    const out = [];
    for (const c of pg.columns) out.push(...c);
    return out;
  };

  const canAppendToPage = (pg, colIdx, line, footer = true) =>
    columnFits(pg, colIdx, line, footer);

  const tryMergeTrailingPages = () => {
    while (pages.length > 1) {
      const prev = pages[pages.length - 2];
      const last = pages[pages.length - 1];
      const incoming = flattenPageLines(last);
      if (!incoming.length) {
        pages.pop();
        continue;
      }

      const kept = [];
      for (const line of incoming) {
        const targetCol = pickColumnForLine(prev, line);
        if (targetCol >= 0 && canAppendToPage(prev, targetCol, line, true)) {
          prev.columns[targetCol].push(line);
        } else {
          kept.push(line);
        }
      }

      if (kept.length === incoming.length) break;

      if (!kept.length) {
        pages.pop();
        continue;
      }

      if (numCols === 2) {
        last.columns = [[], []];
        for (const line of kept) {
          const targetCol = pickColumnForLine(last, line);
          if (targetCol >= 0 && canAppendToPage(last, targetCol, line, false)) {
            last.columns[targetCol].push(line);
          } else {
            last.columns[0].push(line);
          }
        }
      } else {
        last.columns = [kept];
      }
    }
  };

  const pushPage = () => {
    if (page.columns.some((c) => c.length)) pages.push(page);
    page = { columns: numCols === 2 ? [[], []] : [[]], header: 'compact' };
    col = 0;
  };

  const paginateSingleColumn = () => {
    while (i < lines.length) {
      const line = lines[i];
      if (columnFits(page, 0, line)) {
        page.columns[0].push(line);
        i += 1;
        continue;
      }
      if (page.columns[0].length === 0) {
        page.columns[0].push(line);
        i += 1;
      }
      pushPage();
    }
  };

  const paginateDoubleColumn = () => {
    while (i < lines.length) {
      const line = lines[i];
      const targetCol = pickColumnForLine(page, line);
      if (targetCol >= 0) {
        page.columns[targetCol].push(line);
        i += 1;
        col = targetCol;
        continue;
      }
      if (!page.columns[0].length && !page.columns[1].length) {
        page.columns[0].push(line);
        i += 1;
        continue;
      }
      pushPage();
    }
  };

  if (numCols === 2) paginateDoubleColumn();
  else paginateSingleColumn();

  if (page.columns.some((c) => c.length)) pages.push(page);
  if (!pages.length) pages.push({ columns: numCols === 2 ? [[], []] : [[]], header: 'full' });

  if (composer || meta) {
    const peelLine = () => {
      const last = pages[pages.length - 1];
      for (let c = last.columns.length - 1; c >= 0; c -= 1) {
        if (last.columns[c].length) return last.columns[c].pop();
      }
      return null;
    };

    while (pages.length) {
      const last = pages[pages.length - 1];
      if (pageBodyHeight(last) <= bodyLimit(last, true)) break;
      const peeled = peelLine();
      if (peeled == null) break;
      let overflow = pages[pages.length - 1];
      const lastStillSame = overflow === last;
      if (lastStillSame || !flattenPageLines(overflow).length) {
        overflow = { columns: numCols === 2 ? [[], []] : [[]], header: 'compact' };
        pages.push(overflow);
      }
      const destCol = pickColumnForLine(overflow, peeled);
      overflow.columns[destCol >= 0 ? destCol : 0].push(peeled);
    }

    while (pages.length > 1 && !pages[pages.length - 1].columns.some((c) => c.length)) {
      pages.pop();
    }
  }

  tryMergeTrailingPages();

  pages[pages.length - 1].showComposer = !!(composer || meta);
  measurer.remove();

  return {
    pages,
    totalPages: pages.length,
    composer,
    meta,
    paper,
    box,
    columns: numCols,
    chordMode,
  };
}

/** @deprecated use paginateLyrics — mantido para testes legados */
export function splitLyricsColumns(lines, columns = 2) {
  if (columns !== 2 || !lines.length) return [lines, []];
  const target = Math.ceil(lines.length / 2);
  let splitAt = target;
  let best = Infinity;
  for (let j = 1; j < lines.length; j++) {
    if (lines[j] === '' || lines[j - 1] === '') {
      const diff = Math.abs(j - target);
      if (diff < best) { best = diff; splitAt = j; }
    }
  }
  while (splitAt < lines.length && lines[splitAt] === '') splitAt += 1;
  return [lines.slice(0, splitAt), lines.slice(splitAt)];
}

export function buildPaginatedPagesHtml(song, settings, fontClasses, pagination) {
  const { pages, totalPages, composer, meta, paper, chordMode } = pagination;
  const logo = esc(productLogoUrl());
  const subtitle = [song.artist, song.ministry].filter(Boolean).join(' · ') || song.category || '';

  return pages.map((pg, idx) => {
    const n = idx + 1;
    const pageClasses = [
      'lps-page', 'lps-print-sheet', fontClasses.font, fontClasses.size, paper.class,
      chordMode ? '--chordMode --singleColumn' : (settings.columns === 2 ? '--doubleColumn' : '--singleColumn'),
      pg.header === 'compact' ? '--compactHeader' : '',
    ].filter(Boolean).join(' ');

    const header = pg.header === 'full'
      ? `<header class="lps-page-header">
          <h1 style="color:${esc(settings.colorTitle)}">${esc(song.title)}</h1>
          ${subtitle ? `<h2 style="color:${esc(settings.colorArtist)}">${esc(subtitle)}</h2>` : ''}
          <img class="lps-brand-logo" src="${logo}" alt="SOMOSUM" />
        </header>`
      : `<header class="lps-page-header lps-page-header--compact">
          <p class="lps-page-continued" style="color:${esc(settings.colorTitle)}">${esc(song.title)} <span class="lps-page-continued-mark">(continuação)</span></p>
          <img class="lps-brand-logo" src="${logo}" alt="SOMOSUM" />
        </header>`;

    const cols = pg.columns.map((colLines) =>
      `<div class="lps-page-col">${renderLinesHtml(colLines, { chordMode })}</div>`
    ).join('');

    const footer = pg.showComposer
      ? `${composer ? `<p class="lps-composer">${esc(composer)}</p>` : ''}${meta ? `<p class="lps-meta-line">${esc(meta)}</p>` : ''}`
      : '';

    const sheetBreak = idx < pages.length - 1
      ? '<div class="lps-sheet-gap" aria-hidden="true"><span class="lps-sheet-gap-label">— quebra de folha —</span></div>'
      : '';

    return `<article class="${pageClasses}" data-paper="${paper.id}" data-page="${n}" data-total="${totalPages}" style="--lps-page-h:${paper.heightMm}mm;--lps-page-w:${paper.widthMm}mm">
        <div class="lps-page-badge">Folha ${n} / ${totalPages}${chordMode ? ' · cifra' : ''}</div>
        ${header}
        <div class="lps-page-body" style="color:${esc(settings.colorLyrics)}">${cols}</div>
        ${footer}
      </article>${sheetBreak}`;
  }).join('');
}

export function buildPrintStyles(paper, fontStack, fontPt, { chordMode = false } = {}) {
  const p = PAPER_SPECS[paper.id] || paper;
  const bodyFont = chordMode ? '"Courier New", Courier, monospace' : fontStack;
  return `
  @page { margin: ${p.marginTopMm}mm ${p.marginRightMm}mm ${p.marginBottomMm}mm ${p.marginLeftMm}mm; size: ${p.pageSize}; }
  * { box-sizing: border-box; }
  body { margin: 0; padding: 0; background: #fff; font-family: ${bodyFont}; }
  .lps-print-sheet { page-break-after: always; break-after: page; }
  .lps-print-sheet:last-of-type { page-break-after: auto; break-after: auto; }
  .lps-page {
    position: relative;
    width: ${p.widthMm}mm;
    height: ${p.heightMm}mm;
    min-height: ${p.heightMm}mm;
    max-height: ${p.heightMm}mm;
    padding: ${p.marginTopMm}mm ${p.marginRightMm}mm ${p.marginBottomMm}mm ${p.marginLeftMm}mm;
    overflow: hidden;
  }
  .lps-page-header { padding-right: 28mm; margin-bottom: 0.3rem; }
  .lps-page-header h1 { margin: 0 0 6px; font-size: 1.45em; line-height: 1.2; font-family: ${fontStack}; }
  .lps-page-header h2 { margin: 0 0 0.85rem; font-size: 1.12em; font-weight: normal; line-height: 1.35; font-family: ${fontStack}; }
  .lps-page-continued { margin: 0 0 0.55rem; font-size: 0.92em; font-weight: 600; font-family: ${fontStack}; }
  .lps-page-continued-mark { font-weight: 400; opacity: 0.75; font-size: 0.92em; }
  .lps-brand-logo { position: absolute; top: ${p.marginTopMm}mm; right: ${p.marginRightMm}mm; height: 28px; max-width: 100px; object-fit: contain; }
  .lps-page-body { line-height: 1.5; font-size: ${fontPt}pt; }
  .lps-page.--chordMode .lps-page-body { font-family: "Courier New", Courier, monospace; }
  .lps-line--pre { white-space: pre; font-variant-ligatures: none; }
  .lps-page-body::after { content: ""; display: block; clear: both; }
  .lps-page-col { min-height: 0; }
  .--doubleColumn .lps-page-col { float: left; width: 48%; }
  .--doubleColumn .lps-page-col + .lps-page-col { margin-left: 4%; }
  .--singleColumn .lps-page-col { width: 100%; float: none; }
  .lps-composer { margin: 0.6em 0 0; clear: both; font-size: 9pt; color: #bbb; font-family: ${fontStack}; }
  .lps-meta-line { margin: 0.2em 0 0; font-size: 9pt; color: #999; font-family: ${fontStack}; }
  .lps-page-badge, .lps-sheet-gap { display: none !important; }`;
}
