/**
 * Mensagens amigáveis para erros de pacotes de hinários.
 */
const MESSAGES = {
  manifest_fetch_404: 'Catálogo de hinários não encontrado. Reinstale ou verifique model/content/packs/hinarios/.',
  manifest_fetch_failed: 'Não foi possível ler o catálogo de hinários.',
  pack_not_found: 'Pacote não encontrado no disco.',
  pack_not_found_id: 'Hinário não listado no catálogo.',
  pack_fetch_404: 'Arquivo do pacote ausente. Use offline local ou verifique a instalação.',
  pack_fetch_failed: 'Falha ao ler o arquivo do pacote.',
  pack_fetch_cdn_failed: 'Pacote não está no disco e a internet não respondeu. Conecte-se ou reinstale o SOMOSUM.',
  extract_api_failed: 'Falha ao descompactar no servidor.',
  extract_client_failed: 'Falha ao descompactar o ZIP no navegador.',
  pack_json_invalid: 'Conteúdo do pacote inválido (pack.json).',
  pack_json_missing: 'pack.json não encontrado dentro do arquivo.',
  seven_zip_missing: 'Formato 7z requer 7-Zip (tools/7z/7za.exe). Reinstale ou use o pacote ZIP.',
  already_installed: 'Este hinário já está instalado.',
  not_installed: 'Este hinário não está instalado.',
  uninstall_empty: 'Nenhum hino deste pacote na biblioteca.',
  import_failed: 'Falha ao gravar hinos na biblioteca.',
  offline_no_local: 'Sem conexão e pacote não está incluído localmente.',
  invalid_filename: 'Nome de arquivo de pacote inválido.',
};

export function formatHinarioPackError(err) {
  const raw = String(err?.message || err || '').trim();
  if (!raw) return 'Erro desconhecido ao processar hinário.';

  for (const [code, msg] of Object.entries(MESSAGES)) {
    if (raw === code || raw.startsWith(code + ':') || raw.includes(code)) return msg;
  }

  if (raw.startsWith('pack_not_found:')) return MESSAGES.pack_not_found_id;
  if (raw.startsWith('manifest_fetch_')) return MESSAGES.manifest_fetch_failed;
  if (raw.startsWith('pack_fetch_')) return MESSAGES.pack_fetch_failed;
  if (raw.startsWith('extract_failed')) return MESSAGES.extract_api_failed;

  return raw.length > 120 ? `${raw.slice(0, 117)}…` : raw;
}

export function isOnline() {
  return typeof navigator !== 'undefined' ? navigator.onLine !== false : true;
}
