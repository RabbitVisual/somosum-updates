/**
 * Editor de louvores — prévia 16:9 fiel, divisão por presets, editor legível.
 */
import { getPrefs } from '../core/store.js';
import {
  getLyricsStyle,
  buildLyricsSlides,
  resolveLyricsBackground,
  formatLyricsForSlides,
} from '../lyrics/lyrics-splitter.js';
import { renderPreview } from '../slides/slide-engine.js';
import { cleanPastedLyrics, detectBlocks, insertBlockMarker } from './worship-parser.js';
import { autoSplitLyrics, DEFAULT_MAX_LINES, DEFAULT_MAX_CHARS } from './worship-splitter.js';
import { BLOCK_TYPES, LANGUAGES } from './worship-schema.js';
import { formatHinarioRefsList, parseHinarioRefsInput } from './hinario-catalog.js';
import { observeStagePreviewFit } from '../ui/stage-preview-fit.js';
import { mediaBackgroundOptionsHtml } from '../core/media-url.js';
import { faIcon, faIconRaw } from '../core/fa-icons.js';
import { renderChordChartHtml } from '../screen/stage-chords-view.js';
import { collectUniqueChords, renderChordDiagramsGrid } from './ui/chord-diagram.js';
import { syncStructureFromLyrics } from './lyrics-engine/lyrics-projection-text.js';

function esc(t) {
  const d = document.createElement('div');
  d.textContent = t ?? '';
  return d.innerHTML;
}
function escAttr(t) {
  return esc(t).replace(/"/g, '&quot;');
}

const SPLIT_PRESETS = [
  { id: 'lines-1', label: '1 linha', hint: 'Uma linha por slide', mode: 'line', count: 1 },
  { id: 'lines-2', label: '2 linhas', hint: 'Duas linhas por slide', mode: 'lines', count: 2 },
  { id: 'lines-4', label: '4 linhas', hint: 'Quatro linhas por slide', mode: 'lines', count: 4 },
  { id: 'lines-6', label: '6 linhas', hint: 'Seis linhas por slide', mode: 'lines', count: 6 },
  { id: 'stanza-1', label: '1 estrofe', hint: 'Cada estrofe = um slide', mode: 'stanza', count: 1 },
  { id: 'stanzas-2', label: '2 estrofes', hint: 'Duas estrofes por slide', mode: 'stanzas', count: 2 },
];

export class WorshipEditor {
  constructor(container, callbacks = {}) {
    this.container = container;
    this.callbacks = callbacks;
    this.draft = null;
    this.mediaList = [];
    this.syncTimer = null;
    this.categories = [];
    this._previewIdx = 0;
    this._previewObs = null;
    this._caret = null;
    /** Assistente de letra aberto (persiste entre re-renders leves). */
    this._assistOpen = false;
    /** Prévia: público (projetor) ou músicos (cifra). */
    this._previewAudience = 'public';
    /** Aba principal do editor: meta | lyrics | chords | projection */
    this._mainTab = 'lyrics';
    /** Editor: letra (projeção) ou cifra (Stage) — espelha aba Conteúdo */
    this._contentTab = 'lyrics';
    this._defaultEdited = false;
    this._assistPasteDraft = '';
    this._assistPreviewTimer = null;
  }

  setDraft(song, { openAssist = null, contentTab, defaultEdited = null } = {}) {
    this.draft = song ? structuredClone(song) : null;
    this._previewIdx = 0;
    this._caret = null;
    this._assistPasteDraft = '';
    if (defaultEdited != null) this._defaultEdited = !!defaultEdited;
    else if (!song?.systemDefault) this._defaultEdited = false;
    if (contentTab === 'lyrics' || contentTab === 'chords') {
      this._contentTab = contentTab;
      this._mainTab = contentTab;
    }
    if (openAssist === true) this._assistOpen = true;
    else if (openAssist === false) this._assistOpen = false;
    else if (song && !String(song.lyrics || '').trim()) this._assistOpen = true;
    else this._assistOpen = false;
    this.render();
  }

  /** Atualiza badge de edição sem re-render completo. */
  setDefaultEdited(edited) {
    this._defaultEdited = !!edited;
    if (!this.draft) return;
    const badge = this.container?.querySelector('.worship-protected-badge');
    if (badge) {
      badge.textContent = this._defaultEdited ? 'Padrão · editado' : 'Padrão do sistema';
    }
    const showRestore = !!(this.draft.systemDefault || this.draft.protected) && this._defaultEdited;
    for (const sel of ['#we-restore-default', '#we-restore-default-lyrics', '#we-restore-default-chords']) {
      const el = this.container?.querySelector(sel);
      if (el) el.hidden = !showRestore;
    }
  }

  focusContentTab(tab) {
    if (tab !== 'lyrics' && tab !== 'chords') return;
    this._contentTab = tab;
    this._mainTab = tab;
    if (this.draft) this.render();
  }

  focusMainTab(tab) {
    if (!['meta', 'lyrics', 'chords', 'projection'].includes(tab)) return;
    this._mainTab = tab;
    if (tab === 'lyrics' || tab === 'chords') this._contentTab = tab;
    if (this.draft) this.render();
  }

  getDraft() {
    return this.draft;
  }

  updateField(field, value) {
    if (!this.draft) return;
    this.draft[field] = value;
    this.draft.updatedAt = Date.now();
    this.schedulePreview();
  }

  updateStyle(key, value) {
    if (!this.draft) return;
    this.draft.style = { ...this.draft.style, [key]: value };
    this.draft.updatedAt = Date.now();
    this.schedulePreview();
  }

  schedulePreview() {
    clearTimeout(this.syncTimer);
    this.syncTimer = setTimeout(() => {
      if (typeof requestAnimationFrame === 'function') {
        requestAnimationFrame(() => { void this.renderPreview(); });
      } else {
        void this.renderPreview();
      }
    }, 120);
  }

  rememberCaret() {
    const ta = this.container?.querySelector('#we-lyrics');
    if (!ta) return;
    this._caret = { start: ta.selectionStart, end: ta.selectionEnd };
  }

  restoreCaret() {
    const ta = this.container?.querySelector('#we-lyrics');
    if (!ta || !this._caret) return;
    const len = ta.value.length;
    const start = Math.min(this._caret.start ?? 0, len);
    const end = Math.min(this._caret.end ?? start, len);
    try {
      ta.focus({ preventScroll: true });
      ta.setSelectionRange(start, end);
    } catch { /* ignore */ }
  }

  getActivePreset() {
    const st = this.draft?.style || {};
    const mode = st.splitMode || 'lines';
    if (mode === 'line') return 'lines-1';
    if (mode === 'lines') return `lines-${st.linesPerSlide || 4}`;
    if (mode === 'stanzas') return `stanzas-${st.stanzasPerSlide || 2}`;
    return 'stanza-1';
  }

  /**
 * Aplica divisão (presets clássicos 1/2/4/6 linhas e 1/2 estrofes).
 * Em modo estrofe, só atualiza o estilo — não reescreve a letra
 * (preserva maiúsculas, quebras e identificação verso/refrão).
 */
  applyPreset(presetId, { reformat = true } = {}) {
    if (!this.draft) return;
    const preset = SPLIT_PRESETS.find((p) => p.id === presetId);
    if (!preset) return;

    this.rememberCaret();
    const style = { ...(this.draft.style || {}) };

    if (preset.mode === 'line') {
      style.splitMode = 'line';
      style.linesPerSlide = 1;
      delete style.stanzasPerSlide;
    } else if (preset.mode === 'lines') {
      style.splitMode = 'lines';
      style.linesPerSlide = preset.count;
      delete style.stanzasPerSlide;
    } else if (preset.mode === 'stanzas') {
      style.splitMode = 'stanzas';
      style.stanzasPerSlide = preset.count;
    } else {
      style.splitMode = 'stanza';
      delete style.linesPerSlide;
      delete style.stanzasPerSlide;
    }

    this.draft.style = style;
    this.draft.updatedAt = Date.now();

    // Só reformatar texto em modos por linhas — estrofes usam linhas em branco já existentes
    const stanzaMode = preset.mode === 'stanza' || preset.mode === 'stanzas';
    if (reformat && !stanzaMode && this.draft.lyrics?.trim()) {
      const prefs = getPrefs();
      const resolved = getLyricsStyle(this.draft, prefs.globalLyricsStyle);
      this.draft.lyrics = formatLyricsForSlides(this.draft.lyrics, resolved);
    }

    this.syncStructureFromDraft();
    this._previewIdx = Math.min(this._previewIdx, 1);
    this.syncPresetUi();
    const ta = this.container.querySelector('#we-lyrics');
    if (ta) ta.value = this.draft.lyrics || '';
    this.renderPreview();
    this.restoreCaret();
    this.callbacks.onToast?.(
      `Divisão: ${preset.label} — ${preset.hint}`
    );
  }

  /** Mantém sections/blocks alinhados à letra (preserva verso/refrão). */
  syncStructureFromDraft() {
    if (!this.draft) return;
    const { sections, blocks } = syncStructureFromLyrics(
      this.draft.lyrics || '',
      this.draft.sections || [],
    );
    this.draft.sections = sections;
    this.draft.blocks = blocks;
  }

  syncPresetUi() {
    const active = this.getActivePreset();
    this.container?.querySelectorAll('[data-preset]').forEach((btn) => {
      btn.classList.toggle('is-active', btn.dataset.preset === active);
    });
  }

  async pasteLyrics({ fromClipboard = true, rawText = null, force = false, keepAssist = false } = {}) {
    try {
      let text = rawText;
      if (fromClipboard && text == null) {
        text = await navigator.clipboard.readText();
      }
      if (!String(text || '').trim()) {
        this.callbacks.onToast?.('Nada para colar — copie a letra e tente de novo.');
        return false;
      }
      const cleaned = cleanPastedLyrics(text);
      if (!cleaned.trim()) {
        this.callbacks.onToast?.('Texto colado vazio após limpeza.');
        return false;
      }
      if (!force && this.draft?.lyrics?.trim()) {
        if (!confirm('Substituir a letra atual pela colada?')) return false;
      }
      const detected = detectBlocks(cleaned);
      this.draft.lyrics = detected.lyrics;
      this.draft.blocks = detected.blocks;
      this.draft.updatedAt = Date.now();
      this._assistPasteDraft = '';
      if (!keepAssist) this._assistOpen = false;
      // Atualiza só a letra + prévia — sem re-render completo da biblioteca
      this.applyLyricsToDom();
      this.schedulePreview();
      this.syncAssistPanel();
      this.callbacks.onToast?.('Letra colada e normalizada (sem cifras).');
      return true;
    } catch {
      this.callbacks.onToast?.('Não foi possível ler a área de transferência. Cole com Ctrl+V no campo da letra.');
      this.container?.querySelector('#we-lyrics')?.focus();
      return false;
    }
  }

  /** Atualiza textarea da letra e contador de estrofes sem re-montar o editor. */
  applyLyricsToDom() {
    const ta = this.container?.querySelector('#we-lyrics');
    if (ta && this.draft) ta.value = this.draft.lyrics || '';
    const n = String(this.draft?.lyrics || '').split(/\n\s*\n/).filter((b) => b.trim()).length;
    const hint = this.container?.querySelector('#we-stanza-hint');
    if (hint) hint.textContent = `${n} estrofe${n === 1 ? '' : 's'} · linha em branco = nova estrofe`;
  }

  showImportAssist() {
    if (this.callbacks.onOpenImportStudio) {
      this.callbacks.onOpenImportStudio();
      return;
    }
    void this.openImportStudioFallback();
  }

  hideImportAssist() {
    /* painel legado removido — Import Studio é o fluxo principal */
  }

  toggleImportAssist() {
    this.showImportAssist();
  }

  syncAssistPanel() {
    /* no-op — assist legado removido */
  }

  scheduleAssistCleanPreview() {}
  updateAssistCleanPreview() {}

  async openImportStudioFallback() {
    const { openLyricsImportStudio } = await import('./lyrics-engine/ui/lyrics-import-studio.js');
    const q = [this.draft?.title, this.draft?.artist].filter(Boolean).join(' ').trim();
    openLyricsImportStudio({
      query: q,
      onToast: (msg) => this.callbacks.onToast?.(msg),
      onSaved: (song) => {
        this.setDraft(song);
        this.render();
      },
    });
  }

  async searchLyricsOnline() {
    this.showImportAssist();
  }

  async applyAssistPaste() {
    return this.pasteLyrics({ fromClipboard: true, force: false, keepAssist: false });
  }

  async clipboardIntoAssist() {
    return this.pasteLyrics({ fromClipboard: true });
  }

  autoSplit() {
    if (!this.draft?.lyrics) return;
    this.rememberCaret();
    const st = this.draft.style || {};
    this.draft.lyrics = autoSplitLyrics(this.draft.lyrics, {
      maxLines: st.linesPerSlide || DEFAULT_MAX_LINES,
      maxChars: st.maxCharsPerLine || DEFAULT_MAX_CHARS,
    });
    this.draft.style = { ...st, splitMode: 'stanza' };
    const ta = this.container.querySelector('#we-lyrics');
    if (ta) ta.value = this.draft.lyrics;
    this.syncPresetUi();
    this.renderPreview();
    this.restoreCaret();
    this.callbacks.onToast?.('Letra dividida automaticamente (por estrofe).');
  }

  formatSelection(mode) {
    const ta = this.container.querySelector('#we-lyrics');
    if (!ta || !this.draft) return;
    const start = ta.selectionStart;
    const end = ta.selectionEnd;
    if (start === end) {
      this.callbacks.onToast?.('Selecione o trecho para formatar.');
      return;
    }
    let chunk = (this.draft.lyrics || '').slice(start, end);
    if (mode === 'upper') chunk = chunk.toUpperCase();
    else if (mode === 'lower') chunk = chunk.toLowerCase();
    else if (mode === 'title') {
      chunk = chunk.replace(/\S+/g, (w) => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase());
    }
    this.draft.lyrics = (this.draft.lyrics || '').slice(0, start) + chunk + (this.draft.lyrics || '').slice(end);
    this.draft.updatedAt = Date.now();
    this.syncStructureFromDraft();
    ta.value = this.draft.lyrics;
    ta.focus();
    ta.setSelectionRange(start, start + chunk.length);
    this.schedulePreview();
  }

  insertStanzaBreak() {
    const ta = this.container.querySelector('#we-lyrics');
    if (!ta || !this.draft) return;
    const start = ta.selectionStart ?? 0;
    const end = ta.selectionEnd ?? start;
    const before = (this.draft.lyrics || '').slice(0, start);
    const after = (this.draft.lyrics || '').slice(end);
    const insert = before.endsWith('\n') || before === '' ? '\n' : '\n\n';
    this.draft.lyrics = `${before}${insert}${after}`;
    this.draft.updatedAt = Date.now();
    this.syncStructureFromDraft();
    ta.value = this.draft.lyrics;
    const caret = start + insert.length;
    ta.focus();
    ta.setSelectionRange(caret, caret);
    this.schedulePreview();
  }

  addBlockMarker(type) {
    if (!this.draft) return;
    this.rememberCaret();
    const ta = this.container.querySelector('#we-lyrics');
    const pos = ta?.selectionStart ?? (this.draft.lyrics || '').length;
    const before = (this.draft.lyrics || '').slice(0, pos);
    const lineIndex = before.split('\n').length - 1;
    this.draft.lyrics = insertBlockMarker(this.draft.lyrics, lineIndex, type);
    this.render();
  }

  render() {
    if (!this.container) return;
    if (this._previewObs) {
      this._previewObs.disconnect();
      this._previewObs = null;
    }
    if (this._previewFitDispose) {
      try { this._previewFitDispose(); } catch { /* ignore */ }
      this._previewFitDispose = null;
    }
    if (!this.draft) {
      this.container.innerHTML = `
        <div class="worship-editor-empty">
          <p class="worship-editor-empty-title">Editor de louvor</p>
          <p class="muted">Selecione uma música na lista à esquerda ou use <strong>Importar música</strong> para começar.</p>
          <p class="worship-editor-empty-steps muted">1. Identificação · 2. Letra (projetor) · 3. Cifra (músicos) · 4. Projeção</p>
        </div>`;
      return;
    }

    const d = this.draft;
    const st = d.style || {};
    const cats = this.categories || [];
    const activePreset = this.getActivePreset();
    const stanzaCount = String(d.lyrics || '').split(/\n\s*\n/).filter((b) => b.trim()).length;
    const mainTab = this._mainTab || 'lyrics';
    const chordSourceUrl = d.importMeta?.chordSourceUrl || d.chordSourceUrl || '';
    const isSystemDefault = !!(d.systemDefault || d.protected);
    const showRestore = isSystemDefault && this._defaultEdited;

    const mainTabs = [
      { id: 'meta', label: 'Identificação' },
      { id: 'lyrics', label: 'Letra' },
      { id: 'chords', label: 'Cifra' },
      { id: 'projection', label: 'Projeção' },
    ];

    this.container.innerHTML = `
      <div class="worship-editor">
        <header class="worship-editor-topbar">
          <div class="worship-editor-topbar-left">
            <p class="worship-editor-kicker">Louvor selecionado</p>
            <h2 class="worship-editor-song-title">${esc(d.title || 'Sem título')}</h2>
            <div class="worship-dual-track-status worship-editor-status" aria-label="Trilhas">
              <span class="lyrics-studio-track-chip ${d.lyrics?.trim() ? 'is-ready' : 'is-empty'}">Letra ${d.lyrics?.trim() ? '✓' : '—'}</span>
              <span class="lyrics-studio-track-chip ${d.chordSource?.trim() ? 'is-ready' : 'is-empty'}">Cifra ${d.chordSource?.trim() ? '✓' : '—'}</span>
              ${d.key ? `<span class="worship-editor-meta-chip">Tom ${esc(d.key)}</span>` : ''}
              ${isSystemDefault ? `<span class="worship-protected-badge">${this._defaultEdited ? 'Padrão · editado' : 'Padrão do sistema'}</span>` : ''}
            </div>
          </div>
          <div class="worship-editor-topbar-actions">
            ${showRestore ? '<button type="button" class="btn btn-secondary btn-sm" id="we-restore-default" title="Restaurar letra e cifra originais">↩ Restaurar original</button>' : ''}
          </div>
          <nav class="worship-editor-main-tabs" role="tablist" aria-label="Seções do editor">
            ${mainTabs.map((t) => `
              <button type="button" class="worship-editor-main-tab ${mainTab === t.id ? 'is-active' : ''}"
                data-main-tab="${t.id}" role="tab" aria-selected="${mainTab === t.id}">${t.label}</button>
            `).join('')}
          </nav>
        </header>

        <div class="worship-editor-body">
          <div class="worship-editor-scroll">
            <section class="worship-editor-pane ${mainTab === 'meta' ? 'is-active' : ''}" id="we-pane-meta" ${mainTab !== 'meta' ? 'hidden' : ''}>
              <header class="worship-section-head">
                <div>
                  <h3>Identificação</h3>
                  <p class="worship-section-hint">Título e metadados usados na busca de letra e cifra.</p>
                </div>
                <label class="worship-check worship-check--inline">
                  <input type="checkbox" id="we-favorite" ${d.favorite ? 'checked' : ''}/> Favorita
                </label>
              </header>
              <div class="worship-meta-primary">
                <div class="form-row"><label for="we-title">Título *</label>
                  <input type="text" id="we-title" value="${escAttr(d.title)}" autocomplete="off" /></div>
                <div class="form-row"><label for="we-artist">Autor / artista</label>
                  <input type="text" id="we-artist" value="${escAttr(d.artist || '')}" placeholder="Ex.: Harpa Cristã" /></div>
                <div class="form-row"><label for="we-key">Tom</label>
                  <input type="text" id="we-key" value="${escAttr(d.key || '')}" placeholder="G, Am…" /></div>
                <div class="form-row"><label for="we-capo">Capo</label>
                  <input type="number" id="we-capo" min="0" max="11" value="${d.capo || 0}" /></div>
                <div class="form-row"><label for="we-category">Categoria</label>
                  <select id="we-category">
                    <option value="">—</option>
                    ${cats.map((c) => `<option value="${escAttr(c)}" ${d.category === c ? 'selected' : ''}>${esc(c)}</option>`).join('')}
                  </select></div>
              </div>
              <details class="worship-more-meta" open>
                <summary>Mais detalhes</summary>
                <div class="worship-meta-extra">
                  <div class="form-row"><label for="we-hinario">Hinário (CC 15, HCC 12…)</label>
                    <input type="text" id="we-hinario" value="${escAttr(formatHinarioRefsList(d.hinarioRefs || []))}" placeholder="CC 15, HC 120" /></div>
                  <div class="form-row"><label for="we-subtitle">Subtítulo</label>
                    <input type="text" id="we-subtitle" value="${escAttr(d.subtitle || '')}" /></div>
                  <div class="form-row"><label for="we-composer">Compositor</label>
                    <input type="text" id="we-composer" value="${escAttr(d.composer || '')}" /></div>
                  <div class="form-row"><label for="we-ccli">Número CCLI</label>
                    <input type="text" id="we-ccli" value="${escAttr(d.ccliNumber || '')}" placeholder="ex.: 1234567" inputmode="numeric" /></div>
                  <div class="form-row"><label for="we-bpm">BPM</label>
                    <input type="number" id="we-bpm" min="40" max="240" value="${d.bpm || ''}" /></div>
                  <div class="form-row"><label for="we-language">Idioma</label>
                    <select id="we-language">${LANGUAGES.map((l) =>
                      `<option value="${escAttr(l)}" ${d.language === l ? 'selected' : ''}>${esc(l)}</option>`
                    ).join('')}</select></div>
                  <div class="form-row"><label for="we-tags">Tags</label>
                    <input type="text" id="we-tags" value="${escAttr((d.tags || []).join(', '))}" placeholder="vírgula" /></div>
                  <div class="form-row form-row--full"><label for="we-notes">Observações</label>
                    <textarea id="we-notes" rows="2">${esc(d.notes || '')}</textarea></div>
                </div>
              </details>
            </section>

            <section class="worship-editor-pane ${mainTab === 'lyrics' ? 'is-active' : ''}" id="we-pane-lyrics" ${mainTab !== 'lyrics' ? 'hidden' : ''}>
              <header class="worship-section-head">
                <div>
                  <h3>Letra · projeção</h3>
                  <p class="worship-section-hint" id="we-stanza-hint">${stanzaCount} estrofe${stanzaCount === 1 ? '' : 's'} · linha em branco = nova estrofe · <strong>só isto vai ao projetor</strong></p>
                </div>
              </header>
              <div class="worship-lyrics-toolbar">
                <button type="button" class="btn btn-primary btn-sm" id="we-search-lyrics" title="Abrir estúdio de importação">Importar letra</button>
                ${showRestore ? '<button type="button" class="btn btn-secondary btn-sm" id="we-restore-default-lyrics">Restaurar original</button>' : ''}
                <button type="button" class="btn btn-secondary btn-sm" id="we-paste">Colar</button>
                <button type="button" class="btn btn-secondary btn-sm" id="we-stanza-break" title="Inserir quebra de estrofe">＋ Estrofe</button>
                <div class="worship-format-group" role="group" aria-label="Formatação">
                  <button type="button" class="btn btn-ghost btn-sm" id="we-fmt-upper" title="MAIÚSCULAS">AA</button>
                  <button type="button" class="btn btn-ghost btn-sm" id="we-fmt-lower" title="minúsculas">aa</button>
                  <button type="button" class="btn btn-ghost btn-sm" id="we-fmt-title" title="Capitalizar">Aa</button>
                </div>
              </div>
              <div class="worship-lyrics-editor-shell">
                <label class="visually-hidden" for="we-lyrics">Texto da letra</label>
                <textarea id="we-lyrics" class="worship-lyrics-area" rows="16" spellcheck="false"
                  placeholder="Digite ou cole a letra limpa para o público…&#10;&#10;Linha em branco separa estrofes.">${esc(d.lyrics || '')}</textarea>
              </div>
            </section>

            <section class="worship-editor-pane ${mainTab === 'chords' ? 'is-active' : ''}" id="we-pane-chords" ${mainTab !== 'chords' ? 'hidden' : ''}>
              <header class="worship-section-head">
                <div>
                  <h3>Cifra · Stage (músicos)</h3>
                  <p class="form-hint">ChordPro para o Púlpito — não aparece na projeção do público.</p>
                </div>
              </header>
              <div class="worship-lyrics-toolbar">
                <button type="button" class="btn btn-primary btn-sm" id="we-fetch-chords">Buscar no Cifra Club</button>
                ${d.hinarioRefs?.length ? '<span class="worship-chord-hinario-hint">Busca inclui número do hinário</span>' : ''}
                ${showRestore ? '<button type="button" class="btn btn-secondary btn-sm" id="we-restore-default-chords">Restaurar original</button>' : ''}
                <button type="button" class="btn btn-ghost btn-sm" id="we-chord-to-lyrics" title="Extrair letra limpa da cifra">Gerar letra da cifra</button>
              </div>
              <p class="worship-chord-source-hint ${chordSourceUrl ? '' : 'is-empty'}" id="we-chord-source-hint">
                ${chordSourceUrl
                  ? `Fonte: <a href="${escAttr(chordSourceUrl)}" target="_blank" rel="noopener">${esc(chordSourceUrl)}</a>`
                  : 'Use o título e artista corretos na aba Identificação, depois busque aqui.'}
              </p>
              <textarea id="we-chord-source" class="worship-lyrics-area worship-chord-area" rows="14" spellcheck="false"
                placeholder="{title: Nome}&#10;{key: G}&#10;{capo: 2}&#10;[G]Linha com [C]acordes">${esc(d.chordSource || '')}</textarea>
            </section>

            <section class="worship-editor-pane ${mainTab === 'projection' ? 'is-active' : ''}" id="we-pane-projection" ${mainTab !== 'projection' ? 'hidden' : ''}>
              <header class="worship-section-head">
                <div>
                  <h3>Projeção · slides</h3>
                  <p class="worship-section-hint">Como a letra aparece no projetor e fundo visual.</p>
                </div>
              </header>
              <div class="worship-split-panel">
                <div class="worship-split-panel-head">
                  <h4>Divisão dos slides</h4>
                  <p>Quantas linhas ou estrofes aparecem em cada tela.</p>
                </div>
                <div class="slide-preset-bar worship-preset-bar" id="we-presets" role="group" aria-label="Divisão dos slides">
                  ${SPLIT_PRESETS.map((p) => `
                    <button type="button" class="slide-preset-btn${activePreset === p.id ? ' is-active' : ''}"
                      data-preset="${p.id}" title="${escAttr(p.hint)}">${esc(p.label)}</button>
                  `).join('')}
                </div>
                <div class="worship-split-actions">
                  <button type="button" class="btn btn-secondary btn-sm" id="we-split" title="Reorganizar com linha em branco entre slides">Auto-dividir texto</button>
                </div>
              </div>
              <div class="worship-structure-panel">
                <h4>Estrutura (marcar trechos na letra)</h4>
                <div class="worship-block-btns">
                  ${BLOCK_TYPES.slice(0, 5).map((b) =>
                    `<button type="button" class="btn btn-ghost btn-sm" data-block="${b.id}">${b.label}</button>`
                  ).join('')}
                </div>
              </div>
              <div class="worship-bg-panel">
                <h4>Fundo na projeção</h4>
                <div class="worship-meta-extra worship-bg-grid">
                  <div class="form-row">
                    <label for="we-bg-preset">Gradiente</label>
                    <select id="we-bg-preset">
                      <option value="theme" ${(st.backgroundPreset || 'theme') === 'theme' ? 'selected' : ''}>Tema</option>
                      <option value="dark" ${st.backgroundPreset === 'dark' ? 'selected' : ''}>Escuro</option>
                      <option value="gold" ${st.backgroundPreset === 'gold' ? 'selected' : ''}>Dourado</option>
                    </select>
                  </div>
                  <div class="form-row">
                    <label for="we-bg-media">Vídeo / imagem</label>
                    <select id="we-bg-media">
                      ${mediaBackgroundOptionsHtml(this.mediaList || [], st.backgroundMediaId)}
                    </select>
                  </div>
                </div>
              </div>
            </section>
          </div>

          <aside class="worship-preview-panel" aria-label="Prévia dos slides">
            <header class="worship-preview-head">
              <div>
                <span class="worship-preview-kicker">Prévia 16:9</span>
                <p class="worship-preview-sub" id="we-preview-label">Capa</p>
              </div>
              <div class="worship-preview-head-right">
                <div class="lyrics-studio-preview-tabs worship-preview-tabs" id="we-preview-tabs">
                  <button type="button" class="lyrics-studio-preview-tab ${this._previewAudience === 'public' ? 'is-active' : ''}" data-audience="public">Público</button>
                  <button type="button" class="lyrics-studio-preview-tab ${this._previewAudience === 'musician' ? 'is-active' : ''}" data-audience="musician">Músicos</button>
                </div>
                <span class="worship-preview-count" id="we-preview-count">—</span>
              </div>
            </header>
            <div class="worship-preview-meta" id="we-preview-meta" hidden></div>
            <div class="worship-preview-frame-wrap">
              <div class="lyrics-preview-box worship-preview-box" id="we-preview-box"></div>
            </div>
            <div class="worship-preview-nav" id="we-preview-nav" hidden>
              <button type="button" class="btn btn-secondary btn-sm btn-icon" id="we-prev" title="Slide anterior">${faIcon('prev')}</button>
              <span id="we-preview-pos">1 / 1</span>
              <button type="button" class="btn btn-secondary btn-sm btn-icon" id="we-next" title="Próximo slide">${faIcon('next')}</button>
            </div>
            <div class="worship-preview-chips" id="we-preview-chips"></div>
            <p class="worship-preview-hint" id="we-preview-hint">O que você vê aqui é o que o projetor mostra com a divisão escolhida.</p>
          </aside>
        </div>
      </div>`;

    this.container.querySelectorAll('#we-preview-tabs [data-audience]').forEach((btn) => {
      btn.onclick = () => {
        this._previewAudience = btn.dataset.audience || 'public';
        this.container.querySelectorAll('#we-preview-tabs [data-audience]').forEach((b) => {
          b.classList.toggle('is-active', b === btn);
        });
        this.renderPreview();
      };
    });

    this.container.querySelectorAll('[data-main-tab]').forEach((btn) => {
      btn.onclick = () => this.focusMainTab(btn.dataset.mainTab);
    });

    this.container.querySelectorAll('[data-content-tab]').forEach((btn) => {
      btn.onclick = () => this.focusContentTab(btn.dataset.contentTab);
    });

    this.bindEditorEvents();
    requestAnimationFrame(() => {
      void this.renderPreview();
      this.restoreCaret();
    });
  }

  bindEditorEvents() {
    const bind = (sel, field, transform = (v) => v) => {
      const el = this.container.querySelector(sel);
      if (!el) return;
      const apply = () => this.updateField(field, transform(el.value));
      el.oninput = apply;
      el.onchange = apply;
    };
    bind('#we-title', 'title');
    bind('#we-subtitle', 'subtitle');
    bind('#we-artist', 'artist');
    bind('#we-composer', 'composer');
    bind('#we-ccli', 'ccliNumber');
    bind('#we-key', 'key');
    bind('#we-capo', 'capo', (v) => Math.max(0, Math.min(11, Number(v) || 0)));
    bind('#we-notes', 'notes');
    bind('#we-bpm', 'bpm', (v) => (v ? Number(v) : null));
    bind('#we-language', 'language');
    bind('#we-category', 'category');
    bind('#we-hinario', 'hinarioRefs', (v) => parseHinarioRefsInput(v));
    bind('#we-tags', 'tags', (v) => v.split(',').map((t) => t.trim()).filter(Boolean));

    const lyrics = this.container.querySelector('#we-lyrics');
    lyrics?.addEventListener('input', () => {
      this.draft.lyrics = lyrics.value;
      this.draft.updatedAt = Date.now();
      this.rememberCaret();
      const n = String(lyrics.value || '').split(/\n\s*\n/).filter((b) => b.trim()).length;
      const hint = this.container.querySelector('#we-stanza-hint');
      if (hint) hint.textContent = `${n} estrofe${n === 1 ? '' : 's'} · linha em branco = nova estrofe`;
      clearTimeout(this._structureTimer);
      this._structureTimer = setTimeout(() => this.syncStructureFromDraft(), 280);
      this.schedulePreview();
    });

    const chordTa = this.container.querySelector('#we-chord-source');
    chordTa?.addEventListener('input', () => {
      this.draft.chordSource = chordTa.value;
      this.schedulePreview();
    });
    this.container.querySelector('#we-fetch-chords')?.addEventListener('click', async () => {
      if (!this.draft || !this.callbacks.onFetchChords) {
        this.callbacks.onToast?.('Busca de cifra indisponível.', 'warn');
        return;
      }
      const btn = this.container.querySelector('#we-fetch-chords');
      if (btn) { btn.disabled = true; btn.textContent = 'Buscando…'; }
      try {
        const fetched = await this.callbacks.onFetchChords(this.draft);
        if (fetched?.chordSource) {
          this.draft.chordSource = fetched.chordSource;
          if (fetched.key) this.draft.key = fetched.key;
          if (fetched.capo != null) this.draft.capo = fetched.capo;
          if (fetched.bpm != null) this.draft.bpm = fetched.bpm;
          if (Array.isArray(fetched.chordShapes)) this.draft.chordShapes = fetched.chordShapes;
          if (fetched.sourceUrl) {
            this.draft.chordSourceUrl = fetched.sourceUrl;
            this.draft.importMeta = { ...(this.draft.importMeta || {}), chordSourceUrl: fetched.sourceUrl };
          }
          this.render();
          const src = fetched.sourceUrl ? ` (${fetched.sourceUrl})` : '';
          this.callbacks.onToast?.(`Cifra encontrada no Cifra Club${src} — salve para gravar.`, 'success');
        }
      } finally {
        if (btn) { btn.disabled = false; btn.textContent = 'Buscar no Cifra Club'; }
      }
    });
    this.container.querySelector('#we-chord-to-lyrics')?.addEventListener('click', async () => {
      const { chordProToPlainLyrics } = await import('./chordpro-parser.js');
      const plain = chordProToPlainLyrics(this.draft.chordSource || '');
      if (!plain.trim()) {
        this.callbacks.onToast?.('Cole uma cifra ChordPro primeiro.', 'warn');
        return;
      }
      if (this.draft.lyrics?.trim() && !confirm('Substituir a letra limpa pela letra extraída da cifra?')) return;
      this.draft.lyrics = plain;
      if (lyrics) lyrics.value = plain;
      this.schedulePreview();
      this.callbacks.onToast?.('Letra limpa gerada a partir da cifra.', 'success');
    });
    const restoreHandler = () => this.callbacks.onRestoreDefault?.();
    this.container.querySelector('#we-restore-default')?.addEventListener('click', restoreHandler);
    this.container.querySelector('#we-restore-default-lyrics')?.addEventListener('click', restoreHandler);
    this.container.querySelector('#we-restore-default-chords')?.addEventListener('click', restoreHandler);
    lyrics?.addEventListener('click', () => this.rememberCaret());
    lyrics?.addEventListener('keyup', () => this.rememberCaret());
    lyrics?.addEventListener('select', () => this.rememberCaret());

    this.container.querySelector('#we-favorite')?.addEventListener('change', (e) => {
      this.updateField('favorite', e.target.checked);
    });

    this.container.querySelectorAll('[data-preset]').forEach((btn) => {
      btn.addEventListener('click', () => this.applyPreset(btn.dataset.preset, { reformat: true }));
    });

    this.container.querySelector('#we-bg-preset')?.addEventListener('change', (e) => {
      this.updateStyle('backgroundPreset', e.target.value || 'theme');
      if (e.target.value) this.updateStyle('backgroundMediaId', null);
      const media = this.container.querySelector('#we-bg-media');
      if (media && e.target.value) media.value = '';
    });
    this.container.querySelector('#we-bg-media')?.addEventListener('change', (e) => {
      const id = e.target.value || null;
      this.updateStyle('backgroundMediaId', id);
      if (id) {
        this.updateStyle('backgroundPreset', 'theme');
        const gp = this.container.querySelector('#we-bg-preset');
        if (gp) gp.value = 'theme';
      }
    });

    this.container.querySelector('#we-paste')?.addEventListener('click', () => this.pasteLyrics());
    this.container.querySelector('#we-search-lyrics')?.addEventListener('click', () => {
      if (this.callbacks.onOpenImportStudio) {
        this.callbacks.onOpenImportStudio();
        return;
      }
      void this.openImportStudioFallback();
    });
    this.container.querySelector('#we-split')?.addEventListener('click', () => {
      const id = this.getActivePreset();
      this.applyPreset(id, { reformat: true });
    });
    this.container.querySelector('#we-stanza-break')?.addEventListener('click', () => this.insertStanzaBreak());
    this.container.querySelector('#we-fmt-upper')?.addEventListener('click', () => this.formatSelection('upper'));
    this.container.querySelector('#we-fmt-lower')?.addEventListener('click', () => this.formatSelection('lower'));
    this.container.querySelector('#we-fmt-title')?.addEventListener('click', () => this.formatSelection('title'));

    this.container.querySelectorAll('[data-block]').forEach((btn) => {
      btn.onclick = () => this.addBlockMarker(btn.dataset.block);
    });

    this.container.querySelector('#we-prev')?.addEventListener('click', () => {
      this._previewIdx = Math.max(0, this._previewIdx - 1);
      this.renderPreview();
    });
    this.container.querySelector('#we-next')?.addEventListener('click', () => {
      this._previewIdx += 1;
      this.renderPreview();
    });
  }

  async renderPreview() {
    const box = this.container?.querySelector('#we-preview-box');
    const countEl = this.container?.querySelector('#we-preview-count');
    const nav = this.container?.querySelector('#we-preview-nav');
    const posEl = this.container?.querySelector('#we-preview-pos');
    const labelEl = this.container?.querySelector('#we-preview-label');
    const chips = this.container?.querySelector('#we-preview-chips');
    const metaEl = this.container?.querySelector('#we-preview-meta');
    const hintEl = this.container?.querySelector('#we-preview-hint');
    if (!box || !this.draft) return;

    const musician = this._previewAudience === 'musician';
    const chart = this.draft.chordSource
      ? {
        source: this.draft.chordSource,
        title: this.draft.title,
        key: this.draft.key,
        bpm: this.draft.bpm,
        capo: this.draft.capo,
      }
      : null;

    if (musician) {
      if (nav) nav.hidden = true;
      if (chips) chips.innerHTML = '';
      if (countEl) countEl.textContent = chart?.source ? 'Cifra' : 'Sem cifra';
      if (labelEl) labelEl.textContent = `Músicos · ${this.draft.title || 'Louvor'}`;
      if (metaEl) {
        const parts = [
          this.draft.key ? `Tom ${this.draft.key}` : '',
          this.draft.capo ? `Capo ${this.draft.capo}` : '',
          this.draft.bpm ? `${this.draft.bpm} BPM` : '',
        ].filter(Boolean);
        metaEl.hidden = !parts.length;
        metaEl.textContent = parts.join(' · ');
      }
      if (hintEl) {
        hintEl.textContent = 'Cifra ChordPro — tablatura e acordes no Púlpito; a projeção usa letra limpa.';
      }
      const chartHtml = renderChordChartHtml(chart, { highlightBlock: this._previewIdx, stableView: true });
      const shapes = collectUniqueChords(this.draft.chordSource || '', this.draft.chordShapes || []);
      const diagrams = shapes.length
        ? `<div class="worship-preview-diagrams">${renderChordDiagramsGrid(shapes, { accent: '#f0c94d' })}</div>`
        : '';
      box.innerHTML = `<div class="worship-preview-chord-wrap worship-preview-chord-wrap--musician">${chartHtml}${diagrams}</div>`;
      if (this._previewFitDispose) {
        try { this._previewFitDispose(); } catch { /* ignore */ }
        this._previewFitDispose = null;
      }
      if (this._previewObs) {
        this._previewObs.disconnect();
        this._previewObs = null;
      }
      return;
    }

    if (metaEl) metaEl.hidden = true;
    if (hintEl) {
      hintEl.textContent = 'O que você vê aqui é o que o projetor mostra com a divisão escolhida.';
    }

    const prefs = getPrefs();
    const style = getLyricsStyle(this.draft, prefs.globalLyricsStyle);
    const background = await resolveLyricsBackground(style, (id) =>
      this.mediaList.find((m) => m.id === id) || null
    );
    const slides = buildLyricsSlides(this.draft, style, { background });

    if (!slides.length) {
      box.innerHTML = '<div class="worship-preview-empty">Sem conteúdo</div>';
      if (countEl) countEl.textContent = '0 slides';
      if (nav) nav.hidden = true;
      if (chips) chips.innerHTML = '';
      return;
    }

    this._previewIdx = Math.max(0, Math.min(this._previewIdx, slides.length - 1));
    const idx = this._previewIdx;
    const slide = slides[idx];
    const isTitle = slide.type === 'lyrics-title';

    if (countEl) countEl.textContent = `${slides.length} slide${slides.length === 1 ? '' : 's'}`;
    if (nav) nav.hidden = slides.length < 2;
    if (posEl) posEl.textContent = `${idx + 1} / ${slides.length}`;
    if (labelEl) {
      labelEl.textContent = isTitle
        ? `Capa · ${this.draft.title || 'Louvor'}`
        : `Letra · slide ${idx + 1}`;
    }

    box.innerHTML = `<div class="lyrics-preview-scaler preview-scaler" id="we-preview-scaler">${renderPreview(slide, {}, prefs)}</div>`;
    const scaler = box.querySelector('#we-preview-scaler');
    if (this._previewFitDispose) {
      try { this._previewFitDispose(); } catch { /* ignore */ }
      this._previewFitDispose = null;
    }
    if (this._previewObs) {
      this._previewObs.disconnect();
      this._previewObs = null;
    }
    this._previewFitDispose = observeStagePreviewFit(box, scaler);
    box.querySelectorAll('video').forEach((v) => v.play()?.catch(() => {}));

    if (chips) {
      const maxChips = Math.min(slides.length, 12);
      chips.innerHTML = slides.slice(0, maxChips).map((s, i) => {
        const lbl = s.type === 'lyrics-title' ? faIconRaw('music', 'su-fa su-fa--sm') : String(i);
        return `<button type="button" class="btn btn-secondary btn-icon slide-nav-btn${i === idx ? ' is-active' : ''}" data-i="${i}">${lbl}</button>`;
      }).join('') + (slides.length > maxChips
        ? `<span class="worship-preview-more">+${slides.length - maxChips}</span>`
        : '');
      chips.querySelectorAll('[data-i]').forEach((btn) => {
        btn.onclick = () => {
          this._previewIdx = Number(btn.dataset.i);
          this.renderPreview();
        };
      });
    }
  }

  destroy() {
    clearTimeout(this.syncTimer);
    this.syncTimer = null;
    clearTimeout(this._assistPreviewTimer);
    this._assistPreviewTimer = null;
    clearTimeout(this._structureTimer);
    this._structureTimer = null;
    if (this._previewFitDispose) {
      try { this._previewFitDispose(); } catch { /* ignore */ }
      this._previewFitDispose = null;
    }
    if (this._previewObs) {
      try { this._previewObs.disconnect(); } catch { /* ignore */ }
      this._previewObs = null;
    }
    this.draft = null;
    this.container = null;
  }
}
