/**
 * Converte HTML de sites de cifra (CifraClub etc.) para ChordPro.
 */
const CHORD_TOKEN = /^[A-G][#b]?(?:maj|min|m|dim|aug|sus|add|maj7|m7|7|9|11|13|6|º|°|\d)*(?:\/[A-G][#b]?)?$/i;

export function isLikelyChordLine(line) {
  const t = String(line || '').trim();
  if (!t) return false;
  const parts = t.split(/\s+/).filter(Boolean);
  if (!parts.length) return false;
  return parts.every((p) => CHORD_TOKEN.test(p.replace(/[()[\]]/g, '')));
}

function stripAccents(s) {
  return String(s || '')
    .normalize('NFD')
    .replace(/\p{M}/gu, '')
    .toLowerCase()
    .replace(/\s+/g, ' ')
    .trim();
}

/** Fold para comparar títulos (ignora ! , . (A) etc.). */
export function foldCifraText(s) {
  return stripAccents(s)
    .replace(/[^a-z0-9\s]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

/** Extrai número de hino do título Cifra ("001 - Antífona", "Rende o Coração - 571"). */
export function extractCifraDocHymnNumber(docTitle) {
  const raw = String(docTitle || '').trim();
  if (!raw) return null;
  const lead = raw.match(/^(\d{1,4})[A-Za-z]?\s*[-–—.:]/);
  if (lead) return parseInt(lead[1], 10);
  const tagged = raw.match(/\b(?:HC|CC|HCC|HNC|HM|HE)\s*[.-]?\s*(\d{1,4})\b/i);
  if (tagged) return parseInt(tagged[1], 10);
  const trail = raw.match(/[-–—]\s*(\d{1,4})[A-Za-z]?\s*$/);
  if (trail) return parseInt(trail[1], 10);
  return null;
}

/** Remove sufixo/prefixo de hinário e ruído "(2)" / "(A)" para melhorar busca. */
export function normalizeCifraSearchTitle(title) {
  return String(title || '')
    .trim()
    .replace(/^\(\s*[A-Za-z0-9]{1,4}\s*\)\s*/i, '')
    .replace(/\s*\(\s*\d{1,3}\s*\)\s*$/i, '')
    .replace(/^[A-Z]{2,4}\s*\d{1,4}[A-Za-z]?\s*[-–—]\s*/i, '')
    .replace(/^\d{1,4}[A-Za-z]?\s*[-–—.:]\s*/i, '')
    .replace(/\s*[-–—]\s*(?:HC|CC|HCC|HNC|HM|HE|H\s*C)?\s*\d{1,4}[A-Za-z]?\s*$/i, '')
    .trim();
}

export function normalizeCifraSearchQuery(title, artist) {
  const t = normalizeCifraSearchTitle(title);
  const a = String(artist || '').trim();
  return { title: t, artist: a, query: [t, a].filter(Boolean).join(' ') };
}

function titleTokenOverlap(a, b) {
  const ta = foldCifraText(a).split(/\s+/).filter((w) => w.length > 1);
  const tb = new Set(foldCifraText(b).split(/\s+/).filter((w) => w.length > 1));
  if (!ta.length || !tb.size) return 0;
  let hits = 0;
  for (const w of ta) if (tb.has(w)) hits += 1;
  return hits / ta.length;
}

function artistsLooselyMatch(na, da) {
  const a = foldCifraText(na);
  const b = foldCifraText(da);
  if (!a || !b) return false;
  if (a === b) return true;
  if (a.includes(b) || b.includes(a)) return true;
  // "HCC - Hinário Para o Culto Cristão" ↔ "Hinário Para o Culto Cristão"
  const aCore = a.replace(/^(hcc|hc|cc|hnc|he|hm)\s+/, '');
  const bCore = b.replace(/^(hcc|hc|cc|hnc|he|hm)\s+/, '');
  return !!(aCore && bCore && (aCore.includes(bCore) || bCore.includes(aCore)));
}

export function buildCifraClubSolrUrl(query, limit = 8) {
  const q = encodeURIComponent(String(query || '').trim());
  return `https://solr.sscdn.co/cc/h2/?q=${q}&limit=${limit}&callback=cc`;
}

export function buildCifraClubSearchUrl(title, artist) {
  const { query } = normalizeCifraSearchQuery(title, artist);
  return `https://www.cifraclub.com.br/busca/?q=${encodeURIComponent(query)}`;
}

export function buildCifraClubSongUrl(slug) {
  if (!slug) return '';
  return `https://www.cifraclub.com.br/${slug.replace(/^\//, '')}`;
}

export function buildCifraClubUrlFromSlugs(artistSlug, songSlug) {
  if (!artistSlug || !songSlug) return '';
  return `https://www.cifraclub.com.br/${artistSlug}/${songSlug}/`;
}

/** Parse resposta JSONP da API Solr do CifraClub. */
export function parseCifraClubSolrJsonp(body) {
  const raw = String(body || '').trim();
  if (!raw) return [];
  const start = raw.indexOf('{');
  const end = raw.lastIndexOf('}');
  if (start < 0 || end <= start) return [];
  try {
    const data = JSON.parse(raw.slice(start, end + 1));
    return data?.response?.docs || [];
  } catch {
    return [];
  }
}

/**
 * @param {object} doc
 * @param {string} title
 * @param {string} artist
 * @param {{ hymnNumber?: number|null }} [opts]
 */
export function scoreCifraSolrDoc(doc, title, artist, opts = {}) {
  const { title: nt, artist: na } = normalizeCifraSearchQuery(title, artist);
  const docTitle = normalizeCifraSearchTitle(doc?.m || '');
  const docArtist = String(doc?.a || '').trim();
  let score = Number(doc?.s) || 0;

  const ntNorm = foldCifraText(nt);
  const dtNorm = foldCifraText(docTitle);
  const overlap = titleTokenOverlap(nt, docTitle);

  if (ntNorm && dtNorm === ntNorm) score += 120;
  else if (ntNorm && dtNorm && (dtNorm.includes(ntNorm) || ntNorm.includes(dtNorm))) score += 70;
  else if (overlap >= 0.6) score += 55;
  else if (overlap >= 0.35) score += 25;
  else if (ntNorm && dtNorm && overlap < 0.25) score -= 50;

  if (na && docArtist && artistsLooselyMatch(na, docArtist)) {
    const naNorm = foldCifraText(na);
    const daNorm = foldCifraText(docArtist);
    score += naNorm === daNorm ? 80 : 50;
  }

  const hymnNumber = opts.hymnNumber != null ? Number(opts.hymnNumber) : null;
  if (Number.isFinite(hymnNumber) && hymnNumber > 0) {
    const docNum = extractCifraDocHymnNumber(doc?.m || '');
    if (docNum === hymnNumber) score += 110;
    else if (docNum != null && docNum !== hymnNumber) score -= 90;
  }

  return score;
}

/** Hit aceitável: precisa de sobreposição mínima de título quando há título. */
export function isAcceptableCifraHit(hit, title, { minOverlap = 0.22, hymnNumber = null } = {}) {
  if (!hit?.url || /\/undefined\/?$/i.test(hit.url)) return false;
  const docTitle = hit.title || hit.doc?.m || '';
  const num = hymnNumber != null ? Number(hymnNumber) : null;
  if (Number.isFinite(num) && num > 0) {
    const docNum = extractCifraDocHymnNumber(docTitle);
    if (docNum === num) return true;
  }
  const nt = normalizeCifraSearchTitle(title);
  if (!nt || foldCifraText(nt).length < 3) return true;
  const overlap = titleTokenOverlap(nt, docTitle);
  if (overlap >= minOverlap) return true;
  // Título curto exato após fold
  const a = foldCifraText(nt);
  const b = foldCifraText(normalizeCifraSearchTitle(docTitle));
  return !!(a && b && (a === b || b.includes(a) || a.includes(b)));
}

/**
 * Busca músicas no Solr do CifraClub.
 * @param {string} title
 * @param {string} artist
 * @param {(url: string) => Promise<{ body?: string }>} fetchFn
 * @param {{ hymnNumber?: number|null }} [opts]
 */
export async function searchCifraClubSolr(title, artist, fetchFn, opts = {}) {
  const { query } = normalizeCifraSearchQuery(title, artist);
  if (!query || !fetchFn) return [];
  return searchCifraClubSolrByQuery(query, title, artist, fetchFn, opts);
}

/**
 * Busca Solr com query livre (ex.: "Harpa Cristã Rende O Coração").
 * @param {string} query
 * @param {string} title
 * @param {string} artist
 * @param {(url: string) => Promise<{ body?: string }>} fetchFn
 * @param {{ hymnNumber?: number|null }} [opts]
 */
export async function searchCifraClubSolrByQuery(query, title, artist, fetchFn, opts = {}) {
  const q = String(query || '').trim();
  if (!q || !fetchFn) return [];

  const url = buildCifraClubSolrUrl(q);
  const res = await fetchFn(url);
  const docs = parseCifraClubSolrJsonp(res?.body || '');

  return docs
    .map((doc) => ({
      doc,
      score: scoreCifraSolrDoc(doc, title, artist, opts),
      url: buildCifraClubUrlFromSlugs(doc.d, doc.u),
      title: doc.m || '',
      artist: doc.a || '',
    }))
    .filter((hit) => hit.url && hit.doc?.u && String(hit.doc.u) !== 'undefined')
    .sort((a, b) => b.score - a.score);
}

function findCifraPre(doc) {
  const pres = doc.querySelectorAll('pre');
  let best = null;
  let bestScore = 0;
  for (const pre of pres) {
    const text = (pre.innerText || pre.textContent || '').trim();
    if (text.length < 20) continue;
    const lines = text.split('\n').filter((l) => l.trim());
    const chordLines = lines.filter((l) => {
      const stripped = l.replace(/\[.*?\]/g, '').trim();
      return isLikelyChordLine(stripped) || /<\/?b>/i.test(l);
    }).length;
    const score = text.length + chordLines * 120;
    if (score > bestScore) {
      bestScore = score;
      best = pre;
    }
  }
  return best || doc.querySelector('[class*="cifra"]') || doc.querySelector('pre') || doc.body;
}

function stripHtmlTags(html) {
  return String(html || '')
    .replace(/<br\s*\/?>/gi, '\n')
    .replace(/<\/(p|div|li|h\d)>/gi, '\n')
    .replace(/<[^>]+>/g, '')
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>');
}

function extractKeyFromHtml(html) {
  const m = String(html || '').match(/(?:Tom|Key)(?:\s*original)?[\s:>]*([A-G](?:#|b)?)/i);
  return m?.[1] || '';
}

/** Afinação padrão ou data-tuning "E A D G B E" — evita capturas parciais ("be"). */
function extractTuningFromHtml(html) {
  const raw = String(html || '');
  const fromAttr = raw.match(/data-tuning="([EADGBe](?:\s+[EADGBe]){5})"/i);
  if (fromAttr) return fromAttr[1].trim().replace(/\s+/g, ' ').toUpperCase();
  const fromLabel = raw.match(/Afina(?:ç|c)[ãa]o\s*[:\s>]*\s*([EADGBe](?:\s+[EADGBe]){5})/i);
  if (fromLabel) return fromLabel[1].trim().replace(/\s+/g, ' ').toUpperCase();
  return 'E A D G B E';
}

export function normalizeTuningLabel(tuning) {
  const t = String(tuning || '').trim().replace(/\s+/g, ' ');
  if (/^[EADGBe](?:\s+[EADGBe]){5}$/i.test(t)) return t.toUpperCase();
  return 'E A D G B E';
}

/** Extrai diagramas de acordes do HTML Cifra Club (data-mount). */
export function extractChordShapesFromHtml(html) {
  const raw = String(html || '');
  const shapes = [];
  const seen = new Set();

  const add = (name, mount, tuning) => {
    const n = String(name || '').trim();
    const m = String(mount || '').trim();
    if (!n || !m || seen.has(n)) return;
    seen.add(n);
    shapes.push({ name: n, mount: m, tuning: tuning || 'E A D G B E' });
  };

  if (typeof document !== 'undefined') {
    const doc = new DOMParser().parseFromString(raw, 'text/html');
    const tuning = extractTuningFromHtml(raw);
    doc.querySelectorAll('.chord[data-mount], [data-mount].chord, div.chord[data-mount]').forEach((el) => {
      const mount = el.getAttribute('data-mount');
      const tuningAttr = el.getAttribute('data-tuning') || tuning;
      const name = el.querySelector('b, strong, .chord-name')?.textContent?.trim()
        || el.getAttribute('data-chord')
        || '';
      add(name, mount, tuningAttr);
    });
  }

  const re = /class="chord"[^>]*data-mount="([^"]+)"[^>]*(?:data-tuning="([^"]*)")?[^>]*>[\s\S]*?<(?:b|strong)[^>]*>([^<]+)</gi;
  let match;
  while ((match = re.exec(raw)) !== null) {
    add(match[3], match[1], match[2] || extractTuningFromHtml(raw));
  }

  return shapes;
}

function normalizeChordProSpacing(lines) {
  const out = [];
  let prevBlank = false;
  for (const line of lines) {
    const trimmed = String(line ?? '').trimEnd();
    if (!trimmed) {
      if (!prevBlank && out.length) {
        out.push('');
        prevBlank = true;
      }
      continue;
    }
    prevBlank = false;
    if (/^\[[^\]]+\]$/.test(trimmed) && !/^\[(Intro|Tab|Solo|Final|Outro)/i.test(trimmed)) {
      if (out.length && out[out.length - 1] !== '') out.push('');
      out.push(trimmed);
      out.push('');
      continue;
    }
    out.push(trimmed);
  }
  return out;
}

/** Extrai blocos letra+acordes de HTML comum (pre, span chord). */
export function cifraHtmlToChordPro(html, { title = '', artist = '' } = {}) {
  if (!html) return { chordSource: '', key: '', capo: null, bpm: null, chordShapes: [], tuning: 'E A D G B E' };

  const tuning = normalizeTuningLabel(extractTuningFromHtml(html));
  const chordShapes = extractChordShapesFromHtml(html);

  if (typeof document === 'undefined') {
    const plain = plainHtmlToChordPro(html);
    return {
      chordSource: plain,
      key: extractKeyFromHtml(html),
      capo: null,
      bpm: null,
      chordShapes,
      tuning,
    };
  }

  const doc = new DOMParser().parseFromString(html, 'text/html');
  const header = [];
  if (title) header.push(`{title: ${title}}`);
  if (artist) header.push(`{subtitle: ${artist}}`);

  const keyMatch = html.match(/(?:Tom|Key)(?:\s*original)?[\s:>]*([A-G][#b]?)/i);
  const capoMatch = html.match(/Capo(?:traste)?[\s:>]*(\d+)/i);
  const bpmMatch = html.match(/(\d{2,3})\s*BPM/i);
  const key = keyMatch?.[1] || extractKeyFromHtml(html);
  const capo = capoMatch ? Number(capoMatch[1]) : null;
  const bpm = bpmMatch ? Number(bpmMatch[1]) : null;
  if (key) header.push(`{key: ${key}}`);
  if (capo != null) header.push(`{capo: ${capo}}`);
  if (tuning) header.push(`{tuning: ${tuning}}`);

  const pre = findCifraPre(doc);
  const rawText = (pre?.innerText || pre?.textContent || stripHtmlTags(pre?.innerHTML || ''))
    .replace(/\r\n/g, '\n');
  const lines = rawText.split('\n');
  const body = [];
  let pendingChords = '';

  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed) {
      if (pendingChords) { body.push(''); pendingChords = ''; }
      body.push('');
      continue;
    }
    if (/^\[(Intro|Tab|Solo|Final|Outro|Refr|Verso|Ponte)/i.test(trimmed) || /^\[[^\]]+\]$/.test(trimmed)) {
      if (pendingChords) { body.push(pendingChords); pendingChords = ''; }
      body.push(trimmed);
      continue;
    }
    if (isLikelyChordLine(trimmed)) {
      pendingChords = trimmed;
      continue;
    }
    if (pendingChords) {
      body.push(mergeChordsIntoLyric(pendingChords, trimmed));
      pendingChords = '';
    } else {
      body.push(trimmed);
    }
  }
  if (pendingChords) body.push(pendingChords);

  const chordSource = normalizeChordProSpacing([...header, ...body]).join('\n').replace(/\n{3,}/g, '\n\n').trim();
  return {
    chordSource,
    key,
    capo,
    bpm,
    chordShapes,
    tuning,
  };
}

function mergeChordsIntoLyric(chordLine, lyricLine) {
  const chordTokens = [];
  const re = /\S+/g;
  let m;
  while ((m = re.exec(chordLine)) !== null) {
    chordTokens.push({ name: m[0], col: m.index });
  }
  if (!chordTokens.length) return lyricLine;

  let out = '';
  let li = 0;
  for (const { name, col } of chordTokens) {
    while (li < Math.min(col, lyricLine.length)) {
      out += lyricLine[li];
      li += 1;
    }
    while (li < col) {
      out += ' ';
      li += 1;
    }
    out += `[${name}]`;
  }
  out += lyricLine.slice(Math.min(li, lyricLine.length));
  return out;
}

function plainHtmlToChordPro(html) {
  return stripHtmlTags(html).trim();
}

/** Tenta extrair slug de cifra de resultados HTML. */
export function extractCifraClubLinks(html) {
  const links = [];
  const reList = [
    /href="(\/(?!estilos|aprenda|pro|musico|academy|busca|static)[^"/]+\/[^"/]+\/?)"/gi,
    /href="(https?:\/\/(?:www\.)?cifraclub\.com\.br\/[^"/]+\/[^"/]+\/?)"/gi,
  ];
  for (const re of reList) {
    let m;
    while ((m = re.exec(html)) !== null) {
      const path = m[1];
      if (/\/letra\/|\/tabs\/|\/videos\/|\/partituras\/|\/estilos\//i.test(path)) continue;
      const rel = path.replace(/^https?:\/\/(?:www\.)?cifraclub\.com\.br/i, '');
      if (!/^\/[^/]+\/[^/]+\/?$/.test(rel)) continue;
      links.push(path.startsWith('http')
        ? path.replace(/\/?$/, '/')
        : `https://www.cifraclub.com.br${path.replace(/\/?$/, '/')}`);
    }
  }
  return [...new Set(links)].slice(0, 5);
}
