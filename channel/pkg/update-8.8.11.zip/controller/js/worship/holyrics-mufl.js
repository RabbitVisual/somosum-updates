/**
 * Importação e exportação Holyrics (.muf / .mufl).
 * Formato: AES-128-CBC + SerialMap (Java) com JSON da música em "main".
 */
import { normalizeSong } from './worship-schema.js';
import { cleanPastedLyrics, detectBlocks } from './worship-parser.js';
import { randomId } from '../core/uuid.js';

/** Chave LGSaveOpen usada em arquivos .muf / .mufl individuais (Holyrics 2.x). */
export const HOLYRICS_LGSO_KEY = '$%#@keyLGSO*&\u00a812';

const IV_BYTES = new TextEncoder().encode('AAAAAAAAAAAAAAAA');

/** Prefixo fixo do ObjectOutputStream (SerialMap + HashMap) — 201 bytes. */
const SERIAL_PREFIX_HEX =
  'aced000573720022636f6d2e6c696d61676972616e2e6c67736176656f70656e2e53657269616c4d617000000000000030cb0200024a000868617368436f64654c00036d617074000f4c6a6176612f7574696c2f4d61703b78700000002809193c737200116a6176612e7574696c2e486173684d61700507dac1c31660d103000246000a6c6f6164466163746f724900095468726573686f6c6478703f400000000000000c770800000010000000017400046d61696e757200025b42acf317f8060854e00200007870';

const SERIAL_SUFFIX = new Uint8Array([0x78]);

function hexToBytes(hex) {
  const out = new Uint8Array(hex.length / 2);
  for (let i = 0; i < out.length; i++) out[i] = parseInt(hex.slice(i * 2, i * 2 + 2), 16);
  return out;
}

const SERIAL_PREFIX = hexToBytes(SERIAL_PREFIX_HEX);

function toBuffer(input) {
  if (input instanceof Uint8Array) return input;
  if (input instanceof ArrayBuffer) return new Uint8Array(input);
  if (ArrayBuffer.isView(input)) return new Uint8Array(input.buffer, input.byteOffset, input.byteLength);
  return new Uint8Array(input);
}

function concatBytes(...parts) {
  const total = parts.reduce((n, p) => n + p.length, 0);
  const out = new Uint8Array(total);
  let off = 0;
  for (const p of parts) {
    out.set(p, off);
    off += p.length;
  }
  return out;
}

export async function getHolyricsPass16(key = HOLYRICS_LGSO_KEY) {
  const k = key && String(key).trim() ? String(key) : 'A';
  try {
    const hash = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(k));
    const hex = [...new Uint8Array(hash)].map((b) => b.toString(16).padStart(2, '0')).join('').toUpperCase();
    return hex.slice(0, 16);
  } catch {
    let padded = k;
    while (padded.length < 16) padded += padded;
    return padded.slice(0, 16);
  }
}

async function importAesKey(pass16) {
  return crypto.subtle.importKey(
    'raw',
    new TextEncoder().encode(pass16),
    { name: 'AES-CBC' },
    false,
    ['encrypt', 'decrypt']
  );
}

export async function decryptHolyricsBlob(buffer) {
  const data = toBuffer(buffer);
  const pass16 = await getHolyricsPass16();
  const key = await importAesKey(pass16);
  const dec = await crypto.subtle.decrypt({ name: 'AES-CBC', iv: IV_BYTES }, key, data);
  return new Uint8Array(dec);
}

export async function encryptHolyricsBlob(serialized) {
  const data = toBuffer(serialized);
  const pass16 = await getHolyricsPass16();
  const key = await importAesKey(pass16);
  const enc = await crypto.subtle.encrypt({ name: 'AES-CBC', iv: IV_BYTES }, key, data);
  return new Uint8Array(enc);
}

/** Empacota JSON como String Java (aced0005 74 + len + utf8). */
export function wrapJavaUtf8String(jsonUtf8) {
  const utf = typeof jsonUtf8 === 'string' ? new TextEncoder().encode(jsonUtf8) : toBuffer(jsonUtf8);
  const len = new Uint8Array(2);
  len[0] = (utf.length >> 8) & 0xff;
  len[1] = utf.length & 0xff;
  return concatBytes(
    new Uint8Array([0xac, 0xed, 0x00, 0x05, 0x74]),
    len,
    utf
  );
}

export function extractHolyricsJsonFromSerialized(serialized) {
  const buf = toBuffer(serialized);
  const text = new TextDecoder('utf-8', { fatal: false }).decode(buf);
  const idx = text.indexOf('{"');
  if (idx < 0) throw new Error('Conteúdo Holyrics inválido — JSON não encontrado');
  let depth = 0;
  for (let i = idx; i < text.length; i++) {
    const c = text[i];
    if (c === '{') depth++;
    else if (c === '}') {
      depth--;
      if (depth === 0) return JSON.parse(text.slice(idx, i + 1));
    }
  }
  throw new Error('JSON Holyrics incompleto');
}

export async function parseHolyricsMuflBuffer(buffer, fileName = '') {
  const decrypted = await decryptHolyricsBlob(buffer);
  const holyrics = extractHolyricsJsonFromSerialized(decrypted);
  return holyricsMusicToSong(holyrics, fileName);
}

export function guessTitleFromMuflName(fileName, holyrics = {}) {
  const base = String(fileName || '')
    .replace(/\.mufl?$/i, '')
    .trim();
  if (holyrics.title?.trim()) return holyrics.title.trim();
  const paren = base.match(/^\(\s*(.+?)\s*\)(?:\s*\((.+)\))?$/);
  if (paren?.[1]) return paren[1].trim();
  const dash = base.match(/^(.+?)\s*[-–—]\s*(.+)$/);
  if (dash?.[1] && !holyrics.artist) return dash[1].trim();
  if (holyrics.artist?.trim()) return holyrics.artist.trim();
  return base || 'Sem título';
}

export function guessArtistFromMuflName(fileName, holyrics = {}) {
  if (holyrics.artist?.trim()) return holyrics.artist.trim();
  const base = String(fileName || '').replace(/\.mufl?$/i, '').trim();
  const paren = base.match(/^\(\s*(.+?)\s*\)\s*\(\s*(.+?)\s*\)$/);
  if (paren?.[2]) return paren[2].trim();
  const dash = base.match(/^(.+?)\s*[-–—]\s*(.+)$/);
  if (dash?.[2]) return dash[2].trim();
  return '';
}

/** Converte objeto Holyrics → song SOMOSUM. */
export function holyricsMusicToSong(holyrics, fileName = '') {
  const title = guessTitleFromMuflName(fileName, holyrics);
  const artist = guessArtistFromMuflName(fileName, holyrics);
  let lyrics = cleanPastedLyrics(String(holyrics.lyrics || ''));
  const detected = detectBlocks(lyrics);
  lyrics = detected.lyrics;

  const tags = ['importado', 'holyrics'];
  if (holyrics.set) tags.push('holyrics-set');

  return normalizeSong({
    id: randomId(),
    title,
    artist,
    composer: holyrics.author || '',
    lyrics,
    blocks: detected.blocks,
    notes: holyrics.note || '',
    language: holyrics.language && holyrics.language !== 'undefined' ? holyrics.language : 'Português',
    tags,
    source: 'holyrics-mufl',
    externalId: holyrics.id != null ? String(holyrics.id) : '',
  });
}

/** Converte song SOMOSUM → payload Holyrics para exportação. */
export function songToHolyricsMusic(song) {
  const s = song || {};
  const lyrics = String(s.lyrics || '').trim();
  return {
    id: Date.now(),
    title: String(s.title || '').trim(),
    artist: String(s.artist || '').trim(),
    lyrics,
    order: Array.isArray(s.order) ? s.order : [],
    note: String(s.notes || '').trim(),
    language: s.language || 'Português',
    formatting: '\n\n\n',
    set: 0,
    titleToSearch: String(s.title || '').trim().toLowerCase(),
    artistToSearch: String(s.artist || '').trim().toLowerCase(),
    lyricsToSearch: lyrics.toLowerCase(),
    noteToSearch: String(s.notes || '').trim().toLowerCase(),
    author: String(s.composer || '').trim(),
    numIni: 0,
    archived: false,
    modifiedTime: Date.now(),
    strParams: [null, null, null, null, null, null, '', null, null, null],
    version: 2,
  };
}

export async function encodeHolyricsMufl(holyricsMusic) {
  const json = JSON.stringify(holyricsMusic);
  const inner = wrapJavaUtf8String(json);
  const lenBuf = new Uint8Array(4);
  new DataView(lenBuf.buffer).setInt32(0, inner.length);
  const serialized = concatBytes(SERIAL_PREFIX, lenBuf, inner, SERIAL_SUFFIX);
  return encryptHolyricsBlob(serialized);
}

export async function encodeHolyricsMuflFromSong(song) {
  return encodeHolyricsMufl(songToHolyricsMusic(song));
}

export function holyricsMuflFileName(song) {
  const title = String(song?.title || song?.artist || 'louvor').trim();
  const safe = title.replace(/[<>:"/\\|?*]/g, '_').slice(0, 120);
  return `${safe}.mufl`;
}

export function isHolyricsMuflFile(name = '') {
  return /\.mufl?$/i.test(String(name));
}

function yieldToMain(ms = 0) {
  return new Promise((resolve) => {
    if (ms > 0) {
      setTimeout(resolve, ms);
      return;
    }
    if (typeof requestIdleCallback === 'function') {
      requestIdleCallback(() => resolve(), { timeout: 40 });
    } else {
      setTimeout(resolve, 0);
    }
  });
}

const CRC_TABLE = (() => {
  const table = new Uint32Array(256);
  for (let i = 0; i < 256; i++) {
    let c = i;
    for (let k = 0; k < 8; k++) c = (c & 1) ? (0xedb88320 ^ (c >>> 1)) : (c >>> 1);
    table[i] = c >>> 0;
  }
  return table;
})();

function crc32(data) {
  const buf = toBuffer(data);
  let c = 0xffffffff;
  for (let i = 0; i < buf.length; i++) c = CRC_TABLE[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}

/** ZIP store-only (sem compressão) — compatível com WebView2 offline. */
export function createStoreZip(entries) {
  const list = entries.map((e) => ({
    name: String(e.name || '').replace(/\\/g, '/'),
    data: toBuffer(e.data),
  }));
  const enc = new TextEncoder();
  const locals = [];
  const central = [];
  let offset = 0;

  for (const { name, data } of list) {
    const nameBytes = enc.encode(name);
    const local = new Uint8Array(30 + nameBytes.length);
    const dv = new DataView(local.buffer);
    dv.setUint32(0, 0x04034b50, true);
    dv.setUint16(4, 20, true);
    dv.setUint16(8, 0, true);
    dv.setUint32(14, crc32(data), true);
    dv.setUint32(18, data.length, true);
    dv.setUint32(22, data.length, true);
    dv.setUint16(26, nameBytes.length, true);
    local.set(nameBytes, 30);
    locals.push(local, data);

    const cd = new Uint8Array(46 + nameBytes.length);
    const cdv = new DataView(cd.buffer);
    cdv.setUint32(0, 0x02014b50, true);
    cdv.setUint16(4, 20, true);
    cdv.setUint16(6, 20, true);
    cdv.setUint16(10, 0, true);
    cdv.setUint32(16, crc32(data), true);
    cdv.setUint32(20, data.length, true);
    cdv.setUint32(24, data.length, true);
    cdv.setUint16(28, nameBytes.length, true);
    cdv.setUint32(42, offset, true);
    cd.set(nameBytes, 46);
    central.push(cd);
    offset += local.length + data.length;
  }

  const centralBytes = concatBytes(...central);
  const eocd = new Uint8Array(22);
  const edv = new DataView(eocd.buffer);
  edv.setUint32(0, 0x06054b50, true);
  edv.setUint16(8, list.length, true);
  edv.setUint16(10, list.length, true);
  edv.setUint32(12, centralBytes.length, true);
  edv.setUint32(16, offset, true);

  return concatBytes(...locals, centralBytes, eocd);
}

/** Tamanho padrão de lote — equilibra throughput e fluidez da UI. */
export const MUFL_IMPORT_BATCH_SIZE = 20;
export const MUFL_BATCH_PAUSE_MS = 24;
export const MUFL_PARSE_YIELD_EVERY = 6;

/**
 * Importa vários arquivos .muf/.mufl em lotes com pausas entre batches.
 */
export async function importHolyricsMuflFiles(files, {
  onProgress,
  onBatch,
  shouldCancel,
  batchSize = MUFL_IMPORT_BATCH_SIZE,
  batchPauseMs = MUFL_BATCH_PAUSE_MS,
} = {}) {
  const list = [...files].filter((f) => isHolyricsMuflFile(f.name));
  const songs = [];
  const errors = [];
  const totalBatches = Math.max(1, Math.ceil(list.length / batchSize));

  for (let b = 0; b < list.length; b += batchSize) {
    if (shouldCancel?.()) break;
    const batchFiles = list.slice(b, b + batchSize);
    const batchSongs = [];
    const batchIndex = Math.floor(b / batchSize);

    for (let i = 0; i < batchFiles.length; i++) {
      if (shouldCancel?.()) break;
      const file = batchFiles[i];
      const globalIdx = b + i + 1;
      onProgress?.({
        phase: 'parse',
        current: globalIdx,
        total: list.length,
        batch: batchIndex + 1,
        totalBatches,
        fileName: file.name,
        label: `Lendo ${globalIdx}/${list.length} · lote ${batchIndex + 1}/${totalBatches}`,
        percent: Math.round((globalIdx / list.length) * 88),
      });
      try {
        const buf = await file.arrayBuffer();
        batchSongs.push(await parseHolyricsMuflBuffer(buf, file.name));
      } catch (err) {
        errors.push({ file: file.name, message: err?.message || String(err) });
      }
      if (i % MUFL_PARSE_YIELD_EVERY === MUFL_PARSE_YIELD_EVERY - 1) {
        await yieldToMain(0);
      }
    }

    if (batchSongs.length) {
      songs.push(...batchSongs);
      if (onBatch) {
        onProgress?.({
          phase: 'persist',
          current: Math.min(b + batchSize, list.length),
          total: list.length,
          batch: batchIndex + 1,
          totalBatches,
          label: `Salvando lote ${batchIndex + 1}/${totalBatches}…`,
          percent: Math.round((Math.min(b + batchSize, list.length) / list.length) * 92),
        });
        await onBatch(batchSongs, {
          batchIndex,
          totalBatches,
          parsed: songs.length,
          errors: errors.length,
        });
      }
    }

    if (b + batchSize < list.length) {
      await yieldToMain(batchPauseMs);
    }
  }

  onProgress?.({
    phase: 'done',
    current: list.length,
    total: list.length,
    imported: songs.length,
    errors: errors.length,
    label: errors.length
      ? `Concluído — ${songs.length} ok, ${errors.length} erro(s)`
      : `${songs.length} louvor(es) importado(s)`,
    percent: 100,
  });

  return { songs, errors, imported: songs.length, skipped: errors.length };
}
