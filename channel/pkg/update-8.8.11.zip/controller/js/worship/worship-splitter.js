/**
 * Divisão inteligente em slides — respeita frases, respiração e limites de linha/caracteres.
 */
import { parseLyrics } from '../lyrics/lyrics-parser.js';

const DEFAULT_MAX_LINES = 4;
const DEFAULT_MAX_CHARS = 42;
const MIN_LAST_LINE_WORDS = 2;

function splitLongLine(line, maxChars) {
  const t = (line || '').trim();
  if (t.length <= maxChars) return [t];

  const breakPoints = [
    t.lastIndexOf(', ', Math.floor(t.length * 0.6)),
    t.lastIndexOf('; ', Math.floor(t.length * 0.6)),
    t.lastIndexOf(' — ', Math.floor(t.length * 0.6)),
    t.lastIndexOf(' - ', Math.floor(t.length * 0.6)),
    t.lastIndexOf(' ', Math.floor(t.length * 0.6)),
  ].filter((i) => i > 8);

  const idx = breakPoints.length ? Math.max(...breakPoints) : Math.floor(t.length / 2);
  const a = t.slice(0, idx).trim();
  const b = t.slice(idx).trim();
  return [a, ...splitLongLine(b, maxChars)].filter(Boolean);
}

function expandLines(lines, maxChars) {
  const out = [];
  for (const line of lines) {
    if (!line?.trim()) continue;
    out.push(...splitLongLine(line, maxChars));
  }
  return out;
}

function isSentenceEnd(line) {
  return /[.!?…:;]$/.test((line || '').trim());
}

function orphanLastLine(slide) {
  if (slide.length < 2) return false;
  const last = slide[slide.length - 1].trim();
  return last.split(/\s+/).length < MIN_LAST_LINE_WORDS;
}

/**
 * Divide letra em slides respeitando limites e respiração natural.
 * @returns {string} letra com linhas em branco entre slides
 */
export function autoSplitLyrics(rawText, options = {}) {
  const maxLines = options.maxLines || DEFAULT_MAX_LINES;
  const maxChars = options.maxChars || DEFAULT_MAX_CHARS;
  const { stanzas } = parseLyrics(rawText);
  if (!stanzas.length) return '';

  const slides = [];
  let current = [];

  const flush = () => {
    if (!current.length) return;
    // Evita linha órfã com uma palavra
    if (orphanLastLine(current) && slides.length) {
      const orphan = current.pop();
      slides[slides.length - 1].push(orphan);
    }
    slides.push(current);
    current = [];
  };

  for (const stanza of stanzas) {
    const lines = expandLines(stanza, maxChars);
    for (const line of lines) {
      if (current.length >= maxLines) flush();
      current.push(line);
      if (isSentenceEnd(line) && current.length >= Math.max(2, maxLines - 1)) flush();
    }
    if (current.length) flush();
  }

  return slides.map((s) => s.join('\n')).join('\n\n');
}

/** Converte slides em array para preview (cada slide = array de linhas). */
export function slidesFromLyrics(rawText) {
  const { stanzas } = parseLyrics(rawText);
  return stanzas.map((lines) => lines.filter(Boolean));
}

export { DEFAULT_MAX_LINES, DEFAULT_MAX_CHARS };
