/**
 * Importação offline: TXT, HTML simples, RTF, DOCX, OpenSong, OpenLP (U2-E).
 */
import { normalizeSong } from './worship-schema.js';
import { cleanPastedLyrics, detectBlocks } from './worship-parser.js';
import { randomId } from '../core/uuid.js';
import { songIdentityKey } from './song-identity.js';

export async function importFile(file) {
  const name = file?.name || 'import';
  const ext = name.split('.').pop()?.toLowerCase() || 'txt';
  if (ext === 'muf' || ext === 'mufl') {
    const { parseHolyricsMuflBuffer } = await import('./holyrics-mufl.js');
    const buf = await file.arrayBuffer();
    return [await parseHolyricsMuflBuffer(buf, name)];
  }
  const text = await readFileAsText(file, ext);
  return importFromTextAsync(text, { fileName: name });
}

/** Sync plain-text path (TXT/HTML/RTF/JSON SOMOSUM). XML routed via async. */
export function importFromText(text, { fileName = '', title = '' } = {}) {
  let lyrics = '';
  const lower = (fileName || '').toLowerCase();

  if (lower.endsWith('.somosum.json') || (text.trim().startsWith('{') && !/openlp|serviceitem/i.test(text))) {
    try {
      const parsed = JSON.parse(text);
      if (parsed.songs) return parsed.songs.map((s) => normalizeSong(s));
      if (parsed.title || parsed.lyrics) return [normalizeSong(parsed)];
    } catch { /* fall through */ }
  }

  if (fileName.endsWith('.html') || fileName.endsWith('.htm') || /<html|<body|<p[\s>]/i.test(text)) {
    lyrics = stripHtml(text);
  } else if (fileName.endsWith('.rtf') || text.startsWith('{\\rtf')) {
    lyrics = stripRtf(text);
  } else if (fileName.endsWith('.docx')) {
    throw new Error('DOCX: use importação via arquivo — leitura assíncrona necessária');
  } else {
    lyrics = text;
  }

  lyrics = cleanPastedLyrics(lyrics);
  const detected = detectBlocks(lyrics);
  lyrics = detected.lyrics;

  const guessedTitle = title || guessTitle(fileName, lyrics);
  return [normalizeSong({
    id: randomId(),
    title: guessedTitle,
    lyrics,
    blocks: detected.blocks,
    tags: ['importado'],
  })];
}

/**
 * Detecta OpenSong / OpenLP (.xml/.osz/.json) e roteia; senão usa importFromText.
 */
export async function importFromTextAsync(text, { fileName = '', title = '' } = {}) {
  const lower = (fileName || '').toLowerCase();
  const isXml = lower.endsWith('.xml') || lower.endsWith('.osz') || /<song[\s>]/i.test(text);
  const isJson = lower.endsWith('.json') || text.trim().startsWith('{');

  const looksOpenSong = lower.includes('opensong')
    || (isXml && /\[[VC]\d*\]/.test(text))
    || (isXml && /<copyright[\s>]/i.test(text) && /<lyrics[\s>]/i.test(text) && !/<verse\s/i.test(text));

  const looksOpenLp = lower.includes('openlp')
    || (isXml && /<verse\s/i.test(text))
    || (isXml && /<titles[\s>]/i.test(text))
    || (isJson && /serviceitem|openlp|"verses"/i.test(text));

  if (looksOpenSong) {
    const { importOpenSongText } = await import('./opensong-import.js');
    return importOpenSongText(text);
  }
  if (looksOpenLp) {
    const { importOpenLpText } = await import('./openlp-import.js');
    return importOpenLpText(text, { fileName });
  }
  if (isXml && /<song[\s>]/i.test(text)) {
    try {
      const { importOpenSongText } = await import('./opensong-import.js');
      return importOpenSongText(text);
    } catch {
      const { importOpenLpText } = await import('./openlp-import.js');
      return importOpenLpText(text, { fileName });
    }
  }
  return importFromText(text, { fileName, title });
}

export async function importDocxFile(file) {
  const buf = await file.arrayBuffer();
  const text = await extractDocxText(buf);
  return importFromText(text, { fileName: file.name });
}

async function readFileAsText(file, ext) {
  if (ext === 'docx') {
    const buf = await file.arrayBuffer();
    return extractDocxText(buf);
  }
  return file.text();
}

function stripHtml(html) {
  const doc = new DOMParser().parseFromString(html, 'text/html');
  return (doc.body?.textContent || html)
    .replace(/\r\n/g, '\n')
    .replace(/\n{3,}/g, '\n\n');
}

function stripRtf(rtf) {
  return rtf
    .replace(/\\par[d]?/gi, '\n')
    .replace(/\\'[0-9a-f]{2}/gi, ' ')
    .replace(/\\[a-z]+\d* ?/gi, '')
    .replace(/[{}]/g, '')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}

/** Extração mínima de DOCX (ZIP + document.xml) — sem dependências externas. */
async function extractDocxText(arrayBuffer) {
  const { unzipSync } = await importDocxZip();
  const bytes = new Uint8Array(arrayBuffer);
  const files = unzipSync(bytes);
  const xmlBytes = files['word/document.xml'];
  if (!xmlBytes) throw new Error('DOCX inválido — document.xml ausente');
  const xml = new TextDecoder('utf-8').decode(xmlBytes);
  return xml
    .replace(/<w:tab[^/]*\/>/gi, '\t')
    .replace(/<w:br[^/]*\/>/gi, '\n')
    .replace(/<\/w:p>/gi, '\n\n')
    .replace(/<[^>]+>/g, '')
    .replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}

/** Mini unzip para DOCX — apenas store method, suficiente para importação. */
async function importDocxZip() {
  return {
    unzipSync(data) {
      const view = new DataView(data.buffer, data.byteOffset, data.byteLength);
      const files = {};
      let offset = 0;
      while (offset < data.length - 4) {
        if (view.getUint32(offset, true) !== 0x04034b50) break;
        const compMethod = view.getUint16(offset + 8, true);
        const compSize = view.getUint32(offset + 18, true);
        const nameLen = view.getUint16(offset + 26, true);
        const extraLen = view.getUint16(offset + 28, true);
        const nameStart = offset + 30;
        const name = new TextDecoder().decode(data.subarray(nameStart, nameStart + nameLen));
        const dataStart = nameStart + nameLen + extraLen;
        const chunk = data.subarray(dataStart, dataStart + compSize);
        if (compMethod === 0) files[name] = chunk;
        offset = dataStart + compSize;
      }
      return files;
    },
  };
}

function guessTitle(fileName, lyrics) {
  const base = fileName.replace(/\.[^.]+$/, '').replace(/[_-]/g, ' ').trim();
  if (base && base.length > 1) return base;
  const first = lyrics.split('\n').map((l) => l.trim()).find(Boolean);
  return first?.slice(0, 60) || 'Música importada';
}

/** Mescla importados evitando duplicatas por título+artista normalizados. */
export function dedupeImports(existing, incoming) {
  const seen = new Set(existing.map((s) => songIdentityKey(s)));
  const out = [];
  for (const s of incoming) {
    const k = songIdentityKey(s);
    if (seen.has(k)) continue;
    seen.add(k);
    out.push(s);
  }
  return out;
}
