/**
 * Inferência inteligente de categoria de louvor a partir de título, artista e metadados.
 */
import { DEFAULT_CATEGORIES } from './worship-schema.js';

const RULES = [
  { category: 'Natal', patterns: [/natal/i, /christmas/i, /noite\s+feliz/i, /noel/i, /pres[eé]pio/i] },
  { category: 'Páscoa', patterns: [/p[aá]scoa/i, /easter/i, /ressurrei/i, /calv[aá]rio/i, /cruz\b/i] },
  { category: 'Ceia do Senhor', patterns: [/ceia/i, /comunh[aã]o/i, /p[aã]o\s+e\s+vinho/i, /santa\s+ceia/i] },
  { category: 'Batismo', patterns: [/batismo/i, /baptism/i] },
  { category: 'Missões', patterns: [/miss[oõ]es/i, /mission/i, /evangeliza/i] },
  { category: 'Evangelismo', patterns: [/evangelismo/i, /altar\s+call/i, /convite/i] },
  { category: 'Infantil', patterns: [/infantil/i, /\bkids?\b/i, /crian[cç]a/i, /juniores/i] },
  { category: 'Jovens', patterns: [/jovens/i, /\byouth\b/i, /adolescentes/i] },
  { category: 'Mulheres', patterns: [/mulheres/i, /ladies/i, /irm[aã]s\b/i] },
  { category: 'Homens', patterns: [/homens/i, /\bmen'?s\b/i, /irm[aã]os\b/i] },
  { category: 'Adoração', patterns: [
    /adora[cç][aã]o/i, /\bworship\b/i, /harpa\s+crist/i, /hin[aá]rio/i,
    /casa\s+worship/i, /minist[eé]rio/i, /louvor/i, /koinonya/i,
  ] },
];

const ARTIST_HINTS = [
  { category: 'Adoração', patterns: [/harpa\s+crist/i, /casa\s+worship/i, /aline\s+barros/i, /fernandinho/i, /diante\s+do\s+trono/i, /n[ií]vea\s+soares/i, /gabriel\s+guedes/i, /isaias\s+saad/i, /ministry|minist[eé]rio/i] },
  { category: 'Infantil', patterns: [/3\s*palavrinhas/i, /a\s+turminha/i] },
];

function normalizeCat(name) {
  const n = String(name || '').trim();
  if (!n) return '';
  const hit = DEFAULT_CATEGORIES.find((c) => c.toLowerCase() === n.toLowerCase());
  return hit || n;
}

/**
 * @param {{ title?: string, artist?: string, album?: string, tags?: string[], category?: string, theme?: string, hinarioRefs?: object[] }} meta
 * @param {{ categories?: string[] }} [opts]
 * @returns {string} categoria inferida ou ''
 */
export function inferSongCategory(meta = {}, opts = {}) {
  if (meta.category) return normalizeCat(meta.category);

  const allowed = opts.categories?.length ? opts.categories : DEFAULT_CATEGORIES;
  const blob = [
    meta.title,
    meta.artist,
    meta.album,
    meta.theme,
    ...(meta.tags || []),
  ].filter(Boolean).join(' · ');

  if (meta.hinarioRefs?.length) {
    const adoracao = allowed.find((c) => /adora/i.test(c)) || 'Adoração';
    return normalizeCat(adoracao);
  }

  for (const rule of ARTIST_HINTS) {
    if (!allowed.includes(rule.category) && !allowed.some((c) => c.toLowerCase() === rule.category.toLowerCase())) {
      continue;
    }
    if (rule.patterns.some((re) => re.test(meta.artist || '') || re.test(blob))) {
      return normalizeCat(rule.category);
    }
  }

  for (const rule of RULES) {
    const cat = allowed.find((c) => c.toLowerCase() === rule.category.toLowerCase()) || rule.category;
    if (!allowed.some((c) => c.toLowerCase() === cat.toLowerCase()) && opts.categories?.length) continue;
    if (rule.patterns.some((re) => re.test(blob))) return normalizeCat(cat);
  }

  // Título com número de hinário ("Nome - 193")
  if (/\s[-–—]\s*\d{1,4}\s*$/.test(String(meta.title || ''))) {
    return normalizeCat(allowed.find((c) => /adora/i.test(c)) || 'Adoração');
  }

  return '';
}

/** Contagem por categoria a partir da biblioteca. */
export function countSongsByCategory(songs = []) {
  const map = new Map();
  for (const s of songs) {
    const c = String(s.category || '').trim() || '(sem categoria)';
    map.set(c, (map.get(c) || 0) + 1);
  }
  return map;
}
