/**
 * Metadados da biblioteca: categorias, playlists e sites de pesquisa de letras.
 */
import { DiskAdapter } from '../core/storage/adapters/disk-adapter.js';
import { randomId } from '../core/uuid.js';
import {
  DEFAULT_CATEGORIES,
  DEFAULT_LYRICS_SEARCH_SITES,
  DEFAULT_PLAYLIST_NAMES,
  LYRICS_SEARCH_WINDOW,
  WORSHIP_VERSION,
} from './worship-schema.js';

const FILE = 'worship-meta.json';
let _meta = null;
let _loadPromise = null;

/** Sites que não devem aparecer no fluxo padrão (só letra). */
const BLOCKED_SITE_IDS = new Set(['cifraclub', 'google']);

function seedPlaylists(existing) {
  if (existing?.length) return existing;
  return DEFAULT_PLAYLIST_NAMES.map((name) => ({
    id: randomId(),
    name,
    songIds: [],
    createdAt: Date.now(),
    updatedAt: Date.now(),
  }));
}

function defaultMeta() {
  return {
    version: WORSHIP_VERSION,
    categories: [...DEFAULT_CATEGORIES],
    playlists: seedPlaylists([]),
    lyricsSearchSites: [...DEFAULT_LYRICS_SEARCH_SITES],
    updatedAt: Date.now(),
  };
}

/**
 * Corrige URLs antigas (/busca/ → /search/), remove cifra/google e garante Letras + Vagalume.
 * @param {Array} sites
 * @returns {{ sites: Array, changed: boolean }}
 */
export function normalizeLyricsSearchSites(sites) {
  const defaultsById = Object.fromEntries(DEFAULT_LYRICS_SEARCH_SITES.map((s) => [s.id, s]));
  let changed = false;
  const seen = new Set();
  const out = [];

  const list = Array.isArray(sites) && sites.length ? sites : DEFAULT_LYRICS_SEARCH_SITES;

  for (const raw of list) {
    if (!raw || typeof raw !== 'object') continue;
    let id = String(raw.id || '').trim().toLowerCase();
    let url = String(raw.url || '').trim();
    let name = String(raw.name || id || 'Site').trim();

    if (!id && /letras\.mus\.br/i.test(url)) id = 'letras';
    if (!id && /vagalume/i.test(url)) id = 'vagalume';
    if (!id && /cifraclub/i.test(url)) id = 'cifraclub';

    if (BLOCKED_SITE_IDS.has(id) || /cifraclub\.com/i.test(url)) {
      changed = true;
      continue;
    }

    if (id === 'letras' || /letras\.mus\.br/i.test(url)) {
      const fixed = defaultsById.letras;
      if (/\/busca\/?/i.test(url) || !url.includes('/search/')) {
        url = fixed.url;
        changed = true;
      }
      id = 'letras';
      name = fixed.name;
    }

    if (id === 'vagalume' || /vagalume\.com/i.test(url)) {
      const fixed = defaultsById.vagalume;
      if (!url) {
        url = fixed.url;
        changed = true;
      }
      id = 'vagalume';
      name = fixed.name;
    }

    if (!id || !url || !url.includes('{query}')) {
      changed = true;
      continue;
    }
    if (seen.has(id)) {
      changed = true;
      continue;
    }
    seen.add(id);
    out.push({ id, name, url });
  }

  for (const def of DEFAULT_LYRICS_SEARCH_SITES) {
    if (!seen.has(def.id)) {
      out.push({ ...def });
      seen.add(def.id);
      changed = true;
    }
  }

  // Ordem canônica: letras primeiro, depois vagalume, depois outros
  out.sort((a, b) => {
    const rank = (id) => (id === 'letras' ? 0 : id === 'vagalume' ? 1 : 2);
    return rank(a.id) - rank(b.id);
  });

  if (out.length !== (sites?.length || 0)) changed = true;
  return { sites: out, changed };
}

export async function loadWorshipMeta() {
  if (_meta) return _meta;
  if (_loadPromise) return _loadPromise;
  _loadPromise = (async () => {
    try {
      const raw = await DiskAdapter.load(FILE);
      if (raw && typeof raw === 'object') {
        const { sites, changed } = normalizeLyricsSearchSites(raw.lyricsSearchSites);
        _meta = {
          ...defaultMeta(),
          ...raw,
          categories: raw.categories?.length ? raw.categories : defaultMeta().categories,
          lyricsSearchSites: sites,
          playlists: Array.isArray(raw.playlists) && raw.playlists.length
            ? raw.playlists
            : seedPlaylists([]),
        };
        if (changed) {
          _meta.updatedAt = Date.now();
          DiskAdapter.saveDebounced(FILE, _meta);
        }
      } else {
        _meta = defaultMeta();
        try { await DiskAdapter.save(FILE, _meta); } catch { /* ignore */ }
      }
    } catch {
      _meta = defaultMeta();
      try { await DiskAdapter.save(FILE, _meta); } catch { /* ignore */ }
    }
    return _meta;
  })();
  return _loadPromise;
}

export async function saveWorshipMeta(patch = {}) {
  const current = await loadWorshipMeta();
  let next = { ...current, ...patch, updatedAt: Date.now() };
  if (patch.lyricsSearchSites) {
    next.lyricsSearchSites = normalizeLyricsSearchSites(patch.lyricsSearchSites).sites;
  }
  _meta = next;
  DiskAdapter.saveDebounced(FILE, _meta);
  return _meta;
}

export async function getCategories() {
  const m = await loadWorshipMeta();
  return [...m.categories];
}

export async function addCategory(name) {
  const label = String(name || '').trim();
  if (!label) return null;
  const m = await loadWorshipMeta();
  if (m.categories.some((c) => c.toLowerCase() === label.toLowerCase())) return m.categories;
  m.categories.push(label);
  m.categories.sort((a, b) => a.localeCompare(b, 'pt-BR'));
  await saveWorshipMeta({ categories: m.categories });
  return m.categories;
}

export async function getPlaylists() {
  const m = await loadWorshipMeta();
  return [...m.playlists];
}

export async function savePlaylist(playlist) {
  const m = await loadWorshipMeta();
  const pl = {
    id: playlist.id || randomId(),
    name: String(playlist.name || 'Nova lista').trim(),
    songIds: Array.isArray(playlist.songIds) ? [...new Set(playlist.songIds)] : [],
    createdAt: playlist.createdAt || Date.now(),
    updatedAt: Date.now(),
  };
  const idx = m.playlists.findIndex((p) => p.id === pl.id);
  if (idx >= 0) m.playlists[idx] = pl;
  else m.playlists.push(pl);
  m.playlists.sort((a, b) => a.name.localeCompare(b.name, 'pt-BR'));
  await saveWorshipMeta({ playlists: m.playlists });
  return pl;
}

export async function deletePlaylist(id) {
  const m = await loadWorshipMeta();
  m.playlists = m.playlists.filter((p) => p.id !== id);
  await saveWorshipMeta({ playlists: m.playlists });
}

/** Adiciona música a uma playlist (música pode estar em várias listas). */
export async function addSongToPlaylist(playlistId, songId) {
  if (!playlistId || !songId) return null;
  const m = await loadWorshipMeta();
  const pl = m.playlists.find((p) => p.id === playlistId);
  if (!pl) return null;
  if (!pl.songIds.includes(songId)) pl.songIds.push(songId);
  pl.updatedAt = Date.now();
  await saveWorshipMeta({ playlists: m.playlists });
  return pl;
}

export async function removeSongFromPlaylist(playlistId, songId) {
  const m = await loadWorshipMeta();
  const pl = m.playlists.find((p) => p.id === playlistId);
  if (!pl) return null;
  pl.songIds = pl.songIds.filter((id) => id !== songId);
  pl.updatedAt = Date.now();
  await saveWorshipMeta({ playlists: m.playlists });
  return pl;
}

export async function getLyricsSearchSites() {
  const m = await loadWorshipMeta();
  return [...m.lyricsSearchSites];
}

/**
 * Abre pesquisa no navegador (sem scrape — política offline / direitos autorais).
 * Sempre abre no máximo 1 site na janela nomeada `somosum-lyrics-search`.
 * @param {string} title
 * @param {string} artist
 * @param {Array|{url:string,id?:string,name?:string}|null} sitesOrSite
 * @param {{ siteId?: string }} [opts]
 */
export function openLyricsSearch(title, artist, sitesOrSite, opts = {}) {
  const query = encodeURIComponent([title, artist].filter(Boolean).join(' '));
  if (!query || query === '') return false;

  const list = Array.isArray(sitesOrSite)
    ? sitesOrSite
    : sitesOrSite
      ? [sitesOrSite]
      : DEFAULT_LYRICS_SEARCH_SITES;

  const { sites: normalized } = normalizeLyricsSearchSites(list);
  let site = normalized[0] || DEFAULT_LYRICS_SEARCH_SITES[0];
  if (opts.siteId) {
    site = normalized.find((s) => s.id === opts.siteId) || site;
  }

  const url = String(site?.url || '').replace('{query}', query);
  if (!url) return false;

  const win = window.open(url, LYRICS_SEARCH_WINDOW, 'noopener,noreferrer');
  try {
    win?.focus?.();
  } catch { /* ignore */ }
  return true;
}

export function invalidateWorshipMetaCache() {
  _meta = null;
  _loadPromise = null;
}
