/**
 * Cache LRU — pré-carrega apenas favoritas, recentes e playlist aberta.
 * Nunca carrega a biblioteca inteira na memória de trabalho da UI.
 */
const MAX_RECENT = 40;
const MAX_FAVORITES = 60;
const MAX_PLAYLIST = 80;

const recent = new Map();
const favorites = new Map();
let playlistCache = { id: null, songs: new Map() };

function touch(map, id, song, max) {
  if (map.has(id)) map.delete(id);
  map.set(id, song);
  while (map.size > max) {
    const first = map.keys().next().value;
    map.delete(first);
  }
}

export function cacheSong(song) {
  if (!song?.id) return;
  if (song.favorite) touch(favorites, song.id, song, MAX_FAVORITES);
  touch(recent, song.id, song, MAX_RECENT);
}

export function cachePlaylistSongs(playlistId, songs) {
  playlistCache = { id: playlistId, songs: new Map() };
  for (const s of songs || []) {
    if (s?.id) playlistCache.songs.set(s.id, s);
    if (playlistCache.songs.size >= MAX_PLAYLIST) break;
  }
}

export function getCachedSong(id) {
  return recent.get(id) || favorites.get(id) || playlistCache.songs.get(id) || null;
}

export function getRecentCached() {
  return [...recent.values()].reverse();
}

export function getFavoritesCached() {
  return [...favorites.values()];
}

export function clearWorshipCache() {
  recent.clear();
  favorites.clear();
  playlistCache = { id: null, songs: new Map() };
}

/** Hidrata cache a partir de metadados leves (sem letra completa). */
export function warmCacheFromSongs(songs) {
  const sortedRecent = [...songs]
    .filter((s) => s.lastUsedAt)
    .sort((a, b) => (b.lastUsedAt || 0) - (a.lastUsedAt || 0))
    .slice(0, MAX_RECENT);
  for (const s of sortedRecent) touch(recent, s.id, s, MAX_RECENT);

  const favs = songs.filter((s) => s.favorite).slice(0, MAX_FAVORITES);
  for (const s of favs) touch(favorites, s.id, s, MAX_FAVORITES);
}
