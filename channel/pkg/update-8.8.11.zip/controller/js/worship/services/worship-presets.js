import {
  createDomingoProgram,
  createDomingoComCeiaProgram,
  createJovensProgram,
  createCriancasProgram,
  createEspecialProgram,
  createQuartaProgram,
  createProgramFromTemplate,
  cultoWizardDefaults,
} from '../../program/programa-templates.js';

/** Presets litúrgicos oficiais — factories wired no wizard. */
export const WORSHIP_PRESETS = Object.freeze({
  domingo: { label: 'Dominical', factory: createDomingoProgram, wizard: 'domingo' },
  ceia: { label: 'Ceia', factory: createDomingoComCeiaProgram, wizard: 'domingo-com-ceia' },
  batismo: { label: 'Batismo', factory: (c) => createProgramFromTemplate('especial', c), wizard: 'especial' },
  casamento: { label: 'Casamento', factory: (c) => createProgramFromTemplate('especial', c), wizard: 'especial' },
  jovens: { label: 'Jovens', factory: createJovensProgram, wizard: 'jovens' },
  criancas: { label: 'Crianças', factory: createCriancasProgram, wizard: 'criancas' },
  congresso: { label: 'Congresso', factory: createEspecialProgram, wizard: 'especial' },
  conferencia: { label: 'Conferência', factory: createEspecialProgram, wizard: 'especial' },
  ebd: { label: 'EBD', factory: createQuartaProgram, wizard: 'quarta' },
  vigilia: { label: 'Vigília', factory: createEspecialProgram, wizard: 'especial' },
});

export function listWorshipPresets() {
  return Object.entries(WORSHIP_PRESETS).map(([key, p]) => ({ key, label: p.label }));
}

export function buildPresetProgram(key, church = {}) {
  const preset = WORSHIP_PRESETS[key];
  if (!preset) return createDomingoProgram(church);
  return preset.factory(church);
}

export function wizardSpecForPreset(key) {
  const preset = WORSHIP_PRESETS[key];
  if (!preset?.wizard) return cultoWizardDefaults('domingo');
  return cultoWizardDefaults(preset.wizard);
}
