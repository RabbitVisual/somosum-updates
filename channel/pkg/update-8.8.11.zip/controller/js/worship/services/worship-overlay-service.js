/** Overlays — blank/logo/ticker/countdown/alerts. */
export class WorshipOverlayService {
  constructor({ program, state, app } = {}) {
    this.program = program;
    this.state = state;
    this.app = app;
  }

  setBlank() {
    this.program?.setBlank?.();
    this.state?.patch({ overlay: 'blank' });
    this._sync();
  }

  setLogo() {
    this.program?.setLogo?.();
    this.state?.patch({ overlay: 'logo' });
    this._sync();
  }

  clear() {
    this.program?.clearOverlay?.();
    this.state?.patch({ overlay: null });
    this._sync();
  }

  broadcast(type, payload = {}) {
    this.app?.bus?.send?.('OVERLAY', { type, ...payload });
    this.state?.patch({ overlay: type, ...payload });
  }

  _sync() {
    this.app?.syncCoordinator?.emit?.({ kind: 'nav' });
  }
}
