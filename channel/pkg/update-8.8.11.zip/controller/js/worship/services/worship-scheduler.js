/** Scheduler stub — API estável para timers/triggers futuros. */
export class WorshipScheduler {
  constructor() {
    this._jobs = new Map();
  }

  schedule(trigger, action) {
    const id = `sched-${Date.now()}-${this._jobs.size}`;
    this._jobs.set(id, { trigger, action, at: Date.now(), status: 'stub' });
    return id;
  }

  cancel(id) {
    return this._jobs.delete(id);
  }

  list() {
    return [...this._jobs.entries()].map(([id, j]) => ({ id, ...j }));
  }
}
