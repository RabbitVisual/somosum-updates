/** Undo/redo administrativo — mutações de ordem (não nav ao vivo). */
export class WorshipHistory {
  constructor({ max = 32 } = {}) {
    this.max = max;
    this._undo = [];
    this._redo = [];
  }

  push(label, beforeItems, afterItems) {
    this._undo.push({ label, at: Date.now(), before: beforeItems, after: afterItems });
    if (this._undo.length > this.max) this._undo.shift();
    this._redo = [];
  }

  canUndo() { return this._undo.length > 0; }
  canRedo() { return this._redo.length > 0; }

  undo(currentItems) {
    const entry = this._undo.pop();
    if (!entry) return null;
    this._redo.push({ ...entry, before: currentItems, after: entry.before });
    return entry.before;
  }

  redo(currentItems) {
    const entry = this._redo.pop();
    if (!entry) return null;
    this._undo.push({ ...entry, before: currentItems, after: entry.after });
    return entry.after;
  }
}
