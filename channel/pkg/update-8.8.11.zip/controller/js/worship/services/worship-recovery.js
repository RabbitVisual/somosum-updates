/** Recuperação — never black screen; restore session. */
export class WorshipRecovery {
  constructor({ state, app, role = 'control' } = {}) {
    this.state = state;
    this.app = app;
    this.role = role;
    this._lastGood = null;
  }

  rememberSlide(slide) {
    if (!slide) return;
    this._lastGood = { slide, at: Date.now() };
    try {
      localStorage.setItem('somosum-worship-last-slide', JSON.stringify(this._lastGood));
    } catch { /* ignore */ }
  }

  loadLastSlide() {
    if (this._lastGood?.slide) return this._lastGood.slide;
    try {
      const raw = localStorage.getItem('somosum-worship-last-slide');
      if (raw) return JSON.parse(raw)?.slide ?? null;
    } catch { /* ignore */ }
    return null;
  }

  async restoreSession() {
    const cp = this.app?.worshipEngine?.session?.lastCheckpoint?.();
    if (cp?.state) {
      this.state.patch(cp.state);
      const flat = cp.state.flatIndex ?? 0;
      this.app?.program?.goTo?.(flat);
      this.app?.syncCoordinator?.emit?.({ kind: 'full', force: true });
      return { ok: true, source: 'checkpoint' };
    }
    const slide = this.loadLastSlide();
    if (slide && this.role === 'screen') {
      this.app?.bus?.send?.('SLIDE', { slide, animate: false });
      return { ok: true, source: 'last-slide' };
    }
    return { ok: false };
  }

  failoverScreen() {
    const slide = this.loadLastSlide();
    if (slide) return { slide, blank: false };
    return { slide: { type: 'logo' }, blank: false };
  }

  failoverStage() {
    const s = this.state?.snapshot || {};
    return {
      rundown: {
        itemIndex: s.itemIndex,
        flatIndex: s.flatIndex,
        phase: s.phase,
        cultoId: s.cultoId,
      },
    };
  }
}
