/** Estado canônico da sessão litúrgica (SSOT in-memory). */
export function createWorshipState(initial = {}) {
  return {
    sessionId: initial.sessionId || null,
    cultoId: initial.cultoId || null,
    phase: initial.phase || 'idle',
    itemIndex: initial.itemIndex ?? 0,
    flatIndex: initial.flatIndex ?? 0,
    slide: initial.slide ?? null,
    overlay: initial.overlay ?? null,
    countdown: initial.countdown ?? null,
    mediaOnAir: initial.mediaOnAir ?? null,
    bibleLive: initial.bibleLive ?? null,
    seq: initial.seq ?? 0,
    updatedAt: Date.now(),
  };
}

export class WorshipState {
  constructor(initial = {}) {
    this._state = createWorshipState(initial);
    this._listeners = new Set();
  }

  get snapshot() {
    return { ...this._state };
  }

  patch(partial) {
    this._state = {
      ...this._state,
      ...partial,
      updatedAt: Date.now(),
    };
    this._notify();
    return this._state;
  }

  subscribe(fn) {
    this._listeners.add(fn);
    return () => this._listeners.delete(fn);
  }

  _notify() {
    for (const fn of this._listeners) {
      try { fn(this.snapshot); } catch { /* ignore */ }
    }
  }
}
