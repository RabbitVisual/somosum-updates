import { validateCultoProgram } from '../../ops/culto-validate.js';

/** Validação pré-live — relatório de integridade do culto. */
export class WorshipValidation {
  constructor({ app } = {}) {
    this.app = app;
  }

  async run(cultoId) {
    let resolved = this.app?.program?.items || [];
    if (!resolved.length && cultoId) {
      const { getCulto } = await import('../../program/culto-manager.js');
      const culto = await getCulto(cultoId);
      resolved = culto?.items || [];
    }
    const base = await validateCultoProgram(resolved, {
      mediaList: this.app?.mediaList || [],
      songs: this.app?.songs || [],
    });

    const extras = [];
    for (const item of resolved) {
      if (item.slideType === 'lyrics' && item.songId) {
        const song = (this.app?.songs || []).find((s) => s.id === item.songId);
        if (song && !song.slides?.length && !song.lyrics?.trim()) {
          extras.push(`Louvor incompleto: ${item.title || song.title}`);
        }
      }
      if (item.slideType === 'bible' && item.bible?.book && !item.bible?.chapter) {
        extras.push(`Referência bíblica incompleta: ${item.title || '?'}`);
      }
    }

    return {
      cultoId: cultoId || this.app?.cultoIndex?.activeId || null,
      ok: base.ok && extras.length === 0,
      issues: [...(base.issues || []), ...extras],
      warnings: base.warnings || [],
      checkedAt: Date.now(),
    };
  }
}
