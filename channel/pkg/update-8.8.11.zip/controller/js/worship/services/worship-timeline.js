/** Timeline — sequência, markers, blocos compatível com items do culto. */
export const TIMELINE_KINDS = ['item', 'separator', 'marker', 'block'];

export function normalizeTimelineItem(item) {
  if (!item) return item;
  const kind = item.kind || 'item';
  return {
    ...item,
    kind: TIMELINE_KINDS.includes(kind) ? kind : 'item',
    notes: item.notes || '',
    estimatedSec: Number(item.estimatedSec) || 0,
  };
}

export class WorshipTimeline {
  constructor({ program } = {}) {
    this.program = program;
  }

  get items() {
    return (this.program?.items || []).map(normalizeTimelineItem);
  }

  setItems(items) {
    if (!this.program) return;
    this.program.setItems(items.map(normalizeTimelineItem));
  }

  reorder(from, to) {
    if (!this.program?.reorderItemBlocks) return false;
    return this.program.reorderItemBlocks(from, to);
  }

  insertMarker(afterIndex, label, notes = '') {
    const items = [...this.items];
    const marker = normalizeTimelineItem({
      id: `marker-${Date.now()}`,
      kind: 'marker',
      title: label,
      notes,
      slideType: 'section',
      data: { marker: true },
    });
    items.splice(afterIndex + 1, 0, marker);
    this.setItems(items);
    return marker;
  }

  insertSeparator(afterIndex, title = '—') {
    const items = [...this.items];
    const sep = normalizeTimelineItem({
      id: `sep-${Date.now()}`,
      kind: 'separator',
      title,
      slideType: 'section',
      data: { separator: true },
    });
    items.splice(afterIndex + 1, 0, sep);
    this.setItems(items);
    return sep;
  }

  estimatedTotalSec() {
    return this.items.reduce((sum, it) => sum + (Number(it.estimatedSec) || 0), 0);
  }
}
