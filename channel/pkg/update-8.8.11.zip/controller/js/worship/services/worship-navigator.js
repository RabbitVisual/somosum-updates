/** Navegação unificada — next/prev/jump. */
export class WorshipNavigator {
  constructor({ program, state, app } = {}) {
    this.program = program;
    this.state = state;
    this.app = app;
  }

  next() {
    this.program?.next?.();
    this._syncState();
  }

  prev() {
    this.program?.prev?.();
    this._syncState();
  }

  goToFlat(index) {
    this.program?.goTo?.(index);
    this._syncState();
  }

  goToItem(itemIndex, localSlide = 0) {
    if (localSlide > 0) this.program?.goToItemSlide?.(itemIndex, localSlide);
    else this.program?.goToItem?.(itemIndex);
    this._syncState();
  }

  jumpToItemId(itemId) {
    const idx = (this.program?.items || []).findIndex((it) => it.id === itemId);
    if (idx >= 0) this.goToItem(idx);
    return idx;
  }

  _syncState() {
    const ps = this.program?.getState?.() || {};
    this.state?.patch({
      itemIndex: ps.meta?.itemIndex ?? 0,
      flatIndex: ps.currentIndex ?? 0,
      slide: ps.slide ?? null,
      overlay: ps.overlay ?? null,
    });
  }
}
