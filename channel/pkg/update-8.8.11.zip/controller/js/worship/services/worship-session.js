import { randomId } from '../../core/uuid.js';

/** Sessão litúrgica — culto ativo, fase rehearsal/live/ended, checkpoints. */
export class WorshipSession {
  constructor({ state, app } = {}) {
    this.state = state;
    this.app = app;
    this._checkpoints = [];
  }

  start(cultoId, { phase = 'rehearsal' } = {}) {
    const sessionId = randomId('worship');
    this.state.patch({
      sessionId,
      cultoId,
      phase,
    });
    this._reportMetrics();
    return sessionId;
  }

  setPhase(phase) {
    this.state.patch({ phase });
    this._reportMetrics();
  }

  end() {
    this.state.patch({ phase: 'ended' });
    this._reportMetrics();
  }

  checkpoint(label = 'auto') {
    const snap = this.state.snapshot;
    this._checkpoints.push({ label, at: Date.now(), state: { ...snap } });
    if (this._checkpoints.length > 20) this._checkpoints.shift();
    return snap;
  }

  lastCheckpoint() {
    return this._checkpoints[this._checkpoints.length - 1] || null;
  }

  restoreCheckpoint(cp) {
    if (!cp?.state) return false;
    this.state.patch(cp.state);
    return true;
  }

  _reportMetrics() {
    const s = this.state.snapshot;
    try {
      fetch('/api/worship/metrics/record', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sessionId: s.sessionId,
          phase: s.phase,
          cultoId: s.cultoId,
        }),
      }).catch(() => {});
    } catch { /* offline */ }
  }
}
