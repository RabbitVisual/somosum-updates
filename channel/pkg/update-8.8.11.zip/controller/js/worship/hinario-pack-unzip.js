/**
 * Descompacta pacotes ZIP de hinários (store + deflate — WebView2).
 * Reutiliza lógica de plugin-zip.js.
 */
async function inflateRawAsync(data) {
  if (typeof DecompressionStream === 'undefined') {
    throw new Error('Deflate ZIP requer WebView2 recente');
  }
  const ds = new DecompressionStream('deflate-raw');
  const blob = new Blob([data]);
  const stream = blob.stream().pipeThrough(ds);
  const ab = await new Response(stream).arrayBuffer();
  return new Uint8Array(ab);
}

function parseLocalFiles(data) {
  const view = new DataView(data.buffer, data.byteOffset, data.byteLength);
  const entries = [];
  let offset = 0;
  while (offset < data.length - 4) {
    if (view.getUint32(offset, true) !== 0x04034b50) break;
    const compMethod = view.getUint16(offset + 8, true);
    const compSize = view.getUint32(offset + 18, true);
    const nameLen = view.getUint16(offset + 26, true);
    const extraLen = view.getUint16(offset + 28, true);
    const nameStart = offset + 30;
    const name = new TextDecoder().decode(data.subarray(nameStart, nameStart + nameLen));
    const dataStart = nameStart + nameLen + extraLen;
    const chunk = data.subarray(dataStart, dataStart + compSize);
    entries.push({ name, compMethod, chunk });
    offset = dataStart + compSize;
  }
  return entries;
}

/**
 * @param {Uint8Array} data
 * @returns {Promise<object>} pack.json parseado
 */
export async function unzipHinarioPackJson(data) {
  const entries = parseLocalFiles(data);
  if (!entries.length) throw new Error('ZIP vazio ou inválido');

  let packEntry = null;
  for (const e of entries) {
    const norm = e.name.replace(/\\/g, '/');
    if (norm.endsWith('pack.json') || norm.endsWith('.pack.json')) {
      packEntry = e;
      break;
    }
  }
  if (!packEntry) throw new Error('pack.json não encontrado no ZIP');

  let bytes = packEntry.chunk;
  if (packEntry.compMethod === 8) {
    bytes = await inflateRawAsync(packEntry.chunk);
  } else if (packEntry.compMethod !== 0) {
    throw new Error(`Método ZIP ${packEntry.compMethod} não suportado`);
  }

  const text = new TextDecoder().decode(bytes);
  const pack = JSON.parse(text);
  if (!Array.isArray(pack?.songs)) throw new Error('pack.json inválido (songs ausente)');
  return pack;
}

/**
 * @param {Response} res
 * @param {(pct: number, loaded: number, total: number) => void} [onProgress]
 */
export async function readResponseWithProgress(res, onProgress) {
  const total = Number(res.headers.get('content-length')) || 0;
  if (!res.body || !total) {
    const buf = await res.arrayBuffer();
    onProgress?.(100, buf.byteLength, buf.byteLength || 1);
    return new Uint8Array(buf);
  }

  const reader = res.body.getReader();
  const chunks = [];
  let loaded = 0;
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    chunks.push(value);
    loaded += value.byteLength;
    onProgress?.(Math.min(99, Math.round((loaded / total) * 100)), loaded, total);
  }
  const out = new Uint8Array(loaded);
  let off = 0;
  for (const c of chunks) {
    out.set(c, off);
    off += c.byteLength;
  }
  onProgress?.(100, loaded, total);
  return out;
}
