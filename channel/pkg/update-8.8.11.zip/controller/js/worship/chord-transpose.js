/**
 * Transpose / capo offline para cifras ChordPro (U1-A).
 */

const NOTES_SHARP = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'];
const NOTES_FLAT = ['C', 'Db', 'D', 'Eb', 'E', 'F', 'Gb', 'G', 'Ab', 'A', 'Bb', 'B'];
const ENHARMONIC = {
  Db: 'C#', Eb: 'D#', Gb: 'F#', Ab: 'G#', Bb: 'A#',
  'C#': 'C#', 'D#': 'D#', 'F#': 'F#', 'G#': 'G#', 'A#': 'A#',
};

function noteIndex(root) {
  const n = String(root || '').trim();
  if (!n) return -1;
  const sharp = NOTES_SHARP.indexOf(n);
  if (sharp >= 0) return sharp;
  const flat = NOTES_FLAT.indexOf(n);
  if (flat >= 0) return flat;
  const enh = ENHARMONIC[n];
  return enh ? NOTES_SHARP.indexOf(enh) : -1;
}

function preferFlats(chordRoot) {
  return /b/.test(chordRoot) || /^(F|Bb|Eb|Ab|Db|Gb)$/.test(chordRoot);
}

/**
 * Transpose a single chord token (e.g. "Am7/G", "F#m").
 * @param {string} chord
 * @param {number} semitones
 */
export function transposeChord(chord, semitones) {
  const raw = String(chord || '').trim();
  if (!raw || raw === 'N.C.' || raw === 'NC') return raw;
  const steps = ((Number(semitones) % 12) + 12) % 12;
  if (!steps && Number(semitones) === 0) return raw;

  const m = raw.match(/^([A-G][#b]?)(.*)$/);
  if (!m) return raw;
  const root = m[1];
  let rest = m[2] || '';
  let bass = '';
  const slash = rest.match(/\/([A-G][#b]?)$/);
  if (slash) {
    bass = slash[1];
    rest = rest.slice(0, -slash[0].length);
  }

  const idx = noteIndex(root);
  if (idx < 0) return raw;
  const useFlat = preferFlats(root);
  const scale = useFlat ? NOTES_FLAT : NOTES_SHARP;
  const newRoot = scale[(idx + steps) % 12];

  let newBass = '';
  if (bass) {
    const bi = noteIndex(bass);
    if (bi >= 0) newBass = '/' + (useFlat ? NOTES_FLAT : NOTES_SHARP)[(bi + steps) % 12];
    else newBass = '/' + bass;
  }
  return newRoot + rest + newBass;
}

/**
 * Apply transpose to ChordPro source text (only [chord] tokens).
 * Capo: sounding key = written key transposed by -capo (display),
 * or shift chords by +semitones for band.
 */
export function transposeChordProSource(source, semitones) {
  const steps = Number(semitones) || 0;
  if (!steps) return String(source || '');
  return String(source || '').replace(/\[([^\]]+)\]/g, (_, ch) => `[${transposeChord(ch, steps)}]`);
}

/** Capo N: chords written as if capo'd — sounding = transpose by -N for concert pitch display. */
export function applyCapoToSource(source, capo) {
  const n = Math.max(0, Math.min(11, Number(capo) || 0));
  if (!n) return String(source || '');
  // Capo 2 means shapes sound 2 semitones higher — for concert chart, transpose +2
  return transposeChordProSource(source, n);
}

export function transposeKeyLabel(key, semitones) {
  const k = String(key || '').trim();
  if (!k) return '';
  const m = k.match(/^([A-G][#b]?)(.*)$/);
  if (!m) return k;
  return transposeChord(m[1], semitones) + (m[2] || '');
}
