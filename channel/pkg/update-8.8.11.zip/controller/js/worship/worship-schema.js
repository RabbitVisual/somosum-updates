/** Schema e normalização da Biblioteca de Louvores — offline first. */
import { hinarioRefsToSearchText } from './hinario-catalog.js';
import { sanitizeSongForProjection } from './lyrics-engine/lyrics-projection-text.js';

export const WORSHIP_VERSION = 2;

export const BLOCK_TYPES = [
  { id: 'verse', label: 'Verso' },
  { id: 'chorus', label: 'Refrão' },
  { id: 'bridge', label: 'Ponte' },
  { id: 'intro', label: 'Introdução' },
  { id: 'outro', label: 'Final' },
  { id: 'instrumental', label: 'Instrumental' },
  { id: 'pre-chorus', label: 'Pré-refrão' },
  { id: 'post-chorus', label: 'Pós-refrão' },
  { id: 'hook', label: 'Hook' },
  { id: 'interlude', label: 'Interlúdio' },
  { id: 'spoken', label: 'Fala' },
  { id: 'tag', label: 'Tag' },
  { id: 'unknown', label: 'Seção' },
];

export const DEFAULT_CATEGORIES = [
  'Adoração',
  'Ceia do Senhor',
  'Missões',
  'Natal',
  'Páscoa',
  'Batismo',
  'Jovens',
  'Infantil',
  'Mulheres',
  'Homens',
  'Evangelismo',
  'Livre',
];

export const DEFAULT_PLAYLIST_NAMES = [
  'Culto Domingo Manhã',
  'Culto Domingo Noite',
  'Ceia do Senhor',
  'Conferência',
  'Congresso',
  'Especial',
];

/** Só fontes de letra (sem cifra). Letras.mus.br usa /search/ (não /busca/). */
export const DEFAULT_LYRICS_SEARCH_SITES = [
  { id: 'letras', name: 'Letras.mus.br', url: 'https://www.letras.mus.br/search/?q={query}' },
  { id: 'vagalume', name: 'Vagalume', url: 'https://www.vagalume.com.br/busca?q={query}' },
];

/** Janela nomeada reutilizada — evita empilhar abas. */
export const LYRICS_SEARCH_WINDOW = 'somosum-lyrics-search';

export const LANGUAGES = ['Português', 'Inglês', 'Espanhol', 'Outro'];

/** Metadados leves para lista/busca — letra completa sob demanda; snippet para ranking. */
export function songMetaLite(song) {
  if (!song?.id) return song;
  const lyrics = String(song.lyrics || '');
  return {
    id: song.id,
    title: song.title,
    subtitle: song.subtitle,
    artist: song.artist,
    composer: song.composer,
    ministry: song.ministry,
    key: song.key,
    bpm: song.bpm,
    language: song.language,
    category: song.category,
    theme: song.theme,
    notes: song.notes,
    ccliNumber: song.ccliNumber,
    capo: song.capo,
    tags: song.tags,
    hinarioRefs: song.hinarioRefs,
    favorite: song.favorite,
    systemDefault: song.systemDefault,
    protected: song.protected,
    useCount: song.useCount,
    lastUsedAt: song.lastUsedAt,
    createdAt: song.createdAt,
    updatedAt: song.updatedAt,
    style: song.style,
    source: song.source,
    externalId: song.externalId,
    // Trecho para score de busca (evita resultados “aleatórios” só por índice)
    lyricsSnippet: lyrics ? lyrics.slice(0, 1200) : '',
  };
}

/** Campos indexáveis para busca (metadados + letra). */
export function songSearchText(song) {
  if (!song) return '';
  return [
    song.title,
    song.subtitle,
    song.artist,
    song.composer,
    song.ministry,
    song.key,
    song.category,
    song.theme,
    song.notes,
    song.ccliNumber,
    hinarioRefsToSearchText(song.hinarioRefs),
    ...(song.tags || []),
    song.lyrics,
    song.chordSource,
  ].filter(Boolean).join(' ');
}

/** Normaliza entidade vinda de import/legado para o schema atual. */
export function normalizeSong(raw = {}) {
  const now = Date.now();
  const base = {
    id: raw.id || '',
    title: String(raw.title || 'Sem título').trim(),
    subtitle: String(raw.subtitle || '').trim(),
    artist: String(raw.artist || raw.author || '').trim(),
    composer: String(raw.composer || '').trim(),
    ministry: String(raw.ministry || '').trim(),
    key: String(raw.key || raw.tom || '').trim(),
    bpm: raw.bpm ? Number(raw.bpm) : null,
    language: String(raw.language || 'Português').trim(),
    category: String(raw.category || '').trim(),
    theme: String(raw.theme || '').trim(),
    notes: String(raw.notes || raw.observations || '').trim(),
    ccliNumber: String(raw.ccliNumber || raw.ccli || raw.data?.ccliNumber || '').trim(),
    lyrics: String(raw.lyrics || '').replace(/\r\n/g, '\n'),
    /** Fonte ChordPro (cifra) — separada da letra limpa usada na projeção. */
    chordSource: String(raw.chordSource || raw.chordpro || '').replace(/\r\n/g, '\n'),
    /** Diagramas de braço extraídos do Cifra Club — [{ name, mount, tuning? }] */
    chordShapes: Array.isArray(raw.chordShapes)
      ? raw.chordShapes
        .map((s) => ({
          name: String(s.name || '').trim(),
          mount: String(s.mount || '').trim(),
          tuning: String(s.tuning || 'E A D G B E').trim(),
        }))
        .filter((s) => s.name && s.mount)
      : [],
    capo: raw.capo != null && Number.isFinite(Number(raw.capo))
      ? Math.max(0, Math.min(11, Number(raw.capo)))
      : 0,
    tags: Array.isArray(raw.tags) ? raw.tags.map((t) => String(t).trim()).filter(Boolean) : [],
    hinarioRefs: Array.isArray(raw.hinarioRefs)
      ? raw.hinarioRefs
        .map((r) => ({
          sigla: String(r.sigla || '').toUpperCase().trim(),
          numero: Number(r.numero),
        }))
        .filter((r) => r.sigla && Number.isFinite(r.numero))
      : [],
    blocks: Array.isArray(raw.blocks) ? raw.blocks : [],
    sections: Array.isArray(raw.sections)
      ? raw.sections.map((s) => ({
        type: String(s.type || 'unknown'),
        label: String(s.label || ''),
        lines: Array.isArray(s.lines) ? s.lines.map((l) => String(l)) : [],
        confidence: Number(s.confidence) || 0,
      }))
      : [],
    source: raw.source && typeof raw.source === 'object'
      ? {
        provider: String(raw.source.provider || ''),
        url: String(raw.source.url || ''),
        retrievedAt: raw.source.retrievedAt || null,
      }
      : null,
    importMeta: raw.importMeta && typeof raw.importMeta === 'object'
      ? {
        method: String(raw.importMeta.method || ''),
        normalized: !!raw.importMeta.normalized,
        confidence: Number(raw.importMeta.confidence) || 0,
      }
      : null,
    favorite: !!raw.favorite,
    /** Louvor padrão do sistema (hinário) — não listar em browse vazio. */
    systemDefault: !!raw.systemDefault,
    /** Impede exclusão acidental; edição local permitida. */
    protected: !!raw.protected,
    useCount: Number(raw.useCount) || 0,
    lastUsedAt: raw.lastUsedAt || null,
    style: raw.style && typeof raw.style === 'object' ? { ...raw.style } : {},
    createdAt: raw.createdAt || now,
    updatedAt: raw.updatedAt || now,
  };

  // Letra é fonte da verdade; sections/blocks acompanham (preserva verso/refrão)
  const { lyrics, blocks, sections, sanitized } = sanitizeSongForProjection(base);
  base.lyrics = lyrics;
  base.blocks = blocks;
  base.sections = sections;
  if (sanitized) base.updatedAt = now;

  return base;
}

export function createEmptySong(id) {
  return normalizeSong({
    id,
    title: 'Nova Música',
    lyrics: '',
    tags: [],
    style: { splitMode: 'lines', linesPerSlide: 4 },
    createdAt: Date.now(),
  });
}

export function songListLabel(song) {
  const parts = [song.title];
  if (song.subtitle) parts.push(song.subtitle);
  return parts.join(' — ');
}

export function songMetaLine(song) {
  const bits = [];
  if (song.hinarioRefs?.length) {
    bits.push(song.hinarioRefs.map((r) => `${r.sigla} ${r.numero}`).join(', '));
  }
  if (song.artist) bits.push(song.artist);
  if (song.key) bits.push(`Tom: ${song.key}`);
  if (song.ccliNumber) bits.push(`CCLI ${song.ccliNumber}`);
  if (song.category) bits.push(song.category);
  return bits.join(' · ') || 'Sem metadados';
}
