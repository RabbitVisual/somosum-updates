/**
 * ChordPro parser offline (U1-A).
 * Extrai cifra + letra limpa; não depende de internet.
 */

const CHORD_TOKEN = /\[([^\]]+)\]/g;
const DIRECTIVE = /^\{([^}:]+)(?::\s*(.*))?\}$/;

/**
 * @typedef {{ chords: string[], lyric: string }} ChordLine
 * @typedef {{ title?: string, key?: string, lines: ChordLine[], plainLyrics: string }} ChordProSong
 */

export function isChordProText(text) {
  const s = String(text || '');
  if (!s.trim()) return false;
  if (/\{(?:title|t|key|k|subtitle|st|composer)\s*:/i.test(s)) return true;
  return (s.match(/\[[A-G][#b]?[^\]]*\]/g) || []).length >= 2;
}

/**
 * Parse ChordPro → linhas com acordes + letra limpa.
 * @param {string} source
 * @returns {ChordProSong}
 */
export function parseChordPro(source) {
  const raw = String(source || '').replace(/\r\n/g, '\n');
  const lines = [];
  let title = '';
  let key = '';
  const plain = [];

  for (const line of raw.split('\n')) {
    const trimmed = line.trim();
    const dir = trimmed.match(DIRECTIVE);
    if (dir) {
      const name = dir[1].toLowerCase();
      const val = (dir[2] || '').trim();
      if (name === 'title' || name === 't') title = val;
      else if (name === 'key' || name === 'k') key = val;
      continue;
    }
    if (!trimmed) {
      lines.push({ chords: [], lyric: '' });
      plain.push('');
      continue;
    }

    const chords = [];
    let lyric = '';
    let lastIndex = 0;
    let m;
    const re = new RegExp(CHORD_TOKEN.source, 'g');
    while ((m = re.exec(line)) !== null) {
      const before = line.slice(lastIndex, m.index);
      lyric += before;
      const col = lyric.length;
      while (chords.length < col) chords.push('');
      chords[col] = (chords[col] ? `${chords[col]} ` : '') + m[1].trim();
      lastIndex = m.index + m[0].length;
    }
    lyric += line.slice(lastIndex);
    // trim trailing empty chord slots beyond lyric
    while (chords.length > lyric.length + 1) chords.pop();
    lines.push({ chords, lyric });
    plain.push(lyric);
  }

  // collapse trailing empties lightly
  let plainLyrics = plain.join('\n').replace(/\n{3,}/g, '\n\n').trim();
  return { title, key, lines, plainLyrics };
}

/** Gera letra limpa a partir de ChordPro (projeção). */
export function chordProToPlainLyrics(source) {
  return parseChordPro(source).plainLyrics;
}

/**
 * Render linhas de cifra alinhadas (texto monoespaçado).
 * @param {ChordLine[]} lines
 * @returns {string[]}
 */
export function formatChordChartLines(lines) {
  const out = [];
  for (const row of lines || []) {
    const lyric = row.lyric || '';
    const chords = row.chords || [];
    if (!chords.some(Boolean)) {
      out.push(lyric);
      continue;
    }
    let chordLine = '';
    for (let i = 0; i < Math.max(chords.length, lyric.length); i += 1) {
      const ch = chords[i] || '';
      if (ch) {
        while (chordLine.length < i) chordLine += ' ';
        chordLine += ch;
      }
    }
    out.push(chordLine);
    out.push(lyric);
  }
  return out;
}
