/**
 * Import OpenSong XML → normalizeSong (U2-E).
 */
import { normalizeSong } from './worship-schema.js';
import { cleanPastedLyrics, detectBlocks } from './worship-parser.js';
import { randomId } from '../core/uuid.js';

function textOf(xml, tag) {
  const m = xml.match(new RegExp(`<${tag}[^>]*>([\\s\\S]*?)</${tag}>`, 'i'));
  return m ? decodeXml(m[1].trim()) : '';
}

function decodeXml(s) {
  return String(s || '')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&amp;/g, '&')
    .replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'");
}

/**
 * Converte linhas OpenSong (acordes acima / [V1] seções) em ChordPro + letra limpa.
 */
export function opensongLyricsToChordPro(raw) {
  const lines = String(raw || '').replace(/\r\n/g, '\n').split('\n');
  const out = [];
  let i = 0;
  while (i < lines.length) {
    const line = lines[i];
    const section = line.match(/^\[([^\]]+)\]\s*$/);
    if (section) {
      out.push(`{comment: ${section[1]}}`);
      i += 1;
      continue;
    }
    // Chord line often followed by lyric line (OpenSong: chords have spaces aligning)
    const next = lines[i + 1];
    if (next != null && looksLikeChordLine(line) && !looksLikeChordLine(next)) {
      out.push(mergeChordLyric(line, next));
      i += 2;
      continue;
    }
    out.push(line);
    i += 1;
  }
  return out.join('\n').trim();
}

function looksLikeChordLine(line) {
  const t = line.trim();
  if (!t) return false;
  // Mostly chords / spaces, few lowercase words
  const tokens = t.split(/\s+/).filter(Boolean);
  if (!tokens.length) return false;
  const chordish = tokens.filter((tok) => /^[A-G][#b]?(?:m|maj|min|dim|aug|sus)?\d*(?:\/[A-G][#b]?)?$/i.test(tok));
  return chordish.length >= Math.ceil(tokens.length * 0.6);
}

function mergeChordLyric(chords, lyrics) {
  // Simple: prepend chords in [] at start of lyric segments by column positions
  const c = chords;
  const l = lyrics;
  let result = '';
  let li = 0;
  for (let ci = 0; ci < c.length; ) {
    if (c[ci] === ' ') {
      if (li < l.length) {
        result += l[li];
        li += 1;
      }
      ci += 1;
      continue;
    }
    let chord = '';
    while (ci < c.length && c[ci] !== ' ') {
      chord += c[ci];
      ci += 1;
    }
    result += `[${chord}]`;
  }
  if (li < l.length) result += l.slice(li);
  return result.trimEnd();
}

export function parseOpenSongXml(xml) {
  const title = textOf(xml, 'title') || 'Música OpenSong';
  const author = textOf(xml, 'author') || textOf(xml, 'copyright') || '';
  const rawLyrics = textOf(xml, 'lyrics');
  const chordSource = opensongLyricsToChordPro(rawLyrics);
  const plain = chordSource.replace(/\[[^\]]+\]/g, '').replace(/\{[^}]+\}/g, '').trim();
  const cleaned = cleanPastedLyrics(plain || rawLyrics);
  const detected = detectBlocks(cleaned);
  return normalizeSong({
    id: randomId(),
    title,
    artist: author,
    lyrics: detected.lyrics,
    chordSource,
    blocks: detected.blocks,
    tags: ['opensong', 'importado'],
  });
}

export function importOpenSongText(text) {
  if (!/<song[\s>]/i.test(text) && !/<lyrics[\s>]/i.test(text)) {
    throw new Error('XML OpenSong invalido');
  }
  return [parseOpenSongXml(text)];
}
