/**
 * Hinários congregacionais padrão — seed offline na biblioteca.
 */
import { normalizeSong } from './worship-schema.js';
import { DEFAULT_HINARIO_CATEGORIES, hinarioNamesEqual } from './hinario-catalog.js';

export const DEFAULT_HINARIOS_SEED_VERSION = 1;

const BUNDLE_URL = '/api/data/default-hinarios.json';

/** Campos restaurados ao original do hinário. */
export const DEFAULT_RESTORE_FIELDS = [
  'title', 'subtitle', 'artist', 'composer', 'key', 'capo', 'bpm', 'language',
  'category', 'notes', 'lyrics', 'chordSource', 'ccliNumber', 'hinarioRefs', 'tags',
  'blocks', 'sections',
];

let _bundlePromise = null;
let _snapshotMap = null;

/** Registra snapshots de um pack recém-instalado (restore original). */
export function registerPackSnapshots(songs = []) {
  if (!_snapshotMap) _snapshotMap = new Map();
  for (const song of songs) {
    if (song?.id) _snapshotMap.set(song.id, song);
  }
}

/** Remove snapshots de um pack desinstalado. */
export function unregisterPackSnapshots(packId, sigla = '') {
  if (!_snapshotMap?.size) return;
  const id = String(packId || '').toLowerCase();
  const sig = String(sigla || '').toLowerCase();
  for (const key of [..._snapshotMap.keys()]) {
    const k = String(key).toLowerCase();
    if (k.includes(`hinario-${id}-`) || (sig && k.startsWith(`hinario-${sig}-`))) {
      _snapshotMap.delete(key);
    }
  }
}

function normCompare(value) {
  return String(value ?? '').replace(/\r\n/g, '\n').trim();
}

function buildSnapshotMap(bundle) {
  const map = new Map();
  for (const song of bundle?.songs || []) {
    if (song?.id) map.set(song.id, song);
  }
  return map;
}

export async function getDefaultHinarioSnapshot(songId) {
  const bundle = await fetchDefaultHinariosBundle();
  if (!_snapshotMap) _snapshotMap = buildSnapshotMap(bundle);
  return _snapshotMap.get(songId) || null;
}

export function songDiffersFromDefault(song, snapshot) {
  if (!song || !snapshot) return false;
  for (const field of DEFAULT_RESTORE_FIELDS) {
    const a = normCompare(song[field]);
    const b = normCompare(snapshot[field]);
    if (field === 'hinarioRefs') {
      const aj = JSON.stringify(song.hinarioRefs || []);
      const bj = JSON.stringify(snapshot.hinarioRefs || []);
      if (aj !== bj) return true;
      continue;
    }
    if (field === 'tags') {
      const aj = JSON.stringify(song.tags || []);
      const bj = JSON.stringify(snapshot.tags || []);
      if (aj !== bj) return true;
      continue;
    }
    if (a !== b) return true;
  }
  return false;
}

export async function hasDefaultHinarioEdits(song) {
  if (!isSystemDefaultSong(song) || !song?.id) return false;
  const snapshot = await getDefaultHinarioSnapshot(song.id);
  if (!snapshot) return false;
  return songDiffersFromDefault(song, snapshot);
}

/** Mescla snapshot no louvor atual — preserva uso, favorito e estilo de projeção. */
export function buildRestoredDefaultSong(current, snapshot) {
  if (!current || !snapshot) return null;
  const style = current.style && typeof current.style === 'object' ? { ...current.style } : {};
  return normalizeSong({
    ...snapshot,
    id: current.id,
    favorite: !!current.favorite,
    useCount: Number(current.useCount) || 0,
    lastUsedAt: current.lastUsedAt || null,
    style,
    protected: true,
    systemDefault: true,
    source: snapshot.source || current.source,
    updatedAt: Date.now(),
  });
}

export function invalidateDefaultHinariosCache() {
  _bundlePromise = null;
  _snapshotMap = null;
}

export function isSystemDefaultSong(song) {
  return !!(song?.systemDefault || song?.protected);
}

export function isHinarioCategory(name) {
  const n = String(name || '').trim();
  if (!n) return false;
  return DEFAULT_HINARIO_CATEGORIES.some((c) => hinarioNamesEqual(c, n));
}

export async function fetchDefaultHinariosBundle() {
  if (!_bundlePromise) {
    _bundlePromise = (async () => {
      const res = await fetch(BUNDLE_URL, { cache: 'no-store' });
      if (!res.ok) throw new Error(`default_hinarios_fetch_${res.status}`);
      const data = await res.json();
      const songs = Array.isArray(data?.songs) ? data.songs : [];
      return {
        version: Number(data?.version) || DEFAULT_HINARIOS_SEED_VERSION,
        count: songs.length,
        categories: data?.categories || DEFAULT_HINARIO_CATEGORIES,
        songs: songs.map((s) => normalizeSong(s)),
      };
    })();
  }
  return _bundlePromise;
}

/**
 * Mescla hinos padrão na biblioteca — preserva edições locais (id já existente).
 * @returns {{ added: number, skipped: number, total: number }}
 */
export async function seedDefaultHinarios(existingSongs, { saveManySongs, loadMeta, saveMeta, force = false } = {}) {
  const meta = await loadMeta();
  const seededVersion = Number(meta.hinarioSeedVersion) || 0;
  const hasDefaults = existingSongs.some(isSystemDefaultSong);

  if (!force && seededVersion >= DEFAULT_HINARIOS_SEED_VERSION && hasDefaults) {
    return { added: 0, skipped: 0, total: existingSongs.length };
  }

  let bundle;
  try {
    bundle = await fetchDefaultHinariosBundle();
  } catch {
    return { added: 0, skipped: 0, total: existingSongs.length, error: 'fetch_failed' };
  }

  const existingIds = new Set(existingSongs.map((s) => s.id));
  const toAdd = [];
  let skipped = 0;

  for (const seed of bundle.songs) {
    if (existingIds.has(seed.id)) {
      skipped += 1;
      continue;
    }
    toAdd.push(seed);
    existingIds.add(seed.id);
  }

  if (toAdd.length) {
    await saveManySongs(toAdd);
  }

  if (toAdd.length > 0 || seededVersion < bundle.version) {
    await saveMeta({
      hinarioSeedVersion: Math.max(bundle.version, DEFAULT_HINARIOS_SEED_VERSION),
      hinarioCategories: bundle.categories,
    });
  }

  return { added: toAdd.length, skipped, total: existingIds.size };
}

export function countSongsByKind(songs = []) {
  let user = 0;
  let hinarios = 0;
  for (const s of songs) {
    if (isSystemDefaultSong(s)) hinarios += 1;
    else user += 1;
  }
  return { user, hinarios, total: songs.length };
}
