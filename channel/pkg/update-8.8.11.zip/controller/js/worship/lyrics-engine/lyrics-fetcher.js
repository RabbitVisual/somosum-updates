/** Fetch remoto via proxy Kestrel (loopback ou LAN). */
import { isServerAvailable } from '../../core/storage/adapters/server-adapter.js';
import { authHeaders } from '../../core/security/auth-manager.js';

let _onlineCache = null;
let _onlineCheckAt = 0;

function lyricsHeaders(extra = {}) {
  return authHeaders({ 'Content-Type': 'application/json', ...extra });
}

export async function isLyricsOnline() {
  const now = Date.now();
  if (_onlineCache !== null && now - _onlineCheckAt < 5000) return _onlineCache;
  _onlineCache = await isServerAvailable();
  _onlineCheckAt = now;
  return _onlineCache;
}

export async function fetchViaProxy(url, { signal, authorization } = {}) {
  const res = await fetch('/api/worship/lyrics/proxy', {
    method: 'POST',
    headers: lyricsHeaders(),
    body: JSON.stringify({ url, authorization }),
    signal,
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    const code = err.error || `proxy_${res.status}`;
    const e = new Error(code);
    e.status = res.status;
    e.code = code;
    throw e;
  }
  return res.json();
}

export async function geniusSearch(query, { signal } = {}) {
  const res = await fetch('/api/worship/lyrics/genius/search', {
    method: 'POST',
    headers: lyricsHeaders(),
    body: JSON.stringify({ query }),
    signal,
  });
  if (res.status === 401 || res.status === 403) {
    const err = new Error('genius_auth_invalid');
    err.status = res.status;
    throw err;
  }
  if (res.status === 503) return null;
  if (!res.ok) throw new Error(`genius_search_${res.status}`);
  return res.json();
}

export async function geniusStatus() {
  try {
    const res = await fetch('/api/worship/lyrics/genius/status', { cache: 'no-store' });
    if (!res.ok) return { configured: false };
    return res.json();
  } catch {
    return { configured: false };
  }
}

export async function configureGeniusToken(accessToken) {
  const res = await fetch('/api/worship/lyrics/genius/configure', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ accessToken }),
  });
  const data = await res.json();
  try {
    const { resetGeniusProviderCache } = await import('./providers/genius-provider.js');
    resetGeniusProviderCache();
  } catch { /* ignore */ }
  return data;
}

export async function removeGeniusToken() {
  const res = await fetch('/api/worship/lyrics/genius/configure', { method: 'DELETE' });
  const data = await res.json();
  try {
    const { resetGeniusProviderCache } = await import('./providers/genius-provider.js');
    resetGeniusProviderCache();
  } catch { /* ignore */ }
  return data;
}
