/** Estados de progresso do Import Studio. */
export const PROGRESS_STAGES = [
  { id: 'search', label: 'Pesquisando...' },
  { id: 'identify', label: 'Identificando música...' },
  { id: 'fetch', label: 'Obtendo conteúdo...' },
  { id: 'extract', label: 'Extraindo letra...' },
  { id: 'analyze', label: 'Analisando estrutura...' },
  { id: 'prepare', label: 'Preparando importação...' },
];

export function renderProgress(host, stageLabel) {
  if (!host) return;
  host.textContent = stageLabel || '';
  host.hidden = !stageLabel;
}

export function mapProgressCallback(onProgress) {
  return (label) => onProgress?.(label);
}
