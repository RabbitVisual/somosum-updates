function esc(t) {
  const d = document.createElement('div');
  d.textContent = t ?? '';
  return d.innerHTML;
}

const PROVIDER_LABELS = {
  local: 'Biblioteca',
  genius: 'Genius',
  'lyrics-ovh': 'Lyrics.ovh',
  letras: 'Letras',
  vagalume: 'Vagalume',
  'web-search': 'Web',
  custom: 'Personalizado',
  structured: 'Estruturado',
};

export function renderSearchResults(container, results, { selectedUrl, onSelect, onPreview, onImport }) {
  if (!container) return;
  if (!results?.length) {
    container.innerHTML = `
      <div class="lyrics-studio-empty">
        <strong>Nenhum resultado</strong>
        <p>Tente título completo, trecho da letra ou “Título - Artista”.</p>
      </div>`;
    return;
  }

  container.innerHTML = results.map((r) => {
    const src = PROVIDER_LABELS[r.providerId] || r.providerId;
    const status = r.status === 'cached'
      ? 'Na biblioteca'
      : (r.hasLyrics ? 'Letra disponível' : 'Só metadados');
    const active = selectedUrl && selectedUrl === r.url ? ' is-selected' : '';
    const score = Number(r.matchScore || r.confidence) || 0;
    // Só mostra % quando a correspondência é confiável (evita badges enganosos).
    const showPct = score >= 0.7;
    const pct = Math.round(score * 100);
    return `
      <article class="lyrics-studio-result${active}" data-url="${esc(r.url)}" tabindex="0">
        <div class="lyrics-studio-result-main">
          <div class="lyrics-studio-result-title-row">
            <strong class="lyrics-studio-result-title">${esc(r.title || 'Sem título')}</strong>
            <span class="lyrics-studio-hit-badge">${esc(src)}</span>
          </div>
          ${r.artist ? `<span class="lyrics-studio-result-artist">${esc(r.artist)}</span>` : ''}
          <div class="lyrics-studio-result-meta">
            ${showPct ? `<span class="lyrics-studio-chip lyrics-studio-chip--score">${pct}%</span>` : ''}
            ${r.language ? `<span class="lyrics-studio-chip">${esc(r.language)}</span>` : ''}
            <span class="lyrics-studio-chip lyrics-studio-chip--muted">${esc(status)}</span>
          </div>
        </div>
        <div class="lyrics-studio-result-actions">
          <button type="button" class="btn btn-secondary btn-sm" data-action="preview">Visualizar</button>
        </div>
      </article>`;
  }).join('');

  container.querySelectorAll('.lyrics-studio-result').forEach((row) => {
    const url = row.dataset.url;
    const result = results.find((r) => r.url === url);
    const activate = () => {
      onSelect?.(result);
      onPreview?.(result);
    };
    row.querySelector('[data-action="preview"]')?.addEventListener('click', (e) => {
      e.stopPropagation();
      activate();
    });
    row.addEventListener('click', (e) => {
      if (e.target.closest('button')) return;
      activate();
    });
    row.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        activate();
      }
    });
  });
}
