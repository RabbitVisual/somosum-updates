/** IndexedDB cache for lyrics search results — TTL 7 days (Holyrics-style reuse). */

const DB_NAME = 'somosum-lyrics-search-cache';
const STORE = 'queries';
const TTL_MS = 7 * 24 * 60 * 60 * 1000;
const CACHE_VERSION = 2;

let _dbPromise = null;

function openDb() {
  if (_dbPromise) return _dbPromise;
  _dbPromise = new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, 1);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(STORE)) {
        db.createObjectStore(STORE, { keyPath: 'key' });
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
  return _dbPromise;
}

function cacheKey(query, providerIds = []) {
  return `v${CACHE_VERSION}|${String(query || '').trim().toLowerCase()}|${providerIds.sort().join(',')}`;
}

export async function getCachedSearch(query, providerIds) {
  try {
    const db = await openDb();
    const key = cacheKey(query, providerIds);
    return new Promise((resolve) => {
      const tx = db.transaction(STORE, 'readonly');
      const req = tx.objectStore(STORE).get(key);
      req.onsuccess = () => {
        const row = req.result;
        if (!row || Date.now() - row.at > TTL_MS) resolve(null);
        else resolve(row.payload);
      };
      req.onerror = () => resolve(null);
    });
  } catch {
    return null;
  }
}

export async function setCachedSearch(query, providerIds, payload) {
  try {
    const db = await openDb();
    const key = cacheKey(query, providerIds);
    const tx = db.transaction(STORE, 'readwrite');
    tx.objectStore(STORE).put({ key, at: Date.now(), payload });
  } catch { /* ignore */ }
}

/** Provider success/latency stats for ranker (localStorage). */
const STATS_KEY = 'SOMOSUM_LYRICS_PROVIDER_STATS';

export function getProviderStats() {
  try {
    return JSON.parse(localStorage.getItem(STATS_KEY) || '{}');
  } catch {
    return {};
  }
}

export function noteProviderLatency(providerId, ms, success) {
  if (!providerId) return;
  const stats = getProviderStats();
  const s = stats[providerId] || { ok: 0, fail: 0, avgMs: 0 };
  if (success) {
    s.ok += 1;
    s.avgMs = s.avgMs ? Math.round(s.avgMs * 0.7 + ms * 0.3) : ms;
  } else {
    s.fail += 1;
  }
  stats[providerId] = s;
  try { localStorage.setItem(STATS_KEY, JSON.stringify(stats)); } catch { /* ignore */ }
}

export function providerScoreBoost(providerId) {
  const s = getProviderStats()[providerId];
  if (!s) return 0;
  const total = s.ok + s.fail;
  if (total < 3) return 0;
  const rate = s.ok / total;
  const speed = s.avgMs < 800 ? 0.05 : (s.avgMs > 3000 ? -0.05 : 0);
  return (rate - 0.5) * 0.12 + speed;
}
