/** Score de correspondência query vs resultado. */

export function normalizeForMatch(s) {
  return String(s || '')
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9\s]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function levenshtein(a, b) {
  const m = a.length;
  const n = b.length;
  if (!m) return n;
  if (!n) return m;
  const dp = Array.from({ length: m + 1 }, (_, i) => [i]);
  for (let j = 1; j <= n; j += 1) dp[0][j] = j;
  for (let i = 1; i <= m; i += 1) {
    for (let j = 1; j <= n; j += 1) {
      const cost = a[i - 1] === b[j - 1] ? 0 : 1;
      dp[i][j] = Math.min(dp[i - 1][j] + 1, dp[i][j - 1] + 1, dp[i - 1][j - 1] + cost);
    }
  }
  return dp[m][n];
}

function commonPrefixLen(a, b) {
  const n = Math.min(a.length, b.length);
  let i = 0;
  while (i < n && a[i] === b[i]) i += 1;
  return i;
}

/** Correspondência tolerante a typos (ruge ≈ rugir). */
export function fuzzyTokenMatch(a, b) {
  const ta = normalizeForMatch(a);
  const tb = normalizeForMatch(b);
  if (!ta || !tb) return false;
  if (ta === tb) return true;
  if (ta.length >= 3 && tb.includes(ta)) return true;
  if (tb.length >= 3 && ta.includes(tb)) return true;
  const prefix = commonPrefixLen(ta, tb);
  if (prefix >= 3 && Math.abs(ta.length - tb.length) <= 2) return true;
  if (ta.length >= 4 && tb.length >= 4) {
    const maxDist = Math.min(2, Math.floor(Math.max(ta.length, tb.length) / 4));
    if (levenshtein(ta, tb) <= maxDist) return true;
  }
  return false;
}

export function tokenOverlap(a, b) {
  const ta = normalizeForMatch(a).split(' ').filter((t) => t.length > 1);
  const tb = normalizeForMatch(b).split(' ').filter((t) => t.length > 1);
  if (!ta.length || !tb.length) return 0;
  const tbSet = new Set(tb);
  let hit = 0;
  for (const t of ta) {
    if (tbSet.has(t)) hit += 1;
    else if (tb.some((ht) => fuzzyTokenMatch(t, ht))) hit += 0.85;
  }
  return hit / Math.max(ta.length, tb.length);
}

function haystackForResult(result) {
  return normalizeForMatch(`${result.title || ''} ${result.artist || ''} ${result.url || ''}`);
}

/** Score para busca por trecho de letra. */
export function snippetMatchScore(snippet, result) {
  const words = normalizeForMatch(snippet).split(' ').filter((w) => w.length > 2);
  if (!words.length) return 0;
  const hay = haystackForResult(result);
  const hayTokens = hay.split(' ').filter(Boolean);
  let hits = 0;
  for (const w of words) {
    if (hay.includes(w)) hits += 1;
    else if (hayTokens.some((ht) => fuzzyTokenMatch(w, ht))) hits += 0.85;
  }
  return hits / words.length;
}

/** Bônus quando altTitle/feats da query aparecem no resultado ou URL. */
export function hintMatchBonus(result, parsed) {
  if (!parsed?.searchHints?.length && !parsed?.altTitles?.length && !parsed?.featSignals?.length) {
    return 0;
  }
  const hay = haystackForResult(result);
  const hayCompact = hay.replace(/\s/g, '');
  let hits = 0;

  for (const alt of parsed.altTitles || []) {
    const h = normalizeForMatch(alt);
    if (h && (hay.includes(h) || hayCompact.includes(h.replace(/\s/g, '')))) hits += 1;
  }
  for (const feat of parsed.featSignals || []) {
    const h = normalizeForMatch(feat);
    if (!h) continue;
    if (hay.includes(h) || hayCompact.includes(h.replace(/\s/g, ''))) hits += 1;
    else if (tokenOverlap(feat, `${result.title} ${result.artist}`) >= 0.5) hits += 1;
  }
  return Math.min(0.32, hits * 0.1);
}

/** Penalidade: query tinha hints mas resultado é só título curto ambíguo. */
export function ambiguousTitlePenalty(result, parsed) {
  const hasHints = (parsed?.searchHints?.length || 0) > 0;
  if (!hasHints) return 0;

  const qTitle = normalizeForMatch(parsed.title);
  const rTitle = normalizeForMatch(result.title);
  const isShortAmbiguous = qTitle.split(' ').filter(Boolean).length <= 1 && qTitle.length <= 8;
  if (!isShortAmbiguous) return 0;

  if (rTitle === qTitle || rTitle.startsWith(`${qTitle} `)) {
    const bonus = hintMatchBonus(result, parsed);
    if (bonus < 0.08) return -0.35;
  }
  return 0;
}

export function computeMatchScore(query, result, { parsed } = {}) {
  const qTitle = parsed?.title || query;
  const fullQuery = parsed?.query || query;

  if (parsed?.mode === 'snippet') {
    const snip = parsed.snippet || fullQuery;
    const snipScore = snippetMatchScore(snip, result);
    const titleScore = tokenOverlap(snip, `${result.title} ${result.artist}`);
    const combined = Math.max(snipScore, titleScore);
    const langBonus = result.language?.startsWith('pt') ? 0.06 : 0.02;
    const providerBonus = /letras\.mus\.br/i.test(result.url || '') ? 0.06 : 0;
    return Math.max(0, Math.min(1, combined * 0.88 + langBonus + providerBonus));
  }

  const titleNorm = normalizeForMatch(qTitle);
  const resultTitle = normalizeForMatch(result.title);
  let titleScore = tokenOverlap(qTitle, result.title);

  if (titleNorm && resultTitle) {
    if (resultTitle === titleNorm) titleScore = Math.max(titleScore, 1);
    else if (resultTitle.includes(titleNorm) || titleNorm.includes(resultTitle)) {
      titleScore = Math.max(titleScore, 0.85);
    }
  }

  if (parsed?.altTitles?.length) {
    for (const alt of parsed.altTitles) {
      const altNorm = normalizeForMatch(alt);
      const hay = haystackForResult(result);
      if (altNorm && hay.includes(altNorm)) {
        titleScore = Math.max(titleScore, 0.94);
      }
    }
  }

  const fullOverlap = tokenOverlap(fullQuery, `${result.title} ${result.artist} ${result.url || ''}`);
  titleScore = Math.max(titleScore, fullOverlap * 0.98);

  let artistScore = 0.45;
  if (parsed?.artist) {
    const a = normalizeForMatch(parsed.artist);
    const ra = normalizeForMatch(result.artist);
    if (a && ra) {
      if (ra === a) artistScore = 1;
      else if (ra.includes(a) || a.includes(ra)) artistScore = 0.8;
      else artistScore = tokenOverlap(parsed.artist, result.artist);
    } else {
      artistScore = 0.2;
    }
  } else if (result.artist) {
    artistScore = 0.35;
  }

  const langBonus = result.language?.startsWith('pt') ? 0.08 : 0.03;
  const providerBonus = result.providerId === 'letras' || result.providerId === 'vagalume' || result.providerId === 'local'
    ? 0.05
    : 0;
  const urlBonus = /letras\.mus\.br/i.test(result.url || '') && (parsed?.searchHints?.length || 0) > 0
    ? 0.05
    : 0;
  const hintsBonus = hintMatchBonus(result, parsed);
  const ambPenalty = ambiguousTitlePenalty(result, parsed);

  const score = titleScore * 0.58 + artistScore * 0.24 + langBonus + providerBonus + urlBonus + hintsBonus + ambPenalty;
  return Math.max(0, Math.min(1, score));
}

export function isAutoDiscoverCandidate(result, parsed, { minScore = 0.75 } = {}) {
  const score = result?.matchScore ?? computeMatchScore(parsed?.query || '', result, { parsed });
  if (score >= minScore) return true;
  if ((parsed?.searchHints?.length || 0) > 0) {
    const hints = hintMatchBonus(result, parsed);
    if (hints >= 0.08 && score >= 0.58) return true;
  }
  if (parsed?.mode === 'snippet') {
    const snip = snippetMatchScore(parsed.snippet || parsed.query, result);
    if (snip >= 0.25 && score >= 0.45) return true;
  }
  return false;
}

export function computeImportConfidence(sections, matchScore) {
  if (!sections?.length) return matchScore * 0.5;
  const typed = sections.filter((s) => s.type && s.type !== 'unknown').length;
  const typeRatio = typed / sections.length;
  return Math.max(0, Math.min(1, matchScore * 0.55 + typeRatio * 0.45));
}
