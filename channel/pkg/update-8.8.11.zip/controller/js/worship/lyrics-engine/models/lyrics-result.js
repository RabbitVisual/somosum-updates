/** Resultado normalizado de busca de letras. */
export function createLyricsResult(partial = {}) {
  return {
    providerId: String(partial.providerId || ''),
    title: String(partial.title || '').trim(),
    artist: String(partial.artist || '').trim(),
    url: String(partial.url || '').trim(),
    confidence: clamp01(partial.confidence),
    matchScore: clamp01(partial.matchScore),
    language: String(partial.language || 'pt-BR').trim(),
    hasLyrics: partial.hasLyrics !== false,
    status: partial.status || 'ready',
    externalId: partial.externalId || null,
    album: partial.album || '',
    year: partial.year || null,
    category: String(partial.category || '').trim(),
    tags: Array.isArray(partial.tags) ? partial.tags.map((t) => String(t).trim()).filter(Boolean) : [],
  };
}

function clamp01(v) {
  const n = Number(v);
  if (!Number.isFinite(n)) return 0;
  return Math.max(0, Math.min(1, n));
}

export function resultKey(r) {
  const t = (r.title || '').toLowerCase().trim();
  const a = (r.artist || '').toLowerCase().trim();
  return `${t}|${a}|${r.providerId || ''}`;
}
