/** Seção tipada de letra normalizada. */
export function createLyricsSection(partial = {}) {
  const lines = Array.isArray(partial.lines)
    ? partial.lines.map((l) => String(l).trim()).filter(Boolean)
    : [];
  return {
    type: String(partial.type || 'unknown'),
    label: String(partial.label || '').trim(),
    lines,
    confidence: clamp01(partial.confidence),
  };
}

function clamp01(v) {
  const n = Number(v);
  if (!Number.isFinite(n)) return 0;
  return Math.max(0, Math.min(1, n));
}

export const SECTION_LABELS = {
  intro: 'Introdução',
  verse: 'Verso',
  chorus: 'Refrão',
  'pre-chorus': 'Pré-refrão',
  bridge: 'Ponte',
  'post-chorus': 'Pós-refrão',
  hook: 'Hook',
  instrumental: 'Instrumental',
  interlude: 'Interlúdio',
  spoken: 'Fala',
  outro: 'Final',
  unknown: 'Seção',
};

export function sectionDisplayLabel(section, index = 0) {
  if (section.label) return section.label;
  const base = SECTION_LABELS[section.type] || SECTION_LABELS.unknown;
  if (section.type === 'verse') return `${base} ${index + 1}`;
  return base;
}
