import { createLyricsSection } from './lyrics-section.js';
import { sectionsToSongLyricsAndBlocks } from '../lyrics-projection-text.js';

/** DTO interno do pipeline antes de mapear para worship-schema. */
export function createNormalizedSong(partial = {}) {
  const sections = Array.isArray(partial.sections)
    ? partial.sections.map((s) => createLyricsSection(s))
    : [];
  return {
    title: String(partial.title || 'Sem título').trim(),
    artist: String(partial.artist || '').trim(),
    composer: String(partial.composer || '').trim(),
    language: String(partial.language || 'Português').trim(),
    plainLyrics: String(partial.plainLyrics || partial.lyrics || '').replace(/\r\n/g, '\n'),
    sections,
    chordSource: partial.chordSource ? String(partial.chordSource).replace(/\r\n/g, '\n') : null,
    key: String(partial.key || '').trim(),
    bpm: partial.bpm != null && Number.isFinite(Number(partial.bpm)) ? Number(partial.bpm) : null,
    capo: partial.capo != null && Number.isFinite(Number(partial.capo))
      ? Math.max(0, Math.min(11, Number(partial.capo)))
      : 0,
    source: partial.source && typeof partial.source === 'object'
      ? {
        provider: String(partial.source.provider || ''),
        url: String(partial.source.url || ''),
        retrievedAt: partial.source.retrievedAt || Date.now(),
      }
      : null,
    importMeta: partial.importMeta && typeof partial.importMeta === 'object'
      ? {
        method: String(partial.importMeta.method || 'lyrics-engine'),
        normalized: !!partial.importMeta.normalized,
        confidence: Number(partial.importMeta.confidence) || 0,
      }
      : null,
    album: partial.album || '',
    year: partial.year || null,
    category: String(partial.category || '').trim(),
    tags: Array.isArray(partial.tags) ? partial.tags.map((t) => String(t).trim()).filter(Boolean) : [],
  };
}

/** @deprecated Prefer sectionsToSongLyricsAndBlocks — projeção limpa sem marcadores. */
export function sectionsToLyricsAndBlocks(sections) {
  return sectionsToSongLyricsAndBlocks(sections);
}
