/**
 * Texto de projeção — letra limpa para o público (sem marcadores de seção).
 * Metadados estruturais ficam em sections[] / blocks[].
 * A letra editada (lyrics) é a fonte da verdade; sections acompanham a letra.
 */

/** Linha que é só marcador de seção (Verso, Refrão, etc.). */
export const SECTION_MARKER_RE = /^\s*\[?\s*(verso|refr[aã]o|ponte|intro|introdu[cç][aã]o|final|instrumental|pr[eé][\s-]?refr[aã]o|tag|coro|hook|p[oó]s[\s-]?refr[aã]o|interl[uú]dio|fala|outro|se[cç][aã]o)\s*\d*\]?\s*:?\s*$/i;

export function isSectionMarkerLine(line) {
  return SECTION_MARKER_RE.test(String(line || '').trim());
}

/** Remove linhas de marcador; colapsa linhas em branco extras. */
export function stripSectionMarkerLines(text) {
  if (!text) return '';
  const lines = String(text).replace(/\r\n/g, '\n').split('\n');
  const out = [];
  for (const line of lines) {
    if (isSectionMarkerLine(line)) continue;
    out.push(line);
  }
  return out.join('\n').replace(/\n{3,}/g, '\n\n').trim();
}

function stripAccents(s) {
  return String(s || '')
    .normalize('NFD')
    .replace(/\p{M}/gu, '')
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

/** Fingerprint de conteúdo de estrofe (ignora caixa). */
export function stanzaFingerprint(lines) {
  return stripAccents((lines || []).join(' '));
}

/** Junta seções em letra limpa para projeção (sem labels). Preserva linhas em branco internas. */
export function sectionsToProjectionLyrics(sections) {
  if (!sections?.length) return '';
  const parts = [];
  for (const sec of sections) {
    const lines = (sec.lines || []).map((l) => String(l));
    while (lines.length && !String(lines[0]).trim()) lines.shift();
    while (lines.length && !String(lines[lines.length - 1]).trim()) lines.pop();
    if (lines.length) parts.push(lines.join('\n'));
  }
  return parts.join('\n\n').trim();
}

/** Metadados de bloco alinhados ao texto de projeção limpo. */
export function sectionsToBlocks(sections) {
  if (!sections?.length) return [];
  const blocks = [];
  let lineIndex = 0;

  for (let i = 0; i < sections.length; i++) {
    const sec = sections[i];
    const lines = (sec.lines || []).map((l) => String(l));
    while (lines.length && !String(lines[0]).trim()) lines.shift();
    while (lines.length && !String(lines[lines.length - 1]).trim()) lines.pop();
    if (!lines.length) continue;
    if (i > 0) lineIndex += 1;
    const startLine = lineIndex;
    lineIndex += lines.length;
    blocks.push({
      type: sec.type || 'unknown',
      label: sec.label || '',
      startLine,
      endLine: lineIndex - 1,
    });
  }
  return blocks;
}

/** Gera lyrics + blocks a partir de sections (projeção limpa). */
export function sectionsToSongLyricsAndBlocks(sections) {
  return {
    lyrics: sectionsToProjectionLyrics(sections),
    blocks: sectionsToBlocks(sections),
  };
}

/** Detecta se o texto contém marcadores de seção visíveis na projeção. */
export function lyricsHasSectionMarkers(text) {
  if (!text) return false;
  return String(text).split('\n').some((l) => isSectionMarkerLine(l));
}

/** Divide letra em estrofes por linha em branco (preserva caixa e conteúdo). */
export function splitLyricsIntoStanzaLines(lyrics) {
  const text = String(lyrics || '').replace(/\r\n/g, '\n').trim();
  if (!text) return [];
  return text
    .split(/\n\s*\n/)
    .map((block) => block
      .split('\n')
      .map((l) => l.replace(/\s+$/g, ''))
      .filter((l) => l.trim().length))
    .filter((lines) => lines.length > 0);
}

/**
 * Reconstrói sections/blocks a partir da letra atual,
 * preservando tipos (verso/refrão) das seções anteriores por similaridade de conteúdo.
 */
export function syncStructureFromLyrics(lyrics, previousSections = []) {
  const stanzas = splitLyricsIntoStanzaLines(lyrics);
  const prev = Array.isArray(previousSections) ? previousSections : [];
  const used = new Set();

  const sections = stanzas.map((lines, idx) => {
    const fp = stanzaFingerprint(lines);
    let best = null;
    let bestScore = 0;
    for (let i = 0; i < prev.length; i += 1) {
      if (used.has(i)) continue;
      const pfp = stanzaFingerprint(prev[i].lines || []);
      if (!fp || !pfp) continue;
      let score = 0;
      if (fp === pfp) score = 1;
      else if (fp.includes(pfp) || pfp.includes(fp)) score = 0.85;
      else {
        const a = new Set(fp.split(' ').filter(Boolean));
        const b = new Set(pfp.split(' ').filter(Boolean));
        if (!a.size || !b.size) continue;
        let inter = 0;
        for (const w of a) if (b.has(w)) inter += 1;
        score = inter / Math.max(a.size, b.size);
      }
      if (score > bestScore) {
        bestScore = score;
        best = { i, sec: prev[i] };
      }
    }
    if (best && bestScore >= 0.45) {
      used.add(best.i);
      return {
        type: best.sec.type || 'verse',
        label: best.sec.label || '',
        lines: [...lines],
        confidence: best.sec.confidence ?? bestScore,
      };
    }
    const earlierSame = stanzaAppearsEarlier(stanzas, idx, fp);
    return {
      type: earlierSame ? 'chorus' : 'verse',
      label: earlierSame ? 'Refrão' : '',
      lines: [...lines],
      confidence: earlierSame ? 0.7 : 0.4,
    };
  });

  const seen = new Map();
  for (const sec of sections) {
    const fp = stanzaFingerprint(sec.lines);
    if (!fp) continue;
    if (seen.has(fp)) {
      sec.type = 'chorus';
      if (!sec.label) sec.label = 'Refrão';
      sec.confidence = Math.max(sec.confidence || 0, 0.75);
    } else {
      seen.set(fp, true);
    }
  }

  return {
    sections,
    blocks: sectionsToBlocks(sections),
  };
}

function stanzaAppearsEarlier(stanzas, idx, fp) {
  for (let i = 0; i < idx; i += 1) {
    if (stanzaFingerprint(stanzas[i]) === fp) return true;
  }
  return false;
}

/**
 * Sanitiza song.lyrics para projeção limpa.
 * NÃO sobrescreve a letra editada com sections antigas (preserva maiúsculas / estrofes).
 * Sincroniza sections/blocks a partir da letra.
 */
export function sanitizeSongForProjection(song) {
  const previousSections = Array.isArray(song?.sections) ? song.sections : [];
  let lyrics = String(song?.lyrics || '').replace(/\r\n/g, '\n');
  let sanitized = false;

  if (lyricsHasSectionMarkers(lyrics)) {
    lyrics = stripSectionMarkerLines(lyrics);
    sanitized = true;
  }

  const { sections, blocks } = syncStructureFromLyrics(lyrics, previousSections);
  const prevKey = JSON.stringify(previousSections.map((s) => ({ type: s.type, lines: s.lines })));
  const nextKey = JSON.stringify(sections.map((s) => ({ type: s.type, lines: s.lines })));
  if (prevKey !== nextKey) sanitized = true;

  return { lyrics, blocks, sections, sanitized };
}
