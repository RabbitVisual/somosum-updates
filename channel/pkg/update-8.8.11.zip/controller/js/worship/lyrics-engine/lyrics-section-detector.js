import { createLyricsSection, sectionDisplayLabel } from './models/lyrics-section.js';
import { detectBlocks } from '../worship-parser.js';
import { dedupePageBlocks } from './lyrics-deduplicator.js';

const LABEL_RE = /^\s*\[?\s*(verso|refr[aã]o|ponte|intro|introdu[cç][aã]o|final|instrumental|pr[eé][\s-]?refr[aã]o|tag|coro|hook|p[oó]s[\s-]?refr[aã]o|interl[uú]dio|fala|outro)\s*(\d*)\]?\s*:?\s*$/i;

const TYPE_MAP = {
  verso: 'verse',
  refrão: 'chorus',
  refrao: 'chorus',
  coro: 'chorus',
  ponte: 'bridge',
  intro: 'intro',
  introdução: 'intro',
  introducao: 'intro',
  final: 'outro',
  outro: 'outro',
  instrumental: 'instrumental',
  'pré-refrão': 'pre-chorus',
  'pre-refrão': 'pre-chorus',
  'pre-refrao': 'pre-chorus',
  'pós-refrão': 'post-chorus',
  'pos-refrão': 'post-chorus',
  hook: 'hook',
  interlúdio: 'interlude',
  interludio: 'interlude',
  fala: 'spoken',
  tag: 'tag',
};

function resolveType(label) {
  const key = String(label || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
  for (const [k, v] of Object.entries(TYPE_MAP)) {
    if (key.includes(k.normalize('NFD').replace(/[\u0300-\u036f]/g, ''))) return v;
  }
  return 'unknown';
}

function normalizeParaKey(text) {
  return String(text || '')
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^\w\s]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function paragraphSimilarity(a, b) {
  const ka = normalizeParaKey(a);
  const kb = normalizeParaKey(b);
  if (!ka || !kb) return 0;
  if (ka === kb) return 1;
  const wa = new Set(ka.split(' '));
  const wb = new Set(kb.split(' '));
  let inter = 0;
  for (const w of wa) if (wb.has(w)) inter += 1;
  return inter / Math.max(wa.size, wb.size, 1);
}

/** Refrão = parágrafos repetidos (≥85% similaridade). */
function detectChorusIndices(paragraphs) {
  const chorus = new Set();
  for (let i = 0; i < paragraphs.length; i++) {
    for (let j = i + 1; j < paragraphs.length; j++) {
      if (paragraphSimilarity(paragraphs[i], paragraphs[j]) >= 0.85) {
        chorus.add(i);
        chorus.add(j);
      }
    }
  }
  return chorus;
}

function extractVerseLabel(rawLabel, verseNumFromSource) {
  if (verseNumFromSource) return `Verso ${verseNumFromSource}`;
  return '';
}

/** Detecta seções com confidence a partir de texto plano. */
export function detectSections(plainText) {
  const text = String(plainText || '').trim();
  if (!text) return [];

  const lines = text.split('\n');
  const sections = [];
  let current = null;
  let verseCount = 0;
  let hasExplicitLabels = false;

  const flush = () => {
    if (!current) return;
    const linesFiltered = current.lines.filter((l) => String(l).trim());
    if (linesFiltered.length) {
      sections.push(createLyricsSection({
        type: current.type,
        label: current.label,
        lines: linesFiltered,
        confidence: current.confidence,
      }));
    }
    current = null;
  };

  for (const line of lines) {
    const m = line.match(LABEL_RE);
    if (m) {
      hasExplicitLabels = true;
      flush();
      const type = resolveType(m[1]);
      const numFromSource = m[2] ? parseInt(m[2], 10) : null;
      let label = '';
      if (type === 'verse') {
        if (numFromSource && Number.isFinite(numFromSource)) {
          label = `Verso ${numFromSource}`;
          verseCount = Math.max(verseCount, numFromSource);
        } else {
          verseCount += 1;
          label = `Verso ${verseCount}`;
        }
      } else {
        label = sectionDisplayLabel({ type, label: '' });
      }
      current = { type, label, lines: [], confidence: 0.95 };
      continue;
    }
    if (!current) {
      current = { type: 'unknown', label: '', lines: [], confidence: 0.4 };
    }
    current.lines.push(line);
  }
  flush();

  if (hasExplicitLabels && sections.length) {
    return dedupePageBlocks(sections);
  }

  if (sections.length <= 1 && sections.every((s) => s.type === 'unknown')) {
    const paras = text.split(/\n\s*\n/).filter((p) => p.trim());
    if (paras.length > 1) {
      const chorusIdx = detectChorusIndices(paras);
      let verseNum = 0;
      return paras.map((p, i) => {
        const isChorus = chorusIdx.has(i);
        let type = 'verse';
        let label = '';
        let confidence = 0.45;
        if (isChorus) {
          type = 'chorus';
          label = 'Refrão';
          confidence = 0.7;
        } else {
          verseNum += 1;
          type = 'verse';
          label = `Verso ${verseNum}`;
          confidence = 0.5;
        }
        return createLyricsSection({
          type,
          label,
          lines: p.split('\n').map((l) => l.trim()).filter(Boolean),
          confidence,
        });
      });
    }
    return [createLyricsSection({
      type: 'unknown',
      label: '',
      lines: text.split('\n').map((l) => l.trim()).filter(Boolean),
      confidence: 0.3,
    })];
  }

  return dedupePageBlocks(sections);
}

/** Fallback via worship-parser detectBlocks. */
export function detectSectionsFromBlocks(lyrics) {
  const { lyrics: cleaned, blocks } = detectBlocks(lyrics);
  if (!blocks.length) return detectSections(cleaned);
  const lines = cleaned.split('\n');
  return blocks.map((b, i) => {
    const slice = lines.slice(b.startLine, b.endLine + 1).filter((l) => l.trim());
    return createLyricsSection({
      type: b.type || 'unknown',
      label: sectionDisplayLabel({ type: b.type }, i),
      lines: slice,
      confidence: 0.85,
    });
  });
}

/** Confiança média das seções (para banner de revisão). */
export function averageSectionConfidence(sections) {
  if (!sections?.length) return 0;
  const sum = sections.reduce((n, s) => n + (Number(s.confidence) || 0), 0);
  return sum / sections.length;
}
