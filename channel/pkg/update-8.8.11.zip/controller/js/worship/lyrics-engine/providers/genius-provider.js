import { LyricsProvider } from './base-provider.js';
import { createLyricsResult } from '../models/lyrics-result.js';
import { geniusSearch, fetchViaProxy, geniusStatus, removeGeniusToken } from '../lyrics-fetcher.js';
import { extractLyricsFromHtml } from '../lyrics-extractor.js';
import { logLyrics } from '../lyrics-logger.js';
import { LogLevel } from '../../../core/logging/log-service.js';

let _geniusAuthWarned = false;

export function resetGeniusProviderCache() {
  _geniusAuthWarned = false;
}

export class GeniusProvider extends LyricsProvider {
  constructor() {
    super('genius', { priority: 4, requiresNetwork: true });
    this._configured = null;
  }

  async isConfigured() {
    if (this._configured === null) {
      const st = await geniusStatus();
      this._configured = !!st?.configured;
    }
    return this._configured;
  }

  async _handleAuthFailure() {
    this._configured = false;
    await removeGeniusToken().catch(() => {});
    if (!_geniusAuthWarned) {
      _geniusAuthWarned = true;
      logLyrics('LYRICS_PROVIDER', {
        providerId: this.id,
        error: 'genius_auth_invalid',
        action: 'token_cleared',
      }, LogLevel.INFO);
    }
  }

  async search(query, parsed, { signal } = {}) {
    if (!(await this.isConfigured())) return [];
    const q = parsed?.title && parsed?.artist
      ? `${parsed.title} ${parsed.artist}`
      : (parsed?.title || query);
    try {
      const data = await geniusSearch(q, { signal });
      if (!data?.response?.hits) return [];

      return data.response.hits.slice(0, 10).map((hit) => {
        const song = hit.result || hit;
        const primary = song.primary_artist?.name || '';
        return createLyricsResult({
          providerId: this.id,
          title: song.title || '',
          artist: primary,
          url: song.url || '',
          language: 'en',
          hasLyrics: true,
          confidence: 0.7,
          externalId: String(song.id || ''),
        });
      });
    } catch (err) {
      if (err?.message === 'genius_auth_invalid') {
        await this._handleAuthFailure();
        return [];
      }
      throw err;
    }
  }

  async getLyrics(result, { signal } = {}) {
    if (!result.url) return { plainText: '', chordSource: null };
    const res = await fetchViaProxy(result.url, { signal });
    const extracted = await extractLyricsFromHtml(res.body || '', result.url);
    return { plainText: extracted.plainText, chordSource: extracted.chordSource, html: res.body };
  }
}
