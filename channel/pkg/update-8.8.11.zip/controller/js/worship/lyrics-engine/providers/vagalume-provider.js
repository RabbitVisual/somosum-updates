import { LyricsProvider } from './base-provider.js';
import { createLyricsResult } from '../models/lyrics-result.js';
import { fetchViaProxy } from '../lyrics-fetcher.js';
import { extractLyricsFromHtml } from '../lyrics-extractor.js';
import { buildSearchTerms } from '../lyrics-search-engine.js';
import { isValidMusicResult } from '../lyrics-result-filter.js';

const NOISE = new Set(['blog', 'busca', 'search', 'login', 'conta', 'menu', 'home']);

function parseVagalumeResults(html) {
  const results = [];
  if (typeof document === 'undefined') return results;
  const doc = new DOMParser().parseFromString(html, 'text/html');
  const links = doc.querySelectorAll('a[href*="/"]');
  const seen = new Set();
  for (const a of links) {
    const href = a.getAttribute('href') || '';
    if (!/\/[^/]+\/[^/]+\.html$/i.test(href)) continue;
    const url = href.startsWith('http') ? href : `https://www.vagalume.com.br${href.startsWith('/') ? '' : '/'}${href}`;
    if (seen.has(url)) continue;
    seen.add(url);
    const text = (a.textContent || '').replace(/\s+/g, ' ').trim();
    if (text.length < 2) continue;
    const parts = text.split(/\s[-–—]\s/);
    const title = parts[0]?.trim() || text;
    const artist = parts[1]?.trim() || '';
    if (NOISE.has(title.toLowerCase())) continue;
    results.push(createLyricsResult({
      providerId: 'vagalume',
      title,
      artist,
      url,
      language: 'pt-BR',
      hasLyrics: true,
      confidence: 0.55,
    }));
    if (results.length >= 8) break;
  }
  return results;
}

export class VagalumeProvider extends LyricsProvider {
  constructor() {
    super('vagalume', { priority: 3, requiresNetwork: true });
  }

  async search(query, parsed, { signal } = {}) {
    if (parsed?.mode === 'snippet') {
      return [];
    }
    const terms = buildSearchTerms(parsed?.mode ? parsed : { mode: 'title', title: query, artist: '', altTitles: [], featSignals: [], searchHints: [] });
    const q = terms[0] || parsed?.title || query;
    const apiHits = await this._searchApi(q, { signal });
    const filtered = apiHits.filter(isValidMusicResult);
    if (filtered.length) return filtered.slice(0, 8);

    const url = `https://www.vagalume.com.br/busca?q=${encodeURIComponent(q)}`;
    try {
      const res = await fetchViaProxy(url, { signal });
      return parseVagalumeResults(res.body || '').filter(isValidMusicResult).slice(0, 8);
    } catch {
      return [];
    }
  }

  async _searchApi(query, { signal }) {
    const urls = [
      `https://api.vagalume.com.br/search.ex?q=${encodeURIComponent(query)}&limit=10`,
    ];
    for (const url of urls) {
      try {
        const res = await fetchViaProxy(url, { signal });
        const body = res.body || '';
        const json = tryParseJson(body);
        if (json?.response?.docs?.length) {
          return json.response.docs.slice(0, 10).map((doc) => createLyricsResult({
            providerId: 'vagalume',
            title: doc.name || doc.title || query,
            artist: doc.art || doc.artist || '',
            url: doc.url || `https://www.vagalume.com.br${doc.url || ''}`,
            language: 'pt-BR',
            hasLyrics: true,
            confidence: 0.65,
          }));
        }
      } catch { /* next */ }
    }
    return [];
  }

  async getLyrics(result, { signal } = {}) {
    const res = await fetchViaProxy(result.url, { signal });
    return extractLyricsFromHtml(res.body || '', result.url);
  }
}

function tryParseJson(text) {
  try { return JSON.parse(text); } catch { return null; }
}
