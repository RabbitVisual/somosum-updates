/** Interface base de provider de letras. */
export class LyricsProvider {
  constructor(id, { priority = 50, requiresNetwork = true } = {}) {
    this.id = id;
    this.priority = priority;
    this.requiresNetwork = requiresNetwork;
  }

  async search(/* query, parsed, opts */) {
    return [];
  }

  async getSongMetadata(/* result, opts */) {
    return {};
  }

  async getLyrics(/* result, opts */) {
    return { plainText: '', html: null, chordSource: null };
  }
}
