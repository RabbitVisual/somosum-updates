import { LyricsProvider } from './base-provider.js';
import { createLyricsResult } from '../models/lyrics-result.js';
import { fetchViaProxy } from '../lyrics-fetcher.js';
import { extractLyricsFromHtml } from '../lyrics-extractor.js';

export class StructuredProvider extends LyricsProvider {
  constructor() {
    super('structured', { priority: 6, requiresNetwork: true });
  }

  async search() {
    return [];
  }

  async getLyrics(result, { signal } = {}) {
    if (!result.url) return { plainText: '', chordSource: null };
    const res = await fetchViaProxy(result.url, { signal });
    const html = res.body || '';
    let title = result.title;
    let artist = result.artist;

    if (typeof document !== 'undefined') {
      const doc = new DOMParser().parseFromString(html, 'text/html');
      for (const script of doc.querySelectorAll('script[type="application/ld+json"]')) {
        try {
          const data = JSON.parse(script.textContent || '');
          const items = Array.isArray(data) ? data : [data];
          for (const item of items) {
            if (item['@type'] === 'MusicComposition' || item['@type'] === 'MusicRecording') {
              title = item.name || title;
              artist = item.byArtist?.name || item.author?.name || artist;
            }
          }
        } catch { /* ignore */ }
      }
    }

    const extracted = await extractLyricsFromHtml(html, result.url);
    return { ...extracted, title, artist };
  }
}
