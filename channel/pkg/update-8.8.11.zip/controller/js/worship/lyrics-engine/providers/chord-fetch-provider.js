import { fetchViaProxy } from '../lyrics-fetcher.js';
import {
  cifraHtmlToChordPro,
  buildCifraClubSearchUrl,
  extractCifraClubLinks,
  searchCifraClubSolr,
  searchCifraClubSolrByQuery,
  normalizeCifraSearchQuery,
  isAcceptableCifraHit,
} from '../../cifra-html-to-chordpro.js';
import {
  buildHinarioCifraSearchQueries,
  resolveHinarioCifraArtist,
  resolveHinarioCifraNumber,
} from '../../hinario-chord-search.js';
import { logLyrics } from '../lyrics-logger.js';
import { LogLevel } from '../../../core/logging/log-service.js';

const FAIL_THRESHOLD = 5;
const COOLDOWN_MS = 90 * 1000;

class ChordBreaker {
  constructor() {
    this._failures = 0;
    this._disabledUntil = 0;
  }
  isOpen() { return Date.now() < this._disabledUntil; }
  remainingMs() { return Math.max(0, this._disabledUntil - Date.now()); }
  ok() { this._failures = 0; }
  /** Só erros de rede/proxy — miss limpo não bloqueia as próximas buscas. */
  failHard() {
    this._failures += 1;
    if (this._failures >= FAIL_THRESHOLD) this._disabledUntil = Date.now() + COOLDOWN_MS;
  }
}

const _breaker = new ChordBreaker();

function cifraSearchContext(songInfo = {}) {
  const title = String(songInfo?.title || '').trim();
  const hymnalArtist = resolveHinarioCifraArtist(songInfo);
  const artist = hymnalArtist || String(songInfo?.artist || songInfo?.composer || '').trim();
  const hymnNumber = resolveHinarioCifraNumber(songInfo);
  return { title, artist, hymnNumber, hymnal: !!hymnalArtist };
}

function miss(reason, extra = {}) {
  return { ok: false, reason, chordSource: null, ...extra };
}

function htmlLinkLooksLike(url, title, artist, hymnNumber) {
  try {
    const u = new URL(url);
    const parts = u.pathname.replace(/\/+$/, '').split('/').filter(Boolean);
    if (parts.length < 2) return false;
    const songSlug = (parts[parts.length - 1] || '').replace(/-/g, ' ');
    const artistSlug = (parts[parts.length - 2] || '').replace(/-/g, ' ');
    return isAcceptableCifraHit(
      { url, title: songSlug, artist: artistSlug },
      title,
      { hymnNumber, minOverlap: 0.28 },
    );
  } catch {
    return false;
  }
}

/**
 * Lista candidatos no Solr do Cifra Club (sem baixar a página).
 * Aceita songInfo para queries de hinário (mesmo path que fetchChordsForSong).
 * @returns {Promise<Array<{ url: string, title: string, artist: string, score: number }>>}
 */
export async function searchCifraClubCandidates(title, artist, { signal, songInfo } = {}) {
  const fetchFn = (url) => fetchViaProxy(url, { signal });
  const ctx = songInfo
    ? cifraSearchContext(songInfo)
    : { title, artist, hymnNumber: null };
  const t = ctx.title || title;
  const a = ctx.artist || artist;
  const hinarioQueries = songInfo ? buildHinarioCifraSearchQueries(songInfo) : [];
  const baseQuery = normalizeCifraSearchQuery(t, a).query;
  const queries = [...new Set([...hinarioQueries, baseQuery].filter(Boolean))];
  const acceptOpts = { hymnNumber: ctx.hymnNumber, minOverlap: 0.22 };

  const byUrl = new Map();
  const addHit = (h, scoreBoost = 0) => {
    if (!h?.url || !isAcceptableCifraHit(h, t, acceptOpts)) return;
    const score = (h.score || 0) + scoreBoost;
    const prev = byUrl.get(h.url);
    if (!prev || score > prev.score) {
      byUrl.set(h.url, {
        url: h.url,
        title: h.title || h.doc?.m || '',
        artist: h.artist || h.doc?.a || '',
        score,
      });
    }
  };

  try {
    for (const q of queries.slice(0, 4)) {
      const hits = await searchCifraClubSolrByQuery(q, t, a, fetchFn, { hymnNumber: ctx.hymnNumber });
      for (const h of hits) addHit(h);
      if (byUrl.size >= 8) break;
    }
    // Fallback Solr clássico se queries especiais falharam
    if (!byUrl.size) {
      const hits = await searchCifraClubSolr(t, a, fetchFn, { hymnNumber: ctx.hymnNumber });
      for (const h of hits) addHit(h);
    }
    // Fallback HTML (paridade com resolveCifraClubUrl / Buscar cifra)
    if (!byUrl.size && t) {
      for (const q of queries.slice(0, 3)) {
        try {
          const searchUrl = `https://www.cifraclub.com.br/busca/?q=${encodeURIComponent(q)}`;
          const searchRes = await fetchFn(searchUrl);
          const links = extractCifraClubLinks(searchRes.body || '');
          for (const url of links) {
            if (/\/undefined\/?$/i.test(url)) continue;
            if (!htmlLinkLooksLike(url, t, a, ctx.hymnNumber)) continue;
            try {
              const u = new URL(url);
              const parts = u.pathname.replace(/\/+$/, '').split('/').filter(Boolean);
              const songSlug = (parts[parts.length - 1] || '').replace(/-/g, ' ');
              const artistSlug = (parts[parts.length - 2] || '').replace(/-/g, ' ');
              addHit({ url, title: songSlug, artist: artistSlug, score: 40 }, 0);
            } catch { /* ignore */ }
            if (byUrl.size >= 8) break;
          }
          if (byUrl.size) {
            logLyrics('LYRICS_CHORD_SEARCH', { title: t, via: 'html-candidates', query: q, n: byUrl.size }, LogLevel.DEBUG);
            break;
          }
        } catch (err) {
          logLyrics('LYRICS_CHORD_SEARCH', { title: t, via: 'html-candidates', error: err?.message || String(err) }, LogLevel.DEBUG);
        }
      }
    }
  } catch (err) {
    logLyrics('LYRICS_CHORD_SEARCH', { title: t, error: err?.message || String(err) }, LogLevel.DEBUG);
    return [];
  }
  return [...byUrl.values()].sort((x, y) => y.score - x.score).slice(0, 8);
}

/** Baixa e converte uma URL específica do Cifra Club. */
export async function fetchCifraFromUrl(url, { title = '', artist = '', signal } = {}) {
  if (!url) return null;
  const res = await fetchViaProxy(url, { signal });
  let parsed = cifraHtmlToChordPro(res.body || '', { title, artist });

  const printUrl = url.replace(/\/?$/, '/imprimir.html');
  if (printUrl !== url) {
    try {
      const printRes = await fetchViaProxy(printUrl, { signal });
      const printParsed = cifraHtmlToChordPro(printRes.body || '', { title, artist });
      if (printParsed.chordShapes?.length) {
        parsed = {
          ...parsed,
          chordShapes: printParsed.chordShapes,
          chordSource: parsed.chordSource || printParsed.chordSource,
        };
      }
    } catch { /* print page optional */ }
  }

  if (!parsed.chordSource?.trim()) return null;
  return {
    ok: true,
    chordSource: parsed.chordSource,
    key: parsed.key || '',
    capo: parsed.capo ?? 0,
    bpm: parsed.bpm ?? null,
    chordShapes: parsed.chordShapes || [],
    tuning: parsed.tuning || 'E A D G B E',
    sourceUrl: url,
  };
}

async function resolveCifraClubUrl(songInfo, { signal } = {}) {
  const ctx = cifraSearchContext(songInfo);
  const { title, artist, hymnNumber } = ctx;
  const direct = String(songInfo?.url || '').trim();
  if (direct && /cifraclub/i.test(direct)) return direct;

  const fetchFn = (url) => fetchViaProxy(url, { signal });
  const hinarioQueries = buildHinarioCifraSearchQueries(songInfo);
  const baseQuery = normalizeCifraSearchQuery(title, artist).query;
  const queries = [...new Set([...hinarioQueries, baseQuery].filter(Boolean))];
  const scoreOpts = { hymnNumber };
  const acceptOpts = { hymnNumber };

  let bestHit = null;
  for (const q of queries) {
    try {
      const solrHits = await searchCifraClubSolrByQuery(q, title, artist, fetchFn, scoreOpts);
      const hit = solrHits.find((h) => isAcceptableCifraHit(h, title, acceptOpts));
      if (!hit?.url) continue;
      if (!bestHit || hit.score > bestHit.score) bestHit = hit;
      if (hit.score >= 160) break;
    } catch (err) {
      logLyrics('LYRICS_CHORD_SEARCH', {
        title,
        via: 'solr',
        query: q,
        error: err?.message || String(err),
      }, LogLevel.DEBUG);
    }
  }

  if (bestHit?.url) {
    logLyrics('LYRICS_CHORD_SEARCH', {
      title,
      artist,
      via: 'solr',
      match: bestHit.title,
      score: bestHit.score,
    }, LogLevel.DEBUG);
    return bestHit.url;
  }

  // Fallback HTML — escolhe link ranqueado, não o primeiro cego
  for (const q of queries.slice(0, 3)) {
    try {
      const searchUrl = `https://www.cifraclub.com.br/busca/?q=${encodeURIComponent(q)}`;
      const searchRes = await fetchFn(searchUrl);
      const links = extractCifraClubLinks(searchRes.body || '');
      const ranked = links
        .filter((u) => !/\/undefined\/?$/i.test(u))
        .filter((u) => htmlLinkLooksLike(u, title, artist, hymnNumber));
      const url = ranked[0] || links.find((u) => !/\/undefined\/?$/i.test(u));
      if (url) {
        logLyrics('LYRICS_CHORD_SEARCH', { title, via: 'html', url, query: q }, LogLevel.DEBUG);
        return url;
      }
    } catch { /* try next */ }
  }

  const searchUrl = buildCifraClubSearchUrl(title, artist);
  if (!title) return null;
  try {
    const searchRes = await fetchFn(searchUrl);
    const links = extractCifraClubLinks(searchRes.body || '');
    const ranked = links.filter((u) => htmlLinkLooksLike(u, title, artist, hymnNumber));
    const pick = ranked[0] || links[0] || null;
    if (pick) {
      logLyrics('LYRICS_CHORD_SEARCH', { title, via: 'html', url: pick }, LogLevel.DEBUG);
    }
    return pick;
  } catch {
    return null;
  }
}

/**
 * Busca cifra ChordPro para músicos (Stage) — não bloqueia import de letra.
 * @returns {Promise<{ ok: boolean, reason?: string, chordSource?: string|null, ... }>}
 */
export async function fetchChordsForSong(songInfo, { signal } = {}) {
  if (_breaker.isOpen()) {
    return miss('cooldown', { cooldownMs: _breaker.remainingMs() });
  }
  const title = String(songInfo?.title || '').trim();
  if (!title) return miss('not_found');
  const { artist } = cifraSearchContext(songInfo);

  try {
    const chordUrl = await resolveCifraClubUrl(songInfo, { signal });
    if (!chordUrl) {
      return miss('not_found');
    }

    const res = await fetchViaProxy(chordUrl, { signal });
    let parsed = cifraHtmlToChordPro(res.body || '', { title, artist });

    try {
      const printUrl = chordUrl.replace(/\/?$/, '/imprimir.html');
      const printRes = await fetchViaProxy(printUrl, { signal });
      const printParsed = cifraHtmlToChordPro(printRes.body || '', { title, artist });
      if (printParsed.chordShapes?.length) {
        parsed = {
          ...parsed,
          chordShapes: printParsed.chordShapes,
        };
      }
      if (!parsed.chordSource?.trim() && printParsed.chordSource?.trim()) {
        parsed = { ...parsed, chordSource: printParsed.chordSource };
      }
    } catch { /* optional */ }

    if (!parsed.chordSource?.trim()) {
      return miss('not_found', { sourceUrl: chordUrl });
    }
    _breaker.ok();
    logLyrics('LYRICS_CHORD_FETCH', { title, hasChords: true, key: parsed.key, url: chordUrl }, LogLevel.DEBUG);
    return {
      ok: true,
      reason: 'ok',
      chordSource: parsed.chordSource,
      key: parsed.key || '',
      capo: parsed.capo ?? 0,
      bpm: parsed.bpm ?? null,
      chordShapes: parsed.chordShapes || [],
      tuning: parsed.tuning || 'E A D G B E',
      sourceUrl: chordUrl,
      sourceTitle: title,
      sourceArtist: artist,
    };
  } catch (err) {
    const code = err?.code || err?.message || '';
    if (/local_or_lan_only|proxy_403|403/.test(code)) {
      return miss('proxy_forbidden', { error: code });
    }
    _breaker.failHard();
    logLyrics('LYRICS_CHORD_FETCH', { title, error: err?.message || String(err) }, LogLevel.WARN);
    return miss('proxy', { error: err?.message || String(err) });
  }
}

export function chordFetchToastMessage(result) {
  if (result?.ok && result.chordSource) return null;
  switch (result?.reason) {
    case 'cooldown':
      return 'Busca de cifra em pausa (rede instável). Tente de novo em alguns segundos.';
    case 'proxy_forbidden':
      return 'Busca de cifra bloqueada neste PC — abra o Controle no servidor ou na rede da igreja.';
    case 'proxy':
      return 'Não foi possível contactar o Cifra Club agora. Verifique a internet e tente de novo.';
    default:
      return 'Cifra não encontrada no Cifra Club — confira título/hinário ou cole manualmente.';
  }
}
