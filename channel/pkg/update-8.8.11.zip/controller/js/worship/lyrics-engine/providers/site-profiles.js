/** Perfis de extração por domínio. */
export const SITE_PROFILES = {
  'genius.com': {
    selectors: ['div[data-lyrics-container="true"]', '.Lyrics__Container', '[class*="Lyrics__Container"]'],
  },
  'letras.mus.br': {
    selectors: ['.lyric-original', '.cnt-letra', '#js-lyric-content', '.lyric'],
  },
  'vagalume.com.br': {
    selectors: ['.lyric', '.lyric-original', '#lyric-content'],
  },
};

export function getSiteProfile(url) {
  try {
    const host = new URL(url).hostname.replace(/^www\./, '');
    for (const [domain, profile] of Object.entries(SITE_PROFILES)) {
      if (host === domain || host.endsWith('.' + domain)) return profile;
    }
  } catch { /* ignore */ }
  return { selectors: ['article', 'main', '[class*="lyric"]', '[id*="lyric"]', '.content'] };
}

export function hostFromUrl(url) {
  try { return new URL(url).hostname.replace(/^www\./, ''); } catch { return ''; }
}
