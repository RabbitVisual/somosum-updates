import { LyricsProvider } from './base-provider.js';
import { createLyricsResult } from '../models/lyrics-result.js';
import { fetchViaProxy } from '../lyrics-fetcher.js';
import { extractLyricsFromHtml } from '../lyrics-extractor.js';
import { buildSearchTerms } from '../lyrics-search-engine.js';
import { hintMatchBonus } from '../lyrics-confidence.js';
import { isValidMusicResult } from '../lyrics-result-filter.js';

function parseDuckDuckGoLinks(html) {
  const urls = [];
  if (typeof document === 'undefined') {
    const re = /uddg=([^&"]+)/g;
    let m;
    while ((m = re.exec(html)) && urls.length < 12) {
      try {
        const u = decodeURIComponent(m[1]);
        if (/letras|vagalume|genius|lyric/i.test(u)) urls.push(u);
      } catch { /* ignore */ }
    }
    return urls;
  }
  const doc = new DOMParser().parseFromString(html, 'text/html');
  for (const a of doc.querySelectorAll('a.result__a, a[href*="uddg="]')) {
    const href = a.getAttribute('href') || '';
    const m = href.match(/uddg=([^&]+)/);
    if (m) {
      try {
        const u = decodeURIComponent(m[1]);
        if (/letras|vagalume|genius|lyric|mus/i.test(u)) urls.push(u);
      } catch { /* ignore */ }
    }
    if (urls.length >= 12) break;
  }
  return urls;
}

function slugToLabel(slug) {
  return String(slug || '')
    .replace(/-/g, ' ')
    .replace(/\bpart\b/gi, 'part.')
    .replace(/\s+/g, ' ')
    .trim();
}

/** Extrai artista/título de URL letras.mus.br/{artist}/{song}/ */
export function parseLetrasUrlMeta(url) {
  try {
    const u = new URL(url.startsWith('http') ? url : `https://${url}`);
    if (!/letras\.mus\.br$/i.test(u.hostname.replace(/^www\./, ''))) return null;
    const parts = u.pathname.split('/').filter(Boolean);
    if (parts.length < 2) return null;
    const [artistSlug, songSlug] = parts;
    if (['search', 'busca', 'blog'].includes(artistSlug)) return null;
    return {
      artistSlug,
      songSlug,
      artist: slugToLabel(artistSlug),
      title: slugToLabel(songSlug),
    };
  } catch {
    return null;
  }
}

function resultFromUrl(url, parsed, index) {
  const letrasMeta = parseLetrasUrlMeta(url);
  const title = letrasMeta?.title || parsed?.title || '';
  const artist = letrasMeta?.artist || parsed?.artist || '';
  const base = createLyricsResult({
    providerId: 'web-search',
    title,
    artist,
    url,
    language: 'pt-BR',
    hasLyrics: true,
    confidence: 0.42 - index * 0.02,
    status: 'discovered',
  });
  const hintsBonus = hintMatchBonus(base, parsed);
  return {
    ...base,
    confidence: Math.min(0.88, base.confidence + hintsBonus),
    matchScore: Math.min(0.88, base.confidence + hintsBonus),
  };
}

export class WebSearchProvider extends LyricsProvider {
  constructor() {
    super('web-search', { priority: 7, requiresNetwork: true });
  }

  async search(query, parsed, { signal } = {}) {
    const fullQuery = parsed?.query || query;
    const terms = buildSearchTerms(parsed?.mode ? parsed : { mode: 'title', title: query, artist: '', altTitles: [], featSignals: [], searchHints: [] });
    const ddgQueries = parsed?.mode === 'snippet'
      ? [
        `site:letras.mus.br ${fullQuery}`,
        `${terms[0] || fullQuery} letra site:letras.mus.br`,
      ]
      : [
        `site:letras.mus.br ${fullQuery}`,
        `${terms[0] || fullQuery} letra letras.mus.br`,
      ];
    const urls = [];
    const seen = new Set();

    for (const ddgQ of ddgQueries) {
      const url = `https://html.duckduckgo.com/html/?q=${encodeURIComponent(ddgQ)}`;
      try {
        const res = await fetchViaProxy(url, { signal });
        for (const link of parseDuckDuckGoLinks(res.body || '')) {
          if (seen.has(link)) continue;
          seen.add(link);
          urls.push(link);
        }
      } catch { /* next query */ }
      if (urls.length >= 6) break;
    }

    return urls.slice(0, 6).map((u, i) => resultFromUrl(u, parsed, i)).filter(isValidMusicResult);
  }

  async getLyrics(result, { signal } = {}) {
    const res = await fetchViaProxy(result.url, { signal });
    return extractLyricsFromHtml(res.body || '', result.url);
  }
}
