import { LyricsProvider } from './base-provider.js';
import { createLyricsResult } from '../models/lyrics-result.js';
import { fetchViaProxy } from '../lyrics-fetcher.js';
import { extractLyricsFromHtml } from '../lyrics-extractor.js';

export class CustomProvider extends LyricsProvider {
  constructor(sites = []) {
    super('custom', { priority: 8, requiresNetwork: true });
    this.sites = sites;
  }

  async search(query, parsed, { signal } = {}) {
    const results = [];
    for (const site of this.sites) {
      if (!site?.url) continue;
      const q = encodeURIComponent(parsed?.title && parsed?.artist
        ? `${parsed.title} ${parsed.artist}`
        : (parsed?.title || query));
      const url = site.url.replace('{query}', q);
      results.push(createLyricsResult({
        providerId: this.id,
        title: parsed?.title || query,
        artist: parsed?.artist || '',
        url,
        language: 'pt-BR',
        hasLyrics: true,
        confidence: 0.5,
        status: 'custom',
      }));
    }
    return results;
  }

  async getLyrics(result, { signal } = {}) {
    const res = await fetchViaProxy(result.url, { signal });
    return extractLyricsFromHtml(res.body || '', result.url);
  }
}
