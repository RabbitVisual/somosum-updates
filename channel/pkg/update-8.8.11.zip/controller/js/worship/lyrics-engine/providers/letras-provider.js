import { LyricsProvider } from './base-provider.js';
import { createLyricsResult } from '../models/lyrics-result.js';
import { fetchViaProxy } from '../lyrics-fetcher.js';
import { extractLyricsFromHtml } from '../lyrics-extractor.js';
import { buildSearchTerms, sanitizeSearchTerm } from '../lyrics-search-engine.js';
import { isValidMusicResult } from '../lyrics-result-filter.js';

const LETRAS_HOST = 'https://www.letras.mus.br';
const SOLR_ENDPOINT = 'https://solr.sscdn.co/letras/m1/';

/** Slugs / path segments that are site chrome, not songs. */
const RESERVED_SLUGS = new Set([
  'search', 'busca', 'blog', 'playlists', 'estilos', 'academy', 'idiomas',
  'radio', 'mais-acessadas', 'top', 'news', 'assinatura', 'conta', 'login',
  'entrar', 'cadastro', 'artistas', 'musicas', 'albuns', 'atualizacoes',
  'lancamentos', 'enviar', 'enviar-letras', 'correcoes', 'ajuda', 'sobre',
  'termos', 'privacidade', 'apps', 'extensao', 'configuracoes', 'trabalhe',
  'significado', 'traducao', 'traducoes', 'cifra', 'video', 'videos',
]);

const NOISE_TITLES = new Set([
  'músicas', 'musicas', 'artistas', 'álbuns', 'albuns', 'playlists', 'blog',
  'treino de pronúncia', 'treino de pronuncia', 'aulas rápidas', 'aulas rapidas',
  'cursos de idiomas', 'ouvir', 'aleatório', 'aleatorio', 'enviar letra',
  'enviar letras', 'assinar', 'entrar', 'conta', 'menu', 'home', 'página inicial',
  'pagina inicial', 'letras', 'estilos musicais', 'atualizações', 'lançamentos',
]);

function stripAccents(s) {
  return String(s || '')
    .normalize('NFD')
    .replace(/\p{M}/gu, '')
    .toLowerCase();
}

/** Remove sufixo de hinário (" - 193", " - HC 120") para melhorar busca. */
export function normalizeLetrasSearchTitle(title) {
  return String(title || '')
    .trim()
    .replace(/\s*[-–—]\s*(?:HC|CC|HCC|H\s*C)?\s*\d+\s*$/i, '')
    .replace(/\+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

export function normalizeLetrasSearchQuery(title, artist) {
  const t = normalizeLetrasSearchTitle(title);
  const a = String(artist || '').trim();
  return { title: t, artist: a, query: [t, a].filter(Boolean).join(' ') };
}

/** Solr/Lucene treats `+` as operator — strip punctuation that breaks search. */
export function sanitizeLetrasSolrQuery(query) {
  return String(query || '')
    .replace(/\+/g, ' ')
    .replace(/[()[\]{}"'`]/g, ' ')
    .replace(/\bpart\.?\b/gi, ' ')
    .replace(/[^\p{L}\p{N}\s-]/gu, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

export function buildLetrasSolrUrl(query, limit = 12) {
  const q = encodeURIComponent(sanitizeLetrasSolrQuery(query));
  return `${SOLR_ENDPOINT}?q=${q}&wt=json&rows=${limit}`;
}

export function parseLetrasSolrJsonp(body) {
  const raw = String(body || '').trim();
  if (!raw) return [];
  const start = raw.indexOf('{');
  const end = raw.lastIndexOf('}');
  if (start < 0 || end <= start) return [];
  try {
    const data = JSON.parse(raw.slice(start, end + 1));
    return data?.response?.docs || [];
  } catch {
    return [];
  }
}

/**
 * Ranking no estilo Cifra Club: score Solr + boosts de título/artista/hints.
 * @returns {number} score bruto (quanto maior, melhor)
 */
export function scoreLetrasSolrDoc(doc, title, artist, { parsed } = {}) {
  const { title: nt, artist: na } = normalizeLetrasSearchQuery(title, artist);
  const docTitle = normalizeLetrasSearchTitle(String(doc?.txt || '').trim());
  const docArtist = String(doc?.art || '').trim();
  const songSlug = String(doc?.url || '').trim();
  const artistSlug = String(doc?.dns || '').trim();
  let score = Number(doc?.score) || 0;

  const ntNorm = stripAccents(nt);
  const dtNorm = stripAccents(docTitle);
  const naNorm = stripAccents(na);
  const daNorm = stripAccents(docArtist);
  const docCombined = stripAccents(`${docTitle} ${docArtist} ${songSlug} ${artistSlug}`);

  if (ntNorm && dtNorm === ntNorm) score += 120;
  else if (ntNorm && dtNorm.includes(ntNorm)) score += 70;
  else if (ntNorm && ntNorm.includes(dtNorm.split(' + ')[0]?.trim() || dtNorm)) score += 40;
  else if (ntNorm && dtNorm) {
    const qTokens = ntNorm.split(/\s+/).filter((t) => t.length > 2);
    const hits = qTokens.filter((t) => dtNorm.includes(t)).length;
    if (qTokens.length) score += Math.round((hits / qTokens.length) * 50);
  }

  if (naNorm && daNorm) {
    if (daNorm === naNorm) score += 80;
    else if (daNorm.includes(naNorm) || naNorm.includes(daNorm)) score += 45;
  }

  for (const alt of parsed?.altTitles || []) {
    const altNorm = stripAccents(alt);
    if (altNorm && docCombined.includes(altNorm)) score += 95;
  }

  for (const feat of parsed?.featSignals || []) {
    const featNorm = stripAccents(feat);
    if (!featNorm) continue;
    if (docCombined.includes(featNorm) || docCombined.includes(featNorm.replace(/\s+/g, ''))) {
      score += 40;
    }
  }

  const hasHints = (parsed?.searchHints?.length || 0) > 0;
  if (hasHints && ntNorm.split(/\s+/).filter(Boolean).length <= 1) {
    let hintHit = false;
    for (const alt of parsed.altTitles || []) {
      if (docCombined.includes(stripAccents(alt))) hintHit = true;
    }
    for (const feat of parsed.featSignals || []) {
      if (docCombined.includes(stripAccents(feat))) hintHit = true;
    }
    if (!hintHit && dtNorm === ntNorm) score -= 65;
  }

  return score;
}

function confidenceFromSolrScore(score) {
  return Math.max(0.4, Math.min(0.99, Number(score) / 200));
}

function isValidSongPath(artistSlug, songSlug) {
  if (!artistSlug || !songSlug) return false;
  if (RESERVED_SLUGS.has(artistSlug) || RESERVED_SLUGS.has(songSlug)) return false;
  if (songSlug.includes('significado') || artistSlug.includes('significado')) return false;
  if (/^\d+$/.test(artistSlug)) return false;
  return /^[a-z0-9][a-z0-9-]*$/i.test(artistSlug) && /^[a-z0-9][a-z0-9-]*$/i.test(songSlug);
}

function parseLetrasSongUrl(href) {
  try {
    const u = new URL(href.startsWith('http') ? href : `${LETRAS_HOST}${href.startsWith('/') ? '' : '/'}${href}`);
    if (!/letras\.mus\.br$/i.test(u.hostname.replace(/^www\./, ''))) return null;
    const parts = u.pathname.split('/').filter(Boolean);
    if (parts.length < 2) return null;
    const [artistSlug, songSlug] = parts;
    if (!isValidSongPath(artistSlug, songSlug)) return null;
    return {
      artistSlug,
      songSlug,
      url: `${LETRAS_HOST}/${artistSlug}/${songSlug}/`,
    };
  } catch {
    return null;
  }
}

function titleLooksLikeNoise(title) {
  const t = stripAccents(title).replace(/\s+/g, ' ').trim();
  if (!t || t.length < 2) return true;
  if (NOISE_TITLES.has(t)) return true;
  if (t.length <= 12 && /^(musicas|artistas|albuns|playlists|ouvir|aleatorio)$/.test(t)) return true;
  return false;
}

/**
 * Busca músicas no Solr da Letras (paridade com searchCifraClubSolr).
 */
export async function searchLetrasSolr(title, artist, fetchFn, { limit = 12, parsed } = {}) {
  const { query, title: nt, artist: na } = normalizeLetrasSearchQuery(title, artist);
  if (!query || !fetchFn) return [];

  const url = buildLetrasSolrUrl(query, limit);
  const res = await fetchFn(url);
  const docs = parseLetrasSolrJsonp(res?.body || '');

  return docs
    .filter((doc) => doc?.t == null || String(doc.t) === '2')
    .map((doc) => {
      const artistSlug = String(doc?.dns || '').trim();
      const songSlug = String(doc?.url || '').trim();
      if (!isValidSongPath(artistSlug, songSlug)) return null;
      const songTitle = String(doc?.txt || '').trim() || songSlug;
      if (titleLooksLikeNoise(songTitle)) return null;
      const score = scoreLetrasSolrDoc(doc, nt, na, { parsed });
      return {
        doc,
        score,
        url: `${LETRAS_HOST}/${artistSlug}/${songSlug}/`,
        title: songTitle,
        artist: String(doc?.art || '').trim(),
      };
    })
    .filter(Boolean)
    .sort((a, b) => b.score - a.score);
}

function resultsFromSolrHits(hits) {
  const results = [];
  const seen = new Set();
  for (const hit of hits || []) {
    if (!hit?.url || seen.has(hit.url)) continue;
    seen.add(hit.url);
    results.push(createLyricsResult({
      providerId: 'letras',
      title: hit.title,
      artist: hit.artist,
      url: hit.url,
      language: 'pt-BR',
      hasLyrics: true,
      confidence: confidenceFromSolrScore(hit.score),
      matchScore: confidenceFromSolrScore(hit.score),
    }));
    if (results.length >= 12) break;
  }
  return results;
}

/** Fallback HTML scrape — only real /artist/song/ links, never nav chrome. */
function parseSearchResults(html) {
  const results = [];
  if (typeof document === 'undefined') return results;
  const doc = new DOMParser().parseFromString(html, 'text/html');
  const links = doc.querySelectorAll('a[href]');
  const seen = new Set();
  for (const a of links) {
    const href = a.getAttribute('href') || '';
    const parsed = parseLetrasSongUrl(href);
    if (!parsed) continue;
    if (seen.has(parsed.url)) continue;
    seen.add(parsed.url);
    const text = (a.textContent || '').replace(/\s+/g, ' ').trim();
    if (titleLooksLikeNoise(text)) continue;
    const inNav = a.closest('nav, header, footer, [role="navigation"], .menu, #menu');
    if (inNav) continue;
    const parts = text.split(/\s[-–—]\s/);
    const title = parts[0]?.trim() || text;
    const artist = parts[1]?.trim() || '';
    if (titleLooksLikeNoise(title)) continue;
    results.push(createLyricsResult({
      providerId: 'letras',
      title,
      artist,
      url: parsed.url,
      language: 'pt-BR',
      hasLyrics: true,
      confidence: 0.45,
      matchScore: 0.45,
    }));
    if (results.length >= 10) break;
  }
  return results;
}

function buildSearchParts(query, parsed) {
  if (parsed?.title) {
    return {
      title: parsed.title,
      artist: parsed.artist || '',
      query: parsed.artist ? `${parsed.title} ${parsed.artist}` : parsed.title,
    };
  }
  const q = String(query || '').trim();
  const dash = q.split(/\s+[-–—]\s+/);
  if (dash.length >= 2) {
    return { title: dash[0].trim(), artist: dash.slice(1).join(' - ').trim(), query: q };
  }
  return { title: q, artist: '', query: q };
}

export class LetrasProvider extends LyricsProvider {
  constructor() {
    // Prioridade 2 — logo após biblioteca local (paridade com fluxo Cifra).
    super('letras', { priority: 2, requiresNetwork: true });
  }

  async search(query, parsed, { signal } = {}) {
    const parts = buildSearchParts(query, parsed);
    const effectiveParsed = parsed?.mode ? parsed : {
      mode: 'title', title: parts.title, artist: parts.artist, altTitles: [], featSignals: [], searchHints: [],
    };
    const terms = buildSearchTerms(effectiveParsed);
    const fetchFn = (url) => fetchViaProxy(url, { signal });
    const merged = [];
    const seen = new Set();

    const searchTerms = (terms.length ? terms : [parts.query]).slice(0, effectiveParsed.mode === 'snippet' ? 1 : 2);
    for (const term of searchTerms) {
      try {
        const hits = await searchLetrasSolr(term, parts.artist, fetchFn, { limit: 12, parsed: effectiveParsed });
        for (const hit of hits) {
          if (!hit?.url || seen.has(hit.url)) continue;
          seen.add(hit.url);
          merged.push(hit);
        }
      } catch { /* try next term */ }
    }

    merged.sort((a, b) => b.score - a.score);
    let fromSolr = resultsFromSolrHits(merged);

    if (!fromSolr.length || effectiveParsed.mode === 'snippet') {
      const q = encodeURIComponent(sanitizeLetrasSolrQuery(searchTerms[0] || parts.query));
      const url = `${LETRAS_HOST}/search/?q=${q}`;
      try {
        const res = await fetchViaProxy(url, { signal });
        const htmlHits = parseSearchResults(res.body || '');
        for (const hit of htmlHits) {
          if (!hit?.url || seen.has(hit.url)) continue;
          seen.add(hit.url);
          fromSolr.push(hit);
        }
      } catch { /* ignore */ }
    }

    return fromSolr.filter(isValidMusicResult).slice(0, 12);
  }

  async getLyrics(result, { signal } = {}) {
    const res = await fetchViaProxy(result.url, { signal });
    return extractLyricsFromHtml(res.body || '', result.url);
  }
}
