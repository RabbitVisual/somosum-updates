import { LyricsProvider } from './base-provider.js';
import { createLyricsResult } from '../models/lyrics-result.js';
import { fetchViaProxy } from '../lyrics-fetcher.js';

export class LyricsOvhProvider extends LyricsProvider {
  constructor() {
    super('lyrics-ovh', { priority: 5, requiresNetwork: true });
  }

  async search(query, parsed, { signal } = {}) {
    if (!parsed?.title) return [];
    const artist = parsed.artist || 'unknown';
    const title = parsed.title;
    const url = `https://api.lyrics.ovh/v1/${encodeURIComponent(artist)}/${encodeURIComponent(title)}`;
    try {
      const res = await fetchViaProxy(url, { signal });
      if (res.status !== 200) return [];
      const data = JSON.parse(res.body || '{}');
      if (!data.lyrics) return [];
      return [createLyricsResult({
        providerId: this.id,
        title,
        artist,
        url,
        language: 'en',
        hasLyrics: true,
        confidence: 0.75,
        externalId: url,
      })];
    } catch {
      return [];
    }
  }

  async getLyrics(result, { signal } = {}) {
    const res = await fetchViaProxy(result.url, { signal });
    const data = JSON.parse(res.body || '{}');
    return { plainText: data.lyrics || '', chordSource: null };
  }
}
