import { LyricsProvider } from './base-provider.js';
import { createLyricsResult } from '../models/lyrics-result.js';
import { searchWorship } from '../../worship-store.js';

export class LocalLibraryProvider extends LyricsProvider {
  constructor() {
    super('local', { priority: 1, requiresNetwork: false });
  }

  async search(query, parsed) {
    const q = parsed?.snippet || parsed?.title || query;
    const hits = searchWorship(q, {}) || [];
    return hits.slice(0, 15).map((s) => createLyricsResult({
      providerId: this.id,
      title: s.title,
      artist: s.artist,
      url: `local://${s.id}`,
      language: s.language || 'pt-BR',
      hasLyrics: !!s.lyrics,
      confidence: 1,
      matchScore: 1,
      status: 'cached',
      externalId: s.id,
      category: s.category || '',
      tags: Array.isArray(s.tags) ? s.tags : [],
    }));
  }

  async getLyrics(result) {
    const { getWorshipSong } = await import('../../worship-store.js');
    const song = await getWorshipSong(result.externalId);
    if (!song) return { plainText: '', chordSource: null };
    return { plainText: song.lyrics || '', chordSource: song.chordSource || null };
  }
}
