/** Filtra resultados que não são músicas/letras reais. */
import { normalizeForMatch, tokenOverlap } from './lyrics-confidence.js';

const NOISE_TITLES = new Set([
  'blog', 'menu', 'home', 'busca', 'search', 'login', 'entrar', 'conta',
  'playlists', 'artistas', 'musicas', 'músicas', 'albuns', 'álbuns',
  'treino de pronúncia', 'treino de pronuncia', 'aulas rápidas', 'aulas rapidas',
  'cursos de idiomas', 'enviar letras', 'assinar', 'ajuda', 'sobre',
  'página inicial', 'pagina inicial', 'letras', 'estilos musicais',
  'atualizações', 'lançamentos', 'ouvir', 'aleatório', 'aleatorio',
]);

const CHROME_SLUGS = new Set([
  'blog', 'search', 'busca', 'playlists', 'artistas', 'musicas', 'albuns',
  'estilos', 'academy', 'login', 'conta', 'entrar', 'ajuda', 'sobre',
]);

function titleIsNoise(title) {
  const t = normalizeForMatch(title);
  if (!t || t.length < 2) return true;
  if (NOISE_TITLES.has(t)) return true;
  if (t.length <= 12 && /^(musicas|artistas|albuns|playlists|blog)$/.test(t)) return true;
  return false;
}

function urlLooksLikeSong(url, providerId) {
  const u = String(url || '').toLowerCase();
  if (!u) return providerId === 'local';
  if (providerId === 'local') return u.startsWith('local://');
  if (/letras\.mus\.br/.test(u)) {
    const m = u.match(/letras\.mus\.br\/([^/]+)\/([^/?#]+)/);
    if (!m) return false;
    return !CHROME_SLUGS.has(m[1]) && !CHROME_SLUGS.has(m[2]);
  }
  if (/vagalume\.com\.br/.test(u)) {
    return /\/[^/]+\/[^/]+\.html$/i.test(u);
  }
  if (providerId === 'web-search') {
    return /letras\.mus\.br|vagalume\.com\.br|genius\.com/i.test(u);
  }
  return true;
}

/** Resultado parece música/letra válida? */
export function isValidMusicResult(result) {
  if (!result?.title) return false;
  if (titleIsNoise(result.title)) return false;
  if (!urlLooksLikeSong(result.url, result.providerId)) return false;
  if (result.providerId === 'vagalume' && !result.artist && titleIsNoise(result.title)) return false;
  return true;
}

/** Remove lixo e resultados com score muito baixo vs query. */
export function filterSearchResults(results, query, parsed, { minScore = 0.22 } = {}) {
  const q = parsed?.query || query || '';
  const hasHints = (parsed?.searchHints?.length || 0) > 0;
  const isSnippet = parsed?.mode === 'snippet';
  // Threshold mais permissivo — ranking já ordena; filtro só remove lixo/ruído
  const threshold = isSnippet ? 0.16 : (hasHints ? 0.24 : minScore);

  return (results || []).filter((r) => {
    if (!isValidMusicResult(r)) return false;
    const score = Number(r.matchScore ?? r.confidence) || 0;
    if (score < threshold) return false;

    if (isSnippet || hasHints) {
      const overlap = tokenOverlap(q, `${r.title} ${r.artist} ${r.url || ''}`);
      const hintOverlap = hasHints
        ? tokenOverlap((parsed.searchHints || []).join(' '), `${r.title} ${r.artist} ${r.url || ''}`)
        : 0;
      if (isSnippet && overlap < 0.08 && hintOverlap < 0.08 && score < 0.45) return false;
      if (hasHints && overlap < 0.12 && hintOverlap < 0.05 && score < 0.5) return false;
    }
    return true;
  });
}
