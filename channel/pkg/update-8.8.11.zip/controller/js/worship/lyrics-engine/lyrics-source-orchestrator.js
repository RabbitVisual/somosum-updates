import { parseSearchQuery } from './lyrics-search-engine.js';
import { rankResults } from './lyrics-result-ranker.js';
import { isLyricsOnline } from './lyrics-fetcher.js';
import { LocalLibraryProvider } from './providers/local-library-provider.js';
import { GeniusProvider } from './providers/genius-provider.js';
import { LyricsOvhProvider } from './providers/lyrics-ovh-provider.js';
import { LetrasProvider } from './providers/letras-provider.js';
import { VagalumeProvider } from './providers/vagalume-provider.js';
import { StructuredProvider } from './providers/structured-provider.js';
import { WebSearchProvider } from './providers/web-search-provider.js';
import { CustomProvider } from './providers/custom-provider.js';
import { normalizeLyricsPipeline } from './lyrics-normalizer.js';
import { createNormalizedSong } from './models/normalized-song.js';
import { computeMatchScore, isAutoDiscoverCandidate } from './lyrics-confidence.js';
import { getCachedSearch, setCachedSearch, noteProviderLatency } from './lyrics-search-cache.js';
const FAIL_THRESHOLD = 3;
const COOLDOWN_MS = 5 * 60 * 1000;

class CircuitBreaker {
  constructor() {
    this._failures = new Map();
    this._disabledUntil = new Map();
  }

  isOpen(id) {
    const until = this._disabledUntil.get(id) || 0;
    if (Date.now() < until) return true;
    if (until) this._disabledUntil.delete(id);
    return false;
  }

  recordSuccess(id) {
    this._failures.set(id, 0);
  }

  recordFailure(id) {
    const n = (this._failures.get(id) || 0) + 1;
    this._failures.set(id, n);
    if (n >= FAIL_THRESHOLD) this._disabledUntil.set(id, Date.now() + COOLDOWN_MS);
  }
}

let _providers = null;
let _providersCustomKey = '';
const _breaker = new CircuitBreaker();
let _abortController = null;

export function getProviders(customSites = []) {
  // Recria quando customSites muda; prioridades Letras/Vagalume atualizadas.
  if (!_providers || _providersCustomKey !== JSON.stringify(customSites || [])) {
    _providersCustomKey = JSON.stringify(customSites || []);
    _providers = [
      new LocalLibraryProvider(),
      new LetrasProvider(),
      new VagalumeProvider(),
      new GeniusProvider(),
      new LyricsOvhProvider(),
      new StructuredProvider(),
      new WebSearchProvider(),
      new CustomProvider(customSites),
    ].sort((a, b) => a.priority - b.priority);
  }
  return _providers;
}

export function cancelSearch() {
  _abortController?.abort();
  _abortController = null;
}

export async function searchLyrics(query, { onProgress, customSites } = {}) {
  cancelSearch();
  _abortController = new AbortController();
  const signal = _abortController.signal;
  const parsed = parseSearchQuery(query);
  const online = await isLyricsOnline();
  const providers = getProviders(customSites);
  const providerIds = providers.map((p) => p.id);
  const cached = await getCachedSearch(query, providerIds);
  if (cached?.results?.length) {
    onProgress?.('Cache local…');
    const reranked = rankResults(cached.results, query, parsed);
    return { results: reranked, parsed, online, fromCache: true };
  }
  const all = [];

  onProgress?.('Pesquisando…');

  const runnable = providers.filter((p) => {
    if (_breaker.isOpen(p.id)) return false;
    if (p.requiresNetwork && !online) return false;
    return true;
  });

  // Paralelo (estilo Cifra: resposta rápida) — timeout por provider.
  const settled = await Promise.all(runnable.map(async (p) => {
    if (signal.aborted) return [];
    const t0 = performance.now();
    try {
      const hits = await Promise.race([
        p.search(query, parsed, { signal }),
        new Promise((_, rej) => setTimeout(() => rej(new Error('timeout')), 5500)),
      ]);
      noteProviderLatency(p.id, performance.now() - t0, true);
      _breaker.recordSuccess(p.id);
      return hits || [];
    } catch (err) {
      noteProviderLatency(p.id, performance.now() - t0, false);
      _breaker.recordFailure(p.id);
      try {
        const { logLyrics } = await import('./lyrics-logger.js');
        const { LogLevel } = await import('../../core/logging/log-service.js');
        logLyrics('LYRICS_PROVIDER', { providerId: p.id, error: err?.message || String(err) }, LogLevel.WARN);
      } catch { /* ignore */ }
      return [];
    }
  }));

  for (const hits of settled) all.push(...hits);

  const ranked = rankResults(all, query, parsed);
  void setCachedSearch(query, providerIds, { results: ranked });
  try {
    const { logLyrics } = await import('./lyrics-logger.js');
    const { LogLevel } = await import('../../core/logging/log-service.js');
    logLyrics('LYRICS_SEARCH', {
      queryLen: String(query || '').length,
      resultCount: ranked.length,
      online,
      providersTried: runnable.map((p) => p.id),
      top: ranked.slice(0, 5).map((r) => ({
        providerId: r.providerId,
        title: r.title,
        score: r.matchScore,
      })),
    }, LogLevel.DEBUG);
  } catch { /* ignore */ }
  return { results: ranked, parsed, online };
}

export async function fetchAndNormalizeLyrics(result, query, { onProgress, skipChords = false } = {}) {
  const signal = _abortController?.signal;
  const parsed = parseSearchQuery(query);
  const providers = getProviders();
  const provider = providers.find((p) => p.id === result.providerId) || providers[0];

  onProgress?.('Obtendo conteúdo...');
  let raw;
  try {
    if (result.providerId === 'local') {
      raw = await provider.getLyrics(result, { signal });
    } else {
      raw = await provider.getLyrics(result, { signal });
    }
  } catch (err) {
    try {
      const { logLyrics } = await import('./lyrics-logger.js');
      const { LogLevel } = await import('../../core/logging/log-service.js');
      logLyrics('LYRICS_FETCH', {
        providerId: result.providerId,
        url: result.url,
        title: result.title,
        error: err?.message || String(err),
        err,
      }, LogLevel.ERROR);
    } catch { /* ignore */ }
    throw new Error(err.message || 'fetch_failed');
  }

  onProgress?.('Extraindo letra...');
  const plainText = raw.plainText || '';
  if (!plainText.trim()) {
    try {
      const { logLyrics } = await import('./lyrics-logger.js');
      const { LogLevel } = await import('../../core/logging/log-service.js');
      logLyrics('LYRICS_FETCH', {
        providerId: result.providerId,
        url: result.url,
        error: 'empty_lyrics',
      }, LogLevel.WARN);
    } catch { /* ignore */ }
    throw new Error('empty_lyrics');
  }

  onProgress?.('Analisando estrutura...');
  const matchScore = computeMatchScore(query, result, { parsed });
  const normalized = normalizeLyricsPipeline(plainText, { matchScore });

  let chordMeta = raw.chordSource ? { chordSource: raw.chordSource } : null;
  if (!chordMeta?.chordSource && !skipChords) {
    try {
      onProgress?.('Buscando cifra para músicos…');
      const { fetchChordsForSong } = await import('./providers/chord-fetch-provider.js');
      const fetched = await fetchChordsForSong(
        { title: result.title, artist: result.artist, url: result.url },
        { signal },
      );
      if (fetched?.chordSource) chordMeta = fetched;
    } catch { /* cifra opcional */ }
  }

  onProgress?.('Preparando importação...');
  return createNormalizedSong({
    title: result.title,
    artist: result.artist,
    plainLyrics: normalized.plainLyrics,
    sections: normalized.sections,
    chordSource: chordMeta?.chordSource || null,
    key: chordMeta?.key || '',
    bpm: chordMeta?.bpm ?? null,
    capo: chordMeta?.capo ?? 0,
    category: result.category || '',
    tags: result.tags || [],
    language: result.language?.startsWith('pt') ? 'Português' : (result.language || 'Português'),
    source: {
      provider: result.providerId,
      url: result.url,
      retrievedAt: Date.now(),
    },
    importMeta: {
      method: 'lyrics-engine',
      normalized: true,
      confidence: normalized.confidence,
    },
  });
}

/** Fallback automatizado: tenta extrair de candidatos com score/hints confiáveis. */
export async function autoDiscoverLyrics(query, { onProgress, skipChords = false } = {}) {
  const { results, parsed } = await searchLyrics(query, { onProgress });
  const webResults = results.filter((r) => r.providerId !== 'local');
  const eligible = webResults.filter((r) => isAutoDiscoverCandidate(r, parsed));
  const toTry = (eligible.length ? eligible : []).slice(0, 3);

  if (!eligible.length && webResults.length) {
    throw new Error('ambiguous_results');
  }

  for (const result of toTry) {
    try {
      const song = await fetchAndNormalizeLyrics(result, query, { onProgress, skipChords });
      if (song.plainLyrics?.trim()) return { song, result };
    } catch { /* next */ }
  }

  const local = results.find((r) => r.providerId === 'local');
  if (local && isAutoDiscoverCandidate(local, parsed)) {
    const song = await fetchAndNormalizeLyrics(local, query, { onProgress, skipChords });
    return { song, result: local };
  }

  throw new Error('no_lyrics_found');
}
