/** Parse de query: título, artista, trecho ou hints em parênteses. */

const QUOTED = /^["'""](.+)["'""]$/;
const FEAT_PREFIX = /^(?:part\.?|feat\.?|ft\.?|com|with)\s+(.+)$/i;
const LYRIC_WORD = /\b(o|a|os|as|do|da|dos|das|de|que|eu|tu|me|te|se|na|no|em|um|uma|senhor|deus|amor|vida|coracao|coração|terra|ouve|ouvir|ruge|rugir|leao|leão|judá|juda|voz|louvor|céu|ceu|mar|sol|luz|paz|gloria|glória|santo|cristo|jesus|reina|reino|espirito|espírito)\b/i;

function stripHinarioSuffix(title) {
  return String(title || '')
    .trim()
    .replace(/\s*[-–—]\s*(?:HC|CC|HCC|H\s*C)?\s*\d+\s*$/i, '')
    .trim();
}

function splitFeatNames(raw) {
  return String(raw || '')
    .split(/\s*,\s*|\s+e\s+|\s+and\s+/i)
    .map((s) => s.trim())
    .filter((s) => s.length >= 2);
}

/** Trecho de letra (≥4 palavras ou frase com vocabulário típico de louvor). */
export function looksLikeLyricSnippet(q) {
  const text = String(q || '').trim();
  if (!text) return false;
  if (/\([^)]+\)/.test(text)) return false;
  const words = text.split(/\s+/).filter(Boolean);
  if (words.length >= 5) return true;
  if (words.length >= 4 && LYRIC_WORD.test(text)) return true;
  if (words.length >= 3 && LYRIC_WORD.test(text) && text.length >= 18) return true;
  return false;
}

/** Extrai altTitle (ex. LION) e featSignals (part. X e Y) dos parênteses. */
export function extractParenHints(raw) {
  const altTitles = [];
  const featSignals = [];
  const blocks = [...String(raw || '').matchAll(/\(([^)]+)\)/g)].map((m) => m[1].trim());

  for (const block of blocks) {
    const featMatch = block.match(FEAT_PREFIX);
    if (featMatch) {
      featSignals.push(...splitFeatNames(featMatch[1]));
      continue;
    }
    const trimmed = block.trim();
    if (!trimmed) continue;
    const tokens = trimmed.split(/\s+/);
    const allCaps = tokens.every((t) => /^[A-Z0-9]{2,}$/.test(t));
    const singleCapsWord = tokens.length === 1 && /^[A-Z]{2,}$/.test(trimmed);
    const looksLikeAltTitle = singleCapsWord || (tokens.length <= 3 && allCaps);
    if (looksLikeAltTitle) altTitles.push(trimmed);
  }

  return { altTitles, featSignals };
}

function enrichParsed(base) {
  const searchHints = [
    ...(base.altTitles || []),
    ...(base.featSignals || []),
  ].filter(Boolean);
  return { ...base, searchHints };
}

export function parseSearchQuery(raw) {
  const q = String(raw || '').trim();
  if (!q) {
    return enrichParsed({
      mode: 'empty', query: '', title: '', artist: '', snippet: '', altTitles: [], featSignals: [],
    });
  }

  const quoted = q.match(QUOTED);
  if (quoted) {
    return enrichParsed({
      mode: 'snippet', query: q, title: '', artist: '', snippet: quoted[1].trim(), altTitles: [], featSignals: [],
    });
  }

  const dashParts = q.split(/\s+[-–—]\s+/).map((p) => p.trim()).filter(Boolean);
  if (dashParts.length === 2) {
    const left = stripHinarioSuffix(dashParts[0]);
    const right = dashParts[1];
    if (left.length >= 2 && right.length >= 2 && right.split(/\s+/).length <= 8) {
      const { altTitles, featSignals } = extractParenHints(left);
      const titleClean = left.replace(/\([^)]*\)/g, ' ').replace(/\+/g, ' ').replace(/\s+/g, ' ').trim();
      return enrichParsed({
        mode: 'title-artist',
        query: q,
        title: stripHinarioSuffix(titleClean) || left,
        artist: right,
        snippet: '',
        altTitles,
        featSignals,
      });
    }
  }

  if (looksLikeLyricSnippet(q)) {
    return enrichParsed({
      mode: 'snippet',
      query: q,
      title: '',
      artist: '',
      snippet: q,
      altTitles: [],
      featSignals: [],
    });
  }

  const { altTitles, featSignals } = extractParenHints(q);
  const noParen = q.replace(/\([^)]*\)/g, ' ').replace(/\+/g, ' ').replace(/\s+/g, ' ').trim();
  const cleaned = stripHinarioSuffix(noParen);

  return enrichParsed({
    mode: 'title',
    query: q,
    title: cleaned || q,
    artist: '',
    snippet: '',
    altTitles,
    featSignals,
  });
}

/** Sanitiza termo para Solr / busca web. */
export function sanitizeSearchTerm(term) {
  return String(term || '')
    .replace(/\+/g, ' ')
    .replace(/[()[\]{}"'`]/g, ' ')
    .replace(/\bpart\.?\b/gi, ' ')
    .replace(/[^\p{L}\p{N}\s-]/gu, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

export function buildSearchTerms(parsed) {
  if (!parsed || parsed.mode === 'empty') return [];
  if (parsed.mode === 'snippet') {
    const snip = sanitizeSearchTerm(parsed.snippet || parsed.query);
    return snip ? [snip] : [];
  }

  const title = parsed.title || '';
  const artist = parsed.artist || '';
  const hints = parsed.searchHints || [];
  const altTitles = parsed.altTitles || [];

  if (parsed.mode === 'title-artist') {
    const rich = sanitizeSearchTerm([title, ...altTitles, artist, ...hints].filter(Boolean).join(' '));
    const basic = sanitizeSearchTerm(`${title} ${artist}`.trim());
    return [...new Set([rich, basic, title].filter(Boolean))];
  }

  const fullRich = sanitizeSearchTerm([title, ...altTitles, ...hints].filter(Boolean).join(' '));
  const titleAlt = sanitizeSearchTerm([title, ...altTitles].filter(Boolean).join(' '));
  const titleOnly = sanitizeSearchTerm(title);
  return [...new Set([fullRich, titleAlt, titleOnly].filter(Boolean))];
}
