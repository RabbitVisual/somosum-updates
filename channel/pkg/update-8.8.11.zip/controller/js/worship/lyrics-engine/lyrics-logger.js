import { LogService, LogLevel, LogCategory } from '../../core/logging/log-service.js';

/**
 * Logs do Lyric Engine — detail sempre serializável (sem tokens/HTML completo).
 * Sucesso = DEBUG (não polui console); falhas = WARN/ERROR.
 * @param {string} tag ex.: LYRICS_SEARCH
 * @param {object} data
 * @param {string} [level]
 */
export function logLyrics(tag, data = {}, level = LogLevel.DEBUG) {
  const safe = sanitizeLyricsDetail(data);
  const opts = {
    category: LogCategory.LYRICS,
    module: 'lyrics-engine',
    detail: { tag, ...safe },
  };
  if (level === LogLevel.WARN) LogService.warn(tag, opts);
  else if (level === LogLevel.ERROR || level === LogLevel.FATAL) LogService.error(tag, { ...opts, err: data.err });
  else if (level === LogLevel.INFO) LogService.info(tag, opts);
  else LogService.debug(tag, opts);
}

function sanitizeLyricsDetail(data) {
  if (!data || typeof data !== 'object') return {};
  const out = {};
  for (const [k, v] of Object.entries(data)) {
    if (k === 'err') continue;
    if (k === 'html' || k === 'body' || k === 'token' || k === 'accessToken' || k === 'authorization') continue;
    if (typeof v === 'string' && v.length > 300) out[k] = `${v.slice(0, 300)}…`;
    else if (v && typeof v === 'object') {
      try {
        const s = JSON.stringify(v);
        out[k] = s.length > 500 ? `${s.slice(0, 500)}…` : v;
      } catch {
        out[k] = String(v);
      }
    } else out[k] = v;
  }
  if (data.err) {
    out.errorMessage = data.err?.message || String(data.err);
    out.errorName = data.err?.name || 'Error';
  }
  return out;
}

export const LyricsLogTag = {
  SEARCH: 'LYRICS_SEARCH',
  PROVIDER: 'LYRICS_PROVIDER',
  FETCH: 'LYRICS_FETCH',
  EXTRACT: 'LYRICS_EXTRACT',
  NORMALIZE: 'LYRICS_NORMALIZE',
  IMPORT: 'LYRICS_IMPORT',
  CACHE: 'LYRICS_CACHE',
};
