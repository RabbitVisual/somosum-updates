import { cleanPastedLyrics } from '../worship-parser.js';
import { isChordProText } from '../chordpro-parser.js';
import { getSiteProfile } from './providers/site-profiles.js';
import { dedupeAdjacentParagraphs } from './lyrics-deduplicator.js';

const NOISE_SELECTORS = 'script, style, nav, header, footer, aside, iframe, noscript, .ad, .ads, .advertisement, .menu, .navbar, .breadcrumb, .social, .share, .comments, .comment, [role="navigation"], [role="banner"], [role="contentinfo"]';

/**
 * Convert lyric HTML to plain text preserving line/stanza breaks.
 * textContent alone collapses <br> and adjacent lines (e.g. Letras.mus.br).
 */
export function htmlFragmentToLyricText(htmlOrEl) {
  let html = '';
  if (typeof htmlOrEl === 'string') {
    html = htmlOrEl;
  } else if (htmlOrEl && typeof htmlOrEl.innerHTML === 'string') {
    html = htmlOrEl.innerHTML;
  } else {
    return String(htmlOrEl?.textContent || '').replace(/\r\n/g, '\n');
  }

  return String(html)
    .replace(/\r\n/g, '\n')
    .replace(/<br\s*\/?>/gi, '\n')
    .replace(/<\/\s*(p|div|li|tr|h[1-6]|blockquote|section|article)\s*>/gi, '\n\n')
    .replace(/<\s*(p|div|li|tr|h[1-6]|blockquote|section|article)(\s[^>]*)?>/gi, '\n')
    .replace(/<[^>]+>/g, '')
    .replace(/&nbsp;/gi, ' ')
    .replace(/&amp;/gi, '&')
    .replace(/&lt;/gi, '<')
    .replace(/&gt;/gi, '>')
    .replace(/&#(\d+);/g, (_, n) => {
      try { return String.fromCharCode(Number(n)); } catch { return ''; }
    })
    .replace(/&#x([0-9a-f]+);/gi, (_, h) => {
      try { return String.fromCharCode(parseInt(h, 16)); } catch { return ''; }
    })
    .replace(/&apos;|&#39;/gi, "'")
    .replace(/&quot;/gi, '"')
    .replace(/[ \t]+\n/g, '\n')
    .replace(/\n[ \t]+/g, '\n')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}

export function stripHtmlToText(html) {
  if (!html) return '';
  if (typeof document === 'undefined') {
    return htmlFragmentToLyricText(html);
  }
  const doc = new DOMParser().parseFromString(html, 'text/html');
  doc.querySelectorAll(NOISE_SELECTORS).forEach((el) => el.remove());
  return htmlFragmentToLyricText(doc.body || html);
}

function pickBestLyricText(doc, selectors) {
  for (const sel of selectors || []) {
    const nodes = doc.querySelectorAll(sel);
    if (!nodes.length) continue;
    const text = [...nodes].map((n) => htmlFragmentToLyricText(n)).join('\n\n').trim();
    if (text.length > 80) return text;
  }
  return '';
}

export async function extractLyricsFromHtml(html, url = '') {
  const profile = getSiteProfile(url);
  let text = '';

  if (typeof document !== 'undefined') {
    const doc = new DOMParser().parseFromString(html, 'text/html');
    doc.querySelectorAll(NOISE_SELECTORS).forEach((el) => el.remove());

    text = pickBestLyricText(doc, profile.selectors);

    if (!text.trim()) {
      const candidates = doc.querySelectorAll('article, main, [class*="lyric"], [id*="lyric"], .content');
      let best = '';
      for (const el of candidates) {
        const t = htmlFragmentToLyricText(el).trim();
        if (t.length > best.length && t.length < 15000) best = t;
      }
      text = best || htmlFragmentToLyricText(doc.body);
    }
  } else {
    text = stripHtmlToText(html);
  }

  text = cleanPastedLyrics(dedupeAdjacentParagraphs(text));
  let chordSource = null;
  if (isChordProText(text)) {
    chordSource = text;
    try {
      const { chordProToPlainLyrics } = await import('../chordpro-parser.js');
      text = chordProToPlainLyrics(text);
    } catch { /* keep text */ }
  }

  return { plainText: text, chordSource };
}

/** Versão sync para worker (sem dynamic import chordpro). */
export function extractLyricsFromHtmlSync(html, url = '') {
  const profile = getSiteProfile(url);
  let text = stripHtmlToText(html);

  if (typeof document !== 'undefined') {
    const doc = new DOMParser().parseFromString(html, 'text/html');
    doc.querySelectorAll(NOISE_SELECTORS).forEach((el) => el.remove());
    const picked = pickBestLyricText(doc, profile.selectors);
    if (picked) text = picked;
  }

  text = cleanPastedLyrics(dedupeAdjacentParagraphs(text));
  return { plainText: text, chordSource: null };
}

export async function extractFromUrl(html, url) {
  return extractLyricsFromHtml(html, url);
}
