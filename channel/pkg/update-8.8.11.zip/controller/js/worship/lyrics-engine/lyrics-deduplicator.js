/** Remove duplicações causadas por página — preserva repetições musicais legítimas. */
export function dedupePageBlocks(blocks) {
  if (!blocks?.length) return blocks || [];
  const out = [];
  for (const block of blocks) {
    const text = (block.lines || []).join('\n').trim();
    if (!text) continue;
    const prev = out[out.length - 1];
    if (prev) {
      const prevText = (prev.lines || []).join('\n').trim();
      if (prevText === text && block.type === prev.type) continue;
    }
    out.push({ ...block, lines: [...(block.lines || [])] });
  }
  return out;
}

export function dedupeAdjacentLines(lines) {
  const out = [];
  let prev = null;
  for (const line of lines || []) {
    const t = String(line).trim();
    if (!t) {
      if (out.length && out[out.length - 1] !== '') out.push('');
      prev = null;
      continue;
    }
    if (t === prev) continue;
    out.push(line);
    prev = t;
  }
  return out.join('\n').replace(/\n{3,}/g, '\n\n').trim();
}

/**
 * Só remove parágrafos idênticos consecutivos (chrome duplicado na página).
 * NÃO remove refrões repetidos — isso quebrava detectChorusIndices.
 */
export function dedupeAdjacentParagraphs(text) {
  const paragraphs = String(text || '').split(/\n\s*\n/);
  const kept = [];
  let prevKey = null;
  for (const p of paragraphs) {
    const trimmed = p.trim();
    if (!trimmed) continue;
    const key = trimmed.toLowerCase();
    if (key === prevKey) continue;
    kept.push(trimmed);
    prevKey = key;
  }
  return kept.join('\n\n');
}

/**
 * @deprecated Prefer dedupeAdjacentParagraphs before section detection.
 * Global unique só sob demanda (ex.: limpeza manual agressiva).
 */
export function dedupePageLyrics(text, { preserveRepeats = true } = {}) {
  if (preserveRepeats !== false) return dedupeAdjacentParagraphs(text);
  const paragraphs = String(text || '').split(/\n\s*\n/);
  const seen = new Set();
  const kept = [];
  for (const p of paragraphs) {
    const key = p.trim().toLowerCase();
    if (!key) continue;
    if (seen.has(key)) continue;
    seen.add(key);
    kept.push(p.trim());
  }
  return kept.join('\n\n');
}
