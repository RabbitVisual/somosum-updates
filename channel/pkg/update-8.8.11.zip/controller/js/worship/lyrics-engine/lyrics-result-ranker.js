import { computeMatchScore } from './lyrics-confidence.js';
import { providerScoreBoost } from './lyrics-search-cache.js';
import { filterSearchResults } from './lyrics-result-filter.js';

const SOLR_PROVIDERS = new Set(['letras', 'vagalume', 'local']);
const PT_PROVIDERS = new Set(['letras', 'vagalume', 'local']);

export function rankResults(results, query, parsed) {
  const lang = (parsed?.language || 'pt').toLowerCase();
  const preferPt = lang.startsWith('pt');
  const hasHints = (parsed?.searchHints?.length || 0) > 0;
  const isSnippet = parsed?.mode === 'snippet';
  const trustTokenScore = hasHints || isSnippet;

  const scored = results.map((r) => {
    const tokenScore = computeMatchScore(query, r, { parsed });
    const providerConf = Number(r.confidence) || 0;
    let matchScore = tokenScore;

    if (trustTokenScore) {
      matchScore = tokenScore * 0.94 + providerConf * 0.06;
    } else if (SOLR_PROVIDERS.has(r.providerId) && providerConf > 0) {
      matchScore = Math.max(tokenScore, providerConf * 0.55 + tokenScore * 0.45);
    } else if (providerConf > 0) {
      matchScore = providerConf * 0.35 + tokenScore * 0.65;
    }

    matchScore += providerScoreBoost(r.providerId);
    if (preferPt && PT_PROVIDERS.has(r.providerId)) matchScore += 0.04;
    if (r.providerId === 'letras') matchScore += 0.02;

    return {
      ...r,
      matchScore: Math.max(0, Math.min(1, matchScore)),
      confidence: Math.max(providerConf, matchScore),
    };
  });

  scored.sort((a, b) => (b.matchScore - a.matchScore) || (b.confidence - a.confidence));
  const deduped = dedupeResults(scored);
  return filterSearchResults(deduped, query, parsed);
}

export function dedupeResults(results) {
  const seen = new Map();
  const out = [];
  for (const r of results) {
    const k = `${(r.title || '').toLowerCase().trim()}|${(r.artist || '').toLowerCase().trim()}`;
    const prev = seen.get(k);
    if (prev && prev.matchScore >= r.matchScore) continue;
    if (prev && Math.abs(prev.matchScore - r.matchScore) < 0.03) {
      if (prev.providerId === 'letras' && r.providerId !== 'letras') continue;
    }
    seen.set(k, r);
  }
  for (const r of seen.values()) out.push(r);
  out.sort((a, b) => b.matchScore - a.matchScore);
  return out;
}

export function pickBestCandidate(candidates, minScore = 0.35) {
  if (!candidates?.length) return null;
  const best = candidates[0];
  return best.matchScore >= minScore ? best : null;
}
