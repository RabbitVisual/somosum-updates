/**
 * Catálogo de hinários batistas — siglas para busca "CC 15", "HCC 12", etc.
 */
export const HINARIO_CATALOG = {
  CC: {
    sigla: 'CC',
    name: 'Cantor Cristão',
    filePrefix: 'CC',
    aliases: ['cantor cristao', 'cantor cristão'],
  },
  HCC: {
    sigla: 'HCC',
    name: 'Hinário Para o Culto Cristão',
    filePrefix: 'HCC',
    aliases: ['hinario culto cristao', 'hinário culto cristão', 'culto cristao', 'hinario para o culto cristao'],
  },
  HC: {
    sigla: 'HC',
    name: 'Harpa Cristã',
    filePrefix: 'HC',
    aliases: ['harpa crista', 'harpa cristã'],
  },
  HE: {
    sigla: 'HE',
    name: 'Hinário Evangélico',
    filePrefix: 'HM',
    aliases: ['hinario evangelico', 'hinário evangélico', 'hm'],
  },
  HNC: {
    sigla: 'HNC',
    name: 'Hinário Novo Cântico',
    filePrefix: 'HNC',
    aliases: ['hinario novo cantico', 'hinário novo cântico', 'novo cantico'],
  },
};

/** Categorias dos hinários padrão (nome da pasta = categoria). */
export const DEFAULT_HINARIO_CATEGORIES = [
  HINARIO_CATALOG.CC.name,
  HINARIO_CATALOG.HC.name,
  HINARIO_CATALOG.HE.name,
  HINARIO_CATALOG.HNC.name,
  HINARIO_CATALOG.HCC.name,
];

const SIGLA_ALIASES = {};
for (const cat of Object.values(HINARIO_CATALOG)) {
  SIGLA_ALIASES[cat.sigla] = cat.sigla;
  if (cat.filePrefix && cat.filePrefix !== cat.sigla) {
    SIGLA_ALIASES[String(cat.filePrefix).toUpperCase()] = cat.sigla;
  }
}

export function getHinarioBySigla(sigla) {
  return HINARIO_CATALOG[String(sigla || '').toUpperCase()] || null;
}

export function formatHinarioRef(ref) {
  if (!ref?.sigla || ref.numero == null) return '';
  return `${String(ref.sigla).toUpperCase()} ${ref.numero}`;
}

export function hinarioRefsToSearchText(refs = []) {
  return refs.map((r) => {
    const cat = getHinarioBySigla(r.sigla);
    const parts = [formatHinarioRef(r), r.sigla, String(r.numero)];
    if (cat) parts.push(cat.name, ...cat.aliases);
    return parts.join(' ');
  }).join(' ');
}

/** Parse query like "CC 15", "HCC12", "cantor cristao 15". */
export function parseHinarioQuery(query) {
  const raw = String(query || '').trim();
  if (!raw) return null;
  const norm = raw.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');

  const direct = norm.match(/^([a-z]{2,4})\s*[-.]?\s*(\d{1,4})$/i);
  if (direct) {
    const raw = direct[1].toUpperCase();
    const sigla = SIGLA_ALIASES[raw] || raw;
    if (HINARIO_CATALOG[sigla]) {
      return { sigla, numero: parseInt(direct[2], 10) };
    }
  }

  const numMatch = norm.match(/(\d{1,4})\s*$/);
  if (numMatch) {
    const num = parseInt(numMatch[1], 10);
    const prefix = norm.slice(0, numMatch.index).trim();
    // Número sozinho ("571") NÃO força hinário — senão a.includes("") casa tudo
    if (prefix.length < 2) return null;
    for (const [sigla, cat] of Object.entries(HINARIO_CATALOG)) {
      const filePrefix = String(cat.filePrefix || cat.sigla).toLowerCase();
      if (prefix === sigla.toLowerCase() || prefix === filePrefix) return { sigla, numero: num };
      const aliases = cat.aliases.map((a) => a.normalize('NFD').replace(/[\u0300-\u036f]/g, ''));
      if (aliases.some((a) => a.length >= 2 && (prefix.includes(a) || (prefix.length >= 2 && a.includes(prefix))))) {
        return { sigla, numero: num };
      }
    }
  }
  return null;
}

export function songMatchesHinarioQuery(song, parsed) {
  if (!parsed || !song) return false;
  const refs = song.hinarioRefs || [];
  return refs.some((r) =>
    String(r.sigla || '').toUpperCase() === parsed.sigla
    && Number(r.numero) === parsed.numero
  );
}

/** "CC 15, HCC 12" → [{ sigla, numero }, …] */
export function parseHinarioRefsInput(text) {
  const refs = [];
  String(text || '').split(/[,;]+/).forEach((chunk) => {
    const m = chunk.trim().match(/^([A-Za-z]{2,4})\s*[-.:]?\s*(\d{1,4})$/);
    if (m) {
      const raw = m[1].toUpperCase();
      const sigla = SIGLA_ALIASES[raw] || raw;
      if (HINARIO_CATALOG[sigla]) {
        refs.push({ sigla, numero: parseInt(m[2], 10) });
      }
    }
  });
  return refs;
}

export function formatHinarioRefsList(refs = []) {
  return refs.map(formatHinarioRef).filter(Boolean).join(', ');
}

/** Sigla curta para chips na UI (ex.: "Harpa Cristã" → "HC"). */
export function getHinarioSiglaForName(categoryName) {
  const name = String(categoryName || '').trim();
  if (!name) return '';
  const lower = name.toLowerCase();
  for (const cat of Object.values(HINARIO_CATALOG)) {
    if (cat.name === name || cat.name.toLowerCase() === lower) return cat.sigla;
  }
  return name.slice(0, 3).toUpperCase();
}

/** Compara nomes de categoria/hinário sem depender de capitalização. */
export function hinarioNamesEqual(a, b) {
  return String(a || '').trim().toLowerCase() === String(b || '').trim().toLowerCase();
}
