/**
 * Relatório de uso CCLI (U3-D) — persistência local offline.
 */
import { DiskAdapter } from '../core/storage/adapters/disk-adapter.js';

const PATH = 'ccli-usage.json';
const LS_KEY = 'somosum-ccli-usage';
const MAX = 500;

/** @type {{ songId: string, title: string, ccliNumber: string, cultoId: string, ts: number, count: number }[]|null} */
let cache = null;

async function load() {
  if (cache) return cache;
  try {
    const disk = await DiskAdapter.load(PATH);
    if (Array.isArray(disk?.entries)) {
      cache = disk.entries;
      return cache;
    }
    if (Array.isArray(disk)) {
      cache = disk;
      return cache;
    }
  } catch { /* ignore */ }
  try {
    cache = JSON.parse(localStorage.getItem(LS_KEY) || '[]');
  } catch {
    cache = [];
  }
  return cache;
}

function persist() {
  if (!cache) return;
  const payload = { version: 1, entries: cache.slice(-MAX) };
  DiskAdapter.saveDebounced(PATH, payload);
  try { localStorage.setItem(LS_KEY, JSON.stringify(cache.slice(-MAX))); } catch { /* */ }
}

function csvEscape(value) {
  const s = String(value ?? '');
  if (/[",\n\r]/.test(s)) return `"${s.replace(/"/g, '""')}"`;
  return s;
}

/**
 * Registra uso de uma música projetada ao vivo.
 * @param {{ songId?: string, title?: string, ccliNumber?: string, cultoId?: string }} entry
 */
export async function recordSongUsage(entry = {}) {
  const songId = String(entry.songId || '').trim();
  const title = String(entry.title || '').trim() || 'Sem título';
  const ccliNumber = String(entry.ccliNumber || '').trim();
  const cultoId = String(entry.cultoId || 'current').trim() || 'current';
  if (!songId && !title) return null;

  await load();
  const dayKey = new Date().toISOString().slice(0, 10);
  const existing = cache.find((e) =>
    e.songId === songId
    && e.cultoId === cultoId
    && String(e.ts ? new Date(e.ts).toISOString().slice(0, 10) : '') === dayKey
  );

  if (existing) {
    existing.count = (Number(existing.count) || 1) + 1;
    existing.ts = Date.now();
    if (title) existing.title = title;
    if (ccliNumber) existing.ccliNumber = ccliNumber;
  } else {
    cache.push({
      songId,
      title,
      ccliNumber,
      cultoId,
      ts: Date.now(),
      count: 1,
    });
  }
  if (cache.length > MAX) cache = cache.slice(-MAX);
  persist();
  return existing || cache[cache.length - 1];
}

/**
 * Hook: registra CCLI quando um item de louvor vai ao ar (uma vez por item).
 * @param {object} app control-app
 */
export async function recordLiveSongFromApp(app) {
  if (!app?.program || app.isRehearsal?.()) return;
  const meta = app.program.getCurrentMeta?.() || {};
  const itemIndex = meta.itemIndex ?? -1;
  if (itemIndex < 0) return;
  const item = app.program.items?.[itemIndex];
  if (!item || (item.slideType !== 'lyrics' && item.slideType !== 'lyrics-title')) return;

  const key = `${item.songId || item.id || itemIndex}:${itemIndex}`;
  if (app._lastCcliUsageKey === key) return;
  app._lastCcliUsageKey = key;

  let song = null;
  if (item.songId) {
    song = app.program.songsCache?.get?.(item.songId) || null;
    if (!song) {
      try {
        song = await app.program.cacheSong?.(item.songId);
      } catch { /* ignore */ }
    }
  }

  const ccliNumber = song?.ccliNumber
    || song?.data?.ccliNumber
    || item.data?.ccliNumber
    || item.ccliNumber
    || '';

  const cultoId = app.prefs?.navigation?.activeCultoId
    || app.cultoIndex?.activeId
    || 'current';

  await recordSongUsage({
    songId: item.songId || item.id || '',
    title: song?.title || item.title || '',
    ccliNumber,
    cultoId,
  });
}

export async function listUsage({ cultoId, limit = 200 } = {}) {
  await load();
  let list = cache.slice().reverse();
  if (cultoId) list = list.filter((e) => e.cultoId === cultoId);
  return list.slice(0, limit);
}

export async function exportCsv() {
  const rows = await listUsage({ limit: MAX });
  const header = ['songId', 'title', 'ccliNumber', 'cultoId', 'ts', 'count', 'date'];
  const lines = [header.join(',')];
  for (const e of rows.slice().reverse()) {
    const date = e.ts ? new Date(e.ts).toISOString() : '';
    lines.push([
      csvEscape(e.songId),
      csvEscape(e.title),
      csvEscape(e.ccliNumber),
      csvEscape(e.cultoId),
      csvEscape(e.ts),
      csvEscape(e.count || 1),
      csvEscape(date),
    ].join(','));
  }
  return lines.join('\n');
}

/** HTML imprimível offline para relatório CCLI. */
export async function exportPdfHtml() {
  const rows = await listUsage({ limit: MAX });
  const ordered = rows.slice().reverse();
  const total = ordered.reduce((n, e) => n + (Number(e.count) || 1), 0);
  const body = ordered.map((e) => {
    const date = e.ts ? new Date(e.ts).toLocaleString() : '';
    return `<tr>
      <td>${escapeHtml(e.title || '')}</td>
      <td>${escapeHtml(e.ccliNumber || '—')}</td>
      <td>${escapeHtml(e.cultoId || '')}</td>
      <td>${Number(e.count) || 1}</td>
      <td>${escapeHtml(date)}</td>
    </tr>`;
  }).join('') || '<tr><td colspan="5">Nenhum uso registrado.</td></tr>';

  return `<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8" />
  <title>Relatório CCLI — SOMOSUM</title>
  <style>
    body { font-family: Georgia, "Times New Roman", serif; margin: 2rem; color: #111; }
    h1 { font-size: 1.4rem; margin: 0 0 0.25rem; }
    .meta { color: #444; margin-bottom: 1.5rem; font-size: 0.95rem; }
    table { width: 100%; border-collapse: collapse; font-size: 0.9rem; }
    th, td { border: 1px solid #ccc; padding: 0.4rem 0.55rem; text-align: left; }
    th { background: #f3f3f3; }
    @media print { body { margin: 0.8rem; } }
  </style>
</head>
<body>
  <h1>Relatório de uso CCLI</h1>
  <p class="meta">Gerado offline · ${escapeHtml(new Date().toLocaleString())} · ${ordered.length} registros · ${total} usos</p>
  <table>
    <thead><tr><th>Título</th><th>CCLI</th><th>Culto</th><th>Qtd</th><th>Data</th></tr></thead>
    <tbody>${body}</tbody>
  </table>
  <script>window.addEventListener('load', () => { try { window.print(); } catch (e) {} });</script>
</body>
</html>`;
}

function escapeHtml(s) {
  return String(s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

export async function clearUsage(cultoId) {
  await load();
  cache = cultoId ? cache.filter((e) => e.cultoId !== cultoId) : [];
  persist();
}
