/**
 * Consultas de cifra priorizando nome do hinário + título (Cifra Club Solr
 * ignora "HC 571" / "CC 50" sozinho e costuma devolver hinos errados).
 */
import {
  formatHinarioRef,
  getHinarioBySigla,
  DEFAULT_HINARIO_CATEGORIES,
  hinarioNamesEqual,
} from './hinario-catalog.js';
import { normalizeCifraSearchTitle } from './cifra-html-to-chordpro.js';

export function isHinarioCategoryName(name) {
  const n = String(name || '').trim();
  if (!n) return false;
  return DEFAULT_HINARIO_CATEGORIES.some((c) => hinarioNamesEqual(c, n));
}

/** Artista efetivo para busca/score: nome do hinário, não compositor. */
export function resolveHinarioCifraArtist(song = {}) {
  if (song.category && isHinarioCategoryName(song.category)) {
    return String(song.category).trim();
  }
  const refs = Array.isArray(song.hinarioRefs) ? song.hinarioRefs : [];
  for (const ref of refs) {
    const cat = getHinarioBySigla(ref?.sigla);
    if (cat?.name) return cat.name;
  }
  const artist = String(song.artist || '').trim();
  if (artist && isHinarioCategoryName(artist)) return artist;
  return '';
}

export function resolveHinarioCifraNumber(song = {}) {
  const refs = Array.isArray(song.hinarioRefs) ? song.hinarioRefs : [];
  for (const ref of refs) {
    const n = Number(ref?.numero);
    if (Number.isFinite(n) && n > 0) return n;
  }
  return null;
}

/** @returns {string[]} queries únicas, mais específicas primeiro */
export function buildHinarioCifraSearchQueries(song = {}) {
  const title = normalizeCifraSearchTitle(song.title);
  const queries = [];
  const refs = Array.isArray(song.hinarioRefs) ? song.hinarioRefs : [];

  const push = (q) => {
    const s = String(q || '').replace(/\s+/g, ' ').trim();
    if (s.length >= 3) queries.push(s);
  };

  for (const ref of refs) {
    if (!ref?.sigla || ref.numero == null) continue;
    const cat = getHinarioBySigla(ref.sigla);
    const refLabel = formatHinarioRef(ref);
    const num = ref.numero;

    // Nome do hinário + título (melhor hit no Solr do Cifra Club)
    if (cat?.name && title) {
      push(`${cat.name} ${title}`);
      push(`${title} ${cat.name}`);
    }
    // Título + número (ex.: "Rende O Coração 571") — evita "HC 571" vazio
    if (title) {
      push(`${title} ${num}`);
      push(`${num} ${title}`);
    }
    if (cat?.name && title) {
      push(`${cat.name} ${num} ${title}`);
    }
    // Só número com nome do hinário: frágil no Solr — só se não houver título
    if (cat?.name && !title) {
      push(`${cat.name} ${num}`);
      push(refLabel);
    }
    if (cat?.aliases && title) {
      for (const alias of cat.aliases.slice(0, 2)) {
        push(`${alias} ${title}`);
      }
    }
  }

  if (song.category && isHinarioCategoryName(song.category) && title) {
    push(`${song.category} ${title}`);
    push(`${title} ${song.category}`);
  }

  if (title) push(title);

  // Compositor só ajuda em louvor comum — em hinário polui a busca
  const artist = String(song.artist || song.composer || '').trim();
  const hymnalArtist = resolveHinarioCifraArtist(song);
  if (title && artist && !hymnalArtist && !/autor desconhecido|anonim/i.test(artist)) {
    push(`${title} ${artist}`);
  }

  const seen = new Set();
  return queries.filter((q) => {
    const key = q.toLowerCase();
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}
