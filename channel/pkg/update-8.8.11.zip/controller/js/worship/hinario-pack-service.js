/**
 * Catálogo e instalação opcional de pacotes de hinários.
 * Offline-first · ZIP/7z via API C# · CDN opcional · desinstalar.
 */
import { normalizeSong } from './worship-schema.js';
import { unzipHinarioPackJson, readResponseWithProgress } from './hinario-pack-unzip.js';
import { registerPackSnapshots, unregisterPackSnapshots } from './default-hinarios.js';
import { formatHinarioPackError, isOnline } from './hinario-pack-errors.js';
import { HINARIO_CATALOG } from './hinario-catalog.js';
import { fetchCatalog } from '../core/catalog-proxy-fetch.js';

const MANIFEST_URL = '/content/packs/hinarios/manifest.json';
const EXTRACT_API = '/api/content/packs/hinarios/extract';
const EXTRACT_BYTES_API = '/api/content/packs/hinarios/extract-bytes';

let _manifestPromise = null;

function normalizePackEntry(p) {
  return {
    id: String(p.id || '').toLowerCase(),
    sigla: String(p.sigla || '').toUpperCase(),
    name: String(p.name || p.category || ''),
    category: String(p.category || p.name || ''),
    file: String(p.file || ''),
    format: String(p.format || 'zip').toLowerCase(),
    altFile: String(p.altFile || p.zipFile || '').trim(),
    altFormat: String(p.altFormat || 'zip').toLowerCase(),
    remotePath: String(p.remotePath || p.cdnPath || '').trim(),
    sha256: String(p.sha256 || '').trim().toLowerCase(),
    version: Number(p.version) || 1,
    count: Number(p.count) || 0,
    bytes: Number(p.bytes) || 0,
    remoteOnly: !!p.remoteOnly,
  };
}

function mergeManifests(local, remote) {
  if (!remote?.packs?.length) return local;
  const byId = new Map((local.packs || []).map((p) => [p.id, p]));
  for (const rp of remote.packs) {
    const pack = normalizePackEntry(rp);
    if (!pack.id) continue;
    const existing = byId.get(pack.id);
    if (existing) {
      byId.set(pack.id, {
        ...existing,
        remotePath: pack.remotePath || existing.remotePath,
        sha256: pack.sha256 || existing.sha256,
        version: Math.max(pack.version, existing.version),
      });
    } else {
      byId.set(pack.id, { ...pack, remoteOnly: true });
    }
  }
  return {
    ...local,
    cdnBaseUrl: remote.cdnBaseUrl || local.cdnBaseUrl,
    packs: [...byId.values()],
  };
}

export async function fetchHinarioPackManifest({ force = false } = {}) {
  if (force) _manifestPromise = null;
  if (!_manifestPromise) {
    _manifestPromise = (async () => {
      const res = await fetch(MANIFEST_URL, { cache: 'no-store' });
      if (!res.ok) throw new Error(`manifest_fetch_${res.status}`);
      const data = await res.json();
      let manifest = {
        version: Number(data?.version) || 1,
        totalSongs: Number(data?.totalSongs) || 0,
        cdnBaseUrl: String(data?.cdnBaseUrl || data?.cdn || '').trim().replace(/\/+$/, ''),
        remoteCatalogUrl: String(data?.remoteCatalogUrl || '').trim(),
        packs: (Array.isArray(data?.packs) ? data.packs : []).map(normalizePackEntry).filter((p) => p.id),
      };

      if (manifest.remoteCatalogUrl && isOnline()) {
        try {
          const remoteRes = await fetchCatalog(`${manifest.remoteCatalogUrl}${manifest.remoteCatalogUrl.includes('?') ? '&' : '?'}_=${Date.now()}`);
          if (remoteRes.ok) {
            const remoteData = await remoteRes.json();
            manifest = mergeManifests(manifest, {
              cdnBaseUrl: remoteData.cdnBaseUrl || remoteData.cdn,
              packs: remoteData.packs,
            });
          }
        } catch {
          /* offline / CDN opcional — ignora */
        }
      }
      return manifest;
    })();
  }
  return _manifestPromise;
}

export function invalidateHinarioPackManifest() {
  _manifestPromise = null;
}

export function getInstalledHinarioPacks(meta = {}) {
  const raw = meta?.hinarioPacks;
  if (!raw || typeof raw !== 'object') return {};
  return { ...raw };
}

export function isHinarioPackInstalled(meta, packId) {
  const id = String(packId || '').toLowerCase();
  return !!getInstalledHinarioPacks(meta)[id]?.installedAt;
}

function localPackUrl(file) {
  return `/content/packs/hinarios/${encodeURIComponent(file)}`;
}

function remotePackUrl(manifest, pack) {
  const base = manifest?.cdnBaseUrl || '';
  const path = pack.remotePath || `hinarios/${pack.file}`;
  if (!base) return null;
  return `${base.replace(/\/+$/, '')}/${path.replace(/^\/+/, '')}`;
}

function resolvePackFiles(pack) {
  const primary = { file: pack.file, format: pack.format || 'zip' };
  const alt = pack.altFile
    ? { file: pack.altFile, format: pack.altFormat || 'zip' }
    : null;
  if (primary.format === '7z' && alt?.format === 'zip') {
    return [alt, primary];
  }
  return alt ? [primary, alt] : [primary];
}

function validatePackJson(packJson, packInfo) {
  if (!packJson || typeof packJson !== 'object') throw new Error('pack_json_invalid');
  if (!Array.isArray(packJson.songs) || !packJson.songs.length) throw new Error('pack_json_invalid');
  if (packInfo?.count && packJson.songs.length > packInfo.count + 5) {
    throw new Error('pack_json_invalid');
  }
  return packJson;
}

async function extractViaApi(file) {
  const url = `${EXTRACT_API}?file=${encodeURIComponent(file)}`;
  const res = await fetch(url, { cache: 'no-store' });
  if (!res.ok) {
    let code = `extract_api_${res.status}`;
    try {
      const err = await res.json();
      if (err?.error) code = String(err.error);
    } catch { /* ignore */ }
    throw new Error(code);
  }
  const data = await res.json();
  if (data?.ok === false) throw new Error(data.error || 'extract_api_failed');
  if (Array.isArray(data?.songs)) return data;
  return data;
}

async function extractViaApiBytes(bytes, format) {
  const res = await fetch(`${EXTRACT_BYTES_API}?format=${encodeURIComponent(format)}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/octet-stream' },
    body: bytes,
  });
  if (!res.ok) throw new Error(`extract_api_${res.status}`);
  return res.json();
}

async function fetchPackBytes(manifest, pack, fileEntry, onProgress) {
  onProgress?.('download', 0);

  if (!pack.remoteOnly) {
    const localRes = await fetch(localPackUrl(fileEntry.file), { cache: 'no-store' });
    if (localRes.ok) {
      return readResponseWithProgress(localRes, (pct) => onProgress?.('download', pct));
    }
  }

  const remoteUrl = remotePackUrl(manifest, { ...pack, file: fileEntry.file });
  if (remoteUrl && isOnline()) {
    try {
      const remoteRes = await fetchCatalog(remoteUrl);
      if (remoteRes.ok) {
        return readResponseWithProgress(remoteRes, (pct) => onProgress?.('download', pct));
      }
    } catch {
      /* tenta próximo */
    }
  }

  if (!isOnline() && pack.remoteOnly) throw new Error('offline_no_local');
  throw new Error(`pack_fetch_404:${fileEntry.file}`);
}

/**
 * Carrega pack.json — API C# (ZIP/7z) → fallback cliente ZIP → CDN + extract-bytes.
 */
export async function loadHinarioPackJson(pack, manifest, { onProgress } = {}) {
  const attempts = resolvePackFiles(pack);

  for (const fileEntry of attempts) {
    try {
      onProgress?.('extract', 0);
      const viaApi = await extractViaApi(fileEntry.file);
      onProgress?.('extract', 100);
      return validatePackJson(viaApi, pack);
    } catch (apiErr) {
      const apiMsg = String(apiErr?.message || '');
      if (fileEntry.format === '7z' && (apiMsg.includes('7za') || apiMsg.includes('7z'))) {
        continue;
      }
      if (fileEntry.format !== 'zip') continue;

      try {
        const bytes = await fetchPackBytes(manifest, pack, fileEntry, onProgress);
        onProgress?.('extract', 0);
        const json = await unzipHinarioPackJson(bytes);
        onProgress?.('extract', 100);
        return validatePackJson(json, pack);
      } catch (clientErr) {
        if (attempts.indexOf(fileEntry) < attempts.length - 1) continue;
        throw clientErr;
      }
    }
  }

  for (const fileEntry of attempts) {
    if (fileEntry.format === '7z') continue;
    try {
      const bytes = await fetchPackBytes(manifest, pack, fileEntry, onProgress);
      onProgress?.('extract', 0);
      const json = await extractViaApiBytes(bytes, fileEntry.format);
      onProgress?.('extract', 100);
      return validatePackJson(json, pack);
    } catch {
      /* next */
    }
  }

  throw new Error('seven_zip_missing');
}

export async function installHinarioPack(packId, deps = {}) {
  const {
    saveManySongs,
    loadMeta,
    saveMeta,
    getExistingSongs,
    onProgress,
  } = deps;

  const id = String(packId || '').toLowerCase();
  let manifest;
  try {
    manifest = await fetchHinarioPackManifest();
  } catch (err) {
    throw new Error(formatHinarioPackError(err));
  }

  const packInfo = manifest.packs.find((p) => p.id === id);
  if (!packInfo) throw new Error('pack_not_found:' + id);

  const meta = await loadMeta();
  if (isHinarioPackInstalled(meta, id)) {
    return { added: 0, skipped: packInfo.count, pack: packInfo, alreadyInstalled: true };
  }

  onProgress?.('prepare', 5);
  let packJson;
  try {
    packJson = await loadHinarioPackJson(packInfo, manifest, {
      onProgress: (phase, pct) => {
        if (phase === 'download') onProgress?.('download', pct);
        if (phase === 'extract') onProgress?.('extract', pct);
      },
    });
  } catch (err) {
    throw new Error(formatHinarioPackError(err));
  }

  const existing = await getExistingSongs();
  const existingIds = new Set(existing.map((s) => s.id));
  const toAdd = [];
  let skipped = 0;

  for (const raw of packJson.songs || []) {
    const seed = normalizeSong({
      ...raw,
      source: {
        ...(raw.source || {}),
        provider: 'hinario-pack',
        packId: id,
      },
    });
    if (existingIds.has(seed.id)) {
      skipped += 1;
      continue;
    }
    toAdd.push(seed);
    existingIds.add(seed.id);
  }

  onProgress?.('import', 50);
  try {
    if (toAdd.length) await saveManySongs(toAdd);
  } catch {
    throw new Error('import_failed');
  }

  registerPackSnapshots(packJson.songs || []);

  const installed = getInstalledHinarioPacks(meta);
  installed[id] = {
    version: packInfo.version,
    sigla: packInfo.sigla,
    name: packInfo.name,
    count: packInfo.count,
    installedAt: Date.now(),
    added: toAdd.length,
  };

  await saveMeta({
    hinarioPacks: installed,
    hinarioCategories: Object.values(installed).map((p) => p.name).filter(Boolean),
  });

  onProgress?.('done', 100);
  return { added: toAdd.length, skipped, pack: packInfo };
}

export function songsBelongToPack(song, packId, packInfo = {}) {
  const id = String(packId || '').toLowerCase();
  const src = song?.source;
  if (src?.packId && String(src.packId).toLowerCase() === id) return true;
  if (src?.provider === 'hinario-pack' && src?.packId && String(src.packId).toLowerCase() === id) return true;

  const sigla = String(packInfo.sigla || '').toUpperCase();
  if (sigla && Array.isArray(song?.hinarioRefs)) {
    if (song.hinarioRefs.some((r) => String(r?.sigla || '').toUpperCase() === sigla)) {
      return !!(song.systemDefault || song.protected);
    }
  }

  const cat = packInfo.category || packInfo.name;
  if (cat && String(song?.category || '').trim().toLowerCase() === String(cat).trim().toLowerCase()
    && (song.systemDefault || song.protected)) return true;

  const catalog = HINARIO_CATALOG[sigla];
  if (catalog
    && String(song?.category || '').trim().toLowerCase() === String(catalog.name).trim().toLowerCase()
    && (song.systemDefault || song.protected)) return true;

  return false;
}

export async function uninstallHinarioPack(packId, deps = {}) {
  const { loadMeta, saveMeta, getExistingSongs, deleteManySongs, onProgress } = deps;
  const id = String(packId || '').toLowerCase();

  const meta = await loadMeta();
  if (!isHinarioPackInstalled(meta, id)) {
    return { removed: 0, pack: null, notInstalled: true };
  }

  const manifest = await fetchHinarioPackManifest().catch(() => ({ packs: [] }));
  const packInfo = manifest.packs.find((p) => p.id === id) || meta.hinarioPacks?.[id] || { id };

  const existing = await getExistingSongs();
  const toRemove = existing.filter((s) => songsBelongToPack(s, id, packInfo));
  if (!toRemove.length) {
    const installed = getInstalledHinarioPacks(meta);
    delete installed[id];
    await saveMeta({
      hinarioPacks: installed,
      hinarioCategories: Object.values(installed).map((p) => p.name).filter(Boolean),
    });
    unregisterPackSnapshots(id, packInfo.sigla);
    return { removed: 0, pack: packInfo, empty: true };
  }

  onProgress?.('remove', 10);
  await deleteManySongs(toRemove.map((s) => s.id));
  unregisterPackSnapshots(id, packInfo.sigla);

  const installed = getInstalledHinarioPacks(meta);
  delete installed[id];
  await saveMeta({
    hinarioPacks: installed,
    hinarioCategories: Object.values(installed).map((p) => p.name).filter(Boolean),
  });

  onProgress?.('done', 100);
  return { removed: toRemove.length, pack: packInfo };
}

export async function installAllHinarioPacks(deps) {
  const manifest = await fetchHinarioPackManifest();
  let totalAdded = 0;
  const errors = [];
  for (const pack of manifest.packs) {
    if (pack.remoteOnly) continue;
    try {
      const r = await installHinarioPack(pack.id, deps);
      totalAdded += r.added || 0;
    } catch (err) {
      errors.push({ id: pack.id, error: formatHinarioPackError(err) });
    }
  }
  return { added: totalAdded, packs: manifest.packs.length, errors };
}

export function formatPackSize(bytes) {
  const n = Number(bytes) || 0;
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(0)} KB`;
  return `${(n / (1024 * 1024)).toFixed(1)} MB`;
}

export { formatHinarioPackError };
