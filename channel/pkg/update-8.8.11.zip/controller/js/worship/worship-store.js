/**
 * API unificada da Biblioteca de Louvores — camada sobre store + índice + cache.
 */
import {
  getAllSongs,
  getSong,
  saveSong as storeSaveSong,
  deleteSong as storeDeleteSong,
  generateId,
} from '../core/store.js';
import { normalizeSong, songMetaLite } from './worship-schema.js';
import {
  buildIndexAsync,
  indexSong,
  removeFromIndex,
  searchSongs,
  isIndexReady,
} from './worship-index.js';
import { cacheSong, warmCacheFromSongs, clearWorshipCache } from './worship-cache.js';
import { loadWorshipMeta, saveWorshipMeta } from './worship-meta.js';
import { dedupeImports } from './worship-import.js';
import { scheduleWorshipBackup, recoverWorshipLibraryIfNeeded } from './worship-backup.js';
import {
  seedDefaultHinarios,
  isSystemDefaultSong,
  getDefaultHinarioSnapshot,
  hasDefaultHinarioEdits,
  buildRestoredDefaultSong,
  invalidateDefaultHinariosCache,
  fetchDefaultHinariosBundle,
} from './default-hinarios.js';
import {
  installHinarioPack,
  installAllHinarioPacks,
  uninstallHinarioPack,
  fetchHinarioPackManifest,
  invalidateHinarioPackManifest,
  formatHinarioPackError,
} from './hinario-pack-service.js';
import {
  findBestDuplicate,
  findDuplicateSongs,
  clusterDuplicateSongs,
  mergeSongFields,
  pickRicherSong,
  songIdentityKey,
} from './song-identity.js';

let _songMap = new Map();
let _metaList = [];
let _indexPromise = null;
let _hinarioCategoryCounts = null;
let _userCategoryCounts = null;
let _bulkImportDepth = 0;

function isBulkImporting() {
  return _bulkImportDepth > 0;
}

export function beginWorshipBulkImport() {
  _bulkImportDepth += 1;
}

export function endWorshipBulkImport() {
  _bulkImportDepth = Math.max(0, _bulkImportDepth - 1);
}

function applyLiteMetaList(fullSongs) {
  _metaList = fullSongs.map((s) => songMetaLite(normalizeSong(s)));
  _songMap = new Map(_metaList.map((s) => [s.id, s]));
}

function yieldToMain(ms = 0) {
  return new Promise((resolve) => {
    if (ms > 0) {
      setTimeout(resolve, ms);
      return;
    }
    if (typeof requestIdleCallback === 'function') {
      requestIdleCallback(() => resolve(), { timeout: 48 });
    } else {
      setTimeout(resolve, 16);
    }
  });
}

function rebuildCategoryCounts() {
  const hinario = new Map();
  const user = new Map();
  for (const s of _metaList) {
    const cat = String(s.category || '').trim() || '(sem categoria)';
    const bucket = isSystemDefaultSong(s) ? hinario : user;
    bucket.set(cat, (bucket.get(cat) || 0) + 1);
  }
  _hinarioCategoryCounts = hinario;
  _userCategoryCounts = user;
}

export function getHinarioCategoryCounts() {
  if (!_hinarioCategoryCounts) rebuildCategoryCounts();
  return _hinarioCategoryCounts;
}

export function getUserCategoryCounts() {
  if (!_userCategoryCounts) rebuildCategoryCounts();
  return _userCategoryCounts;
}

export async function initWorshipLibrary() {
  const meta = await loadWorshipMeta();
  let songs = (await getAllSongs()).map((s) => normalizeSong(s));

  const recovery = await recoverWorshipLibraryIfNeeded(songs);
  if (recovery.recovered) {
    for (const song of recovery.songs) {
      await storeSaveSong(song);
    }
    songs = recovery.songs;
    if (recovery.worshipMeta) {
      await saveWorshipMeta(recovery.worshipMeta);
    }
  }

  // Hinários: instalação opcional via pacotes ZIP (painel) — sem auto-seed na abertura.
  const hasInstalledPacks = meta?.hinarioPacks && Object.keys(meta.hinarioPacks).length > 0;
  const hasDefaults = songs.some(isSystemDefaultSong);

  const fullSongs = songs.map((s) => normalizeSong(s));
  if (!_indexPromise) {
    _indexPromise = buildIndexAsync(fullSongs);
  }
  applyLiteMetaList(fullSongs);
  rebuildCategoryCounts();
  warmCacheFromSongs(_metaList);
  if (hasDefaults || hasInstalledPacks) {
    void fetchDefaultHinariosBundle().catch(() => {});
  }
  scheduleWorshipBackup(_metaList, meta);
  return {
    count: _metaList.length,
    indexReady: isIndexReady(),
    recovered: recovery.recovered,
    hinariosSeeded: 0,
    hinarioPacksInstalled: hasInstalledPacks ? Object.keys(meta.hinarioPacks).length : 0,
  };
}

export function getWorshipSongMap() {
  return _songMap;
}

export async function refreshWorshipLibrary() {
  clearWorshipCache();
  _indexPromise = null;
  return initWorshipLibrary();
}

export async function listWorshipSongsMeta() {
  return _metaList.map((s) => ({
    id: s.id,
    title: s.title,
    subtitle: s.subtitle,
    artist: s.artist,
    category: s.category,
    key: s.key,
    favorite: s.favorite,
    useCount: s.useCount,
    lastUsedAt: s.lastUsedAt,
    createdAt: s.createdAt,
    tags: s.tags,
  }));
}

export async function getWorshipSong(id) {
  const cached = _songMap.get(id);
  if (cached && 'lyrics' in cached) return cached;
  const full = await getSong(id);
  if (!full) return null;
  const norm = normalizeSong(full);
  cacheSong(norm);
  return norm;
}

/** Lista completa em memória (meta + campos já carregados). */
export function listWorshipSongs() {
  return [..._metaList];
}

/**
 * Busca duplicatas de um candidato na biblioteca.
 * @returns {Array<{ song: object, score: number }>}
 */
export function findWorshipDuplicates(candidate, { excludeId = null, minScore = 0.72 } = {}) {
  return findDuplicateSongs(candidate, _metaList, { excludeId, minScore });
}

/**
 * @param {object} raw
 * @param {{ allowDuplicate?: boolean, mergeIntoId?: string }} [opts]
 * @returns {Promise<{ song: object, action: 'created'|'updated'|'merged'|'duplicate', duplicate?: object }>}
 */
export async function saveWorshipSong(raw, opts = {}) {
  const { allowDuplicate = false, mergeIntoId = null } = opts;
  let song = normalizeSong(raw);

  if (mergeIntoId) {
    const existing = await getWorshipSong(mergeIntoId);
    if (!existing) throw new Error('merge_target_missing');
    const merged = normalizeSong(mergeSongFields(existing, song));
    merged.id = existing.id;
    const saved = await _persistSong(merged);
    return { song: saved, action: 'merged', duplicate: existing };
  }

  const isUpdate = !!(song.id && _songMap.has(song.id));
  if (!allowDuplicate) {
    const hit = findBestDuplicate(song, _metaList, { excludeId: song.id || null });
    if (hit) {
      // Nova música OU edição que colide com outra ficha
      if (!isUpdate || hit.song.id !== song.id) {
        return {
          song: normalizeSong(hit.song),
          action: 'duplicate',
          duplicate: hit.song,
          score: hit.score,
        };
      }
    }
  }

  if (!song.id) song.id = generateId();
  const saved = await _persistSong(song);
  return {
    song: saved,
    action: isUpdate ? 'updated' : 'created',
  };
}

/** Persistência direta (uso interno / quando o caller já resolveu duplicata). */
export async function forceSaveWorshipSong(raw) {
  const song = normalizeSong(raw);
  if (!song.id) song.id = generateId();
  return _persistSong(song);
}

async function _persistSong(song) {
  const saved = normalizeSong(await storeSaveSong(song));
  indexSong(saved);
  const lite = songMetaLite(saved);
  _songMap.set(lite.id, lite);
  const metaIdx = _metaList.findIndex((s) => s.id === saved.id);
  if (metaIdx >= 0) _metaList[metaIdx] = lite;
  else _metaList.push(lite);
  if (!isBulkImporting()) {
    _metaList.sort((a, b) => (a.title || '').localeCompare(b.title || '', 'pt-BR'));
    rebuildCategoryCounts();
    const worshipMeta = await loadWorshipMeta();
    scheduleWorshipBackup(_metaList, worshipMeta);
  }
  cacheSong(saved);
  return saved;
}

export async function deleteWorshipSong(id) {
  const existing = _songMap.get(id) || await getSong(id);
  if (existing?.protected || existing?.systemDefault) {
    throw new Error('protected_song');
  }
  await storeDeleteSong(id);
  _songMap.delete(id);
  _metaList = _metaList.filter((s) => s.id !== id);
  rebuildCategoryCounts();
  removeFromIndex(id);
}

/**
 * Mescla `donorId` em `keepId` e apaga a cópia doadora.
 * Atualiza itens do programa que apontavam para o donor (se app informado).
 */
export async function mergeWorshipSongs(keepId, donorId, { app } = {}) {
  if (!keepId || !donorId || keepId === donorId) return null;
  const keep = await getWorshipSong(keepId);
  const donor = await getWorshipSong(donorId);
  if (!keep || !donor) return null;
  if (donor.protected || donor.systemDefault || keep.protected || keep.systemDefault) {
    return keep;
  }
  const merged = normalizeSong(mergeSongFields(keep, donor));
  merged.id = keepId;
  const saved = await _persistSong(merged);
  try {
    await deleteWorshipSong(donorId);
  } catch (err) {
    if (err?.message !== 'protected_song') throw err;
  }

  if (app?.program?.items) {
    let changed = false;
    for (const item of app.program.items) {
      if (item.slideType === 'lyrics' && item.songId === donorId) {
        item.songId = keepId;
        if (!item.title || item.title === donor.title) item.title = saved.title;
        changed = true;
      }
    }
    if (changed) {
      app.program?.clearSongCache?.();
      await app.persistProgram?.();
      app.markProgramDirty?.();
    }
  }
  return saved;
}

/**
 * Detecta e mescla automaticamente clusters de duplicatas.
 * @returns {{ merged: number, removed: string[], kept: string[] }}
 */
export async function cleanupWorshipDuplicates({ app, dryRun = false } = {}) {
  const userSongs = _metaList.filter((s) => !isSystemDefaultSong(s));
  const clusters = clusterDuplicateSongs(userSongs);
  const removed = [];
  const kept = [];
  if (dryRun) {
    return {
      merged: clusters.reduce((n, c) => n + c.duplicates.length, 0),
      removed: clusters.flatMap((c) => c.duplicates.map((d) => d.id)),
      kept: clusters.map((c) => c.keep.id),
      clusters,
    };
  }
  for (const cluster of clusters) {
    let keep = cluster.keep;
    for (const dup of cluster.duplicates) {
      keep = await mergeWorshipSongs(keep.id, dup.id, { app }) || keep;
      removed.push(dup.id);
    }
    kept.push(keep.id);
  }
  return { merged: removed.length, removed, kept };
}

export async function duplicateWorshipSong(id) {
  const src = await getWorshipSong(id);
  if (!src) return null;
  const copy = normalizeSong({
    ...structuredClone(src),
    id: generateId(),
    title: `${src.title} (cópia)`,
    useCount: 0,
    lastUsedAt: null,
    favorite: false,
    createdAt: Date.now(),
    updatedAt: Date.now(),
  });
  // Cópia explícita do usuário — permite mesmo título base
  return forceSaveWorshipSong(copy);
}

export async function recordSongUsage(id) {
  const song = await getWorshipSong(id);
  if (!song) return null;
  song.useCount = (song.useCount || 0) + 1;
  song.lastUsedAt = Date.now();
  return forceSaveWorshipSong(song);
}

export async function toggleFavorite(id) {
  const song = await getWorshipSong(id);
  if (!song) return null;
  song.favorite = !song.favorite;
  return forceSaveWorshipSong(song);
}

export function searchWorship(query, filters = {}) {
  return searchSongs(query, filters, _songMap);
}

export async function importWorshipSongs(incoming) {
  const list = Array.isArray(incoming) ? incoming : [];
  if (list.length > 8) {
    return importWorshipSongsBulk(list);
  }
  const existing = [..._metaList];
  const unique = dedupeImports(existing, list.map(normalizeSong));
  const saved = [];
  for (const s of unique) {
    const result = await saveWorshipSong(s, { allowDuplicate: true });
    if (result.action === 'duplicate') continue;
    saved.push(result.song);
  }
  return saved;
}

/**
 * Importação em massa — saveMany por lote, índice incremental, UI não trava.
 * @param {object[]} incoming
 * @param {{ batchSize?: number, onProgress?: Function }} opts
 */
export async function importWorshipSongsBulk(incoming, { batchSize = 40, onProgress } = {}) {
  const list = (incoming || []).map(normalizeSong);
  if (!list.length) return [];

  beginWorshipBulkImport();
  const seen = new Set(_metaList.map((s) => songIdentityKey(s)));
  const toSave = [];
  for (const s of list) {
    const k = songIdentityKey(s);
    if (seen.has(k)) continue;
    seen.add(k);
    toSave.push(s);
  }
  if (!toSave.length) {
    endWorshipBulkImport();
    return [];
  }

  const saved = [];
  try {
    const { DatabaseEngine } = await import('../core/database/database-engine.js');
    for (let i = 0; i < toSave.length; i += batchSize) {
      const batch = toSave.slice(i, i + batchSize);
      const persisted = await DatabaseEngine.songs.saveMany(batch);
      for (const row of persisted) {
        const norm = normalizeSong(row);
        indexSong(norm);
        const lite = songMetaLite(norm);
        _songMap.set(lite.id, lite);
        _metaList.push(lite);
        cacheSong(norm);
        saved.push(norm);
      }
      onProgress?.({
        phase: 'save',
        current: Math.min(i + batchSize, toSave.length),
        total: toSave.length,
        saved: saved.length,
        label: `Salvando ${Math.min(i + batchSize, toSave.length)}/${toSave.length}…`,
        percent: Math.round((Math.min(i + batchSize, toSave.length) / toSave.length) * 100),
      });
      await yieldToMain(12);
    }
    _metaList.sort((a, b) => (a.title || '').localeCompare(b.title || '', 'pt-BR'));
    rebuildCategoryCounts();
    const worshipMeta = await loadWorshipMeta();
    scheduleWorshipBackup(_metaList, worshipMeta);
  } finally {
    endWorshipBulkImport();
  }
  return saved;
}

function packInstallDeps() {
  return {
    saveManySongs: async (batch) => {
      const { DatabaseEngine } = await import('../core/database/database-engine.js');
      return DatabaseEngine.songs.saveMany(batch.map(normalizeSong));
    },
    deleteManySongs: async (ids) => {
      const { DatabaseEngine } = await import('../core/database/database-engine.js');
      return DatabaseEngine.songs.deleteMany(ids);
    },
    loadMeta: loadWorshipMeta,
    saveMeta: saveWorshipMeta,
    getExistingSongs: async () => (await getAllSongs()).map((s) => normalizeSong(s)),
  };
}

async function refreshAfterHinarioPackChange() {
  clearWorshipCache();
  const full = (await getAllSongs()).map((s) => normalizeSong(s));
  _indexPromise = buildIndexAsync(full);
  applyLiteMetaList(full);
  rebuildCategoryCounts();
  warmCacheFromSongs(_metaList);
  await _indexPromise;
}

export async function installHinarioPackById(packId, { onProgress } = {}) {
  try {
    const result = await installHinarioPack(packId, { ...packInstallDeps(), onProgress });
    if (result.added > 0 || result.alreadyInstalled) {
      await refreshAfterHinarioPackChange();
    }
    return result;
  } catch (err) {
    throw new Error(formatHinarioPackError(err));
  }
}

export async function uninstallHinarioPackById(packId, { onProgress } = {}) {
  try {
    const result = await uninstallHinarioPack(packId, { ...packInstallDeps(), onProgress });
    if (result.removed > 0 || result.notInstalled || result.empty) {
      await refreshAfterHinarioPackChange();
    }
    return result;
  } catch (err) {
    throw new Error(formatHinarioPackError(err));
  }
}

export async function ensureDefaultHinariosSeeded({ force = false } = {}) {
  if (force) {
    invalidateDefaultHinariosCache();
    invalidateHinarioPackManifest();
  }

  try {
    const manifest = await fetchHinarioPackManifest({ force });
    if (manifest.packs.length) {
      const all = await installAllHinarioPacks(packInstallDeps());
      if (all.added > 0) {
        const full = (await getAllSongs()).map((s) => normalizeSong(s));
        _indexPromise = buildIndexAsync(full);
        applyLiteMetaList(full);
        rebuildCategoryCounts();
        warmCacheFromSongs(_metaList);
        await _indexPromise;
      }
      return { added: all.added, skipped: 0, total: _metaList.length, via: 'packs', errors: all.errors };
    }
  } catch {
    /* fallback monolito dev */
  }

  const songs = (await getAllSongs()).map((s) => normalizeSong(s));
  const seedResult = await seedDefaultHinarios(songs, {
    ...packInstallDeps(),
    force,
  });
  if (seedResult.added > 0) {
    const full = (await getAllSongs()).map((s) => normalizeSong(s));
    _indexPromise = buildIndexAsync(full);
    applyLiteMetaList(full);
    rebuildCategoryCounts();
    warmCacheFromSongs(_metaList);
    await _indexPromise;
    void fetchDefaultHinariosBundle().catch(() => {});
  }
  return { ...seedResult, via: 'monolith' };
}

export async function restoreSystemDefaultSong(id) {
  const current = await getWorshipSong(id);
  if (!current || !isSystemDefaultSong(current)) {
    throw new Error('not_system_default');
  }
  const snapshot = await getDefaultHinarioSnapshot(id);
  if (!snapshot) throw new Error('default_snapshot_missing');
  const restored = buildRestoredDefaultSong(current, snapshot);
  return forceSaveWorshipSong(restored);
}

export { hasDefaultHinarioEdits, isSystemDefaultSong, getDefaultHinarioSnapshot };

export async function waitForIndex() {
  if (_indexPromise) await _indexPromise;
  return isIndexReady();
}

export function getWorshipStats() {
  const total = _metaList.length;
  const userTotal = _metaList.filter((s) => !isSystemDefaultSong(s)).length;
  const hinarioTotal = total - userTotal;
  const favorites = _metaList.filter((s) => s.favorite).length;
  const neverUsed = _metaList.filter((s) => !(s.useCount > 0)).length;
  const recent = _metaList
    .filter((s) => s.lastUsedAt)
    .sort((a, b) => b.lastUsedAt - a.lastUsedAt)
    .slice(0, 10);
  const mostUsed = [..._metaList]
    .sort((a, b) => (b.useCount || 0) - (a.useCount || 0))
    .slice(0, 10);
  const recentlyAdded = [..._metaList]
    .sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0))
    .slice(0, 10);
  return { total, userTotal, hinarioTotal, favorites, neverUsed, recent, mostUsed, recentlyAdded };
}
