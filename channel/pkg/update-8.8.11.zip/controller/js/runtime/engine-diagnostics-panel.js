/**
 * Engine Diagnostics Panel — suporte técnico; polling lento, só quando visível.
 */

const POLL_MS = 5000;
let mounted = false;
let pollTimer = null;
let hostEl = null;
let disposers = [];
let pollReady = false;

function fmtTime(ts) {
  if (!ts) return '—';
  try {
    return new Date(ts).toLocaleTimeString('pt-BR');
  } catch {
    return String(ts);
  }
}

function statusClass(state) {
  if (state === 'connected') return 'is-ok';
  if (state === 'degraded' || state === 'reconnecting') return 'is-warn';
  return 'is-fail';
}

function fetchOpsDashboard() {
  try {
    const raw = window.Engine?.runtime?.getStateJson?.('performance');
    if (!raw) return null;
    const parsed = typeof raw === 'string' ? JSON.parse(raw) : raw;
    return parsed?.performance?.ops || null;
  } catch {
    return null;
  }
}

function metric(ops, name) {
  const m = ops?.telemetry?.[name];
  if (!m) return '—';
  const breach = m.breaches > 0 ? ` (${m.breaches} alertas)` : '';
  return `${m.avg}${m.unit ? ` ${m.unit}` : ''} méd / ${m.max} máx${breach}`;
}

function renderOpsSection(ops) {
  if (!ops) return '';
  const stab = ops.stability || {};
  const gov = ops.governor || {};
  const cache = ops.cache || {};
  return `
      <header class="ecm-diag-header">
        <h3>Operações do Engine</h3>
        <span class="ecm-diag-badge ${ops.productionMode ? 'is-ok' : 'is-warn'}">${ops.productionMode ? 'produção' : 'dev'}</span>
      </header>
      <dl class="ecm-diag-grid">
        <dt>Perfil adaptativo</dt><dd>${gov.profile || '—'} (${gov.adaptations ?? 0} adaptações)</dd>
        <dt>CPU do processo</dt><dd>${metric(ops, 'cpu.processPercent')}</dd>
        <dt>GPU</dt><dd>${metric(ops, 'gpu.usagePercent')} · ${ops.resources?.gpuTier || '—'}</dd>
        <dt>RAM em uso</dt><dd>${metric(ops, 'memory.workingSetMb')}</dd>
        <dt>Tempo de quadro</dt><dd>${metric(ops, 'frame.timeMs')}</dd>
        <dt>Troca de slide</dt><dd>${metric(ops, 'projection.slideChangeMs')}</dd>
        <dt>Fila de comandos</dt><dd>${metric(ops, 'commands.queueDepth')}</dd>
        <dt>Cache</dt><dd>${cache.usedMb ?? 0} / ${cache.budgetMb ?? 0} MB (${cache.entries ?? 0} itens)</dd>
        <dt>Disponibilidade</dt><dd>${stab.availabilityPercent ?? '—'}%</dd>
        <dt>Tempo ativo</dt><dd>${stab.uptimeHours ?? 0} h (12h: ${stab.progressPercent ?? 0}%)</dd>
        <dt>Sessão longa</dt><dd>${stab.sessionValid ? 'válida' : 'em análise'} (${stab.memoryGrowthMbPerHour ?? 0} MB/h)</dd>
        <dt>Violações de orçamento</dt><dd>${stab.budgetBreaches ?? 0}</dd>
        <dt>Recuperações de falha</dt><dd>${stab.crashRecoveries ?? 0}</dd>
      </dl>`;
}

function renderPanel(diag) {
  if (!hostEl) return;
  const s = diag || {};
  const ops = fetchOpsDashboard();
  hostEl.innerHTML = `
    <section class="ecm-diag-panel" aria-label="Diagnóstico do Engine">
      <header class="ecm-diag-header">
        <h3>Conectividade do Engine</h3>
        <span class="ecm-diag-badge ${statusClass(s.state)}">${s.state || '—'}</span>
      </header>
      <dl class="ecm-diag-grid">
        <dt>Ambiente</dt><dd>${s.environment || '—'}</dd>
        <dt>Bridge</dt><dd>${s.bridgeState || '—'}</dd>
        <dt>Protocolo</dt><dd>${s.negotiatedProtocolVersion || s.protocolVersion || window.Engine?.PROTOCOL_VERSION || '—'}</dd>
        <dt>Resposta</dt><dd>${s.bridge?.responseMs != null ? `${s.bridge.responseMs} ms` : '—'}</dd>
        <dt>Último handshake</dt><dd>${fmtTime(s.lastHandshakeAt)}</dd>
        <dt>Última sync</dt><dd>${fmtTime(s.lastSyncAt)}</dd>
        <dt>Engine runtime</dt><dd>${s.engine?.available ? 'OK' : '—'}</dd>
        <dt>Shell nativo</dt><dd>${s.bridge?.shell ? 'OK' : 'Indisponível'}</dd>
        <dt>Projeção</dt><dd>${s.projection?.open ? `Aberta (mon. ${(s.projection.displayIndex ?? 0) + 1})` : 'Fechada'}</dd>
        <dt>Monitores</dt><dd>${s.monitors?.count ?? 0}</dd>
        <dt>Display Manager</dt><dd>${s.displayManager?.hasSnapshot ? 'Snapshot OK' : 'Sem snapshot'}</dd>
        <dt>Projection Module</dt><dd>${s.projectionModule?.state?.open ? 'Ativo' : 'Inativo'}</dd>
        <dt>Runtime Scheduler</dt><dd>${s.runtimeScheduler?.mode || '—'}</dd>
      </dl>
      ${renderOpsSection(ops)}
      <p class="ecm-diag-hint">${s.userMessage || 'Painel de suporte — não afeta performance em produção.'}</p>
    </section>`;
}

function refresh() {
  try {
    const engine = window.Engine;
    if (!engine) {
      renderPanel({ state: 'disconnected', userMessage: 'window.Engine não instalado.' });
      return;
    }
    renderPanel(engine.getDiagnostics());
  } catch (err) {
    console.warn('[ECM panel] refresh failed', err);
    renderPanel({
      state: 'degraded',
      userMessage: 'Shell indisponível — abra pelo SOMOSUM.exe na bandeja.',
      bridge: { shell: false },
    });
  }
}

function startPoll() {
  stopPoll();
  if (!pollReady || document.visibilityState !== 'visible') return;
  pollTimer = setInterval(() => {
    refresh();
  }, POLL_MS);
}

function stopPoll() {
  if (pollTimer) {
    clearInterval(pollTimer);
    pollTimer = null;
  }
}

function markPollReady() {
  pollReady = true;
  refresh();
  startPoll();
}

export function mountEngineDiagnosticsPanel(container) {
  if (!container || mounted) return;
  mounted = true;
  hostEl = document.createElement('div');
  hostEl.className = 'ecm-diag-host';
  container.appendChild(hostEl);

  renderPanel({
    state: 'connecting',
    userMessage: 'Aguardando conexão com o motor SOMOSUM…',
  });

  const engine = window.Engine;
  if (engine?.getState?.() === 'connected' || engine?.shell?.isAvailable?.()) {
    markPollReady();
  } else {
    const onReady = () => markPollReady();
    const onNativeReady = () => markPollReady();
    disposers = [
      engine?.on?.('connected', onReady),
      engine?.on?.('bridge-lost', refresh),
      engine?.on?.('resynced', refresh),
    ].filter((dispose) => typeof dispose === 'function');
    document.addEventListener('somosum-native-ready', onNativeReady, { once: true });
    disposers.push(() => document.removeEventListener('somosum-native-ready', onNativeReady));
    setTimeout(() => {
      if (!pollReady) markPollReady();
    }, 2500);
  }

  const onVisibilityChanged = () => {
    if (document.visibilityState === 'visible') {
      refresh();
      startPoll();
    } else {
      stopPoll();
    }
  };
  document.addEventListener('visibilitychange', onVisibilityChanged);
  disposers.push(() => document.removeEventListener('visibilitychange', onVisibilityChanged));
}

export function unmountEngineDiagnosticsPanel() {
  stopPoll();
  disposers.forEach((dispose) => dispose());
  disposers = [];
  hostEl?.remove();
  mounted = false;
  hostEl = null;
  pollReady = false;
}
