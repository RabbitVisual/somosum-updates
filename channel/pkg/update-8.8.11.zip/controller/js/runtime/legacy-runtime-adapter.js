/**
 * Legacy runtime adapter — traduz Commands/Events do Runtime para
 * ProjectionBus / TaskScheduler durante a migração. Sem import de runtime-client.
 */

import { TaskScheduler } from '../core/task-scheduler.js';

const DEDUP_WINDOW_MS = 2000;
const processedCorrelationIds = new Map();

/** Mapeamento SyncMessageTypes → Eventos do Runtime. */
const MESSAGE_TO_EVENT = {
  slide: 'SlideChangedEvent',
  overlay: 'OverlayChangedEvent',
  overlay_layer: 'OverlayChangedEvent',
  settings: 'PrefsChangedEvent',
  assets: 'AssetsChangedEvent',
  ambient: 'AmbientChangedEvent',
  countdown: 'CountdownTickEvent',
  heartbeat: 'SyncStateEvent',
  request_state: 'SyncStateEvent',
  full_state: 'SyncStateEvent',
  stage_state: 'StageStateEvent',
  stage_note: 'StageStateEvent',
  stage_alert: 'StageStateEvent',
  remote_cmd: 'RemoteStateEvent',
  slide_ack: 'AckReceivedEvent',
};

const EVENT_PRIORITY = {
  SlideChangedEvent: 'Critical',
  OverlayChangedEvent: 'Critical',
  AckReceivedEvent: 'High',
  SyncStateEvent: 'High',
  CountdownTickEvent: 'High',
  RecoveryTriggeredEvent: 'High',
  StageStateEvent: 'Normal',
  RemoteStateEvent: 'Normal',
  ProgramChangedEvent: 'Normal',
  PrefsChangedEvent: 'Normal',
  AssetsChangedEvent: 'Normal',
  AmbientChangedEvent: 'Normal',
  HealthStatusEvent: 'Low',
  DisplayChangedEvent: 'Low',
  ClientPresenceEvent: 'Low',
  DiagnosticsTickEvent: 'Idle',
  PerfSnapshotEvent: 'Idle',
  LogBatchEvent: 'Idle',
  BackupProgressEvent: 'Idle',
};

const SCHEDULER_MODE_MAP = {
  active: 'Active',
  background: 'Background',
  hidden: 'Hidden',
  live: 'Live',
};

let sequence = 0;

function touchCorrelation(correlationId) {
  if (!correlationId) return false;
  const now = Date.now();
  for (const [key, ts] of processedCorrelationIds) {
    if (now - ts > DEDUP_WINDOW_MS) processedCorrelationIds.delete(key);
  }
  if (processedCorrelationIds.has(correlationId)) return true;
  processedCorrelationIds.set(correlationId, now);
  return false;
}

function nextSequence() {
  sequence += 1;
  return sequence;
}

/**
 * Decide if JS should use the legacy command path.
 * When legacyFallback === false and engine is enabled, never fall back to legacy
 * even if the COM bridge is briefly unavailable — HTTP SyncHub/ProjectionBus
 * remains the transport between WebView2 profiles.
 */
export function shouldUseLegacy(config, bridgeAvailable) {
  if (!config?.enabled) return true;
  if (config.legacyFallback === false) return false;
  if (config.bridgePreferred && bridgeAvailable) return false;
  return true;
}

export function busMessageToRuntimeEvent(message) {
  if (!message?.type) return null;
  const type = MESSAGE_TO_EVENT[message.type] || 'SyncStateEvent';
  return {
    id: message.id,
    type,
    payload: {
      messageType: message.type,
      payload: message.payload ?? {},
      from: message.from,
      ts: message.ts,
    },
    priority: EVENT_PRIORITY[type] || 'Normal',
    timestampUtc: new Date(message.ts || Date.now()).toISOString(),
    correlationId: message.id,
    sequence: nextSequence(),
  };
}

export function runtimeEventToBusMessage(event) {
  if (!event?.payload?.messageType) return null;
  return {
    id: event.correlationId || event.id,
    type: event.payload.messageType,
    payload: event.payload.payload ?? {},
    ts: event.payload.ts || Date.now(),
    from: event.payload.from || 'runtime',
    _runtimeMirror: true,
  };
}

export function executeLegacyCommand(command) {
  const type = command?.type;
  const payload = command?.payload ?? {};

  switch (type) {
    case 'PingCommand':
      return { ok: true, legacy: true, pong: true };

    case 'GetStateCommand':
      return {
        ok: true,
        legacy: true,
        domain: payload.domain || command.domain || 'projection',
        state: null,
      };

    case 'PushSyncCommand':
      return {
        ok: true,
        legacy: true,
        delegated: true,
        note: 'ProjectionBus.send owns sync relay during migration',
      };

    case 'RegisterTaskCommand':
      return {
        ok: true,
        legacy: true,
        registered: payload.id,
        note: 'TaskScheduler retains JS callback execution',
      };

    case 'SetSchedulerModeCommand':
    case 'SetModeCommand': {
      const mode = payload.mode || command.mode || 'active';
      TaskScheduler.setMode(mode);
      return { ok: true, legacy: true, mode };
    }

    case 'ShutdownCommand':
      return { ok: true, legacy: true, shutdown: true };

    case 'RenderIntentCommand':
      return { ok: true, legacy: true, intent: payload };

    default:
      return { ok: true, legacy: true, noop: true, type };
  }
}

export function mapSchedulerMode(mode) {
  return SCHEDULER_MODE_MAP[mode] || 'Active';
}

export function isDuplicateCorrelation(correlationId) {
  return touchCorrelation(correlationId);
}

export function buildPushSyncCommand(message, source = 'control') {
  return {
    type: 'PushSyncCommand',
    payload: { message },
    source,
    priority: 'High',
    correlationId: message?.id,
  };
}
