/** Boot ECM antes de qualquer módulo que use window.Engine */
import { installEngineFacade } from './engine-facade.js';

export const engineReady = installEngineFacade().then((engine) => {
  try {
    engine?.resources?.start?.();
  } catch { /* optional */ }
  return engine;
});
