/**
 * SOMOSUM Runtime Client — única porta de entrada JS para Somosum.Runtime.dll.
 * API: execute, getState, subscribe, unsubscribe, setMode, shutdown.
 */

import { randomId } from '../core/uuid.js';
import { getPrefs } from '../core/store.js';
import { TaskScheduler } from '../core/task-scheduler.js';
import { TaskIds } from '../core/task-registry.js';
import { registerDisposable } from '../core/disposable-registry.js';
import {
  shouldUseLegacy,
  executeLegacyCommand,
  mapSchedulerMode,
  isDuplicateCorrelation,
  busMessageToRuntimeEvent,
} from './legacy-runtime-adapter.js';
import { getEngineConnectivity } from './engine-connectivity-manager.js';

const DEFAULT_RUNTIME_CONFIG = {
  enabled: false,
  bridgePreferred: true,
  legacyFallback: false,
  authoritativeSync: true,
  authoritativeRecovery: true,
};

const COALESCE_PRIORITIES = new Set(['Normal', 'Low', 'Idle']);
const subscriptions = new Map();
const coalescedEvents = new Map();
const stateCache = new Map();
const commandDedup = new Map();

let nextToken = 1;
let bridgeAvailable = null;
let bridgeChecked = false;
let pollRegistered = false;
let webMessageBound = false;
let lastEventSequence = 0;
let shuttingDown = false;
let initialized = false;

function getConfig() {
  const prefs = getPrefs();
  return { ...DEFAULT_RUNTIME_CONFIG, ...(prefs.runtimeEngine || {}) };
}

function detectSurface() {
  if (typeof window === 'undefined') return 'unknown';
  if (window.SOMOSUM_SURFACE) return window.SOMOSUM_SURFACE;
  const path = (window.location?.pathname || '').toLowerCase();
  if (path.includes('control')) return 'control';
  if (path.includes('screen')) return 'screen';
  if (path.includes('stage')) return 'stage';
  if (path.includes('remote')) return 'remote';
  if (path.includes('panel')) return 'panel';
  if (path.includes('diagnostics')) return 'diagnostics';
  return 'unknown';
}

function getEngineRuntime() {
  return typeof window !== 'undefined' ? window.Engine?.runtime : null;
}

function probeBridge() {
  if (bridgeChecked) return bridgeAvailable;
  bridgeChecked = true;
  bridgeAvailable = !!getEngineRuntime()?.isAvailable?.();
  return bridgeAvailable;
}

function callBridge(method, ...args) {
  const runtime = getEngineRuntime();
  if (!runtime) return null;
  const aliases = {
    ExecuteJson: 'executeJson',
    pollEventsJson: 'getEventsJson',
    PollEventsJson: 'getEventsJson',
    GetStateJson: 'getStateJson',
    SetMode: 'setMode',
    Shutdown: 'shutdown',
    RegisterTaskJson: 'registerTaskJson',
    UnregisterTask: 'unregisterTask',
  };
  const fn = runtime[aliases[method] || method];
  if (typeof fn !== 'function') return null;
  try {
    return fn.apply(runtime, args);
  } catch {
    return null;
  }
}

function normalizeEnvelope(input = {}, defaults = {}) {
  const id = input.id || randomId();
  return {
    id,
    type: input.type,
    payload: input.payload ?? {},
    source: input.source || detectSurface(),
    priority: input.priority || defaults.priority || 'Normal',
    timestampUtc: input.timestampUtc || new Date().toISOString(),
    correlationId: input.correlationId || id,
  };
}

function touchCommandDedup(correlationId) {
  if (!correlationId) return false;
  const now = Date.now();
  for (const [key, ts] of commandDedup) {
    if (now - ts > 2000) commandDedup.delete(key);
  }
  if (commandDedup.has(correlationId)) return true;
  commandDedup.set(correlationId, now);
  return false;
}

function parseJsonSafe(value) {
  if (value == null) return null;
  if (typeof value === 'object') return value;
  try {
    return JSON.parse(value);
  } catch {
    return null;
  }
}

function dispatchEvent(event) {
  if (!event?.type) return;
  if (event.sequence != null && event.sequence <= lastEventSequence) return;
  if (event.sequence != null) lastEventSequence = event.sequence;
  if (isDuplicateCorrelation(event.correlationId || event.id)) return;

  const priority = event.priority || 'Normal';
  if (COALESCE_PRIORITIES.has(priority)) {
    coalescedEvents.set(event.type, event);
    return;
  }

  deliverEvent(event);
}

function deliverEvent(event) {
  for (const sub of subscriptions.values()) {
    if (sub.type !== event.type && sub.type !== '*') continue;
    try {
      sub.handler(event);
    } catch { /* ignore */ }
  }
}

function flushCoalescedEvents() {
  if (!coalescedEvents.size) return;
  const batch = [...coalescedEvents.values()];
  coalescedEvents.clear();
  for (const event of batch) deliverEvent(event);
}

function ingestRuntimePayload(payload) {
  const data = parseJsonSafe(payload);
  if (!data) return;
  if (Array.isArray(data.events)) {
    for (const event of data.events) dispatchEvent(event);
  } else if (data.type) {
    dispatchEvent(data);
  }
  if (data.state && typeof data.state === 'object') {
    for (const [domain, snapshot] of Object.entries(data.state)) {
      stateCache.set(domain, snapshot);
    }
  }
}

function pollEvents() {
  if (shuttingDown || !probeBridge()) return;
  const raw = callBridge('getEventsJson', lastEventSequence)
    ?? callBridge('pollEventsJson', lastEventSequence)
    ?? callBridge('PollEventsJson', lastEventSequence);
  if (raw != null) {
    const data = parseJsonSafe(raw);
    if (data?.latestSequence != null) lastEventSequence = Math.max(lastEventSequence, data.latestSequence);
    ingestRuntimePayload(raw);
  }
  flushCoalescedEvents();
}

function ensureEventPolling() {
  const cfg = getConfig();
  if (!cfg.enabled || !probeBridge() || pollRegistered) return;
  if (document.documentElement?.dataset?.productionMode === '1') return;
  pollRegistered = true;
  TaskScheduler.register({
    id: TaskIds.RUNTIME_EVENT_POLL,
    kind: 'interval',
    intervalMs: 250,
    priority: 1,
    coalesce: true,
    runWhenHidden: true,
    fn: pollEvents,
  });
}

function bindWebMessageChannel() {
  if (webMessageBound || typeof window === 'undefined') return;
  webMessageBound = true;
  const ecm = getEngineConnectivity();
  ecm.on('runtime-event', ({ payload }) => {
    const data = parseJsonSafe(payload);
    if (!data) return;
    if (data.type === 'engine-event' || data.channel === 'somosum-engine') {
      ingestRuntimePayload(data.payload ?? data);
      return;
    }
    if (data.channel !== 'somosum-runtime') return;
    if (data.event) dispatchEvent(data.event);
    if (data.events) {
      for (const event of data.events) dispatchEvent(event);
    }
    if (data.state) ingestRuntimePayload({ state: data.state });
  });
}

function stopEventPolling() {
  if (!pollRegistered) return;
  pollRegistered = false;
  TaskScheduler.unregister(TaskIds.RUNTIME_EVENT_POLL);
}

function initRuntimeClient() {
  if (initialized || typeof window === 'undefined') return;
  initialized = true;

  window.__SOMOSUM_RUNTIME__ = Runtime;
  bindWebMessageChannel();
  ensureEventPolling();

  const offConnected = window.Engine?.on?.('connected', () => {
    bridgeChecked = false;
    bridgeAvailable = null;
    ensureEventPolling();
  });
  const offLost = window.Engine?.on?.('bridge-lost', () => {
    bridgeChecked = false;
    bridgeAvailable = false;
    stopEventPolling();
  });

  registerDisposable(() => {
    offConnected?.();
    offLost?.();
    Runtime.shutdown({ reason: 'pagehide' });
  });

  window.addEventListener('pagehide', () => {
    Runtime.shutdown({ reason: 'pagehide' });
  }, { capture: true });
}

export const Runtime = {
  isEnabled() {
    return getConfig().enabled === true;
  },

  isBridgeAvailable() {
    if (!this.isEnabled()) return false;
    return probeBridge();
  },

  shouldUseLegacy() {
    return shouldUseLegacy(getConfig(), this.isBridgeAvailable());
  },

  execute(command = {}) {
    if (shuttingDown) {
      return { ok: false, error: 'runtime_shutting_down' };
    }

    const envelope = normalizeEnvelope(command);
    if (touchCommandDedup(envelope.correlationId)) {
      return { ok: true, deduped: true, correlationId: envelope.correlationId };
    }

    const cfg = getConfig();
    if (!cfg.enabled || shouldUseLegacy(cfg, this.isBridgeAvailable())) {
      return executeLegacyCommand(envelope);
    }

    const raw = callBridge('executeJson', JSON.stringify(envelope))
      ?? callBridge('ExecuteJson', JSON.stringify(envelope));
    const parsed = parseJsonSafe(raw);
    if (parsed) return parsed;

    if (cfg.legacyFallback !== false) {
      return executeLegacyCommand(envelope);
    }

    return { ok: false, error: 'bridge_unavailable' };
  },

  getState(domain = 'projection') {
    const cfg = getConfig();
    if (!cfg.enabled || shouldUseLegacy(cfg, this.isBridgeAvailable())) {
      return stateCache.get(domain) ?? null;
    }

    const raw = callBridge('getStateJson', domain)
      ?? callBridge('GetStateJson', domain);
    const parsed = parseJsonSafe(raw);
    if (parsed) {
      stateCache.set(domain, parsed);
      return parsed;
    }
    return stateCache.get(domain) ?? null;
  },

  subscribe(type, handler) {
    if (typeof handler !== 'function' || !type) return null;
    const token = nextToken++;
    subscriptions.set(token, { type, handler });
    ensureEventPolling();
    callBridge('subscribe', type);
    return token;
  },

  unsubscribe(token) {
    if (!subscriptions.has(token)) return false;
    const sub = subscriptions.get(token);
    subscriptions.delete(token);
    callBridge('unsubscribe', sub.type);
    return true;
  },

  setMode(mode = 'active') {
    TaskScheduler.setMode(mode);
    return { ok: true, mode };
  },

  /** Proxy do TaskScheduler — apenas bridge, sem tocar no loop local. */
  setBridgeMode(mode = 'active') {
    const cfg = getConfig();
    if (!cfg.enabled) return { ok: true, local: true, mode };
    const mapped = mapSchedulerMode(mode);
    if (this.isBridgeAvailable()) {
      callBridge('setMode', mapped) ?? callBridge('SetMode', mapped);
      return { ok: true, mode, mapped, bridge: true };
    }
    return { ok: true, mode, mapped, local: true };
  },

  shutdown({ reason = 'manual' } = {}) {
    if (shuttingDown) return { ok: true, already: true };
    shuttingDown = true;
    stopEventPolling();

    const envelope = normalizeEnvelope({
      type: 'ShutdownCommand',
      payload: { reason, surface: detectSurface() },
      priority: 'Critical',
    });

    const cfg = getConfig();
    if (cfg.enabled && this.isBridgeAvailable()) {
      const raw = callBridge('shutdown', JSON.stringify(envelope))
        ?? callBridge('Shutdown', JSON.stringify(envelope))
        ?? callBridge('executeJson', JSON.stringify(envelope));
      const parsed = parseJsonSafe(raw);
      if (parsed) return parsed;
    }

    return executeLegacyCommand(envelope);
  },

  /** Proxy de metadados para o Runtime Scheduler (callbacks permanecem no JS). */
  registerTaskMetadata(spec = {}) {
    if (!spec.id || !this.isEnabled() || !this.isBridgeAvailable()) return false;
    const payload = {
      id: spec.id,
      kind: spec.kind || 'interval',
      intervalMs: spec.intervalMs ?? 1000,
      priority: spec.priority ?? 5,
      runWhenHidden: spec.runWhenHidden === true,
      coalesce: spec.coalesce !== false,
    };
    const raw = callBridge('registerTaskJson', JSON.stringify(payload))
      ?? callBridge('RegisterTaskJson', JSON.stringify(payload));
    return raw != null || true;
  },

  unregisterTaskMetadata(id) {
    if (!id || !this.isBridgeAvailable()) return false;
    callBridge('unregisterTask', id) ?? callBridge('UnregisterTask', id);
    return true;
  },

  /** Usado pelo bus adapter para evitar loops de espelhamento. */
  mirrorBusMessage(message) {
    if (!this.isEnabled() || shuttingDown) return null;
    if (message?._runtimeMirror || message?._skipRuntimeMirror) return null;

    return this.execute({
      type: 'PushSyncCommand',
      payload: { message },
      source: message.from || detectSurface(),
      priority: 'High',
      correlationId: message.id,
    });
  },

  ingestBusMessage(message) {
    if (!message || message._runtimeMirror) return;
    const event = busMessageToRuntimeEvent(message);
    if (event) dispatchEvent(event);
  },

  getMetrics() {
    return {
      bridgeAvailable: this.isBridgeAvailable(),
      legacy: this.shouldUseLegacy(),
      subscriptions: subscriptions.size,
      coalescedPending: coalescedEvents.size,
      lastEventSequence,
      pollRegistered,
      shuttingDown,
    };
  },
};

initRuntimeClient();

export default Runtime;

if (typeof window !== 'undefined') {
  window.Runtime = Runtime;
}
