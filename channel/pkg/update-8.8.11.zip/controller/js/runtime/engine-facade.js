/**
 * Facade pública window.Engine — única API para telas e módulos JS.
 */
import {
  getEngineConnectivity,
  ENGINE_PROTOCOL_VERSION,
} from './engine-connectivity-manager.js';

let installPromise = null;
let installedEngine = null;

function shellApi(ecm) {
  return {
    isAvailable() {
      return ecm.isShellAvailable();
    },
    openProjection(displayIndex = -1) {
      ecm.setProjectionState({ open: true, displayIndex });
      return ecm.invokeShell('openScreenOnDisplay', displayIndex);
    },
    closeProjection() {
      ecm.setProjectionState({ open: false });
      return ecm.invokeShell('closeProjectionWindow');
    },
    openProjection2(displayIndex = -1) {
      return ecm.invokeShell('openScreen2OnDisplay', displayIndex);
    },
    closeProjection2() {
      return ecm.invokeShell('closeProjection2Window');
    },
    openControl() {
      return ecm.invokeShell('openControl');
    },
    openRemote() {
      return ecm.invokeShell('openRemoteWindow');
    },
    openStage(displayIndex = -1) {
      return ecm.invokeShell('openStage', displayIndex);
    },
    openManagementPanel(section = '') {
      if (section) {
        try {
          return ecm.invokeShell('openManagementPanelSection', String(section));
        } catch {
          /* fallback sem overload */
        }
      }
      return ecm.invokeShell('openManagementPanel');
    },
    openDiagnosticsPanel() {
      return ecm.invokeShell('openDiagnosticsPanel');
    },
    openDocsPanel(fragment = '') {
      return ecm.invokeShell('openDocsPanel', fragment || '');
    },
    restartServer() {
      return ecm.invokeShell('restartServer');
    },
    relaunchForUpdate() {
      return ecm.invokeShell('relaunchForUpdate');
    },
    getPort() {
      return ecm.invokeShell('getPort');
    },
    getDisplays() {
      return ecm.listDisplays();
    },
    getDisplaysJson() {
      return ecm.invokeShell('getDisplays');
    },
    getDisplaysDetailed() {
      return ecm.invokeShell('getDisplaysDetailed') ?? ecm.invokeShell('getDisplaySnapshot');
    },
    getDisplaySnapshot() {
      return ecm.invokeShell('getDisplaySnapshot') ?? ecm.invokeShell('getDisplaysDetailed');
    },
    setProjectorDisplay(index) {
      return ecm.invokeShell('setProjectorDisplay', index);
    },
    getProjectorDisplayIndex() {
      return ecm.invokeShell('getProjectorDisplayIndex');
    },
    setProjector2Display(index) {
      return ecm.invokeShell('setProjector2Display', index);
    },
    getProjector2DisplayIndex() {
      return ecm.invokeShell('getProjector2DisplayIndex');
    },
    closeStageWindow() {
      return ecm.invokeShell('closeStageWindow');
    },
    getStageDisplayIndex() {
      return ecm.invokeShell('getStageDisplayIndex');
    },
    setStageDisplay(index) {
      return ecm.invokeShell('setStageDisplay', index);
    },
    getStageFullscreen() {
      return ecm.invokeShell('getStageFullscreen');
    },
    setStageFullscreen(value) {
      return ecm.invokeShell('setStageFullscreen', value);
    },
    setStageOpenLayout(layout) {
      return ecm.invokeShell('setStageOpenLayout', layout || '');
    },
    setAutoOpenProjection(value) {
      return ecm.invokeShell('setAutoOpenProjection', value);
    },
    getAutoOpenProjection() {
      return ecm.invokeShell('getAutoOpenProjection');
    },
    setAutoOpenOnSecondDisplay(value) {
      return ecm.invokeShell('setAutoOpenOnSecondDisplay', value);
    },
    getAutoOpenOnSecondDisplay() {
      return ecm.invokeShell('getAutoOpenOnSecondDisplay');
    },
    setPreferNativeProjectorMode(value) {
      return ecm.invokeShell('setPreferNativeProjectorMode', value);
    },
    getPreferNativeProjectorMode() {
      return ecm.invokeShell('getPreferNativeProjectorMode');
    },
    applyProjectorNativeResolution(displayIndex = -1) {
      return ecm.invokeShell('applyProjectorNativeResolution', displayIndex);
    },
    getSystemDpi() {
      return ecm.invokeShell('getSystemDpi');
    },
    openFolder(relativePath) {
      return ecm.invokeShell('openFolder', relativePath);
    },
    registerHttpPorts() {
      return ecm.invokeShell('registerHttpPorts');
    },
    toggleProjectionFullscreen() {
      return ecm.invokeShell('toggleProjectionFullscreen');
    },
    shutdown() {
      return ecm.invokeShell('shutdown');
    },
    createDesktopShortcut() {
      return ecm.invokeShell('createDesktopShortcut');
    },
    isNativeShell() {
      const v = ecm.invokeShell('isNativeShell');
      return v === true || ecm.environment === 'webview2' || ecm.environment === 'engine';
    },
  };
}

function runtimeApi(ecm) {
  return {
    isAvailable() {
      return ecm.isRuntimeAvailable();
    },
    executeJson(commandJson) {
      return ecm.callRuntime('executeJson', commandJson);
    },
    getStateJson(scope) {
      return ecm.callRuntime('getStateJson', scope);
    },
    getEventsJson(sinceSequence) {
      return ecm.callRuntime('getEventsJson', sinceSequence)
        ?? ecm.callRuntime('pollEventsJson', sinceSequence);
    },
    getDiagnostics() {
      return ecm.callRuntime('getDiagnostics');
    },
    getNetworkStatus() {
      return ecm.callRuntime('getNetworkStatus');
    },
    setMode(mode) {
      return ecm.callRuntime('setMode', mode);
    },
    subscribe(type) {
      return ecm.callRuntime('subscribe', type);
    },
    unsubscribe(type) {
      return ecm.callRuntime('unsubscribe', type);
    },
    registerTaskJson(taskJson) {
      return ecm.callRuntime('registerTaskJson', taskJson);
    },
    unregisterTask(id) {
      return ecm.callRuntime('unregisterTask', id);
    },
    shutdown(payload) {
      return ecm.callRuntime('shutdown', payload);
    },
  };
}

function networkApi(ecm) {
  return {
    isAvailable() {
      return ecm.isNetworkAvailable();
    },
    getStatus() {
      return ecm.callNetwork('getNetworkStatus');
    },
    runDiagnostics() {
      return ecm.callNetwork('runNetworkDiagnostics');
    },
    discover() {
      return ecm.callNetwork('networkDiscover');
    },
    buildQr(ttlMinutes = 15) {
      return ecm.callNetwork('networkBuildQr', ttlMinutes);
    },
    registerPorts(repair = false) {
      return ecm.callNetwork('networkRegisterPorts', repair);
    },
    pairList() {
      return ecm.callNetwork('networkPairList');
    },
    rebind() {
      return ecm.callNetwork('networkRebind');
    },
  };
}

function displayApi(ecm) {
  return {
    list() {
      return ecm.listDisplays();
    },
    getSnapshot() {
      return ecm.getCachedDisplaySnapshot();
    },
    onChanged(handler) {
      return ecm.on('display-changed', handler);
    },
    applySnapshot(snapshot) {
      return ecm.applyDisplaySnapshot(snapshot);
    },
  };
}

function resourcesApi() {
  return {
    start() {
      return import('./resource-governor.js').then(({ ResourceGovernor }) => {
        ResourceGovernor.start();
        return true;
      });
    },
    snapshot() {
      return import('./resource-governor.js').then(({ ResourceGovernor }) => ResourceGovernor.snapshot());
    },
    getSnapshot() {
      return import('./resource-governor.js').then(({ ResourceGovernor }) => ResourceGovernor.getSnapshot());
    },
    getProfile() {
      return import('./resource-governor.js').then(({ ResourceGovernor }) => ResourceGovernor.getProfile());
    },
    forceProfile(name) {
      return import('./resource-governor.js').then(({ ResourceGovernor }) => ResourceGovernor.forceProfile(name));
    },
  };
}

function buildPublicEngine(ecm, readyPromise) {
  return Object.freeze({
    PROTOCOL_VERSION: ENGINE_PROTOCOL_VERSION,
    ready: readyPromise,
    connect() {
      return ecm.connect();
    },
    getStatus() {
      return ecm.getStatus();
    },
    getDiagnostics() {
      return ecm.getDiagnostics();
    },
    on(event, handler) {
      return ecm.on(event, handler);
    },
    off(event, handler) {
      return ecm.off(event, handler);
    },
    onResync(hook) {
      return ecm.onResync(hook);
    },
    shell: Object.freeze(shellApi(ecm)),
    runtime: Object.freeze(runtimeApi(ecm)),
    display: Object.freeze(displayApi(ecm)),
    network: Object.freeze(networkApi(ecm)),
    resources: Object.freeze(resourcesApi()),
  });
}

export function installEngineFacade() {
  if (installPromise) return installPromise;
  const ecm = getEngineConnectivity();
  let resolveReady;
  installPromise = new Promise((resolve) => { resolveReady = resolve; });
  installedEngine = buildPublicEngine(ecm, installPromise);

  if (typeof window !== 'undefined') {
    Object.defineProperty(window, 'Engine', {
      value: installedEngine,
      writable: false,
      configurable: false,
      enumerable: true,
    });

    ecm.on('user-message', ({ message, key }) => {
      window.dispatchEvent(new CustomEvent('engine-user-message', {
        detail: { message, key },
      }));
    });

    const reconnect = () => { void ecm.requestReconnect('native-ready'); };
    window.addEventListener('somosum-native-ready', reconnect);
    window.addEventListener('somosum-engine-ready', reconnect);
    window.addEventListener('somosum-network-ready', reconnect);
  }

  // A facade existe sincronicamente; ready aguarda somente a primeira tentativa.
  void ecm.connect({ reason: 'initial' })
    .catch(() => false)
    .finally(() => resolveReady(installedEngine));

  return installPromise;
}

export function getEngine() {
  if (typeof window !== 'undefined' && window.Engine) return window.Engine;
  if (installedEngine) return installedEngine;
  const ecm = getEngineConnectivity();
  return buildPublicEngine(ecm, Promise.resolve(null));
}
