/**
 * Render intent client — emite metadados de RenderIntent ao Runtime
 * enquanto o commit DOM permanece no RenderScheduler local.
 */

import { getPrefs } from '../core/store.js';

const PRIORITY_MAP = {
  critical: 'Critical',
  live: 'High',
  normal: 'Normal',
  idle: 'Idle',
};

function getRuntime() {
  if (typeof window === 'undefined') return null;
  return window.__SOMOSUM_RUNTIME__ || null;
}

function detectSurface() {
  if (typeof window === 'undefined') return 'unknown';
  if (window.SOMOSUM_SURFACE) return window.SOMOSUM_SURFACE;
  const path = (window.location?.pathname || '').toLowerCase();
  if (path.includes('control')) return 'control';
  if (path.includes('screen')) return 'screen';
  if (path.includes('stage')) return 'stage';
  if (path.includes('remote')) return 'remote';
  if (path.includes('panel')) return 'panel';
  if (path.includes('diagnostics')) return 'diagnostics';
  return 'unknown';
}

export function shouldRouteRenderIntent() {
  const cfg = getPrefs().runtimeEngine || {};
  if (!cfg.enabled) return false;
  const rt = getRuntime();
  return !!(rt?.isBridgeAvailable?.() && cfg.bridgePreferred !== false);
}

/**
 * Notifica o Runtime sobre trabalho de render pendente (sem serializar callbacks).
 * Retorna true quando o intent foi encaminhado ao bridge.
 */
export function emitRenderIntent(surface, { patch = null, full = null, priority = 'normal', slideType = null, slideId = null } = {}) {
  if (!shouldRouteRenderIntent()) return false;
  const rt = getRuntime();
  if (!rt?.execute) return false;

  const mode = typeof full === 'function' ? 'full' : 'patch';
  rt.execute({
    type: 'RenderIntentCommand',
    payload: {
      surface,
      mode,
      priority,
      slideType,
      slideId,
      hasPatch: typeof patch === 'function' || patch === true,
      hasFull: typeof full === 'function' || full === true,
    },
    source: detectSurface(),
    priority: PRIORITY_MAP[priority] || 'Normal',
  });
  return true;
}

export function emitRenderCommitMetrics(metrics = {}) {
  if (!shouldRouteRenderIntent()) return false;
  const rt = getRuntime();
  if (!rt?.execute) return false;
  rt.execute({
    type: 'RenderIntentCommand',
    payload: {
      surface: 'coordinator',
      mode: 'metrics',
      metrics,
    },
    source: detectSurface(),
    priority: 'Idle',
  });
  return true;
}
