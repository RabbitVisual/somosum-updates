/**
 * Facade autoritativa para Somosum.Network.Engine via ECM ou HTTP fallback.
 */

function parseJson(raw) {
  try { return JSON.parse(raw); } catch { return null; }
}

function network() {
  return typeof window !== 'undefined' ? window.Engine?.network : null;
}

async function fetchJsonTimed(url, opts = {}, ms = 8000) {
  const ctrl = typeof AbortController !== 'undefined' ? new AbortController() : null;
  const timer = ctrl ? setTimeout(() => ctrl.abort(), ms) : null;
  try {
    const res = await fetch(url, { ...opts, cache: 'no-store', signal: ctrl?.signal });
    if (timer) clearTimeout(timer);
    if (!res.ok) return null;
    return res.json();
  } catch {
    if (timer) clearTimeout(timer);
    return null;
  }
}

function launchShellRegisterPorts() {
  if (!window.Engine?.shell?.registerHttpPorts) return false;
  try {
    window.Engine.shell.registerHttpPorts();
    return true;
  } catch {
    return false;
  }
}

let _uacLaunchedAt = 0;

function canLaunchUac() {
  return Date.now() - _uacLaunchedAt > 90000;
}

function markUacLaunched() {
  _uacLaunchedAt = Date.now();
}

/** Painel: ignora “offline” por alguns segundos durante rebind do Kestrel. */
let _rebindGraceUntil = 0;

export function beginRebindGrace(ms = 15000) {
  _rebindGraceUntil = Date.now() + Math.max(2000, ms || 0);
}

export function isRebindGraceActive() {
  return Date.now() < _rebindGraceUntil;
}

export async function getNetworkStatus() {
  const http = await fetchJsonTimed('/api/network/status', {}, 6000);
  if (http) return http;
  const n = network();
  if (n?.isAvailable?.()) {
    try { return parseJson(n.getStatus()); } catch { /* ignore */ }
  }
  const lan = await fetchJsonTimed('/api/lan-info', {}, 5000);
  if (lan) {
    return {
      lanBindOk: !!lan.lanBindOk,
      lanMode: !!lan.lanMode,
      port: lan.port,
      recommendedIp: lan.lanIp,
      lanIp: lan.lanIp,
    };
  }
  return null;
}

export async function runNetworkDiagnostics() {
  const http = await fetchJsonTimed('/api/network/diagnostics', {}, 8000);
  if (http) return http;
  const n = network();
  if (n?.isAvailable?.()) {
    try { return parseJson(n.runDiagnostics()); } catch { /* ignore */ }
  }
  return null;
}

export async function networkDiscover() {
  const http = await fetchJsonTimed('/api/network/discover', {}, 5000);
  if (http) return http;
  const lan = await fetchJsonTimed('/api/lan-info', {}, 4000);
  if (lan?.lanIp) return { recommendedIp: lan.lanIp, lanIp: lan.lanIp };
  const n = network();
  if (n?.isAvailable?.()) {
    try { return parseJson(n.discover()); } catch { /* ignore */ }
  }
  return null;
}

export async function networkBuildQr(ttlMinutes = 15) {
  const lan = await fetchJsonTimed('/api/lan-info', {}, 5000);
  const stage = String(lan?.guarantee?.stage || lan?.guaranteeStage || '').toLowerCase();
  const proven = !!(lan?.lanBindOk && lan?.listeningPublic !== false
    && (stage === 'ready' || lan?.guarantee?.ready === true || lan?.guarantee?.probeOk === true));
  // Só URL pública quando o Kestrel realmente escuta na LAN e o probe passou.
  if (proven && lan?.remoteUrl && !String(lan.remoteUrl).includes('127.0.0.1')) {
    return { ok: true, url: lan.remoteUrl, source: 'lan-info', stageUrl: lan.stageUrl || lan.stageQrUrl };
  }
  const data = await fetchJsonTimed('/api/network/qr', {}, 6000);
  if (data?.ok && data.url && !String(data.url).includes('127.0.0.1')) return data;
  // Pendente: NUNCA devolver IP LAN — tablet recebe “site inacessível”.
  if (lan?.localRemoteUrl) {
    return {
      ok: false,
      error: 'lan_bind_not_ready',
      url: lan.localRemoteUrl,
      source: 'lan-info-local',
      blockers: ['lan_bind_not_ready', ...(data?.blockers || [])],
    };
  }
  const n = network();
  if (n?.isAvailable?.()) {
    try {
      const bridge = parseJson(n.buildQr(ttlMinutes));
      if (bridge?.ok && bridge.url) return bridge;
    } catch { /* ignore */ }
  }
  return { ok: false, error: 'unavailable', blockers: data?.blockers };
}

/**
 * Prepara URL ACL + firewall.
 * NÃO chama rebind no JS — o servidor agenda no máximo 1 reinício quando a LAN
 * acaba de liberar. Rebind duplo derruba o painel (“Servidor offline”).
 */
export async function networkRegisterPorts(repair = false) {
  let data = await fetchJsonTimed('/api/network/register', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ repair: !!repair }),
  }, 10000);

  if (data == null) {
    await new Promise((r) => setTimeout(r, 1200));
    data = await fetchJsonTimed('/api/network/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ repair: !!repair }),
    }, 10000);
  }

  const success = !!(data?.Success || data?.ok || data?.AlreadyConfigured || data?.alreadyConfigured);
  if (success) {
    if (data?.rebindScheduled) beginRebindGrace(18000);
    return {
      ...data,
      ok: true,
      Success: true,
      success: true,
    };
  }

  const needsElevation = !!(data?.NeedsElevation || data?.needsElevation);

  if (needsElevation) {
    if (canLaunchUac() && launchShellRegisterPorts()) {
      markUacLaunched();
      beginRebindGrace(25000);
      return {
        ok: true,
        pending: true,
        needsElevation: true,
        NeedsElevation: true,
        Success: false,
        message: 'uac_launched',
      };
    }
    if (!canLaunchUac()) {
      return {
        ok: false,
        pending: true,
        needsElevation: true,
        NeedsElevation: true,
        message: 'UAC solicitado há instantes — aguarde ou use o menu da bandeja: Preparar rede local.',
      };
    }
  }

  if (data == null) {
    return {
      ok: false,
      error: 'server_busy',
      NeedsElevation: false,
      needsElevation: false,
      message: 'Servidor ocupado. Aguarde alguns segundos e tente Preparar rede de novo.',
    };
  }

  const n = network();
  let result = null;
  if (n?.isAvailable?.()) {
    try { result = parseJson(n.registerPorts(repair)); } catch { result = null; }
  }

  if (result?.Success || result?.success || result?.ok || result?.AlreadyConfigured) {
    return { ...result, ok: true, Success: true, success: true };
  }

  if ((result?.NeedsElevation || result?.needsElevation) && canLaunchUac()) {
    markUacLaunched();
    if (launchShellRegisterPorts()) {
      beginRebindGrace(25000);
      return {
        ok: true,
        pending: true,
        needsElevation: true,
        NeedsElevation: true,
        Success: false,
        message: 'uac_launched',
      };
    }
  }

  if (result) return result;
  return {
    ok: false,
    error: 'no_bridge',
    NeedsElevation: false,
    needsElevation: false,
    message: 'Confirme o UAC pelo menu da bandeja: Rede → Preparar rede local.',
  };
}

export async function networkPairList() {
  try {
    const res = await fetch('/api/network/pair/list', { cache: 'no-store' });
    if (!res.ok) return { devices: [], pendingCount: 0 };
    const data = await res.json();
    return {
      devices: Array.isArray(data?.devices) ? data.devices : [],
      pendingCount: data?.pendingCount ?? 0,
      ...data,
    };
  } catch {
    return { devices: [], pendingCount: 0 };
  }
}

export async function networkPairApprove(deviceId, name) {
  try {
    const res = await fetch('/api/network/pair/approve', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ deviceId, name }),
    });
    return res.json();
  } catch {
    return { ok: false };
  }
}

export async function networkPairRevoke(deviceId) {
  try {
    const res = await fetch('/api/network/pair/revoke', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ deviceId }),
    });
    return res.json();
  } catch {
    return { ok: false };
  }
}

export async function networkRebind() {
  beginRebindGrace(15000);
  const http = await fetchJsonTimed('/api/network/rebind', { method: 'POST' }, 5000);
  if (http) return { ok: true, ...http };
  const n = network();
  if (n?.isAvailable?.()) {
    try {
      n.rebind();
      return { ok: true };
    } catch { /* ignore */ }
  }
  return { ok: false };
}

export async function networkRepairFirewall() {
  const data = await fetchJsonTimed('/api/network/firewall/repair', { method: 'POST' }, 20000);
  const needsElev = !!(data?.requiresElevation || data?.RequiresElevation);
  if (needsElev) {
    if (canLaunchUac() && launchShellRegisterPorts()) {
      markUacLaunched();
      beginRebindGrace(25000);
      return {
        ok: true,
        pending: true,
        requiresElevation: true,
        message: 'Confirme o UAC do Windows (Sim) para liberar o firewall.',
      };
    }
    return networkRegisterPorts(true);
  }
  if (data) return data;
  return { ok: false, error: 'unavailable' };
}

export async function getCurrentPin(opts = {}) {
  const rotate = opts?.rotate ? '?rotate=1' : '';
  return fetchJsonTimed(`/api/network/pin/current${rotate}`, {}, 5000);
}

export function onNetworkReady(cb) {
  if (window.Engine?.network?.isAvailable?.()) {
    cb();
    return () => {};
  }
  const handler = () => cb();
  window.addEventListener('engine-connected', handler);
  window.addEventListener('somosum-network-ready', handler);
  return () => {
    window.removeEventListener('engine-connected', handler);
    window.removeEventListener('somosum-network-ready', handler);
  };
}

/** Espera LAN comprovada (bind + probe HTTP no IP Wi‑Fi — não só firewall). */
export async function waitForLanBind(timeoutMs = 45000) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    const info = await fetchJsonTimed('/api/lan-info', {}, 2500);
    const stage = String(info?.guarantee?.stage || info?.guaranteeStage || '').toLowerCase();
    const probeOk = info?.guarantee?.probeOk === true || info?.lanProbeOk === true;
    if (info?.lanBindOk && (stage === 'ready' || probeOk || info?.listeningPublic === true
        || info?.guarantee?.ready === true)) {
      return info;
    }
    await new Promise((r) => setTimeout(r, 800));
  }
  return null;
}

export async function enableLanModeFlow({ savePrefs, getPrefs, requestSoftRestart, toast }) {
  const prefs = getPrefs();
  savePrefs({ ...prefs, lanMode: true });
  const reg = await networkRegisterPorts(false);
  if (reg?.pending || reg?.needsElevation || reg?.NeedsElevation) {
    toast?.('Confirme o UAC do Windows (Sim) — necessário uma vez neste PC.', 'info');
  } else if (!(reg?.ok || reg?.Success)) {
    toast?.(reg?.message || 'Clique em Preparar rede e confirme o UAC.', 'warn');
  } else if (reg?.rebindScheduled) {
    toast?.('Abrindo rede Wi‑Fi… o painel pode piscar por 1–2s.', 'info');
  }
  const ready = await waitForLanBind(
    reg?.pending || reg?.needsElevation || reg?.NeedsElevation ? 55000 : 12000,
  );
  if (ready?.lanBindOk) {
    toast?.('Rede LAN ativa. Escaneie o QR e digite o PIN no celular.', 'success');
    return { ...reg, ok: true, Success: true, lanBindOk: true };
  }
  if (reg?.pending || reg?.needsElevation || reg?.NeedsElevation) {
    toast?.('Rede pendente — confirme o UAC ou clique Preparar rede novamente.', 'warn');
  } else {
    toast?.('Rede não liberada. Use Preparar rede (admin) no Painel → Rede.', 'warn');
  }
  if (!ready?.lanBindOk && typeof requestSoftRestart === 'function') {
    beginRebindGrace(30000);
    await requestSoftRestart(25000);
  }
  return { ...reg, ok: false, lanBindOk: false };
}
