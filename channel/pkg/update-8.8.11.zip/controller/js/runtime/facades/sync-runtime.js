/**
 * Facade Sync — delegação autoritativa ao SyncManager C# quando bridge ativo.
 */
import {
  SyncHub,
  SyncMessageTypes,
  loadRemoteToken,
  getRemoteToken,
  getStoredSessionToken,
  storeSessionToken,
  clearStoredSessionToken,
  validateStoredSession,
} from '../../core/sync-hub.js';

function getRuntime() {
  if (typeof window === 'undefined') return null;
  return window.__SOMOSUM_RUNTIME__ || null;
}

/** Envia sync ao Runtime C# (autoritativo). Retorna resultado ou null se legado. */
export function pushSyncAuthoritative(payload = {}, source = 'control') {
  const rt = getRuntime();
  if (!rt?.isBridgeAvailable?.() || rt.shouldUseLegacy?.()) return null;
  try {
    return rt.execute({
      type: 'PushSyncCommand',
      payload: {
        messageType: payload.messageType || payload.type || 'sync',
        message: payload.message || payload,
      },
      source,
      priority: 'High',
      correlationId: payload.id || payload.correlationId,
    });
  } catch {
    return null;
  }
}

export function requestFullStateAuthoritative(source = 'control', reason = 'request') {
  const rt = getRuntime();
  if (!rt?.isBridgeAvailable?.() || rt.shouldUseLegacy?.()) return null;
  try {
    return rt.execute({
      type: 'RequestFullStateCommand',
      payload: { reason },
      source,
      priority: 'High',
    });
  } catch {
    return null;
  }
}

export function ackSlideAuthoritative(slideIndex, source = 'screen') {
  const rt = getRuntime();
  if (!rt?.isBridgeAvailable?.() || rt.shouldUseLegacy?.()) return null;
  try {
    return rt.execute({
      type: 'AckSlideCommand',
      payload: { slideIndex },
      source,
      priority: 'High',
    });
  } catch {
    return null;
  }
}

export function getSyncStateFromRuntime() {
  const rt = getRuntime();
  if (!rt?.isBridgeAvailable?.() || rt.shouldUseLegacy?.()) return null;
  try {
    return rt.getState('sync');
  } catch {
    return null;
  }
}

export {
  SyncHub,
  SyncMessageTypes,
  loadRemoteToken,
  getRemoteToken,
  getStoredSessionToken,
  storeSessionToken,
  clearStoredSessionToken,
  validateStoredSession,
};
