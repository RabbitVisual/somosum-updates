/**
 * Facade Display Projection — importar daqui em vez de display-projection-engine.js (Fase 12).
 */
export {
  DisplayProjectionEngine,
  bootDisplayProjectionEngine,
  getDesignDimensions,
} from '../../core/display-projection-engine.js';
