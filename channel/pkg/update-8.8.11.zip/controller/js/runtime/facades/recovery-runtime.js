/**
 * Facade Recovery — delegação autoritativa ao RecoveryManager C# quando bridge ativo.
 */
import {
  RecoveryEngine,
  getRecoveryEngine,
  runRecoveryDiagnostics,
} from '../../core/recovery/recovery-engine.js';

function getRuntime() {
  if (typeof window === 'undefined') return null;
  return window.__SOMOSUM_RUNTIME__ || null;
}

export function triggerRecoveryAuthoritative(path = 'sync', source = 'control', extra = {}) {
  const rt = getRuntime();
  if (!rt?.isBridgeAvailable?.() || rt.shouldUseLegacy?.()) return null;
  try {
    return rt.execute({
      type: 'TriggerRecoveryCommand',
      payload: { path, ...extra },
      source,
      priority: 'High',
    });
  } catch {
    return null;
  }
}

export function getRecoveryStateFromRuntime() {
  const rt = getRuntime();
  if (!rt?.isBridgeAvailable?.() || rt.shouldUseLegacy?.()) return null;
  try {
    return rt.getState('recovery');
  } catch {
    return null;
  }
}

export function isRuntimeRecoveryActive() {
  const state = getRecoveryStateFromRuntime();
  return !!(state?.active || state?.recovering || state?.inProgress);
}

export { RecoveryEngine, getRecoveryEngine, runRecoveryDiagnostics };
