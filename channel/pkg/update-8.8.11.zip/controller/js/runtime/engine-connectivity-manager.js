/**
 * Engine Connectivity Manager (ECM) — única camada entre JS e Somosum.Engine.dll / WebView2.
 * Nenhum outro módulo deve acessar somosumNative, hostObjects ou bridges COM diretamente.
 */

import { TaskScheduler } from '../core/task-scheduler.js';
import { TaskIds } from '../core/task-registry.js';
import { registerDisposable } from '../core/disposable-registry.js';
import { getPrefs } from '../core/store.js';
import { ProjectionBus, MessageTypes } from '../core/bus.js';

export const ENGINE_PROTOCOL_VERSION = '1.0.0';

const ENV = Object.freeze({
  ENGINE: 'engine',
  WEBVIEW2: 'webview2',
  BROWSER: 'browser',
  MOCK: 'mock',
});

const STATE = Object.freeze({
  DISCONNECTED: 'disconnected',
  CONNECTING: 'connecting',
  HANDSHAKING: 'handshaking',
  CONNECTED: 'connected',
  DEGRADED: 'degraded',
  RECONNECTING: 'reconnecting',
});

const USER_MESSAGES = Object.freeze({
  connecting: 'Conectando ao motor SOMOSUM…',
  connected: 'Motor SOMOSUM conectado.',
  degraded: 'Motor em modo limitado — algumas funções usam fallback local.',
  reconnecting: 'Reconectando ao motor SOMOSUM…',
  unavailable: 'Motor indisponível. Abra pelo SOMOSUM.exe ou reinicie o aplicativo.',
  browser: 'Modo navegador — projeção nativa e monitores requerem SOMOSUM.exe.',
});

let singleton = null;

function isDevMode() {
  try {
    const prefs = getPrefs();
    if (prefs?.productionMode) return false;
  } catch { /* ignore */ }
  return document.documentElement?.dataset?.productionMode !== '1'
    && !window.SOMOSUM_PRODUCTION;
}

function parseJsonSafe(value) {
  if (value == null) return null;
  if (typeof value === 'object') return value;
  try { return JSON.parse(value); } catch { return null; }
}

function devLog(...args) {
  if (isDevMode()) console.debug('[ECM]', ...args);
}

/** Resolve adaptador interno — NÃO exportar para consumidores. */
function resolveShellAdapter() {
  if (typeof window === 'undefined') return null;
  try {
    const sync = window.chrome?.webview?.hostObjects?.sync?.somosumNative;
    if (sync) return sync;
  } catch (err) {
    devLog('shell adapter unavailable', err);
  }
  try {
    if (window.somosumNative) return window.somosumNative;
  } catch (err) {
    devLog('somosumNative fallback unavailable', err);
  }
  return null;
}

function resolveRuntimeAdapter() {
  if (typeof window === 'undefined') return null;
  try {
    const sync = window.chrome?.webview?.hostObjects?.sync?.somosumEngine
      || window.chrome?.webview?.hostObjects?.sync?.somosumRuntime;
    if (sync) return sync;
  } catch (err) {
    devLog('runtime adapter unavailable', err);
  }
  try {
    return window.somosumEngine || window.somosumRuntime || null;
  } catch (err) {
    devLog('runtime fallback unavailable', err);
    return null;
  }
}

function resolveNetworkAdapter() {
  if (typeof window === 'undefined') return null;
  try {
    const sync = window.chrome?.webview?.hostObjects?.sync?.somosumNetwork;
    if (sync) return sync;
  } catch (err) {
    devLog('network adapter unavailable', err);
  }
  try {
    return window.somosumNetwork || null;
  } catch (err) {
    devLog('network fallback unavailable', err);
    return null;
  }
}

function callAdapter(adapter, method, ...args) {
  if (!adapter) return undefined;
  const fn = adapter[method] || adapter[method.charAt(0).toUpperCase() + method.slice(1)];
  if (typeof fn !== 'function') return undefined;
  try {
    return fn.apply(adapter, args);
  } catch (err) {
    devLog('adapter call failed', method, err);
    return undefined;
  }
}

export class EngineConnectivityManager {
  constructor() {
    this.state = STATE.DISCONNECTED;
    this.environment = null;
    this.bridgeState = 'unknown';
    this.lastHandshakeAt = null;
    this.lastHealthAt = null;
    this.lastSyncAt = null;
    this.lastResponseMs = null;
    this.lastError = null;
    this.reconnectAttempt = 0;
    this.negotiatedProtocolVersion = null;
    this._listeners = new Map();
    this._resyncHooks = [];
    this._connectPromise = null;
    this._connectionGeneration = 0;
    this._reconnectTimer = null;
    this._hasConnected = false;
    this._healthRegistered = false;
    this._webMessageBound = false;
    this._userMessage = null;
    this._projectionState = { open: false, displayIndex: -1 };
    this._displaySnapshot = null;
    this._engineDiagnostics = null;
    this._runtimeScheduler = { mode: 'unknown', tickMs: null };
  }

  on(event, handler) {
    if (!this._listeners.has(event)) this._listeners.set(event, new Set());
    this._listeners.get(event).add(handler);
    return () => this.off(event, handler);
  }

  off(event, handler) {
    this._listeners.get(event)?.delete(handler);
  }

  _emit(event, detail = {}) {
    const payload = { ...detail, timestamp: Date.now() };
    this._listeners.get(event)?.forEach((fn) => {
      try { fn(payload); } catch { /* ignore */ }
    });
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent(`engine-${event}`, { detail: payload }));
    }
  }

  onResync(hook) {
    if (typeof hook !== 'function') return () => {};
    this._resyncHooks.push(hook);
    return () => {
      const index = this._resyncHooks.indexOf(hook);
      if (index >= 0) this._resyncHooks.splice(index, 1);
    };
  }

  _setUserMessage(key) {
    this._userMessage = USER_MESSAGES[key] || key;
    this._emit('user-message', { message: this._userMessage, key });
  }

  detectEnvironment() {
    const runtime = resolveRuntimeAdapter();
    const shell = resolveShellAdapter();
    if (runtime && (typeof runtime.executeJson === 'function' || typeof runtime.getStateJson === 'function')) {
      return ENV.ENGINE;
    }
    if (shell || window.chrome?.webview || window.somosumNativeShell || window.somosumEngineShell) {
      return ENV.WEBVIEW2;
    }
    if (location.protocol === 'file:') return ENV.MOCK;
    return ENV.BROWSER;
  }

  _bindWebMessages() {
    if (this._webMessageBound || !window.chrome?.webview) return;
    this._webMessageBound = true;
    const handler = (ev) => {
      try {
        const data = typeof ev.data === 'string' ? JSON.parse(ev.data) : ev.data;
        if (data?.type === 'display-changed') {
          const snapshot = typeof data.snapshot === 'string' ? JSON.parse(data.snapshot) : data.snapshot;
          this._displaySnapshot = snapshot;
          this.lastSyncAt = Date.now();
          this._emit('display-changed', { snapshot });
        } else if (data?.type === 'engine-event' || data?.events
          || data?.channel === 'somosum-runtime' || data?.channel === 'somosum-engine') {
          this.lastSyncAt = Date.now();
          this._emit('runtime-event', { payload: data });
        }
      } catch { /* ignore */ }
    };
    window.chrome.webview.addEventListener('message', handler);
    registerDisposable(() => window.chrome?.webview?.removeEventListener?.('message', handler));
  }

  async connect({ reason = 'initial' } = {}) {
    if (this._connectPromise) return this._connectPromise;
    const generation = ++this._connectionGeneration;
    this._connectPromise = this._connectInternal(reason, generation);
    return this._connectPromise;
  }

  async _connectInternal(reason, generation) {
    const reconnecting = reason !== 'initial' || this._hasConnected;
    this.state = reconnecting ? STATE.RECONNECTING : STATE.CONNECTING;
    this._setUserMessage(reconnecting ? 'reconnecting' : 'connecting');
    this.environment = this.detectEnvironment();
    this._bindWebMessages();

    const deadline = Date.now() + 12000;
    let delay = 400;

    while (Date.now() < deadline) {
      if (generation !== this._connectionGeneration) return false;
      const ok = await this._attemptHandshake();
      if (generation !== this._connectionGeneration) return false;
      if (ok) {
        const limited = this.environment === ENV.BROWSER;
        this.state = limited ? STATE.DEGRADED : STATE.CONNECTED;
        this.reconnectAttempt = 0;
        this._hasConnected = true;
        this._setUserMessage(this.environment === ENV.BROWSER ? 'browser' : 'connected');
        this._startHealthCheck();
        this._emit('connected', { environment: this.environment });
        await this._resyncFullState(reconnecting ? 'reconnect' : 'initial');
        return true;
      }
      this.reconnectAttempt += 1;
      await new Promise((r) => setTimeout(r, delay));
      delay = Math.min(delay * 1.8, 8000);
    }

    if (generation !== this._connectionGeneration) return false;
    this.state = this.environment === ENV.BROWSER ? STATE.DEGRADED : STATE.DISCONNECTED;
    this.bridgeState = 'unavailable';
    this._setUserMessage(this.environment === ENV.BROWSER ? 'browser' : 'unavailable');
    this._emit('unavailable', { environment: this.environment });
    this._scheduleReconnect();
    return false;
  }

  async _attemptHandshake() {
    this.state = STATE.HANDSHAKING;
    const sw = performance.now();

    const runtime = resolveRuntimeAdapter();
    if (runtime) {
      const handshakeRaw = callAdapter(runtime, 'executeJson', JSON.stringify({
        type: 'handshake',
        protocolVersion: ENGINE_PROTOCOL_VERSION,
        source: 'ecm',
      }));
      if (handshakeRaw != null) {
        const handshake = parseJsonSafe(handshakeRaw);
        this.negotiatedProtocolVersion = handshake?.protocolVersion || ENGINE_PROTOCOL_VERSION;
        this.bridgeState = 'engine';
        this.lastHandshakeAt = Date.now();
        this.lastResponseMs = Math.round(performance.now() - sw);
        devLog('handshake engine OK', this.lastResponseMs, 'ms');
        return true;
      }

      const stateRaw = callAdapter(runtime, 'getStateJson', 'meta')
        ?? callAdapter(runtime, 'getStateJson', 'connectivity');
      if (stateRaw != null) {
        const state = parseJsonSafe(stateRaw);
        this.negotiatedProtocolVersion = state?.protocolVersion || ENGINE_PROTOCOL_VERSION;
        this.bridgeState = 'engine';
        this.lastHandshakeAt = Date.now();
        this.lastResponseMs = Math.round(performance.now() - sw);
        devLog('legacy engine handshake OK', this.lastResponseMs, 'ms');
        return true;
      }
    }

    const shell = resolveShellAdapter();
    if (shell) {
      const port = callAdapter(shell, 'getPort');
      const native = callAdapter(shell, 'isNativeShell');
      if (port != null || native === true || typeof shell.getDisplays === 'function') {
        this.negotiatedProtocolVersion = ENGINE_PROTOCOL_VERSION;
        this.bridgeState = 'webview2-shell';
        this.lastHandshakeAt = Date.now();
        this.lastResponseMs = Math.round(performance.now() - sw);
        devLog('handshake webview2 shell OK');
        return true;
      }
    }

    if (this.environment === ENV.BROWSER || this.environment === ENV.MOCK) {
      this.negotiatedProtocolVersion = ENGINE_PROTOCOL_VERSION;
      this.bridgeState = 'http-only';
      this.lastHandshakeAt = Date.now();
      this.lastResponseMs = Math.round(performance.now() - sw);
      return true;
    }

    return false;
  }

  _startHealthCheck() {
    if (this._healthRegistered) return;
    this._healthRegistered = true;
    const intervalMs = isDevMode() ? 15000 : 45000;
    TaskScheduler.register({
      id: TaskIds.ENGINE_CONNECTIVITY_HEALTH,
      kind: 'interval',
      intervalMs,
      priority: 2,
      fn: () => this._healthCheck(),
    });
  }

  async _healthCheck() {
    if (this.state === STATE.RECONNECTING) return;
    const sw = performance.now();
    let alive = false;

    const runtime = resolveRuntimeAdapter();
    if (this.environment === ENV.ENGINE && runtime) {
      const raw = callAdapter(runtime, 'getStateJson', 'meta');
      alive = raw != null;
      if (!alive) {
        alive = callAdapter(runtime, 'executeJson', JSON.stringify({
          type: 'health',
          protocolVersion: ENGINE_PROTOCOL_VERSION,
          source: 'ecm',
        })) != null;
      }
    }
    if (this.environment === ENV.WEBVIEW2) {
      const shell = resolveShellAdapter();
      if (shell) {
        const p = callAdapter(shell, 'getPort');
        alive = p != null || typeof shell.getDisplays === 'function';
      }
    }
    if (!alive && (this.environment === ENV.BROWSER || this.environment === ENV.MOCK)) {
      alive = true;
    }

    this.lastHealthAt = Date.now();
    this.lastResponseMs = Math.round(performance.now() - sw);

    if (!alive) {
      devLog('health check failed — scheduling reconnect');
      this.state = STATE.RECONNECTING;
      this.bridgeState = 'lost';
      this._setUserMessage('reconnecting');
      this._emit('bridge-lost', {});
      this._connectPromise = null;
      this._scheduleReconnect();
      return;
    }

    if (this.state === STATE.DEGRADED) {
      this.state = STATE.CONNECTED;
      this._emit('recovered', {});
    }
  }

  _scheduleReconnect() {
    if (this._reconnectTimer != null) return;
    const attempt = this.reconnectAttempt;
    const delay = Math.min(500 * Math.pow(2, attempt), 30000);
    this._reconnectTimer = setTimeout(() => {
      this._reconnectTimer = null;
      if (this.state === STATE.CONNECTED) return;
      this._connectPromise = null;
      void this.connect({ reason: 'reconnect' });
    }, delay);
  }

  requestReconnect(reason = 'manual') {
    if (this._reconnectTimer != null) {
      clearTimeout(this._reconnectTimer);
      this._reconnectTimer = null;
    }
    this._connectPromise = null;
    return this.connect({ reason });
  }

  async _resyncFullState(reason) {
    devLog('full state resync', reason);

    try {
      const runtime = resolveRuntimeAdapter();
      if (runtime) {
        const diag = callAdapter(runtime, 'getDiagnostics');
        const parsed = parseJsonSafe(diag);
        if (parsed) {
          this._engineDiagnostics = parsed;
          this._runtimeScheduler = parsed.runtimeScheduler || parsed.scheduler || this._runtimeScheduler;
        }
      }
    } catch { /* ignore */ }

    const snapshot = this._fetchDisplaySnapshot() || this._displaySnapshot;
    if (snapshot) {
      this._displaySnapshot = snapshot;
      this._emit('display-changed', { snapshot });
    }

    for (const hook of this._resyncHooks) {
      try { await hook({ reason, ecm: this }); } catch { /* ignore */ }
    }

    try {
      const bus = ProjectionBus.getInstance?.();
      if (bus) {
        const prefs = getPrefs();
        bus.send(MessageTypes.SETTINGS, prefs);
        const now = Date.now();
        const minGap = 30000;
        if (!this._lastFullStateRequestAt || now - this._lastFullStateRequestAt >= minGap) {
          this._lastFullStateRequestAt = now;
          bus.send(MessageTypes.FULL_STATE_REQUEST, { reason, ts: now });
        }
      }
    } catch { /* ignore */ }

    this.lastSyncAt = Date.now();
    this._emit('resynced', { reason });
    if (reason !== 'initial') {
      window.dispatchEvent(new CustomEvent('engine-reconnected', { detail: { reason } }));
    }
  }

  _fetchDisplaySnapshot() {
    const shell = resolveShellAdapter();
    if (!shell) return null;
    const raw = callAdapter(shell, 'getDisplaysDetailed') ?? callAdapter(shell, 'getDisplaySnapshot');
    if (raw) {
      try {
        const parsed = typeof raw === 'string' ? JSON.parse(raw) : raw;
        if (parsed?.displays?.length) return parsed;
      } catch { /* fallback to basic display list */ }
    }
    const displays = parseJsonSafe(callAdapter(shell, 'getDisplays'));
    const list = Array.isArray(displays) ? displays : displays?.displays;
    return list?.length ? { timestamp: Date.now(), displays: list } : null;
  }

  invokeShell(method, ...args) {
    try {
      const shell = resolveShellAdapter();
      if (!shell) return undefined;
      const sw = performance.now();
      const result = callAdapter(shell, method, ...args);
      this.lastResponseMs = Math.round(performance.now() - sw);
      return result;
    } catch (err) {
      devLog('invokeShell failed', method, err);
      return undefined;
    }
  }

  callRuntime(method, ...args) {
    const runtime = resolveRuntimeAdapter();
    if (!runtime) return undefined;
    const sw = performance.now();
    const result = callAdapter(runtime, method, ...args);
    this.lastResponseMs = Math.round(performance.now() - sw);
    return result;
  }

  isRuntimeAvailable() {
    return !!resolveRuntimeAdapter();
  }

  isNetworkAvailable() {
    return !!resolveNetworkAdapter();
  }

  callNetwork(method, ...args) {
    const network = resolveNetworkAdapter();
    if (!network) return undefined;
    const sw = performance.now();
    const result = callAdapter(network, method, ...args);
    this.lastResponseMs = Math.round(performance.now() - sw);
    return result;
  }

  isShellAvailable() {
    return !!resolveShellAdapter();
  }

  parseDisplaysJson(json) {
    try {
      const parsed = JSON.parse(json || '[]');
      return Array.isArray(parsed) ? parsed : (parsed?.displays || []);
    } catch {
      return [];
    }
  }

  listDisplays() {
    try {
      const normalize = (list) => (list || []).map((d, i) => ({
        ...d,
        index: d.index ?? i,
        width: d.width ?? d.bounds?.w ?? d.currentMode?.w ?? null,
        height: d.height ?? d.bounds?.h ?? d.currentMode?.h ?? null,
        primary: !!d.primary,
        friendlyName: d.friendlyName || d.deviceName || `Monitor ${i + 1}`,
      }));

      const snap = this._displaySnapshot;
      if (snap?.displays?.length) return normalize(snap.displays);
      // Detalhado primeiro (hash/DPI/modos) — getDisplays agora também retorna snapshot completo
      const detailed = this.invokeShell('getDisplaysDetailed') ?? this.invokeShell('getDisplaySnapshot');
      if (detailed != null) {
        try {
          const parsed = typeof detailed === 'string' ? JSON.parse(detailed) : detailed;
          if (parsed?.displays?.length) {
            this._displaySnapshot = { ...parsed, timestamp: parsed.timestamp || Date.now() };
            return normalize(parsed.displays);
          }
        } catch { /* ignore */ }
      }
      const json = this.invokeShell('getDisplays');
      if (json != null) {
        const list = this.parseDisplaysJson(typeof json === 'string' ? json : String(json));
        if (list.length) return normalize(list);
      }
      if (typeof screen !== 'undefined') {
        return normalize([{
          index: 0,
          width: screen.width || 1920,
          height: screen.height || 1080,
          primary: true,
          friendlyName: 'Monitor 1',
        }]);
      }
      return [];
    } catch (err) {
      devLog('listDisplays failed', err);
      return [];
    }
  }

  getCachedDisplaySnapshot() {
    return this._displaySnapshot;
  }

  setProjectionState(patch) {
    Object.assign(this._projectionState, patch);
  }

  applyDisplaySnapshot(snapshot) {
    if (!snapshot?.displays?.length) return null;
    this._displaySnapshot = snapshot;
    this.lastSyncAt = Date.now();
    return snapshot;
  }

  getStatus() {
    return {
      state: this.state,
      environment: this.environment,
      bridgeState: this.bridgeState,
      protocolVersion: ENGINE_PROTOCOL_VERSION,
      negotiatedProtocolVersion: this.negotiatedProtocolVersion,
      lastHandshakeAt: this.lastHandshakeAt,
      lastHealthAt: this.lastHealthAt,
      lastSyncAt: this.lastSyncAt,
      lastResponseMs: this.lastResponseMs,
      userMessage: this._userMessage,
      reconnectAttempt: this.reconnectAttempt,
    };
  }

  getDiagnostics() {
    try {
      const displays = this.listDisplays();
      const native = this._engineDiagnostics || {};
      return {
        ...this.getStatus(),
        engine: {
          available: !!resolveRuntimeAdapter(),
          bridgeState: this.bridgeState,
        },
        bridge: {
          shell: !!resolveShellAdapter(),
          runtime: !!resolveRuntimeAdapter(),
          responseMs: this.lastResponseMs,
        },
        projection: native.projection || { ...this._projectionState },
        monitors: native.monitors || {
          count: displays.length,
          displays: displays.slice(0, 8),
        },
        displayManager: {
          ...(native.displayManager || {}),
          snapshotAge: this._displaySnapshot ? Date.now() - (this._displaySnapshot.timestamp || this.lastSyncAt || 0) : null,
          hasSnapshot: !!this._displaySnapshot,
        },
        projectionModule: native.projectionModule || {
          state: this._projectionState,
        },
        runtimeScheduler: { ...this._runtimeScheduler },
        lastError: this.lastError,
      };
    } catch (err) {
      devLog('getDiagnostics failed', err);
      return {
        ...this.getStatus(),
        state: 'degraded',
        userMessage: 'Shell indisponível — abra pelo SOMOSUM.exe.',
        bridge: { shell: false, runtime: false, responseMs: null },
        engine: { available: false, bridgeState: this.bridgeState },
      };
    }
  }
}

export function getEngineConnectivity() {
  if (!singleton) singleton = new EngineConnectivityManager();
  return singleton;
}

export async function bootEngineConnectivity() {
  const ecm = getEngineConnectivity();
  await ecm.connect();
  return ecm;
}
