/**
 * Resource Governor — perfil adaptativo da superfície JS (CPU/RAM/GPU/cache).
 * Espelha o AdaptiveGovernor C# e aplica knobs locais: TaskScheduler, ImageCache, preload.
 */
import { TaskScheduler } from '../core/task-scheduler.js';
import { TaskIds } from '../core/task-registry.js';
import { LogService, LogCategory } from '../core/logging/log-service.js';

const BUDGETS = Object.freeze({
  processRamMb: 1200,
  screenHeapMb: 280,
  assetBlobCacheMb: 150,
  imageCacheMax: 80,
  imageCacheEco: 24,
  imageCacheLive: 40,
});

const PROFILES = Object.freeze({
  performance: {
    name: 'performance',
    schedulerMode: 'active',
    tickHintMs: 16,
    imageCacheMax: 80,
    preloadAggressive: true,
    sampleMs: 5000,
  },
  conservative: {
    name: 'conservative',
    schedulerMode: 'active',
    tickHintMs: 32,
    imageCacheMax: 48,
    preloadAggressive: false,
    sampleMs: 8000,
  },
  eco: {
    name: 'eco',
    schedulerMode: 'background',
    tickHintMs: 64,
    imageCacheMax: 24,
    preloadAggressive: false,
    sampleMs: 12000,
  },
  live: {
    name: 'live',
    schedulerMode: 'active',
    tickHintMs: 16,
    imageCacheMax: 40,
    preloadAggressive: true,
    sampleMs: 10000,
  },
  'live-eco': {
    name: 'live-eco',
    schedulerMode: 'active',
    tickHintMs: 32,
    imageCacheMax: 24,
    preloadAggressive: false,
    sampleMs: 12000,
  },
});

let started = false;
let currentProfile = PROFILES.performance;
let lastSnapshot = null;
let adaptations = 0;
let lastGpuProbe = null;

function heapMb() {
  const mem = typeof performance !== 'undefined' ? performance.memory : null;
  if (!mem?.usedJSHeapSize) return null;
  return {
    usedMb: Math.round(mem.usedJSHeapSize / (1024 * 1024)),
    totalMb: Math.round(mem.totalJSHeapSize / (1024 * 1024)),
    limitMb: Math.round(mem.jsHeapSizeLimit / (1024 * 1024)),
  };
}

function probeGpuTier() {
  if (lastGpuProbe && Date.now() - lastGpuProbe.at < 60000) return lastGpuProbe;
  let tier = 'unknown';
  let renderer = '';
  try {
    const canvas = document.createElement('canvas');
    const gl = canvas.getContext('webgl') || canvas.getContext('experimental-webgl');
    if (!gl) {
      tier = 'software';
    } else {
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      renderer = ext
        ? String(gl.getParameter(ext.UNMASKED_RENDERER_WEBGL) || '')
        : String(gl.getParameter(gl.RENDERER) || '');
      const low = renderer.toLowerCase();
      if (/swiftshader|llvmpipe|software|microsoft basic/i.test(low)) tier = 'software';
      else if (/intel|uhd|iris|vega|radeon graphics(?!.*(rx|pro))/i.test(low)) tier = 'integrated';
      else tier = 'discrete';
    }
  } catch {
    tier = 'unknown';
  }
  lastGpuProbe = { tier, renderer, at: Date.now() };
  return lastGpuProbe;
}

function readEngineOps() {
  try {
    const raw = window.Engine?.runtime?.getStateJson?.('performance');
    if (!raw) return null;
    const parsed = typeof raw === 'string' ? JSON.parse(raw) : raw;
    return parsed?.performance?.ops || null;
  } catch {
    return null;
  }
}

async function cacheMetrics() {
  try {
    const { ImageCache, VideoCache } = await import('../render/asset-cache.js');
    return {
      image: ImageCache.getMetrics?.() || { size: ImageCache._map?.size || 0 },
      video: VideoCache.getMetrics?.() || { size: VideoCache._map?.size || 0 },
      imageMax: ImageCache._maxSize || BUDGETS.imageCacheMax,
    };
  } catch {
    return { image: { size: 0 }, video: { size: 0 }, imageMax: BUDGETS.imageCacheMax };
  }
}

function chooseProfile({ heap, gpu, ops, live }) {
  const reasons = [];
  let pressure = 0;

  if (window.__SOMOSUM_LOW_SPEC) {
    pressure += 2;
    reasons.push('low-spec flag');
  }

  const cpu = Number(ops?.telemetry?.['cpu.processPercent']?.avg ?? ops?.cpu ?? 0);
  const ramWs = Number(ops?.telemetry?.['memory.workingSetMb']?.avg ?? 0);
  const memLoad = Number(ops?.telemetry?.['memory.systemLoadPercent']?.avg ?? 0);
  const gpuUsage = Number(ops?.telemetry?.['gpu.usagePercent']?.avg ?? -1);

  // Memória do dispositivo (Chrome) — ajusta sozinho sem checkbox do usuário
  let deviceMem = 0;
  try { deviceMem = Number(navigator.deviceMemory) || 0; } catch { /* ignore */ }
  if (deviceMem > 0 && deviceMem <= 2) { pressure += 3; reasons.push('RAM≤2GB'); }
  else if (deviceMem > 0 && deviceMem <= 4) { pressure += 2; reasons.push('RAM≤4GB'); }
  else if (deviceMem > 0 && deviceMem <= 8 && live) { pressure += 1; reasons.push('RAM≤8GB+live'); }

  // Várias superfícies WebView2 no culto = dois heaps Chromium
  if (live) {
    pressure += 1;
    reasons.push('projeção live');
  }

  if (cpu >= 75) { pressure += 2; reasons.push('cpu>=75%'); }
  else if (cpu >= 45) { pressure += 1; reasons.push('cpu>=45%'); }

  if (heap?.usedMb >= BUDGETS.screenHeapMb) { pressure += 2; reasons.push('heap alto'); }
  else if (heap?.usedMb >= BUDGETS.screenHeapMb * 0.75) { pressure += 1; reasons.push('heap médio'); }

  if (ramWs >= BUDGETS.processRamMb * 0.9 || memLoad >= 90) {
    pressure += 2; reasons.push('RAM crítica');
  } else if (ramWs >= BUDGETS.processRamMb * 0.7 || memLoad >= 75) {
    pressure += 1; reasons.push('RAM alta');
  }

  if (gpu?.tier === 'software') { pressure += 2; reasons.push('GPU software'); }
  else if (gpu?.tier === 'integrated') { pressure += 1; reasons.push('GPU integrada'); }
  if (gpuUsage >= 85) { pressure += 1; reasons.push('GPU uso alto'); }

  let name;
  if (live) {
    name = pressure >= 3 ? 'live-eco' : 'live';
  } else if (pressure >= 4) name = 'eco';
  else if (pressure >= 2) name = 'conservative';
  else name = 'performance';

  return {
    ...PROFILES[name],
    reason: reasons.join('; ') || 'estável',
    pressure,
    signals: { cpu, ramWs, memLoad, gpuUsage, heapUsedMb: heap?.usedMb ?? null, deviceMem },
  };
}

async function applyProfile(profile) {
  const prev = currentProfile?.name;
  currentProfile = profile;

  try {
    if (document.visibilityState === 'hidden') {
      TaskScheduler.setMode('hidden');
    } else if (profile.schedulerMode === 'background' && !window.__SOMOSUM_LIVE_ACTIVE) {
      TaskScheduler.setMode('background');
    } else {
      TaskScheduler.setMode('active');
    }
  } catch { /* ignore */ }

  try {
    const { ImageCache, VideoCache } = await import('../render/asset-cache.js');
    ImageCache._maxSize = profile.imageCacheMax;
    VideoCache._maxSize = Math.max(2, Math.round(profile.imageCacheMax / 8));
    if ((ImageCache._map?.size || 0) > profile.imageCacheMax) {
      ImageCache.trim?.(profile.imageCacheMax);
    }
  } catch { /* ignore */ }

  try {
    window.Engine?.runtime?.executeJson?.(JSON.stringify({
      type: 'UpdateOpsSignalsCommand',
      source: 'resource-governor',
      priority: 'Idle',
      payload: {
        openMediaCount: lastSnapshot?.caches?.image?.size || 0,
        jsHeapMb: lastSnapshot?.heap?.usedMb || 0,
        jsProfile: profile.name,
        gpuTier: lastSnapshot?.gpu?.tier || 'unknown',
      },
    }));
  } catch { /* engine opcional */ }

  if (prev && prev !== profile.name) {
    adaptations += 1;
    LogService.debug(`Resource profile: ${profile.name}`, {
      module: 'resource-governor',
      category: LogCategory.PERFORMANCE,
      detail: { reason: profile.reason, pressure: profile.pressure },
    });
    window.dispatchEvent(new CustomEvent('somosum-resource-profile', {
      detail: { profile: profile.name, reason: profile.reason },
    }));
  }
}

async function sample() {
  const heap = heapMb();
  const gpu = probeGpuTier();
  const ops = readEngineOps();
  const caches = await cacheMetrics();
  const live = !!window.__SOMOSUM_LIVE_ACTIVE;
  const profile = chooseProfile({ heap, gpu, ops, live });

  lastSnapshot = {
    ts: Date.now(),
    heap,
    gpu,
    caches,
    ops: ops ? {
      profile: ops.governor?.profile,
      cache: ops.cache,
      stability: ops.stability,
    } : null,
    profile: {
      name: profile.name,
      reason: profile.reason,
      pressure: profile.pressure,
      signals: profile.signals,
      adaptations,
    },
    scheduler: TaskScheduler.getMetrics?.() || {},
    budgets: BUDGETS,
  };

  if (profile.name !== currentProfile.name
    || profile.imageCacheMax !== currentProfile.imageCacheMax) {
    await applyProfile(profile);
  } else {
    currentProfile = profile;
  }

  TaskScheduler.setIntervalMs?.(TaskIds.RESOURCE_GOVERNOR, profile.sampleMs);
  return lastSnapshot;
}

export const ResourceGovernor = {
  budgets: BUDGETS,

  start() {
    if (started) return;
    started = true;
    TaskScheduler.register({
      id: TaskIds.RESOURCE_GOVERNOR,
      kind: 'interval',
      intervalMs: PROFILES.performance.sampleMs,
      priority: 8,
      runWhenHidden: true,
      fn: () => { void sample(); },
    });
    void sample();
  },

  stop() {
    started = false;
    TaskScheduler.unregister(TaskIds.RESOURCE_GOVERNOR);
  },

  async snapshot() {
    return sample();
  },

  getSnapshot() {
    return lastSnapshot;
  },

  getProfile() {
    return currentProfile;
  },

  forceProfile(name) {
    const p = PROFILES[name];
    if (!p) return false;
    void applyProfile({ ...p, reason: 'manual', pressure: 0, signals: {} });
    return true;
  },
};
