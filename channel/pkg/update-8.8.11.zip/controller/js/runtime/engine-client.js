/** Alias público — Somosum.Engine.dll client */
export { Runtime as Engine, Runtime } from './runtime-client.js';
