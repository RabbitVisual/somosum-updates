/** Google Drive backup — facade; OAuth/upload reais no plugin + API Kestrel. */

export async function getGoogleDriveStatus() {
  const res = await fetch('/api/integrations/google-drive/status', { cache: 'no-store' });
  if (!res.ok) return { connected: false };
  return res.json();
}

export async function startGoogleDriveBackup() {
  const res = await fetch('/api/integrations/google-drive/backup', { method: 'POST' });
  const data = await res.json().catch(() => ({}));
  if (!res.ok || !data.ok) throw new Error(data.error || 'backup_failed');
  return data;
}

/** @deprecated Use o plugin google-drive-backup (Loja). */
export function getGDriveBackupConfig() {
  return { enabled: false, deprecated: true, usePlugin: 'google-drive-backup' };
}

/** @deprecated */
export function setGDriveBackupConfig() {
  /* moved to SecureStorage via API */
}

/** @deprecated Manifest legado — o backup real sobe ZIP completo. */
export function buildBackupManifest() {
  return {
    paths: ['data/'],
    generatedAt: new Date().toISOString(),
    note: 'Use o plugin Google Drive Backup na Loja.',
  };
}

/** @deprecated */
export async function exportBackupBundle() {
  return startGoogleDriveBackup();
}
