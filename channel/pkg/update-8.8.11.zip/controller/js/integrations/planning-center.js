/**
 * Planning Center Online — import service order (OAuth stub + manual token).
 */

const STORAGE_KEY = 'SOMOSUM_PCO_CONFIG';

export function getPcoConfig() {
  try {
    return JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}');
  } catch {
    return {};
  }
}

export function savePcoConfig(cfg) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(cfg || {}));
}

export async function fetchPcoPlan(planId, { accessToken, subdomain } = {}) {
  const cfg = getPcoConfig();
  const token = accessToken || cfg.accessToken;
  const sub = subdomain || cfg.subdomain;
  if (!token || !sub) throw new Error('pco_not_configured');
  const url = `https://api.planningcenteronline.com/services/v2/service_types/${sub}/plans/${planId}/items`;
  const res = await fetch(url, {
    headers: { Authorization: `Bearer ${token}`, Accept: 'application/json' },
  });
  if (!res.ok) throw new Error('pco_fetch_failed');
  const data = await res.json();
  return normalizePcoItems(data);
}

function normalizePcoItems(data) {
  const items = data?.data || [];
  return items.map((it) => ({
    title: it.attributes?.title || 'Item',
    type: mapPcoType(it.attributes?.item_type),
    notes: it.attributes?.description || '',
  }));
}

function mapPcoType(t) {
  if (t === 'song') return 'lyrics';
  if (t === 'header') return 'section';
  return 'section';
}

export function openPcoSettings(container, { onSave } = {}) {
  const cfg = getPcoConfig();
  container.innerHTML = `
    <div class="integration-pco">
      <h3>Planning Center</h3>
      <label>Subdomain / Service Type ID<input id="pco-sub" value="${cfg.subdomain || ''}" /></label>
      <label>Access Token<input id="pco-token" type="password" value="${cfg.accessToken || ''}" /></label>
      <button type="button" id="pco-save" class="btn btn-primary">Salvar</button>
    </div>`;
  container.querySelector('#pco-save')?.addEventListener('click', () => {
    savePcoConfig({
      subdomain: container.querySelector('#pco-sub')?.value?.trim(),
      accessToken: container.querySelector('#pco-token')?.value?.trim(),
    });
    onSave?.();
  });
}
