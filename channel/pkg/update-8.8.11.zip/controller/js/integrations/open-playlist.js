/** OpenPlaylist XML import (Holyrics OpenPlaylist parity). */

export async function parseOpenPlaylistXml(text) {
  const doc = new DOMParser().parseFromString(text, 'application/xml');
  if (doc.querySelector('parsererror')) throw new Error('invalid_xml');
  const items = [...doc.querySelectorAll('item, song, playlist > *')];
  return items.map((el) => ({
    title: textContent(el, 'title,name') || el.getAttribute('title') || 'Item',
    artist: textContent(el, 'artist,author') || '',
    lyrics: textContent(el, 'lyrics,text,content') || '',
    type: el.getAttribute('type') || 'lyrics',
  })).filter((i) => i.title || i.lyrics);
}

function textContent(el, selectors) {
  for (const sel of selectors.split(',')) {
    const n = el.querySelector(sel.trim());
    if (n?.textContent?.trim()) return n.textContent.trim();
  }
  return el.textContent?.trim() || '';
}

export async function importOpenPlaylistFile(file) {
  const text = await file.text();
  return parseOpenPlaylistXml(text);
}
