/** Modos de exibição do slide Mensagem — inspetor, wizard, projeção e programa. */
export const MESSAGE_DISPLAY_MODES = [
  {
    id: 'tema_ref',
    label: 'Tema + referência (sem pregador)',
    hint: 'Somente tema e referência bíblica na tela — ideal para introito ou mensagem sem nome do pregador.',
    showTheme: true,
    showReference: true,
    showPreacher: false,
    wholeChapter: false,
    showMottoSection: true,
  },
  {
    id: 'ref_pregador',
    label: 'Referência + pregador',
    hint: 'Referência bíblica e nome do pregador — sem tema na tela. Foto opcional.',
    showTheme: false,
    showReference: true,
    showPreacher: true,
    wholeChapter: false,
    showMottoSection: true,
  },
  {
    id: 'tema_ref_pregador',
    label: 'Tema + referência + pregador',
    hint: 'Tema, referência e pregador. Desmarque a foto se quiser só nome e local.',
    showTheme: true,
    showReference: true,
    showPreacher: true,
    wholeChapter: false,
    showMottoSection: true,
  },
  {
    id: 'tema_capitulo_pregador',
    label: 'Tema + capítulo inteiro + pregador',
    hint: 'Tema, referência do capítulo completo e pregador — versículos individuais ficam ocultos.',
    showTheme: true,
    showReference: true,
    showPreacher: true,
    wholeChapter: true,
    showMottoSection: false,
  },
  {
    id: 'tema_pregador',
    label: 'Tema + pregador (sem referência)',
    hint: 'Somente tema e nome do pregador — ideal quando não há referência bíblica na tela.',
    showTheme: true,
    showReference: false,
    showPreacher: true,
    wholeChapter: false,
    showMottoSection: false,
  },
];

export const PREACHER_ROLES = [
  { id: 'pregador', label: 'Pregador' },
  { id: 'pregadora', label: 'Pregadora' },
  { id: 'pastor', label: 'Pastor' },
  { id: 'pastora', label: 'Pastora' },
  { id: 'expositor', label: 'Expositor' },
  { id: 'expositora', label: 'Expositora' },
  { id: 'evangelista', label: 'Evangelista' },
  { id: 'missionario', label: 'Missionário' },
  { id: 'missionaria', label: 'Missionária' },
  { id: 'convidado', label: 'Convidado' },
  { id: 'convidada', label: 'Convidada' },
];

export const MESSAGE_CARD_TEMPLATES = [
  { id: 'horizontal', label: 'Ficha', hint: 'Foto à esquerda' },
  { id: 'portrait', label: 'Retrato', hint: 'Foto circular' },
  { id: 'editorial', label: 'Editorial', hint: 'Foto retangular' },
  { id: 'banner', label: 'Faixa', hint: 'Barra inferior' },
  { id: 'split', label: 'Split', hint: 'Painel partido' },
  { id: 'minimal', label: 'Minimal', hint: 'Nome limpo' },
];

export function preacherRoleLabel(roleId) {
  return PREACHER_ROLES.find((r) => r.id === roleId)?.label || 'Pregador';
}

export function preacherRolesHtml(selected = 'pregador') {
  const cur = selected || 'pregador';
  return PREACHER_ROLES.map(
    (r) => `<option value="${r.id}" ${r.id === cur ? 'selected' : ''}>${r.label}</option>`
  ).join('');
}

export function messageCardTemplatesHtml(selected = 'horizontal') {
  const cur = selected || 'horizontal';
  return MESSAGE_CARD_TEMPLATES.map((t) => `
    <button type="button" class="msg-card-tpl ${t.id === cur ? 'is-on' : ''}" data-msg-card-tpl="${t.id}" title="${t.hint}" aria-pressed="${t.id === cur ? 'true' : 'false'}">
      <span class="msg-card-tpl-preview msg-card-tpl-preview--${t.id}"></span>
      <span class="msg-card-tpl-name">${t.label}</span>
    </button>`).join('');
}

export function readMessageCardTemplate(el, fallback = 'horizontal') {
  const on = el?.querySelector?.('.msg-card-tpl.is-on')?.getAttribute('data-msg-card-tpl');
  if (on && MESSAGE_CARD_TEMPLATES.some((t) => t.id === on)) return on;
  const radio = el?.querySelector?.('input[name="insp-msg-card-tpl"]:checked')?.value;
  if (radio && MESSAGE_CARD_TEMPLATES.some((t) => t.id === radio)) return radio;
  return fallback || 'horizontal';
}

function flagOr(data, key, fallback) {
  if (data[key] === true) return true;
  if (data[key] === false) return false;
  return fallback;
}

/** Blocos visíveis na projeção — checkboxes do inspetor, com fallback do modo antigo. */
export function resolveMessageBlocks(data = {}) {
  const mode = getMessageMode(data.messageMode);
  return {
    showTheme: flagOr(data, 'showTheme', mode.showTheme),
    showReference: flagOr(data, 'showReference', mode.showReference),
    showMotto: data.showMotto !== false,
    showPreacher: flagOr(data, 'showPreacher', mode.showPreacher),
    showPreacherFrom: flagOr(data, 'showPreacherFrom', true),
    showPreacherPhoto: resolveShowPreacherPhoto(data),
    wholeChapter: flagOr(data, 'wholeChapter', !!mode.wholeChapter),
  };
}

export function inferMessageMode(blocks = {}) {
  if (blocks.showTheme && blocks.showReference && blocks.showPreacher && blocks.wholeChapter) {
    return 'tema_capitulo_pregador';
  }
  if (blocks.showTheme && !blocks.showReference && blocks.showPreacher) return 'tema_pregador';
  if (!blocks.showTheme && blocks.showReference && blocks.showPreacher) return 'ref_pregador';
  if (blocks.showTheme && blocks.showReference && !blocks.showPreacher) return 'tema_ref';
  return 'tema_ref_pregador';
}

export function getMessageMode(modeId) {
  return MESSAGE_DISPLAY_MODES.find((m) => m.id === modeId)
    || MESSAGE_DISPLAY_MODES.find((m) => m.id === 'ref_pregador')
    || MESSAGE_DISPLAY_MODES[0];
}

export function messageModeOptionsHtml(selected = 'ref_pregador') {
  return MESSAGE_DISPLAY_MODES.map(
    (m) => `<option value="${m.id}" ${selected === m.id ? 'selected' : ''}>${m.label}</option>`
  ).join('');
}

export function resolveShowPreacherPhoto(data = {}) {
  if (data.showPreacherPhoto === false) return false;
  if (data.showPreacherPhoto === true) return true;
  return !!data.preacherPhotoId;
}

function setDisplay(node, visible) {
  if (node) node.style.display = visible ? '' : 'none';
}

/** Inspetor — tamanhos conforme checkboxes (campos sempre visíveis). */
export function applyMessageInspectorModeUI(el, modeId) {
  if (!el) return;
  const hasBlocks = !!el.querySelector('#insp-msg-show-theme');
  if (hasBlocks) {
    applyMessageInspectorBlocksUI(el);
    return;
  }
  const mode = getMessageMode(modeId);
  setDisplay(el.querySelector('#insp-msg-theme-wrap'), mode.showTheme);
  setDisplay(el.querySelector('#insp-msg-bible-wrap'), mode.showReference);
  setDisplay(el.querySelector('#insp-msg-motto-wrap'), mode.showMottoSection);
  setDisplay(el.querySelector('#insp-msg-verses-wrap'), mode.showReference && !mode.wholeChapter);
  setDisplay(el.querySelector('#insp-msg-verse-end-wrap'), mode.showReference && !mode.wholeChapter);
  setDisplay(el.querySelector('#insp-msg-preacher-wrap'), mode.showPreacher);
  setDisplay(el.querySelector('#insp-msg-photo-wrap'), mode.showPreacher);
  setDisplay(el.querySelector('#insp-msg-preacher-size-group'), mode.showPreacher);
  setDisplay(el.querySelector('#insp-msg-from-size-group'), mode.showPreacher);
  setDisplay(el.querySelector('#insp-msg-theme-size-group'), mode.showTheme);
  setDisplay(el.querySelector('#insp-msg-ref-size-group'), mode.showReference);
  setDisplay(el.querySelector('#insp-msg-motto-size-group'), mode.showMottoSection);
  setDisplay(el.querySelector('#insp-msg-text-size-group'), mode.showReference);
  const hint = el.querySelector('#insp-msg-mode-hint');
  if (hint) hint.textContent = mode.hint;
}

export function applyMessageInspectorBlocksUI(el) {
  if (!el) return;
  const showTheme = el.querySelector('#insp-msg-show-theme')?.checked !== false;
  const showRef = el.querySelector('#insp-msg-show-ref')?.checked !== false;
  const showMotto = el.querySelector('#insp-msg-show-motto')?.checked !== false;
  const showPreacher = el.querySelector('#insp-msg-show-preacher')?.checked !== false;
  const showFrom = el.querySelector('#insp-msg-show-from')?.checked !== false;
  const whole = !!el.querySelector('#insp-msg-whole-chapter')?.checked;
  setDisplay(el.querySelector('#insp-msg-theme-size-group'), showTheme);
  setDisplay(el.querySelector('#insp-msg-ref-size-group'), showRef);
  setDisplay(el.querySelector('#insp-msg-motto-size-group'), showMotto);
  setDisplay(el.querySelector('#insp-msg-text-size-group'), showRef);
  setDisplay(el.querySelector('#insp-msg-preacher-size-group'), showPreacher);
  setDisplay(el.querySelector('#insp-msg-from-size-group'), showPreacher && showFrom);
  setDisplay(el.querySelector('#insp-msg-verses-wrap'), showRef && !whole);
  setDisplay(el.querySelector('#insp-msg-verse-end-wrap'), showRef && !whole);
  setDisplay(el.querySelector('#insp-msg-card-tpl-wrap'), showPreacher);
}

/** Wizard de adicionar slide Mensagem. */
export function applyMessageWizardModeUI(modal, modeId) {
  if (!modal) return;
  const mode = getMessageMode(modeId);

  setDisplay(modal.querySelector('#wiz-theme-wrap'), mode.showTheme);
  setDisplay(modal.querySelector('#wiz-bible-wrap'), mode.showReference);
  setDisplay(modal.querySelector('#wiz-msg-motto-wrap'), mode.showMottoSection);
  setDisplay(modal.querySelector('#wiz-preacher-wrap'), mode.showPreacher);

  const hint = modal.querySelector('#wiz-msg-mode-hint');
  if (hint) hint.textContent = mode.hint;
}

export function syncMessagePhotoInspectorUI(el) {
  if (!el) return;
  const photoId = el.querySelector('#insp-msg-photo')?.value;
  const showChk = el.querySelector('#insp-msg-show-photo');
  // Sem foto escolhida: não força desmarcar (operador pode marcar antes de escolher).
  // Sem círculo vazio na projeção — o render só desenha img se houver preacherPhoto.
  const wantShow = !!showChk?.checked;
  const showPhoto = wantShow && !!photoId;
  setDisplay(el.querySelector('#insp-msg-photo-size-wrap'), showPhoto);
  const showPreacher = el.querySelector('#insp-msg-show-preacher')?.checked !== false;
  setDisplay(el.querySelector('#insp-msg-card-width-block'), showPreacher);
}
