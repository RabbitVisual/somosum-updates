import { formatReference } from '../../../bible/bible-service.js';
import { esc, escAttr, rawHtml, setHtml } from '../../../core/render-engine/index.js';
import { parseScriptBlocks } from '../../utils/sermon-script.js';
import { inferMessageMode, readMessageCardTemplate } from '../../../slides/message-display-modes.js';
import { bindFontPickerPair, readFontPickerPair } from '../../../core/font-picker-ui.js';

export const messageInspectorFields = {
  updateMessagePhotoPreview(el) {
    const preview = el.querySelector('#insp-msg-photo-preview');
    const photoId = el.querySelector('#insp-msg-photo')?.value;
    if (!preview) return;
    if (!photoId) {
      setHtml(preview, '<span class="msg-photo-placeholder">Sem foto</span>');
      return;
    }
    const media = this.mediaList.find((m) => m.id === photoId);
    if (media?.dataUrl) {
      setHtml(preview, rawHtml(`<img src="${escAttr(media.dataUrl)}" alt="" />`));
    } else {
      setHtml(preview, '<span class="msg-photo-placeholder">Foto na aba Mídia</span>');
    }
  },

  readMessageInspectorStyle(el, prev = {}) {
    return {
      fontSize: Number(el.querySelector('#insp-msg-font-readout')?.textContent) || prev.fontSize || 80,
      refSize: Number(el.querySelector('#insp-msg-ref-readout')?.textContent) || prev.refSize || 34,
      textSize: Number(el.querySelector('#insp-msg-text-readout')?.textContent) || prev.textSize || 30,
      preacherSize: Number(el.querySelector('#insp-msg-preacher-readout')?.textContent) || prev.preacherSize || 32,
      fromSize: Number(el.querySelector('#insp-msg-from-readout')?.textContent) || prev.fromSize || 22,
      photoSize: Number(el.querySelector('#insp-msg-photo-readout')?.textContent) || prev.photoSize || 200,
      contentWidth: Number(el.querySelector('#insp-msg-content-width')?.value) || prev.contentWidth || 94,
      layout: el.querySelector('#insp-msg-layout')?.value || prev.layout || 'balanced',
      align: el.querySelector('#insp-msg-align')?.value || prev.align || 'left',
      cardTemplate: readMessageCardTemplate(el, prev.cardTemplate || 'horizontal'),
      ...readFontPickerPair(el, {
        familySelector: '#insp-msg-font',
        variantSelector: '#insp-msg-font-variant',
      }),
      textTransform: el.querySelector('#insp-msg-transform')?.value || 'none',
      showLabels: el.querySelector('#insp-msg-labels')?.checked !== false,
      cardWidth: Number(el.querySelector('#insp-msg-card-width')?.value) || prev.cardWidth || 36,
      mottoSize: Number(el.querySelector('#insp-msg-motto-readout')?.textContent) || prev.mottoSize || prev.textSize || 30,
      titleColor: el.querySelector('#insp-msg-title-color')?.value || prev.titleColor || null,
      textColor: el.querySelector('#insp-msg-text-color')?.value || prev.textColor || null,
      refColor: el.querySelector('#insp-msg-ref-color')?.value || prev.refColor || null,
      ...this.readSlideLegibilityStyle(el, 'insp-msg'),
      ...this.readSlideBackgroundStyle(el, 'insp-msg'),
    };
  },

  readMessageBibleRef(el) {
    const picker = el._messageBiblePicker;
    if (picker?.readValues) return picker.readValues();
    return {
      version: el.querySelector('#insp-msg-ver')?.value || this.prefs.bibleVersion || 'naa',
      book: el.querySelector('#insp-msg-book')?.value,
      chapter: Number(el.querySelector('#insp-msg-ch')?.value) || 1,
      verseStart: Number(el.querySelector('#insp-msg-vs')?.value) || 1,
      verseEnd: Number(el.querySelector('#insp-msg-ve')?.value) || Number(el.querySelector('#insp-msg-vs')?.value) || 1,
    };
  },

  updateMessageRefPreview(el) {
    const preview = el.querySelector('#insp-msg-ref-preview');
    if (!preview) return;
    const ref = this.readMessageBibleRef(el);
    const override = el.querySelector('#insp-msg-ref-override')?.value?.trim();
    const showVersion = el.querySelector('#insp-msg-show-version')?.checked !== false;
    const refStyle = el.querySelector('#insp-msg-ref-style')?.value || 'colon';
    if (override) {
      preview.textContent = override;
      return;
    }
    if (!ref.book || !ref.chapter) {
      preview.textContent = '—';
      return;
    }
    preview.textContent = formatReference(
      ref.book,
      ref.chapter,
      ref.verseStart,
      ref.verseEnd,
      ref.version,
      { style: refStyle, showVersion }
    );
  },

  resolveMessageItemTitle(item, rawTitle = '') {
    const t = (rawTitle || item?.title || '').trim();
    if (/^M[uú]sica\s*\d*\s*[—–-]\s*Louvor$/i.test(t) || t === 'Louvor') {
      const preacher = item?.data?.preacher?.trim();
      return preacher ? `Mensagem — ${preacher}` : 'Mensagem Bíblica';
    }
    return t || 'Mensagem Bíblica';
  },

  readMessageInspectorData(el, item) {
    const prevStyle = item?.data?.style || {};
    const showTheme = !!el.querySelector('#insp-msg-show-theme')?.checked;
    const showReference = !!el.querySelector('#insp-msg-show-ref')?.checked;
    const showPreacher = !!el.querySelector('#insp-msg-show-preacher')?.checked;
    const showPreacherFrom = !!el.querySelector('#insp-msg-show-from')?.checked;
    const wholeChapter = !!el.querySelector('#insp-msg-whole-chapter')?.checked;
    const messageMode = inferMessageMode({
      showTheme, showReference, showPreacher, wholeChapter,
    });
    const ref = this.readMessageBibleRef(el);
    const scriptRaw = el.querySelector('#insp-msg-script')?.value || '';
    const photoId = el.querySelector('#insp-msg-photo')?.value || null;
    const showPhotoChecked = !!el.querySelector('#insp-msg-show-photo')?.checked && !!photoId;
    return {
      messageMode,
      showTheme,
      showReference,
      showPreacher,
      showPreacherFrom,
      wholeChapter,
      theme: el.querySelector('#insp-msg-theme')?.value || '',
      mottoText: el.querySelector('#insp-msg-motto')?.value || '',
      showMotto: el.querySelector('#insp-msg-show-motto')?.checked !== false,
      referenceOverride: el.querySelector('#insp-msg-ref-override')?.value?.trim() || '',
      refStyle: el.querySelector('#insp-msg-ref-style')?.value || 'colon',
      preacherRole: el.querySelector('#insp-msg-role')?.value || 'pregador',
      preacher: el.querySelector('#insp-msg-preacher')?.value || '',
      preacherFrom: el.querySelector('#insp-msg-from')?.value || '',
      preacherPhotoId: photoId,
      showPreacherPhoto: showPhotoChecked,
      showVersion: el.querySelector('#insp-msg-show-version')?.checked !== false,
      scriptRaw,
      scriptBlocks: parseScriptBlocks(scriptRaw),
      style: this.readMessageInspectorStyle(el, prevStyle),
      bible: {
        version: ref.version,
        book: ref.book,
        chapter: ref.chapter,
        verseStart: wholeChapter ? 1 : ref.verseStart,
        verseEnd: wholeChapter ? 999 : ref.verseEnd,
        wholeChapter,
        referenceOverride: el.querySelector('#insp-msg-ref-override')?.value?.trim() || '',
        refStyle: el.querySelector('#insp-msg-ref-style')?.value || 'colon',
      },
    };
  },

  bindMessageSizeStep(el, meta, minusId, plusId, readoutSel, min, max, step) {
    const readout = el.querySelector(readoutSel);
    const sync = () => meta && this.scheduleInspectorLiveSync(meta, el, 120);
    el.querySelector(minusId)?.addEventListener('click', () => {
      readout.textContent = Math.max(min, (Number(readout.textContent) || min) - step);
      sync();
    });
    el.querySelector(plusId)?.addEventListener('click', () => {
      readout.textContent = Math.min(max, (Number(readout.textContent) || min) + step);
      sync();
    });
  },

  bindMessageInspectorToolbar(el, meta) {
    const live = () => this.scheduleInspectorLiveSync(meta, el, 120);
    this.bindMessageSizeStep(el, meta, '#insp-msg-font-minus', '#insp-msg-font-plus', '#insp-msg-font-readout', 32, 140, 4);
    this.bindMessageSizeStep(el, meta, '#insp-msg-ref-minus', '#insp-msg-ref-plus', '#insp-msg-ref-readout', 18, 80, 2);
    this.bindMessageSizeStep(el, meta, '#insp-msg-text-minus', '#insp-msg-text-plus', '#insp-msg-text-readout', 18, 80, 2);
    this.bindMessageSizeStep(el, meta, '#insp-msg-motto-minus', '#insp-msg-motto-plus', '#insp-msg-motto-readout', 18, 80, 2);
    this.bindMessageSizeStep(el, meta, '#insp-msg-preacher-minus', '#insp-msg-preacher-plus', '#insp-msg-preacher-readout', 16, 72, 2);
    this.bindMessageSizeStep(el, meta, '#insp-msg-from-size-minus', '#insp-msg-from-size-plus', '#insp-msg-from-readout', 14, 48, 1);
    this.bindMessageSizeStep(el, meta, '#insp-msg-photo-minus', '#insp-msg-photo-plus', '#insp-msg-photo-readout', 100, 360, 10);
    bindFontPickerPair(el, {
      familySelector: '#insp-msg-font',
      variantSelector: '#insp-msg-font-variant',
      onChange: live,
    });
    ['#insp-msg-layout', '#insp-msg-align', '#insp-msg-transform', '#insp-msg-labels', '#insp-msg-show-version', '#insp-msg-show-motto', '#insp-msg-ref-style', '#insp-msg-show-photo', '#insp-msg-show-theme', '#insp-msg-show-ref', '#insp-msg-show-preacher', '#insp-msg-show-from', '#insp-msg-whole-chapter', '#insp-msg-role'].forEach((sel) => {
      el.querySelector(sel)?.addEventListener('change', live);
    });
    el.querySelector('.msg-card-templates')?.addEventListener('click', (ev) => {
      const btn = ev.target?.closest?.('.msg-card-tpl');
      if (!btn || !el.querySelector('.msg-card-templates')?.contains(btn)) return;
      ev.preventDefault();
      el.querySelectorAll('.msg-card-tpl').forEach((lab) => {
        const on = lab === btn;
        lab.classList.toggle('is-on', on);
        lab.setAttribute('aria-pressed', on ? 'true' : 'false');
      });
      live();
    });
    el.querySelector('#insp-msg-content-width')?.addEventListener('input', live);
    el.querySelector('#insp-msg-card-width')?.addEventListener('input', live);
    el.querySelector('#insp-msg-ref-override')?.addEventListener('input', () => {
      this.updateMessageRefPreview(el);
      live();
    });
    el.querySelector('#insp-msg-motto')?.addEventListener('input', () => {
      this.scheduleInspectorLiveSync(meta, el, 350);
    });
    el.querySelector('#insp-msg-motto')?.addEventListener('blur', live);
    this.bindSlideLegibilityControls(el, meta, { idPrefix: 'insp-msg' });
    ['#insp-msg-title-color', '#insp-msg-text-color', '#insp-msg-ref-color'].forEach((sel) => {
      el.querySelector(sel)?.addEventListener('input', live);
      el.querySelector(sel)?.addEventListener('change', live);
    });
  },
};
