import { renderPreview } from '../../slides/slide-engine.js';
import { formatCountdownDigits } from '../../core/countdown.js';
import { savePrefs } from '../../core/store.js';
import { esc, escAttr, rawHtml, setHtml } from '../../core/render-engine/index.js';
import { resolvePreviewFitFrame, refitStagePreviewContainer } from '../../ui/stage-preview-fit.js';
import { RenderScheduler } from '../../core/render-scheduler.js';
import { updateLiveDockHint } from '../views/live-preview-dock.js';
import { isLiveProgramView } from '../views/live-console-view.js';
import { isLiveLouvorFocus, renderLiveLouvorWorkspace } from '../views/live-louvor-workspace.js';
import { faIconRaw, faIcon } from '../../core/fa-icons.js';

/** Hub único de resize para preview e projeção no controle. */
export const PreviewFitHub = {
  ensureSet() {
    if (typeof window === 'undefined') return null;
    if (!window.__SOMOSUM_PREVIEW_FIT_SET) {
      window.__SOMOSUM_PREVIEW_FIT_SET = new Set();
      let pending = false;
      window.addEventListener('resize', () => {
        if (pending) return;
        pending = true;
        requestAnimationFrame(() => {
          pending = false;
          window.__SOMOSUM_PREVIEW_FIT_SET.forEach((fn) => { try { fn(); } catch { /* */ } });
        });
      }, { passive: true });
    }
    return window.__SOMOSUM_PREVIEW_FIT_SET;
  },
  register(fn) {
    const set = this.ensureSet();
    if (!set || typeof fn !== 'function') return () => {};
    set.add(fn);
    return () => set.delete(fn);
  },
};

/** Preview do palco — extraído de control-app */
export function wirePreviewService() {
  return {
      updatePreviewBadge() {
        const badge = document.getElementById('preview-badge');
        if (badge) {
          if (this.isCountdownLive()) {
            badge.textContent = '⏱ PRÉ-CULTO';
            badge.classList.add('is-live', 'is-countdown');
            return;
          }
          badge.classList.remove('is-countdown');
          badge.textContent = this.autoLive ? '● NO AR' : 'Pré-visualização';
          badge.classList.toggle('is-live', this.autoLive);
        }
        if (!this.isCountdownLive()) {
          this.clearCountdownPreviewOverlay();
        }
      },

      setPreviewHtml(container, slide) {
        if (!container) return;
        const commit = () => {
          void this._commitPreviewHtml(container, slide);
        };
        if (window.__SOMOSUM_LIVE_ACTIVE) {
          RenderScheduler.markDirty('preview', { full: commit, priority: 'live' });
          return;
        }
        commit();
      },

      async _commitPreviewHtml(container, slide) {
        const lowSpec = !!(this.prefs?.ui?.lowSpec || this.prefs?.lowSpec || window.__SOMOSUM_LOW_SPEC);
        const useBitmap = lowSpec
          || this.prefs?.render?.previewMode === 'bitmap'
          || (window.__SOMOSUM_LIVE_ACTIVE && lowSpec);
        if (useBitmap && slide) {
          try {
            const { paintPreviewBitmap } = await import('../preview-bitmap.js');
            const ok = await paintPreviewBitmap(container, slide, {
              ...this.prefs,
              render: { ...(this.prefs?.render || {}), previewMode: 'bitmap' },
            });
            if (ok) return;
          } catch { /* fallback DOM */ }
        }
        const urls = this.getAssetUrls();
        setHtml(container, rawHtml(`<div class="preview-scaler" id="preview-scaler">${renderPreview(slide, this.defaults, this.prefs, urls)}</div>`));
        const scaler = container.querySelector('#preview-scaler');
        const stage = scaler?.querySelector('.screen-stage');
        if (stage) {
          stage.dataset.transition = slide?.transition || this.prefs.transition || 'fade';
        }
        const fitAll = () => {
          refitStagePreviewContainer(container);
        };
        let fitPending = false;
        const scheduleFit = () => {
          if (fitPending) return;
          fitPending = true;
          requestAnimationFrame(() => {
            fitPending = false;
            fitAll();
          });
        };
        scheduleFit();
        if (!container._previewFitRegistered && typeof window !== 'undefined') {
          const fitFn = () => scheduleFit();
          container._previewFitDispose = PreviewFitHub.register(fitFn);
          container._previewFitRegistered = true;
          const observeEl = resolvePreviewFitFrame(container) || container;
          if (typeof ResizeObserver !== 'undefined' && !container._previewFitObs) {
            container._previewFitObs = new ResizeObserver(fitFn);
            container._previewFitObs.observe(observeEl);
          }
        }
      },

      refreshStage(options = {}) {
        const { skipInspector = false, liveEdit = false } = options;
        if (isLiveLouvorFocus(this) && !options.forceProgram) {
          void renderLiveLouvorWorkspace(this);
          return;
        }
        this.clearCountdownPreviewOverlay();
        const items = this.program.items;
        let slide = this.getProjectorSlide();
        if (!slide && this._lastKnownSlide) slide = this._lastKnownSlide;
        else if (slide) this._lastKnownSlide = slide;
        if (slide?.type === 'bible-interlinear' && this.interlinearView) {
          slide = { ...slide, liveView: { ...this.interlinearView } };
        }
        const meta = this.program.getCurrentMeta();

        // Inspetor primeiro quando solicitado — propriedades não esperam a prévia
        if (!skipInspector && isLiveProgramView(this.view)) {
          this.renderInspector(meta);
        }

        if (!items.length && !this.bibleReader?.isLive && !this._mediaOnAir) {
          const container = document.getElementById('stage-preview');
          if (container) {
            setHtml(container, `
              <div class="program-empty-state">
                <h3>Nada no ar</h3>
                <p>Monte a ordem do culto ou projete mídia / leitura bíblica.</p>
                <button type="button" class="btn btn-primary" id="btn-empty-add">Ir ao Programa</button>
              </div>`);
            container.querySelector('#btn-empty-add')?.addEventListener('click', () => {
              this.setView?.('live');
            });
          }
          const info = document.getElementById('stage-info');
          if (info) info.textContent = 'Ordem vazia';
          const counter = document.getElementById('stage-counter');
          if (counter) counter.textContent = '0/0';
          const fill = document.getElementById('progress-fill');
          if (fill) fill.style.width = '0%';
          document.querySelectorAll('.rundown-item').forEach((el) => el.classList.remove('is-live'));
          document.getElementById('slide-strip')?.replaceChildren();
          this.updatePreviewBadge();
          updateLiveDockHint(this);
          return;
        }

        const container = document.getElementById('stage-preview');
        if (container && slide) {
          const isLyricsSlide = slide.type === 'lyrics' || slide.type === 'lyrics-title';
          const useLive = liveEdit || (isLyricsSlide && typeof this.setPreviewHtmlLive === 'function');
          if (useLive && typeof this.setPreviewHtmlLive === 'function') {
            this.setPreviewHtmlLive(container, slide);
          } else {
            this.setPreviewHtml(container, slide);
          }
          if (this.isCountdownLive()) {
            this.clearCountdownPreviewOverlay();
            const remaining = Math.max(0, this.getCountdownState().targetMs - Date.now());
            const { display } = formatCountdownDigits(remaining);
            const phase = this.getCountdownState().phase;
            const phaseLabel = phase === 'announce' ? 'Avisos finais' : phase === 'transition' ? 'Entrando no culto…' : 'Contagem regressiva';
            const overlay = document.createElement('div');
            overlay.className = 'countdown-preview-overlay';
            setHtml(overlay, `
              <div class="countdown-preview-overlay-inner">
                <span class="countdown-preview-badge">⏱ Pré-culto no projetor — preview local do slide</span>
                <span class="countdown-preview-time-sm">${esc(display)}</span>
                <span class="countdown-preview-phase-sm">${esc(phaseLabel)}</span>
                <button type="button" class="btn btn-secondary btn-sm" id="btn-stop-countdown-preview">Parar pré-culto</button>
              </div>`);
            container.appendChild(overlay);
            overlay.querySelector('#btn-stop-countdown-preview')?.addEventListener('click', () => this.stopCountdown());
          }
        } else if (container) {
          this.setPreviewHtml(container, slide);
        }

        const info = document.getElementById('stage-info');
        if (info && this.bibleReader?.isLive) {
          const rp = this.bibleReader.getState()?.readerProgress;
          setHtml(info, rawHtml(`<b>Leitura bíblica</b> · ${esc(rp?.chapterTitle || '')} · slide ${(rp?.index ?? 0) + 1}/${rp?.total || '?'}`));
        } else if (info && this._mediaOnAir) {
          setHtml(info, rawHtml(`<b>Mídia</b> · ${esc(this._mediaOnAir.title || 'No ar')}`));
        } else if (info && meta) {
          setHtml(info, rawHtml(`<b>${esc(meta.itemTitle)}</b> · slide ${meta.slideIndex + 1}`));
        } else if (info) info.textContent = '—';

        const counter = document.getElementById('stage-counter');
        if (counter && this.bibleReader?.isLive) {
          const rp = this.bibleReader.getState()?.readerProgress;
          counter.textContent = `${(rp?.index ?? 0) + 1}/${rp?.total || '?'}`;
        } else if (counter && this._mediaOnAir) {
          counter.textContent = 'Mídia';
        } else if (counter) {
          counter.textContent = `${this.program.currentIndex + 1} / ${this.program.flatSlides.length || 0}`;
        }

        const fill = document.getElementById('progress-fill');
        if (fill && this.bibleReader?.isLive) {
          const rp = this.bibleReader.getState()?.readerProgress;
          const total = rp?.total || 1;
          fill.style.width = `${(((rp?.index ?? 0) + 1) / total) * 100}%`;
        } else if (fill && this.program.flatSlides.length) {
          fill.style.width = `${((this.program.currentIndex + 1) / this.program.flatSlides.length) * 100}%`;
        }

        document.querySelectorAll('.rundown-item').forEach((el) => {
          el.classList.toggle('is-live', Number(el.dataset.index) === meta?.itemIndex);
        });

        if (!liveEdit) {
          this.renderSlideStrip(meta);
        } else {
          this.updateSlideStripActive(meta);
        }
        if (isLiveProgramView(this.view)) this.renderLookahead?.();
        if (this.view === 'live') {
          this.renderLiveSequenceHeader?.();
          this.renderLiveSequenceBlocks?.();
          this._liveLibrary?.refreshOrdem?.();
        }
        this.updatePreviewBadge();
        updateLiveDockHint(this);
        this.renderOverlayPanel?.();
        this.syncLiveDockVisibility?.();
      },

      /** Atualiza só .is-active na strip durante navegação live (sem recriar chips). */
      updateSlideStripActive(meta) {
        const strip = document.getElementById('slide-strip');
        if (!strip || !meta) {
          this.renderSlideStrip(meta);
          return;
        }
        const chips = strip.querySelectorAll('.slide-chip');
        if (!chips.length) {
          this.renderSlideStrip(meta);
          return;
        }
        const range = this.program.getItemSlideRange(meta.itemIndex);
        if (!range?.length || chips.length !== range.length) {
          this.renderSlideStrip(meta);
          return;
        }
        chips.forEach((btn) => {
          const local = Number(btn.dataset.local);
          btn.classList.toggle('is-active', local === meta.slideIndex);
        });
      },

      renderSlideStrip(meta) {
        const strip = document.getElementById('slide-strip');
        const label = document.getElementById('slide-strip-label');
        const stripArea = strip?.closest('.slide-strip-area');
        if (!strip || !label || !meta) {
          strip?.replaceChildren();
          stripArea?.classList.remove('is-lyrics-delegated');
          return;
        }

        const item = this.program.items[meta.itemIndex];
        const range = this.program.getItemSlideRange(meta.itemIndex);
        const multi = range.length > 1;
        const isLyrics = item?.slideType === 'lyrics';
        const isBible = item?.slideType === 'bible';
        const isCommunion = item?.slideType === 'communion';
        const hasLiveSequence = !!document.getElementById('lc-sequence-blocks');

        // Live Console: sequência acima cuida do louvor — footer limpo (sem miniaturas duplicadas)
        if (isLyrics && hasLiveSequence) {
          strip.replaceChildren();
          label.replaceChildren();
          label.textContent = '';
          stripArea?.classList.add('is-lyrics-delegated');
          return;
        }
        stripArea?.classList.remove('is-lyrics-delegated');

        if (!multi || (!isLyrics && !isBible && !isCommunion)) {
          strip.replaceChildren();
          label.textContent = range.length === 1 ? 'Slide único' : '';
          return;
        }

        const lyricsMode = this.prefs.slideStripLyricsMode === 'snippets' ? 'snippets' : 'numbers';
        if (isLyrics) {
          setHtml(label, rawHtml(`
            <span>${faIconRaw('music', 'su-fa su-fa--sm')} Partes do louvor — capa · clique prepara no controle</span>
            <button type="button" class="slide-strip-mode ${lyricsMode === 'snippets' ? 'is-snippets' : ''}" id="slide-strip-mode"
              title="${escAttr(lyricsMode === 'snippets' ? 'Trocar para números (1, 2, 3…)' : 'Trocar para miniaturas com trecho da letra')}">
              ${lyricsMode === 'snippets' ? '1 2 3…' : 'Miniaturas'}
            </button>`));
          label.querySelector('#slide-strip-mode')?.addEventListener('click', () => {
            this.prefs = savePrefs({
              ...this.prefs,
              slideStripLyricsMode: lyricsMode === 'snippets' ? 'numbers' : 'snippets',
            });
            this.renderSlideStrip(meta);
          });
        } else {
          label.textContent = isCommunion
            ? 'Fases da Ceia do Senhor — clique para ir'
            : 'Versículos — clique para ir direto';
        }

        const phaseChipLabels = { intro: 'Abertura', bread: 'Pão', cup: 'Cálice', meditation: 'Meditação' };

        strip.classList.toggle('slide-strip--snippets', isLyrics && lyricsMode === 'snippets');
        setHtml(strip, rawHtml(range
          .map((m) => {
            let chipHtml;
            let chipTitle = '';
            let extraClass = '';
            if (isLyrics && m.slideIndex === 0) {
              chipHtml = lyricsMode === 'snippets'
                ? `${faIconRaw('music', 'su-fa su-fa--sm')} ${esc(item.title || 'Capa')}`
                : faIconRaw('music', 'su-fa su-fa--sm');
              chipTitle = `Capa — ${item.title || 'Louvor'}`;
              extraClass = lyricsMode === 'snippets' ? 'slide-chip--snippet slide-chip--cover' : '';
            } else if (isLyrics && lyricsMode === 'snippets') {
              const flatIndex = this.program.slideMeta.findIndex(
                (sm) => sm.itemIndex === meta.itemIndex && sm.slideIndex === m.slideIndex
              );
              const lyricSlide = flatIndex >= 0 ? this.program.flatSlides[flatIndex] : null;
              const full = (lyricSlide?.lines || []).join(' / ').replace(/\s+/g, ' ').trim();
              const short = full.length > 36 ? `${full.slice(0, 34)}…` : full;
              chipHtml = esc(short || `Parte ${m.slideIndex}`);
              chipTitle = full || `Parte ${m.slideIndex}`;
              extraClass = 'slide-chip--snippet';
            } else if (isLyrics) {
              chipHtml = esc(String(m.slideIndex));
              chipTitle = `Parte ${m.slideIndex}`;
            } else if (isCommunion) {
              const phase = item.data?.phases?.[m.slideIndex];
              chipHtml = esc(phaseChipLabels[phase?.id] || phase?.title?.slice(0, 10) || String(m.slideIndex + 1));
              chipTitle = phaseChipLabels[phase?.id] || phase?.title || '';
            } else {
              chipHtml = esc(String(m.slideIndex + 1));
            }
            return `<button class="slide-chip ${extraClass} ${m.slideIndex === meta.slideIndex ? 'is-active' : ''}" data-local="${m.slideIndex}" title="${escAttr(chipTitle)}">${chipHtml}</button>`;
          })
          .join('')));

        strip.querySelectorAll('.slide-chip').forEach((btn) => {
          btn.onclick = () => this.goToLocalSlide(meta.itemIndex, Number(btn.dataset.local));
        });
      }
  };
}
