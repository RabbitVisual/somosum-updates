export const inspectorLiveSync = {
scheduleInspectorLiveSync(meta, el, delayMs = 220, inspGen = null) {
  if (el?._suppressInspectorSync) return;
  // Prévia do inspetor sempre permitida (mesmo com culto ao vivo);
  // push ao projetor continua só com autoLive em syncProjectorState(liveEdit).
  clearTimeout(this._inspectorDebounce);
  const gen = inspGen ?? this._inspectorGen;
  this._inspectorDebounce = setTimeout(async () => {
    try {
      if (gen !== this._inspectorGen) return;
      if (el?._suppressInspectorSync) return;
      if (!el?.isConnected) return;
      if (!this.captureInspectorItemState(meta, el)) return;
      const item = this.program.items[meta.itemIndex];
      if (item?.songId && this._liveSyncSongId !== item.songId) {
        this.program.clearSongCache(item.songId);
        this._liveSyncSongId = item.songId;
      }
      await this.program.rebuildItem(meta.itemIndex);
      this.markProgramDirty?.();
      this._inspectorDirty = true;
      this.syncProjectorState(false, { skipInspector: true, liveEdit: true });
      this.syncLiveDockVisibility?.();
      this.updateInspectorDirtyBadge?.();
    } catch (err) {
      console.warn('[SOMOSUM] inspector live-sync', err);
    }
  }, delayMs);
},
};
