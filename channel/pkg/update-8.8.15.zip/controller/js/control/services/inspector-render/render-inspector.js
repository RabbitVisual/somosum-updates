import { setHtml } from '../../../core/render-engine/index.js';
import { RenderScheduler } from '../../../core/render-scheduler.js';
import { isIntroitoProgramItem } from '../../../program/programa-templates.js';
import { isLiveLouvorFocus } from '../../views/live-louvor-workspace.js';

export const inspectorRenderCore = {
  renderInspector(meta) {
    if (isLiveLouvorFocus(this)) return;
    const el = document.getElementById('inspector-body');
    if (!el) return;

    const force = !!this._forceInspectorSync;
    const focused = document.activeElement;
    const isTypingField = (node, root = el) => {
      if (!node || !root?.contains(node)) return false;
      if (node.isContentEditable) return true;
      if (node.matches?.('textarea, select')) return true;
      if (!node.matches?.('input')) return false;
      const t = String(node.type || 'text').toLowerCase();
      return !['checkbox', 'radio', 'range', 'color', 'button', 'submit', 'reset', 'file', 'hidden'].includes(t);
    };
    const inspectorHasContentNow = !!el.querySelector('.inspector-scroll, .inspector-sticky-actions, .empty');
    if (!force && inspectorHasContentNow && isTypingField(focused)) {
      this._pendingInspectorMeta = meta;
      clearTimeout(this._deferInspectorRender);
      this._deferInspectorRender = setTimeout(() => {
        const body = document.getElementById('inspector-body');
        const active = document.activeElement;
        const stillFilled = !!body?.querySelector('.inspector-scroll, .inspector-sticky-actions, .empty');
        if (stillFilled && isTypingField(active, body)) return;
        this.renderInspector(this._pendingInspectorMeta);
      }, 900);
      return;
    }

    if (!this.program.items.length) {
      setHtml(el, '<div class="empty">Ordem vazia — use + para adicionar slides ao culto</div>');
      return;
    }
    if (!meta) { setHtml(el, '<div class="empty">Selecione um item</div>'); return; }

    const item = this.program.items[meta.itemIndex];
    if (!item) {
      this._inspectorItemRef = null;
      this._inspectorLiveKey = null;
      setHtml(el, '<div class="empty">Item não encontrado — selecione outro na ordem</div>');
      return;
    }
    this._inspectorItemRef = item;
    this._inspectorGen = (this._inspectorGen || 0) + 1;
    const inspGen = this._inspectorGen;

    if (isIntroitoProgramItem(item)) {
      item.data = { ...(item.data || {}), role: 'introito' };
    }

    const fields = this.buildInspectorFieldsHtml(item, meta);
    const rehearsalBlock = this.buildRehearsalBlockHtml(item);

    const inspectorKey = `${meta.itemIndex}:${item.slideType}`;
    const inspectorHasContent = !!el.querySelector('.inspector-scroll, .inspector-sticky-actions, .empty');
    const inspectorKeyChanged = this._inspectorLiveKey !== inspectorKey;
    // Não remountar a cada avanço de parte — só ao mudar de item (ou force / painel vazio).
    if (!this._forceInspectorSync && !inspectorKeyChanged && inspectorHasContent) {
      return;
    }

    const syncMount = this._forceInspectorSync || inspectorKeyChanged || !inspectorHasContent;

    const mountInspector = () => {
      this.mountInspectorPanel(el, meta, item, fields, rehearsalBlock, inspectorKey, inspGen);
    };

    if (window.__SOMOSUM_LIVE_ACTIVE && !syncMount) {
      RenderScheduler.markDirty('inspector', { full: mountInspector, priority: 'critical' });
    } else {
      mountInspector();
    }
  },
};
