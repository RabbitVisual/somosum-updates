/**
 * Live Console Operador — 3 zonas:
 * Ordem do culto | Projetor (sequência + prévia) | Painel operador
 * Biblioteca fica no rail lateral (Louvores/Bíblia/Mídia) — sem duplicar no ao vivo.
 */
import { SLIDE_TYPE_OPTIONS, createProgramItem } from '../../program/programa-templates.js';
import { saveProgramTemplate } from '../upgrades-v2.js';
import { esc } from '../utils/escape.js';
import { mountPreviewChromeInLiveConsole } from './live-preview-dock.js';
import { isLiveLouvorFocus, renderLiveLouvorWorkspace, setLiveLouvorFocus, clearLiveLouvorFocus } from './live-louvor-workspace.js';
import { getWorshipSong, recordSongUsage } from '../../worship/worship-store.js';
import { faIconRaw } from '../../core/fa-icons.js';
import { setHtml, rawHtml } from '../../core/render-engine/index.js';
import { savePrefs } from '../../core/store.js';
import { renderLiveBgGallery, applyLiveBackground } from '../ui/live-bg-gallery.js';

const TYPE_META = Object.fromEntries(SLIDE_TYPE_OPTIONS.map((o) => [o.type, o]));

function typeMetaForItem(item) {
  if (item?.data?.role === 'introito' || item?.slideType === 'bible-intro') {
    return TYPE_META['bible-intro'] || { label: 'Introito', icon: 'book-open' };
  }
  return TYPE_META[item?.slideType] || { label: item?.slideType || 'slide', icon: 'shapes' };
}

export function isLiveProgramView(view) {
  return view === 'live' || view === 'program';
}

export function wireLiveConsoleView() {
  return {
    renderLiveConsoleView(main) {
      this._liveLibrary?.destroy?.();
      this._liveLibrary = null;
      this._rundownVirtual?.dispose?.();
      this._rundownVirtual = null;
      this._rundownDelegated = false;

      const itemCount = this.program?.items?.length || 0;

      main.innerHTML = `
      <div class="view-panel is-active live-console-grid live-console-grid--pro live-console-grid--3col" id="live-console-root">
        <section class="lc-col lc-rundown lc-zone lc-zone--order program-rundown-col" id="lc-rundown-col" aria-label="Ordem do culto">
          <div id="culto-active-banner" class="culto-active-banner"></div>
          <header class="lc-zone-head lc-order-head">
            <div class="lc-zone-head-main">
              <span class="lc-zone-kicker">Programa</span>
              <h2 class="lc-zone-title">Ordem do Culto</h2>
              <span class="lc-order-count" id="lc-order-count">${itemCount} ${itemCount === 1 ? 'item' : 'itens'}</span>
            </div>
            <div class="add-slide-wrap program-head-actions lc-order-actions">
              <button class="btn btn-secondary btn-sm" id="btn-save-program" title="Salvar ordem (Ctrl+S)" disabled>${faIconRaw('floppy-disk', 'su-fa su-fa--sm')}</button>
              <button class="btn btn-secondary btn-sm" id="btn-save-template" title="Salvar como template">Tpl</button>
              <button class="btn btn-secondary btn-sm" id="btn-load-template" title="Carregar ordem">Ordem</button>
              <button class="btn btn-secondary btn-icon" id="btn-add" title="Adicionar slide">${faIconRaw('plus', 'su-fa')}</button>
              <div class="add-slide-menu" id="add-slide-menu">
                ${SLIDE_TYPE_OPTIONS.map((o) =>
                  `<button type="button" class="add-slide-option" data-type="${o.type}">${faIconRaw(o.icon, 'su-fa su-fa--sm')} ${esc(o.label)}</button>`
                ).join('')}
              </div>
            </div>
          </header>
          <div class="program-culto-bar" id="program-culto-bar" role="toolbar" aria-label="Modo culto">
            <button type="button" class="btn btn-primary btn-sm" id="btn-culto-start" title="Layout leve">Iniciar culto</button>
            <button type="button" class="btn btn-secondary btn-sm" id="btn-culto-end" hidden title="Encerrar culto">Encerrar</button>
            <button type="button" class="btn btn-secondary btn-sm" id="btn-culto-quick-edit" hidden title="Editar item ao vivo">Editar</button>
            <span class="program-culto-hint" id="program-culto-hint" hidden>Modo culto ativo</span>
          </div>
          <div class="col-body lc-rundown-body" id="rundown"></div>
          <footer class="lc-lookahead-wrap">
            <span class="lc-zone-kicker lc-lookahead-kicker">Próximo</span>
            <div class="rundown-lookahead" id="rundown-lookahead"></div>
          </footer>
        </section>

        <div class="lc-resizer lc-resizer--order" id="lc-resizer-order" aria-hidden="true" title="Redimensionar ordem"></div>

        <section class="lc-col lc-stage lc-zone lc-zone--stage" aria-label="Projetor e sequência">
          <header class="lc-sequence-head lc-stage-head">
            <div class="lc-sequence-title-wrap">
              <span class="lc-zone-kicker">No ar</span>
              <h2 class="lc-active-title" id="lc-active-title">—</h2>
              <p class="lc-active-meta" id="lc-active-meta"></p>
            </div>
            <div class="lc-seq-mode-bar" id="lc-seq-mode-bar" hidden></div>
          </header>
          <div class="lc-stage-split">
            <div class="lc-preview-pane lc-preview-zone program-preview-col">
              <div class="lc-pane-label lc-pane-label--live">
                <span class="lc-pane-label-dot" aria-hidden="true"></span>
                <span class="lc-pane-label-text">No ar</span>
                <span class="lc-pane-label-hint" id="lc-onair-hint">Espelho em tempo real</span>
              </div>
              <div class="program-preview-stack" id="live-monitor-stack"></div>
            </div>
            <div class="lc-resizer lc-resizer--vert" id="lc-resizer-vert" aria-hidden="true" title="Redimensionar sequência"></div>
            <div class="lc-sequence-pane">
              <div class="lc-pane-label">
                <span class="lc-pane-label-text">Sequência</span>
                <span class="lc-pane-label-hint">Clique para projetar · ← → no teclado</span>
              </div>
              <div class="lc-sequence-blocks lc-sequence-thumbs" id="lc-sequence-blocks" aria-label="Partes do item ativo"></div>
            </div>
          </div>
        </section>

        <div class="lc-resizer lc-resizer--side" id="lc-resizer-side" aria-hidden="true" title="Redimensionar painel operador"></div>

        <aside class="lc-col lc-lateral lc-zone lc-zone--ops inspector" aria-label="Painel operador">
          <header class="lc-zone-head lc-ops-head">
            <span class="lc-zone-kicker">Operador</span>
            <h2 class="lc-zone-title">Controles</h2>
          </header>
          <div class="lc-lateral-tabs" role="tablist" aria-label="Painel operador">
            <button type="button" class="lc-lateral-tab" role="tab" aria-selected="false" data-lateral-pane="actions">
              ${faIconRaw('bolt', 'su-fa su-fa--sm')} <span>Ações</span>
            </button>
            <button type="button" class="lc-lateral-tab" role="tab" aria-selected="false" data-lateral-pane="themes">
              ${faIconRaw('palette', 'su-fa su-fa--sm')} <span>Fundos</span>
            </button>
            <button type="button" class="lc-lateral-tab is-active" role="tab" aria-selected="true" data-lateral-pane="notes">
              ${faIconRaw('pen', 'su-fa su-fa--sm')} <span>Item</span>
            </button>
          </div>

          <div class="lc-lateral-pane" data-lateral-pane-panel="actions" role="tabpanel" aria-label="Ações rápidas" hidden>
            <div class="lc-quick-actions lc-quick-actions--grid" role="toolbar" aria-label="Ações rápidas">
              <button type="button" class="lc-qa-card" id="lc-qa-clear" title="Limpar overlay (Esc)">
                ${faIconRaw('eraser', 'su-fa')}
                <span>Limpar</span>
              </button>
              <button type="button" class="lc-qa-card lc-qa-card--warn" id="lc-qa-black" title="Tela preta (B)">
                ${faIconRaw('circle', 'su-fa')}
                <span>Preta</span>
              </button>
              <button type="button" class="lc-qa-card" id="lc-qa-logo" title="Logo (L)">
                ${faIconRaw('image', 'su-fa')}
                <span>Logo</span>
              </button>
            </div>
            <p class="lc-lateral-hint">Louvores, Bíblia e mídia estão no menu lateral esquerdo.</p>
          </div>

          <div class="lc-lateral-pane" data-lateral-pane-panel="themes" role="tabpanel" aria-label="Temas e fundos" hidden>
            <div class="overlay-panel lc-themes-overlay" id="overlay-panel"></div>
            <div class="lc-bg-gallery-host" id="lc-bg-gallery-host" aria-label="Galeria de fundos"></div>
            <footer class="lc-display-bar">
              <button type="button" class="btn btn-secondary btn-sm lc-display-btn" id="lc-display-settings">
                ${faIconRaw('display', 'su-fa su-fa--sm')} Exibição
              </button>
            </footer>
          </div>

          <div class="lc-lateral-pane lc-lateral-notes is-active" data-lateral-pane-panel="notes" role="tabpanel" aria-label="Propriedades do item">
            <div class="col-head lc-lateral-ins-head">
              <div class="col-head-copy">
                <span class="col-head-kicker">Inspetor</span>
                <span class="col-head-title">Propriedades</span>
              </div>
              <button type="button" class="btn btn-secondary btn-sm culto-quick-edit-close" id="btn-culto-quick-close" hidden>Fechar</button>
            </div>
            <div class="col-body" id="inspector-body"></div>
          </div>
        </aside>

        <div class="culto-quick-edit-backdrop" id="culto-quick-edit-backdrop" hidden aria-hidden="true"></div>
      </div>`;

      mountPreviewChromeInLiveConsole();
      this.applyLiveConsoleLayoutWidths?.();
      this.bindLiveLateralTabs?.();
      this.bindLiveQuickActions?.();

      if (this._liveRestoreSongId) {
        const restoreId = this._liveRestoreSongId;
        this._liveRestoreSongId = null;
        void this.openLiveSong?.(restoreId);
      }

      this.bindAddSlideMenu();
      this.bindLiveConsoleResizers();
      this.openLiveInspectorPane?.(this._liveLateralPane || 'notes', { persist: false });
      document.getElementById('btn-save-program')?.addEventListener('click', () => this.saveProgramNow());
      this.updateSaveProgramButton();
      document.getElementById('btn-save-template')?.addEventListener('click', async () => {
        const name = prompt('Nome do template:', 'Ordem padrão');
        if (!name) return;
        await saveProgramTemplate(name, this.program.items);
        this.toast(`Template "${name}" salvo`, 'success');
      });
      document.getElementById('btn-load-template')?.addEventListener('click', () => {
        this.showProgramTemplatePicker?.({ replaceMode: true });
      });
      document.getElementById('lc-display-settings')?.addEventListener('click', () => {
        this.setView?.('settings');
      });

      this.renderCultoBanner?.();
      this.bindCultoProgramUi?.();
      void import('../../plugins/toolbar-mount.js').then(({ mountPluginToolbar }) => {
        const bar = document.getElementById('program-culto-bar');
        if (bar) mountPluginToolbar(bar, 'program-culto-bar', this);
      }).catch(() => {});

      import('../../core/live-culto-mode.js').then(({ isCultoPresentation, applyCultoPresentationDom }) => {
        applyCultoPresentationDom(isCultoPresentation());
      }).catch(() => {});

      this.renderRundown?.();
      this.renderLookahead?.();
      this.renderOverlayPanel?.();
      this.renderLiveBgGallery?.();
      this.updateLiveOrderCount?.();
      this.refreshLiveConsoleUI();
      if (!isLiveLouvorFocus(this)) {
        this.paintInspectorForSelection?.();
      }

      requestAnimationFrame(() => {
        requestAnimationFrame(() => this.refreshStage?.({ skipInspector: true }));
      });
    },

    updateLiveOrderCount() {
      const el = document.getElementById('lc-order-count');
      if (!el) return;
      const n = this.program?.items?.length || 0;
      el.textContent = `${n} ${n === 1 ? 'item' : 'itens'}`;
    },

    async addSongToLiveOrder(songId) {
      const song = await getWorshipSong(songId);
      if (!song) return -1;
      const existing = this.program.items.findIndex(
        (it) => it.slideType === 'lyrics' && it.songId === songId
      );
      if (existing >= 0) {
        this.goToItem?.(existing);
      } else {
        const item = createProgramItem('lyrics', { title: song.title, songId: song.id });
        await this.insertProgramItem?.(item);
      }
      await recordSongUsage(songId);
      this.updateLiveOrderCount?.();
      this.refreshLiveConsoleUI?.({ forceProgram: true, parts: { rundown: true, stage: true } });
      this.toast?.(`"${song.title}" na ordem`, 'info');
      return existing >= 0 ? existing : this.program.items.length - 1;
    },

    async projectLiveSong(songId) {
      const idx = await this.addSongToLiveOrder(songId);
      if (idx < 0) return;
      clearLiveLouvorFocus(this);
      this.goToItem?.(idx);
      await this.program.rebuild?.();
      this.clearMediaOnAir?.();
      this.pushToProjector?.(true);
      this.refreshLiveConsoleUI?.({ forceProgram: true, parts: { rundown: true, stage: true } });
      this.toast?.('Projetando louvor', 'success');
    },

    openLiveInspectorPane(pane = 'notes', { persist = true } = {}) {
      const root = document.getElementById('live-console-root');
      if (!root) return;
      const next = pane === 'themes' || pane === 'actions' || pane === 'notes' ? pane : 'notes';
      if (persist) this._liveLateralPane = next;
      const tabs = root.querySelectorAll('.lc-lateral-tab');
      const panels = root.querySelectorAll('[data-lateral-pane-panel]');
      tabs.forEach((t) => {
        const on = t.dataset.lateralPane === next;
        t.classList.toggle('is-active', on);
        t.setAttribute('aria-selected', on ? 'true' : 'false');
      });
      panels.forEach((p) => {
        const on = p.dataset.lateralPanePanel === next;
        p.classList.toggle('is-active', on);
        p.hidden = !on;
      });
      if (next === 'notes' || next === 'themes') {
        requestAnimationFrame(() => {
          window.dispatchEvent(new Event('resize'));
          if (next === 'themes') this.renderLiveBgGallery?.();
        });
      }
    },

    bindLiveLateralTabs() {
      const root = document.getElementById('live-console-root');
      if (!root) return;
      root.querySelectorAll('.lc-lateral-tab').forEach((t) => {
        t.addEventListener('click', () => this.openLiveInspectorPane(t.dataset.lateralPane));
      });
    },

    bindLiveQuickActions() {
      document.getElementById('lc-qa-black')?.addEventListener('click', () => {
        document.getElementById('btn-black')?.click();
      });
      document.getElementById('lc-qa-logo')?.addEventListener('click', () => {
        document.getElementById('btn-logo-btn')?.click();
      });
      document.getElementById('lc-qa-clear')?.addEventListener('click', () => {
        const clearBtn = document.querySelector('#overlay-panel [data-overlay="clear"], #overlay-panel .btn-clear, #overlay-panel button[data-action="clear"]');
        if (clearBtn) {
          clearBtn.click();
          return;
        }
        this.broadcastOverlay?.('clear');
      });
    },

    bindLiveConsoleResizers() {
      const root = document.getElementById('live-console-root');
      if (!root) return;
      const maxCol = () => Math.max(260, Math.floor(window.innerWidth * 0.42));
      const bindH = (handleId, prefKey, cssVar, minW, invert) => {
        const handle = document.getElementById(handleId);
        if (!handle) return;
        let startX = 0;
        let startW = 0;
        const defaults = { liveOrderW: 300, liveSideW: 280 };
        const readW = () => {
          const raw = getComputedStyle(root).getPropertyValue(cssVar).trim();
          const n = parseInt(raw, 10);
          return Number.isFinite(n) && n > 0 ? n : (defaults[prefKey] || 280);
        };
        let raf = 0;
        const onMove = (e) => {
          if (raf) return;
          raf = requestAnimationFrame(() => {
            raf = 0;
            const dx = e.clientX - startX;
            const w = Math.min(maxCol(), Math.max(minW, startW + (invert ? -dx : dx)));
            root.style.setProperty(cssVar, `${w}px`);
          });
        };
        const onUp = () => {
          document.removeEventListener('mousemove', onMove);
          document.removeEventListener('mouseup', onUp);
          if (raf) cancelAnimationFrame(raf);
          raf = 0;
          const w = readW();
          const layout = { ...(this.prefs?.layout || {}), [prefKey]: w };
          this.prefs = { ...this.prefs, layout };
          import('../../core/store.js').then(({ savePrefs }) => savePrefs(this.prefs)).catch(() => {});
          window.dispatchEvent(new Event('resize'));
        };
        handle.addEventListener('mousedown', (e) => {
          e.preventDefault();
          startX = e.clientX;
          startW = readW();
          document.addEventListener('mousemove', onMove);
          document.addEventListener('mouseup', onUp);
        });
      };
      bindH('lc-resizer-order', 'liveOrderW', '--lc-order-w', 220, false);
      bindH('lc-resizer-side', 'liveSideW', '--lc-side-w', 240, true);

      const vertHandle = document.getElementById('lc-resizer-vert');
      const split = root.querySelector('.lc-stage-split');
      if (vertHandle && split) {
        let startY = 0;
        let startH = 0;
        const readSeqH = () => {
          const raw = getComputedStyle(root).getPropertyValue('--lc-seq-h').trim();
          const n = parseInt(raw, 10);
          return Number.isFinite(n) && n > 0 ? n : (this.prefs?.layout?.liveSeqH || 240);
        };
        let rafV = 0;
        const onMoveV = (e) => {
          if (rafV) return;
          rafV = requestAnimationFrame(() => {
            rafV = 0;
            /* Sequência está embaixo: arrastar o handle para cima aumenta a faixa */
            const dy = e.clientY - startY;
            const maxH = Math.max(100, split.clientHeight - 160);
            const h = Math.min(maxH, Math.max(88, startH - dy));
            root.style.setProperty('--lc-seq-h', `${h}px`);
          });
        };
        const onUpV = () => {
          document.removeEventListener('mousemove', onMoveV);
          document.removeEventListener('mouseup', onUpV);
          if (rafV) cancelAnimationFrame(rafV);
          rafV = 0;
          const h = readSeqH();
          const layout = { ...(this.prefs?.layout || {}), liveSeqH: h };
          this.prefs = { ...this.prefs, layout };
          import('../../core/store.js').then(({ savePrefs }) => savePrefs(this.prefs)).catch(() => {});
          window.dispatchEvent(new Event('resize'));
        };
        vertHandle.addEventListener('mousedown', (e) => {
          e.preventDefault();
          startY = e.clientY;
          startH = readSeqH();
          document.addEventListener('mousemove', onMoveV);
          document.addEventListener('mouseup', onUpV);
        });
      }
    },

    applyLiveConsoleLayoutWidths() {
      const root = document.getElementById('live-console-root');
      if (!root) return;
      const layout = this.prefs?.layout || {};
      const order = layout.liveOrderW
        || layout.liveRundownWidth
        || layout.liveLeftWidth
        || 300;
      const side = layout.liveSideW
        || layout.liveInspectorWidth
        || 280;
      root.style.setProperty('--lc-order-w', `${order}px`);
      root.style.setProperty('--lc-side-w', `${side}px`);
      root.style.setProperty('--lc-seq-h', `${layout.liveSeqH || 240}px`);
    },

    refreshLiveConsoleUI(options = {}) {
      if (this.view !== 'live') return;
      if (isLiveLouvorFocus(this) && !options.forceProgram) {
        void renderLiveLouvorWorkspace(this);
        this.updatePreviewBadge?.();
        return;
      }
      const parts = {
        banner: true,
        rundown: true,
        inspector: true,
        ...options.parts,
      };
      if (parts.banner) this.renderCultoBanner?.();
      if (parts.rundown) {
        this.renderRundown?.();
        this.updateLiveOrderCount?.();
      }
      if (parts.lookahead !== false) this.renderLookahead?.();
      if (parts.inspector && !options.skipInspector) {
        this.paintInspectorForSelection?.();
      }
      this.renderLiveSequenceHeader?.();
      this.renderLiveSequenceBlocks?.();
      if (parts.stage !== false) this.refreshStage?.({ ...options, skipInspector: true });
      this.renderOverlayPanel?.();
      this.updatePreviewBadge?.();
      this.updateSaveProgramButton?.();
      this.renderLiveBgGallery?.();
    },

    renderLiveBgGallery() {
      renderLiveBgGallery(this);
    },

    applyLiveBackground(opts) {
      return applyLiveBackground(this, opts);
    },

    renderLiveSequenceHeader() {
      if (isLiveLouvorFocus(this)) return;
      const titleEl = document.getElementById('lc-active-title');
      const metaEl = document.getElementById('lc-active-meta');
      const modeBar = document.getElementById('lc-seq-mode-bar');
      if (!titleEl) return;
      const meta = this.program.getCurrentMeta?.();
      if (!meta) {
        titleEl.textContent = 'Nenhum item selecionado';
        if (metaEl) metaEl.textContent = 'Escolha um item na ordem do culto';
        if (modeBar) {
          modeBar.hidden = true;
          modeBar.replaceChildren();
        }
        return;
      }
      const item = this.program.items[meta.itemIndex];
      if (!item) return;
      const tm = typeMetaForItem(item);
      titleEl.textContent = item.title || tm.label;
      if (metaEl) {
        metaEl.innerHTML = `${faIconRaw(tm.icon, 'su-fa su-fa--sm')} ${esc(tm.label)} · parte ${meta.slideIndex + 1} de ${this.program.getItemSlideRange(meta.itemIndex)?.length || 1}`;
      }

      if (modeBar) {
        if (item.slideType === 'lyrics') {
          const lyricsMode = this.prefs.slideStripLyricsMode === 'snippets' ? 'snippets' : 'numbers';
          modeBar.hidden = false;
          setHtml(modeBar, rawHtml(`
            <span class="lc-seq-mode-label">Exibir</span>
            <div class="lc-seq-mode-toggle" role="group" aria-label="Modo da sequência">
              <button type="button" class="lc-seq-mode${lyricsMode === 'numbers' ? ' is-active' : ''}" data-mode="numbers" title="Números">Números</button>
              <button type="button" class="lc-seq-mode${lyricsMode === 'snippets' ? ' is-active' : ''}" data-mode="snippets" title="Miniaturas">Miniaturas</button>
            </div>`));
          modeBar.querySelectorAll('.lc-seq-mode').forEach((btn) => {
            btn.onclick = () => {
              const next = btn.dataset.mode === 'snippets' ? 'snippets' : 'numbers';
              if (next === lyricsMode) return;
              this.prefs = savePrefs({ ...this.prefs, slideStripLyricsMode: next });
              this.renderLiveSequenceHeader();
              this.renderLiveSequenceBlocks();
            };
          });
        } else {
          modeBar.hidden = true;
          modeBar.replaceChildren();
        }
      }
    },

    renderLiveSequenceBlocks() {
      if (isLiveLouvorFocus(this)) return;
      const container = document.getElementById('lc-sequence-blocks');
      if (!container) return;
      const meta = this.program.getCurrentMeta?.();
      if (!meta) {
        container.innerHTML = `<div class="lc-blocks-empty">Selecione um item na ordem do culto.</div>`;
        container.classList.remove('lc-sequence-blocks--numbers');
        return;
      }
      const item = this.program.items[meta.itemIndex];
      const range = this.program.getItemSlideRange(meta.itemIndex);
      const MAX_SEQ = 64;
      const fullLen = range?.length || 0;
      const visible = fullLen > MAX_SEQ ? range.slice(0, MAX_SEQ) : range;
      if (!range?.length) {
        container.innerHTML = `<div class="lc-blocks-empty">Slide único — clique na ordem ou use ← → para navegar.</div>`;
        container.classList.remove('lc-sequence-blocks--numbers');
        return;
      }

      const isLyrics = item?.slideType === 'lyrics';
      const isBible = item?.slideType === 'bible';
      const phaseLabels = { intro: 'Abertura', bread: 'Pão', cup: 'Cálice', meditation: 'Meditação' };
      const lyricsMode = this.prefs.slideStripLyricsMode === 'snippets' ? 'snippets' : 'numbers';
      const useNumbers = isLyrics && lyricsMode === 'numbers';
      container.classList.toggle('lc-sequence-blocks--numbers', useNumbers);
      container.classList.toggle('lc-sequence-thumbs', !useNumbers);

      setHtml(container, rawHtml((visible || []).map((m) => {
        let label = '';
        let preview = '';
        const isActive = m.slideIndex === meta.slideIndex;
        if (isLyrics && m.slideIndex === 0) {
          label = 'Capa';
          preview = item.title || 'Louvor';
        } else if (isLyrics) {
          const flatIndex = this.program.slideMeta.findIndex(
            (sm) => sm.itemIndex === meta.itemIndex && sm.slideIndex === m.slideIndex
          );
          const slide = flatIndex >= 0 ? this.program.flatSlides[flatIndex] : null;
          preview = (slide?.lines || []).join('\n') || `Parte ${m.slideIndex}`;
          label = `Estrofe ${m.slideIndex}`;
        } else if (isBible) {
          label = `Versículo ${m.slideIndex + 1}`;
          preview = item.title || '';
        } else if (item?.slideType === 'communion') {
          const phase = item.data?.phases?.[m.slideIndex];
          label = phaseLabels[phase?.id] || phase?.title || String(m.slideIndex + 1);
          preview = phase?.title || '';
        } else {
          label = `Slide ${m.slideIndex + 1}`;
          preview = item.title || '';
        }

        if (useNumbers) {
          const badge = m.slideIndex === 0 ? '♪' : String(m.slideIndex);
          return `<button type="button" class="lc-seq-block lc-seq-num ${isActive ? 'is-live' : ''}"
            data-local="${m.slideIndex}" data-item="${meta.itemIndex}" title="${esc(label)} — clique para projetar">
            <span class="lc-seq-num-badge">${esc(badge)}</span>
            <span class="lc-seq-block-label">${esc(label)}</span>
          </button>`;
        }

        return `<button type="button" class="lc-seq-block lc-seq-thumb ${isActive ? 'is-live' : ''}"
          data-local="${m.slideIndex}" data-item="${meta.itemIndex}" title="${esc(label)} — clique para projetar">
          <span class="lc-seq-thumb-frame" aria-hidden="true">
            <span class="lc-seq-thumb-body">${esc(preview || label)}</span>
          </span>
          <span class="lc-seq-block-label">${esc(label)}</span>
        </button>`;
      }).join('')));

      container.querySelectorAll('.lc-seq-block').forEach((btn) => {
        btn.onclick = () => {
          const itemIdx = Number(btn.dataset.item);
          const local = Number(btn.dataset.local);
          if (itemIdx !== meta.itemIndex) this.goToItem?.(itemIdx);
          this.goToLocalSlide?.(itemIdx, local);
          this.renderLiveSequenceBlocks();
        };
      });
    },

    highlightLiveOrdemSelection(itemIndex) {
      this.highlightRundownSelection?.(itemIndex);
      this.renderLiveSequenceHeader?.();
      this.renderLiveSequenceBlocks?.();
    },

    async openLiveSong(songId, projectNow = false) {
      if (this.view !== 'live') this.setView?.('live');
      await new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r)));
      const song = await getWorshipSong(songId);
      if (!song) return;
      await setLiveLouvorFocus(this, song);
      if (projectNow) {
        await this.projectLiveSong?.(songId);
      }
    },
  };
}
