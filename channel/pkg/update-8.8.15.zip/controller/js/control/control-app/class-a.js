﻿import { ProjectionBus, MessageTypes } from '../../core/bus.js';
import { toast as kitToast } from '../../ui/kit/toast.js';
import { applyUiPrefs } from '../../ui/apply-ui-prefs.js';
import {
  getPrefs, savePrefs, getProgram, saveProgram, getAllSongs, getSong, saveSong,
  generateId, getAllAssets, saveAsset,
  deleteAsset, fileToDataUrl, getAllMedia, saveMediaFile, deleteMedia,
  initializeFromDisk, saveNavigationState, getNavigationState, flushPrefsToDisk,
  savePrefsLocal,
  resolveChurchWelcomeBgUrl, resolveChurchLogoUrl, resolveChurchWelcomeBgKind,
} from '../../core/store.js';
import { logToServer } from '../../core/storage/adapters/server-adapter.js';
import { url as assetUrl } from '../../core/asset-registry.js';
import { onError } from '../../core/error-boundary.js';
import { getRecoveryEngine } from '../../runtime/facades/recovery-runtime.js';
import { bindShortcuts, resolveAppShortcuts } from '../../core/shortcuts.js';
import { applyTheme } from '../../core/themes.js';
import { resolveLiveAtmosphereId, resolvePrefsAtmosphereId } from '../../ui/theme/atmospheres.js';
import { DEFAULTS } from '../../data/defaults.js';
import { ProgramManager } from '../../program/program-manager.js';
import { bootstrapWorshipEngine } from '../../worship/engine/worship-engine.js';
import {
  createDefaultProgram,
} from '../../program/programa-templates.js';
import { cloneProgramItem, moveItemInList } from '../../program/program-item-clone.js';
import { syncActiveCultoConfig, resolveActiveCultoId } from '../../core/culto-sync.js';
import { isLiveLouvorFocus } from '../views/live-louvor-workspace.js';
import {
  listCultos,
  getCulto,
  saveCulto,
  setActiveCulto,
  migrateLegacyProgram,
} from '../../program/culto-manager.js';
import { sanitizeProgramBibleItems } from '../../bible/bible-picker.js';
import { LazyLoader } from '../../core/performance/lazy-loader.js';
import { ensureRenderPrefsPersisted, hydrateRenderPrefs } from '../../core/performance/render-prefs.js';
import { prepareCustomSlideForSync } from '../../designer/content-bindings.js';
import { loadCustomFonts, getCustomFontList } from '../../core/fonts.js';
import { loadAmbientTracks, normalizeAmbientState } from '../../core/ambient-audio.js';
import { playBellSound, preloadBellSound, setKnownAudioPaths } from '../../core/bell-sound.js';
import { wireControlUpgrades } from '../upgrades-v2.js';
import { setProjectionHealth, setSyncHealth, setSavePending, setProgramDirty, beginLoadGrace, endLoadGrace } from '../../core/health-monitor.js';
import { applyLiveCultoRuntime, liveProjectorDebounceMs, isLiveCultoActive } from '../../core/live-culto-mode.js';
import { registerDisposable } from '../../core/disposable-registry.js';
import { TaskScheduler } from '../../core/task-scheduler.js';
import { TaskIds } from '../../core/task-registry.js';
import { applyPushedDisplaySnapshot } from '../../core/display-manager.js';
import { DisplayProjectionEngine } from '../../runtime/facades/display-runtime.js';
import { savePrefs as storeSavePrefs } from '../../core/store.js';
import { applyControlTitle } from '../../ui/bootstrap-branding.js';
import { clearBanner } from '../../ui/feedback.js';
import { wireCountdownSync } from '../sync/countdown-sync.js';
import { wirePreviewService } from '../services/preview-service.js';
import { wireAmbientPanel } from '../services/ambient-panel.js';
import { wireInspectorService } from '../services/inspector-service.js';
import { wireSettingsView } from '../views/settings-view.js';
import { wireCultosView, normalizeProgramItems } from '../views/cultos-view.js';
import { wireProgramView } from '../views/program-view.js';
import { wireLiveConsoleView } from '../views/live-console-view.js';
import { wireModalsView } from '../views/modals-view.js';
import { wireShellView } from '../views/shell-view.js';
import { wireBulletinCarousel } from '../../ops/bulletin-carousel.js';
import { createSyncCoordinator } from '../sync/sync-coordinator.js';
import { wireSyncOutbound } from '../sync/sync-outbound.js';
import { wireProjectorSlideAccess } from '../sync/projector-slide-access.js';
import { wireProjectionDisplayUi } from '../projection-display-ui.js';
import { wireProgramMutations } from '../program/program-mutations.js';
import { wireBusHandlers } from '../wire/wire-bus-handlers.js';
import { defer } from '../../core/defer.js';
import { pushSyncAuthoritative, requestFullStateAuthoritative } from '../../runtime/facades/sync-runtime.js';
import { fetchClientPresence } from '../../core/client-presence.js';

export class ControlApp {
  constructor() {
    this.bus = new ProjectionBus('control');
    this.defaults = DEFAULTS;
    this.prefs = getPrefs();
    applyUiPrefs(this.prefs);
    this.assets = { logo: null, welcomeBg: null };
    this.program = new ProgramManager(DEFAULTS, this.prefs);
    this.songs = [];
    this.mediaList = [];
    this.view = 'live';
    this.screenConnected = false;
    this._lastScreenHeartbeat = 0;
    this._initSyncDone = false;
    this._lastFullStateAt = 0;
    this._slidePendingAck = false;
    this._lastSlideAckAt = 0;
    this.syncCoordinator = createSyncCoordinator({ defer });
    this._displayChangeTimer = null;
    this._lastDisplayFullStateAt = 0;
    wireSyncOutbound(this);
    wireProjectorSlideAccess(this);
    wireProjectionDisplayUi(this);
    wireProgramMutations(this);
    this.cultoIndex = { cultos: [], activeId: null };
    this.calendarMonth = new Date().getMonth() + 1;
    this.calendarYear = new Date().getFullYear();
    this.dragIndex = null;
    this.lyricsEditor = null;
    this.autoLive = this.prefs.autoLive !== false;
    this.customFonts = [];
    this.ambientTracks = [];
    this.ambientPanelOpen = false;
    this.countdownPanelOpen = false;
    this._countdownTick = null;
    this.controlAmbient = null;
    this.rehearsalMode = this.prefs.rehearsalMode === true;
    this.stageNote = '';
    this._designer = null;
    this._inspectorDebounce = null;
    this._lastKnownSlide = null;
    try { window.__SOMOSUM_CONTROL_APP = this; } catch { /* ignore */ }
  }

  async init() {
    await initializeFromDisk();
    applyControlTitle();
    this.prefs = hydrateRenderPrefs(getPrefs());
    try {
      await ensureRenderPrefsPersisted(() => this.prefs, (partial) => {
        this.prefs = savePrefs(partial);
        return this.prefs;
      });
      this.prefs = hydrateRenderPrefs(getPrefs());
    } catch { /* ignore */ }
    await loadCustomFonts({ injectFaces: true });
    this.customFonts = getCustomFontList();
    try {
      const { startFontCatalogWatch } = await import('../../core/fonts.js');
      const { MessageTypes } = await import('../../core/bus.js');
      startFontCatalogWatch({
        intervalMs: 8000,
        onChange: (families) => {
          this.customFonts = families || getCustomFontList();
          try { this.bus?.send?.(MessageTypes.FONTS_RELOAD, { at: Date.now() }); } catch { /* ignore */ }
        },
      });
    } catch { /* ignore */ }
    applyTheme(resolvePrefsAtmosphereId(this.prefs));
    const stored = await getAllAssets();
    this.assets = {
      logo: stored.logo || null,
      welcomeBg: stored.welcomeBg || null,
    };

    this.program.setDefaults(this.defaults);
    this.program.setPrefs(this.prefs);

    const legacyProgram = await getProgram();
    await migrateLegacyProgram(legacyProgram);
    this.cultoIndex = await listCultos();
    this.cultoIndex = await syncActiveCultoConfig(this.cultoIndex);

    let items;
    const activeId = resolveActiveCultoId(this.cultoIndex, this.prefs.navigation);
    if (activeId) {
      const culto = await getCulto(activeId);
      items = culto?.items || legacyProgram || createDefaultProgram();
      if (activeId !== this.cultoIndex.activeId) {
        await setActiveCulto(activeId);
        this.cultoIndex.activeId = activeId;
      }
    } else {
      items = legacyProgram || createDefaultProgram();
    }

    let itemsChanged = false;
    if (!items.length) {
      items = createDefaultProgram();
      itemsChanged = true;
    }

    const activeMeta = activeId
      ? (this.cultoIndex.cultos.find((c) => c.id === activeId) || {})
      : {};
    items = normalizeProgramItems(items, this.prefs?.church || {}, activeMeta.type || 'domingo');
    const itemsBefore = JSON.stringify(items);
    if (await sanitizeProgramBibleItems(items, this.prefs.bibleVersion || 'naa')) {
      itemsChanged = true;
    }
    if (JSON.stringify(items) !== itemsBefore) itemsChanged = true;
    if (itemsChanged) {
      await saveProgram(items);
      if (activeId) await saveCulto(activeId, items, activeMeta);
    }
    this.program.setItems(items, { resetNav: false });
    if (!items.length) {
      this.view = this.prefs.navigation?.lastView || 'cultos';
    } else {
      const last = this.prefs.navigation?.lastView;
      const legacyLive = new Set(['program', 'library']);
      this.view = legacyLive.has(last) ? 'live' : (last || 'live');
    }
    const hasBibleInProgram = items.some((it) => String(it.slideType || '').includes('bible'));
    const biblePreload = hasBibleInProgram
      ? import('../../bible/bible-service.js')
        .then(({ preloadVersion }) => preloadVersion(this.prefs.bibleVersion || 'naa'))
        .catch(() => {})
      : Promise.resolve();
    this.render();
    this.bindGlobal();
    this.bindDisplayEngine();
    window.Engine?.onResync?.(() => {
      if (this._lastSlideSentAt && this.screenConnected && !this._openingProjection) {
        this.pushProjectorLightSync?.({ force: true, skipPreview: true });
      } else {
        this._burstSyncToProjection();
      }
    });
    window.addEventListener('engine-reconnected', () => {
      if (this._lastSlideSentAt && this.screenConnected && !this._openingProjection) {
        this.pushProjectorLightSync?.({ force: true, skipPreview: true });
      } else {
        this._burstSyncToProjection();
      }
    });
    this._bindLowSpecBanner();
    window.addEventListener('engine-user-message', (ev) => {
      const msg = ev.detail?.message;
      if (msg) this.toast(msg, ev.detail?.key === 'unavailable' ? 'warn' : 'info');
    });
    await this.program.rebuild();
    await biblePreload;
    this.restoreNavigation();
    try {
      this.refreshStage();
    } catch (err) {
      console.error('[SOMOSUM] refreshStage (boot)', err);
    }

    void (async () => {
      this.songs = await getAllSongs();
      this.mediaList = await getAllMedia();
      if (this.view === 'live' || this.view === 'program') {
        const meta = this.program.getCurrentMeta?.();
        const item = meta ? this.program.items[meta.itemIndex] : null;
        if (item && (item.slideType === 'lyrics' || item.slideType === 'participation')) {
          this._inspectorLiveKey = null;
          this._forceInspectorSync = true;
          try {
            this.renderInspector?.(meta);
          } finally {
            this._forceInspectorSync = false;
          }
        }
      }
    })();

    this.ambientTracks = await loadAmbientTracks();
    setKnownAudioPaths(this.ambientTracks.map((t) => t.path));
    preloadBellSound();

    this.initControlAmbient();
    try {
      this.initCountdownPanel();
    } catch (err) {
      console.error('[SOMOSUM] initCountdownPanel', err);
    }
    try {
      await this.initAmbientPanel();
    } catch (err) {
      console.error('[SOMOSUM] initAmbientPanel', err);
    }
    this.bindErrorLogging();
    this.syncCountdown();
    this.reconcileCountdown();
    this.startCountdownPreviewTick();
    this.startHeartbeat();
    this.startScreenWatchdog();
    this.startScreenPresenceProbe();

    try {
      wireControlUpgrades(this);
    } catch (err) {
      console.error('[SOMOSUM] wireControlUpgrades', err);
    }

    if (this.view === 'live' || this.view === 'program') {
      this._forceInspectorSync = true;
      try {
        this.renderInspector?.(this.program.getCurrentMeta());
      } catch (err) {
        console.error('[SOMOSUM] renderInspector (boot)', err);
      } finally {
        this._forceInspectorSync = false;
      }
      requestAnimationFrame(() => {
        requestAnimationFrame(() => {
          try {
            this.refreshStage?.({ skipInspector: true });
          } catch (err) {
            console.error('[SOMOSUM] refreshStage (layout)', err);
          }
        });
      });
    }
    this.worshipEngine = bootstrapWorshipEngine('control', this);
    getRecoveryEngine().init({
      role: 'control',
      bus: this.bus,
      onPushFullState: (opts) => {
        if (isLiveCultoActive() && !this.isRehearsal?.()) {
          this.pushProjectorLightSync(opts);
        } else {
          this.pushFullState(opts);
        }
      },
      isCultoActive: () => this.program?.items?.length > 0 && this.screenConnected,
    });
    this.bibleReader = null;
    this._bibleReaderPromise = null;
    this._store = { savePrefs: storeSavePrefs };

    void import('../tools/midi-controller.js').then(({ bootMidiFromPrefs }) => {
      bootMidiFromPrefs(this).catch((err) => console.warn('[SOMOSUM] MIDI', err));
    }).catch(() => {});

    this.bus.onAck(() => {
      const age = this.bus.getLastAckAge();
      setSyncHealth('ok', age != null ? Math.min(age, 999) : null);
      this.markScreenConnected('slide_ack');
    });

    this._diskPendingCount = 0;
    this._programDirty = false;
    window.addEventListener('somosum-disk-pending', () => {
      this._diskPendingCount += 1;
    });
    window.addEventListener('somosum-disk-saved', () => {
      this._diskPendingCount = Math.max(0, (this._diskPendingCount || 0) - 1);
    });

    const flushOnHide = () => {
      void this.flushPendingEdits();
      TaskScheduler.setMode('background');
    };
    const resumeOnShow = () => {
      TaskScheduler.setMode('active');
    };
    window.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'hidden') flushOnHide();
      else resumeOnShow();
    });
    window.addEventListener('pagehide', () => {
      void this.flushPendingEdits();
      try {
        import('../../core/storage/adapters/server-adapter.js').then(({ flushDebouncedDiskWrites }) => flushDebouncedDiskWrites()).catch(() => {});
      } catch { /* ignore */ }
      try { this.bus?.hub?.stopPolling?.(); } catch { /* ignore */ }
      getRecoveryEngine().shutdown?.();
      TaskScheduler.setMode('hidden');
    });
    registerDisposable(() => {
      try { this.bus?.hub?.stopPolling?.(); } catch { /* ignore */ }
      getRecoveryEngine().shutdown?.();
      TaskScheduler.stop();
    });

    clearBanner();
    // Splash fora de #app: só some depois do shell pintado + tempo mínimo
    const finishBoot = () => {
      window.dispatchEvent(new Event('somosum-app-ready'));
      this.consumePanelCultoDeepLink?.();
      import('../../core/server-boot.js').then(({ markAppReady }) => markAppReady()).catch(() => {});
      import('../../ui/onboarding-tour.js').then(({ maybeStartTour }) => maybeStartTour(this)).catch(() => {});
      import('../../ui/whats-new-modal.js').then(({ maybeShowWhatsNew }) => maybeShowWhatsNew()).catch(() => {});
      import('../../ui/welcome-modal.js').then(({ maybeShowWelcome }) => maybeShowWelcome(this)).catch(() => {});
      setTimeout(() => {
        import('../../ui/app-update-dialog.js').then(({ maybeCheckAppUpdate }) => maybeCheckAppUpdate()).catch(() => {});
      }, 4000);
    };
    requestAnimationFrame(() => {
      requestAnimationFrame(() => {
        try { window.__somosumBootSplashReady?.(); } catch { /* ignore */ }
        if (typeof window.__somosumDismissBootSplash === 'function') {
          void window.__somosumDismissBootSplash(finishBoot);
        } else {
          document.getElementById('boot-loading')?.remove();
          finishBoot();
        }
      });
    });

    defer(() => {
      if (!this.screenConnected) this.syncAll(false);
    }, 900, 7);

    wireBusHandlers(this);
  }

  getWelcomeSlide() {
    const church = this.prefs.church || {};
    const idx = this.program.flatSlides.findIndex((s) => s.type === 'welcome');
    if (idx >= 0) return { slide: this.program.flatSlides[idx], index: idx };
    return {
      slide: {
        type: 'welcome',
        years: church.defaultWelcomeTitle || 'Bem-vindos',
        theme: church.defaultTheme || '',
        subtitle: church.subtitle || '',
      },
      index: 0,
    };
  }

  restoreNavigation() {
    const nav = getNavigationState();
    this.program.restoreNavigation({
      currentIndex: nav.currentIndex,
      overlay: nav.overlay,
    });
  }

  persistNavigation() {
    this.prefs = saveNavigationState({
      currentIndex: this.program.currentIndex,
      overlay: this.program.overlay,
      activeCultoId: this.cultoIndex.activeId || this.prefs.navigation?.activeCultoId || null,
    });
  }

  /** Debounce da nav em disco — não compete com o inspetor no clique. */
  schedulePersistNavigation(delayMs = 280) {
    clearTimeout(this._navPersistTimer);
    this._navPersistTimer = setTimeout(() => {
      try { this.persistNavigation(); } catch { /* ignore */ }
    }, delayMs);
  }

  /** Inspetor imediato na seleção do usuário (não depende de autoLive). */
  paintInspectorForSelection() {
    if (this.view !== 'program' && this.view !== 'live') return;
    if (isLiveLouvorFocus(this)) return;
    const meta = this.program.getCurrentMeta?.();
    if (!meta) {
      this.renderInspector?.(null);
      return;
    }
    const el = document.getElementById('inspector-body');
    const item = this.program.items[meta.itemIndex];
    if (!item) {
      this._inspectorLiveKey = null;
      this.renderInspector?.(null);
      return;
    }
    const key = `${meta.itemIndex}:${item.slideType || ''}`;
    const hasContent = !!el?.querySelector('.inspector-scroll, .inspector-sticky-actions, .empty');
    // Mesmo item com painel OK — não remountar (ex.: avançar parte do louvor).
    if (key && key === this._inspectorLiveKey && hasContent) return;
    this.openLiveInspectorPane?.('notes');
    this._forceInspectorSync = true;
    try {
      this.renderInspector?.(meta);
    } finally {
      this._forceInspectorSync = false;
    }
  }

  bindErrorLogging() {
    onError(() => this.health?.recordError?.());
  }

  startHeartbeat() {
    TaskScheduler.unregister(TaskIds.CONTROL_HEARTBEAT);
    TaskScheduler.register({
      id: TaskIds.CONTROL_HEARTBEAT,
      kind: 'interval',
      intervalMs: this.screenConnected ? 15000 : 6000,
      priority: 5,
      runWhenHidden: true,
      fn: () => {
        this.bus.send(MessageTypes.HEARTBEAT, { ping: true });
        TaskScheduler.setIntervalMs(
          TaskIds.CONTROL_HEARTBEAT,
          this.screenConnected ? 15000 : 6000,
        );
      },
    });
  }

  startScreenWatchdog() {
    this.updateLiveBadge();
    this._screenMissStreak = 0;
    TaskScheduler.unregister(TaskIds.CONTROL_SCREEN_WATCH);
    TaskScheduler.register({
      id: TaskIds.CONTROL_SCREEN_WATCH,
      kind: 'interval',
      intervalMs: 12000,
      priority: 6,
      runWhenHidden: true,
      fn: () => {
        if (this._openingProjection) return;
        const ackAge = this.bus?.getLastAckAge?.();
        const ackAt = ackAge != null ? Date.now() - ackAge : 0;
        const lastSignal = Math.max(this._lastScreenHeartbeat || 0, ackAt);
        if (!lastSignal) return;
        // 60s + 2 ticks falhos — evita flap falso "desconectado"
        if (Date.now() - lastSignal > 60000) {
          this._screenMissStreak = (this._screenMissStreak || 0) + 1;
          if (this._screenMissStreak >= 2 && this.screenConnected) {
            this.screenConnected = false;
            this.updateLiveBadge();
            this.startScreenPresenceProbe();
            this.bus.hub?.boostPolling?.();
          }
        } else {
          this._screenMissStreak = 0;
        }
      },
    });
  }

  startScreenPresenceProbe() {
    TaskScheduler.unregister(TaskIds.CONTROL_SCREEN_PROBE);
    TaskScheduler.register({
      id: TaskIds.CONTROL_SCREEN_PROBE,
      kind: 'interval',
      intervalMs: 2500,
      priority: 4,
      runWhenHidden: true,
      fn: () => {
        if (this.screenConnected && !this._openingProjection) {
          TaskScheduler.unregister(TaskIds.CONTROL_SCREEN_PROBE);
          return;
        }
        void this.probeScreenPresence();
      },
    });
  }

  async probeScreenPresence() {
    try {
      const clients = await fetchClientPresence(15000);
      const hasScreen = clients.some((c) => c.role === 'screen');
      if (!hasScreen) return false;
      const was = this.screenConnected;
      this.markScreenConnected('presence');
      this.bus.hub?.boostPolling?.();
      // Só burst FULL_STATE na abertura / primeiro contato — não a cada flap de presence
      if (this._openingProjection || (!was && !this._lastSlideSentAt)) {
        if (isLiveCultoActive() && !this.isRehearsal?.()) {
          this._burstSyncToProjection();
        } else if (!this._lastFullStateAt || this._openingProjection) {
          this.pushFullState({ force: true, skipPreview: was });
        }
      } else if (!was) {
        // Reconexão leve: slide atual sem remount completo
        this.syncCoordinator?.emit?.({ kind: 'slide', animate: false });
      }
      return true;
    } catch {
      return false;
    }
  }

  toast(msg, type = 'info') {
    kitToast(msg, type);
  }
}

