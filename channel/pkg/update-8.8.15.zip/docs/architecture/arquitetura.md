# SOMOSUM v8.8.15 — Arquitetura do Sistema

> **Produto:** SOMOSUM (SOMOS UM) — Projeção offline para cultos  
> **Versão:** 8.8.15  
> **Stack:** HTML5 / ES Modules / .NET 8 (WinForms + Kestrel) / WebView2  
> **Autor:** Reinan Rodrigues  —  `r.rodriguesjs@gmail.com`  
> **Público:** desenvolvedores, arquitetos e mantenedores

---

## 1. Visão geral

O SOMOSUM é um sistema **100% offline** para projeção multimídia em cultos de igreja. Opera em Windows 10/11 sem Node.js, npm, PHP ou internet na igreja. A arquitetura atual (v8.7) combina **resiliência**, **observabilidade**, **persistência enterprise** e **renderização profissional** sobre o monólito modular ES + motor .NET 8 (Kestrel).

### 1.1 Superfícies do produto

| Superfície | Entry point | Papel |
|------------|-------------|-------|
| **Controle** | `control.html` | Operador  —  monta culto, navega slides, preview |
| **Projeção** | `screen.html` | Congregação  —  fullscreen no monitor do projetor |
| **Stage** | `stage.html` | Músicos/líderes  —  letras, ordem, alertas |
| **Remote** | `remote.html` | Celular ou 2º PC na LAN |
| **Painel** | `launcher/panel.html` | Hub do culto neste PC — home, 10 seções (Culto / Este PC / Igreja), chrome claro/escuro, Sobre com novidades ao vivo |
| **Diagnóstico** | `launcher/diagnostics.html` | Health check e troubleshooting |
| **Docs** | `docs/` | Portal de documentação servido em `/docs/` |

### 1.2 Diagrama de superfícies e sync

```mermaid
flowchart LR
  subgraph local [Mesma máquina]
    CTRL[control.html<br/>WebView2]
    SCR[screen.html<br/>Navegador]
    STG[stage.html]
  end

  subgraph lan [Rede local opcional]
    REM[remote.html<br/>PWA + SW]
    REM2[SOMOSUM-Remote.exe]
  end

  subgraph server [Servidor HTTP]
    ENGINE[Somosum.Engine<br/>Kestrel]
  end

  CTRL <-->|BroadcastChannel<br/>somosum-projecao| SCR
  CTRL <-->|STAGE_STATE / ALERT| STG
  CTRL <-->|REMOTE_CMD| REM
  REM2 --> REM

  CTRL -->|fetch /api/*| ENGINE
  SCR --> ENGINE
  STG --> ENGINE
  REM -->|sync token| ENGINE
```

---

## 2. Princípios arquiteturais

### 2.1 Regra de ouro: nunca `file://`

Todos os HTML/JS/CSS **devem** ser servidos via HTTP local (`http://127.0.0.1:PORTA/...`). Abrir arquivos diretamente quebra:

- ES modules (`import`)
- IndexedDB / localStorage isolados por origem
- `BroadcastChannel` entre janelas
- `fetch` para `/api/*`

Cada HTML exibe aviso de bloqueio se `location.protocol === 'file:'`. O boot inline em `js/core/boot-inline.js` valida isso.

### 2.2 Offline-first

| Recurso | Localização |
|---------|-------------|
| Bíblias (13 traduções) | `model/storage/private/biblias/offline/*.bible.js` |
| Dados do usuário | `model/data/*.json` + IndexedDB `somosum-db` v4 |
| Vendor (Konva, QR) | `view/vendor/` |
| Fontes | `view/fonts/` |
| Áudio ambiente | `view/audio/` |
| Imagens padrão | `view/IMG/` |
| Hinários padrão (seed) | `model/content/default_letras/` → build → `model/data/default-hinarios.json` |

### 2.3 Sync em três camadas

1. **BroadcastChannel** (`somosum-projecao`)  —  mesma máquina, latência mínima
2. **localStorage fallback**  —  quando BroadcastChannel indisponível
3. **HTTP sync queue** (`/api/sync/push` + `/api/sync/poll`)  —  LAN, remote, reconexão

Implementação: `js/core/bus.js`, `js/core/sync-hub.js`, `js/control/sync/projector-sync.js`.

### 2.4 Monólito modular (sem bundler)

O frontend usa **ES modules nativos**. Cache-bust centralizado via **AssetRegistry** (`js/core/asset-registry.js`) e `GET /api/app-meta` — sem `?v=` manual nos HTML.

### 2.5 Servidor Kestrel (motor único)

O HTTP local roda em **Somosum.Engine** (Kestrel / .NET 8). Poll de sync usa resposta imediata + polling cliente (tipicamente 250 ms ativo) para manter Remote/Stage fluidos sem bloquear o push.

### 2.6 Layout MVC explícito (content root)

A **raiz do repositório é o content root**. Validação: `view/html/control.html` + `model/data/` + `app\SOMOSUM.exe`. O trampolim `SOMOSUM.exe` na raiz **nunca** vai para `app/`.

**URLs públicas estáveis** (`/control.html`, `/js/*`, `/css/*`, `/api/data/*`) são mapeadas para disco por [`ContentLayout.cs`](../../controller/runtime/Core/ContentLayout.cs).

| Camada MVC | Pasta física | Conteúdo |
|------------|--------------|----------|
| **Model** | `model/` | `data/`, `storage/`, `content/` (seed) |
| **View** | `view/` | `html/`, `css/`, `fonts/`, `IMG/`, `audio/`, `vendor/`, PWA |
| **Controller** | `controller/` | `js/` (cliente), `launcher/` (shell), `runtime/` (engine .NET) |

Infra na raiz (fora do MVC): `app/`, `docs/`, `scripts/`, `installer/`, `system/`, `governance/`, `logs/`, `dist/`, `tools/`, `tests/`.

**Raiz enxuta:** meta + trampolim + pastas `model/`, `view/`, `controller/` + infra acima.

---

## 3. Camadas da arquitetura v4

```mermaid
flowchart TB
  subgraph surfaces [Superfícies]
    CTRL[control.html]
    SCR[screen.html]
    STG[stage.html]
    REM[remote.html]
  end

  subgraph ux [UX Layer]
    CMD[js/ux/command-palette.js]
    DOCK[js/ux/dock-panels.js]
  end

  subgraph product [Módulos de Produto]
    StagePro[js/stage-pro/]
    RemotePro[js/remote-pro/]
    BiblePro[js/bible-pro/]
    DesignerPro[js/designer-pro/]
    DAM[js/assets/asset-manager.js]
  end

  subgraph render [Render Stack]
    RQ[js/render/render-queue.js]
    RP[js/render/render-pipeline.js]
    SE[js/slides/engine/slide-engine-v2.js]
    FX[js/slides/effects/effects-engine.js]
    TR[js/slides/transitions/transition-engine.js]
  end

  subgraph resilience [Resilience Stack]
    RE[js/core/recovery/recovery-engine.js]
    WD[js/core/watchdog/watchdog-hub.js]
    RJ[js/core/recovery/recovery-journal.js]
  end

  subgraph data [Data Stack]
    DBE[js/core/database/database-engine.js]
    TM[js/core/database/transaction-manager.js]
    BE[js/core/backup/backup-manager.js]
    WAL[scripts/storage/wal.ps1]
    ATOMIC[scripts/storage/atomic-save.ps1]
  end

  subgraph obs [Observabilidade]
    LOG[js/core/logging/log-service.js]
    DIAG[js/core/system-diagnostics.js]
  end

  subgraph ext [Extensibilidade]
    PLG[js/plugins/plugin-engine.js]
  end

  subgraph native [Nativo]
    EXE[SOMOSUM.exe]
    LAUNCHER[launcher/SomosumLauncher.cs]
  end

  surfaces --> ux
  surfaces --> product
  product --> render
  render --> resilience
  resilience --> data
  data --> obs
  ext -.-> product
  ext -.-> render
  EXE --> LAUNCHER
  LAUNCHER -->|Kestrel Engine| surfaces
```

### 3.1 Mapa de responsabilidades por camada

| Camada | Pasta principal | Responsabilidade |
|--------|-----------------|------------------|
| **Superfícies** | `control.html`, `screen.html`, `stage.html`, `remote.html` | Entry points HTML; bootstrap via `js/*/bootstrap.js` |
| **Controle** | `js/control/` | `control-app.js` (fachada), `upgrades-v2.js`, views, sync, services |
| **Projeção** | `js/screen/` | `screen-app.js`, `stage-app.js`, countdown, lyrics-fx |
| **Programa** | `js/program/` | Cultos, flatten de slides, ordem do culto |
| **Slides** | `js/slides/` | Engine v1/v2, templates, layers, effects, transitions |
| **Render (slides)** | `js/render/` | Queue, pipeline, caches, frame scheduler |
| **Render Engine (UI)** | `js/core/render-engine/` | SafeHTML, SafeDOM, patch, UI Kit, profiler — ver [`render-engine.md`](render-engine.md) |
| **Security** | `runtime/security/`, `js/core/security/` | Token, auth, static deny, middleware, audit — ver [`security.md`](security.md) |
| **Performance** | `runtime/performance/`, `js/core/performance/` | Lazy boot, memória, idle, frame budget, virtual lists — ver [`performance.md`](performance.md) |
| **Design System** | `css/design-system/`, `js/ui/` | Tokens, ThemeEngine, componentes, layout, a11y — ver [`design-system.md`](../design/design-system.md) |
| **Recovery** | `js/core/recovery/` | Crash, window, projection, sync, checkpoint |
| **Watchdog** | `js/core/watchdog/` | FPS, RAM, servidor, sync, IDB probes |
| **Database** | `js/core/database/` | Schema v4, repositories, transactions, IDB adapter |
| **Backup** | `js/core/backup/` + `scripts/storage/backup-engine.ps1` | ZIP, incremental, restauração parcial |
| **Storage** | `scripts/storage/` | Atomic save, checksum SHA256, WAL |
| **Logging** | `js/core/logging/` | LogService (ring buffer); `POST /api/log` → 204 (sem persistência); Diagnóstico para suporte |
| **Plugins** | `js/plugins/` | PluginHost, PluginEngine, API 2, **Plugin Studio**, Control Center (catálogo), hooks + quarantine |
| **UX** | `js/ux/` | Command palette (Ctrl+K), dock panels |
| **Servidor** | `controller/runtime/Somosum.Engine` (Kestrel) | HTTP local, API REST, static files, sync |
| **Nativo** | `launcher/` | WebView2, Painel, bandeja, monitores, janelas |

---

## 4. Runtime e boot

### 4.1 Sequência de inicialização

```mermaid
sequenceDiagram
  participant User
  participant EXE as SOMOSUM.exe
  participant Engine as Somosum.Engine
  participant Boot as boot-inline.js
  participant App as control-app.js

  User->>EXE: Duplo clique
  EXE->>Engine: Sobe Kestrel (porta local)
  EXE->>Boot: Abre Painel / Controle
  Boot->>Boot: Valida protocolo HTTP
  Boot->>App: Carrega módulos ES
  App->>App: RecoveryEngine.init(role=control)
  App->>App: WatchdogHub.start()
  App->>App: loadPluginsFromDisk()
  App->>App: activatePlugin() por superfície (sem hook boot)
```

### 4.2 Arquivos críticos de boot

| Arquivo | Função |
|---------|--------|
| `controller/runtime/Somosum.Engine` | Servidor Kestrel, APIs `/api/*`, static files |
| `controller/launcher/SomosumLauncher.cs` | EXE, bandeja, Painel, WebView2 |
| `js/core/boot-asset-loader.js` | Fetch `/api/app-meta`, injeta CSS, carrega boot-inline |
| `js/core/asset-registry.js` | URLs versionadas (`url()`, lazy groups) |
| `js/core/boot-inline.js` | Carrega scripts/módulos após ping |
| `js/control/bootstrap.js` | Import chain do controle |
| `js/core/bootstrap-logging.js` | Inicializa LogService |
| `js/core/error-boundary.js` | `window.onerror`, `safeCall()` |
| `js/control/upgrades-v2.js` | Wire: recovery, watchdog, plugins, palette |

### 4.3 Porta e tokens

- Porta padrão: **8765** (fallback: 5500, 9080, 5501)
- Porta persistida: `model/data/.port`
- Token sync LAN: `model/data/.remote-token`
- Estado sync: `model/data/.sync-state.json`

---

## 5. Fluxo de dados

### 5.1 Navegação de slide (controle → projeção)

```mermaid
sequenceDiagram
  participant Op as Operador
  participant CA as control-app.js
  participant Bus as ProjectionBus
  participant RE as RecoveryEngine
  participant SCR as screen-app.js

  Op->>CA: Próximo slide (→)
  CA->>CA: program.advance()
  CA->>RE: noteSlideSent()
  CA->>Bus: SLIDE_CHANGE + payload
  Bus->>SCR: BroadcastChannel
  SCR->>SCR: renderSlide()
  SCR->>Bus: HEARTBEAT ack
  Bus->>CA: ack recebido
  CA->>RE: noteSlideAck()
```

Se o ack não chegar em 3 s, `projection-recovery.js` dispara `pushFullState({ force: true })`.

### 5.2 Persistência (gravação em disco)

```mermaid
flowchart LR
  UI[control-app.js] -->|debounce 800ms| FS[file-store.js]
  FS -->|POST /api/save| API[Somosum.Engine]
  API --> JSON[model/data/*.json]
```

Pipeline atômico (`scripts/storage/atomic-save.ps1`):

1. Escreve em arquivo `.tmp`
2. Calcula SHA256 (`scripts/storage/checksum.ps1`)
3. Backup pré-write em `model/data/.backups/*.bak`
4. Rename atômico
5. Verifica checksum pós-gravação

### 5.3 IndexedDB (runtime)

| Store | Key | Conteúdo |
|-------|-----|----------|
| `songs` | `id` | Músicas e letras |
| `program` | `id` | Programa ativo |
| `meta` | `key` | Metadados runtime |
| `assets` | `key` | Assets do designer |
| `media` | `id` | Biblioteca de mídia |

Schema: `js/core/database/schema.js`  —  `SCHEMA_VERSION = 4`, `DB_NAME = 'somosum-db'`.

Fachada pública: `js/core/store.js` (mantida para retrocompatibilidade).

---

## 6. API REST local

### 6.1 Rotas principais

| Método | Rota | Descrição |
|--------|------|-----------|
| `GET` | `/api/health` | Versão, uptime, Konva, bíblias, `readyForService` |
| `GET` | `/api/diagnostics` | Checks completos (pacote, disco, LAN, performance) |
| `POST` | `/api/save?file=` | Grava JSON em `model/data/` (async, 202) |
| `POST` | `/api/save-media` | Grava mídia base64 |
| `GET` | `/api/sync/state` | Estado completo (requer token) |
| `GET` | `/api/sync/poll?since=` | Poll de mensagens sync |
| `POST` | `/api/sync/push` | Envia mensagem sync |
| `GET` | `/api/journal/status` | Status WAL (local only) |
| `POST` | `/api/journal/checkpoint` | Replay WAL pendente |
| `GET` | `/api/storage/integrity` | Checksums JSON críticos (sync) |
| `GET` | `/api/storage/integrity?async=1` | Job assíncrono de integridade |
| `GET` | `/api/backup.zip` | Exporta ZIP de `model/data/` (sync ou `?async=1`) |
| `GET` | `/api/backup/status` | Backups incrementais |
| `POST` | `/api/backup/incremental` | Cria backup incremental |
| `POST` | `/api/log` | Recebe batch de logs do cliente |

### 6.3 Jobs assíncronos (não bloqueantes)

Operações pesadas podem rodar em **jobs assíncronos** no Engine (integridade, backup ZIP) — poll via `?job={jobId}` sem bloquear sync ao vivo.

| Operação | Início | Poll |
|----------|--------|------|
| Integridade | `GET /api/storage/integrity?async=1` | `?job={jobId}` |
| Backup ZIP | `GET /api/backup.zip?async=1` | `?job={jobId}` |

Fluxo: `202 Accepted` + `jobId` → poll até `200` (resultado) ou timeout. Config do job em JSON temporário (`%TEMP%`).

**Modo Produção** (`js/core/production-mode.js`) agenda integrity async em background sem impactar latência de `/api/ping` ou sync.

### 6.4 Performance gate

| Script | Métrica |
|--------|---------|
| `scripts/tests/test-perf-gate.ps1` | Ping &lt; 50 ms, health &lt; 500 ms, slide-save &lt; 150 ms |
| `tests/benchmark.html` | Boot módulos, FPS render, slide switch (WebView2) |
| `tests/benchmark-harness.js` | Harness reutilizável para benchmark.html |

### 6.5 Segurança de rotas

- Rotas sensíveis (`/api/journal/*`, `/api/backup/*`, `/api/storage/integrity`) exigem `Test-IsLocalRequest` (127.0.0.1)
- Sync LAN exige token em `model/data/.remote-token` via header `X-Somosum-Token`

---

## 7. Launcher nativo (.NET / WebView2)

| Componente | Arquivo |
|------------|---------|
| Executável principal | `SOMOSUM.exe` (trampolim) + `app/SOMOSUM.exe` (runtime) |
| Remote dedicado | `app/SOMOSUM-Remote.exe` |
| Versão canônica | arquivo `VERSION` na raiz (+ `AppVersionFallback` no launcher) |
| Projeto shell | `controller/launcher/SomosumShell.csproj` |
| Engine HTTP | `controller/runtime/Somosum.Engine` (Kestrel) |
| Compilação | `scripts/compile-launcher.ps1` / `scripts/build-all.ps1` |

O launcher:

- Sobe o servidor **Kestrel** embutido (`Somosum.Engine`)
- Abre o **Painel Gerencial** em WebView2 (`model/data/.webview2/`)
- Gerencia a bandeja do sistema (menu completo: janelas, URLs, rede, ferramentas)
- Expõe bridge `somosumNative` (monitores, janelas, diagnóstico)

---

## 8. Estrutura do repositório (MVC)

```
SOMOSUM/
├── SOMOSUM.exe                  # trampolim (raiz)
├── VERSION, README.md, build-manifest.json
├── model/
│   ├── data/                    # JSON runtime, tokens, plugins
│   ├── storage/                 # bíblias offline, assets privados
│   └── content/                 # seed de build (hinários)
├── view/
│   ├── html/                    # control.html, screen.html, …
│   ├── css/, fonts/, IMG/, audio/, vendor/
│   └── sw.js, manifest.webmanifest
├── controller/
│   ├── js/                      # módulos ES (URLs /js/*)
│   ├── launcher/                # C# WebView2 + Painel
│   └── runtime/                 # Somosum.Engine (Kestrel)
├── app/                         # runtime .NET publicado
├── installer/, scripts/, docs/, logs/, dist/
└── system/media/                # mídia embutida
```

**URLs públicas estáveis** (`/control.html`, `/js/*`, `/css/*`) são mapeadas para disco por `ContentLayout.cs` — não renomear pastas MVC sem atualizar o runtime.

**Pastas de runtime do usuário (excluídas do ZIP de produção):**

- `model/data/.webview2/`  —  perfil WebView2
- `model/data/.backups/`  —  backups atômicos pré-write
- `model/data/.journal/`  —  Write-Ahead Log
- `logs/`  —  logs do servidor

---

## 9. Runtime Engine

**Somosum.Engine.dll** (Kestrel + managers) é o motor HTTP e de operações. A cascata JS (`SyncHub`, `RecoveryEngine`, DPE) continua ativa nas superfícies WebView2; U3 deixou `legacyFallback: false` / sync autoritativo no perfil de produção.

### 9.1 Estado atual (v8.7.9)

| Componente | Status |
|------------|--------|
| `controller/runtime/CONTRACTS.md` | Contrato Command/Event |
| `Somosum.Engine.dll` | Compilada; Kestrel + managers C# ativos |
| `RuntimeBridgeInjector` | Control + Projection + Stage |
| `js/runtime/runtime-client.js` | API JS única |
| `js/plugins/plugin-host.js` | Plugins API 2 — activate por superfície |
| Gates `test-runtime-*` / `test-u2-plugins` | Bloqueantes no `build-all` |

### 9.2 Arquitetura alvo

```mermaid
flowchart LR
  UI[WebView2 superfícies] --> RC[runtime-client.js]
  RC --> BR[RuntimeBridge COM]
  BR --> RT[Somosum.Engine.dll]
  RT --> EXE[SOMOSUM.exe / DisplayEnumerator]
```

UI captura input, envia Commands, recebe StateSnapshot e renderiza DOM. Orquestração, sync, recovery, display hash e budgets ficam no Runtime C#.

### 9.3 Feature flag

`model/data/config.json` → `runtimeEngine.enabled` (padrão `true`). Rollback — ver `docs/enterprise/RUNTIME-MIGRATION.md`.

### 9.4 Gates de verificação

| Gate | Script |
|------|--------|
| Bridge COM + client | `scripts/tests/test-runtime-bridge.ps1` |
| Managers + CONTRACTS | `scripts/tests/test-runtime-wiring.ps1` |
| Inventário timers | `scripts/tests/test-runtime-timer-audit.ps1` |
| Paridade tipografia/layout | `scripts/tests/test-runtime-layout-parity.ps1` |
| Anti-imports diretos | `scripts/tests/test-runtime-no-direct-calls.ps1` |

Integrados em `build-all.ps1` e `verify-enterprise-ready.ps1`. Evidências em `logs/runtime-*-inventory.json` e `dist/release-evidence/`.

---

## 10. Versionamento

Versão canônica: arquivo `VERSION` na raiz + `controller/js/core/app-meta.js` → `APP_VERSION = '8.8.15'`

Arquivos que devem manter a versão sincronizada (gate `test-docs-freshness`):

- `controller/js/core/boot-inline.js`
- `controller/launcher/SomosumLauncher.cs` (`AppVersionFallback`)
- `controller/launcher/SomosumShell.csproj` / `controller/runtime/Somosum.Engine.csproj`
- `installer/somosum-setup.iss`
- `view/sw.js` (nome do cache: `somosum-shell-v8.7.7`, revision via `/api/app-meta`)
- AssetRegistry + `build-manifest.json` (`/api/app-meta`)
- `README.md` / `docs/architecture/arquitetura.md`

---

## 11. Documentação relacionada

| Documento | Conteúdo |
|-----------|----------|
| `docs/architecture/documentacao-tecnica.md` | Ponte para documentação técnica atual (8.7.9) |
| Guias em `docs/guides/` | Backup, Strong, operação |
| `docs/architecture/worship-engine.md` | Worship Engine 8.0 |
| `docs/architecture/storage.md` | Storage Platform 8.0 |
| `docs/enterprise/PRODUCTION-RELEASE-8.0.0/` | Release production final |
| `docs/releases/RELEASE-NOTES-8.7.7.md` | Release notes 8.7.7 (plugins, Painel, chrome) |
| `docs/enterprise/CHECKLISTS.md` | Checklists enterprise |
| `docs/enterprise/THREAT-MODEL.md` | Modelo de ameaça LAN |
| `docs/enterprise/RUNTIME-MIGRATION.md` | Migração Runtime Engine |
| [`docs/enterprise/AUDITORIA-TECNICA.md`](../enterprise/AUDITORIA-TECNICA.md) | Auditoria técnica enterprise |
| Portal online | `http://127.0.0.1:PORTA/docs/` |

---

*Documento alinhado ao código SOMOSUM v8.7.9 — julho/2026.*
