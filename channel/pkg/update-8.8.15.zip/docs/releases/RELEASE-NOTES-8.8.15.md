# Release Notes — SOMOSUM 8.8.15

**Data:** 2026-08-19  
**Tipo:** correção da Mensagem Bíblica e painel do operador

## Destaques

- Ao escolher o **modelo do card** do pregador (Ficha, Retrato, Editorial…), a prévia aplica o visual e o **painel da direita permanece aberto** — não some mais.
- Clicar na **Mensagem Bíblica** (ou em outro item da ordem) abre a aba **Item** com fonte, foto, função (pregador/pregadora) e os 6 modelos do card.
- Fonte da mensagem e da letra continuam no seletor (família + peso); o catálogo de fontes não se apaga sozinho durante o culto.

## Como atualizar
1. Painel → **Sobre** → **Procurar novidades** (ou Controle → Ajuda → Verificar atualização).
2. Baixe **8.8.15** (passo seguinte da **8.8.14**).
3. Confirme o **reinício**. Na reabertura: boas-vindas e Sobre = **8.8.15**.

## Verificação rápida
- [ ] Sobre = **8.8.15**
- [ ] Mensagem Bíblica → aba **Item** → trocar o modelo do card: prévia muda e o inspetor **não some**
- [ ] Fonte da mensagem ainda aparece na lista e aplica na prévia
