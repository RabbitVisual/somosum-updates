# SOMOSUM — Roadmap

> **Versão estável atual:** **8.8.15** (arquivo `VERSION`)  
> **Última revisão:** 2026-07-24

---

## Princípios (invioláveis)

1. **100% offline** no culto — sem cloud, sem conta obrigatória
2. **Retrocompatibilidade** — backups, JSON e APIs sync preservados
3. **Sem bundler / npm em produção** — ES modules nativos
4. **Motor único** — `Somosum.Engine` (Kestrel)
5. **Gates bloqueantes** — `scripts/build-all.ps1` + enterprise audit
6. **Documentação e instalador 100% pt-BR**

---

## Já entregue (baseline de produção)

| Release | Foco |
|---------|------|
| **8.7.7** | Plugin Studio, Control Center catálogo, PluginHost API 2, Painel rebrand, chrome global, docs PT-BR |
| **8.7.0** | Pacote completo `culto-*` (8 plugins) |
| **8.2.4** | Sync Screen estável, Bíblia no projetor, docs/instalador pt-BR |
| **8.2.x** | Dark Studio, Live Console 3 colunas, hotfixes de projeção |
| **8.1.0** | Extreme Performance — WS-first, workers, projeção fluida |
| **8.0.0** | Worship Engine + Storage 8.0 + release production |
| **7.x** | Storage, Design System, Performance, Security, Render, Versioning |
| **6.x** | Kestrel, sync, painel, portal docs |

Detalhe: [`docs/changelog.md`](changelog.md).

---

## Próximos passos (pós-8.7.7)

| Prioridade | Item |
|------------|------|
| Alta | Certificado Authenticode no Setup (menos alerta do Windows) |
| Alta | Smoke automatizado Controle → Screen (Bíblia + letras + vídeo) |
| Alta | Persistência real de logs do `LogService` no servidor (hoje `/api/log` retorna 204) |
| Média | Identidade estável de projetor (EDID/perfil persistente exposto ao operador) |
| Média | Compositor Canvas maduro (opcional) sem risco de tela preta |
| Média | Empacotamento mais leve do instalador |
| Baixa | Storybook / catálogo visual do Design System |

---

## Não faremos

- Conta na nuvem obrigatória
- Dependência de internet no culto
- Bundler (Webpack/Vite) no runtime de produção
