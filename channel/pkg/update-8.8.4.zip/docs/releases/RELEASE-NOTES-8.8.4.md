# Release Notes — SOMOSUM 8.8.4

**Data:** 2026-08-08  
**Tipo:** correções de edição (inspetor) + plugins e Loja

## Destaques

### Edição de slides mais confiável
- **O fundo não some mais** ao mudar fonte, cor ou tamanho do texto. Antes, ao escolher um vídeo/imagem de fundo e depois ajustar a tipografia, o fundo voltava para o gradiente dourado do tema — corrigido.
- **Letras** agora mudam **cor do título/letra** e a **legibilidade** (contorno/sombra/placa, escurecer o fundo, posição vertical).
- **Aumentar/diminuir a fonte funciona** também em **Oferta**, **Pausa/Contagem**, **Ceia** e **Participação** (antes o tamanho era fixo nesses tipos).
- **Participação** passa a respeitar as **cores** definidas no inspetor (nome e música).
- **Boas-vindas** ganhou **seletor de fonte** (família) — o texto muda de fonte de verdade na prévia e no projetor.

### Plugins e Loja
- **Texto ao vivo no projetor:** quando um plugin (ex.: Texto livre) já está no ar, editar o texto no Studio **atualiza a projeção em tempo real** (sem precisar projetar de novo).
- **Loja:** ao **instalar ou remover** um plugin, o **menu lateral e ajustes atualizam na hora** (antes, às vezes só depois de recarregar).
- **Botão “Abrir”** do plugin instalado leva **direto ao Studio** do plugin.
- **Correção de aviso falso:** durante o **pré-culto (contagem no ar)**, o plugin de texto não diz mais “projetado” quando na verdade nada foi para a tela.

## Como atualizar
1. Se estiver em **8.8.3**: Ajuda → Verificar atualização → **8.8.4** → confirme o reinício.
2. Se estiver em **8.7.x / 8.8.0–8.8.2**: aplique o próximo passo oferecido (reinicie e verifique de novo até chegar em 8.8.4).
3. Em **Sobre** deve aparecer **8.8.4**.

## Verificação rápida
- [ ] Sobre = **8.8.4**
- [ ] Definir vídeo de fundo → mudar fonte/cor/tamanho: o fundo **permanece**
- [ ] Letras: mudar cor do texto e legibilidade → aplica
- [ ] Oferta/Pausa/Ceia/Participação: aumentar a fonte → cresce
- [ ] Boas-vindas: trocar a fonte → muda na prévia e no projetor
- [ ] Plugin Texto livre no ar → editar texto no Studio atualiza o projetor
- [ ] Loja: instalar/remover → menu atualiza na hora; “Abrir” abre o Studio
