/**
 * Loja de Plugins — catalogo, install/update/uninstall (offline-first + CDN).
 */
import { DiskAdapter } from '../core/storage/adapters/disk-adapter.js';
import { formatPluginPackError, isOnline } from './plugin-pack-errors.js';
import { reloadPlugins, listPluginsDetailed } from './plugin-host.js';
import { installPackWithRemoteFallback } from '../core/pack-remote-fetch.js';
import { fetchCatalog } from '../core/catalog-proxy-fetch.js';

const MANIFEST_URL = '/content/packs/plugins/manifest.json';
const MANIFEST_API = '/api/content/packs/plugins/manifest';

/** Ocultos da Loja / bloqueados até liberação (OAuth Google em verificação). */
export const STORE_BLOCKED_PLUGIN_IDS = new Set(['google-drive-backup']);

let _manifestPromise = null;

function normalizePluginEntry(p) {
  const pricing = p.pricing && typeof p.pricing === 'object' ? p.pricing : {};
  const license = p.license && typeof p.license === 'object' ? p.license : {};
  const id = String(p.id || '').toLowerCase();
  const listed = !STORE_BLOCKED_PLUGIN_IDS.has(id) && p.listed !== false;
  return {
    id,
    name: String(p.name || p.id || ''),
    tagline: String(p.tagline || p.description || ''),
    description: String(p.description || ''),
    longDescription: String(p.longDescription || p.description || ''),
    howTo: String(p.howTo || ''),
    changelog: String(p.changelog || ''),
    version: String(p.version || '1.0.0'),
    minHostVersion: String(p.minHostVersion || ''),
    api: Number(p.api) || 2,
    author: String(p.author || 'SOMOSUM'),
    publisher: String(p.publisher || 'SOMOSUM'),
    category: String(p.category || 'culto'),
    tags: Array.isArray(p.tags) ? p.tags : [],
    hooks: Array.isArray(p.hooks) ? p.hooks : [],
    capabilities: Array.isArray(p.capabilities) ? p.capabilities : [],
    icon: String(p.icon || 'assets/icon.png'),
    banner: String(p.banner || ''),
    screenshots: Array.isArray(p.screenshots) ? p.screenshots : [],
    featured: !!p.featured && listed,
    listed,
    sortOrder: Number(p.sortOrder) || 99,
    file: String(p.file || `${p.id}.zip`),
    bytes: Number(p.bytes) || 0,
    sha256: String(p.sha256 || '').trim().toLowerCase(),
    remotePath: String(p.remotePath || '').trim(),
    defaultEnabled: p.defaultEnabled !== false,
    pricing: {
      model: String(pricing.model || p.priceModel || 'free'),
      priceDisplay: String(pricing.priceDisplay || (pricing.model === 'paid' ? '' : 'Grátis')),
      futurePriceDisplay: String(pricing.futurePriceDisplay || ''),
      comingSoonPaid: !!(pricing.comingSoonPaid ?? p.comingSoonPaid),
      currency: String(pricing.currency || 'BRL'),
    },
    license: {
      sku: String(license.sku || ''),
      tier: String(license.tier || 'standard'),
      plan: String(license.plan || pricing.model || 'free'),
    },
  };
}

function isStoreListedPlugin(p) {
  return !!p?.id && p.listed !== false && !STORE_BLOCKED_PLUGIN_IDS.has(p.id);
}

function mergeManifests(local, remote) {
  if (!remote?.plugins?.length) return local;
  const byId = new Map((local.plugins || []).map((p) => [p.id, p]));
  for (const rp of remote.plugins) {
    const plug = normalizePluginEntry(rp);
    if (!plug.id) continue;
    const existing = byId.get(plug.id);
    if (existing) {
      const remoteNewer = compareVersions(plug.version, existing.version) > 0;
      // Offline-first: pacote local (com ícones/assets) tem prioridade até haver versão remota mais nova.
      byId.set(plug.id, {
        ...existing,
        ...plug,
        file: existing.file || plug.file,
        sha256: remoteNewer && plug.sha256 ? plug.sha256 : (existing.sha256 || plug.sha256),
        bytes: remoteNewer && plug.sha256 ? (plug.bytes || existing.bytes) : (existing.bytes || plug.bytes),
        remotePath: plug.remotePath || existing.remotePath,
        version: plug.version || existing.version,
        changelog: plug.changelog || existing.changelog,
        icon: existing.icon || plug.icon,
        banner: existing.banner || plug.banner,
      });
    } else {
      byId.set(plug.id, plug);
    }
  }
  return {
    ...local,
    cdnBaseUrl: remote.cdnBaseUrl || local.cdnBaseUrl,
    remoteCatalogUrl: remote.remoteCatalogUrl || local.remoteCatalogUrl,
    plugins: [...byId.values()]
      .filter(isStoreListedPlugin)
      .sort((a, b) => a.sortOrder - b.sortOrder),
  };
}

export function compareVersions(a, b) {
  const parts = (v) => String(v || '0').split('.').map((x) => parseInt(x, 10) || 0);
  const pa = parts(a);
  const pb = parts(b);
  for (let i = 0; i < 3; i += 1) {
    const da = pa[i] || 0;
    const db = pb[i] || 0;
    if (da !== db) return da - db;
  }
  return 0;
}

export function formatPackSize(bytes) {
  const n = Number(bytes) || 0;
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(0)} KB`;
  return `${(n / (1024 * 1024)).toFixed(1)} MB`;
}

export function invalidatePluginPackManifest() {
  _manifestPromise = null;
}

export async function fetchPluginPackManifest({ force = false } = {}) {
  if (force) _manifestPromise = null;
  if (!_manifestPromise) {
    _manifestPromise = (async () => {
      let res = await fetch(MANIFEST_URL, { cache: 'no-store' });
      if (!res.ok) res = await fetch(MANIFEST_API, { cache: 'no-store' });
      if (!res.ok) throw new Error(`manifest_fetch_${res.status}`);
      const data = await res.json();
      let manifest = {
        version: Number(data?.version) || 1,
        hostVersion: String(data?.hostVersion || window.SOMOSUM_VERSION || ''),
        cdnBaseUrl: String(data?.cdnBaseUrl || '').trim().replace(/\/+$/, ''),
        remoteCatalogUrl: String(data?.remoteCatalogUrl || '').trim(),
        plugins: (Array.isArray(data?.plugins) ? data.plugins : [])
          .map(normalizePluginEntry)
          .filter(isStoreListedPlugin),
      };

      if (manifest.remoteCatalogUrl && isOnline()) {
        try {
          const remoteRes = await fetchCatalog(`${manifest.remoteCatalogUrl}${manifest.remoteCatalogUrl.includes('?') ? '&' : '?'}_=${Date.now()}`);
          if (remoteRes.ok) {
            const remoteData = await remoteRes.json();
            manifest = mergeManifests(manifest, remoteData);
          }
        } catch { /* CDN opcional */ }
      }
      manifest.plugins = (manifest.plugins || []).filter(isStoreListedPlugin);
      return manifest;
    })();
  }
  return _manifestPromise;
}

async function loadConfigRaw() {
  return DiskAdapter.load('config.json').catch(() => ({}));
}

async function saveInstalledState(id, patch) {
  const cfg = await loadConfigRaw();
  const raw = cfg?.installedPluginPacks && typeof cfg.installedPluginPacks === 'object'
    ? { ...cfg.installedPluginPacks }
    : {};
  raw[id] = { ...(raw[id] || {}), ...patch, updatedAt: Date.now() };
  await DiskAdapter.save('config.json', {
    ...cfg,
    installedPluginPacks: raw,
    updatedAt: Date.now(),
  }, { silent: true });
  return raw;
}

async function removeInstalledState(id) {
  const cfg = await loadConfigRaw();
  const raw = cfg?.installedPluginPacks && typeof cfg.installedPluginPacks === 'object'
    ? { ...cfg.installedPluginPacks }
    : {};
  delete raw[id];
  await DiskAdapter.save('config.json', {
    ...cfg,
    installedPluginPacks: raw,
    updatedAt: Date.now(),
  }, { silent: true });
}

export function getInstalledPluginPacks(cfg = {}) {
  const raw = cfg?.installedPluginPacks;
  return raw && typeof raw === 'object' ? { ...raw } : {};
}

export function isPluginPackInstalled(cfg, pluginId) {
  return !!getInstalledPluginPacks(cfg)[String(pluginId || '').toLowerCase()]?.installedAt;
}

export async function fetchPluginInstallInfo(pluginId) {
  const id = String(pluginId || '').toLowerCase();
  const res = await fetch(`/api/content/packs/plugins/info?id=${encodeURIComponent(id)}`, { cache: 'no-store' });
  if (!res.ok) return { id, installed: false };
  return res.json();
}

export async function getPluginInstallState(pluginId, catalogPlugin = null) {
  const id = String(pluginId || '').toLowerCase();
  const cfg = await loadConfigRaw();
  const packState = getInstalledPluginPacks(cfg)[id];
  const info = await fetchPluginInstallInfo(id);
  const installed = !!info.installed;
  const installedVersion = String(info.installedVersion || packState?.version || '');
  const catalogVersion = String(catalogPlugin?.version || info.catalogVersion || '');
  const updateAvailable = installed && catalogVersion
    && compareVersions(catalogVersion, installedVersion) > 0;

  const detailed = listPluginsDetailed().find((p) => p.id === id);

  return {
    id,
    installed,
    installedVersion,
    catalogVersion,
    updateAvailable,
    enabled: detailed?.enabled ?? true,
    quarantined: detailed?.quarantined ?? false,
    lastError: detailed?.lastError ?? null,
    installedAt: packState?.installedAt || null,
  };
}

async function postInstallReload(pluginId, version, sha256) {
  await saveInstalledState(pluginId, {
    version,
    sha256,
    installedAt: Date.now(),
  });
  await reloadPlugins();
  try {
    localStorage.setItem('somosum-plugins-reload', String(Date.now()));
  } catch { /* ignore */ }
  try {
    if (typeof BroadcastChannel !== 'undefined') {
      const ch = new BroadcastChannel('somosum-plugins');
      ch.postMessage({ type: 'reload', pluginId });
      ch.close?.();
    }
  } catch { /* ignore */ }
  try {
    const { notifyContributionsChanged } = await import('./contributions.js');
    notifyContributionsChanged('*');
  } catch { /* ignore */ }
}

async function runPluginPackAction(plug, { isUpdate, onProgress } = {}) {
  const id = String(plug.id || '').toLowerCase();
  const manifest = await fetchPluginPackManifest();
  const { secureFetch } = await import('../core/security/api-security.js');
  const localUrl = `/content/packs/plugins/${encodeURIComponent(plug.file)}`;
  const base = isUpdate ? '/api/content/packs/plugins/update' : '/api/content/packs/plugins/install';
  const bytesBase = isUpdate ? '/api/content/packs/plugins/update-bytes' : '/api/content/packs/plugins/install-bytes';

  const data = await installPackWithRemoteFallback({
    manifest,
    pack: plug,
    localUrl,
    installUrl: base,
    installBytesUrl: bytesBase,
    onProgress,
    secureFetch,
  });

  onProgress?.('activate', 90);
  await postInstallReload(id, data.version || plug.version, plug.sha256);
  onProgress?.('done', 100);
  return data;
}

export async function installPluginPack(pluginId, { onProgress } = {}) {
  const id = String(pluginId || '').toLowerCase();
  if (STORE_BLOCKED_PLUGIN_IDS.has(id)) throw new Error('plugin_unavailable');
  const manifest = await fetchPluginPackManifest();
  const plug = manifest.plugins.find((p) => p.id === id);
  if (!plug) throw new Error('pack_not_found');
  return runPluginPackAction(plug, { isUpdate: false, onProgress });
}

export async function updatePluginPack(pluginId, { onProgress } = {}) {
  const id = String(pluginId || '').toLowerCase();
  if (STORE_BLOCKED_PLUGIN_IDS.has(id)) throw new Error('plugin_unavailable');
  const manifest = await fetchPluginPackManifest();
  const plug = manifest.plugins.find((p) => p.id === id);
  if (!plug) throw new Error('pack_not_found');
  return runPluginPackAction(plug, { isUpdate: true, onProgress });
}

export async function uninstallPluginPack(pluginId, { onProgress } = {}) {
  const id = String(pluginId || '').toLowerCase();
  onProgress?.('remove', 20);

  try {
    const { deactivatePlugin } = await import('./plugin-host.js');
    await deactivatePlugin(id);
  } catch { /* ignore */ }

  const { secureFetch } = await import('../core/security/api-security.js');
  const res = await secureFetch('/api/content/packs/plugins/uninstall', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json; charset=utf-8' },
    body: JSON.stringify({ id }),
  });
  if (!res.ok) {
    const t = await res.text().catch(() => '');
    throw new Error(t || 'uninstall_failed');
  }

  await removeInstalledState(id);
  onProgress?.('reload', 70);
  await reloadPlugins();
  try {
    const { notifyContributionsChanged } = await import('./contributions.js');
    notifyContributionsChanged('*');
  } catch { /* ignore */ }
  onProgress?.('done', 100);
  return res.json();
}

export { formatPluginPackError };
