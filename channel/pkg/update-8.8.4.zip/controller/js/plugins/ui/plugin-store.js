/**
 * Loja de Plugins — catálogo, filtros dinâmicos, install com progresso.
 */
import { faIconRaw } from '../../core/fa-icons.js';
import {
  fetchPluginPackManifest,
  formatPackSize,
  formatPluginPackError,
  getPluginInstallState,
  installPluginPack,
  updatePluginPack,
} from '../plugin-pack-service.js';
import { isOnline } from '../plugin-pack-errors.js';
import { openPluginStoreDetail } from './plugin-store-detail.js';
import { pluginStoreIconHtml } from './plugin-store-icons.js';
import { openPluginStudio } from '../studio/register-plugin-studio.js';

function esc(t) {
  const d = document.createElement('div');
  d.textContent = t ?? '';
  return d.innerHTML;
}

function hasStudio(plug) {
  const caps = plug?.capabilities || [];
  return caps.includes('ui.nav') && caps.includes('ui.view');
}

function categoryLabel(cat) {
  const map = {
    culto: 'Culto',
    equipe: 'Equipe',
    'projeção': 'Projeção',
    projecao: 'Projeção',
    utilidades: 'Utilidades',
  };
  return map[cat] || String(cat || 'Plugin').replace(/^\w/, (c) => c.toUpperCase());
}

function statusBadge(state) {
  if (state?.updateAvailable) {
    return '<span class="ps-badge ps-badge--update">Há novidade</span>';
  }
  if (state?.installed) {
    return '<span class="ps-badge ps-badge--ok">Instalado</span>';
  }
  return '<span class="ps-badge ps-badge--new">Disponível</span>';
}

function priceChip(plug) {
  const p = plug?.pricing;
  if (p?.model === 'paid' && p.priceDisplay) {
    return `<span class="ps-badge ps-badge--paid">${esc(p.priceDisplay)}</span>`;
  }
  return '';
}

function iconHtml(plug, opts = {}) {
  return pluginStoreIconHtml(plug, opts);
}

function cardPrimaryAction(plug, state) {
  if (state?.updateAvailable) {
    return `<button type="button" class="ps-btn ps-btn--primary ps-card-update">Atualizar</button>`;
  }
  if (state?.installed) {
    if (hasStudio(plug)) {
      return `<button type="button" class="ps-btn ps-btn--ghost ps-card-open">Abrir</button>`;
    }
    return `<span class="ps-card-done">${faIconRaw('check', 'su-fa')} Pronto</span>`;
  }
  return `<button type="button" class="ps-btn ps-btn--primary ps-card-install">Instalar</button>`;
}

/**
 * @param {HTMLElement} root
 * @param {object} app
 */
export async function mountPluginStore(root, app) {
  if (!root) return;

  root.innerHTML = `<div class="plugin-store" id="plugin-store-root">
    <div class="ps-loading" role="status">
      <span class="ps-loading-spin" aria-hidden="true"></span>
      <p>Carregando catálogo…</p>
    </div>
  </div>`;

  const host = root.querySelector('#plugin-store-root');
  let manifest;
  try {
    manifest = await fetchPluginPackManifest();
  } catch (err) {
    host.innerHTML = `<div class="ps-empty ps-empty--error">
      <p class="ps-empty-title">Catálogo indisponível</p>
      <p>${esc(formatPluginPackError(err))}</p>
      <button type="button" class="ps-btn ps-btn--primary" id="ps-retry">Tentar novamente</button>
    </div>`;
    host.querySelector('#ps-retry')?.addEventListener('click', () => void mountPluginStore(root, app));
    return;
  }

  const plugins = [...(manifest.plugins || [])].sort((a, b) => (a.sortOrder ?? 99) - (b.sortOrder ?? 99));
  const stateMap = new Map();
  await Promise.all(plugins.map(async (p) => {
    stateMap.set(p.id, await getPluginInstallState(p.id, p));
  }));

  let filter = 'all';
  let query = '';
  let busyId = null;

  const categories = [...new Set(plugins.map((p) => p.category).filter(Boolean))];
  const featured = plugins.filter((p) => p.featured).slice(0, 3);

  const buildFilters = () => {
    const base = [
      { id: 'all', label: 'Todos' },
      { id: 'installed', label: 'Instalados' },
      { id: 'updates', label: 'Atualizações' },
    ];
    return [
      ...base,
      ...categories.map((c) => ({ id: `cat:${c}`, label: categoryLabel(c) })),
    ];
  };

  const counts = () => {
    const vals = [...stateMap.values()];
    return {
      total: plugins.length,
      installed: vals.filter((s) => s.installed).length,
      updates: vals.filter((s) => s.updateAvailable).length,
    };
  };

  const filterMatches = (plug) => {
    const st = stateMap.get(plug.id);
    const q = query.trim().toLowerCase();
    if (q) {
      const hay = `${plug.name} ${plug.tagline} ${plug.description} ${(plug.tags || []).join(' ')} ${plug.category}`.toLowerCase();
      if (!hay.includes(q)) return false;
    }
    if (filter === 'installed') return !!st?.installed;
    if (filter === 'updates') return !!st?.updateAvailable;
    if (filter.startsWith('cat:')) return plug.category === filter.slice(4);
    return true;
  };

  const renderFeatured = () => {
    if (!featured.length) return '';
    return `
      <section class="ps-spotlight" aria-label="Em destaque">
        <div class="ps-spotlight-head">
          <h2>Em destaque</h2>
          <p>Extensões essenciais para o culto</p>
        </div>
        <div class="ps-spotlight-grid">
          ${featured.map((p) => {
            const st = stateMap.get(p.id) || {};
            return `
              <article class="ps-spot-card" data-ps-id="${esc(p.id)}" tabindex="0" role="button">
                ${iconHtml(p, { sizeClass: 'ps-icon--lg' })}
                <div class="ps-spot-body">
                  <div class="ps-spot-top">
                    <h3>${esc(p.name)}</h3>
                    ${statusBadge(st)}
                  </div>
                  <p>${esc(p.tagline || p.description)}</p>
                  <div class="ps-spot-meta">
                    <span>v${esc(p.version)}</span>
                    <span>${esc(categoryLabel(p.category))}</span>
                    <span>${esc(formatPackSize(p.bytes))}</span>
                    ${priceChip(p)}
                  </div>
                </div>
                <div class="ps-spot-foot" data-ps-actions>
                  ${cardPrimaryAction(p, st)}
                  <button type="button" class="ps-btn ps-btn--ghost ps-card-detail">Detalhes</button>
                </div>
                <div class="ps-card-progress" hidden>
                  <div class="ps-card-progress-bar"><span></span></div>
                  <span class="ps-card-progress-label"></span>
                </div>
              </article>`;
          }).join('')}
        </div>
      </section>`;
  };

  const renderGrid = () => {
    const list = plugins.filter(filterMatches);
    if (!list.length) {
      const msg = filter === 'installed'
        ? 'Nenhum plugin instalado ainda. Explore o catálogo e instale com um clique.'
        : filter === 'updates'
          ? 'Tudo atualizado — nenhuma atualização pendente.'
          : query
            ? `Nenhum resultado para “${query.trim()}”.`
            : 'Nenhum plugin neste filtro.';
      return `<div class="ps-empty"><p class="ps-empty-title">${esc(msg)}</p></div>`;
    }
    return `<div class="ps-grid">${list.map((p) => {
      const st = stateMap.get(p.id) || {};
      return `
        <article class="ps-card" data-ps-id="${esc(p.id)}" tabindex="0" role="button">
          <div class="ps-card-top">
            ${iconHtml(p)}
            <div class="ps-card-titles">
              <h3>${esc(p.name)}</h3>
              <p class="ps-card-tag">${esc(p.tagline || p.description)}</p>
            </div>
            ${statusBadge(st)}
          </div>
          <div class="ps-card-meta">
            <span>v${esc(p.version)}</span>
            <span>${esc(categoryLabel(p.category))}</span>
            <span>${esc(p.publisher || 'SOMOSUM')}</span>
            ${priceChip(p)}
          </div>
          <div class="ps-card-foot" data-ps-actions>
            ${cardPrimaryAction(p, st)}
            <button type="button" class="ps-btn ps-btn--ghost ps-card-detail">Ver</button>
          </div>
          <div class="ps-card-progress" hidden>
            <div class="ps-card-progress-bar"><span></span></div>
            <span class="ps-card-progress-label"></span>
          </div>
        </article>`;
    }).join('')}</div>`;
  };

  const renderShell = () => {
    const c = counts();
    const offline = !isOnline()
      ? '<span class="ps-pill ps-pill--warn">Sem internet · lista local</span>'
      : '<span class="ps-pill ps-pill--ok">Com internet</span>';

    host.innerHTML = `
      <header class="ps-hero">
        <div class="ps-hero-copy">
          <p class="ps-kicker">SOMOSUM · Recursos extras</p>
          <h1>Loja de Plugins</h1>
          <p class="ps-hero-lead">Instale recursos extras para o culto. Depois de instalados, funcionam neste PC mesmo sem internet.</p>
        </div>
        <div class="ps-hero-stats" aria-label="Resumo">
          <div class="ps-stat"><strong>${c.total}</strong><span>disponíveis</span></div>
          <div class="ps-stat"><strong>${c.installed}</strong><span>instalados</span></div>
          <div class="ps-stat${c.updates ? ' is-alert' : ''}"><strong>${c.updates}</strong><span>com novidade</span></div>
          ${offline}
        </div>
      </header>

      <div class="ps-toolbar">
        <label class="ps-search">
          <span class="ps-search-ico" aria-hidden="true">${faIconRaw('magnifying-glass', 'su-fa')}</span>
          <input type="search" id="ps-search" placeholder="Buscar por nome, tag ou categoria…" autocomplete="off" value="${esc(query)}" />
        </label>
        <div class="ps-filters" role="tablist" aria-label="Filtros">
          ${buildFilters().map((f) => `
            <button type="button" class="ps-filter${filter === f.id ? ' is-active' : ''}"
              data-ps-filter="${esc(f.id)}" role="tab" aria-selected="${filter === f.id}">
              ${esc(f.label)}
            </button>`).join('')}
        </div>
      </div>

      <div class="ps-body">
        ${filter === 'all' && !query ? renderFeatured() : ''}
        <section class="ps-catalog" aria-label="Catálogo">
          <div class="ps-catalog-head">
            <h2>${filter === 'all' && !query ? 'Todos os plugins' : 'Resultados'}</h2>
            <span class="ps-catalog-count">${plugins.filter(filterMatches).length} de ${plugins.length}</span>
          </div>
          <div id="ps-grid-host">${renderGrid()}</div>
        </section>
      </div>`;
  };

  const refreshStates = async () => {
    await Promise.all(plugins.map(async (p) => {
      stateMap.set(p.id, await getPluginInstallState(p.id, p));
    }));
    renderShell();
    bindEvents();
  };

  const setCardProgress = (card, phase, pct = 0) => {
    const wrap = card?.querySelector('.ps-card-progress');
    const bar = wrap?.querySelector('.ps-card-progress-bar span');
    const label = wrap?.querySelector('.ps-card-progress-label');
    if (!wrap || !bar || !label) return;
    wrap.hidden = false;
    const labels = {
      download: `Baixando… ${pct}%`,
      extract: `Instalando… ${pct}%`,
      activate: 'Ativando…',
      reload: 'Atualizando menus…',
      done: 'Concluído',
    };
    label.textContent = labels[phase] || 'Preparando…';
    const w = phase === 'download' ? Math.max(8, pct * 0.45)
      : phase === 'extract' ? 45 + pct * 0.35
      : phase === 'activate' ? 85
      : phase === 'reload' ? 92
      : 100;
    bar.style.width = `${w}%`;
  };

  const openDetail = async (id) => {
    const plug = plugins.find((p) => p.id === id);
    if (!plug) return;
    const state = await getPluginInstallState(id, plug);
    stateMap.set(id, state);
    openPluginStoreDetail({
      plug,
      state,
      app,
      onChanged: async () => {
        await refreshStates();
      },
    });
  };

  const runInstallOnCard = async (card, id, isUpdate = false) => {
    if (busyId) return;
    const plug = plugins.find((p) => p.id === id);
    if (!plug || !card) return;
    busyId = id;
    card.classList.add('is-busy');
    card.querySelectorAll('[data-ps-actions] button').forEach((b) => { b.disabled = true; });
    try {
      const fn = isUpdate ? updatePluginPack : installPluginPack;
      await fn(id, {
        onProgress: (phase, pct) => setCardProgress(card, phase, pct),
      });
      setCardProgress(card, 'done', 100);
      app?.toast?.(isUpdate
        ? `"${plug.name}" atualizado`
        : `"${plug.name}" instalado`, 'success');
      await refreshStates();
      await openDetail(id);
    } catch (err) {
      app?.toast?.(formatPluginPackError(err), 'error');
      const prog = card.querySelector('.ps-card-progress');
      if (prog) prog.hidden = true;
      card.querySelectorAll('[data-ps-actions] button').forEach((b) => { b.disabled = false; });
      card.classList.remove('is-busy');
    } finally {
      busyId = null;
    }
  };

  const bindCardActions = () => {
    host.querySelectorAll('.ps-card-install').forEach((btn) => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const card = btn.closest('[data-ps-id]');
        void runInstallOnCard(card, card?.dataset?.psId, false);
      });
    });
    host.querySelectorAll('.ps-card-update').forEach((btn) => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const card = btn.closest('[data-ps-id]');
        void runInstallOnCard(card, card?.dataset?.psId, true);
      });
    });
    host.querySelectorAll('.ps-card-open').forEach((btn) => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const id = btn.closest('[data-ps-id]')?.dataset?.psId;
        if (!id) return;
        // "Abrir" leva direto ao Studio do plugin; se não der, abre o detalhe.
        if (!openPluginStudio(app, id)) void openDetail(id);
      });
    });
    host.querySelectorAll('.ps-card-detail').forEach((btn) => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const id = btn.closest('[data-ps-id]')?.dataset?.psId;
        if (id) void openDetail(id);
      });
    });
  };

  const wireCards = () => {
    host.querySelectorAll('.ps-card, .ps-spot-card').forEach((el) => {
      el.addEventListener('click', (e) => {
        if (e.target.closest('button, [data-ps-actions]')) return;
        void openDetail(el.dataset.psId);
      });
      el.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          void openDetail(el.dataset.psId);
        }
      });
    });
  };

  const bindEvents = () => {
    host.querySelector('#ps-search')?.addEventListener('input', (e) => {
      query = e.target.value;
      const gridHost = host.querySelector('#ps-grid-host');
      if (gridHost) gridHost.innerHTML = renderGrid();
      const countEl = host.querySelector('.ps-catalog-count');
      if (countEl) countEl.textContent = `${plugins.filter(filterMatches).length} de ${plugins.length}`;
      const spotlight = host.querySelector('.ps-spotlight');
      if (spotlight) spotlight.hidden = !!(query || filter !== 'all');
      bindCardActions();
      wireCards();
    });

    host.querySelectorAll('[data-ps-filter]').forEach((btn) => {
      btn.addEventListener('click', () => {
        filter = btn.dataset.psFilter;
        renderShell();
        bindEvents();
      });
    });

    wireCards();
    bindCardActions();
  };

  renderShell();
  bindEvents();
}
