/**
 * ContributionRegistry — slots de UI/ações para plugins (nav, toolbar, settings, etc.).
 */
const byKind = new Map();
const listeners = new Set();
let _seq = 0;

function kindMap(kind) {
  if (!byKind.has(kind)) byKind.set(kind, new Map());
  return byKind.get(kind);
}

function notify(kind) {
  for (const fn of listeners) {
    try { fn(kind); } catch { /* ignore */ }
  }
}

/**
 * @param {string} kind — nav | toolbar | settings | command | remoteAction | stageLayout | view | template
 * @param {object} entry — must include pluginId; optional id, order, when
 */
export function contribute(kind, entry) {
  if (!kind || !entry?.pluginId) return null;
  const id = entry.id || `${entry.pluginId}:${++_seq}`;
  const record = {
    ...entry,
    id: String(id),
    pluginId: String(entry.pluginId),
    order: Number.isFinite(entry.order) ? entry.order : 100,
    kind: String(kind),
  };
  kindMap(kind).set(record.id, record);
  notify(kind);
  return record.id;
}

export function removeContribution(kind, id) {
  const map = byKind.get(kind);
  if (!map) return false;
  const ok = map.delete(String(id));
  if (ok) notify(kind);
  return ok;
}

export function clearContributionsForPlugin(pluginId) {
  const pid = String(pluginId);
  let changed = false;
  for (const [kind, map] of byKind) {
    for (const [id, entry] of [...map.entries()]) {
      if (entry.pluginId === pid) {
        map.delete(id);
        changed = true;
      }
    }
    if (changed) notify(kind);
  }
  return changed;
}

export function clearAllContributions() {
  byKind.clear();
  notify('*');
}

export function listContributions(kind, ctx = null) {
  const map = byKind.get(kind);
  if (!map) return [];
  const list = [...map.values()].sort((a, b) => (a.order - b.order) || String(a.id).localeCompare(String(b.id)));
  if (!ctx) return list;
  return list.filter((e) => {
    if (typeof e.when !== 'function') return true;
    try { return !!e.when(ctx); } catch { return false; }
  });
}

/** Merge nav contributions into core NAV_GROUPS shape. */
export function mergeNavGroups(baseGroups = [], ctx = null) {
  const groups = baseGroups.map((g) => ({
    ...g,
    items: [...(g.items || [])],
  }));
  const byId = new Map(groups.map((g) => [g.id, g]));
  for (const c of listContributions('nav', ctx)) {
    const groupId = c.group || 'plugins';
    let group = byId.get(groupId);
    if (!group) {
      group = { id: groupId, label: c.groupLabel || 'Plugins', items: [] };
      groups.push(group);
      byId.set(groupId, group);
    }
    if (group.items.some((i) => i.id === c.viewId || i.id === c.id)) continue;
    group.items.push({
      id: c.viewId || c.id,
      title: c.title || c.label || c.id,
      label: c.label || c.id,
      iconKey: c.iconKey || 'puzzle',
      hint: c.hint || '',
      pluginId: c.pluginId,
      order: c.order,
    });
    group.items.sort((a, b) => (a.order ?? 100) - (b.order ?? 100));
  }
  return groups;
}

/** Merge settings.section contributions into core SETTINGS_SECTIONS shape. */
export function mergeSettingsSections(baseSections = [], ctx = null) {
  const sections = baseSections.map((s) => ({ ...s }));
  const byId = new Map(sections.map((s) => [s.id, s]));
  for (const c of listContributions('settings', ctx)) {
    const id = String(c.sectionId || c.id || '').replace(/^plugin:/, '') || `plugin-${c.pluginId}`;
    const sectionId = id.startsWith('plugin-') ? id : `plugin-${id}`;
    if (byId.has(sectionId) || byId.has(c.sectionId) || byId.has(c.id)) continue;
    const section = {
      id: sectionId,
      label: c.label || c.title || c.pluginId,
      hint: c.hint || 'Extensão',
      icon: c.iconKey || c.icon || 'puzzle-piece',
      lead: c.lead || c.description || '',
      pluginId: c.pluginId,
      order: c.order,
      render: typeof c.render === 'function' ? c.render : null,
      contributionId: c.id,
    };
    sections.push(section);
    byId.set(section.id, section);
  }
  return sections.sort((a, b) => {
    const ao = Number.isFinite(a.order) ? a.order : (a.pluginId ? 200 : 50);
    const bo = Number.isFinite(b.order) ? b.order : (b.pluginId ? 200 : 50);
    return ao - bo || String(a.id).localeCompare(String(b.id));
  });
}

export function onContributionsChanged(fn) {
  if (typeof fn !== 'function') return () => {};
  listeners.add(fn);
  return () => listeners.delete(fn);
}

/** Dispara os listeners manualmente (ex.: após instalar/remover pack de plugin). */
export function notifyContributionsChanged(kind = '*') {
  notify(kind);
}

export const CONTRIBUTION_KINDS = Object.freeze([
  'nav',
  'toolbar',
  'settings',
  'command',
  'remoteAction',
  'stageLayout',
  'view',
  'template',
]);
