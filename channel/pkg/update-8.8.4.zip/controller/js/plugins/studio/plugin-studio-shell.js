/**
 * Shell compartilhado — Plugin Studio (layout Controle + prévias 16:9).
 */
import { esc, escAttr } from '../../core/render-engine/index.js';
import { mountProjectorPreview } from './projector-preview.js';

/**
 * @param {HTMLElement} root
 * @param {object} app — ControlApp
 * @param {{
 *   title: string,
 *   lead?: string,
 *   tabs?: { id: string, label: string }[],
 *   renderTab: (tabId: string, panel: HTMLElement, ctx: object) => void,
 *   previews?: { id: string, label: string, slide?: object | null }[],
 *   actions?: { id: string, label: string, primary?: boolean, onClick: (ctx: object) => void }[],
 * }} opts
 */
export function mountPluginStudio(root, app, opts) {
  const tabs = opts.tabs?.length ? opts.tabs : [{ id: 'main', label: 'Geral' }];
  const previews = opts.previews || [];
  const actions = opts.actions || [];
  const activeTab = tabs[0].id;

  root.className = 'plugin-studio-root view-panel is-active';
  root.innerHTML = `
    <header class="plugin-studio-head">
      <div class="plugin-studio-head__copy">
        <p class="plugin-studio-kicker">Plugin Studio</p>
        <h1 class="plugin-studio-title">${esc(opts.title || 'Plugin')}</h1>
        ${opts.lead ? `<p class="plugin-studio-lead">${esc(opts.lead)}</p>` : ''}
      </div>
      <div class="plugin-studio-head__actions">
        ${actions.map((a) => `
          <button type="button" class="btn ${a.primary ? 'btn-primary' : 'btn-secondary'}" data-studio-action="${escAttr(a.id)}">${esc(a.label)}</button>
        `).join('')}
      </div>
    </header>
    <div class="plugin-studio-body">
      <div class="plugin-studio-main">
        ${tabs.length > 1 ? `
        <nav class="plugin-studio-tabs" role="tablist">
          ${tabs.map((t, i) => `
            <button type="button" class="plugin-studio-tab${t.id === activeTab ? ' is-active' : ''}" role="tab"
              data-studio-tab="${escAttr(t.id)}" aria-selected="${t.id === activeTab ? 'true' : 'false'}">${esc(t.label)}</button>
          `).join('')}
        </nav>` : ''}
        <div class="plugin-studio-panels">
          ${tabs.map((t) => `
            <section class="plugin-studio-panel${t.id === activeTab ? ' is-active' : ''}" data-studio-panel="${escAttr(t.id)}" role="tabpanel"></section>
          `).join('')}
        </div>
      </div>
      <aside class="plugin-studio-previews" aria-label="Prévia do projetor">
        ${previews.length ? previews.map((p) => `
          <div class="plugin-studio-preview-block" data-preview-block="${escAttr(p.id)}">
            <header class="plugin-studio-preview-head">
              <span>${esc(p.label || 'Prévia')}</span>
              <span class="plugin-studio-preview-badge">Prévia local</span>
            </header>
            <div class="plugin-studio-preview-frame">
              <div class="stage-preview plugin-studio-preview" data-preview-id="${escAttr(p.id)}"></div>
            </div>
          </div>
        `).join('') : `
          <div class="plugin-studio-preview-block">
            <header class="plugin-studio-preview-head"><span>Prévia</span></header>
            <p class="form-hint plugin-studio-preview-empty">Este plugin não usa prévia de slide.</p>
          </div>
        `}
      </aside>
    </div>
  `;

  const previewContainers = new Map();
  const previewSlides = new Map();
  for (const p of previews) {
    const el = root.querySelector(`[data-preview-id="${CSS.escape(p.id)}"]`);
    if (el) {
      previewContainers.set(p.id, el);
      previewSlides.set(p.id, p.slide || null);
      if (p.slide) mountProjectorPreview(el, p.slide, app);
    }
  }

  // Edição ao vivo: se o slide deste plugin já está no ar, refletir as edições no
  // projetor em tempo real (debounce). Só reprojeta quando o plugin está no ar —
  // digitar no Studio nunca projeta sozinho um plugin que não estava ativo.
  let _resyncTimer = null;
  function maybeLiveResync(slide) {
    try {
      const stamp = slide?._pluginStamp;
      if (!stamp) return;
      const onAir = app?.getProjectorSlide?.();
      if (!onAir || onAir._pluginStamp !== stamp) return;
      if (app?.isCountdownLive?.()) return;
      clearTimeout(_resyncTimer);
      _resyncTimer = setTimeout(() => {
        try {
          app?.setMediaOnAir?.(slide);
          app?.sendSlideToProjector?.(slide, false);
          app?.refreshStage?.({ skipInspector: true });
          app?.updatePreviewBadge?.();
        } catch { /* ignore */ }
      }, 180);
    } catch { /* ignore */ }
  }

  const ctx = {
    app,
    root,
    setPreview(id, slide) {
      previewSlides.set(id, slide);
      const el = previewContainers.get(id);
      if (el) mountProjectorPreview(el, slide, app);
      maybeLiveResync(slide);
    },
    refreshPreviews() {
      for (const [id, slide] of previewSlides) {
        const el = previewContainers.get(id);
        if (el && slide) mountProjectorPreview(el, slide, app);
      }
    },
    getPanel(tabId) {
      return root.querySelector(`[data-studio-panel="${CSS.escape(tabId)}"]`);
    },
  };

  for (const t of tabs) {
    const panel = ctx.getPanel(t.id);
    if (panel && typeof opts.renderTab === 'function') {
      opts.renderTab(t.id, panel, ctx);
    }
  }

  root.querySelectorAll('[data-studio-tab]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const id = btn.dataset.studioTab;
      root.querySelectorAll('[data-studio-tab]').forEach((b) => {
        const on = b.dataset.studioTab === id;
        b.classList.toggle('is-active', on);
        b.setAttribute('aria-selected', on ? 'true' : 'false');
      });
      root.querySelectorAll('[data-studio-panel]').forEach((p) => {
        p.classList.toggle('is-active', p.dataset.studioPanel === id);
      });
      requestAnimationFrame(() => ctx.refreshPreviews());
    });
  });

  for (const a of actions) {
    root.querySelector(`[data-studio-action="${CSS.escape(a.id)}"]`)?.addEventListener('click', () => {
      try { a.onClick(ctx); } catch (err) {
        console.warn('[plugin-studio]', err);
        app?.toast?.(err?.message || 'Erro no Studio', 'error');
      }
    });
  }

  return ctx;
}
