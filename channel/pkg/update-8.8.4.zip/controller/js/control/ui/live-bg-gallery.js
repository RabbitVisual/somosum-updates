/**
 * Galeria de fundos ao vivo — miniaturas dos vídeos/imagens do sistema + biblioteca.
 */
import {
  slideBackgroundPickerHtml,
  bindWelcomeBackgroundPicker,
  syncWelcomeBackgroundPickerUI,
  resolveMediaSrc,
} from '../../core/media-url.js';
import { resolveWelcomeBackground } from '../../slides/welcome-config.js';
import { setHtml, rawHtml } from '../../core/render-engine/index.js';

const PRESETS = [
  { id: 'theme', label: 'Tema', className: '' },
  { id: 'dark', label: 'Escuro', className: ' insp-visual-tile--dark' },
  { id: 'gold', label: 'Dourado', className: ' insp-visual-tile--gold' },
];

/**
 * Espelha o fundo recém-aplicado nos inputs ocultos do inspetor (ITEM), para que
 * a captura de estilo (readProgramStyle/readSlideBackgroundStyle, readWelcomeFromInspector,
 * readLyricsInspectorStyle) não sobrescreva o fundo com "tema" ao editar tipografia.
 */
function syncInspectorBackgroundInputs(item, { kind = 'image' } = {}) {
  const doc = typeof document !== 'undefined' ? document : null;
  if (!doc || !item) return;
  const setVal = (id, val) => {
    const n = doc.getElementById(id);
    if (n) n.value = val;
  };
  const vKind = kind === 'video' ? 'video' : 'image';
  if (item.slideType === 'welcome') {
    setVal('insp-w-bg-media-id', item.data?.bgMediaId || '');
    setVal('insp-w-bg-kind', item.data?.bgKind || vKind);
  } else if (item.slideType === 'lyrics') {
    setVal('insp-lyrics-bg-media', item.data?.lyricsStyle?.backgroundMediaId || '');
    setVal('insp-lyrics-bg-preset', item.data?.lyricsStyle?.backgroundPreset || 'theme');
  } else {
    setVal('insp-slide-bg-media-id', item.data?.style?.backgroundMediaId || '');
    setVal('insp-slide-bg-kind', vKind);
    setVal('insp-slide-bg-preset', item.data?.style?.backgroundPreset || 'theme');
  }
}

function readCurrentBg(app) {
  const meta = app.program?.getCurrentMeta?.();
  if (!meta) return { mediaId: '', preset: 'theme', item: null, meta: null };
  const item = app.program.items[meta.itemIndex];
  if (!item) return { mediaId: '', preset: 'theme', item: null, meta };
  if (item.slideType === 'lyrics') {
    const st = item.data?.lyricsStyle || {};
    return {
      mediaId: st.backgroundMediaId || '',
      preset: st.backgroundPreset || 'theme',
      item,
      meta,
    };
  }
  if (item.slideType === 'welcome') {
    return {
      mediaId: item.data?.bgMediaId || '',
      preset: 'theme',
      item,
      meta,
    };
  }
  const st = { ...(app.defaultProgramStyle?.(item.slideType) || {}), ...(item.data?.style || {}) };
  return {
    mediaId: st.backgroundMediaId || '',
    preset: st.backgroundPreset || 'theme',
    item,
    meta,
  };
}

export function renderLiveBgGallery(app) {
  const host = document.getElementById('lc-bg-gallery-host');
  if (!host || app.view !== 'live') return;

  const { mediaId, preset } = readCurrentBg(app);
  const { html } = slideBackgroundPickerHtml(app.mediaList || [], {
    selectedId: mediaId,
    idField: 'lc-live-bg-media-id',
    kindField: 'lc-live-bg-kind',
  });

  const presetTiles = PRESETS.map((p) =>
    `<button type="button" class="insp-visual-tile${p.className}${preset === p.id && !mediaId ? ' is-selected' : ''}"
      data-lc-bg-preset="${p.id}">${p.label}</button>`
  ).join('');

  setHtml(host, rawHtml(`
    <div class="lc-bg-gallery-inner">
      <div class="lc-bg-presets-block">
        <span class="lc-zone-kicker">Gradiente rápido</span>
        <div class="insp-visual-tiles lc-bg-preset-tiles" role="listbox" aria-label="Gradiente">${presetTiles}</div>
      </div>
      ${html.replace('class="form-hint"', 'class="form-hint lc-bg-gallery-hint"')}
    </div>`));

  host.querySelectorAll('[data-lc-bg-preset]').forEach((btn) => {
    btn.addEventListener('click', () => {
      void app.applyLiveBackground?.({
        mediaId: '',
        kind: 'image',
        preset: btn.dataset.lcBgPreset || 'theme',
        label: btn.textContent?.trim() || 'Gradiente',
      });
    });
  });

  bindWelcomeBackgroundPicker(host, {
    onChange: ({ id, kind, label }) => {
      void app.applyLiveBackground?.({
        mediaId: id,
        kind,
        preset: 'theme',
        label: label || 'Fundo',
      });
    },
  });

  syncWelcomeBackgroundPickerUI(host, { id: mediaId, kind: 'image' });
}

export async function applyLiveBackground(app, { mediaId = '', kind = 'image', preset = 'theme', label = '' } = {}) {
  const { meta, item } = readCurrentBg(app);
  if (!meta || !item) {
    app.toast?.('Selecione um item na ordem do culto', 'warn');
    return false;
  }

  const media = mediaId ? (app.mediaList || []).find((m) => m.id === mediaId) : null;
  const src = mediaId ? resolveMediaSrc(media || { id: mediaId }) : '';

  if (item.slideType === 'lyrics') {
    item.data = item.data || {};
    item.data.lyricsStyle = {
      ...(item.data.lyricsStyle || {}),
      backgroundMediaId: mediaId || null,
      backgroundPreset: mediaId ? 'theme' : preset,
    };
  } else if (item.slideType === 'welcome') {
    const church = app.prefs?.church || {};
    const bgResolved = resolveWelcomeBackground(
      {
        ...(item.data || {}),
        bgMediaId: mediaId,
        bgMedia: src,
        bgKind: kind === 'video' ? 'video' : 'image',
      },
      app.mediaList || [],
      church,
    );
    item.data = {
      ...(item.data || {}),
      bgMediaId: bgResolved.bgMediaId,
      bgMedia: bgResolved.bgMedia,
      bgKind: bgResolved.bgKind,
    };
  } else {
    item.data = item.data || {};
    item.data.style = {
      ...(item.data.style || {}),
      backgroundMediaId: mediaId || null,
      backgroundPreset: mediaId ? 'theme' : preset,
    };
  }

  if (item.songId) app.program.clearSongCache?.(item.songId);
  await app.program.rebuildItem(meta.itemIndex);
  // Mantém os inputs ocultos do inspetor em sincronia com o fundo escolhido aqui.
  // Sem isso, ao mudar fonte/cor/tamanho o inspetor relia o input vazio e zerava
  // o fundo (voltava pro gradiente do tema). Ver readSlideBackgroundStyle.
  syncInspectorBackgroundInputs(item, { kind });
  app.markProgramDirty?.();
  app.syncProjectorState?.(true, { skipInspector: true, liveEdit: true, forceProject: true });
  app.refreshStage?.({ skipInspector: true });
  renderLiveBgGallery(app);
  app.toast?.(mediaId ? `Fundo: ${label}` : `Gradiente: ${label}`, 'success');
  return true;
}
