import { isIntroitoProgramItem } from '../../../program/programa-templates.js';

export const inspectorCaptureState = {
readRehearsalInspectorData(el) {
  const minutes = Number(el.querySelector('#insp-rehearsal-min')?.value);
  const estimatedSec = Number.isFinite(minutes) && minutes > 0 ? Math.round(minutes * 60) : null;
  const operatorNote = el.querySelector('#insp-rehearsal-note')?.value?.trim() || '';
  const marked = el.querySelector('#insp-rehearsal-marked')?.checked === true;
  const data = { marked, operatorNote, estimatedSec };
  return (marked || operatorNote || estimatedSec) ? data : null;
},

captureInspectorItemState(meta, el) {
  const item = this.program.items[meta.itemIndex];
  if (!item || !el || el._suppressInspectorSync) return false;
  // Bíblia: tipografia/cores podem sincronizar mesmo se o picker ainda não montou
  const bibleStyleOnly = item.slideType === 'bible' && !el._biblePickerReady && !item.bible?.book;
  if (item.slideType === 'bible' && !el._biblePickerReady && !item.bible?.book) {
    // Continua: grava style abaixo; não bloqueia A+/fonte/cores
  }

  const rawTitle = el.querySelector('#insp-title')?.value?.trim() || '';
  if (item.slideType === 'section') {
    const title = el.querySelector('#insp-sec-title')?.value?.trim() || item.title;
    item.data = { ...(item.data || {}), title };
    item.title = title;
  } else if (item.slideType === 'prayer') {
    item.title = rawTitle || item.title;
    item.data = { ...(item.data || {}), title: item.title };
  } else if (item.slideType !== 'message' && !bibleStyleOnly) {
    item.title = rawTitle || item.title;
  }
  if (item.slideType === 'lyrics') {
    const prevSongId = item.songId || null;
    let songId = el.querySelector('#insp-song')?.value || null;
    if (!songId) {
      const q = el.querySelector('#insp-song-q')?.value?.trim() || '';
      if (q && Array.isArray(this.songs)) {
        const hits = this.songs.filter((s) => {
          const label = `${s.title || ''}${s.artist ? ` — ${s.artist}` : ''}`.toLowerCase();
          return label.includes(q.toLowerCase()) || (s.title || '').toLowerCase() === q.toLowerCase();
        });
        if (hits.length === 1) songId = hits[0].id;
        else {
          const exact = this.songs.find((s) => {
            const label = `${s.title || ''}${s.artist ? ` — ${s.artist}` : ''}`;
            return label === q;
          });
          if (exact) songId = exact.id;
        }
      }
    }
    if (songId) {
      item.songId = songId;
      const song = this.songs?.find((s) => s.id === songId);
      if (song?.title) item.title = song.title;
    }
    if (prevSongId && prevSongId !== item.songId) this.program.clearSongCache?.(prevSongId);
    item.data = {
      ...(item.data || {}),
      lyricsStyle: this.readLyricsInspectorStyle(el),
      lyricsFx: this.readLyricsInspectorFx(el),
    };
  }
  if (item.slideType === 'participation') {
    Object.assign(item.data || (item.data = {}), this.readParticipationInspectorData(el, item));
    item.songId = item.data.songId || null;
    const name = item.data.participantName || '';
    const label = item.data.participationLabel || 'Participação';
    if (name) item.title = `${label} — ${name}`;
  }
  if (item.slideType === 'message') {
    const fields = this.readMessageInspectorData(el, item);
    item.data = {
      ...(item.data || {}),
      messageMode: fields.messageMode,
      theme: fields.theme,
      mottoText: fields.mottoText,
      showMotto: fields.showMotto,
      referenceOverride: fields.referenceOverride,
      refStyle: fields.refStyle,
      reference: '',
      preacher: fields.preacher,
      preacherFrom: fields.preacherFrom,
      preacherPhotoId: fields.preacherPhotoId,
      showPreacherPhoto: fields.showPreacherPhoto,
      showVersion: fields.showVersion,
      style: fields.style,
    };
    item.bible = fields.bible;
    item.title = this.resolveMessageItemTitle(item, rawTitle || item.title);
  }
  if (item.slideType === 'bible' && !bibleStyleOnly) {
    item.bible = { ...(item.bible || {}), ...this.readBibleInspectorData(el, item.bible) };
    if (item.bible.displayMode !== 'excerpt') item.bible.referenceOverride = '';
    const prevData = item.data || {};
    item.data = {
      ...prevData,
      style: this.readProgramStyle(el, 'bible', prevData.style),
      designer: prevData.designer,
      layers: prevData.layers,
      background: prevData.background ?? prevData.designer?.background,
      templateId: prevData.templateId,
      previewDataUrl: prevData.previewDataUrl,
    };
    if (isIntroitoProgramItem(item)) {
      item.title = 'Introito Bíblico';
      item.data.role = 'introito';
    }
  } else if (item.slideType === 'bible' && bibleStyleOnly) {
    item.data = {
      ...(item.data || {}),
      style: this.readProgramStyle(el, 'bible', item.data?.style),
    };
  }
  const trLive = el.querySelector('#insp-transition')?.value;
  if (trLive !== undefined && !['lyrics', 'message'].includes(item.slideType)) {
    item.transition = trLive || null;
  }
  item.rehearsal = this.readRehearsalInspectorData(el);
  if (item.slideType === 'welcome') {
    item.data = {
      ...this.readWelcomeFromInspector(el, item),
      style: this.readProgramStyle(el, 'welcome'),
    };
  }
  // Hotfix: tipografia/cores/posição ao vivo em TODOS os tipos com toolbar de estilo
  // (oração, seção, anúncios, tema, participação, custom, mídia, comunhão, oferta…)
  if (!['lyrics', 'message', 'welcome', 'bible'].includes(item.slideType)) {
    const hasStyleToolbar = !!el.querySelector('#insp-style-title-readout, #insp-style-text-readout, #insp-style-font');
    if (hasStyleToolbar) {
      item.data = {
        ...(item.data || {}),
        style: this.readProgramStyle(el, item.slideType, item.data?.style),
      };
    }
  }
  return true;
},
};
