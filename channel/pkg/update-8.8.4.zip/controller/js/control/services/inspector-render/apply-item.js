import { getSong, saveSong } from '../../../core/store.js';
import { forceSaveWorshipSong } from '../../../worship/worship-store.js';
import { isIntroitoProgramItem } from '../../../program/programa-templates.js';
import { hasDesignerSkin, getDesignerSkin, applyCustomOrdemProps } from '../../../designer/content-bindings.js';

export const inspectorApplyItem = {
async applyInspectorItem(meta, el) {
  const item = this.program.items[meta.itemIndex];
  if (!item || !el) return;

  try {
    clearTimeout(this._inspectorDebounce);
    this._inspectorDebounce = null;
    item.title = el.querySelector('#insp-title')?.value?.trim() || item.title;

    if (item.slideType === 'bible') {
      item.bible = { ...(item.bible || {}), ...this.readBibleInspectorData(el, item.bible) };
      if (item.bible.displayMode !== 'excerpt') item.bible.referenceOverride = '';
      const prevData = item.data || {};
      item.data = {
        ...prevData,
        style: this.readProgramStyle(el, 'bible'),
        // Preserve Designer skin
        designer: prevData.designer,
        layers: prevData.layers,
        background: prevData.background ?? prevData.designer?.background,
        templateId: prevData.templateId,
        previewDataUrl: prevData.previewDataUrl,
      };
      if (isIntroitoProgramItem(item)) {
        item.title = 'Introito Bíblico';
        item.data.role = 'introito';
      }
    }
    item.rehearsal = this.readRehearsalInspectorData(el);

    if (item.slideType === 'lyrics') {
      let songId = el.querySelector('#insp-song')?.value || null;
      if (!songId) {
        const q = el.querySelector('#insp-song-q')?.value?.trim() || '';
        if (q && Array.isArray(this.songs)) {
          const exact = this.songs.find((s) => {
            const label = `${s.title || ''}${s.artist ? ` — ${s.artist}` : ''}`;
            return label === q || (s.title || '') === q;
          });
          if (exact) songId = exact.id;
          else {
            const hits = this.songs.filter((s) => {
              const label = `${s.title || ''}${s.artist ? ` — ${s.artist}` : ''}`.toLowerCase();
              return label.includes(q.toLowerCase());
            });
            if (hits.length === 1) songId = hits[0].id;
          }
          if (songId) {
            const hidden = el.querySelector('#insp-song');
            if (hidden) hidden.value = songId;
          }
        }
      }
      item.songId = songId;
      const lyricsStyle = this.readLyricsInspectorStyle(el);
      const lyricsFx = this.readLyricsInspectorFx(el);
      item.data = { ...(item.data || {}), lyricsStyle, lyricsFx };
      if (item.songId) {
        const song = await getSong(item.songId);
        if (song) {
          if (song.title) item.title = song.title;
          const { transition, ...songStyle } = lyricsStyle;
          await forceSaveWorshipSong({ ...song, style: { ...(song.style || {}), ...songStyle }, lyricsFx });
          this.program.clearSongCache(item.songId);
        }
      }
    }

    if (item.slideType === 'participation') {
      Object.assign(item.data || (item.data = {}), this.readParticipationInspectorData(el, item));
      item.songId = item.data.songId || null;
      const name = item.data.participantName || '';
      const label = item.data.participationLabel || 'Participação';
      item.title = name ? `${label} — ${name}` : (el.querySelector('#insp-title')?.value?.trim() || item.title);
    }

    if (item.slideType === 'announcements') {
      const raw = el.querySelector('#insp-ann-items')?.value || '';
      const parsed = raw.split('\n').map((line) => line.trim()).filter(Boolean).map((line) => {
        const m = line.match(/^(\S+)\s+(.+)$/);
        return m ? { icon: m[1], text: m[2] } : { icon: '•', text: line };
      });
      item.data = {
        title: el.querySelector('#insp-ann-title')?.value || 'Comunicados',
        items: parsed,
      };
      item.title = item.data.title;
    }

    if (item.slideType === 'custom') {
      const { textKey, ...rest } = item.data || {};
      const title = el.querySelector('#insp-screen-title')?.value?.trim() || '';
      const subtitle = el.querySelector('#insp-custom-sub')?.value?.trim() || '';
      const text = el.querySelector('#insp-text')?.value ?? '';
      const align = el.querySelector('#insp-custom-align')?.value || 'center';
      const backgroundPreset = el.querySelector('#insp-custom-bg')?.value || 'dark';
      let next = {
        ...rest,
        title,
        subtitle,
        text,
        align,
        backgroundPreset,
        textEdited: true,
      };
      if (hasDesignerSkin(item)) {
        const skin = getDesignerSkin(item);
        const layers = applyCustomOrdemProps(skin.layers, { title, subtitle, text });
        const background = { type: 'gradient', preset: backgroundPreset };
        next = {
          ...next,
          layers,
          background,
          designer: {
            ...skin,
            layers,
            background,
            previewDataUrl: null,
          },
          previewDataUrl: null,
        };
      }
      item.data = next;
    }

    if (item.slideType === 'prayer') {
      item.data = { title: item.title };
    }

    if (item.slideType === 'message') {
      const fields = this.readMessageInspectorData(el, item);
      item.bible = fields.bible;
      item.data = {
        ...(item.data || {}),
        messageMode: fields.messageMode,
        theme: fields.theme,
        mottoText: fields.mottoText,
        showMotto: fields.showMotto,
        referenceOverride: fields.referenceOverride,
        refStyle: fields.refStyle,
        reference: '',
        preacher: fields.preacher,
        preacherFrom: fields.preacherFrom,
        preacherPhotoId: fields.preacherPhotoId,
        showPreacherPhoto: fields.showPreacherPhoto,
        showVersion: fields.showVersion,
        style: fields.style,
      };
      item.title = this.resolveMessageItemTitle(
        item,
        el.querySelector('#insp-title')?.value?.trim() || item.title
      );
    }

    if (item.slideType === 'welcome') {
      item.data = {
        ...this.readWelcomeFromInspector(el, item),
        style: this.readProgramStyle(el, 'welcome'),
      };
    }

    if (item.slideType === 'section') {
      const title = el.querySelector('#insp-sec-title')?.value || item.title;
      item.data = { title };
      item.title = title;
    }

    if (item.slideType === 'theme') {
      item.data = {
        motto: el.querySelector('#insp-th-motto')?.value || '',
        mottoText: el.querySelector('#insp-th-text')?.value || '',
        theme: el.querySelector('#insp-th-theme')?.value || '',
      };
    }

    if (item.slideType === 'communion') {
      const updated = this.readCommunionFromInspector?.(el, item);
      if (updated) Object.assign(item, updated);
    }

    if (item.slideType === 'media') {
      item.mediaId = el.querySelector('#insp-media')?.value || null;
      item.data = { ...item.data, loop: el.querySelector('#insp-media-loop')?.checked !== false };
    }

    if (item.slideType === 'media-audio') {
      item.data = {
        ...(item.data || {}),
        screenTitle: el.querySelector('#insp-audio-screen')?.value?.trim() || item.title,
        audioPath: el.querySelector('#insp-audio-path')?.value || null,
        loop: el.querySelector('#insp-audio-loop')?.checked === true,
        hint: el.querySelector('#insp-audio-hint')?.value?.trim() || '',
      };
      item.placeholder = item.data.hint;
    }

    if (item.slideType === 'offering') {
      const title = el.querySelector('#insp-offering-title')?.value?.trim() || 'Oferta e Dízimos';
      item.data = {
        title,
        subtitle: el.querySelector('#insp-offering-sub')?.value?.trim() || '',
        verse: el.querySelector('#insp-offering-verse')?.value?.trim() || '',
        template: el.querySelector('#insp-offering-tpl')?.value || 'classic',
      };
      item.title = el.querySelector('#insp-title')?.value?.trim() || title;
    }

    if (item.slideType === 'countdown') {
      const minsRaw = el.querySelector('#insp-pause-min')?.value;
      const durationMin = minsRaw ? Number(minsRaw) : null;
      const title = el.querySelector('#insp-pause-title')?.value?.trim() || 'Pausa';
      item.data = {
        title,
        note: el.querySelector('#insp-pause-note')?.value?.trim() || '',
        durationMin: Number.isFinite(durationMin) && durationMin > 0 ? durationMin : null,
      };
      item.title = el.querySelector('#insp-title')?.value?.trim() || title;
    }

    if (!['lyrics', 'message', 'welcome'].includes(item.slideType)) {
      item.data = {
        ...(item.data || {}),
        style: this.readProgramStyle(el, item.slideType, item.data?.style),
      };
      const tr = el.querySelector('#insp-transition')?.value;
      item.transition = tr || null;
    } else if (item.slideType === 'welcome') {
      const tr = el.querySelector('#insp-transition')?.value;
      item.transition = tr || null;
    }

    await this.program.rebuildItem(meta.itemIndex);
    this.markProgramDirty?.();
    this.programHistory?.record?.();
    this.invalidatePreviewCache();
    this._inspectorDirty = false;
    // syncProjectorState já chama refreshStage — evita double refresh (P1)
    // forceProject: tipografia/FX do inspetor sempre sobem para a tela ao Aplicar
    this.syncProjectorState(false, { skipInspector: true, liveEdit: true, forceProject: true });
    this.updateInspectorDirtyBadge?.();
    if (item.slideType === 'welcome') {
      this._forceInspectorSync = true;
      this.renderInspector(meta);
      this._forceInspectorSync = false;
    }
    this.toast('Configurações aplicadas — use Salvar para gravar no disco');
    await this.closeCultoQuickEditIfOpen?.();
  } catch (err) {
    console.warn('[SOMOSUM] applyInspectorItem:', err);
    this.toast(`Erro ao aplicar: ${err.message}`);
  }
},
};
