import { esc, escAttr } from '../../../core/render-engine/index.js';
import {
  DEFAULT_WELCOME_NORMAL,
  WELCOME_PRESETS,
  WELCOME_LAYOUTS,
  WELCOME_LOGO_POSITIONS,
  WELCOME_ANIMATIONS,
  WELCOME_BADGE_STYLES,
  WELCOME_POSITION_PRESETS,
  WELCOME_TEXT_STYLE_PRESETS,
  WELCOME_ELEMENT_KEYS,
  WELCOME_LAYOUT_POSITION_PRESETS,
  normalizeWelcomeData,
  buildWelcomeDataFromPreset,
  accentToHex,
  hexToAccentSoft,
  logoPositionForWelcomeLayout,
  resolveWelcomeBackground,
} from '../../../slides/welcome-config.js';
import { welcomeVisualFromPack } from '../../../program/culto-theme-packs.js';
import { welcomeBackgroundPickerHtml, bindWelcomeBackgroundPicker, syncWelcomeBackgroundPickerUI } from '../../../core/media-url.js';
import { bindFontPickerPair } from '../../../core/font-picker-ui.js';

export const welcomeInspectorFields = {
  welcomePositionSelectHtml(key, value) {
    const opts = WELCOME_POSITION_PRESETS.map((o) =>
      `<option value="${o.id}" ${value === o.id ? 'selected' : ''}>${esc(o.label)}</option>`
    ).join('');
    return `<select id="insp-w-pos-${key}" class="welcome-pos-select">${opts}</select>`;
  },

  welcomeTextStyleSelectHtml(key, value) {
    const opts = WELCOME_TEXT_STYLE_PRESETS.map((o) =>
      `<option value="${o.id}" ${value === o.id ? 'selected' : ''}>${esc(o.label)}</option>`
    ).join('');
    return `<select id="insp-w-tstyle-${key}" class="welcome-tstyle-select">${opts}</select>`;
  },

  welcomeInspectorHtml(item) {
    const church = this.prefs.church || {};
    const d = normalizeWelcomeData({ ...DEFAULT_WELCOME_NORMAL, ...(item.data || {}) }, church);
    const presetId = d.welcomePreset || 'domingo';
    const accentHex = accentToHex(d.accent || '#d4c68d');
    const presetOpts = WELCOME_PRESETS.map((o) =>
      `<option value="${o.id}" ${presetId === o.id ? 'selected' : ''}>${esc(o.label)}</option>`
    ).join('');
    const layoutOpts = WELCOME_LAYOUTS.map((o) =>
      `<option value="${o.id}" ${d.layout === o.id ? 'selected' : ''}>${esc(o.label)}</option>`
    ).join('');
    const logoPosOpts = WELCOME_LOGO_POSITIONS.map((o) =>
      `<option value="${o.id}" ${((d.logoPosition === 'hidden' ? 'top' : d.logoPosition) || 'top') === o.id ? 'selected' : ''}>${esc(o.label)}</option>`
    ).join('');
    const animOpts = WELCOME_ANIMATIONS.map((o) =>
      `<option value="${o.id}" ${d.animation === o.id ? 'selected' : ''}>${esc(o.label)}</option>`
    ).join('');
    const badgeStyleOpts = WELCOME_BADGE_STYLES.map((o) =>
      `<option value="${o.id}" ${(d.badgeStyle || 'pill') === o.id ? 'selected' : ''}>${esc(o.label)}</option>`
    ).join('');
    const assetUrls = this.getAssetUrls?.() || {};
    const churchBg = assetUrls.welcomeBg
      || (church.welcomeBgPath
        ? (String(church.welcomeBgPath).startsWith('/') ? church.welcomeBgPath : `/${String(church.welcomeBgPath).replace(/^\/+/, '')}`)
        : 'IMG/FRENTE_DA_IGREJA.png');
    const churchBgLabel = church.name?.trim()
      ? `Foto — ${church.name.trim()}`
      : 'Foto da igreja (Ajustes → Igreja)';
    const bgPicker = welcomeBackgroundPickerHtml(this.mediaList || [], {
      selectedId: d.bgMediaId || '',
      selectedSrc: d.bgMedia || '',
      churchBg,
      churchBgLabel,
      idField: 'insp-w-bg-media-id',
      kindField: 'insp-w-bg-kind',
    });
    const overlayPct = Math.round((Number(d.overlayOpacity ?? 0.72)) * 100);
    const textEls = WELCOME_ELEMENT_KEYS.filter((e) => e.id !== 'logo');
    const positionRows = WELCOME_ELEMENT_KEYS.map((el) => {
      const pos = d.positions?.[el.id] || 'center';
      return `<div class="welcome-insp-row">
            <span class="welcome-insp-row-label">${esc(el.label)}</span>
            ${this.welcomePositionSelectHtml(el.id, pos)}
          </div>`;
    }).join('');
    const visibilityRows = `
          <div class="form-row-2">
            <div class="form-block"><label><input type="checkbox" id="insp-w-show-years" ${d.showYears !== false ? 'checked' : ''} /> Título principal</label></div>
            <div class="form-block"><label><input type="checkbox" id="insp-w-show-badge" ${d.showBadge !== false ? 'checked' : ''} /> Etiqueta</label></div>
          </div>
          <div class="form-row-2">
            <div class="form-block"><label><input type="checkbox" id="insp-w-show-theme" ${d.showTheme !== false ? 'checked' : ''} /> Tema</label></div>
            <div class="form-block"><label><input type="checkbox" id="insp-w-show-sub" ${d.showSubtitle !== false ? 'checked' : ''} /> Subtítulo</label></div>
          </div>
          <div class="form-row-2">
            <div class="form-block"><label><input type="checkbox" id="insp-w-show-date" ${d.showDate !== false ? 'checked' : ''} /> Data</label></div>
            <div class="form-block"><label><input type="checkbox" id="insp-w-show-extra" ${d.showExtra !== false ? 'checked' : ''} /> Linha de apoio</label></div>
          </div>
          <div class="form-row-2">
            <div class="form-block"><label><input type="checkbox" id="insp-w-show-church" ${d.showChurchName !== false ? 'checked' : ''} /> Nome da igreja</label></div>
            <div class="form-block"><label><input type="checkbox" id="insp-w-show-logo" ${d.showLogo !== false ? 'checked' : ''} /> Logo</label></div>
          </div>`;
    const typeRows = textEls.map((el) => {
      const styleId = d.textStyles?.[el.id] || 'classic';
      const color = accentToHex(d.colors?.[el.id] || (el.id === 'years' ? '#fff8ec' : accentHex));
      const size = Number(d.sizes?.[el.id]) || 100;
      return `<div class="welcome-insp-type-row">
            <span class="welcome-insp-row-label">${esc(el.label)}</span>
            <div class="welcome-insp-type-fields">
              ${this.welcomeTextStyleSelectHtml(el.id, styleId)}
              <input type="color" id="insp-w-color-${el.id}" value="${escAttr(color)}" title="Cor" />
              <input type="range" id="insp-w-size-${el.id}" min="50" max="160" step="5" value="${size}" />
              <span class="welcome-insp-size-readout" data-for="insp-w-size-${el.id}">${size}%</span>
            </div>
          </div>`;
    }).join('');
    return `
          <div class="welcome-insp-tabs" data-welcome-insp-tabs>
            <div class="welcome-insp-tab-bar" role="tablist" aria-label="Boas-vindas">
              <button type="button" class="welcome-insp-tab is-active" role="tab" data-w-tab="content" aria-selected="true">Conteúdo</button>
              <button type="button" class="welcome-insp-tab" role="tab" data-w-tab="bg" aria-selected="false">Fundo</button>
              <button type="button" class="welcome-insp-tab" role="tab" data-w-tab="elements" aria-selected="false">Elementos</button>
              <button type="button" class="welcome-insp-tab" role="tab" data-w-tab="type" aria-selected="false">Tipografia</button>
              <button type="button" class="welcome-insp-tab" role="tab" data-w-tab="brand" aria-selected="false">Identidade</button>
            </div>

            <div class="welcome-insp-panel is-active" data-w-panel="content" role="tabpanel">
              <section class="insp-card">
                <header class="insp-card-head">
                  <h3 class="form-section-title">Modelo e textos</h3>
                  <p class="form-hint insp-card-lead">Template do culto e conteúdo exibido na projeção.</p>
                </header>
                <div class="form-block"><label>Template</label>
                  <select id="insp-w-preset">${presetOpts}</select>
                </div>
                <button type="button" class="btn btn-secondary btn-sm" id="insp-w-apply-preset">Aplicar template na tela</button>
                <div class="form-block"><label>Etiqueta / destaque</label>
                  <input id="insp-w-badge" value="${escAttr(d.badge || '')}" placeholder="Ex.: Culto de Celebração" />
                </div>
                <div class="form-block"><label>Título principal</label>
                  <input id="insp-w-years" value="${escAttr(d.years || church.defaultWelcomeTitle || 'Bem-vindos')}" />
                </div>
                <div class="form-block"><label>Tema do culto</label>
                  <input id="insp-w-theme" value="${escAttr(d.theme || church.defaultTheme || '')}" />
                </div>
                <div class="form-block"><label>Data / período do evento</label>
                  <input id="insp-w-date" value="${escAttr(d.dateLine || '')}" placeholder="Ex.: 11 e 12 de julho de 2026" />
                </div>
                <div class="form-block"><label>Subtítulo</label>
                  <input id="insp-w-sub" value="${escAttr(d.subtitle || church.subtitle || '')}" />
                </div>
                <div class="form-block"><label>Linha de apoio</label>
                  <input id="insp-w-extra" value="${escAttr(d.extraLine || '')}" placeholder="Frase elegante sob o título" />
                </div>
              </section>
              <section class="insp-card welcome-insp-visibility-quick">
                <header class="insp-card-head">
                  <h3 class="form-section-title">Exibir na projeção</h3>
                  <p class="form-hint insp-card-lead">Marque o que deve aparecer na tela — incluindo logo e nome da igreja.</p>
                </header>
                ${visibilityRows}
                <div class="form-block welcome-insp-visibility-actions">
                  <button type="button" class="btn btn-secondary btn-sm" id="insp-w-hide-all-text">Ocultar todos os textos</button>
                  <button type="button" class="btn btn-secondary btn-sm" id="insp-w-show-all-text">Mostrar todos os textos</button>
                </div>
                <p class="form-hint">Visibilidade = aba <strong>Conteúdo</strong>. Posição na grade = aba <strong>Elementos</strong>. Tamanho do logo = aba <strong>Identidade</strong>.</p>
              </section>
            </div>

            <div class="welcome-insp-panel" data-w-panel="bg" role="tabpanel" hidden>
              <section class="insp-card">
                <header class="insp-card-head">
                  <h3 class="form-section-title">Fundo na projeção</h3>
                  <p class="form-hint insp-card-lead">O tile “${esc(churchBgLabel)}” usa a foto/vídeo de <strong>Ajustes → Igreja</strong>. Biblioteca abaixo para escolhas por slide.</p>
                </header>
                ${bgPicker.html}
                <div class="form-block"><label>Opacidade do overlay <span id="insp-w-overlay-opacity-readout">${overlayPct}%</span></label>
                  <input type="range" id="insp-w-overlay-opacity" min="0" max="100" step="1" value="${overlayPct}" />
                </div>
                <div class="form-block"><label>Legibilidade (preset)</label>
                  <select id="insp-w-overlay">
                    <option value="strong" ${(d.overlayStrength || 'strong') === 'strong' ? 'selected' : ''}>Forte — blur + painel (recomendado)</option>
                    <option value="medium" ${d.overlayStrength === 'medium' ? 'selected' : ''}>Médio</option>
                    <option value="light" ${d.overlayStrength === 'light' ? 'selected' : ''}>Leve</option>
                  </select>
                </div>
                <div class="form-block"><label><input type="checkbox" id="insp-w-scrim" ${d.scrimEnabled !== false ? 'checked' : ''} /> Véu escuro (scrim) sobre o fundo</label></div>
                <div class="form-block"><label>Movimento do fundo</label>
                  <select id="insp-w-bg-motion">
                    <option value="kenburns" ${(d.bgMotion || 'kenburns') === 'kenburns' ? 'selected' : ''}>Ken Burns (suave)</option>
                    <option value="static" ${d.bgMotion === 'static' ? 'selected' : ''}>Estático</option>
                  </select>
                </div>
              </section>
            </div>

            <div class="welcome-insp-panel" data-w-panel="elements" role="tabpanel" hidden>
              <section class="insp-card">
                <header class="insp-card-head">
                  <h3 class="form-section-title">Posição na tela (grade 3×3)</h3>
                  <p class="form-hint insp-card-lead">Cada peça em uma zona estável — várias peças na mesma célula empilham com espaçamento.</p>
                </header>
                <div class="welcome-insp-preset-actions">
                  <button type="button" class="btn btn-secondary btn-sm" id="insp-w-pos-all-center">${esc(WELCOME_LAYOUT_POSITION_PRESETS.allCenter.label)}</button>
                  <button type="button" class="btn btn-secondary btn-sm" id="insp-w-pos-logo-side">${esc(WELCOME_LAYOUT_POSITION_PRESETS.logoSide.label)}</button>
                </div>
                <div class="welcome-insp-pos-grid">${positionRows}</div>
              </section>
            </div>

            <div class="welcome-insp-panel" data-w-panel="type" role="tabpanel" hidden>
              <section class="insp-card">
                <header class="insp-card-head">
                  <h3 class="form-section-title">Estilo, cor e tamanho</h3>
                  <p class="form-hint insp-card-lead">Presets tipográficos por campo — cor e escala relativos.</p>
                </header>
                <div class="welcome-insp-type-grid">${typeRows}</div>
                <div class="form-block" style="margin-top:0.75rem">
                  <label>Fonte dos textos</label>
                  ${this.fontPickerPairHtml(item.data?.style?.fontFamily || '', item.data?.style || {}, { familyId: 'insp-style-font', variantId: 'insp-style-font-variant' })}
                </div>
                <div class="form-row-2" style="margin-top:0.75rem">
                  <div class="form-block"><label><input type="checkbox" id="insp-w-text-shine" ${d.textShine !== false ? 'checked' : ''} /> Degradê animado no título</label></div>
                  <div class="form-block"><label>Estilo da etiqueta</label>
                    <select id="insp-w-badge-style">${badgeStyleOpts}</select>
                  </div>
                </div>
              </section>
            </div>

            <div class="welcome-insp-panel" data-w-panel="brand" role="tabpanel" hidden>
              <section class="insp-card">
                <header class="insp-card-head">
                  <h3 class="form-section-title">Logo e identidade</h3>
                  <p class="form-hint insp-card-lead">Logo padrão em <strong>Ajustes → Igreja</strong>. Aqui você controla exibição e posição.</p>
                </header>
                <div class="form-row-2">
                  <div class="form-block"><label>Disposição geral</label>
                    <select id="insp-w-layout">${layoutOpts}</select>
                  </div>
                  <div class="form-block"><label>Posição relativa do logo</label>
                    <select id="insp-w-logo-pos">${logoPosOpts}</select>
                  </div>
                </div>
                <div class="form-block"><label>Tamanho do logo (px)</label>
                  <input id="insp-w-logo-size" type="number" min="120" max="480" step="10" value="${d.logoSize || 260}" />
                </div>
                <div class="form-row-2">
                  <div class="form-block"><label>Cor de destaque global</label>
                    <input id="insp-w-accent" type="color" value="${escAttr(accentHex)}" data-accent-soft="${escAttr(d.accentSoft || hexToAccentSoft(accentHex))}" />
                  </div>
                  <div class="form-block"><label>Animação de entrada</label>
                    <select id="insp-w-anim">${animOpts}</select>
                  </div>
                </div>
                <div class="form-row-2">
                  <div class="form-block"><label><input type="checkbox" id="insp-w-sparkles" ${d.sparkles ? 'checked' : ''} /> Brilhos sutis</label></div>
                  <div class="form-block"><label>Atmosfera</label>
                    <select id="insp-w-particles">
                      <option value="none" ${(d.atmosParticles || 'none') === 'none' ? 'selected' : ''}>Nenhuma</option>
                      <option value="petals" ${d.atmosParticles === 'petals' ? 'selected' : ''}>Pétalas</option>
                      <option value="sparkles" ${d.atmosParticles === 'sparkles' ? 'selected' : ''}>Brilhos</option>
                      <option value="dust" ${d.atmosParticles === 'dust' ? 'selected' : ''}>Poeira de luz</option>
                    </select>
                  </div>
                </div>
                <p class="form-hint">Com <strong>Ao vivo</strong>, o projetor atualiza ao editar.</p>
              </section>
            </div>
          </div>`;
  },

  fillWelcomeFormFromPreset(el, presetId) {
    const church = this.prefs.church || {};
    const packVisual = welcomeVisualFromPack(presetId);
    const w = buildWelcomeDataFromPreset(presetId, church, packVisual);
    /* Preservar fundo já escolhido pelo pastor ao trocar template. */
    const keepBgId = el.querySelector('#insp-w-bg-media-id')?.value?.trim() || '';
    const keepBgKind = el.querySelector('#insp-w-bg-kind')?.value || 'image';
    const set = (sel, val) => {
      const n = el.querySelector(sel);
      if (n) n.value = val != null ? String(val) : '';
    };
    set('#insp-w-preset', presetId);
    set('#insp-w-badge', w.badge);
    set('#insp-w-years', w.years);
    set('#insp-w-theme', w.theme);
    set('#insp-w-date', w.dateLine);
    set('#insp-w-sub', w.subtitle);
    set('#insp-w-extra', w.extraLine);
    set('#insp-w-layout', w.layout);
    set('#insp-w-anim', w.animation);
    set('#insp-w-badge-style', w.badgeStyle || 'pill');
    set('#insp-w-overlay', w.overlayStrength || 'strong');
    set('#insp-w-bg-motion', w.bgMotion || 'kenburns');
    set('#insp-w-logo-size', w.logoSize || 260);
    const logoPos = logoPositionForWelcomeLayout(w.layout, w.logoPosition || 'top');
    set('#insp-w-logo-pos', logoPos === 'hidden' ? 'top' : logoPos);
    const showLogo = el.querySelector('#insp-w-show-logo');
    if (showLogo) showLogo.checked = w.showLogo !== false;
    const showChurch = el.querySelector('#insp-w-show-church');
    if (showChurch) showChurch.checked = w.showChurchName !== false;
    const sparklesEl = el.querySelector('#insp-w-sparkles');
    if (sparklesEl) sparklesEl.checked = !!w.sparkles;
    const setChk = (sel, on) => {
      const n = el.querySelector(sel);
      if (n) n.checked = !!on;
    };
    setChk('#insp-w-show-badge', w.showBadge !== false);
    setChk('#insp-w-show-theme', w.showTheme !== false);
    setChk('#insp-w-show-extra', w.showExtra !== false);
    setChk('#insp-w-show-sub', w.showSubtitle !== false);
    setChk('#insp-w-show-date', w.showDate !== false);
    setChk('#insp-w-show-years', w.showYears !== false);
    setChk('#insp-w-text-shine', w.textShine !== false);
    setChk('#insp-w-scrim', w.scrimEnabled !== false);
    set('#insp-w-particles', w.atmosParticles || 'none');
    const overlayPct = Math.round((Number(w.overlayOpacity ?? 0.72)) * 100);
    set('#insp-w-overlay-opacity', overlayPct);
    const overlayReadout = el.querySelector('#insp-w-overlay-opacity-readout');
    if (overlayReadout) overlayReadout.textContent = `${overlayPct}%`;
    WELCOME_ELEMENT_KEYS.forEach(({ id }) => {
      set(`#insp-w-pos-${id}`, w.positions?.[id] || 'center');
      if (id !== 'logo') {
        set(`#insp-w-tstyle-${id}`, w.textStyles?.[id] || 'classic');
        const colorEl = el.querySelector(`#insp-w-color-${id}`);
        if (colorEl) colorEl.value = accentToHex(w.colors?.[id] || colorEl.value);
        const sizeVal = Number(w.sizes?.[id]) || 100;
        set(`#insp-w-size-${id}`, sizeVal);
        const readout = el.querySelector(`[data-for="insp-w-size-${id}"]`);
        if (readout) readout.textContent = `${sizeVal}%`;
      }
    });
    set('#insp-w-bg-media-id', keepBgId);
    set('#insp-w-bg-kind', keepBgId ? keepBgKind : 'image');
    syncWelcomeBackgroundPickerUI(el, {
      id: keepBgId,
      kind: keepBgId ? keepBgKind : 'image',
    });
    const accentEl = el.querySelector('#insp-w-accent');
    if (accentEl) {
      accentEl.value = accentToHex(w.accent);
      accentEl.dataset.accentSoft = w.accentSoft || hexToAccentSoft(w.accent);
    }
    return { ...w, bgMediaId: keepBgId, bgKind: keepBgId ? keepBgKind : 'image' };
  },

  readWelcomeFromInspector(el, item) {
    const church = this.prefs.church || {};
    let logoPosRaw = el.querySelector('#insp-w-logo-pos')?.value || 'top';
    if (logoPosRaw === 'hidden') logoPosRaw = 'top';
    const showLogo = el.querySelector('#insp-w-show-logo')?.checked !== false;
    const accentRaw = accentToHex(
      el.querySelector('#insp-w-accent')?.value || item.data?.accent || '#d4c68d'
    );
    const accentEl = el.querySelector('#insp-w-accent');
    const softAttr = accentEl?.dataset?.accentSoft;
    const prevAccent = accentToHex(item.data?.accent || '');
    const accentSoft = (softAttr && accentRaw === accentToHex(accentEl?.value || accentRaw))
      ? softAttr
      : (accentRaw === prevAccent && item.data?.accentSoft
        ? item.data.accentSoft
        : hexToAccentSoft(accentRaw));
    const presetId = el.querySelector('#insp-w-preset')?.value || item.data?.welcomePreset || 'domingo';
    const layout = el.querySelector('#insp-w-layout')?.value || 'center';
    const bgMediaId = el.querySelector('#insp-w-bg-media-id')?.value?.trim() || '';
    const bgResolved = resolveWelcomeBackground(
      {
        ...(item.data || {}),
        bgMediaId,
        bgMedia: item.data?.bgMedia || '',
        bgKind: el.querySelector('#insp-w-bg-kind')?.value || item.data?.bgKind || 'image',
      },
      this.mediaList || [],
      church,
    );
    const positions = {};
    const colors = {};
    const textStyles = {};
    const sizes = {};
    WELCOME_ELEMENT_KEYS.forEach(({ id }) => {
      positions[id] = el.querySelector(`#insp-w-pos-${id}`)?.value || item.data?.positions?.[id] || 'center';
      if (id !== 'logo') {
        textStyles[id] = el.querySelector(`#insp-w-tstyle-${id}`)?.value || item.data?.textStyles?.[id] || 'classic';
        colors[id] = accentToHex(el.querySelector(`#insp-w-color-${id}`)?.value || item.data?.colors?.[id] || '#fff8ec');
        sizes[id] = Number(el.querySelector(`#insp-w-size-${id}`)?.value) || item.data?.sizes?.[id] || 100;
      }
    });
    const overlayOpacityRaw = Number(el.querySelector('#insp-w-overlay-opacity')?.value);
    const overlayOpacity = Number.isFinite(overlayOpacityRaw) ? overlayOpacityRaw / 100 : undefined;
    return normalizeWelcomeData({
      ...(item.data || {}),
      welcomePreset: presetId,
      badge: el.querySelector('#insp-w-badge')?.value?.trim() || '',
      years: el.querySelector('#insp-w-years')?.value?.trim() || church.defaultWelcomeTitle || 'Bem-vindos',
      theme: el.querySelector('#insp-w-theme')?.value?.trim() || '',
      dateLine: el.querySelector('#insp-w-date')?.value?.trim() || '',
      subtitle: el.querySelector('#insp-w-sub')?.value?.trim() || '',
      extraLine: el.querySelector('#insp-w-extra')?.value?.trim() || '',
      layout,
      logoPosition: showLogo ? logoPosRaw : 'hidden',
      logoSize: Number(el.querySelector('#insp-w-logo-size')?.value) || 260,
      showLogo,
      showYears: el.querySelector('#insp-w-show-years')?.checked !== false,
      showChurchName: el.querySelector('#insp-w-show-church')?.checked !== false,
      showBadge: el.querySelector('#insp-w-show-badge')?.checked !== false,
      showTheme: el.querySelector('#insp-w-show-theme')?.checked !== false,
      showExtra: el.querySelector('#insp-w-show-extra')?.checked !== false,
      showSubtitle: el.querySelector('#insp-w-show-sub')?.checked !== false,
      showDate: el.querySelector('#insp-w-show-date')?.checked !== false,
      textShine: el.querySelector('#insp-w-text-shine')?.checked !== false,
      scrimEnabled: el.querySelector('#insp-w-scrim')?.checked !== false,
      atmosParticles: el.querySelector('#insp-w-particles')?.value || 'none',
      bgMediaId: bgResolved.bgMediaId,
      bgMedia: bgResolved.bgMedia,
      bgKind: bgResolved.bgKind,
      animation: el.querySelector('#insp-w-anim')?.value || 'classic',
      bgMotion: el.querySelector('#insp-w-bg-motion')?.value || 'kenburns',
      overlayStrength: el.querySelector('#insp-w-overlay')?.value || 'strong',
      overlayOpacity,
      accent: accentRaw,
      accentSoft,
      badgeStyle: el.querySelector('#insp-w-badge-style')?.value || 'pill',
      sparkles: el.querySelector('#insp-w-sparkles')?.checked === true,
      positions,
      colors,
      textStyles,
      sizes,
    }, church);
  },

  bindWelcomeInspectorTabs(el) {
    const root = el.querySelector('[data-welcome-insp-tabs]');
    if (!root || root.dataset.bound === '1') return;
    root.dataset.bound = '1';
    const tabs = root.querySelectorAll('.welcome-insp-tab');
    const panels = root.querySelectorAll('.welcome-insp-panel');
    const activate = (id) => {
      tabs.forEach((t) => {
        const on = t.getAttribute('data-w-tab') === id;
        t.classList.toggle('is-active', on);
        t.setAttribute('aria-selected', on ? 'true' : 'false');
      });
      panels.forEach((p) => {
        const on = p.getAttribute('data-w-panel') === id;
        p.classList.toggle('is-active', on);
        p.hidden = !on;
      });
    };
    tabs.forEach((tab) => {
      tab.addEventListener('click', () => activate(tab.getAttribute('data-w-tab')));
    });
  },

  bindWelcomeHideAllText(el, meta) {
    const setAll = (on) => {
      ['#insp-w-show-years', '#insp-w-show-badge', '#insp-w-show-theme', '#insp-w-show-sub',
        '#insp-w-show-date', '#insp-w-show-extra', '#insp-w-show-church', '#insp-w-show-logo'].forEach((sel) => {
        const n = el.querySelector(sel);
        if (n) n.checked = !!on;
      });
      this.scheduleInspectorLiveSync?.(meta, el, 80);
    };
    el.querySelector('#insp-w-hide-all-text')?.addEventListener('click', () => setAll(false));
    el.querySelector('#insp-w-show-all-text')?.addEventListener('click', () => setAll(true));
    el.querySelector('#insp-w-show-logo')?.addEventListener('change', (e) => {
      const logoPos = el.querySelector('#insp-w-logo-pos');
      if (e.target.checked && logoPos?.value === 'hidden') logoPos.value = 'top';
      this.scheduleInspectorLiveSync?.(meta, el, 80);
    });
  },

  bindWelcomePositionPresets(el, meta) {
    const applyPositions = (preset) => {
      if (!preset?.positions) return;
      Object.entries(preset.positions).forEach(([key, value]) => {
        const sel = el.querySelector(`#insp-w-pos-${key}`);
        if (sel) sel.value = value;
      });
      this.scheduleInspectorLiveSync?.(meta, el, 80);
    };
    el.querySelector('#insp-w-pos-all-center')?.addEventListener('click', () => {
      applyPositions(WELCOME_LAYOUT_POSITION_PRESETS.allCenter);
    });
    el.querySelector('#insp-w-pos-logo-side')?.addEventListener('click', () => {
      applyPositions(WELCOME_LAYOUT_POSITION_PRESETS.logoSide);
    });
  },

  bindWelcomePresetApply(el, meta) {
    const commitPreset = async (presetId, { toast = true } = {}) => {
      clearTimeout(this._inspectorDebounce);
      this._inspectorDebounce = null;
      el._suppressInspectorSync = true;
      try {
        this.fillWelcomeFormFromPreset(el, presetId);
        const item = this.program.items[meta.itemIndex];
        if (!item) return;
        const style = this.readProgramStyle(el, 'welcome');
        item.data = {
          ...this.readWelcomeFromInspector(el, item),
          style,
        };
        await this.program.rebuildItem(meta.itemIndex);
        this.markProgramDirty?.();
        this.invalidatePreviewCache?.();
        // syncProjectorState já chama refreshStage — evita double refresh (P1)
        this.syncProjectorState?.(false, { skipInspector: true, liveEdit: true });
        this._forceInspectorSync = true;
        this.renderInspector?.(meta);
        this._forceInspectorSync = false;
        if (toast) {
          const label = WELCOME_PRESETS.find((p) => p.id === presetId)?.label || presetId;
          this.toast(`Template "${label}" aplicado na tela de boas-vindas`);
        }
      } finally {
        el._suppressInspectorSync = false;
      }
    };

    el.querySelector('#insp-w-apply-preset')?.addEventListener('click', () => {
      const id = el.querySelector('#insp-w-preset')?.value || 'domingo';
      void commitPreset(id);
    });

    el.querySelector('#insp-w-preset')?.addEventListener('change', () => {
      const id = el.querySelector('#insp-w-preset')?.value || 'domingo';
      void commitPreset(id);
    });

    el.querySelector('#insp-w-accent')?.addEventListener('input', (e) => {
      const hex = accentToHex(e.target.value);
      e.target.dataset.accentSoft = hexToAccentSoft(hex);
    });

    this.bindWelcomeInspectorTabs(el);
    this.bindWelcomeHideAllText(el, meta);
    this.bindWelcomePositionPresets(el, meta);

    el.querySelector('#insp-w-overlay-opacity')?.addEventListener('input', (e) => {
      const readout = el.querySelector('#insp-w-overlay-opacity-readout');
      if (readout) readout.textContent = `${e.target.value}%`;
    });
    el.querySelectorAll('[id^="insp-w-size-"]').forEach((range) => {
      range.addEventListener('input', (e) => {
        const readout = el.querySelector(`[data-for="${e.target.id}"]`);
        if (readout) readout.textContent = `${e.target.value}%`;
      });
    });

    bindWelcomeBackgroundPicker(el, {
      onChange: () => this.scheduleInspectorLiveSync?.(meta, el, 80),
    });

    bindFontPickerPair(el, {
      familySelector: '#insp-style-font',
      variantSelector: '#insp-style-font-variant',
      onChange: () => this.scheduleInspectorLiveSync?.(meta, el, 80),
    });
  },
};
