import { parseLyrics } from './lyrics-parser.js';
import { resolveMediaSrc, resolveSystemLoopAlias } from '../core/media-url.js';

const MAX_LINE_CHARS = 42;
const MAX_STANZA_LINES = 6;

function splitLongLine(line) {
  const t = (line || '').trim();
  if (t.length <= MAX_LINE_CHARS) return [t];
  const mid = Math.floor(t.length / 2);
  const breakAt = t.lastIndexOf(' ', mid);
  const idx = breakAt > 12 ? breakAt : mid;
  return [t.slice(0, idx).trim(), t.slice(idx).trim()].filter(Boolean);
}

function expandLinesForProjection(lines) {
  const out = [];
  for (const line of lines) {
    if (!line?.trim()) {
      out.push('');
      continue;
    }
    out.push(...splitLongLine(line));
  }
  return out;
}

export function createLyricsTitleSlide(song, style, background) {
  return {
    type: 'lyrics-title',
    title: song?.title || 'Música',
    artist: song?.artist || '',
    style,
    background,
  };
}

export async function resolveSlideBackground(style, getMediaFn) {
  if (style?.backgroundMediaId && getMediaFn) {
    const m = await getMediaFn(style.backgroundMediaId);
    if (m) {
      const src = resolveMediaSrc(m);
      if (src) {
        const isVideo = m.kind === 'video'
          || m.category === 'fundo-animado'
          || m.category === 'loop'
          || String(m.mimeType || m.mime || '').includes('video')
          || /\.(mp4|webm|mov)(\?|$)/i.test(src);
        return { type: isVideo ? 'video' : 'image', src };
      }
    }
    const alias = resolveSystemLoopAlias(style.backgroundMediaId);
    if (alias) {
      return {
        type: /\.mp4|\.webm|mov/i.test(alias) ? 'video' : 'image',
        src: alias,
      };
    }
  }
  return { type: 'gradient', preset: style?.backgroundPreset || 'theme' };
}

/** @deprecated use resolveSlideBackground */
export const resolveLyricsBackground = resolveSlideBackground;

export function buildLyricsSlides(song, style, options = {}) {
  const background = options.background || { type: 'gradient', preset: 'theme' };
  const slides = [createLyricsTitleSlide(song, style, background)];

  if (!song?.lyrics?.trim()) {
    slides.push({
      type: 'lyrics',
      lines: [options.placeholder || 'Cadastre ou vincule uma música na biblioteca de letras.'],
      style,
      background,
    });
    return slides;
  }

  splitLyricsIntoSlides(song.lyrics, style, song).forEach((s) => {
    slides.push({ ...s, style, background });
  });
  return slides;
}

export function splitLyricsIntoSlides(rawText, style = {}, song = null) {
  // Usa a letra atual (linhas em branco = estrofes). sections antigas NÃO sobrescrevem.
  // Tipos verso/refrão vêm dos metadados sincronizados, mas o texto é o de lyrics.
  const { stanzas: parsedStanzas, lines: rawLines } = parseLyrics(rawText);
  let stanzas = parsedStanzas;
  const lines = expandLinesForProjection(rawLines);

  const mode = style.splitMode || 'lines';
  const linesPerSlide = Math.max(1, Math.min(style.linesPerSlide || 4, 6));
  const stanzasPerSlide = Math.max(1, style.stanzasPerSlide || 1);

  if (mode === 'line') {
    return lines.map((line, index) => ({
      type: 'lyrics',
      lines: [line],
      highlightIndex: style.highlightLine ? 0 : -1,
      slideIndex: index,
    }));
  }

  if (mode === 'lines') {
    const slides = [];
    const hi = style.highlightLine !== false ? 0 : -1;
    for (let i = 0; i < lines.length; i += linesPerSlide) {
      slides.push({
        type: 'lyrics',
        lines: lines.slice(i, i + linesPerSlide),
        highlightIndex: hi,
        slideIndex: slides.length,
      });
    }
    return slides;
  }

  if (mode === 'stanzas') {
    const slides = [];
    const hi = style.highlightLine !== false ? 0 : -1;
    for (let i = 0; i < stanzas.length; i += stanzasPerSlide) {
      let chunk = stanzas.slice(i, i + stanzasPerSlide).flat();
      chunk = expandLinesForProjection(chunk);
      while (chunk.length > MAX_STANZA_LINES) {
        slides.push({
          type: 'lyrics',
          lines: chunk.slice(0, MAX_STANZA_LINES),
          highlightIndex: hi,
          slideIndex: slides.length,
        });
        chunk = chunk.slice(MAX_STANZA_LINES);
      }
      if (chunk.length) {
        slides.push({
          type: 'lyrics',
          lines: chunk,
          highlightIndex: hi,
          slideIndex: slides.length,
        });
      }
    }
    return slides;
  }

  const hiDefault = style.highlightLine !== false ? 0 : -1;
  return stanzas.map((stanza) => {
    const expanded = expandLinesForProjection(stanza);
    const chunks = [];
    for (let i = 0; i < expanded.length; i += MAX_STANZA_LINES) {
      chunks.push(expanded.slice(i, i + MAX_STANZA_LINES));
    }
    return chunks.map((linesChunk, index) => ({
      type: 'lyrics',
      lines: linesChunk,
      highlightIndex: hiDefault,
      slideIndex: index,
    }));
  }).flat();
}

/** Reorganiza o texto da letra com linha em branco entre cada slide (visual no editor). */
export function formatLyricsForSlides(rawText, style = {}) {
  const slides = splitLyricsIntoSlides(rawText, style);
  if (!slides.length) return rawText || '';
  return slides.map((s) => s.lines.join('\n')).join('\n\n');
}

function pickStyleValue(override, songStyle, globalStyle, key, fallback) {
  if (override && Object.prototype.hasOwnProperty.call(override, key) && override[key] !== undefined) {
    return override[key];
  }
  if (songStyle && songStyle[key] !== undefined && songStyle[key] !== null && songStyle[key] !== '') {
    return songStyle[key];
  }
  if (globalStyle && globalStyle[key] !== undefined && globalStyle[key] !== null && globalStyle[key] !== '') {
    return globalStyle[key];
  }
  return fallback;
}

export function getLyricsStyle(song, globalStyle, itemOverride = null) {
  const g = globalStyle || {};
  const s = song?.style || {};
  const o = itemOverride || {};
  return {
    fontSize: pickStyleValue(o, s, g, 'fontSize', 54),
    lineHeight: pickStyleValue(o, s, g, 'lineHeight', 1.45),
    align: pickStyleValue(o, s, g, 'align', 'center'),
    marginTop: pickStyleValue(o, s, g, 'marginTop', 10),
    marginBottom: pickStyleValue(o, s, g, 'marginBottom', 10),
    marginLeft: pickStyleValue(o, s, g, 'marginLeft', 6),
    marginRight: pickStyleValue(o, s, g, 'marginRight', 6),
    splitMode: pickStyleValue(o, s, g, 'splitMode', 'lines'),
    linesPerSlide: pickStyleValue(o, s, g, 'linesPerSlide', 4),
    stanzasPerSlide: pickStyleValue(o, s, g, 'stanzasPerSlide', 1),
    highlightLine: pickStyleValue(o, s, g, 'highlightLine', false),
    backgroundPreset: pickStyleValue(o, s, g, 'backgroundPreset', 'theme'),
    backgroundMediaId: pickStyleValue(o, s, g, 'backgroundMediaId', null),
    titleColor: pickStyleValue(o, s, g, 'titleColor', null),
    textColor: pickStyleValue(o, s, g, 'textColor', null),
    textEffect: pickStyleValue(o, s, g, 'textEffect', 'shadow'),
    bgDim: pickStyleValue(o, s, g, 'bgDim', 0),
    vAlign: pickStyleValue(o, s, g, 'vAlign', 'center'),
    fontFamily: pickStyleValue(o, s, g, 'fontFamily', null),
    fontWeight: pickStyleValue(o, s, g, 'fontWeight', null),
    fontStyle: pickStyleValue(o, s, g, 'fontStyle', null),
    textTransform: pickStyleValue(o, s, g, 'textTransform', 'none'),
    transition: o.transition ?? s.transition ?? g.transition ?? null,
  };
}
