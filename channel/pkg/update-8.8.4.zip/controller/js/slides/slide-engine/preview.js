﻿import {
  renderSlide,
  renderFooter,
  renderWatermark,
  renderClock,
  lyricsBackgroundKey,
  renderLyricsBackgroundPersist,
  renderLyricsLinesBlock,
  normalizeMediaSrcKey,
  applyLyricsStyleVars,
  normalizeSlideBackground,
} from '../templates.js';
import { applyTransition, animateSlideChange } from '../animations.js';
import { renderOverlayHtml } from '../../overlays/overlay-library.js';
import { applyLyricsFx, applyLyricsFxPatch } from '../../screen/lyrics-fx.js';
import { RenderPipeline } from '../../render/render-pipeline.js';
import { ImageCache } from '../../render/asset-cache.js';
import { verseDirectionMeta } from '../text-direction.js';
import { TaskScheduler } from '../../core/task-scheduler.js';
import { TaskIds } from '../../core/task-registry.js';
import { DisplayProjectionEngine } from '../../runtime/facades/display-runtime.js';
import { emitRenderIntent } from '../../runtime/render-intent-client.js';

/** Tipos que o slide-prep-worker consegue preparar sem corromper o HTML. */

function previewHasMediaBackground(slide) {
  // Boas-vindas renderiza o fundo (vídeo/imagem) INLINE, com seus overlays/scrim próprios.
  // Usar a camada persistente deixava o vídeo atrás do slide → prévia preta.
  if (slide?.type === 'welcome') return false;
  const t = slide?.background?.type;
  return t === 'video' || t === 'image';
}

export function renderPreview(slide, defaults, prefs, assets = {}) {
  const isLyrics = slide?.type === 'lyrics' || slide?.type === 'lyrics-title';
  const usePersist = isLyrics || previewHasMediaBackground(slide);
  const stageHtml = renderSlide(slide, { defaults, prefs, assets }, { persistBackground: usePersist });
  if (usePersist) {
    return `<div class="screen-viewport preview-inner"><div class="screen-canvas"><div id="lyrics-bg-persist" class="lyrics-bg-persist" hidden></div><div class="screen-stage">${stageHtml}</div></div></div>`;
  }
  return `<div class="screen-viewport preview-inner"><div class="screen-canvas"><div class="screen-stage">${stageHtml}</div></div></div>`;
}

export function previewLyricsShellKey(slide) {
  if (slide?.type !== 'lyrics' && slide?.type !== 'lyrics-title') return '';
  // Só fundo — tipografia aplica via patchPreviewLyricsStage (evita reiniciar vídeo)
  return `lyrics:${lyricsBackgroundKey(slide)}`;
}

/**
 * Fundo de letra na prévia do Controle — leve o suficiente para não travar a UI.
 * A projeção (screen) continua com loop completo via ensureLyricsBackground.
 */
export function ensurePreviewLyricsBackground(scaler, slide, prefs) {
  const persist = scaler?.querySelector('#lyrics-bg-persist');
  const stage = scaler?.querySelector('.screen-stage');
  if (!persist || !stage) return null;
  const isLyrics = slide?.type === 'lyrics' || slide?.type === 'lyrics-title';
  const hasMediaBg = previewHasMediaBackground(slide);
  if (!isLyrics && !hasMediaBg) {
    persist.innerHTML = '';
    persist.hidden = true;
    scaler._previewLyricsBgKey = null;
    return null;
  }

  const bgKey = lyricsBackgroundKey(slide);
  const bg = slide?.background || {};
  const nextVideoSrc = bg.type === 'video' && bg.src ? bg.src : null;
  const existingVideo = persist.querySelector('video.lyrics-bg-video, video.slide-bg-video');

  if (nextVideoSrc && existingVideo) {
    const cur = existingVideo.getAttribute('src') || existingVideo.currentSrc || '';
    if (normalizeMediaSrcKey(cur) === normalizeMediaSrcKey(nextVideoSrc)) {
      persist.hidden = false;
      scaler._previewLyricsBgKey = bgKey;
      persist.dataset.bgKind = 'video';
      const vp = scaler.querySelector('.screen-viewport') || scaler.closest('.screen-viewport');
      if (vp) vp.dataset.hasBgVideo = '1';
      existingVideo.dataset.lyricsPersist = '1';
      existingVideo.muted = true;
      existingVideo.loop = true;
      existingVideo.playsInline = true;
      // Não reinicia nem força play a cada estrofe — só retoma se pausou
      if (existingVideo.paused && !existingVideo.dataset.previewPaused) {
        existingVideo.playbackRate = 0.4;
        existingVideo.play().catch(() => {});
      }
      if (isLyrics) applyLyricsFxPatch(stage, slide, prefs, persist);
      return bgKey;
    }
  }

  const hasStatic = persist.querySelector('.lyrics-bg-image, .lyrics-bg-gradient, .slide-bg-image, .slide-bg-gradient');
  if (!nextVideoSrc && scaler._previewLyricsBgKey === bgKey && hasStatic) {
    persist.hidden = false;
    if (isLyrics) applyLyricsFxPatch(stage, slide, prefs, persist);
    return bgKey;
  }

  persist.innerHTML = renderLyricsBackgroundPersist(slide, prefs, { previewLight: true });
  persist.hidden = false;
  scaler._previewLyricsBgKey = bgKey;
  // Paridade com o projetor: marca vídeo para overlays leves
  const kind = nextVideoSrc ? 'video' : (bg.type === 'image' ? 'image' : 'gradient');
  persist.dataset.bgKind = kind;
  const vp = scaler.querySelector('.screen-viewport') || scaler.closest('.screen-viewport');
  if (vp) vp.dataset.hasBgVideo = kind === 'video' ? '1' : '0';
  const video = persist.querySelector('video.lyrics-bg-video, video.slide-bg-video');
  if (video) {
    video.dataset.lyricsPersist = '1';
    video.muted = true;
    video.loop = true;
    video.playsInline = true;
    video.preload = 'metadata';
    video.playbackRate = 0.4;
    const liveActive = !!(window.__SOMOSUM_LIVE_ACTIVE || document.documentElement?.dataset?.liveActive === '1');
    const lowSpec = !!(prefs?.lowSpec || prefs?.ui?.lowSpec || window.__SOMOSUM_LOW_SPEC || liveActive);
    if (lowSpec) {
      // PC fraco OU culto ao vivo: frame estático na prévia (projetor continua em loop)
      // Evita dual-decode que congelava a projeção no culto.
      video.dataset.previewPaused = '1';
      const freeze = () => {
        try {
          if (video.readyState >= 2) {
            video.currentTime = Math.min(0.15, (video.duration || 1) * 0.02);
          }
          video.pause();
        } catch { /* ignore */ }
      };
      if (video.readyState >= 2) freeze();
      else video.addEventListener('loadeddata', freeze, { once: true });
    } else {
      delete video.dataset.previewPaused;
      // Aguarda idle para não travar o clique/salvar
      const start = () => video.play().catch(() => {});
      if (typeof requestIdleCallback === 'function') {
        requestIdleCallback(start, { timeout: 400 });
      } else {
        setTimeout(start, 80);
      }
    }
  }
  if (isLyrics) applyLyricsFxPatch(stage, slide, prefs, persist);
  return bgKey;
}

/**
 * Atualiza só o stage da prévia (capa↔letra↔estrofe), sem tocar em #lyrics-bg-persist.
 * @returns {boolean} true se o patch foi aplicado
 */
export function patchPreviewLyricsStage(scaler, slide, prefs, context = {}) {
  const stage = scaler?.querySelector('.screen-stage');
  if (!stage) return false;
  const isLyrics = slide?.type === 'lyrics' || slide?.type === 'lyrics-title';
  if (!isLyrics) return false;

  const persist = scaler.querySelector('#lyrics-bg-persist');

  // Mesma estrofe de letra: só as linhas (sem remount)
  if (slide.type === 'lyrics') {
    const slideEl = stage.querySelector('.slide-lyrics:not(.slide-lyrics-title)');
    const body = slideEl?.querySelector('.lyrics-body');
    if (body) {
      applyLyricsStyleVars(slideEl, slide.style || {});
      body.innerHTML = renderLyricsLinesBlock(slide, prefs, { skipEntrance: true });
      applyLyricsFxPatch(stage, slide, prefs, persist);
      return true;
    }
  }

  // Capa ↔ letra ou shell incompleto: troca só o HTML do stage (irmão do vídeo)
  const html = renderSlide(
    slide,
    { defaults: context.defaults || {}, prefs, assets: context.assets || {} },
    { persistBackground: true }
  );
  stage.innerHTML = html;
  applyLyricsFxPatch(stage, slide, prefs, persist);
  return true;
}
