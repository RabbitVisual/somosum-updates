import {
  renderSlide,
  renderFooter,
  renderWatermark,
  renderClock,
  lyricsBackgroundKey,
  renderLyricsBackgroundPersist,
  renderLyricsLinesBlock,
  normalizeMediaSrcKey,
  applyLyricsStyleVars,
  applyMessageStyleVars,
  applySlideStyleVars,
  normalizeSlideBackground,
} from '../templates.js';
import { applyTransition, animateSlideChange } from '../animations.js';
import { renderOverlayHtml } from '../../overlays/overlay-library.js';
import { applyLyricsFx, applyLyricsFxPatch } from '../../screen/lyrics-fx.js';
import { RenderPipeline } from '../../render/render-pipeline.js';
import { ImageCache } from '../../render/asset-cache.js';
import { verseDirectionMeta } from '../text-direction.js';
import { TaskScheduler } from '../../core/task-scheduler.js';
import { TaskIds } from '../../core/task-registry.js';
import { DisplayProjectionEngine } from '../../runtime/facades/display-runtime.js';
import { emitRenderIntent } from '../../runtime/render-intent-client.js';
import { slideStyleFingerprint } from '../../core/presentation-state.js';
/** Tipos que o slide-prep-worker consegue preparar sem corromper o HTML. */

export const WORKER_PREP_TYPES = new Set(['lyrics', 'blank', 'theme']);

export class SlideEngine {
  constructor(rootEl, options = {}) {
    this.root = rootEl;
    this.defaults = options.defaults || {};
    this.prefs = options.prefs || {};
    this.assets = options.assets || {};
    this.overlay = null;
    this.overlayLayer = null;
    this.currentSlide = null;
    this._lastSlideHtml = null;
    this._lyricsBgKey = null;
    this._lyricsBgSlideType = null;
    this._skippedRedraws = 0;
    this._fullRemounts = 0;
    this._renderGeneration = 0;
    this._pipeline = new RenderPipeline({
      renderFn: (ctx) => this._commitSlide(ctx.slide, ctx.animate),
    });
    this.buildShell();
    this._syncLowSpecBudget();
  }

  /** M?tricas de cull / frame-skip (sem segundo RAF ? pipeline existente). */
  getRenderMetrics() {
    return {
      skippedRedraws: this._skippedRedraws || 0,
      fullRemounts: this._fullRemounts || 0,
      hasCurrent: !!this.currentSlide,
    };
  }

  _noteSkip() {
    this._skippedRedraws = (this._skippedRedraws || 0) + 1;
  }

  _isLowSpec() {
    return !!(this.prefs?.lowSpec || this.prefs?.ui?.lowSpec || window.__SOMOSUM_LOW_SPEC);
  }

  /**
   * Low-Spec ? budget eco / live-eco no ResourceGovernor (sem SyncCoordinator).
   * Idempotente; falha silenciosa se o governor ainda n?o carregou.
   */
  _syncLowSpecBudget() {
    const on = this._isLowSpec();
    try {
      window.__SOMOSUM_LOW_SPEC = on;
    } catch { /* ignore */ }
    if (!on) return;
    import('../../runtime/resource-governor.js').then(({ ResourceGovernor }) => {
      const live = !!window.__SOMOSUM_LIVE_ACTIVE;
      ResourceGovernor.forceProfile(live ? 'live-eco' : 'eco');
    }).catch(() => {});
  }

  async _commitSlide(slide, animate) {
    const gen = this._renderGeneration;
    emitRenderIntent('screen', {
      full: true,
      priority: 'critical',
      slideType: slide?.type,
      slideId: slide?.id,
    });
    const result = this._renderSlideDirect(slide, animate, gen);
    if (gen !== this._renderGeneration) return;
    return result;
  }

  buildShell() {
    this.root.innerHTML = `
      <div class="screen-viewport">
        <div class="screen-canvas" id="screen-canvas">
          <div class="lyrics-bg-persist" id="lyrics-bg-persist" hidden aria-hidden="true"></div>
          <div class="screen-stage"></div>
          <canvas id="screen-paint" class="screen-paint-canvas" aria-hidden="true"></canvas>
          <canvas id="screen-postfx" class="screen-postfx-canvas" aria-hidden="true"></canvas>
          <div class="screen-overlay-layer" id="screen-overlay-layer"></div>
          ${renderWatermark({ assets: this.assets })}
          ${renderClock()}
          ${renderFooter(this.prefs.showFooterVerse, this.defaults)}
        </div>
      </div>`;
    this.viewportEl = this.root.querySelector('.screen-viewport');
    this.canvasEl = this.root.querySelector('#screen-canvas');
    this.stageEl = this.root.querySelector('.screen-stage');
    this.paintCanvas = this.root.querySelector('#screen-paint');
    this.postFxCanvas = this.root.querySelector('#screen-postfx');
    this.lyricsBgPersistEl = this.root.querySelector('#lyrics-bg-persist');
    this.overlayLayerEl = this.root.querySelector('#screen-overlay-layer');
    applyTransition(this.stageEl, this.prefs.transition);
    this.syncChromeVisibility();
    this._attachProjectionFit();
    this._initRenderEngine();
  }

  /** Restaura stage DOM e oculta canvases ? tela nunca preta. */
  _ensureDomVisible() {
    if (this.paintCanvas) {
      this.paintCanvas.hidden = true;
      this.paintCanvas.style.display = 'none';
      this.paintCanvas.style.opacity = '0';
    }
    if (this.postFxCanvas) {
      this.postFxCanvas.hidden = true;
      this.postFxCanvas.style.display = 'none';
    }
    if (this.stageEl) this.stageEl.style.visibility = '';
  }

  /**
   * For?a motor DOM (proje??o Screen).
   * Idempotente: se j? est? em DOM com canvases ocultos, n?o mexe no DOM/v?deo.
   */
  forceDomProjection() {
    const alreadyDom = this._renderEngine === 'dom'
      && !this._compositor
      && (!this.paintCanvas || this.paintCanvas.hidden || this.paintCanvas.style.display === 'none');
    if (this.prefs) {
      const r = this.prefs.render || {};
      if (r.engine !== 'dom' || r.postFx) {
        this.prefs.render = {
          ...r,
          engine: 'dom',
          postFx: false,
          reason: 'Proje??o (DOM est?vel)',
          statusLabel: 'DOM ? proje??o confi?vel',
        };
      }
    }
    // Sempre garantir stage vis?vel ? early-return antigo deixava stage hidden ap?s Canvas
    if (alreadyDom) {
      this._ensureDomVisible();
      return;
    }
    this._renderEngine = 'dom';
    this._compositor?.dispose?.();
    this._compositor = null;
    this.canvasEl?.classList.remove('is-canvas-engine');
    this._ensureDomVisible();
  }

  _initRenderEngine() {
    // Default seguro: DOM. Canvas s? se prefs.render.engine === 'canvas' (modo fluidez).
    const pref = this.prefs?.render?.engine || 'dom';
    this._renderEngine = pref === 'canvas' ? 'canvas' : 'dom';
    this.canvasEl?.classList.toggle('is-canvas-engine', this._renderEngine === 'canvas');
    if (this.paintCanvas) {
      this.paintCanvas.hidden = this._renderEngine !== 'canvas';
      this.paintCanvas.style.display = this._renderEngine === 'canvas' ? 'block' : 'none';
      if (this._renderEngine !== 'canvas') this.paintCanvas.style.opacity = '0';
    }
    if (this.postFxCanvas) {
      this.postFxCanvas.hidden = true;
      this.postFxCanvas.style.display = 'none';
    }
    if (this._renderEngine === 'dom') {
      this._compositor?.dispose?.();
      this._compositor = null;
      this._ensureDomVisible();
      return;
    }
    if (this._renderEngine === 'canvas') {
      import('../compositor/slide-compositor.js').then(({ SlideCompositor }) => {
        if (this._renderEngine !== 'canvas') return;
        this._compositor?.dispose?.();
        this._compositor = new SlideCompositor({
          paintCanvas: this.paintCanvas,
          postFxCanvas: this.postFxCanvas,
          stageEl: this.stageEl,
          prefs: this.prefs,
          lowSpec: this._isLowSpec(),
        });
        // N?O esconde o stage at? um paint Canvas bem-sucedido (evita tela preta)
        if (this.stageEl) this.stageEl.style.visibility = '';
      }).catch(() => {
        this._renderEngine = 'dom';
        this.canvasEl?.classList.remove('is-canvas-engine');
        this._ensureDomVisible();
      });
    }
  }

  async _attachProjectionFit() {
    try {
      const { attachProjectionFit } = await import('../projection-fit.js');
      this._disposeProjectionFit?.();
      this._disposeProjectionFit = attachProjectionFit(this.viewportEl, this.canvasEl, {
        surface: 'screen',
        prefs: this.prefs,
        outputIndex: Number(document.documentElement.dataset.screenOutput) || 1,
      });
    } catch { /* fallback: layout fluido */ }
  }

  _syncDisplayProjectionContext(slide) {
    const dpe = DisplayProjectionEngine.getInstance();
    if (!dpe) return;
    const lines = slide?.lines || [];
    const maxChars = lines.reduce((m, l) => Math.max(m, String(l || '').length), 0) || 42;
    const slideFont = Number(slide?.style?.fontSize);
    dpe.updateSlideContext({
      type: slide?.type || 'default',
      lineCount: Math.max(1, lines.length || this.prefs?.globalLyricsStyle?.linesPerSlide || 3),
      maxChars,
      videoFit: slide?.videoFit,
      background: slide?.background || null,
      isBackgroundLoop: !!(slide?.isBackgroundLoop || slide?.background?.type === 'video'),
      operatorFontSize: Number.isFinite(slideFont) && slideFont > 0
        ? slideFont
        : (this.prefs?.globalLyricsStyle?.fontSize || 54),
      preferOperatorFont: Number.isFinite(slideFont) && slideFont > 0,
      align: slide?.style?.align,
      textTransform: slide?.style?.textTransform,
    });
  }

  /** Atualiza CSS vars + linhas no stage sem remount do fundo. */
  _applyLyricsStylePatch(slide) {
    if (!this.stageEl || !slide) return;
    const slideEl = this.stageEl.querySelector('.slide-lyrics, .slide-lyrics-title');
    if (!slideEl) return;
    applyLyricsStyleVars(slideEl, slide.style || {});
    if (slide.type === 'lyrics') {
      const body = slideEl.querySelector('.lyrics-body');
      if (body) {
        body.innerHTML = renderLyricsLinesBlock(slide, this.prefs);
      }
    }
  }

  /** Tipografia da Mensagem ? garante A+/A? do inspetor mesmo se o HTML for reutilizado. */
  _applyMessageStylePatch(slide) {
    if (!this.stageEl || !slide || slide.type !== 'message') return;
    const slideEl = this.stageEl.querySelector('.slide-message-pro, .slide[data-type="message"]');
    if (!slideEl) return;
    applyMessageStyleVars(slideEl, slide.style || {});
  }

  /** Tipografia gen?rica (b?blia, ora??o, se??o, an?ncios, tema?) ? CSS vars ao vivo. */
  _applySlideStylePatch(slide) {
    if (!this.stageEl || !slide) return;
    if (slide.type === 'lyrics' || slide.type === 'lyrics-title') {
      this._applyLyricsStylePatch(slide);
      return;
    }
    if (slide.type === 'message') {
      this._applyMessageStylePatch(slide);
      return;
    }
    const slideEl = this.stageEl.querySelector(
      `.slide[data-type="${slide.type}"], .slide-${slide.type}, .slide`,
    );
    if (!slideEl) return;
    applySlideStyleVars(slideEl, slide.style || {});
  }

  syncChromeVisibility() {
    const clock = this.root.querySelector('#screen-clock');
    if (clock) {
      const visible = !!this.prefs.showClock;
      clock.classList.toggle('is-visible', visible);
      clock.setAttribute('aria-hidden', visible ? 'false' : 'true');
    }
    const footer = this.root.querySelector('.screen-footer');
    if (footer) footer.style.display = this.prefs.showFooterVerse ? '' : 'none';
  }

  /**
   * Cull / early-exit: evita remount completo quando o estado visual n?o mudou.
   * N?o introduz RAF pr?prio ? o FrameScheduler/RenderScheduler j? coalescem.
   */
  _shouldSkipFullRemount(slide, html) {
    if (!slide || !this.currentSlide) return false;
    if (this._lastSlideHtml && this._lastSlideHtml === html) {
      // Mesmo HTML, mas tipografia do inspetor pode ter mudado (fingerprint incompleto antigo)
      const prevFp = slideStyleFingerprint(this.currentSlide, this.prefs);
      const nextFp = slideStyleFingerprint(slide, this.prefs);
      if (prevFp !== nextFp) return false;
      return true;
    }
    return false;
  }

  _renderSlideDirect(slide, animate, commitGen = this._renderGeneration) {
    if (commitGen !== this._renderGeneration) return;
    if (!slide) { this.showOverlay('blank'); return; }
    normalizeSlideBackground(slide);

    const isLyrics = this.isLyricsSlide(slide);
    const usePersist = this.usesPersistBackground(slide);
    const prev = this.currentSlide;
    const prevPersist = this.usesPersistBackground(prev);
    const prevIsLyrics = this.isLyricsSlide(prev);
    const sameSlideType = prev?.type === slide?.type;
    const lowSpec = this._isLowSpec();
    const transition = lowSpec ? 'none' : (slide.transition || this.prefs.transition || 'fade');

    if (usePersist) {
      const bgKey = lyricsBackgroundKey(slide);
      const prevKey = this._lyricsBgKey || (prevPersist ? lyricsBackgroundKey(prev) : null);
      const sameBg = !!bgKey && prevKey === bgKey;
      this.overlay = null;
      this.clearOverlayLayer(false);
      applyTransition(this.stageEl, transition);

      if (isLyrics) {
        // Mesmo fundo de v?deo/imagem: s? atualiza o texto ? fundo continua em loop (padr?o Holyrics)
        if (sameBg && prevIsLyrics) {
          const canPatchLines = slide.type === 'lyrics' && prev?.type === 'lyrics';
          if (canPatchLines) {
            const sameLines = prev?.lines?.join('|') === slide.lines?.join('|');
            if (sameLines) {
              this.currentSlide = slide;
              this._noteSkip();
              this._applyLyricsStylePatch(slide);
              applyLyricsFxPatch(this.stageEl, slide, this.lyricsFxPrefs(slide), this.lyricsBgPersistEl);
              this._syncDisplayProjectionContext(slide);
              return;
            }
            this.showLyricsSlide(slide, { patch: true });
            this._applyLyricsStylePatch(slide);
            this._noteSkip();
            this._syncDisplayProjectionContext(slide);
            return;
          }
          // title ? lyrics ou lyrics-title tipografia: troca conte?do, mant?m o mesmo <video>
          this.showLyricsSlide(slide, { patch: false });
          this._applyLyricsStylePatch(slide);
          this._noteSkip();
          this._syncDisplayProjectionContext(slide);
          return;
        }

        this.showLyricsSlide(slide);
        this._fullRemounts = (this._fullRemounts || 0) + 1;
        this._syncDisplayProjectionContext(slide);
        return;
      }

      // Se��o / b�blia / mensagem / etc. com m�dia ? mesmo padr�o das letras
      if (sameBg && prevPersist && sameSlideType) {
        this.showPersistedBackgroundSlide(slide, commitGen);
        this._applySlideStylePatch(slide);
        this._noteSkip();
        this._syncDisplayProjectionContext(slide);
        return;
      }

      this.showPersistedBackgroundSlide(slide, commitGen);
      this._applySlideStylePatch(slide);
      this._fullRemounts = (this._fullRemounts || 0) + 1;
      this._syncDisplayProjectionContext(slide);
      return;
    }

    // Gradiente / sem m?dia ? libera o decoder persistente
    this.clearLyricsBackground();

    const prepKey = slide?.id || slide?.type || '';
    const canUsePrepared = WORKER_PREP_TYPES.has(slide?.type)
      && this._preparedHtml
      && this._preparedForSlideId
      && this._preparedForSlideId === prepKey;
    const html = canUsePrepared
      ? this._preparedHtml
      : renderSlide(slide, this.ctx());
    if (canUsePrepared) {
      this._preparedHtml = null;
      this._preparedForSlideId = null;
    }
    if (this._shouldSkipFullRemount(slide, html)) {
      this.currentSlide = slide;
      this._noteSkip();
      this._applySlideStylePatch(slide);
      this._syncDisplayProjectionContext(slide);
      return;
    }

    const doAnimate = animate && !isLyrics && !lowSpec;
    this.overlay = null;
    this.clearOverlayLayer(false);
    this.currentSlide = slide;
    this._lastSlideHtml = html;
    this._fullRemounts = (this._fullRemounts || 0) + 1;
    applyTransition(this.stageEl, transition);

    const applyContent = () => {
      if (commitGen !== this._renderGeneration) return;
      if (this._renderEngine === 'canvas' && this._compositor) {
        void this._compositor.paint(slide, this.ctx()).then((ok) => {
          if (commitGen !== this._renderGeneration) return;
          if (!ok) {
            this._ensureDomVisible();
            if (!this.stageEl?.innerHTML) this.stageEl.innerHTML = html;
            this._applySlideStylePatch(slide);
            this._playStageVideos();
            import('../slide-overflow-fit.js').then((m) => m.fitSlideOverflow(this.stageEl)).catch(() => {});
          }
        }).catch(() => {
          if (commitGen !== this._renderGeneration) return;
          this._ensureDomVisible();
          this.stageEl.innerHTML = html;
          this._applySlideStylePatch(slide);
          this._playStageVideos();
          import('../slide-overflow-fit.js').then((m) => m.fitSlideOverflow(this.stageEl)).catch(() => {});
        });
      } else {
        this._ensureDomVisible();
        this.stageEl.innerHTML = html;
        this._applySlideStylePatch(slide);
        this._playStageVideos();
        import('../slide-overflow-fit.js').then((m) => m.fitSlideOverflow(this.stageEl)).catch(() => {});
      }
      this._syncDisplayProjectionContext(slide);
    };

    if (doAnimate) {
      animateSlideChange(this.stageEl, applyContent);
    } else {
      applyContent();
    }
  }

  setAssets(assets) {
    this.assets = assets || {};
    const wm = this.root.querySelector('.screen-watermark');
    if (wm && this.assets.logo) wm.src = this.assets.logo;
  }

  _renderPrefsKey() {
    const r = this.prefs?.render || {};
    return JSON.stringify({
      mode: r.mode || 'auto',
      engine: r.engine || 'dom',
      postFx: !!r.postFx,
      previewMode: r.previewMode || 'dom',
    });
  }

  updatePrefs(prefs) {
    const prevRenderKey = this._renderPrefsKey();
    const prevLowSpec = this._isLowSpec();
    this.prefs = { ...this.prefs, ...prefs };
    if (prefs?.render) {
      this.prefs.render = { ...(this.prefs.render || {}), ...prefs.render };
    }
    applyTransition(this.stageEl, this._isLowSpec() ? 'none' : this.prefs.transition);
    this.syncChromeVisibility();
    const lowSpecChanged = prevLowSpec !== this._isLowSpec();
    this._syncLowSpecBudget();
    if (prevRenderKey !== this._renderPrefsKey() || lowSpecChanged) {
      this._initRenderEngine();
    }
    // Se prefs pediram DOM (ex.: Screen), garantir canvases ocultos sem thrash
    if ((this.prefs?.render?.engine || 'dom') !== 'canvas' && this._renderEngine === 'dom') {
      if (this.paintCanvas && !this.paintCanvas.hidden) this._ensureDomVisible();
    } else if ((this.prefs?.render?.engine || 'dom') !== 'canvas') {
      this._ensureDomVisible();
    }
    DisplayProjectionEngine.getInstance()?.setPrefs(this.prefs);
    if (this.currentSlide && this.stageEl?.querySelector('.slide-lyrics, .slide-lyrics-title')) {
      applyLyricsFx(this.stageEl, this.currentSlide, this.lyricsFxPrefs(this.currentSlide), this.lyricsBgPersistEl);
    }
  }

  ctx() {
    return {
      defaults: this.defaults,
      prefs: this.prefs,
      assets: this.assets,
      textDirection: this.currentSlide ? verseDirectionMeta(this.currentSlide) : { dir: 'ltr', lang: 'pt' },
    };
  }

  lyricsFxPrefs(slide) {
    const itemFx = slide?.data?.lyricsFx || slide?.lyricsFx || {};
    const merged = {
      ...this.prefs,
      lyricsFx: { ...this.prefs.lyricsFx, ...itemFx },
    };
    // Low-Spec: desliga FX pesados de letra (mant?m texto leg?vel)
    if (this._isLowSpec()) {
      merged.lyricsFx = {
        ...merged.lyricsFx,
        ambient: 'none',
        lineEntrance: 'none',
        highlightPulse: false,
      };
    }
    return merged;
  }

  isLyricsSlide(slide) {
    return slide?.type === 'lyrics' || slide?.type === 'lyrics-title';
  }

  hasMediaBackground(slide) {
    const t = slide?.background?.type;
    const src = String(slide?.background?.src || '').trim();
    return (t === 'video' || t === 'image') && !!src;
  }

  /** Letras + qualquer slide com v?deo/imagem de fundo ? evita remount do decoder. */
  usesPersistBackground(slide) {
    // Boas-vindas renderiza o fundo inline (overlays/scrim próprios). Na camada
    // persistente o vídeo ficava atrás do slide e não aparecia (projeção preta).
    if (slide?.type === 'welcome') return false;
    return this.isLyricsSlide(slide) || this.hasMediaBackground(slide);
  }

  _playBgVideo(video) {
    if (!video) return;
    try {
      video.dataset.lyricsPersist = '1';
      video.muted = true;
      video.defaultMuted = true;
      video.loop = true;
      video.playsInline = true;
      video.setAttribute('muted', '');
      video.setAttribute('playsinline', '');
      video.setAttribute('webkit-playsinline', '');
      video.setAttribute('loop', '');
      // object-fit via CSS --video-fit / applyVideoFitToElements (não forçar cover inline)
      video.style.removeProperty('object-fit');
      video.style.opacity = '1';
      video.style.visibility = 'visible';

      // Src relativo ? absoluto na origem do projetor (evita 404 silencioso)
      try {
        const raw = video.getAttribute('src') || '';
        if (raw && !/^https?:|blob:|data:/i.test(raw) && !raw.startsWith('/')) {
          video.setAttribute('src', `/${raw.replace(/^\/+/, '')}`);
        }
      } catch { /* ignore */ }

      if (!video.dataset.bgPlayBound) {
        video.dataset.bgPlayBound = '1';
        const retryPlay = (attempt = 0) => {
          const run = () => {
            try {
              if (video.error || video.readyState === 0) {
                const src = video.getAttribute('src') || video.currentSrc;
                if (src) video.load();
              }
            } catch { /* ignore */ }
            const p = video.play();
            if (p && typeof p.catch === 'function') {
              p.catch((err) => {
                if (attempt < 6) {
                  setTimeout(() => retryPlay(attempt + 1), 180 * (attempt + 1));
                } else {
                  console.warn('[SOMOSUM] bg video play failed', err?.message || err, video.currentSrc || video.src);
                }
              });
            }
          };
          run();
        };
        video.addEventListener('loadeddata', () => {
          if (video.paused) retryPlay(0);
        });
        video.addEventListener('canplay', () => {
          if (video.paused) retryPlay(0);
        });
        video.addEventListener('error', () => {
          try {
            const src = video.getAttribute('src') || video.currentSrc;
            if (src) {
              video.load();
              setTimeout(() => retryPlay(0), 300);
            }
          } catch { /* ignore */ }
        });
        video.addEventListener('stalled', () => {
          if (video.paused) retryPlay(0);
        });
        video.addEventListener('ended', () => {
          // loop attribute should handle; force if browser dropped loop
          try {
            video.currentTime = 0;
            retryPlay(0);
          } catch { /* ignore */ }
        });
        video._bgRetryPlay = retryPlay;
      }
      if (video.paused || video.ended) {
        (video._bgRetryPlay || (() => video.play().catch(() => {})))(0);
      }
    } catch (err) {
      console.warn('[SOMOSUM] _playBgVideo', err?.message || err);
    }
  }
}
