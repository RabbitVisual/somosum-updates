using Somosum.Core;
using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace Somosum.Server
{
    /// <summary>
    /// Stage e apply de pacotes delta de atualização do app.
    /// </summary>
    public sealed class AppUpdateInstallService
    {
        private readonly string _root;

        public AppUpdateInstallService(string root)
        {
            _root = root ?? "";
        }

        public string DataDir => Path.Combine(_root, ContentLayout.ModelDir, "data");

        public string StagingRoot => Path.Combine(DataDir, ".update-staging");

        public string PendingPath => Path.Combine(DataDir, ".pending-update.json");

        public string WhatsNewPath => Path.Combine(DataDir, ".whats-new.json");

        public string DismissedPath => Path.Combine(DataDir, ".update-dismissed.json");

        public bool TryStageFromBytes(byte[] bytes, string expectedSha256, out Dictionary<string, object> result, out string errorCode)
        {
            result = null;
            errorCode = null;
            if (bytes == null || bytes.Length < 32)
            {
                errorCode = "empty_payload";
                return false;
            }

            if (string.IsNullOrWhiteSpace(expectedSha256))
            {
                errorCode = "sha256_required";
                return false;
            }

            {
                var hash = Sha256Hex(bytes);
                if (!hash.Equals(expectedSha256.Trim(), StringComparison.OrdinalIgnoreCase))
                {
                    errorCode = "hash_mismatch";
                    return false;
                }
            }

            Dictionary<string, object> manifest;
            try
            {
                using (var ms = new MemoryStream(bytes))
                using (var zip = new ZipArchive(ms, ZipArchiveMode.Read))
                {
                    var entry = zip.GetEntry("update-manifest.json");
                    if (entry == null)
                    {
                        errorCode = "manifest_missing";
                        return false;
                    }
                    using (var rs = entry.Open())
                    using (var reader = new StreamReader(rs, Encoding.UTF8))
                    {
                        var json = reader.ReadToEnd();
                        manifest = JsonSerializer.Deserialize<Dictionary<string, object>>(json);
                    }

                    if (!ValidateManifest(manifest, out errorCode)) return false;

                    var toVer = manifest["to"]?.ToString();
                    if (!IsSafeVersionFolder(toVer))
                    {
                        errorCode = "invalid_version";
                        return false;
                    }

                    var stageDir = Path.Combine(StagingRoot, toVer);
                    var stagingRootFull = Path.GetFullPath(StagingRoot)
                        .TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar)
                        + Path.DirectorySeparatorChar;
                    var stageDirFull = Path.GetFullPath(stageDir);
                    if (!stageDirFull.StartsWith(stagingRootFull, StringComparison.OrdinalIgnoreCase))
                    {
                        errorCode = "staging_path_escape";
                        return false;
                    }

                    if (Directory.Exists(stageDir)) Directory.Delete(stageDir, true);
                    Directory.CreateDirectory(stageDir);

                    foreach (var e in zip.Entries)
                    {
                        if (string.IsNullOrEmpty(e.Name)) continue;
                        var rel = AppUpdateAllowlist.Normalize(e.FullName.Replace('\\', '/'));
                        if (rel == null) continue;
                        if (rel.Equals("update-manifest.json", StringComparison.OrdinalIgnoreCase)) continue;
                        if (rel.StartsWith("notes/", StringComparison.OrdinalIgnoreCase)) continue;

                        if (!AppUpdateAllowlist.IsAllowedReplacePath(rel))
                            continue;

                        var dest = Path.Combine(stageDir, rel.Replace('/', Path.DirectorySeparatorChar));
                        if (!AppUpdateAllowlist.IsUnderAppRoot(dest, stageDir))
                        {
                            errorCode = "extract_path_escape:" + rel;
                            try { Directory.Delete(stageDir, true); } catch { }
                            return false;
                        }
                        var destDir = Path.GetDirectoryName(dest);
                        if (!string.IsNullOrEmpty(destDir)) Directory.CreateDirectory(destDir);
                        e.ExtractToFile(dest, overwrite: true);
                    }

                    File.WriteAllText(Path.Combine(stageDir, "update-manifest.json"),
                        JsonSerializer.Serialize(manifest), Encoding.UTF8);

                    var notesEntry = zip.GetEntry("notes/" + toVer + ".md");
                    if (notesEntry != null)
                    {
                        var notesDest = Path.Combine(stageDir, "notes", toVer + ".md");
                        Directory.CreateDirectory(Path.GetDirectoryName(notesDest) ?? stageDir);
                        if (AppUpdateAllowlist.IsUnderAppRoot(notesDest, stageDir))
                            notesEntry.ExtractToFile(notesDest, overwrite: true);
                    }

                    result = new Dictionary<string, object>
                    {
                        ["ok"] = true,
                        ["to"] = toVer,
                        ["staging"] = stageDir,
                        ["files"] = manifest.ContainsKey("replace")
                            ? manifest["replace"]
                            : new object[0],
                    };
                    return true;
                }
            }
            catch (Exception ex)
            {
                errorCode = "stage_failed:" + ex.Message;
                return false;
            }
        }

        public bool TryPrepareApply(out Dictionary<string, object> result, out string errorCode)
        {
            result = null;
            errorCode = null;

            var staged = FindLatestStaging();
            if (staged == null)
            {
                errorCode = "no_staging";
                return false;
            }

            var manifestPath = Path.Combine(staged, "update-manifest.json");
            if (!File.Exists(manifestPath))
            {
                errorCode = "manifest_missing";
                return false;
            }

            Dictionary<string, object> manifest;
            try
            {
                manifest = JsonSerializer.Deserialize<Dictionary<string, object>>(File.ReadAllText(manifestPath));
            }
            catch
            {
                errorCode = "manifest_invalid";
                return false;
            }

            if (!ValidateManifest(manifest, out errorCode)) return false;

            var pending = new Dictionary<string, object>
            {
                ["stagingDir"] = staged,
                ["to"] = manifest["to"]?.ToString(),
                ["from"] = manifest.ContainsKey("from") ? manifest["from"]?.ToString() : null,
                ["requestedAt"] = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds(),
            };
            File.WriteAllText(PendingPath, JsonSerializer.Serialize(pending), Encoding.UTF8);

            result = new Dictionary<string, object>
            {
                ["ok"] = true,
                ["to"] = pending["to"],
                ["pending"] = PendingPath,
            };
            return true;
        }

        public static bool TryApplyPending(string appRoot, out string error)
        {
            error = null;
            var dataDir = Path.Combine(appRoot, ContentLayout.ModelDir, "data");
            var pendingPath = Path.Combine(dataDir, ".pending-update.json");
            if (!File.Exists(pendingPath)) return true;

            try
            {
                var pending = JsonSerializer.Deserialize<Dictionary<string, object>>(File.ReadAllText(pendingPath));
                var stagingDir = pending?["stagingDir"]?.ToString();
                if (string.IsNullOrWhiteSpace(stagingDir) || !Directory.Exists(stagingDir))
                {
                    File.Delete(pendingPath);
                    error = "staging_missing";
                    return false;
                }

                var manifestPath = Path.Combine(stagingDir, "update-manifest.json");
                if (!File.Exists(manifestPath))
                {
                    File.Delete(pendingPath);
                    error = "manifest_missing";
                    return false;
                }

                var manifest = JsonSerializer.Deserialize<Dictionary<string, object>>(File.ReadAllText(manifestPath));
                var toVer = manifest?["to"]?.ToString();

                var copied = 0;
                var missing = 0;
                if (manifest != null && manifest.TryGetValue("replace", out var repObj) && repObj is JsonElement repEl && repEl.ValueKind == JsonValueKind.Array)
                {
                    foreach (var item in repEl.EnumerateArray())
                    {
                        var rel = AppUpdateAllowlist.Normalize(item.GetString());
                        if (string.IsNullOrEmpty(rel) || !AppUpdateAllowlist.IsAllowedReplacePath(rel)) continue;
                        var src = Path.Combine(stagingDir, rel.Replace('/', Path.DirectorySeparatorChar));
                        var dst = Path.Combine(appRoot, rel.Replace('/', Path.DirectorySeparatorChar));
                        if (!File.Exists(src))
                        {
                            missing++;
                            continue;
                        }
                        if (!AppUpdateAllowlist.IsUnderAppRoot(dst, appRoot)) continue;
                        var dstDir = Path.GetDirectoryName(dst);
                        if (!string.IsNullOrEmpty(dstDir)) Directory.CreateDirectory(dstDir);
                        File.Copy(src, dst, overwrite: true);
                        copied++;
                    }
                }

                if (missing > 0 && copied == 0)
                {
                    // Nada aplicado — não marcar VERSION nem limpar staging (instalação incompleta)
                    return false;
                }

                if (manifest != null && manifest.TryGetValue("delete", out var delObj) && delObj is JsonElement delEl && delEl.ValueKind == JsonValueKind.Array)
                {
                    foreach (var item in delEl.EnumerateArray())
                    {
                        var rel = AppUpdateAllowlist.Normalize(item.GetString());
                        if (string.IsNullOrEmpty(rel) || !AppUpdateAllowlist.IsAllowedDeletePath(rel)) continue;
                        var dst = Path.Combine(appRoot, rel.Replace('/', Path.DirectorySeparatorChar));
                        if (!AppUpdateAllowlist.IsUnderAppRoot(dst, appRoot)) continue;
                        if (File.Exists(dst)) File.Delete(dst);
                    }
                }

                if (!string.IsNullOrWhiteSpace(toVer))
                {
                    File.WriteAllText(Path.Combine(appRoot, "VERSION"), toVer.Trim() + Environment.NewLine, Encoding.UTF8);
                }

                var notesPath = Path.Combine(stagingDir, "notes", toVer + ".md");
                var notesBody = File.Exists(notesPath) ? File.ReadAllText(notesPath, Encoding.UTF8) : $"Atualização para v{toVer}";
                var whatsNew = new Dictionary<string, object>
                {
                    ["version"] = toVer,
                    ["shown"] = false,
                    ["body"] = notesBody,
                    ["appliedAt"] = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds(),
                };
                File.WriteAllText(Path.Combine(dataDir, ".whats-new.json"), JsonSerializer.Serialize(whatsNew), Encoding.UTF8);

                try { Directory.Delete(stagingDir, true); } catch { }
                try { Directory.Delete(Path.Combine(dataDir, ".update-staging"), true); } catch { }
                File.Delete(pendingPath);
                CleanupTempCaches(appRoot);
                return true;
            }
            catch (Exception ex)
            {
                error = ex.Message;
                return false;
            }
        }

        /// <summary>
        /// Remove restos de staging/temp do ciclo de atualização (não toca em dados da igreja).
        /// </summary>
        public Dictionary<string, object> CleanupTempCaches()
        {
            return CleanupTempCaches(_root);
        }

        public static Dictionary<string, object> CleanupTempCaches(string appRoot)
        {
            var removed = 0;
            var dataDir = Path.Combine(appRoot ?? "", ContentLayout.ModelDir, "data");
            try
            {
                var staging = Path.Combine(dataDir, ".update-staging");
                if (Directory.Exists(staging) && !File.Exists(Path.Combine(dataDir, ".pending-update.json")))
                {
                    try { Directory.Delete(staging, true); removed++; } catch { }
                }
            }
            catch { /* ignore */ }

            try
            {
                if (Directory.Exists(dataDir))
                {
                    foreach (var f in Directory.GetFiles(dataDir, ".update-*.tmp"))
                    {
                        try { File.Delete(f); removed++; } catch { }
                    }
                    foreach (var f in Directory.GetFiles(dataDir, "*.update-part"))
                    {
                        try { File.Delete(f); removed++; } catch { }
                    }
                }
            }
            catch { /* ignore */ }

            try
            {
                var temp = Path.GetTempPath();
                foreach (var path in Directory.GetDirectories(temp, "somosum-*"))
                {
                    var name = Path.GetFileName(path) ?? "";
                    if (name.StartsWith("somosum-relaunch-", StringComparison.OrdinalIgnoreCase)) continue;
                    try { Directory.Delete(path, true); removed++; } catch { }
                }
                foreach (var f in Directory.GetFiles(temp, "somosum-update*"))
                {
                    try { File.Delete(f); removed++; } catch { }
                }
            }
            catch { /* ignore */ }

            return new Dictionary<string, object>
            {
                ["ok"] = true,
                ["removed"] = removed,
            };
        }

        public string ReadLocalVersion()
        {
            var vf = Path.Combine(_root, "VERSION");
            if (!File.Exists(vf)) return "0.0.0";
            return File.ReadAllText(vf).Trim();
        }

        public string ReadWhatsNewJson()
        {
            if (!File.Exists(WhatsNewPath)) return null;
            return File.ReadAllText(WhatsNewPath, Encoding.UTF8);
        }

        public bool MarkWhatsNewShown()
        {
            if (!File.Exists(WhatsNewPath)) return false;
            try
            {
                var doc = JsonSerializer.Deserialize<Dictionary<string, object>>(File.ReadAllText(WhatsNewPath));
                doc["shown"] = true;
                File.WriteAllText(WhatsNewPath, JsonSerializer.Serialize(doc), Encoding.UTF8);
                return true;
            }
            catch
            {
                return false;
            }
        }

        public string ReadDismissedJson()
        {
            if (!File.Exists(DismissedPath)) return "{}";
            return File.ReadAllText(DismissedPath, Encoding.UTF8);
        }

        public void DismissVersion(string version)
        {
            Dictionary<string, object> doc;
            try
            {
                doc = JsonSerializer.Deserialize<Dictionary<string, object>>(ReadDismissedJson()) ?? new Dictionary<string, object>();
            }
            catch
            {
                doc = new Dictionary<string, object>();
            }
            doc[version] = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
            File.WriteAllText(DismissedPath, JsonSerializer.Serialize(doc), Encoding.UTF8);
        }

        private string FindLatestStaging()
        {
            if (!Directory.Exists(StagingRoot)) return null;
            var dirs = Directory.GetDirectories(StagingRoot)
                .OrderByDescending(Directory.GetLastWriteTimeUtc)
                .ToArray();
            return dirs.Length > 0 ? dirs[0] : null;
        }

        private static bool ValidateManifest(Dictionary<string, object> manifest, out string errorCode)
        {
            errorCode = null;
            if (manifest == null || !manifest.ContainsKey("to"))
            {
                errorCode = "manifest_invalid";
                return false;
            }
            var toVer = manifest["to"]?.ToString();
            if (!IsSafeVersionFolder(toVer))
            {
                errorCode = "invalid_version";
                return false;
            }
            if (manifest.TryGetValue("replace", out var repObj) && repObj is JsonElement repEl && repEl.ValueKind == JsonValueKind.Array)
            {
                foreach (var item in repEl.EnumerateArray())
                {
                    var rel = AppUpdateAllowlist.Normalize(item.GetString());
                    if (!AppUpdateAllowlist.IsAllowedReplacePath(rel))
                    {
                        errorCode = "manifest_path_blocked:" + rel;
                        return false;
                    }
                }
            }
            if (manifest.TryGetValue("delete", out var delObj) && delObj is JsonElement delEl && delEl.ValueKind == JsonValueKind.Array)
            {
                foreach (var item in delEl.EnumerateArray())
                {
                    var rel = AppUpdateAllowlist.Normalize(item.GetString());
                    if (!AppUpdateAllowlist.IsAllowedDeletePath(rel))
                    {
                        errorCode = "manifest_delete_blocked:" + rel;
                        return false;
                    }
                }
            }
            return true;
        }

        /// <summary>Pasta de staging só com semver simples (bloqueia path traversal via "to").</summary>
        private static bool IsSafeVersionFolder(string version)
        {
            if (string.IsNullOrWhiteSpace(version) || version.Length > 32) return false;
            if (version.Contains("..") || version.IndexOfAny(Path.GetInvalidFileNameChars()) >= 0) return false;
            for (var i = 0; i < version.Length; i++)
            {
                var c = version[i];
                if (char.IsLetterOrDigit(c) || c == '.' || c == '-' || c == '_') continue;
                return false;
            }
            return version.IndexOf('.') >= 0;
        }

        private static string Sha256Hex(byte[] bytes)
        {
            using (var sha = SHA256.Create())
            {
                return BitConverter.ToString(sha.ComputeHash(bytes)).Replace("-", "").ToLowerInvariant();
            }
        }
    }
}
