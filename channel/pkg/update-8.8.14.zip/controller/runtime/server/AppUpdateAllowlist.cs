using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace Somosum.Server
{
    /// <summary>Paths que um pacote delta pode substituir — nunca model/data do usuário.</summary>
    public static class AppUpdateAllowlist
    {
        private static readonly string[] AllowedPrefixes =
        {
            "controller/",
            "view/",
            "model/content/",
            "model/storage/",
            "system/media/index.json",
            "system/media/LEIA-ME.txt",
            "app/",
            "docs/",
        };

        private static readonly HashSet<string> AllowedExact = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
        {
            "VERSION",
            "build-manifest.json",
            "LEIA-ME.txt",
            "LEIA-ME-PRIMEIRO.txt",
            "README.md",
            "SOMOSUM.exe",
        };

        public static string Normalize(string relativePath)
        {
            if (string.IsNullOrWhiteSpace(relativePath)) return null;
            return relativePath.Replace('\\', '/').Trim().TrimStart('/');
        }

        public static bool IsAllowedReplacePath(string relativePath)
        {
            var n = Normalize(relativePath);
            if (string.IsNullOrEmpty(n) || n.Contains("..")) return false;
            if (n.StartsWith("model/data/", StringComparison.OrdinalIgnoreCase)) return false;
            if (AllowedExact.Contains(n)) return true;
            return AllowedPrefixes.Any(p =>
                n.Equals(p, StringComparison.OrdinalIgnoreCase)
                || n.StartsWith(p, StringComparison.OrdinalIgnoreCase));
        }

        public static bool IsAllowedDeletePath(string relativePath)
        {
            return IsAllowedReplacePath(relativePath);
        }

        public static bool IsUnderAppRoot(string fullPath, string appRoot)
        {
            try
            {
                var root = Path.GetFullPath(appRoot).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar)
                    + Path.DirectorySeparatorChar;
                var full = Path.GetFullPath(fullPath);
                return full.StartsWith(root, StringComparison.OrdinalIgnoreCase);
            }
            catch
            {
                return false;
            }
        }
    }
}
