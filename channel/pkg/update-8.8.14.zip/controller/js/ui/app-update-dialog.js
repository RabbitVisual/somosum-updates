/**
 * Dialog de atualização do sistema (opt-in).
 * Fluxo: baixar → confirmar reinício → aplicar + reabrir.
 */
import {
  checkForAppUpdate,
  downloadAndStageUpdate,
  prepareAndRelaunchUpdate,
  dismissUpdateVersion,
} from '../core/app-update-service.js';
import { fetchCatalog } from '../core/catalog-proxy-fetch.js';
import { releaseNotesToHtml } from '../core/release-notes-format.js';
import { esc } from '../control/utils/escape.js';

let _checking = false;

function ensureUpdateCss() {
  if (document.getElementById('somosum-app-update-css')) return;
  const link = document.createElement('link');
  link.id = 'somosum-app-update-css';
  link.rel = 'stylesheet';
  link.href = '/css/app-update.css';
  document.head.appendChild(link);
}

export async function showUpdateAvailableDialog(latest, { onLater, onDismiss, chainMeta = null } = {}) {
  ensureUpdateCss();
  if (document.getElementById('somosum-app-update')) return false;

  const ver = latest?.version || '?';
  const tip = chainMeta?.channelTip?.version;
  const steps = chainMeta?.stepsRemaining || 1;
  const chainHint = tip && tip !== ver
    ? `<p class="app-update-hint"><strong>Passo em ordem:</strong> esta é a <strong>v${esc(ver)}</strong>${steps > 1 ? ` (${steps} passos até v${esc(tip)})` : ''}. Depois de reiniciar, verifique de novo até chegar na mais recente.</p>`
    : '';
  let notesHtml = '<p>Correções e melhorias nesta versão.</p>';
  if (latest?.notesPath && latest?.version) {
    try {
      const notesPath = String(latest.notesPath || '').replace(/\\/g, '/');
      const safeNotes = /^notes\/[0-9]+\.[0-9]+(?:\.[0-9]+)?\.md$/i.test(notesPath)
        ? notesPath
        : `notes/${String(latest.version).replace(/[^0-9.]/g, '')}.md`;
      const cfgRes = await fetch('/content/updates/channel.json', { cache: 'no-store' });
      const cfg = cfgRes.ok ? await cfgRes.json() : {};
      const owner = cfg.owner || 'RabbitVisual';
      const repo = cfg.repo || 'somosum-updates';
      const branch = cfg.branch || 'main';
      const notesUrl = `https://cdn.jsdelivr.net/gh/${owner}/${repo}@${branch}/channel/${safeNotes}?_=${Date.now()}`;
      const nr = await fetchCatalog(notesUrl);
      if (nr.ok) notesHtml = `<div class="app-update-notes">${releaseNotesToHtml(await nr.text())}</div>`;
    } catch { /* fallback */ }
  }

  return new Promise((resolve) => {
    const overlay = document.createElement('div');
    overlay.id = 'somosum-app-update';
    overlay.className = 'app-update-overlay';
    overlay.innerHTML = `
      <div class="app-update-card" role="dialog" aria-labelledby="app-update-title">
        <div id="app-update-phase-offer">
          <p class="app-update-kicker">Há uma versão nova</p>
          <h2 id="app-update-title">SOMOSUM v${esc(ver)}</h2>
          ${notesHtml}
          ${chainHint}
          <p class="app-update-hint">O download é leve (só o que mudou). Cultos, músicas, mídia e configurações da igreja permanecem neste PC.</p>
        </div>
        <div id="app-update-phase-progress" hidden>
          <p class="app-update-kicker">Preparando</p>
          <h2>Baixando a atualização</h2>
          <div class="app-update-progress">
            <div class="app-update-progress-bar"><span id="app-update-pct"></span></div>
            <p id="app-update-status">Preparando…</p>
          </div>
        </div>
        <div id="app-update-phase-ready" hidden>
          <p class="app-update-kicker">Pronto</p>
          <h2>Atualização concluída</h2>
          <p class="app-update-ready-lead">A versão <strong>v${esc(ver)}</strong> foi baixada e está pronta.</p>
          <p class="app-update-hint">Precisamos reiniciar o SOMOSUM para aplicar. O app fecha, limpa arquivos temporários e reabre sozinho com as novidades.</p>
        </div>
        <div class="app-update-actions" id="app-update-actions">
          <button type="button" class="btn btn-primary" id="app-update-yes">Atualizar agora</button>
          <button type="button" class="btn btn-secondary" id="app-update-later">Depois</button>
          <button type="button" class="btn btn-ghost btn-sm" id="app-update-dismiss">Ignorar esta versão</button>
        </div>
      </div>`;
    document.body.appendChild(overlay);

    const phaseOffer = overlay.querySelector('#app-update-phase-offer');
    const phaseProgress = overlay.querySelector('#app-update-phase-progress');
    const phaseReady = overlay.querySelector('#app-update-phase-ready');
    const pctEl = overlay.querySelector('#app-update-pct');
    const statusEl = overlay.querySelector('#app-update-status');
    const actions = overlay.querySelector('#app-update-actions');
    const yesBtn = overlay.querySelector('#app-update-yes');
    const laterBtn = overlay.querySelector('#app-update-later');
    const dismissBtn = overlay.querySelector('#app-update-dismiss');

    const close = (result) => {
      overlay.remove();
      resolve(result);
    };

    const showReady = () => {
      phaseOffer.hidden = true;
      phaseProgress.hidden = true;
      phaseReady.hidden = false;
      actions.hidden = false;
      yesBtn.textContent = 'Reiniciar agora';
      yesBtn.dataset.phase = 'restart';
      laterBtn.hidden = true;
      dismissBtn.hidden = true;
    };

    laterBtn.addEventListener('click', () => {
      onLater?.();
      close('later');
    });
    dismissBtn.addEventListener('click', async () => {
      await dismissUpdateVersion(ver);
      onDismiss?.();
      close('dismiss');
    });
    yesBtn.addEventListener('click', async () => {
      if (yesBtn.dataset.phase === 'restart') {
        actions.hidden = true;
        phaseReady.hidden = true;
        phaseProgress.hidden = false;
        statusEl.textContent = 'Reiniciando e aplicando…';
        pctEl.style.width = '100%';
        try {
          await prepareAndRelaunchUpdate((phase) => {
            statusEl.textContent = phase === 'relaunch'
              ? 'Reabrindo o SOMOSUM…'
              : 'Aplicando e limpando arquivos temporários…';
          });
          statusEl.textContent = 'O SOMOSUM vai fechar e reabrir em instantes…';
          close('restarting');
        } catch (err) {
          statusEl.textContent = `Falha ao reiniciar: ${err.message || err}. Feche e abra o SOMOSUM.exe.`;
          actions.hidden = false;
          yesBtn.textContent = 'Tentar reiniciar de novo';
          yesBtn.dataset.phase = 'restart';
          phaseReady.hidden = false;
          phaseProgress.hidden = true;
        }
        return;
      }

      actions.hidden = true;
      phaseOffer.hidden = true;
      phaseProgress.hidden = false;
      const onProgress = (phase, pct) => {
        statusEl.textContent = phase === 'download'
          ? `Baixando… ${pct}%`
          : `Preparando arquivos… ${pct}%`;
        pctEl.style.width = `${Math.min(100, pct)}%`;
      };
      try {
        await downloadAndStageUpdate(latest, onProgress);
        showReady();
      } catch (err) {
        const raw = String(err?.message || err || '');
        let detail = raw;
        try {
          const j = JSON.parse(raw);
          if (j?.error) detail = String(j.error);
        } catch { /* texto simples */ }
        if (/path_not_allowed/i.test(detail)) {
          detail = 'O pacote antigo tinha arquivos que esta versão não aceita. Já republicamos a 8.8.10 — clique em Tentar de novo.';
        } else if (/hash_mismatch/i.test(detail)) {
          detail = 'O arquivo baixado não bateu com o canal. Clique em Tentar de novo (pode ser cache).';
        }
        phaseOffer.hidden = true;
        phaseProgress.hidden = false;
        statusEl.textContent = `Não deu para preparar: ${detail}`;
        actions.hidden = false;
        yesBtn.textContent = 'Tentar de novo';
        yesBtn.dataset.phase = '';
      }
    });
  });
}

export async function maybeCheckAppUpdate({ force = false } = {}) {
  if (_checking && !force) return null;
  if (!force) {
    try {
      if (sessionStorage.getItem('somosum.update.autoChecked') === '1') return null;
      sessionStorage.setItem('somosum.update.autoChecked', '1');
    } catch { /* ignore */ }
  }
  _checking = true;
  try {
    const result = await checkForAppUpdate();
    if (!result.available || !result.latest) return result;
    await showUpdateAvailableDialog(result.latest, {
      chainMeta: {
        channelTip: result.channelTip,
        stepsRemaining: result.stepsRemaining,
        chain: result.chain,
      },
    });
    return result;
  } catch {
    return null;
  } finally {
    _checking = false;
  }
}

export async function checkAppUpdateManual() {
  _checking = false;
  const result = await checkForAppUpdate({ includeDismissed: true });
  if (!result.available) {
    if (result.offline) {
      return { ok: true, message: 'Sem internet no momento. Conecte-se e tente de novo.' };
    }
    if (result.needsFullSetup && result.latest?.version) {
      if (result.needsPriorStep && result.blockedBy?.version) {
        return {
          ok: false,
          message: `Há atualizações até ${result.channelTip?.version || result.latest.version}, mas esta instalação (${result.localVersion}) precisa primeiro da ${result.blockedBy.minVersion || '?'} → ${result.blockedBy.version}. Aplique as atualizações em ordem (uma de cada vez).`,
        };
      }
      return {
        ok: false,
        message: `Há a versão ${result.latest.version}, mas esta instalação (${result.localVersion}) precisa do passo anterior (mínimo ${result.latest.minVersion || result.latest.version}) ou do instalador completo.`,
      };
    }
    const remote = result.latest?.version ? ` (canal: ${result.latest.version})` : '';
    return {
      ok: true,
      message: `Tudo certo — você já está com a versão mais nova (${result.localVersion})${remote}.`,
    };
  }
  await showUpdateAvailableDialog(result.latest, {
    chainMeta: {
      channelTip: result.channelTip,
      stepsRemaining: result.stepsRemaining,
      chain: result.chain,
    },
  });
  const tip = result.channelTip?.version;
  const stepNote = tip && tip !== result.latest.version
    ? ` (passo ${result.latest.version} → continue até ${tip})`
    : '';
  return { ok: true, message: `Nova versão ${result.latest.version} disponível${stepNote}.` };
}
