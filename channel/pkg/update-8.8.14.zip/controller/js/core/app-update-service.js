/**
 * Verificação e download de atualizações delta do app SOMOSUM.
 */
import { APP_VERSION } from './app-meta.js';
import { readResponseWithProgress } from '../worship/hinario-pack-unzip.js';
import { fetchCatalog } from './catalog-proxy-fetch.js';

let _channelConfig = null;

export function compareVersions(a, b) {
  const pa = String(a || '0').split('.').map((n) => parseInt(n, 10) || 0);
  const pb = String(b || '0').split('.').map((n) => parseInt(n, 10) || 0);
  const len = Math.max(pa.length, pb.length);
  for (let i = 0; i < len; i++) {
    const da = pa[i] || 0;
    const db = pb[i] || 0;
    if (da > db) return 1;
    if (da < db) return -1;
  }
  return 0;
}

export function isOnline() {
  return typeof navigator !== 'undefined' ? navigator.onLine !== false : true;
}

async function loadChannelConfig() {
  if (_channelConfig) return _channelConfig;
  try {
    const res = await fetch('/content/updates/channel.json', { cache: 'no-store' });
    if (res.ok) _channelConfig = await res.json();
  } catch { /* fallback */ }
  if (!_channelConfig) {
    _channelConfig = {
      owner: 'RabbitVisual',
      repo: 'somosum-updates',
      branch: 'main',
      latestUrl: 'https://cdn.jsdelivr.net/gh/RabbitVisual/somosum-updates@main/channel/latest.json',
    };
  }
  return _channelConfig;
}

export async function fetchLatestUpdate() {
  if (!isOnline()) return null;
  const cfg = await loadChannelConfig();
  const base = cfg.latestUrl
    || `https://cdn.jsdelivr.net/gh/${cfg.owner || 'RabbitVisual'}/${cfg.repo || 'somosum-updates'}@${cfg.branch || 'main'}/channel/latest.json`;
  const url = `${base}${base.includes('?') ? '&' : '?'}_=${Date.now()}`;
  const res = await fetchCatalog(url);
  if (!res.ok) throw new Error(`update_check_${res.status}`);
  return res.json();
}

/** Histórico de patches do canal — aplica de 1 em 1 até a ponta. */
export async function fetchUpdateHistory() {
  if (!isOnline()) return [];
  const cfg = await loadChannelConfig();
  const latestBase = cfg.latestUrl
    || `https://cdn.jsdelivr.net/gh/${cfg.owner || 'RabbitVisual'}/${cfg.repo || 'somosum-updates'}@${cfg.branch || 'main'}/channel/latest.json`;
  const historyBase = cfg.historyUrl
    || String(latestBase).replace(/latest\.json(\?.*)?$/i, 'history.json');
  try {
    const url = `${historyBase}${historyBase.includes('?') ? '&' : '?'}_=${Date.now()}`;
    const res = await fetchCatalog(url);
    if (!res.ok) return [];
    const data = await res.json();
    return Array.isArray(data?.versions) ? data.versions : [];
  } catch {
    return [];
  }
}

export async function getLocalUpdateState() {
  const res = await fetch('/api/app/update/info', { cache: 'no-store' });
  if (!res.ok) throw new Error('update_info_failed');
  return res.json();
}

export function isVersionDismissed(dismissedJson, version) {
  if (!dismissedJson || !version) return false;
  try {
    const d = typeof dismissedJson === 'string' ? JSON.parse(dismissedJson) : dismissedJson;
    return d && Object.prototype.hasOwnProperty.call(d, version);
  } catch {
    return false;
  }
}

function normalizeMinVersion(entry) {
  if (!entry) return null;
  let minReq = entry.minVersion || null;
  if (minReq && compareVersions(minReq, entry.version) >= 0) minReq = null;
  return minReq;
}

/**
 * Escolhe o PRÓXIMO passo aplicável (nunca salta para a ponta se faltar anterior).
 * @returns {{ available: boolean, next?: object, channelTip?: object, stepsRemaining?: number, needsPriorStep?: boolean, needsFullSetup?: boolean, blockedBy?: object }}
 */
export function pickNextUpdateStep(localVer, entries = []) {
  const byVer = new Map();
  for (const e of entries) {
    if (!e?.version || !e?.package?.url) continue;
    byVer.set(String(e.version), e);
  }
  const sorted = [...byVer.values()].sort((a, b) => compareVersions(a.version, b.version));
  const newer = sorted.filter((e) => compareVersions(e.version, localVer) > 0);
  if (!newer.length) return { available: false };

  const channelTip = newer[newer.length - 1];
  for (const step of newer) {
    const minReq = normalizeMinVersion(step);
    const minOk = !minReq || compareVersions(localVer, minReq) >= 0;
    if (minOk) {
      const remaining = newer.filter((e) => compareVersions(e.version, step.version) >= 0).length;
      return {
        available: true,
        next: { ...step, minVersion: minReq || step.minVersion || null },
        channelTip,
        stepsRemaining: remaining,
        chain: remaining > 1 || compareVersions(channelTip.version, step.version) > 0,
      };
    }
  }

  return {
    available: false,
    needsPriorStep: true,
    needsFullSetup: true,
    blockedBy: newer[0],
    channelTip,
  };
}

export async function checkForAppUpdate({ includeDismissed = false } = {}) {
  const local = await getLocalUpdateState();
  const localVer = local.version || APP_VERSION || window.SOMOSUM_VERSION || '0.0.0';
  let latest;
  try {
    latest = await fetchLatestUpdate();
  } catch {
    return { available: false, localVersion: localVer, offline: !isOnline() };
  }

  const history = await fetchUpdateHistory();
  const entries = [...history];
  if (latest?.version) {
    const idx = entries.findIndex((e) => e.version === latest.version);
    if (idx >= 0) {
      const histMin = entries[idx].minVersion;
      entries[idx] = { ...entries[idx], ...latest };
      // Cliente com history: preserva minVersion da escada (1 a 1).
      // latest.json pode ter min baixo só para destravar clientes antigos (sem history).
      if (histMin && (!latest.minVersion || compareVersions(histMin, latest.minVersion) > 0)) {
        entries[idx].minVersion = histMin;
      }
    } else {
      entries.push(latest);
    }
  }

  const pick = pickNextUpdateStep(localVer, entries);
  if (!pick.available) {
    if (pick.needsPriorStep && pick.blockedBy) {
      return {
        available: false,
        localVersion: localVer,
        latest: pick.channelTip || latest,
        needsFullSetup: true,
        needsPriorStep: true,
        blockedBy: pick.blockedBy,
        channelTip: pick.channelTip,
      };
    }
    return { available: false, localVersion: localVer, latest: pick.channelTip || latest };
  }

  const offer = pick.next;
  if (!includeDismissed && isVersionDismissed(local.dismissed, offer.version)) {
    return {
      available: false,
      localVersion: localVer,
      latest: offer,
      dismissed: true,
      channelTip: pick.channelTip,
    };
  }

  return {
    available: true,
    localVersion: localVer,
    latest: offer,
    channelTip: pick.channelTip,
    stepsRemaining: pick.stepsRemaining,
    chain: !!pick.chain,
  };
}

export async function downloadUpdatePackage(latest, onProgress) {
  const pkg = latest?.package;
  if (!pkg?.url) throw new Error('update_no_package');
  onProgress?.('download', 0);
  const res = await fetchCatalog(pkg.url);
  if (!res.ok) throw new Error(`update_download_${res.status}`);
  const bytes = await readResponseWithProgress(res, (pct) => onProgress?.('download', pct));
  return { bytes, sha256: pkg.sha256, file: pkg.file };
}

export async function stageUpdatePackage({ bytes, sha256 }, onProgress) {
  onProgress?.('stage', 10);
  const qs = sha256 ? `?sha256=${encodeURIComponent(sha256)}` : '';
  const res = await fetch(`/api/app/update/stage-bytes${qs}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/octet-stream' },
    body: bytes,
  });
  const t = await res.text().catch(() => '');
  if (!res.ok) {
    throw new Error(t || 'update_stage_failed');
  }
  onProgress?.('stage', 100);
  try {
    return t ? JSON.parse(t) : {};
  } catch {
    return { ok: true };
  }
}

/** Baixa e prepara o pacote — sem reiniciar. */
export async function downloadAndStageUpdate(latest, onProgress) {
  const { bytes, sha256 } = await downloadUpdatePackage(latest, onProgress);
  return stageUpdatePackage({ bytes, sha256 }, onProgress);
}

export async function prepareAndRelaunchUpdate(onProgress) {
  onProgress?.('prepare', 95);
  const prep = await fetch('/api/app/update/prepare', { method: 'POST' });
  if (!prep.ok) throw new Error('update_prepare_failed');
  try {
    await fetch('/api/app/update/cleanup-temp', { method: 'POST' }).catch(() => {});
  } catch { /* optional */ }
  onProgress?.('relaunch', 100);
  if (window.Engine?.shell?.relaunchForUpdate) {
    window.Engine.shell.relaunchForUpdate();
    return { relaunch: true };
  }
  throw new Error('update_relaunch_unavailable');
}

/** @deprecated prefer downloadAndStageUpdate + confirmação + prepareAndRelaunchUpdate */
export async function runAppUpdateFlow(latest, onProgress) {
  await downloadAndStageUpdate(latest, onProgress);
  return prepareAndRelaunchUpdate(onProgress);
}

export async function dismissUpdateVersion(version) {
  await fetch('/api/app/update/dismiss', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ version }),
  });
}

export async function fetchWhatsNew() {
  const local = await getLocalUpdateState();
  if (!local.whatsNew) return null;
  try {
    const doc = typeof local.whatsNew === 'string' ? JSON.parse(local.whatsNew) : local.whatsNew;
    if (doc.shown === true || doc.shown === 'true') return null;
    // Garante body string (evita [object Object] se JSON veio corrompido)
    if (doc && typeof doc.body !== 'string' && doc.body != null) {
      const { coerceNotesBody } = await import('./release-notes-format.js');
      doc.body = coerceNotesBody(doc.body);
    }
    return doc;
  } catch {
    return null;
  }
}

export async function markWhatsNewShown() {
  await fetch('/api/app/update/whats-new-shown', { method: 'POST' });
}

/** @deprecated use release-notes-format.js — reexport para compat. */
export { extractUpdateHighlights } from './release-notes-format.js';
