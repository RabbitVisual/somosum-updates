/**
 * Aplica atualização delta pendente na inicialização (trampolim).
 * Compilado apenas com csc (.NET Framework) — ver compile-launcher.ps1.
 */
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Web.Script.Serialization;

namespace SomosumRootLauncher
{
    internal static class AppUpdateApplyStandalone
    {
        private static readonly string[] AllowedPrefixes =
        {
            "controller/", "view/", "model/content/", "model/storage/",
            "system/media/index.json", "system/media/LEIA-ME.txt", "app/", "docs/",
        };

        private static readonly HashSet<string> AllowedExact = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
        {
            "VERSION", "build-manifest.json", "LEIA-ME.txt", "LEIA-ME-PRIMEIRO.txt",
            "README.md", "SOMOSUM.exe",
        };

        public static bool TryApply(string appRoot, out string error)
        {
            error = null;
            var dataDir = Path.Combine(appRoot, "model", "data");
            var pendingPath = Path.Combine(dataDir, ".pending-update.json");
            if (!File.Exists(pendingPath)) return true;

            try
            {
                var ser = new JavaScriptSerializer { MaxJsonLength = int.MaxValue };
                var pending = ser.Deserialize<Dictionary<string, object>>(File.ReadAllText(pendingPath));
                var stagingDir = pending != null && pending.ContainsKey("stagingDir")
                    ? Convert.ToString(pending["stagingDir"])
                    : null;
                if (string.IsNullOrWhiteSpace(stagingDir) || !Directory.Exists(stagingDir))
                {
                    File.Delete(pendingPath);
                    error = "staging_missing";
                    return false;
                }

                var manifestPath = Path.Combine(stagingDir, "update-manifest.json");
                if (!File.Exists(manifestPath))
                {
                    File.Delete(pendingPath);
                    error = "manifest_missing";
                    return false;
                }

                var manifest = ser.Deserialize<Dictionary<string, object>>(File.ReadAllText(manifestPath));
                var toVer = manifest != null && manifest.ContainsKey("to") ? Convert.ToString(manifest["to"]) : null;

                var copied = 0;
                var missing = 0;
                if (manifest != null && manifest.ContainsKey("replace"))
                {
                    foreach (var relObj in AsStringList(manifest["replace"]))
                    {
                        var rel = Normalize(relObj);
                        if (string.IsNullOrEmpty(rel) || !IsAllowed(rel)) continue;
                        var src = Path.Combine(stagingDir, rel.Replace('/', Path.DirectorySeparatorChar));
                        var dst = Path.Combine(appRoot, rel.Replace('/', Path.DirectorySeparatorChar));
                        if (!File.Exists(src))
                        {
                            missing++;
                            continue;
                        }
                        if (!IsUnderRoot(dst, appRoot)) continue;
                        var dstDir = Path.GetDirectoryName(dst);
                        if (!string.IsNullOrEmpty(dstDir)) Directory.CreateDirectory(dstDir);
                        File.Copy(src, dst, true);
                        copied++;
                    }
                }

                if (missing > 0 && copied == 0)
                {
                    return false;
                }

                if (manifest != null && manifest.ContainsKey("delete"))
                {
                    foreach (var relObj in AsStringList(manifest["delete"]))
                    {
                        var rel = Normalize(relObj);
                        if (string.IsNullOrEmpty(rel) || !IsAllowed(rel)) continue;
                        var dst = Path.Combine(appRoot, rel.Replace('/', Path.DirectorySeparatorChar));
                        if (IsUnderRoot(dst, appRoot) && File.Exists(dst)) File.Delete(dst);
                    }
                }

                if (!string.IsNullOrWhiteSpace(toVer))
                {
                    File.WriteAllText(Path.Combine(appRoot, "VERSION"), toVer.Trim() + Environment.NewLine, Encoding.UTF8);
                }

                var notesPath = Path.Combine(stagingDir, "notes", toVer + ".md");
                var notesBody = File.Exists(notesPath)
                    ? File.ReadAllText(notesPath, Encoding.UTF8)
                    : "Atualizacao para v" + toVer;
                var whatsNew = ser.Serialize(new Dictionary<string, object>
                {
                    { "version", toVer },
                    { "shown", false },
                    { "body", notesBody },
                    { "appliedAt", (long)(DateTime.UtcNow - new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc)).TotalMilliseconds },
                });
                File.WriteAllText(Path.Combine(dataDir, ".whats-new.json"), whatsNew, Encoding.UTF8);

                try { Directory.Delete(stagingDir, true); } catch { }
                try { Directory.Delete(Path.Combine(dataDir, ".update-staging"), true); } catch { }
                File.Delete(pendingPath);
                CleanupTempCaches(appRoot, dataDir);
                return true;
            }
            catch (Exception ex)
            {
                error = ex.Message;
                return false;
            }
        }

        private static void CleanupTempCaches(string appRoot, string dataDir)
        {
            try
            {
                if (Directory.Exists(dataDir))
                {
                    foreach (var f in Directory.GetFiles(dataDir, ".update-*.tmp"))
                    {
                        try { File.Delete(f); } catch { }
                    }
                    foreach (var f in Directory.GetFiles(dataDir, "*.update-part"))
                    {
                        try { File.Delete(f); } catch { }
                    }
                }
            }
            catch { /* ignore */ }

            try
            {
                var temp = Path.GetTempPath();
                foreach (var path in Directory.GetDirectories(temp, "somosum-*"))
                {
                    var name = Path.GetFileName(path) ?? "";
                    if (name.StartsWith("somosum-relaunch-", StringComparison.OrdinalIgnoreCase)) continue;
                    try { Directory.Delete(path, true); } catch { }
                }
                foreach (var f in Directory.GetFiles(temp, "somosum-update*"))
                {
                    try { File.Delete(f); } catch { }
                }
            }
            catch { /* ignore */ }
        }

        private static IEnumerable<string> AsStringList(object raw)
        {
            if (raw == null) yield break;
            var arr = raw as object[];
            if (arr != null)
            {
                foreach (var o in arr) yield return Convert.ToString(o);
                yield break;
            }
            var list = raw as ArrayList;
            if (list != null)
            {
                foreach (var o in list) yield return Convert.ToString(o);
            }
        }

        private static string Normalize(string p)
        {
            if (string.IsNullOrWhiteSpace(p)) return null;
            return p.Replace('\\', '/').Trim().TrimStart('/');
        }

        private static bool IsAllowed(string rel)
        {
            if (rel.Contains("..") || rel.StartsWith("model/data/", StringComparison.OrdinalIgnoreCase)) return false;
            if (AllowedExact.Contains(rel)) return true;
            return AllowedPrefixes.Any(pre =>
                rel.Equals(pre, StringComparison.OrdinalIgnoreCase)
                || rel.StartsWith(pre, StringComparison.OrdinalIgnoreCase));
        }

        private static bool IsUnderRoot(string full, string root)
        {
            try
            {
                var r = Path.GetFullPath(root).TrimEnd('\\', '/') + Path.DirectorySeparatorChar;
                return Path.GetFullPath(full).StartsWith(r, StringComparison.OrdinalIgnoreCase);
            }
            catch { return false; }
        }
    }
}
