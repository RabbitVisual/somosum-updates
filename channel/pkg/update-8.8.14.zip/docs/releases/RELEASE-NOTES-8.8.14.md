# Release Notes — SOMOSUM 8.8.14

**Data:** 2026-08-19  
**Tipo:** correção do canal de atualização

## Destaques

- A **8.8.10** (e os passos seguintes) voltou a aplicar no PC que está em 8.8.9 — o pacote antigo tinha arquivos que o instalador recusava depois do download.
- Se algo falhar, a tela **permanece na preparação** com a causa, em vez de voltar às notas com só “Tentar de novo”.

## Como atualizar
1. Se estiver em **8.8.9**: Ajuda → Verificar atualização → **8.8.10** → **Tentar de novo** (pacote já republicado) → confirme o reinício.
2. Depois suba de 1 em 1 até **8.8.14**.

## Verificação rápida
- [ ] Sobre = **8.8.14** (após a cadeia)
- [ ] Quem estava preso na 8.8.10 consegue aplicar e reiniciar
