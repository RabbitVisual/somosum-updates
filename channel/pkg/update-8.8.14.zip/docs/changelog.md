# Changelog — SOMOSUM

Histórico oficial de versões. Versão canônica: arquivo `VERSION` na raiz (sincronizada com Painel, instalador e `app-meta.js`).

## 8.8.14 — 2026-08-19

**Canal de atualização: 8.8.10 volta a aplicar**

- Pacotes 8.8.10–8.8.13 republicados sem arquivos que o cliente 8.8.9 recusava.
- Requer **8.8.13** na escada (quem está em 8.8.9 aplica 8.8.10 republicada primeiro).

Notas: [`releases/RELEASE-NOTES-8.8.14.md`](releases/RELEASE-NOTES-8.8.14.md).

## 8.8.13 — 2026-08-19

**Padrão de fábrica deste PC + Púlpito/Remote sem flicker**

- Restaura qualidade e projeção pelo perfil do computador, sem apagar dados da igreja.
- Stage/Remote sincronizam sem redesenhar a tela a cada pulso.
- Requer **8.8.12** na escada.

Notas: [`releases/RELEASE-NOTES-8.8.13.md`](releases/RELEASE-NOTES-8.8.13.md).

## 8.8.12 — 2026-08-19

**Modo LAN desliga de verdade**

- Desativar grava no engine, fecha bind público e não volta ao sair da aba.
- Requer **8.8.11** na escada.

Notas: [`releases/RELEASE-NOTES-8.8.12.md`](releases/RELEASE-NOTES-8.8.12.md).

## 8.8.11 — 2026-08-19

**Pacote consolidado (culto + projeção + HDMI/VGA nativo)**

- Reúne no delta o código de culto, letras e projetor já corrigido, mais o EXE com identificação EDID.
- Requer **8.8.10** na escada.

Notas: [`releases/RELEASE-NOTES-8.8.11.md`](releases/RELEASE-NOTES-8.8.11.md).

## 8.8.10 — 2026-08-19

**HDMI/VGA nativo (EDID) + resolução verdadeira do projetor**

- Identifica cabo (HDMI, VGA, DVI, DP) e modo nativo do aparelho; não usa 1080p falso da GPU.
- Ao abrir Projeção: escolhe a tela do projetor e aplica resolução/Hz nativos.
- Requer **8.8.9** na escada.

Notas: [`releases/RELEASE-NOTES-8.8.10.md`](releases/RELEASE-NOTES-8.8.10.md).

## 8.8.9 — 2026-08-19

**Projeção tela cheia (qualquer projetor) + ordem do culto**

- Ao abrir: identifica o monitor, preenche a tela nativa, sem faixa preta; vídeo/fundo em cover; texto com margem mínima; contraste automático.
- Inspetor: leitura responsiva/interlinear, teleprompter da mensagem, comunicados, ceia, introito, PPTX, Ao vivo nos demais tipos.
- Requer **8.8.8** na escada.

Notas: [`releases/RELEASE-NOTES-8.8.9.md`](releases/RELEASE-NOTES-8.8.9.md).

## 8.8.8 — 2026-08-12

**Letras para culto (busca/salvar/projetar) + wizard + Pré-culto**

- Estrofes preservadas na importação; divisão 2/4/6 ao salvar; projeção sem soft-wrap que parte frases.
- Wizard: Participação/filtro de louvor corrigidos; biblioteca manda ao adicionar à ordem.
- Controle claro, Stage Pregador e Pré-culto limpo (sem Modelos).
- Requer **8.8.7** na escada.

Notas: [`releases/RELEASE-NOTES-8.8.8.md`](releases/RELEASE-NOTES-8.8.8.md).

## 8.8.7 — 2026-08-11

**Controle claro legível + Stage Pregador + polish Stage/Remote**

- Modo claro do Controle: botões e labels do operador legíveis (sem texto branco em fundo claro).
- Stage perfil Pregador: layout sem cortar elementos; rail oculto; conteúdo rola no painel ao vivo.
- Stage e Remote: tema claro/escuro mais profissional e coerente com o Painel.
- Requer **8.8.6** na escada.

Notas: [`releases/RELEASE-NOTES-8.8.7.md`](releases/RELEASE-NOTES-8.8.7.md).

## 8.8.6 — 2026-08-11

**Tela pós-atualização e changelog completos**

- Boas-vindas pós-update lista todas as seções e bullets; inclui changelog completo rolável.
- Sobre → O que há de novo: cards completos + changelog oficial da versão (sem texto genérico antigo).
- Notas gravadas em `content/updates/notes` no pacote para leitura estável no Sobre.
- Requer **8.8.5** na escada.

Notas: [`releases/RELEASE-NOTES-8.8.6.md`](releases/RELEASE-NOTES-8.8.6.md).

## 8.8.5 — 2026-08-11

**Projeção no culto + Contagem de abertura (pré-culto nativo) + plugins**

- Contagem de abertura inicia o pré-culto nativo (relógio real, segundos, Remote 5/3/1).
- Letras por linhas poéticas; fundo vídeo/imagem full-bleed; seção com subtítulo/texto.
- Pré-culto/Música mais acessíveis; visitantes com slide próprio; plugins sem falso “projetado”.
- Requer **8.8.4** na escada.

Notas: [`releases/RELEASE-NOTES-8.8.5.md`](releases/RELEASE-NOTES-8.8.5.md).

## 8.8.4 — 2026-08-08

**Correções de edição (inspetor) + plugins e Loja**

- Fundo não some ao mudar fonte/cor/tamanho (não volta mais ao gradiente do tema).
- Letras: cor de título/letra e legibilidade (efeito/escurecer/posição) passam a aplicar.
- Tamanho de fonte funciona em Oferta, Pausa/Contagem, Ceia e Participação; Participação respeita as cores.
- Boas-vindas ganhou seletor de fonte (família).
- Plugins: edição de texto no Studio reflete no projetor ao vivo quando o plugin está no ar; Loja atualiza menu/ajustes ao instalar/remover; "Abrir" vai direto ao Studio; sem falso "projetado" durante o pré-culto.
- Requer **8.8.3** na escada.

Notas: [`releases/RELEASE-NOTES-8.8.4.md`](releases/RELEASE-NOTES-8.8.4.md).

## 8.8.3 — 2026-08-04

**Hot-fix: vídeo de fundo no bem-vindo, cifra e cadeia de update desde 8.7**

- Bem-vindo: vídeo de fundo aplica e permanece na prévia/projetor; overlay legível com vídeo.
- Cifra: filtro mais permissivo + fallback HTML quando o Solr falha.
- Canal: history 8.7.9→8.8.3; tip libera 8.0+; clientes 8.8.1+ sobem 1 a 1.
- Requer **8.8.2** na escada (ou pacote tip para instalações antigas sem history).

Notas: [`releases/RELEASE-NOTES-8.8.3.md`](releases/RELEASE-NOTES-8.8.3.md).

## 8.8.2 — 2026-08-02

**Hot-fix: varredura de anomalias (projeção, louvores, rede, update)**

- LocalBridge FULL_STATE, screen payload null-safe, Stage Bounds fullscreen.
- forceSaveWorshipSong no inspetor/pacote; índice sem ready parcial; try/catch culto/cifra.
- Catalog proxy LAN; Genius configure local-only; imports backup/watchdog; apply update sem falso sucesso.
- Requer **8.8.1**.

Notas: [`releases/RELEASE-NOTES-8.8.2.md`](releases/RELEASE-NOTES-8.8.2.md).

## 8.8.1 — 2026-08-02

**Melhoria: buscador/cifra/lista de louvores + atualizações em cadeia**

- Busca de louvores/cifras mais coerente; proxy de letras na LAN; salvar mostra na lista.
- Canal com `history.json`: aplica patches de 1 em 1 (`minVersion` = anterior).
- Requer **8.8.0** antes de aplicar esta versão.

Notas: [`releases/RELEASE-NOTES-8.8.1.md`](releases/RELEASE-NOTES-8.8.1.md).

## 8.8.0 — 2026-08-02

**Melhoria: projeção profissional + pacote completo do canal**

- Ponte nativa Controle ↔ Projetor no EXE (sync local sem esperar rede).
- Identidade de tela (hash/DPI/modos), papéis na topbar e aviso de modo espelho.
- Vídeo de fundo sem remount ao trocar estrofe/tipo; cover + legibilidade no projetor.
- Delta amplo enxuto para quem já está em 8.7.18.

Notas: [`releases/RELEASE-NOTES-8.8.0.md`](releases/RELEASE-NOTES-8.8.0.md).

## 8.7.18 — 2026-07-30

**Hot-fix: legibilidade (sombra/contorno/placa + escurecer fundo) em todos os slides**

- Controles unificados no inspetor: Texto legível, Escurecer fundo, posição vertical.
- Cores no louvor e na mensagem; fundo na bíblia; ceia respeita cores do inspetor.
- Ajustes → Projeção: padrão global para texto sobre vídeo + intensidade do véu.

Notas: [`releases/RELEASE-NOTES-8.7.18.md`](releases/RELEASE-NOTES-8.7.18.md).

## 8.7.17 — 2026-07-30

**Hot-fix: cores/fonte/peso do inspetor em TODOS os slides no projetor**

- Bloco de autoridade CSS: Título/Texto/Ref. + Bold/ExtraBold em bíblia, oração, seção, anúncios, tema, participação, oferta, mensagem, louvor, etc.
- Paridade Controle ↔ Projetor; mensagem com cor de texto do inspetor.

Notas: [`releases/RELEASE-NOTES-8.7.17.md`](releases/RELEASE-NOTES-8.7.17.md).

## 8.7.16 — 2026-07-30

**Hot-fix: cor Título≠Ref. no projetor + Bold/ExtraBold**

- Introito/bíblia: texto principal usa cor de **Título** (não mais a de Ref.).
- Peso da fonte (Regular/Bold/ExtraBold/Italic) aplicado de verdade no projetor.

Notas: [`releases/RELEASE-NOTES-8.7.16.md`](releases/RELEASE-NOTES-8.7.16.md).

## 8.7.15 — 2026-07-30

**Hot-fix: tipografia/cores/posição ao vivo em todos os itens + fontes**

- Captura e sync ao vivo de estilo para oração, seção, anúncios, tema e demais tipos (não só Aplicar).
- Patch CSS no projetor (`applySlideStyleVars`); tetos CSS que engoliam o A+ removidos/aliviados.
- Pastas `view/fonts`, `view/FONTE` (e `fonte`): descoberta automática + Recarregar fontes + sync para o projetor.

Notas: [`releases/RELEASE-NOTES-8.7.15.md`](releases/RELEASE-NOTES-8.7.15.md).

## 8.7.14 — 2026-07-29

**Hot-fix: brilho do vídeo de fundo no projetor = espelho do Controle**

- Removida lavagem preta (`::before`) exclusiva do projetor sobre o vídeo.
- Overlay mínimo com vídeo; legibilidade por sombra no texto.
- Preferências antigas de “gradiente/escuro” não escurecem mais o fundo em loop.

Notas: [`releases/RELEASE-NOTES-8.7.14.md`](releases/RELEASE-NOTES-8.7.14.md).

## 8.7.13 — 2026-07-29

**Hot-fix: vídeo de fundo, tipografia ao vivo e projeção estável**

- **Fundos:** restauração automática de `system/media` a partir dos packs locais; overlays mais leves; legibilidade por sombra com vídeo.
- **Tipografia ao vivo:** fonte/tamanho/margens no inspetor atualizam o projetor sem reiniciar o vídeo (padrão Holyrics).
- **Projeção:** mesmo fundo em loop ao trocar versos; fingerprint completo de margens/estilo.

Notas: [`releases/RELEASE-NOTES-8.7.13.md`](releases/RELEASE-NOTES-8.7.13.md).

## 8.7.12 — 2026-07-29

**Rede LAN comprovada, projeção local nativa e catálogo packs-8.7.11**

- **NetworkGuarantee:** QR público só após firewall + bind AnyIP + probe HTTP no IP Wi‑Fi (Win10/Win11).
- **Hub Rede:** estados claros até **LAN pronta**; sem IP no QR enquanto o tablet não conseguir acessar.
- **LocalBridge:** sync Controle→Projetor no mesmo EXE com latência mínima; DPI/fullscreen reforçados.
- **Catálogo:** release `packs-8.7.11` no GitHub (fim do 404 do plugins-manifest).

Notas: [`releases/RELEASE-NOTES-8.7.12.md`](releases/RELEASE-NOTES-8.7.12.md).

## 8.7.11 — 2026-07-29

**MIDI e PowerPoint nativos no menu Ferramentas**

- **PowerPoint:** importação `.pptx` (OOXML) sem Office → item Apresentação multi-slide na ordem; ← → no Ao vivo.
- **MIDI:** Web MIDI com Learn, mapeamento nota/CC, prefs persistidas; ações next/prev/blank/logo/clear.
- **UI:** removido “Em breve”; badge de hint no tema escuro.

Notas: [`releases/RELEASE-NOTES-8.7.11.md`](releases/RELEASE-NOTES-8.7.11.md).

## 8.7.10 — 2026-07-29

**Ajuda → Verificar atualização, checagem automática na abertura, endurecimento de segurança do canal delta**

- **Ajuda:** item **Verificar atualização** no menu do Controle.
- **Boot:** Painel e Controle procuram novidades uma vez por sessão e oferecem o update.
- **Segurança:** POST `/api/app/update/*` só em loopback; sha256 obrigatório; pasta `to` sanitizada; validação de `delete[]`.
- **Apply:** pendente também aplicado na subida do Kestrel (além do trampolim).
- **UX:** reinício com atraso maior; notesPath restrito a `notes/<semver>.md`.
- **Correção:** export `GROUPS` no Painel (mapa Sobre).

Notas: [`releases/RELEASE-NOTES-8.7.10.md`](releases/RELEASE-NOTES-8.7.10.md).

## 8.7.9 — 2026-07-29

**Fontes reais, tipografia na projeção, atualização com reinício guiado, Painel Sobre ao vivo e Tour v11**

- **Fontes:** pastas por família; seletor família + estilo; peso/estilo reais na projeção.
- **Tamanhos:** A+/A− do inspetor mandam no projetor (sem tetos CSS engolindo o tamanho).
- **Sync:** perfil WebView2 da projeção isolado; push reforçado ao Aplicar tipografia/FX.
- **Atualização:** confirma reinício → limpa temp → reabre sozinho → boas-vindas com o que mudou.
- **Painel → Sobre:** versão ao vivo, cards de novidades a partir das release notes, mapa clicável das 10 seções (Início, Telas, Loja, Rede, Operação, Monitores, Desempenho, Dados, Igreja, Sobre).
- **Tour v11:** linguagem clara para o operador, cartão mais leve, passos consolidados; tecla **?**.
- **Docs:** guia do operador, funcionamento atual, atualização, INDEX, LEIA-ME e README alinhados à 8.7.9.

Notas: [`releases/RELEASE-NOTES-8.7.9.md`](releases/RELEASE-NOTES-8.7.9.md).

## 8.7.8 — 2026-07-25 (atualizado 2026-07-28)

**Letras profissionais, layout MVC, Púlpito no Controle, Tour v10 e docs alinhados**

- **Layout MVC:** `model/` · `view/` · `controller/`; URLs estáveis via `ContentLayout`; `validate-mvc-layout.ps1`.
- **Púlpito:** Central Stage → monitor + tela cheia + CTA Pregador; URL nativa `?layout=preacher`.
- **Tour v10:** guia didático PT-BR com ilustrações; tecla **?**; docs tecla **D**.
- **Docs:** guia do operador, estrutura MVC, catálogo do portal; links `GUIA-DE-*` corrigidos.
- **Busca de letras (nível Cifra):** Solr Letras com ranking título/artista; formatação preserva `<br>`/`<p>` e refrões.
- **WebSocket `/ws/sync`:** reconexão sem corrida CONNECTING / spam no console.
- **Logs:** console WARN+; `scripts/cleanup-logs.ps1`; `/api/log` 204.
- **pt-BR:** shells HTML e textos de erro em português brasileiro.
- **Projeção full-screen:** bounds exatos do monitor (PerMonitorV2).
- **Remote Pro:** pré-culto, Bíblia ao vivo, aparência, dual-path sync.

Notas: [`releases/RELEASE-NOTES-8.7.8.md`](releases/RELEASE-NOTES-8.7.8.md).

## 8.7.7 — 2026-07-24

**Plugins API 2, Plugin Studio, Painel rebrand, chrome global e docs vivos**

- **PluginHost hardened (API 2):** lifecycle `activate` / `deactivate` por superfície; hook legado `boot` removido; capabilities estritas; quarantine + `lastError` no hub; timeout no activate.
- **Plugin Studio:** páginas dedicadas no Controle (`js/plugins/studio/*`); grupo **Plugins** na sidebar quando enabled; prévia local 16:9; pacote `culto-*` **v2.2.0**.
- **Control Center:** catálogo em Ajustes → Plugins — enable/disable, Como usar, Abrir Studio, Reativar, Instalar ZIP.
- **Painel Gerencial rebrand:** home amigável, rail 9 seções, CTAs Controle/Projeção/Remote, tokens compartilhados com o Controle, guia “Primeiros passos”.
- **Tema chrome claro/escuro:** preferência global `prefs.ui.chromeTheme` (`dark` | `light`) em Painel, Controle, Stage chrome e Remote — **sem** alterar atmosferas da projeção.
- **Tour v8:** onboarding com Plugins, Control Center, Studio e Painel; finish → view live.
- **Docs PT-BR 8.7.7:** guias, glossário, release notes; banner histórico em `PRODUCTION-RELEASE-8.0.0`.

Notas: [`releases/RELEASE-NOTES-8.7.7.md`](releases/RELEASE-NOTES-8.7.7.md).

## 8.7.0 — 2026-07-21

**Pacote completo de plugins de culto (produção)**

- Auditoria e hardening do PluginEngine (`runHookSync`, comandos Remote, reload em Ajustes).
- Plugins: Culto Essencial, Oferta PIX, Diário, Momentos, Avisos rodapé, **Timer do sermão**, **Versículo em destaque**, **Alerta à equipe**.
- Gate `test-u2-plugins` atualizado para o pacote real.

## 8.6.7 — 2026-07-21

**Plugins profissionais de culto**

- **Oferta PIX** — chave + QR no slide de oferta (configurável no Controle / Remote).
- **Diário do culto** — registra o que foi projetado; painel, export JSON e Remote.
- **Momentos** — Oração / Louvor / Palavra / Ceia / Avisos em 1 toque no Remote.
- **Avisos no rodapé** — frases rotativas no projetor (editáveis).
- Registro central de comandos de plugin (`plugin-prefs`) para o Remote funcionar de ponta a ponta.

## 8.6.6 — 2026-07-21

**Plugins — Culto Essencial em todo o sistema**

- Novo pacote `culto-essencial`: carimbo da igreja no projetor, checklist pré-culto, atalhos no Remote e layouts no Púlpito.
- PluginEngine: preload + `runHookSync` para o carimbo aparecer de fato no HTML; load em Controle, Projeção, Stage e Remote.
- Comandos Remote: emergência, checklist, carimbo on/off, ir à mensagem/oferta.

## 8.6.5 — 2026-07-21

**Designer — sombra em moldura/card sem crash**

- Efeitos → sombra não chama mais `shadowBlur`/`shadowColor` em Group (Konva só tem isso em Shape).
- Aplica sombra com segurança no texto/imagem filhos; fim do spam `is not a function` no Controle.

## 8.6.4 — 2026-07-21

**Designer — título sem corte + Konva/projetor alinhados**

- Caixa de título (“Título do slide”) deixa de aparecer cortada: wrap largo por padrão, medição com piso por caracteres e heal após carregar fontes.
- Seleção no canvas reatualiza o painel Design (evita “Nenhum elemento selecionado” com Transformer visível).
- Projeção HTML: texto com altura automática e `overflow: visible` — compatível com o canvas Konva.

## 8.6.1 — 2026-07-21

**Designer — slides salvos, mídia nas molduras e vídeo**

- Nova aba **Salvos**: reabrir, editar, excluir, projetar e adicionar à ordem (ex.: slide «TESTE»).
- Mídia: `src` correto + arrastar para o canvas/moldura; vídeos entram na moldura com zoom/posição.
- Projeção HTML renderiza moldura com imagem ou vídeo animado.
- UX do Designer mais clara (PT-BR) e painéis menos apertados.

## 8.6.0 — 2026-07-21

**Pré-culto completo (PT-BR) + fontes em todo o sistema**

- Painel de pré-culto reorganizado em passos claros (tempo → visual → textos → som → avisos), 100% português — modelos em vez de “presets”.
- Cinco estilos de slide (clássico, minimalista, cinematográfico, central solene, identidade) + fundas animadas e **mídia personalizada** (vídeo/imagem).
- Modelos de fábrica ampliados; salvar/aplicar/prévia/excluir com fluxo compreensível.
- Fontes: pasta `fonts/` e `FONTE/` com nomes reais (Montserrat, Roboto…) + fontes do Windows no Designer, Inspetor e relógio do pré-culto — sincronizados com a projeção.
- Layout, fundo e fonte atualizam ao vivo no projetor quando a contagem está no ar.

## 8.5.1 — 2026-07-21

**Produção — bem-vindo alinhado + perfis de projetor inteligentes**

- Removido o traço decorativo ao lado do tema (“SOMOS UM”) que desalinhava o texto no bem-vindo.
- Perfis de projetor amplos e automáticos por **resolução nativa** (SVGA, XGA, HD, WXGA, FHD, WUXGA, QHD, 4K, TV, LED, ultrawide) — marcas (Epson, BenQ, Optoma, etc.) só ajudam a detectar projetor; **não** forçam SVGA em todo Epson.
- Testes de match de perfil; gates de display/sync OK.
- Build de produção pronta para culto.

## 8.5.0 — 2026-07-21

**Display & Presentation Core 1.0** (Projetor.md + FreeShow/Holyrics)

- Identidade estável de display (`displayId`, fabricante/modelo), DEVMODE real e hierarquia de modo nativo (nunca preferir 1080p em projetor SVGA/720p).
- Ao abrir a projeção no secundário: **resolução nativa** via `ChangeDisplaySettingsEx` (desligável em Ajustes); restaura ao fechar.
- Perfis persistentes por projetor (modo, safeArea, colorPolicy, role) + restore no hotplug.
- Camadas Background ≠ Content ≠ Overlay: blank/logo **não** mata o vídeo; watchdog revive fundos em todos os slides.
- Commit atômico de SLIDE com `revision`/`seq`; FULL_STATE imediato após HDMI/VGA; Output Health Monitor.
- Política de cor (padrão/quente/vívido/alto contraste) para legibilidade — não ICC Photoshop.
- Epson S18+ / SVGA continua com perfil dedicado; preferir nativo 800×600 no Windows quando a opção estiver ligada.

## 8.4.0 — 2026-07-21

**Projeção — Epson PowerLite S18+ (SVGA) e outros projetores**

- Novo perfil **SVGA 800×600 — Epson / PowerLite** (auto-match por nome Epson/PowerLite/S18 ou resolução ≤850px); 4:3 genérico volta a usar `projector_4x3`.
- Tipografia e safe area pensadas para 600p (`maxLegibility`, fontBoost ~1.3); CSS `[data-aspect=4x3]` / `[data-dpe-profile=svga]` com pisos maiores no bem-vindo, letras e bíblia.
- Vídeo de fundo do bem-vindo: normaliza `background.src`, overlay de letras não escurece o welcome, `object-fit: cover`, play com retry (evita tela preta).
- Ajustes → seletor de perfil inclui SVGA. Preferir resolução nativa 800×600 no Windows quando o projetor for o S18+.

## 8.3.9 — 2026-07-21

**Projeção — tipografia do inspetor (louvor) sincroniza 100%**

- Ao mudar tamanho/fonte/caixa/alinhamento/FX e clicar **Aplicar**, a tela recebe o slide na hora (mesmo com patch de fundo persistente).
- CSS vars `--lyrics-*` atualizam no patch (não ficam “presas” no primeiro render).
- Display Projection Engine usa o `fontSize` do slide (não só o global).
- Fingerprint da tela inclui tipografia/FX (não descarta push só de estilo).

## 8.3.8 — 2026-07-21

**Designer — move/resize trava + perde seleção + stack overflow**

- Cliques nos handles/área do Transformer não re-selecionam o handle (isso gerava recursão infinita e limpava a seleção).
- Arraste da moldura inicia antes de anexar o Transformer.
- Após resize, só `forceUpdate` — sem `selectNode` de novo no `transformend`.

## 8.3.7 — 2026-07-21

**Designer — tamanho fantasma da seleção (moldura/linha/imagem)**

- Caixa do Transformer usa o tamanho lógico da moldura (clip), não a foto “cover” que ultrapassa o recorte.
- Após redimensionar, bake de `scale` em linhas, imagens, formas e texto (evita caixa fantasma residual).
- Hit da moldura sem interceptar cliques fora do conteúdo; `ignoreStroke` no Transformer.

## 8.3.6 — 2026-07-20

**Designer — texto empilhado + stack overflow + edição inline**

- Mede largura do texto sem wrap ativo (evita “CBAV” → C/B/A/V).
- `wrap: none` no modo “Ajustar ao texto”; largura mínima na caixa fixa / resize / import.
- `selectNode` não lê `transformer.nodes()` (quebra recursão no Konva Transformer).
- `endInlineTextEdit` remove o textarea só se ainda estiver no DOM (blur/Enter).

## 8.3.5 — 2026-07-20

**Designer — corrige Maximum call stack size exceeded**

- Remove rebind de drag da moldura a cada tick de props (loop infinito).
- `selectNode` com guarda de reentrada; restack sem reindexar todo o conteúdo.

## 8.3.4 — 2026-07-20

**Designer — molduras arrastáveis + foto/borda**

- Arraste da moldura não é mais cancelado pelo stage (Transformer).
- Após borda/foto, o hit de arraste é reativado; picker de imagem reutilizável.

## 8.3.3 — 2026-07-20

**Designer — Caixa de texto fixa/ajustável**

- “Caixa fixa” restaura a largura anterior após “Ajustar ao texto” (antes só mudava o modo e parecia não funcionar).

## 8.3.2 — 2026-07-20

**Designer — espaçamento de texto**

- Controles claros: **Letras <>** (espaço entre caracteres) e **Linhas ↕** (espaço vertical).
- Botões −/+ + slider; Enter no conteúdo cria linhas abaixo.

## 8.3.1 — 2026-07-20

**Designer — seleção e sliders**

- Clique no texto/forma seleciona de novo (dim abaixo do conteúdo; seleção no pointerdown).
- Sliders (escurecer / arredondar) não remountam o painel a cada tick — arraste contínuo funciona.
- Abas Posição / Efeitos desabilitadas sem seleção (só fazem sentido com elemento ativo).

## 8.3.0 — 2026-07-20

**Designer Konva completo — Ordem ↔ Programas ↔ projeção**

- Runtime Konva alinhado a **10.3.0**.
- Botão **Designer** para welcome / Bíblia / introito / custom; wizard com “Editar no Designer”.
- `loadFromItem` re-injeta Bíblia/welcome/foto; botão **Atualizar conteúdo**.
- Fundo animado (vídeo HTML sob o stage) no editor e em `renderCustom` na projeção.
- UI: trilho Elementos → Camadas → Mídia → Fundo → Modelos; feedback **Salvo na Ordem**.

## 8.2.9 — 2026-07-20

**Designer — anti-flicker nos sliders Konva**

- Arredondamento e demais sliders não recriam mais o painel a cada tick (perda de clique / piscar).
- Borda da moldura atualiza in-place no radius; persist/layers com debounce.

## 8.2.8 — 2026-07-20

**Designer — upgrade completo (molduras, props, projeção)**

- Borda da moldura segue a forma (círculo, estrela, hexágono…) — não só retângulo tracejado.
- Traçado: cor, espessura, sólido/tracejado; SVG na projeção.
- Foto na moldura: layout correto na tela (naturalW/H); modo “Reposicionar foto”; slot `photo`.
- Posição W/H redimensiona moldura de verdade; rename usa `displayName` (não quebra o tipo).
- Imagem: trocar arquivo; sombra com cor/offset; grupos com rotação/escala na projeção.

## 8.2.7 — 2026-07-20

**Designer — Molduras (seleção + props)**

- Clique em moldura (retrato/circular/etc.) seleciona de verdade e abre Design: foto, forma, borda/traçado, zoom.
- Hit-area confiável no Konva (clique não “atravessa” para o fundo).
- Após redimensionar, a moldura deixa de ficar “desorientada” (scale bake → width/height + clip).

## 8.2.6 — 2026-07-20

**Designer — Canva Pro (ponta a ponta)**

- Cache-bust 8.2.6: painel Design/Posição/Efeitos visível após reload (fix CSS do ciclo anterior).
- `fitAllTextBoxes` após carregar preset/slide + fontes — caixa da referência justa sem clicar “Ajustar”.
- Edição inline (duplo-clique no texto); line-height e contorno de texto (export + projeção).
- Copiar/colar estilo (Ctrl+Shift+C/V); Ctrl+C/V elementos; colar texto/imagem do clipboard do SO.
- Aviso visual vermelho ao sair da margem de segurança; renomear camada (duplo-clique); flip/rotação na quickbar.
- Duplicar slide nas tabs; presets quote sem `W-320` residual.

## 8.2.5 — 2026-07-20

**Designer — Canva completo (V8.2+)**

- Painel Design/Posição/Efeitos visível de novo (bug CSS: host `#designer-props` colidia com `display:none` das abas).
- Caixas de texto profissionais: presets com largura justa (referência/labels) vs wrap na área segura (versículo); “Ajustar ao texto” / caixa fixa.
- Margem de segurança com **bloqueio** ao salvar modelo, salvar na Ordem ou projetar — alerta + opção de encaixar automaticamente.
- Clique direito Canva: duplicar, excluir, lock, z-order, espelhar, rotação ±90°, ajustar texto, alinhar.
- Espelhar H/V + inverter; export/projeção com `scaleX`/`scaleY` negativos.
- Duplo-clique em texto foca o campo de conteúdo no painel.

**Temas litúrgicos na projeção (sem recolorir o Controle)**

- Atmosferas litúrgicas (Ceia, EBD, Celebração, Oração, Missões, Jovens, Adolescentes, Crianças, Mulheres, etc.) só na **Screen + prévia 16:9**.
- Controle / Painel / Stage chrome permanecem **Dark Studio** — fim do conflito `--color-*` vs `data-theme`.
- SSOT: `js/ui/theme/atmospheres.js` + `atmosphereId` nos packs de culto; Settings → “Tema da projeção”.
- Preferência `projectionTheme` (migra `theme` legado); Ceia no ar força atmosfera `ceia`.

**Ajustes — shell unificado (Dark Studio)**

- Rail com ícones, intro por aba e chip **Ao vivo / Aplicado**; preferências em tempo real.
- Conteúdo reorganizado: Igreja = identidade; Projeção = atmosfera + monitores; Sistema = escala do operador.
- CSS `settings-shell.css` alinhado ao Programa — sem misturar chrome e projeção.

**Designer — design uma vez, editar conteúdo na Ordem**

- Slots (`reference`, `verse`, `years`, `theme`, `photo`, `logo`…): layout Konva permanece ao mudar versículo/campos no inspetor.
- Salvar Introito/Bíblia/Welcome do Designer cria item tipado + `data.designer` (skin).
- Correção Bem-vindo comprimido: projeção de camadas sempre no frame 1920×1080.

## 8.2.4 — 2026-07-20

**Hotfix: Screen preta + “Projeção desconectada” falso**

- Slide/full_state/overlay enviados por **WS + HTTP** (mesmo id) — WebView2 da projeção não fica sem mensagem.
- Screen mantém **poll HTTP rápido** mesmo com WS up (antes caía para 5–10s e a tela ficava preta).
- Footer sincroniza com o badge (não mais “conectado” no topo e “desconectado” embaixo).
- Bíblia e slides complexos forçam DOM na hora do paint.
- Worker de pré-render (`slide-prep-worker`) não gera mais HTML vazio para Bíblia (só lyrics/blank/theme).

**UI — formulários unificados (Painel + Controle)**

- Novo `css/design-system/forms.css`: input, select, busca, choice cards e cartões de seção com o mesmo padrão (insp-card / settings / panel).
- Ajustes do Controle e Recursos/Igreja/Monitores do Painel alinhados — sem disparidade de select/pesquisa/radio.

## 8.2.3 — 2026-07-20

**Hotfix: projetor sem conteúdo (sync morto)**

- WebSocket “zumbi”: `push()` retornava OK sem enviar — agora valida `readyState` e cai no **HTTP** se falhar.
- Clique na ordem sempre chama `_pushSlideCore` (não depende do badge “conectado”).
- Limpa overlay Preta/Logo ao projetar item da ordem.
- Screen: libera countdown travado (>5s) e pinta FULL_STATE mesmo com stage vazio.
- Resync Screen: reforça push do slide durante culto ao vivo.

## 8.2.2 — 2026-07-20

**Hotfix estabilidade de projeção**

- Fim do **push duplo** (clique + debounce) que fazia slide aparecer e sumir / vídeo piscar.
- `forceDomProjection` **idempotente** — não thrasha DOM/canvas a cada SLIDE.
- FULL_STATE aplica **slide antes do overlay** (evita blank limpar vídeo e dedupe pular restore).
- Presence heartbeat **sempre ativo** na Screen (inclui production) — menos falso “desconectado”.
- Watchdog com histerese; reconnect leve sem burst FULL_STATE×2.
- Debounce culto alinhado à dedupe Screen.

## 8.2.1 — 2026-07-20

**Hotfix sync + Live Console ProPresenter**

### Fase A — Sync Screen (anti-tela-preta)

- Screen força **sempre DOM** (`forceDomProjection`); prefs do Controle com `engine:canvas` não ativam compositor na projeção.
- Fallback DOM restaura `.screen-stage` e oculta `#screen-paint` / postFx.
- Slides recebidos durante pré-culto são **bufferizados** e aplicados no unlock.
- Debug: `?debugSync=1` ou `localStorage.SOMOSUM_DEBUG_SYNC=1`.

### Fase B — Layout 3 colunas

- Live Console: **Biblioteca|Ordem** · **Sequência thumbs + Preview 16:9** · **Quick Actions + Inspetor**.
- Miniaturas tipográficas (`.lc-seq-thumb`); estado AO VIVO com borda dourada.
- CSS: `css/ui/layout-live.css` + `css/ui/components-live.css`.

## 8.2.0 — 2026-07-19

**UI/UX Broadcast — Dark Studio**

- Tema **Dark Studio** no Controle: tokens chumbo, accent elétrico, scrollbars finas, botões e modais.
- Shell broadcast: topbar enxuta, **sidebar retrátil**, bottom bar com chip LAN/sync/alertas.
- Workspace Live: prévia hero; cards de rundown com badge de tipo.
- Dock de prévia: toolbar broadcast, espelho BGM, pulse em **Projetar** com tela conectada.
- Gate: `scripts/tests/test-broadcast-ui-shell.ps1`.

## 8.1.0 — 2026-07-19

**Extreme Performance and Render**

- Sync Screen/Stage/Panel **WS-first** (`/ws/sync`); HTTP poll vira heartbeat com WS UP.
- Workers: `slide-fit-worker`, `idb-query-worker`, filtro off-thread na biblioteca Live.
- **Projeção fluida** no Painel e em Ajustes → Sistema: Automático / Máxima fluidez / Economia.
- Default **Automático** = DOM confiável na projeção; Canvas só onde suportado (letras).
- SlideCompositor Canvas2D + WebGL2 postFx gated por ResourceGovernor; fallback DOM.
- Aliases de mídia legada (`sys-bg-*`, `SOMOSUM_S*`) → pack atual em `system/media/`.

## 8.0.6 — 2026-07-19

**Hotfix culto — vídeo de fundo + alinhamento**

- Fundo de vídeo não reinicia a cada estrofe (persist layer).
- Alinhamento tipográfico e safe-area no projetor.

## 8.0.5 — 8.0.1 — 2026-07-19

Polimento de produção: monitores/HDMI no Controle, update seguro do instalador, tipografia, painel e docs.

## 8.0.0 — 2026-07-19

**Production Release**

- **Worship Engine** — sessão litúrgica, command bus, validator, failover, presets.
- **Storage 8.0** — catálogo SQLite, bible packs lazy, DiskAdapter único.
- Gates enterprise e pacote `docs/enterprise/PRODUCTION-RELEASE-8.0.0/`.
- Notas: [`releases/RELEASE-NOTES-8.0.0.md`](releases/RELEASE-NOTES-8.0.0.md).

## 7.9.0 — Storage Platform

Plataforma de storage unificada (repos, índices, WAL).

## 7.8.x — Design System

Tokens, superfícies e kit de UI.

## 7.7.0 — Performance Hub

ResourceGovernor, perfis live/eco, idle cleanup.

## 7.6.0 — Security

Hardening LAN, sanitização, threat model.

## 7.5.0 — Render Engine

Pipeline de render seguro (safe-html).

## 7.4.0 — Versioning SSOT

`VERSION` + `bump-version.js` + `app-meta.js` como fonte única.

## 7.2.x — 7.0.0

Interlinear Pro, Low-Spec, multi-projetor, Culto Pro, plugins, Strong, Designer, backup automático.

## 6.x

Baseline Kestrel in-process, sync P3, assistente de letras, painel gerencial e portal `/docs/`.

---

**Autor:** Reinan Rodrigues · r.rodriguesjs@gmail.com · (75) 99203-4656
