# SOMOSUM 8.8.16 — Hotfix Controle travado após atualização

**Data:** 2026-08-19  
**Tipo:** Correção crítica (hotfix)

### Controle deixa de “congelar” após atualizar
- Corrigido overlay invisível da tela “Atualização aplicada” que bloqueava todos os cliques mesmo quando não aparecia na tela.
- Splash de boot agora libera cliques imediatamente ao sumir (mesmo se o CSS demorar a carregar).
- Limpeza automática de overlays órfãos (splash, skeleton, reconexão) logo ao abrir o Controle.

### Boot mais estável no PC da igreja / com projetor
- Boas-vindas pós-update, tour e verificação de nova versão entram em fila — não competem no mesmo segundo.
- Reduzido trabalho extra ao montar o painel Item do operador (menos repaints no abrir).

### Como atualizar
- Painel → Sobre → Verificar atualização, ou reinicie o SOMOSUM se a checagem automática aparecer.
- Quem está na **8.8.15** aplica este passo e reinicia uma vez.
