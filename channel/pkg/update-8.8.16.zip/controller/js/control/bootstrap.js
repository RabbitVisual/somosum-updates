import '../runtime/engine-boot.js';
import '../runtime/runtime-client.js';
import { initAppMetaRuntime } from '../core/app-meta-boot.js';
import { bootstrapRenderEngine } from '../core/render-engine/index.js';
import { bootstrapSecurity } from '../core/security/index.js';
import { bootstrapPerformance } from '../core/performance/index.js';
import { bootstrapDesignSystem } from '../ui/index.js';
import { initStoragePlatform } from '../core/bootstrap-storage.js';
import { bootstrapWorshipEngine } from '../worship/engine/worship-engine.js';
import { installServerBootGuard, markAppReady } from '../core/server-boot.js';
import { bootstrapLogging } from '../core/bootstrap-logging.js';
import { applyProductionRuntime } from '../core/production-mode.js';
import { initUiScale } from '../core/ui-scale.js';

bootstrapLogging({ module: 'control' });
void initAppMetaRuntime();
bootstrapRenderEngine();
bootstrapSecurity();
bootstrapPerformance('control');
bootstrapDesignSystem('control');
void initStoragePlatform();
bootstrapWorshipEngine('control');
applyProductionRuntime();
initUiScale();
installServerBootGuard({ maxWaitMs: 120000 });
window.__somosumMarkReady = markAppReady;

try {
  document.querySelectorAll('.somosum-tour-backdrop,.somosum-tour-highlight,.somosum-tour-card').forEach((el) => el.remove());
} catch { /* ignore */ }

function showControlBootFatal(err) {
  const msg = err?.message || String(err || 'Erro desconhecido');
  try { document.getElementById('boot-loading')?.remove(); } catch { /* ignore */ }
  try {
    window.__somosumBootSplashReady?.();
    window.__somosumDismissBootSplash?.(() => {});
  } catch { /* ignore */ }
  const app = document.getElementById('app');
  if (!app) return;
  app.innerHTML = `
    <div style="font-family:Segoe UI,sans-serif;background:#0a0a0a;color:#d4c68d;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:2rem;text-align:center">
      <div style="max-width:460px">
        <h1 style="font-size:1.25rem;margin:0 0 .75rem">Falha ao abrir o Controle</h1>
        <p style="color:#888;line-height:1.6;margin:0 0 1rem">${String(msg).replace(/[<>&]/g, '')}</p>
        <button type="button" onclick="location.reload()" style="background:#d4c68d;color:#111;border:none;padding:.7rem 1.4rem;border-radius:8px;cursor:pointer;font-weight:600">Recarregar</button>
      </div>
    </div>`;
}

function forceDismissSplash() {
  try {
    window.__somosumBootSplashReady?.();
    window.__somosumDismissBootSplash?.(() => {});
  } catch { /* ignore */ }
  import('../ui/boot-unblock.js').then(({ clearUiBlockers }) => clearUiBlockers()).catch(() => {});
}

window.__somosumBootTimeout = setTimeout(function () {
  if (!document.getElementById('boot-loading')) return;
  // Shell já montou — splash atrasado, não tratar como falha de servidor.
  if (window.__SOMOSUM_CONTROL_APP || window.__somosumBootSplashApi) {
    forceDismissSplash();
    return;
  }
  forceDismissSplash();
  import('../core/server-boot.js').then(function (m) {
    m.showReconnectOverlay('Carregamento demorado - reconectando...');
    m.waitAndReload();
  }).catch(function () {});
}, 20000);

window.addEventListener('somosum-app-ready', function () {
  clearTimeout(window.__somosumBootTimeout);
  import('../ui/boot-unblock.js').then(({ clearUiBlockers }) => clearUiBlockers()).catch(() => {});
});

// Dynamic import: watchdogs above still run if a dependency fails to load.
import('./control-app.js').then(({ ControlApp }) => {
  try {
    const boot = new ControlApp().init();
    if (boot && typeof boot.then === 'function') {
      const watchdog = setTimeout(() => {
        if (document.getElementById('boot-loading')) {
          console.warn('[SOMOSUM] init demorou - forcando splash');
          forceDismissSplash();
        }
      }, 20000);
      boot.then(() => clearTimeout(watchdog)).catch((err) => {
        clearTimeout(watchdog);
        console.error('[SOMOSUM] ControlApp.init', err);
        showControlBootFatal(err);
      });
    }
  } catch (err) {
    console.error('[SOMOSUM] ControlApp bootstrap', err);
    showControlBootFatal(err);
  }
}).catch((err) => {
  console.error('[SOMOSUM] Falha ao carregar control-app', err);
  showControlBootFatal(err);
});
