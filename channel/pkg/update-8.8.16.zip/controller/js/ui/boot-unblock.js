/**
 * Remove overlays que bloqueiam cliques após boot / atualização.
 */
import { clearAllSkeletonOverlays } from './kit/skeleton-overlay.js';

const BLOCKER_SELECTORS = [
  '#boot-loading',
  '#somosum-boot-overlay',
  '#diag-loading',
];

/** @returns {number} quantos nós removidos ou corrigidos */
export function clearUiBlockers() {
  let n = 0;

  for (const sel of BLOCKER_SELECTORS) {
    const el = document.querySelector(sel);
    if (!el) continue;
    el.remove();
    n += 1;
  }

  n += clearAllSkeletonOverlays();

  const whatsNew = document.getElementById('somosum-whats-new');
  if (whatsNew) {
    if (!whatsNew.classList.contains('is-visible') && !whatsNew.classList.contains('is-leaving')) {
      whatsNew.classList.add('is-visible');
      n += 1;
    }
  }

  return n;
}

/** Garantia tardia — p.ex. WebView2 atrasou rAF ou overlay órfão. */
export function scheduleUiUnblockSafety(delayMs = 3500) {
  setTimeout(() => {
    try { clearUiBlockers(); } catch { /* ignore */ }
  }, delayMs);
}
