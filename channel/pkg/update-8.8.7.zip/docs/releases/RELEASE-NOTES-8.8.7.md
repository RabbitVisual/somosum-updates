# Release Notes — SOMOSUM 8.8.7

**Data:** 2026-08-11  
**Tipo:** correção visual (Controle claro + Stage Pregador) e polish Stage/Remote

## Destaques

### Controle — modo claro legível
- Textos e botões do operador (Limpar, Preta, Logo, Controles, títulos) ficam **escuros sobre fundo claro**.
- Topbar, abas laterais, selects e Live Console acompanham o tema claro sem “branco no branco”.

### Stage — perfil Pregador sem corte
- Layout do púlpito cabe na tela: cabeçalho, conteúdo ao vivo e rodapé **não saem da área visível**.
- A coluna “Ordem do culto” some neste perfil (o próximo item já aparece no monitor).
- Conteúdo longo rola dentro do painel ao vivo; sync e alertas não empurram controles para fora.

### Stage e Remote — visual mais profissional
- Tema claro/escuro alinhado ao Painel gerencial.
- Remote: botões, “Agora” e navegação legíveis no claro; contraste melhorado no escuro.
- Stage: tipografia e tokens de ouro/ink coerentes nos três perfis.

## Como atualizar
1. Se estiver em **8.8.6**: Ajuda → Verificar atualização → **8.8.7** → confirme o reinício.
2. Se estiver atrás: aplique o próximo passo oferecido até chegar em **8.8.7**.
3. Após reiniciar: teste **tema claro** no Controle e o perfil **Pregador** no Stage.

## Verificação rápida
- [ ] Sobre = **8.8.7**
- [ ] Controle em claro: Limpar / Preta / Logo e títulos OPERADOR legíveis
- [ ] Stage → Pregador: relógio, título, próximo e rodapé visíveis sem corte
- [ ] Remote claro/escuro com botões legíveis
