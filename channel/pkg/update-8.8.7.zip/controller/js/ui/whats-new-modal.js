/**
 * Boas-vindas profissional após atualização delta.
 */
import { fetchWhatsNew, markWhatsNewShown } from '../core/app-update-service.js';
import {
  extractUpdateHighlights,
  parseReleaseNotesMeta,
  releaseNotesToHtml,
  coerceNotesBody,
} from '../core/release-notes-format.js';
import { esc } from '../control/utils/escape.js';

function ensureCss() {
  if (document.getElementById('somosum-app-update-css')) return;
  const link = document.createElement('link');
  link.id = 'somosum-app-update-css';
  link.rel = 'stylesheet';
  link.href = '/css/app-update.css';
  document.head.appendChild(link);
}

function cardsHtml(highlights) {
  return highlights.map((h, i) => {
    const items = Array.isArray(h.items) && h.items.length
      ? `<ul class="whats-new-card-list">${h.items.map((it) => `<li>${esc(it)}</li>`).join('')}</ul>`
      : (h.detail ? `<p>${esc(h.detail)}</p>` : '');
    return `
      <article class="whats-new-card-item" style="--i:${i}">
        <span class="whats-new-card-index">${String(i + 1).padStart(2, '0')}</span>
        <h3>${esc(h.title)}</h3>
        ${items}
      </article>`;
  }).join('');
}

export async function maybeShowWhatsNew() {
  const doc = await fetchWhatsNew();
  if (!doc?.version && !doc?.body) return;
  if (document.getElementById('somosum-whats-new')) return;

  ensureCss();

  const ver = String(doc.version || '').trim() || '—';
  const body = coerceNotesBody(doc.body);
  const meta = parseReleaseNotesMeta(body);
  const highlights = extractUpdateHighlights(body, 16);
  const metaLine = [meta.date && `Data: ${meta.date}`, meta.type && meta.type]
    .filter(Boolean)
    .join(' · ');

  const gridInner = highlights.length
    ? cardsHtml(highlights)
    : `<div class="whats-new-notes-fallback">${releaseNotesToHtml(body)}</div>`;

  const fullBlock = body.trim().length > 80
    ? `<details class="whats-new-full" open>
        <summary>Changelog completo da ${esc(ver)}</summary>
        <div class="whats-new-full-body">${releaseNotesToHtml(body)}</div>
      </details>`
    : '';

  const overlay = document.createElement('div');
  overlay.id = 'somosum-whats-new';
  overlay.className = 'whats-new-screen';
  overlay.setAttribute('role', 'dialog');
  overlay.setAttribute('aria-labelledby', 'whats-new-title');
  overlay.innerHTML = `
    <div class="whats-new-atmosphere" aria-hidden="true"></div>
    <div class="whats-new-shell">
      <header class="whats-new-hero">
        <p class="whats-new-brand">SOMOSUM</p>
        <p class="whats-new-kicker">Atualização aplicada</p>
        <h1 id="whats-new-title">Bem-vindo à versão ${esc(ver)}</h1>
        <p class="whats-new-lead">Tudo certo — o sistema foi atualizado neste computador. Seus cultos, músicas e configurações permanecem aqui.</p>
        ${metaLine ? `<p class="whats-new-meta">${esc(metaLine)}</p>` : ''}
        <span class="whats-new-version-pill">v${esc(ver)}</span>
      </header>
      <section class="whats-new-grid" aria-label="O que mudou">
        ${gridInner}
      </section>
      ${fullBlock}
      <footer class="whats-new-foot">
        <button type="button" class="btn btn-primary whats-new-cta" id="whats-new-ok">Começar a usar</button>
      </footer>
    </div>`;
  document.body.appendChild(overlay);

  const close = async () => {
    await markWhatsNewShown().catch(() => {});
    overlay.classList.add('is-leaving');
    setTimeout(() => overlay.remove(), 280);
  };
  overlay.querySelector('#whats-new-ok')?.addEventListener('click', () => { void close(); });
  overlay.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' || e.key === 'Enter') {
      e.preventDefault();
      void close();
    }
  });
  requestAnimationFrame(() => overlay.classList.add('is-visible'));
}
