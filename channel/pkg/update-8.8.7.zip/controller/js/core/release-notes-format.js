/**
 * Parse e formatação de release notes (markdown operador).
 */

/** Normaliza body de notes (evita [object Object] de serialização PowerShell/JSON). */
export function coerceNotesBody(raw) {
  if (raw == null) return '';
  if (typeof raw === 'string') return raw;
  if (typeof raw === 'object') {
    if (typeof raw.value === 'string') return raw.value;
    if (typeof raw.body === 'string') return raw.body;
    if (typeof raw.text === 'string') return raw.text;
    if (typeof raw.content === 'string') return raw.content;
    try {
      if (Array.isArray(raw)) return raw.map((x) => coerceNotesBody(x)).join('\n');
    } catch { /* ignore */ }
  }
  const s = String(raw);
  return s === '[object Object]' ? '' : s;
}

function stripMd(s) {
  return String(s || '')
    .replace(/\*\*(.+?)\*\*/g, '$1')
    .replace(/\*(.+?)\*/g, '$1')
    .replace(/`([^`]+)`/g, '$1')
    .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1')
    .trim();
}

const STOP_SECTIONS = /^(como atualizar|verifica|checklist|notas t[eé]cnicas)\b/i;

/**
 * Extrai seções ### com todos os bullets (ignora “Como atualizar” / checklist).
 * @returns {{ title: string, detail: string, items: string[] }[]}
 */
export function extractUpdateHighlights(body, limit = 12) {
  const text = coerceNotesBody(body);
  const sections = [];
  const orphanBullets = [];
  let current = null;
  let skip = false;

  for (const raw of text.split(/\r?\n/)) {
    const line = raw.replace(/\s+$/, '');
    const h2 = line.match(/^\s*##\s+(.+?)\s*$/);
    if (h2) {
      skip = STOP_SECTIONS.test(h2[1].trim());
      current = null;
      continue;
    }
    if (skip) continue;

    const sec = line.match(/^\s*###\s+(.+?)\s*$/);
    if (sec) {
      current = { title: stripMd(sec[1]), items: [] };
      sections.push(current);
      continue;
    }

    const m = line.match(/^\s*[-*]\s+(.+)\s*$/);
    if (!m) continue;
    if (/^\[[ xX]\]/.test(m[1].trim())) continue;
    const item = stripMd(m[1]);
    if (!item) continue;
    if (current) current.items.push(item);
    else orphanBullets.push(item);
  }

  if (sections.length) {
    return sections.slice(0, limit).map((s) => ({
      title: s.title,
      items: s.items,
      detail: s.items.join(' · '),
    }));
  }

  return orphanBullets.slice(0, limit).map((item) => {
    const dash = item.indexOf('—');
    if (dash > 0 && dash < 56) {
      return { title: item.slice(0, dash).trim(), detail: item.slice(dash + 1).trim(), items: [item] };
    }
    return { title: item.slice(0, 100), detail: '', items: [item] };
  });
}

/** Meta do topo das notes (data, tipo, título). */
export function parseReleaseNotesMeta(body) {
  const text = coerceNotesBody(body);
  const title = (text.match(/^#\s+(.+)$/m) || [])[1]?.trim() || '';
  const date = (text.match(/\*\*Data:\*\*\s*(.+)/i) || [])[1]?.trim() || '';
  const type = (text.match(/\*\*Tipo:\*\*\s*(.+)/i) || [])[1]?.trim() || '';
  return { title: stripMd(title), date: stripMd(date), type: stripMd(type) };
}

/** Markdown simples → HTML (listas, títulos, negrito). */
export function releaseNotesToHtml(text) {
  const lines = coerceNotesBody(text).split(/\r?\n/);
  const out = [];
  let inList = false;
  const closeList = () => {
    if (inList) {
      out.push('</ul>');
      inList = false;
    }
  };
  const esc = (s) => String(s ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
  const inline = (s) => esc(s)
    .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
    .replace(/`([^`]+)`/g, '<code>$1</code>');

  for (const raw of lines) {
    const line = raw.replace(/\s+$/, '');
    if (/^\s*###\s+/.test(line)) {
      closeList();
      out.push(`<h4>${inline(line.replace(/^\s*###\s+/, ''))}</h4>`);
      continue;
    }
    if (/^\s*##\s+/.test(line)) {
      closeList();
      out.push(`<h3>${inline(line.replace(/^\s*##\s+/, ''))}</h3>`);
      continue;
    }
    if (/^\s*#\s+/.test(line)) {
      closeList();
      out.push(`<h2>${inline(line.replace(/^\s*#\s+/, ''))}</h2>`);
      continue;
    }
    const bullet = line.match(/^\s*[-*]\s+(.+)$/);
    if (bullet) {
      if (!inList) {
        out.push('<ul>');
        inList = true;
      }
      out.push(`<li>${inline(bullet[1])}</li>`);
      continue;
    }
    if (/^\s*\d+\.\s+/.test(line)) {
      closeList();
      out.push(`<p class="rn-step">${inline(line.trim())}</p>`);
      continue;
    }
    if (!line.trim()) {
      closeList();
      continue;
    }
    closeList();
    out.push(`<p>${inline(line)}</p>`);
  }
  closeList();
  return out.join('\n');
}
