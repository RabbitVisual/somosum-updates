﻿import {
  APP_VERSION, APP_AUTHOR, APP_AUTHOR_EMAIL, APP_AUTHOR_PHONE,
  APP_DOCS_PATH, creditsLine, formatPhoneBr, getAppMeta,
} from '../../../../core/app-meta.js';
import {
  RENDER_MODE_OPTIONS,
  describeRenderPrefs,
  hydrateRenderPrefs,
} from '../../../../core/performance/render-prefs.js';
import { esc } from '../../../utils/escape.js';

export function sistemaPanelHtml(ctx, activeSection) {
  return `
                  <section class="settings-panel${activeSection === 'sistema' ? ' is-active' : ''}" data-panel="sistema" id="set-panel-sistema">
                    <div class="settings-card">
                      <h3>Interface do operador</h3>
                      <p class="page-desc">Escala e contraste do Controle — não altera a projeção.</p>
                      <div class="form-row-2">
                        <div class="form-block">
                          <label for="set-ui-scale">Escala da interface</label>
                          <select id="set-ui-scale" class="su-select">
                            <option value="0.9" ${Number(ctx.prefs.ui?.scale) === 0.9 ? 'selected' : ''}>Compacta</option>
                            <option value="1" ${!ctx.prefs.ui?.scale || Number(ctx.prefs.ui?.scale) === 1 ? 'selected' : ''}>Padrão</option>
                            <option value="1.15" ${Number(ctx.prefs.ui?.scale) === 1.15 ? 'selected' : ''}>Confortável</option>
                            <option value="1.3" ${Number(ctx.prefs.ui?.scale) === 1.3 ? 'selected' : ''}>Grande</option>
                          </select>
                        </div>
                        <div class="form-block">
                          <label for="set-font-scale">Escala da fonte</label>
                          <select id="set-font-scale" class="su-select">
                            <option value="0.9" ${Number(ctx.prefs.ui?.fontScale) === 0.9 ? 'selected' : ''}>90%</option>
                            <option value="1" ${!ctx.prefs.ui?.fontScale || Number(ctx.prefs.ui?.fontScale) === 1 ? 'selected' : ''}>100%</option>
                            <option value="1.15" ${Number(ctx.prefs.ui?.fontScale) === 1.15 ? 'selected' : ''}>115%</option>
                            <option value="1.3" ${Number(ctx.prefs.ui?.fontScale) === 1.3 ? 'selected' : ''}>130%</option>
                          </select>
                        </div>
                      </div>
                      <label class="settings-toggle"><input type="checkbox" id="set-high-contrast" ${ctx.prefs.highContrast || ctx.prefs.ui?.highContrast ? 'checked' : ''} /><span>Alto contraste (operador)</span></label>
                      <div class="form-block settings-chrome-theme">
                        <label>Tema do operador (global)</label>
                        <p class="form-hint">Painel, Controle, Púlpito e Remote — não altera a projeção da congregação.</p>
                        <div class="settings-chrome-toggle" role="group" aria-label="Tema claro ou escuro">
                          <button type="button" class="btn btn-secondary btn-sm${(ctx.prefs.ui?.chromeTheme || 'dark') === 'dark' ? ' is-active' : ''}" id="set-chrome-dark">Escuro</button>
                          <button type="button" class="btn btn-secondary btn-sm${ctx.prefs.ui?.chromeTheme === 'light' ? ' is-active' : ''}" id="set-chrome-light">Claro</button>
                        </div>
                      </div>
                    </div>
                    <div class="settings-card">
                      <h3>Modo Produção</h3>
                      <p class="page-desc">Backup automático, watchdog e cache de mídia enxuto durante o culto ao vivo.</p>
                      <label class="settings-toggle"><input type="checkbox" id="set-production-mode" ${ctx.prefs.productionMode ? 'checked' : ''} /><span>Ativar Modo Produção</span></label>
                      <p class="settings-hint">Recomendado no culto ao vivo. Desative apenas para manutenção ou importação pesada.</p>
                      <label class="settings-toggle"><input type="checkbox" id="set-low-spec" ${ctx.prefs.lowSpec || ctx.prefs.ui?.lowSpec ? 'checked' : ''} /><span>PC mais leve (menos efeitos)</span></label>
                      <p class="settings-hint">Reduz animações e efeitos. Ideal em notebooks ou computadores mais antigos.</p>
                    </div>
                    <div class="settings-card" id="set-render-card">
                      <h3>Projeção fluida</h3>
                      <p class="page-desc">Deixa a tela do culto mais estável. O modo <strong>Automático</strong> escolhe o melhor para este PC.</p>
                      <fieldset class="settings-render-modes" id="set-render-modes">
                        <legend class="sr-only">Modo de projeção</legend>
                        ${RENDER_MODE_OPTIONS.map((opt) => {
                          const cur = ctx.prefs.render?.mode || 'auto';
                          return `<label class="settings-radio-row">
                            <input type="radio" name="set-render-mode" value="${opt.id}" ${cur === opt.id ? 'checked' : ''} />
                            <span><strong>${opt.label}</strong><small>${opt.hint}</small></span>
                          </label>`;
                        }).join('')}
                      </fieldset>
                      <p class="settings-hint" id="set-render-status">${esc(describeRenderPrefs(hydrateRenderPrefs(ctx.prefs)).statusLabel)} — ${esc(describeRenderPrefs(hydrateRenderPrefs(ctx.prefs)).reason)}</p>
                      <div class="settings-btn-row">
                        <button type="button" class="btn btn-primary btn-sm" id="set-render-apply">Aplicar na projeção</button>
                      </div>
                    </div>
                    <div class="settings-card" id="set-diagnostics-card">
                      <h3>Checagem rápida</h3>
                      <p class="page-desc">Confere se o programa, a rede da igreja, os monitores e a projeção estão em ordem.</p>
                      <div id="set-diag-summary" class="form-hint settings-diag-summary">Clique em “Analisar agora” para uma verificação simples.</div>
                      <div class="settings-btn-row">
                        <button type="button" class="btn btn-primary btn-sm" id="set-run-diagnostics">Analisar agora</button>
                        <button type="button" class="btn btn-secondary btn-sm" id="set-open-diagnostics">Ver detalhes</button>
                      </div>
                    </div>
                    <div class="settings-card" id="set-update-card">
                      <h3>Novidades do SOMOSUM</h3>
                      <p class="page-desc">Veja se há uma versão mais nova. O download é leve e não apaga cultos, músicas nem configurações. Também em <strong>Painel → Sobre</strong>.</p>
                      <div class="settings-btn-row">
                        <button type="button" class="btn btn-primary btn-sm" id="set-check-updates">Procurar novidades</button>
                      </div>
                      <p class="form-hint" id="set-update-status">Versão neste PC: ${APP_VERSION}</p>
                    </div>
                    <div class="settings-card help-guide-card">
                      <h3>Ajuda</h3>
                      <p class="page-desc">Tudo roda neste computador — não depende da nuvem no culto.</p>
                      <div class="help-guide-actions">
                        <button type="button" class="btn btn-primary btn-sm" id="set-start-tour">Iniciar tour guiado</button>
                        <button type="button" class="btn btn-secondary btn-sm" id="set-open-docs">Abrir manual</button>
                        <button type="button" class="btn btn-secondary btn-sm" id="set-reset-tour">Reiniciar tour</button>
                        <button type="button" class="btn btn-secondary btn-sm" id="set-restart-server">Reiniciar o SOMOSUM</button>
                      </div>
                      <div class="help-guide-grid">
                        <div class="help-guide-item"><strong>1. Iniciar</strong><span>Duplo clique em SOMOSUM — ícone na bandeja</span></div>
                        <div class="help-guide-item"><strong>2. Culto</strong><span>Bandeja → Controle + Projeção</span></div>
                        <div class="help-guide-item"><strong>3. Programa</strong><span>Monte a ordem do culto</span></div>
                        <div class="help-guide-item"><strong>4. Designer</strong><span>Ajuste modelos e textos</span></div>
                        <div class="help-guide-item"><strong>5. Mídia</strong><span>Fotos e fundos na aba Mídia</span></div>
                        <div class="help-guide-item"><strong>6. Instalação</strong><span>Use o instalador ou o atalho do Painel</span></div>
                      </div>
                    </div>
                    <div class="settings-card about-card" id="set-about-card">
                      <h3>Sobre o SOMOSUM</h3>
                      <p class="page-desc">Projeção para cultos, neste PC.</p>
                      <dl class="about-dl">
                        <dt>Versão</dt><dd id="set-about-version">${APP_VERSION}</dd>
                        <dt>Data da build</dt><dd id="set-about-build">${getAppMeta().build || '—'}</dd>
                        <dt>Compatibilidade</dt><dd id="set-about-protocol">${getAppMeta().protocol ?? '—'}</dd>
                        <dt>Recursos visuais</dt><dd id="set-about-assets">${getAppMeta().assetRevision || APP_VERSION}</dd>
                        <dt>Base de dados</dt><dd id="set-about-db">${getAppMeta().dbSchemaVersion ?? '—'}</dd>
                        <dt>Desenvolvimento</dt><dd>${esc(APP_AUTHOR)}</dd>
                        <dt>Contato</dt><dd><a href="mailto:${APP_AUTHOR_EMAIL}">${APP_AUTHOR_EMAIL}</a> · <a href="tel:+55${APP_AUTHOR_PHONE}">${formatPhoneBr(APP_AUTHOR_PHONE)}</a></dd>
                        <dt>Manual</dt><dd><a href="${APP_DOCS_PATH}" target="_blank" rel="noopener">Abrir documentação</a></dd>
                        <dt>Produto</dt><dd>SOMOS UM · Projeção para igrejas</dd>
                      </dl>
                      <p class="form-hint" id="set-about-health">Carregando status…</p>
                      <p class="about-credits">${creditsLine(APP_VERSION)}</p>
                    </div>
                  </section>`;
}
