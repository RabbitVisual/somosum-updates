/**
 * Sobre — versão ao vivo, novidades da release e mapa do Painel.
 */
import { getAppMeta } from '../core/app-meta.js';
import {
  extractUpdateHighlights,
  parseReleaseNotesMeta,
  releaseNotesToHtml,
  coerceNotesBody,
} from '../core/release-notes-format.js';
import { SECTIONS, GROUPS } from './panel-shell.js';
import { $, escapeHtml, fetchJson, setText, shell } from './panel-utils.js';

const MAP_BLURB = {
  inicio: 'Checklist e atalhos do culto.',
  superficies: 'Abrir Controle, Projeção, Púlpito e Remote.',
  loja: 'Plugins e recursos extras para o culto.',
  rede: 'Wi‑Fi da igreja, código e celular/tablet.',
  operacao: 'Status e diagnóstico neste PC.',
  monitores: 'Projetor 1 e 2 — onde cada tela abre.',
  recursos: 'CPU e memória deste computador.',
  dados: 'Cópia de segurança e pastas do PC.',
  igreja: 'Nome, logo e fundo das boas-vindas.',
  sobre: 'Versão instalada e o que há de novo.',
};

function mapHtml() {
  return GROUPS.map((g) => {
    const items = SECTIONS.filter((s) => s.group === g.id);
    const rows = items.map((s) => `
      <li class="panel-map__item">
        <button type="button" class="panel-map__link" data-act="goto-section" data-section="${escapeHtml(s.id)}">
          <strong>${escapeHtml(s.label)}</strong>
          <span>${escapeHtml(MAP_BLURB[s.id] || s.hint || '')}</span>
        </button>
      </li>`).join('');
    return `
      <div class="panel-map__group">
        <p class="panel-map__group-label">${escapeHtml(g.label)}</p>
        <ul class="panel-map__list">${rows}</ul>
      </div>`;
  }).join('');
}

export function aboutSectionHtml(active) {
  return `
    <section class="panel-section${active ? ' is-active' : ''}" data-section="sobre">
      <header class="panel-section-head">
        <p class="panel-section-kicker">Ajuda · versão</p>
        <h2>Sobre</h2>
        <p>Veja a versão do SOMOSUM, o que mudou nesta instalação e onde resolver cada coisa no Painel.</p>
      </header>

      <div class="panel-section-stack">
        <article class="panel-tile">
          <header class="panel-tile__head">
            <div>
              <h3>Novidades do SOMOSUM</h3>
              <p>Confira se há uma versão mais nova. Se houver, o download é leve e seus cultos, músicas e configurações continuam neste PC.</p>
            </div>
            <span class="panel-chip panel-chip--soft" id="about-update-badge">—</span>
          </header>
          <p class="panel-card-lead" id="about-update-status">Toque em “Procurar novidades” para ver se já existe algo novo para instalar.</p>
          <div class="panel-tile__actions">
            <button type="button" class="panel-cta panel-cta--primary panel-cta--sm" data-act="check-updates">Procurar novidades</button>
            <button type="button" class="panel-cta panel-cta--ghost panel-cta--sm" data-act="open-control-sistema">Abrir no Controle</button>
          </div>
        </article>

        <article class="panel-tile panel-whats-new-tile" id="about-whats-new-tile">
          <header class="panel-tile__head">
            <div>
              <h3 id="about-whats-new-title">O que há de novo</h3>
              <p id="about-whats-new-lead">Melhorias desta versão — atualizado conforme o que está instalado neste PC.</p>
            </div>
            <span class="panel-chip panel-chip--gold" id="about-whats-new-chip">—</span>
          </header>
          <p class="panel-whats-new__meta" id="about-whats-new-meta" hidden></p>
          <div class="panel-whats-new" id="about-changelog" aria-live="polite">
            <p class="panel-whats-new__loading">Carregando novidades…</p>
          </div>
          <details class="panel-whats-new__full" id="about-changelog-full" hidden>
            <summary>Changelog completo desta versão</summary>
            <div class="panel-whats-new__full-body" id="about-changelog-body"></div>
          </details>
        </article>

        <article class="panel-tile">
          <header class="panel-tile__head">
            <div>
              <h3>Esta instalação</h3>
              <p>Resumo do que está rodando neste computador.</p>
            </div>
            <span class="panel-chip" id="about-install-ver">—</span>
          </header>
          <dl class="panel-stat-grid" id="panel-about">
            <div><dt>Versão</dt><dd id="about-ver">—</dd></div>
            <div><dt>Data da build</dt><dd id="about-build">—</dd></div>
            <div><dt>Compatibilidade</dt><dd id="about-protocol">—</dd></div>
            <div><dt>Recursos visuais</dt><dd id="about-assets">—</dd></div>
            <div><dt>Base de dados</dt><dd id="about-db">—</dd></div>
            <div><dt>Serviço local</dt><dd id="about-engine">—</dd></div>
            <div><dt>Bíblias</dt><dd id="about-bibles">—</dd></div>
            <div><dt>Desenho na tela</dt><dd id="about-konva">—</dd></div>
            <div><dt>Aplicativo</dt><dd id="about-exe">—</dd></div>
            <div><dt>Janela</dt><dd id="about-native">—</dd></div>
          </dl>
          <div class="panel-tile__actions">
            <button type="button" class="panel-cta panel-cta--secondary panel-cta--sm" data-act="restart">Reiniciar o SOMOSUM</button>
            <button type="button" class="panel-cta panel-cta--ghost panel-cta--sm" data-act="integrity-refresh">Conferir arquivos</button>
          </div>
          <p class="panel-about-foot">SOMOSUM — projeção e ordem de culto neste PC · Reinan Rodrigues</p>
        </article>

        <div class="panel-home-grid">
          <article class="panel-tile">
            <header class="panel-tile__head">
              <div>
                <h3>Conferir arquivos</h3>
                <p>Garante que nada essencial do programa esteja faltando ou corrompido.</p>
              </div>
              <span class="panel-chip panel-chip--soft" id="about-integ-badge">—</span>
            </header>
            <p class="panel-card-lead" id="about-integ-detail">Clique em “Conferir arquivos” para uma checagem rápida.</p>
          </article>

          <article class="panel-tile panel-tile--wide">
            <header class="panel-tile__head">
              <div>
                <h3>Onde resolver cada coisa</h3>
                <p>Mapa do Painel — toque em um item para ir até lá.</p>
              </div>
              <span class="panel-chip panel-chip--soft">Mapa</span>
            </header>
            <div class="panel-map">${mapHtml()}</div>
          </article>
        </div>
      </div>
    </section>`;
}

function fallbackHighlights(ver) {
  return [
    {
      title: `SOMOSUM ${ver}`,
      detail: 'As notas desta versão não foram encontradas neste PC. Use “Procurar novidades” com internet ou reinstale a atualização.',
      items: [
        'Confira Ajuda → Procurar novidades',
        'Em Sobre, a versão instalada deve bater com o canal',
      ],
    },
  ];
}

function renderWhatsNewCards(host, highlights) {
  if (!host) return;
  if (!highlights.length) {
    host.innerHTML = '<p class="panel-whats-new__empty">Nenhuma nota desta versão ainda. Use “Procurar novidades” se houver internet.</p>';
    return;
  }
  host.innerHTML = highlights.map((h, i) => {
    const list = Array.isArray(h.items) && h.items.length
      ? `<ul class="panel-whats-new__list">${h.items.map((it) => `<li>${escapeHtml(it)}</li>`).join('')}</ul>`
      : (h.detail ? `<p>${escapeHtml(h.detail)}</p>` : '');
    return `
    <article class="panel-whats-new__card" style="--i:${i}">
      <span class="panel-whats-new__index">${String(i + 1).padStart(2, '0')}</span>
      <h4>${escapeHtml(h.title)}</h4>
      ${list}
    </article>`;
  }).join('');
}

async function loadReleaseNotesBody(ver) {
  const candidates = [
    `/docs/releases/RELEASE-NOTES-${ver}.md`,
    `/content/updates/notes/${ver}.md`,
  ];
  for (const url of candidates) {
    try {
      const res = await fetch(`${url}?_=${Date.now()}`, { cache: 'no-store' });
      if (res.ok) {
        const text = await res.text();
        if (text && text.length > 40 && !/^\s*<!DOCTYPE/i.test(text)) return text;
      }
    } catch { /* try next */ }
  }
  try {
    const info = await fetchJson('/api/app/update/info', 8000);
    if (info?.whatsNew) {
      const doc = typeof info.whatsNew === 'string' ? JSON.parse(info.whatsNew) : info.whatsNew;
      const body = coerceNotesBody(doc?.body);
      if (body && (!doc.version || String(doc.version) === String(ver))) {
        return body;
      }
    }
  } catch { /* ignore */ }
  return '';
}

let _whatsNewVer = '';

export async function refreshAboutWhatsNew(version) {
  const ver = String(version || getAppMeta().version || window.SOMOSUM_VERSION || '').trim() || '—';
  const title = $('about-whats-new-title');
  const lead = $('about-whats-new-lead');
  const chip = $('about-whats-new-chip');
  const metaEl = $('about-whats-new-meta');
  const install = $('about-install-ver');
  const host = $('about-changelog');
  const fullWrap = $('about-changelog-full');
  const fullBody = $('about-changelog-body');

  if (title) title.textContent = `O que há de novo (${ver})`;
  if (chip) chip.textContent = `v${ver}`;
  if (install) install.textContent = ver;
  if (lead) {
    lead.textContent = ver === '—'
      ? 'Melhorias desta versão.'
      : `Changelog da ${ver} — lido desta instalação (cards + texto completo).`;
  }
  if (!host) return;
  if (_whatsNewVer === ver && host.querySelector('.panel-whats-new__card')) return;

  host.innerHTML = '<p class="panel-whats-new__loading">Carregando novidades…</p>';
  if (fullWrap) fullWrap.hidden = true;
  if (metaEl) {
    metaEl.hidden = true;
    metaEl.textContent = '';
  }

  const body = await loadReleaseNotesBody(ver);
  let highlights = extractUpdateHighlights(body, 16);
  if (!highlights.length) highlights = fallbackHighlights(ver);
  renderWhatsNewCards(host, highlights);

  if (body && fullBody && fullWrap) {
    const meta = parseReleaseNotesMeta(body);
    if (metaEl && (meta.date || meta.type)) {
      metaEl.hidden = false;
      metaEl.textContent = [meta.date && `Data: ${meta.date}`, meta.type].filter(Boolean).join(' · ');
    }
    fullBody.innerHTML = releaseNotesToHtml(body);
    fullWrap.hidden = false;
    fullWrap.open = true;
  }

  _whatsNewVer = ver;
}

/** Força reload das novidades (ex.: após checar update). */
export function invalidateAboutWhatsNewCache() {
  _whatsNewVer = '';
}

export function updateAboutMetrics(h) {
  const ver = h.version || window.SOMOSUM_VERSION || getAppMeta().version || '—';
  const meta = getAppMeta();
  setText('about-ver', ver);
  setText('about-build', meta.build || h.build || '—');
  setText('about-protocol', meta.protocol != null ? String(meta.protocol) : '—');
  setText('about-assets', meta.assetRevision || '—');
  setText('about-db', meta.dbSchemaVersion != null ? String(meta.dbSchemaVersion) : '—');
  setText('about-engine', h.serverEngine ? 'Em execução' : '—');
  setText('about-bibles', String(h.bibles ?? 0));
  setText('about-konva', h.konva ? 'OK' : '—');
  setText('about-exe', h.somosumExe ? 'OK' : '—');
  setText('about-native', shell()?.isNativeShell?.() ? 'App nativo' : 'Navegador');
  const install = $('about-install-ver');
  if (install) install.textContent = ver;
  void refreshAboutWhatsNew(ver);
}

export async function refreshIntegrity() {
  const badge = $('about-integ-badge');
  const detail = $('about-integ-detail');
  try {
    const integ = await fetchJson('/api/storage/integrity', 12000);
    if (badge) {
      badge.textContent = integ?.ok ? 'Tudo certo' : 'Atenção';
      badge.className = `panel-chip ${integ?.ok ? '' : 'panel-chip--warn'}`;
    }
    if (detail) {
      const total = integ?.total ?? integ?.checked ?? 0;
      const fail = integ?.fail ?? 0;
      detail.textContent = integ?.ok
        ? `Tudo certo — ${total} itens conferidos.`
        : `${fail} problema(s) em ${total} itens. Se algo essencial sumir, reinstale o SOMOSUM.`;
    }
  } catch (err) {
    if (badge) badge.textContent = '—';
    if (detail) detail.textContent = `Não foi possível conferir: ${escapeHtml(err?.message || 'erro')}`;
  }
}
