import { ProjectionBus, MessageTypes } from '../core/bus.js';
import { SlideEngine } from '../slides/slide-engine.js';
import { DEFAULTS } from '../data/defaults.js';
import { applyTheme } from '../core/themes.js';
import { resolvePrefsAtmosphereId } from '../ui/theme/atmospheres.js';
import {
  getPrefs, savePrefs, getAllAssets, initializeFromDisk,
  resolveChurchWelcomeBgUrl, resolveChurchLogoUrl, resolveChurchWelcomeBgKind,
} from '../core/store.js';
import { loadCustomFonts } from '../core/fonts.js';
import { getCountdownFromPrefs } from '../core/countdown.js';
import { CountdownPlayer } from './countdown-player.js';
import { preloadVersion } from '../bible/bible-service.js';
import { startHealthMonitor } from '../core/health-monitor.js';
import { getRecoveryEngine } from '../runtime/facades/recovery-runtime.js';
import { TaskScheduler } from '../core/task-scheduler.js';
import { TaskIds } from '../core/task-registry.js';
import { defer } from '../core/defer.js';
import { DisplayProjectionEngine } from '../runtime/facades/display-runtime.js';
import { startScreenPresenceHeartbeat, postClientPresence, getScreenClientId } from '../core/client-presence.js';
import { IdleSoftCleanup, noteSlideActivity } from '../core/memory/idle-soft-cleanup.js';
import { saveLastSlideSnapshot, loadLastSlideSnapshot } from './screen-last-slide-cache.js';
import { createOutputHealthMonitor } from '../core/output-health-monitor.js';

async function loadAssets() {
  const stored = await getAllAssets();
  const prefs = getPrefs();
  const church = prefs.church || {};
  return {
    logo: stored.logo || null,
    welcomeBg: stored.welcomeBg || null,
    church,
  };
}

function showWaitingOverlay() {
  let el = document.getElementById('screen-waiting');
  if (el) return;
  el = document.createElement('div');
  el.id = 'screen-waiting';
  el.className = 'screen-waiting';
  el.innerHTML = '<p>Aguardando painel de controle…</p>';
  document.body.appendChild(el);
}

function showFailoverBadge(on) {
  let el = document.getElementById('screen-failover-badge');
  if (!on) {
    el?.remove();
    return;
  }
  if (el) return;
  el = document.createElement('div');
  el.id = 'screen-failover-badge';
  el.className = 'screen-failover-badge';
  el.textContent = 'Modo offline — último slide';
  document.body.appendChild(el);
}

function hideWaitingOverlay() {
  document.getElementById('screen-waiting')?.remove();
}

async function main() {
  // Splash fica fora de #screen-root até o motor pintar
  const qs = new URLSearchParams(location.search);
  const liteMode = qs.get('lite') === '1';
  const productionMode = liteMode || qs.get('production') === '1';
  const screenOutput = (() => {
    const n = Number(qs.get('output'));
    return Number.isFinite(n) && n > 1 ? String(Math.floor(n)) : '1';
  })();
  document.documentElement.dataset.screenOutput = screenOutput;
  document.documentElement.dataset.renderSurface = 'screen';
  if (productionMode) {
    document.documentElement.dataset.productionMode = '1';
  }
  if (!productionMode) {
    await import('../runtime/runtime-client.js');
  }
  await loadCustomFonts();
  try {
    const { startFontCatalogWatch } = await import('../core/fonts.js');
    startFontCatalogWatch({
      intervalMs: 10000,
      onChange: () => { /* @font-face já reinjetado */ },
    });
  } catch { /* ignore */ }
  await initializeFromDisk();
  const {
    hydrateRenderPrefsForSurface,
    ensureRenderPrefsPersisted,
    renderPrefsKey,
  } = await import('../core/performance/render-prefs.js');
  let prefs = hydrateRenderPrefsForSurface(getPrefs(), 'screen');
  try {
    prefs = await ensureRenderPrefsPersisted(getPrefs, savePrefs, { surface: 'screen' });
  } catch { /* ignore */ }
  prefs = hydrateRenderPrefsForSurface(prefs || getPrefs(), 'screen');
  applyTheme(resolvePrefsAtmosphereId(prefs));
  const assets = await loadAssets();
  const defaults = DEFAULTS;
  preloadVersion(prefs.bibleVersion || 'naa').catch(() => {});

  const bus = new ProjectionBus('screen');
  getRecoveryEngine().init({ role: 'screen', bus });
  window.addEventListener('pagehide', () => {
    getRecoveryEngine().shutdown?.();
    try { bus.hub?.stopPolling?.(); } catch { /* ignore */ }
  });

  const root = document.getElementById('screen-root');
  const engine = new SlideEngine(root, { defaults, prefs, assets });
  // v2 (transitions/layers) desativado na Screen — path DOM estável, menos flicker
  engine.startClock();
  engine.hideCursorAfterIdle();
  engine.startBgWatchdog?.();
  IdleSoftCleanup.start();

  let countdownBlocking = false;
  let countdownLockedAt = 0;
  let lastCountdownMsgAt = Date.now();
  let syncedFromControl = false;
  let lastFullStateSeq = 0;
  /** Maior seq/revision já aplicada na projeção — evita FULL_STATE antigo reverter SLIDE recente. */
  let lastAppliedPresentationSeq = 0;
  let lastControlSeenAt = Date.now();
  let lastAppliedSlideKey = '';
  let lastAppliedSlideAt = 0;
  let lastAppliedRenderKey = renderPrefsKey(prefs);
  /** Último slide recebido durante pré-culto — aplicado no unlock. */
  let pendingSlideWhileCountdown = null;
  const debugSync = qs.get('debugSync') === '1'
    || (typeof localStorage !== 'undefined' && localStorage.getItem('SOMOSUM_DEBUG_SYNC') === '1');
  const syncDebug = (...args) => {
    if (debugSync) console.info('[SOMOSUM sync]', ...args);
  };

  const presentationSeqFrom = (payload) => {
    const n = Number(payload?.seq ?? payload?.revision);
    return Number.isFinite(n) && n > 0 ? n : 0;
  };

  const isStalePresentation = (payload) => {
    const seq = presentationSeqFrom(payload);
    return seq > 0 && seq < lastAppliedPresentationSeq;
  };

  const notePresentationApplied = (payload) => {
    const seq = presentationSeqFrom(payload);
    if (seq > 0) {
      lastAppliedPresentationSeq = Math.max(lastAppliedPresentationSeq, seq);
      lastFullStateSeq = Math.max(lastFullStateSeq, seq);
    }
  };

  const outputHealth = createOutputHealthMonitor({
    getEngine: () => engine,
  });
  outputHealth.start(2500);

  // Screen: nunca canvas — prefs do Controle não podem ligar compositor aqui
  engine.forceDomProjection?.();

  const slideFingerprint = (slide) => {
    if (!slide) return '';
    const id = slide.id ?? slide.type ?? '';
    const lines = Array.isArray(slide.lines) ? slide.lines.join('\n') : '';
    const verses = Array.isArray(slide.verses)
      ? slide.verses.map((v) => v?.text || v).join('\n')
      : '';
    const bg = slide.background?.src || slide.background?.url || slide.data?.backgroundMediaId || '';
    const bgPreset = slide.background?.preset || slide.background?.type || '';
    let layerKey = '';
    if (Array.isArray(slide.layers) && slide.layers.length) {
      layerKey = slide.layers.map((l) => {
        const t = String(l?.text || '').slice(0, 40);
        const src = String(l?.src || l?.fillSrc || '').slice(0, 24);
        return `${l?.kind || ''}:${l?.role || ''}:${t}:${src.length}:${l?.x}|${l?.y}`;
      }).join(';');
    }
    const previewKey = slide.previewDataUrl ? `p${String(slide.previewDataUrl).length}` : '';
    let styleKey = '';
    try {
      const st = slide.style || {};
      const fx = slide.lyricsFx || {};
      styleKey = [
        st.fontSize, st.titleSize, st.textSize, st.refSize,
        st.mottoSize, st.preacherSize, st.fromSize, st.photoSize,
        st.fontFamily, st.fontWeight, st.fontStyle, st.textTransform, st.align,
        st.linesPerSlide, st.marginTop, st.marginBottom,
        fx.lineEntrance, fx.highlightPulse, fx.ambient,
        slide.transition,
      ].join('|');
    } catch { /* ignore */ }
    return `${id}|${lines}|${verses}|${slide.currentVerse ?? ''}|${slide.title ?? ''}|${bg}|${bgPreset}|${layerKey}|${previewKey}|${styleKey}`;
  };

  const shouldApplySlide = (slide) => {
    const key = slideFingerprint(slide);
    const now = Date.now();
    // Janela curta só para eco imediato; 80ms evita engolir pushes legítimos
    if (key && key === lastAppliedSlideKey && now - lastAppliedSlideAt < 80) {
      syncDebug('dedupe skip', key.slice(0, 48));
      return false;
    }
    lastAppliedSlideKey = key;
    lastAppliedSlideAt = now;
    return true;
  };

  const applyIncomingPrefs = (incoming) => {
    if (!incoming) return;
    const screenPrefs = hydrateRenderPrefsForSurface(incoming, 'screen');
    const nextKey = renderPrefsKey(screenPrefs);
    if (nextKey !== lastAppliedRenderKey) {
      lastAppliedRenderKey = nextKey;
      engine.updatePrefs(screenPrefs);
      // Só reforça DOM quando prefs mudaram (evita thrash a cada SLIDE)
      engine.forceDomProjection?.();
      syncDebug('prefs applied', engine.prefs?.render?.engine);
    }
  };

  const flushPendingSlide = () => {
    const pending = pendingSlideWhileCountdown;
    pendingSlideWhileCountdown = null;
    if (!pending?.slide) return;
    syncDebug('flush pending slide after countdown');
    if (pending.theme) applyTheme(pending.theme);
    if (pending.prefs) applyIncomingPrefs(pending.prefs);
    if (pending.assets) engine.setAssets(pending.assets);
    if (isStalePresentation(pending)) return;
    if (!shouldApplySlide(pending.slide)) return;
    engine.showSlide(pending.slide, pending.animate === true);
    notePresentationApplied(pending);
    persistSlide(pending.slide);
    sendSlideAck();
  };

  const persistSlide = (slide, extra = {}) => {
    if (!slide) return;
    noteSlideActivity();
    void saveLastSlideSnapshot({
      slide,
      prefs: engine.prefs,
      theme: getPrefs().theme,
      seq: extra.seq || lastFullStateSeq,
    });
  };

  const restoreFailoverSlide = async () => {
    if (syncedFromControl && engine.currentSlide && engine.currentSlide.type !== 'blank') {
      showFailoverBadge(true);
      return true;
    }
    const snap = await loadLastSlideSnapshot();
    if (!snap?.slide) return false;
    if (snap.theme) applyTheme(snap.theme);
    if (snap.prefs) {
      applyIncomingPrefs(hydrateRenderPrefsForSurface(snap.prefs, 'screen'));
    }
    engine.showSlide(snap.slide, false);
    showFailoverBadge(true);
    hideWaitingOverlay();
    return true;
  };

  const assetUrls = () => {
    const church = getPrefs().church || {};
    const welcomeBg = resolveChurchWelcomeBgUrl({ church, assets });
    return {
      logo: resolveChurchLogoUrl({ church, assets }),
      welcomeBg,
      welcomeBgKind: resolveChurchWelcomeBgKind({ church, url: welcomeBg }),
    };
  };

  const sendSlideAck = () => {
    bus.send(MessageTypes.SLIDE_ACK, { ts: Date.now() });
    outputHealth.noteAck();
    const now = Date.now();
    if (!sendSlideAck._lastPresence || now - sendSlideAck._lastPresence > 3000) {
      sendSlideAck._lastPresence = now;
      void postClientPresence({
        clientId: getScreenClientId(),
        role: 'screen',
        label: screenOutput === '1' ? 'Projetor' : `Projetor ${screenOutput}`,
        meta: { ack: true, output: Number(screenOutput) || 1 },
      });
    }
  };

  const unlockCountdown = (reason = 'unlock') => {
    if (!countdownBlocking && !countdownPlayer.isActive()) {
      flushPendingSlide();
      return;
    }
    countdownBlocking = false;
    countdownLockedAt = 0;
    countdownPlayer.apply({ action: 'stop' });
    if (reason === 'watchdog') {
      bus.send(MessageTypes.HEARTBEAT, { needState: true, reason: 'countdown_watchdog' });
    }
    flushPendingSlide();
  };

  const countdownPlayer = new CountdownPlayer({
    root: document.body,
    defaults,
    prefs,
    assets: assetUrls(),
    onAmbientFade: (durationMs) => {
      bus.send(MessageTypes.AMBIENT, { action: 'fadeOut', durationMs });
    },
    onBellPlay: (opts) => {
      bus.send(MessageTypes.AMBIENT, {
        action: 'playBell',
        bellPath: opts.bellPath,
        volume: opts.volume,
      });
    },
    onComplete: ({ welcomeSlide, autoWelcome }) => {
      countdownBlocking = false;
      countdownLockedAt = 0;
      bus.send(MessageTypes.COUNTDOWN, { action: 'complete', autoWelcome });
      if (autoWelcome && welcomeSlide && !pendingSlideWhileCountdown?.slide) {
        engine.showSlide(welcomeSlide, true);
        sendSlideAck();
      }
      flushPendingSlide();
    },
    onPhaseChange: (phase) => {
      if (phase === 'idle') {
        countdownBlocking = false;
        countdownLockedAt = 0;
        flushPendingSlide();
      }
      bus.send(MessageTypes.COUNTDOWN, { action: 'phase', phase });
    },
  });

  const defaultWelcomeSlide = () => {
    const church = getPrefs().church || {};
    return {
      type: 'welcome',
      years: church.defaultWelcomeTitle || 'Bem-vindos',
      theme: church.defaultTheme || '',
      subtitle: church.subtitle || '',
    };
  };

  const restoreCountdown = (state, welcomeSlide = null) => {
    if (!state?.active || !state.targetMs) {
      unlockCountdown('inactive_sync');
      return;
    }
    countdownBlocking = true;
    countdownLockedAt = Date.now();
    lastCountdownMsgAt = Date.now();
    syncedFromControl = true;
    hideWaitingOverlay();
    countdownPlayer.apply({
      action: 'sync',
      state: {
        ...state,
        assets: assetUrls(),
        prefs: getPrefs(),
        bibleVersion: getPrefs().bibleVersion || 'naa',
        welcomeSlide: welcomeSlide || defaultWelcomeSlide(),
      },
    });
    armCountdownWatch();
  };

  let countdownWatchDispose = null;
  const armCountdownWatch = () => {
    countdownWatchDispose?.();
    if (!isCountdownLocked()) return;
    countdownWatchDispose = defer(() => {
      const lockedFor = Date.now() - (countdownLockedAt || lastCountdownMsgAt);
      const staleMsg = Date.now() - lastCountdownMsgAt > 120000;
      if (isCountdownLocked() && (lockedFor > 120000 || staleMsg)) {
        console.warn('[SOMOSUM] Countdown watchdog — liberando tela');
        unlockCountdown('watchdog');
        bus.send(MessageTypes.HEARTBEAT, { needState: true, reason: 'countdown_stale' });
      } else if (isCountdownLocked()) {
        armCountdownWatch();
      }
    }, 30000, 6);
  };

  const applyProgramState = (programState) => {
    if (!programState) return;
    if (programState.overlay === 'blank') engine.showOverlay('blank');
    else if (programState.overlay === 'logo') engine.showOverlay('logo');
  };

  const isCountdownLocked = () => countdownBlocking || countdownPlayer.isActive();

  bus.on((message) => {
    switch (message.type) {
      case MessageTypes.HEARTBEAT:
        if (message.from === 'control') {
          lastControlSeenAt = Date.now();
          hideWaitingOverlay();
          showFailoverBadge(false);
          bus.hub?.boostPolling?.();
          bus.send(MessageTypes.HEARTBEAT, { pong: true });
        }
        break;
      case MessageTypes.SLIDE:
        // Pré-culto travado sem sync recente → libera e aplica (evita buffer eterno / tela preta)
        if (isCountdownLocked() && Date.now() - lastCountdownMsgAt > 5000) {
          syncDebug('countdown stale — unlock for SLIDE');
          unlockCountdown('stale_for_slide');
        }
        if (isCountdownLocked()) {
          pendingSlideWhileCountdown = {
            slide: message.payload?.slide,
            animate: message.payload?.animate === true,
            theme: message.payload?.theme,
            prefs: message.payload?.prefs,
            assets: message.payload?.assets,
          };
          syncDebug('SLIDE buffered (countdown locked)');
          return;
        }
        syncedFromControl = true;
        lastControlSeenAt = Date.now();
        hideWaitingOverlay();
        showFailoverBadge(false);
        const slidePayload = message.payload || {};
        // Hot path: só aplica theme/prefs/assets se vieram no payload (evita trabalho extra)
        if (slidePayload.theme) applyTheme(slidePayload.theme);
        applyIncomingPrefs(slidePayload.prefs);
        if (slidePayload.assets) engine.setAssets(slidePayload.assets);
        if (!slidePayload.slide) {
          syncDebug('SLIDE sem payload.slide — pedindo estado');
          bus.send(MessageTypes.HEARTBEAT, { ready: true, needState: true, reason: 'empty_slide' });
          break;
        }
        if (isStalePresentation(slidePayload)) {
          syncDebug('SLIDE stale skip', presentationSeqFrom(slidePayload), '<', lastAppliedPresentationSeq);
          break;
        }
        if (!shouldApplySlide(slidePayload.slide)) break;
        syncDebug('SLIDE apply', slidePayload.slide?.type, presentationSeqFrom(slidePayload), engine.prefs?.render?.engine);
        // Bíblia e demais tipos complexos = DOM; nunca deixar canvas esconder o stage
        engine.forceDomProjection?.();
        engine.showSlide(slidePayload.slide, slidePayload.animate === true);
        notePresentationApplied(slidePayload);
        if (slidePayload.revision != null) outputHealth.noteRevision(slidePayload.revision);
        persistSlide(slidePayload.slide, { seq: slidePayload.seq || slidePayload.revision });
        sendSlideAck();
        break;
      case MessageTypes.OVERLAY:
        if (isCountdownLocked()) return;
        hideWaitingOverlay();
        if (message.payload?.type === 'clear') engine.clearOverlay(message.payload.slide);
        else if (message.payload?.type) engine.showOverlay(message.payload.type);
        sendSlideAck();
        break;
      case MessageTypes.SETTINGS:
        if (message.payload?.theme || message.payload?.projectionTheme) {
          applyTheme(message.payload.theme || message.payload.projectionTheme);
        } else if (message.payload) {
          applyTheme(resolvePrefsAtmosphereId(message.payload));
        }
        applyIncomingPrefs(message.payload);
        break;
      case MessageTypes.FONTS_RELOAD:
        loadCustomFonts({ injectFaces: true, force: true }).catch(() => {});
        break;
      case MessageTypes.ASSETS:
        if (!message.payload) break;
        if (assets.logo !== message.payload.logo) assets.logo = message.payload.logo;
        if (assets.welcomeBg !== message.payload.welcomeBg) assets.welcomeBg = message.payload.welcomeBg;
        if (message.payload.welcomeBgKind) assets.welcomeBgKind = message.payload.welcomeBgKind;
        engine.setAssets(message.payload);
        break;
      case MessageTypes.COUNTDOWN:
        lastCountdownMsgAt = Date.now();
        if (!message.payload) break;
        if (message.payload.action === 'stop') {
          unlockCountdown('stop');
          syncedFromControl = true;
          countdownPlayer.apply(message.payload);
          break;
        }
        if (message.payload.action === 'start' || message.payload.action === 'sync') {
          restoreCountdown(message.payload.state, message.payload.state?.welcomeSlide);
          break;
        }
        break;
      case MessageTypes.OVERLAY_LAYER:
        if (isCountdownLocked()) return;
        hideWaitingOverlay();
        if (message.payload?.clear) {
          engine.clearOverlayLayer();
        } else if (message.payload) {
          engine.showOverlayLayer(message.payload.overlayId, message.payload.payload || {});
        }
        sendSlideAck();
        break;
      case MessageTypes.FULL_STATE:
        {
          const incomingSeq = Number(message.payload?.seq);
          if (Number.isFinite(incomingSeq) && incomingSeq > 0 && incomingSeq <= lastFullStateSeq) {
            break; // snapshot antigo — ignore (P1 sequence)
          }
          if (Number.isFinite(incomingSeq) && incomingSeq > 0) lastFullStateSeq = incomingSeq;
        }
        syncedFromControl = true;
        lastControlSeenAt = Date.now();
        hideWaitingOverlay();
        showFailoverBadge(false);
        if (message.payload.theme || message.payload.projectionTheme) {
          applyTheme(message.payload.theme || message.payload.projectionTheme);
        } else if (message.payload.prefs) {
          applyTheme(resolvePrefsAtmosphereId(message.payload.prefs));
        }
        if (message.payload.assets) engine.setAssets(message.payload.assets);
        applyIncomingPrefs(message.payload.prefs);
        if (message.payload.countdown?.active) {
          restoreCountdown(message.payload.countdown, message.payload.countdown.welcomeSlide);
        } else {
          unlockCountdown('full_state');
        }
        if (!isCountdownLocked()) {
          // Slide primeiro — depois overlay. Evita blank/logo limpar vídeo e dedupe pular restore.
          if (message.payload.slide) {
            const stageEmpty = !engine.currentSlide
              || !engine.stageEl?.innerHTML
              || engine.currentSlide?.type === 'blank';
            const staleSlide = isStalePresentation(message.payload);
            if (staleSlide) {
              syncDebug('FULL_STATE slide stale skip', presentationSeqFrom(message.payload), '<', lastAppliedPresentationSeq);
            } else if (stageEmpty || shouldApplySlide(message.payload.slide)) {
              engine.showSlide(message.payload.slide, false);
              notePresentationApplied(message.payload);
              persistSlide(message.payload.slide, { seq: message.payload.seq });
              sendSlideAck();
            }
          } else {
            bus.send(MessageTypes.HEARTBEAT, { ready: true, needState: true, reason: 'full_state_empty' });
          }
          const ov = message.payload.programState?.overlay;
          // Só aplica overlay se explícito — não remountar slide limpo
          if (ov === 'blank' || ov === 'logo') {
            applyProgramState(message.payload.programState);
          } else if (engine.overlay) {
            engine.overlay = null;
          }
        } else if (message.payload?.slide) {
          pendingSlideWhileCountdown = {
            slide: message.payload.slide,
            animate: false,
            theme: message.payload.theme,
            prefs: message.payload.prefs,
            assets: message.payload.assets,
          };
          syncDebug('FULL_STATE slide buffered (countdown)');
        }
        break;
      case MessageTypes.STAGE_STATE:
      case MessageTypes.STAGE_NOTE:
      case MessageTypes.STAGE_ALERT:
        break;
      default:
        break;
    }
  });

  bus.send(MessageTypes.HEARTBEAT, { ready: true, needState: true });
  // Presence sempre ativo — evita falso "desconectado" no Controle (production/lite)
  startScreenPresenceHeartbeat(() => ({
    lite: liteMode,
    production: productionMode,
    ready: true,
    output: Number(screenOutput) || 1,
  }));

  // Após recarregar (F5/Ctrl+F5) pede o estado repetidas vezes até sincronizar,
  // para reconectar rápido ao controle sem esperar o heartbeat de 4s.
  let resyncTries = 0;
  TaskScheduler.register({
    id: TaskIds.SCREEN_RESYNC,
    kind: 'interval',
    intervalMs: 1000,
    priority: 5,
    coalesce: true,
    fn: () => {
      resyncTries += 1;
      if (syncedFromControl || resyncTries > 20) {
        TaskScheduler.unregister(TaskIds.SCREEN_RESYNC);
        return;
      }
      bus.send(MessageTypes.HEARTBEAT, { ready: true, needState: true, reason: 'reconnect' });
    },
  });

  TaskScheduler.register({
    id: 'screen-heartbeat',
    kind: 'interval',
    intervalMs: 8000,
    priority: 5,
    runWhenHidden: true,
    fn: () => {
      bus.send(MessageTypes.HEARTBEAT, { ping: true });
    },
  });

  TaskScheduler.scheduleDelayed('screen-boot-blank', 2500, async () => {
    if (syncedFromControl) return;
    const restored = await restoreFailoverSlide();
    if (restored) return;
    showWaitingOverlay();
    engine.showSlide({ type: 'blank' }, false);
  }, 8);

  // Se o Controle sumir por muito tempo, mantém último slide (não apaga a tela)
  TaskScheduler.register({
    id: 'screen-failover-watch',
    kind: 'interval',
    intervalMs: 5000,
    priority: 6,
    runWhenHidden: true,
    fn: () => {
      if (Date.now() - lastControlSeenAt < 20000) return;
      if (engine.currentSlide && engine.currentSlide.type !== 'blank') {
        showFailoverBadge(true);
        return;
      }
      void restoreFailoverSlide();
    },
  });

  document.addEventListener('dblclick', () => {
    toggleScreenFullscreen();
  });

  function toggleScreenFullscreen() {
    try {
      if (typeof window.Engine?.shell?.toggleProjectionFullscreen === 'function') {
        window.Engine.shell.toggleProjectionFullscreen();
        return;
      }
    } catch { /* fallback abaixo */ }
    const el = document.documentElement;
    if (document.fullscreenElement) {
      document.exitFullscreen?.().catch(() => {});
      return;
    }
    el.requestFullscreen?.().catch(() => {});
    if (!el.requestFullscreen && el.webkitRequestFullscreen) el.webkitRequestFullscreen();
  }

  document.addEventListener('keydown', (event) => {
    if (event.code !== 'F11') return;
    event.preventDefault();
    toggleScreenFullscreen();
  });

  if (new URLSearchParams(location.search).get('autofs') === '1') {
    const tryFs = () => {
      const el = document.documentElement;
      if (el.requestFullscreen) return el.requestFullscreen().catch(() => {});
      if (el.webkitRequestFullscreen) return el.webkitRequestFullscreen();
    };
    // WebView2 nativo: C# controla bounds — requestFullscreen causa flash tela reduzida→FS.
    if (window.chrome?.webview) {
      window.addEventListener('somosum-native-ready', () => { /* native layout */ }, { once: true });
    } else {
      tryFs();
      document.body.addEventListener('click', tryFs, { once: true });
    }
  }

  startHealthMonitor({
    onStatusChange: (ok) => {
      if (!ok) console.warn('[SOMOSUM] Servidor offline');
    },
    intervalMs: 30000,
  });

  import('../core/server-boot.js').then(({ markAppReady }) => markAppReady()).catch(() => {});
  requestAnimationFrame(() => {
    requestAnimationFrame(() => {
      try {
        if (typeof window.__somosumFinishBootSplash === 'function') {
          void window.__somosumFinishBootSplash();
        } else {
          document.getElementById('boot-loading')?.remove();
        }
      } catch { /* ignore */ }
    });
  });
}

main();
